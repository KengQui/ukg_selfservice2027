# Bring Your Brand to Work — walkthrough

## Treatment

- **Format:** confirmed 16:9 landscape, 75 seconds. This is the demonstration's runtime, not a measured setup time. The product's existing “5 min” estimate remains unchanged.
- **Promise:** Add a recognizable logo, choose colors, personalize sign-in, then explicitly save.
- **Identity:** current UKG Ready screens supply the real logo, DLS typography, teal, white and gray surfaces. Added captions use DM Sans, dark teal and white. Bright Harbor Bakery LLC is the one fictional business; a separately made bakery wordmark is its sample upload, never the UKG default.
- **Hero:** real screen captures from `/branding/prototypes/system-theme-setup?standalone=1&demo=new-single`, in a fresh browser context. No source imports or edits to the branding application.
- **Motion:** a measured camera over the screen, small pointer moves with a single click ring, action-matched cuts between verified states. No decorative spins or marketing slides.
- **Arc:** establish the screen, upload and check, compare colors, personalize sign-in, finish on the saved login.
- **Payoff:** a close view of the saved sign-in preview replaces the editor. A short pullback and matched cut return to the opening.
- **Sound:** one quiet, warm instrumental bed, no voiceover or sound effects. No claim of music-beat alignment.

## Screen and caption contract

Capture at a true 1920 × 1080 viewport, device scale 1.5, yielding 2880 × 1620 images. Keep full originals. Camera crops are presentation-only; never replace interface text, mock analysis responses or alter the source DOM. Captions occupy a separate lower band, outside the screen viewport. Added copy uses the product voice and exact labels where they identify a control. Existing screen text is retained as captured. Dismiss the development banner using its Close banner button before capture.

All shots retain a small “Bring Your Brand to Work” / “Bright Harbor Bakery LLC” identifier. Chapter labels: “Get started”, “Add your logo”, “Choose your colors”, “Personalize sign-in”, “Save your look”. Captions below are the complete added instructional text. No EIN abbreviation is added; the captured completion fixture's tax ID is fictional.

## Timeline

| Shot | Time | Focus | Action / framing | Handoff |
|---|---|---|---|---|
| 01 | 0–7 | Introduction | Wide to Add your branding | Click-matched cut to upload |
| 02 | 7–14 | Upload | File selection, Upload | Same file persists |
| 03 | 14–22 | Check logo | Verified analysis, selected logo | Next to Theme |
| 04 | 22–30 | Compare colors | Select Navy, show changed preview | Camera transfers to Custom |
| 05 | 30–42 | Custom colors | Custom, Primary color, Accent color | Wider result, Next |
| 06 | 42–50 | Company name | Edit name with sign-in preview | Focus shifts to message |
| 07 | 50–60 | Login message | Edit welcome text; show preview | Pointer prepares Done |
| 08 | 60–67 | Save | Done, What's next?, Preview login | Click-matched full preview |
| 09 | 67–75 | Saved look | Login preview; reassurance | Pullback/dissolve to opening |

## Detailed shot script

### 01 · 0.00–7.00 · 7 seconds
**Purpose:** orient a first-time customer without promising a completion speed.
**Exact caption:** 0–7, “Make Ready feel like your workplace.” Subline: “Start with Add your branding. You can change your look later.”
**Composition/idea:** current introduction fills the screen stage. DLS headline and existing estimate stay visible. The cursor connects the invitation to the real action; no separate title card.
**Choreography:** 0–1 wide hold; 1–3 modest push toward the intro's left side; 3–5 pointer approaches Add your branding; 5.8 ring/click, 6.0 upload screen appears; 6–7 ease back to the upload framing.
**Transition:** retain the screen frame, chapter strip and pointer; action cut plus camera settle, never an empty frame.
**Assets:** intro and upload captures, SVG pointer and ring.
**Sound:** gentle instrumental beginning; no click SFX.

### 02 · 7.00–14.00 · 7 seconds
**Purpose:** show an actual bakery file being added.
**Exact caption:** 7–14, “Upload your company’s logo.” Subline: “Choose the logo file, then select Upload.”
**Composition/idea:** push into Upload your brand assets and the selected-file area. File-to-preview continuity makes the action understandable.
**Choreography:** 7–8.4 show drop zone; 8.4 pointer selects browse; 9.2 selected bright-harbor-bakery.png appears (OS file picker omitted); 9.2–11.5 readable hold; 12.2 pointer clicks Upload; 12.4–14 show actual processing if available, otherwise selected file before settled result.
**Transition:** same uploaded filename and screen position connect to the analysis outcome.
**Assets:** real selected-file, processing and completed-upload captures; locally created fictional wordmark.
**Sound:** quiet music continues.

### 03 · 14.00–22.00 · 8 seconds
**Purpose:** check the actual selected logo rather than trust unseen analysis.
**Exact caption:** 14–22, “Check the selected logo.” Subline: “Use as our brand logo shows which image will appear in Ready.”
**Composition/idea:** frame the uploaded thumbnail, filename and checked Use as our brand logo, then widen for Next. The same bakery mark later occupies the product header.
**Choreography:** 14–16 verified analysis outcome; 16–18.5 small highlight around selected logo; 18.5–20 hold; 20–21.5 pointer approaches and clicks Next; 21.5–22 Theme appears.
**Failure boundary:** if AI analysis is unavailable, retain the real failure capture, select Use as our brand logo through the actual UI, and use the caption “Choose the logo you want to use.” Subline: “If analysis is unavailable, select Use as our brand logo to keep going.” Never fabricate a successful AI response. Update this script to the observed path.
**Assets:** actual outcome, selected logo, Theme screenshots.
**Sound:** understated continuous bed.

### 04 · 22.00–30.00 · 8 seconds
**Purpose:** prove a ready-made palette changes the application preview.
**Exact caption:** 22–30, “Try a palette and check the preview.” Subline: “Your selection changes the colors your team sees in Ready.”
**Composition/idea:** begin wide with Theme and preview together, push right to Choose a palette. The preview header is the visible before/after carrier.
**Choreography:** 22–24 extracted/custom starting view; 24–25 pointer moves to Navy; 25 click; 25.2–28.5 show the actual Navy result, with named preset fields visibly disabled; 28.5–30 pointer transfers to Custom.
**Transition:** application preview persists as the camera widens toward editable settings.
**Assets:** initial palette and Navy captures.
**Sound:** no musical hit required.

### 05 · 30.00–42.00 · 12 seconds
**Purpose:** make the prerequisite for editing unambiguous.
**Exact caption:** 30–36, “Select Custom before changing colors.” Subline: “Then edit Primary color and Accent color to match your brand.”
36–42, “Check your colors in the application preview.” Subline: “You can adjust them again later.”
**Composition/idea:** Custom selection is shown first in a right-side close-up; transfer left to the two labeled fields, then pull back to the changed application. Controlled cause/effect, no color fields mocked over named presets.
**Choreography:** 30–31.5 click Custom and hold its checked state; 32–34 edit Primary color to #245B52; 35–37 edit Accent color to #D99147; 37–40.5 wide result hold; 40.5–41.7 pointer moves/clicks Next; 41.7–42 Login screen appears.
**Transition:** bakery mark stays in the upper preview region while application preview gives way to sign-in.
**Assets:** real Custom selected, primary edit, accent edit, final colors, login captures.
**Sound:** continued gentle bed.

### 06 · 42.00–50.00 · 8 seconds
**Purpose:** personalize the name shown under the logo.
**Exact caption:** 42–50, “Add the name your team recognizes.” Subline: “Company name appears under your logo on the login page.”
**Composition/idea:** paired editor/preview, with close focus on Company name. Actual captured typing states create the link to the live preview.
**Capture preparation:** clear the starter Employee login message through the actual editor before these shots, so its unrelated default support address is not attributed to the bakery. No DOM text replacement.
**Choreography:** 42–44 wider Login screen; 44 pointer focuses Company name; 45–47 replace the legal-name default with “Bright Harbor Bakery”; 47–49 hold the updated name and corresponding preview; 49–50 pointer shifts down to the message.
**Transition:** matched editor geometry, small downward camera reframe.
**Assets:** initial login, name edit, updated-name screenshots.
**Sound:** quiet music; no typing sounds.

### 07 · 50.00–60.00 · 10 seconds
**Purpose:** show a business-specific welcome message and explain unfinished work.
**Exact caption:** 50–55, “Welcome your team in your own words.” Subline: “Update Employee login message and check the sign-in preview.”
55–60, “Need to stop before you’re done?” Subline: “Save and finish later keeps unfinished work. It does not apply your branding.”
**Sample message:** “Welcome to Bright Harbor Bakery\nGood to see you. Sign in to check your schedule and time off.\nNeed help signing in? Ask your bakery manager.”
**Composition/idea:** editor/preview relationship remains visible, then upper header action is briefly highlighted without clicking it. The demo continues to the explicit save.
**Choreography:** 50–53 type the message using captured intermediate states; 53–55 wide preview hold; 55–58 pointer/highlight identifies Save and finish later; 58–60 camera returns to Done.
**Transition:** same final login screen carries across 60; no invented review step.
**Assets:** message typing/final capture and header action bounds.
**Sound:** music remains low under the longer reading caption.

### 08 · 60.00–67.00 · 7 seconds
**Purpose:** distinguish applying the finished setup from keeping a draft.
**Exact caption:** 60–63, “Select Done to save your branding.” Subline: “Your logo, colors, and login message are saved together.”
63–67, “Your company’s look is saved.” Subline: “From What’s next?, select Preview login.”
**Composition/idea:** Done close-up expands to the actual completion page, which shows Bright Harbor Bakery LLC, then Preview login receives attention.
**Choreography:** 60–61.2 pointer click Done; 61.5 completion appears; 61.5–65 readable completion hold; 65–66.7 pointer moves to Preview login and clicks; 66.8 preview appears.
**Transition:** click-matched cut into the saved sign-in; do not depict publishing to a live customer account.
**Assets:** real final login, completion, saved login preview.
**Sound:** gentle resolution begins.

### 09 · 67.00–75.00 · 8 seconds
**Purpose:** give the saved result a clear final hold and state reversibility.
**Exact caption:** 67–74, “A familiar welcome for your team.” Subline: “You can return to Edit theme whenever your look changes.”
**Composition/idea:** crop to the actual sign-in preview panel after Preview login returns to Login screen. The editor is outside the presentation crop; this does not invent a fullscreen-preview feature. Contrast with the opening's setup invitation. Bakery wordmark and welcome text remain legible.
**Choreography:** 67–69 slight push into login; 69–72.7 readable hold; 72.7–74 gentle pullback; 74–75 match-cut to the opening capture and opener caption, settling the camera before the loop with no blank field.
**Transition:** match the outer frame to shot 01 at the loop boundary.
**Assets:** saved login and opening capture.
**Sound:** resolved, faded music ending; scene-owned reset starts the bed on loop.

## Pre-code review

- The requested instructional restraint takes precedence over kinetic marketing-film beat-density and compound-transition rules. Readable holds are intentional, not accidental tails.
- Every major chapter contains a real action/result, not an entrance followed by drift. Alternating wide, right detail, left detail and full saved preview give useful variety.
- Screen stage and caption band never overlap; highlights are local and temporary.
- No claims of AI success before capture evidence. No live publication claims, multi-company screens, Advanced settings, font controls, voiceover or SFX.
- 7 + 7 + 8 + 8 + 12 + 8 + 10 + 7 + 8 = 75 seconds, with no gaps.

## Capture evidence and handoff

- The final capture session used the real logo-analysis service. It returned HTTP 200, selected image 0 and confidence 0.96. The uploaded bakery logo was checked in the real interface. The retained response and control bounds are in `public/images/capture-manifest.json`.
- Original 2880 × 1620 PNGs are retained alongside lossless WebP playback copies. No response mocking, screen-text substitution, customer assets, or branding-app source changes were used.
- Saved storage was checked after Done: the bakery logo filename, #245B52 primary, #D99147 accent, and Bright Harbor Bakery company name matched. The completion screen identifies Bright Harbor Bakery LLC.
- Preview login returns to the Login screen in the current product. The final shot focuses on its actual preview panel; it does not imply a separate fullscreen feature.
- One 75-second instrumental track is included, with soft entrance/exit fades. There is no voiceover or sound effect. Added captions preserve exact product labels and the existing setup estimate.
- `scripts/capture-branding-video.mjs` refreshes source captures in a fresh browser context. `scripts/check-branding-video.mjs` checks preview pause/resume, mute, replay, scene selection, scene-lock, control hiding, a full real-time loop, audio reset, and recording markers.
- Typecheck, build, recording lifecycle validation, and copy check passed. The full loop produced 145 sampled frames with no empty-frame flags. Frames, contact sheets and the playback report are under `screenshots/branding-walkthrough-check/`.
- **Delivery:** playable, export-ready video artifact; **no MP4 or other rendered video file has been exported**. The observed recording markers verify readiness, not a completed file render.

### Local verification commands

```sh
pnpm --filter @workspace/branding-walkthrough typecheck
bash artifacts/branding-walkthrough/scripts/validate-recording.sh
PORT=25254 BASE_PATH=/branding-walkthrough/ pnpm --filter @workspace/branding-walkthrough build
pnpm check:copy artifacts/branding-walkthrough/src
node scripts/check-branding-video.mjs
```