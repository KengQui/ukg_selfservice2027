import { useEffect, useRef } from 'react';

export function MusicBed({ sceneKey, startSeconds, paused, muted }: {
  sceneKey: string; startSeconds: number; paused: boolean; muted: boolean;
}) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const lastScene = useRef<string | null>(null);
  const elapsed = useRef(0);
  const startedAt = useRef(performance.now());
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.volume = 0.45;
    if (lastScene.current !== sceneKey) {
      lastScene.current = sceneKey;
      elapsed.current = 0;
      startedAt.current = performance.now();
      if (Math.abs(audio.currentTime - startSeconds) > 0.18) audio.currentTime = startSeconds;
    }
    if (paused) audio.pause();
    else audio.play().catch(error => {
      if (error.name !== 'NotAllowedError' && error.name !== 'AbortError') console.error('Walkthrough music could not play', error);
    });
  }, [sceneKey, startSeconds, paused, muted]);
  useEffect(() => {
    if (paused) return;
    startedAt.current = performance.now();
    return () => { elapsed.current += (performance.now() - startedAt.current) / 1000; };
  }, [sceneKey, paused]);
  useEffect(() => {
    // A blocked first autoplay starts at the current visual time, not at 0.
    const unlock = () => {
      const audio = audioRef.current;
      if (!audio || paused || !audio.paused) return;
      audio.currentTime = Math.min(74.9, startSeconds + elapsed.current + (performance.now() - startedAt.current) / 1000);
      audio.play().catch(() => {});
    };
    document.addEventListener('pointerdown', unlock);
    document.addEventListener('keydown', unlock);
    return () => {
      document.removeEventListener('pointerdown', unlock);
      document.removeEventListener('keydown', unlock);
    };
  }, [paused, startSeconds]);
  return <audio ref={audioRef} src={`${import.meta.env.BASE_URL}audio/bg_music.mp3`} preload="auto" muted={muted} />;
}