import { useEffect, type ComponentType } from 'react';
import { VideoCanvas, VideoPausedContext, type VideoAspectRatio, useVideoPlayer } from '@/lib/video';
import { AnimatePresence } from 'framer-motion';
import { OpeningScene } from './video_scenes/OpeningScene';
import { UploadScene } from './video_scenes/UploadScene';
import { LogoScene } from './video_scenes/LogoScene';
import { PaletteScene } from './video_scenes/PaletteScene';
import { CustomScene } from './video_scenes/CustomScene';
import { NameScene } from './video_scenes/NameScene';
import { MessageScene } from './video_scenes/MessageScene';
import { SaveScene } from './video_scenes/SaveScene';
import { SavedLookScene } from './video_scenes/SavedLookScene';
import { MusicBed } from './MusicBed';

export const SCENE_DURATIONS = {
  opening: 7000, upload: 7000, logo: 8000, palette: 8000, custom: 12000,
  name: 8000, message: 10000, save: 7000, savedLook: 8000,
};
const SCENES: Record<string, ComponentType> = {
  opening: OpeningScene, upload: UploadScene, logo: LogoScene, palette: PaletteScene,
  custom: CustomScene, name: NameScene, message: MessageScene, save: SaveScene, savedLook: SavedLookScene,
};

const VIDEO_ASPECT_RATIO: VideoAspectRatio = '16:9';
const SCENE_START_SEC = Object.fromEntries(Object.keys(SCENE_DURATIONS).map((key, index) => [
  key, Object.values(SCENE_DURATIONS).slice(0, index).reduce((sum, ms) => sum + ms, 0) / 1000,
]));

export default function VideoTemplate({
  durations = SCENE_DURATIONS, loop = true, paused = false, muted = false, onSceneChange,
}: {
  durations?: Record<string, number>; loop?: boolean; paused?: boolean; muted?: boolean;
  onSceneChange?: (key: string) => void;
} = {}) {
  const { currentSceneKey } = useVideoPlayer({ durations, loop, paused });
  useEffect(() => { onSceneChange?.(currentSceneKey); }, [currentSceneKey, onSceneChange]);
  const baseKey = currentSceneKey.replace(/_r[12]$/, '');
  const sceneIndex = Object.keys(SCENE_DURATIONS).indexOf(baseKey);
  const Scene = SCENES[baseKey];

  return (
    <VideoPausedContext.Provider value={paused}>
      <VideoCanvas aspectRatio={VIDEO_ASPECT_RATIO} style={{ backgroundColor: '#edf3f2' }}>
        <div className="film-header"><span>Bring Your Brand to Work</span><span>Bright Harbor Bakery LLC</span></div>
        <AnimatePresence mode="sync">{Scene && <Scene key={currentSceneKey} />}</AnimatePresence>
        <MusicBed sceneKey={currentSceneKey} startSeconds={SCENE_START_SEC[baseKey] ?? 0} paused={paused} muted={muted} />
        <div className="film-chapter" aria-hidden="true">{Object.keys(SCENE_DURATIONS).map((key, i) => <span className={i === sceneIndex ? 'current' : ''} key={key} />)}</div>
      </VideoCanvas>
    </VideoPausedContext.Provider>
  );
}
