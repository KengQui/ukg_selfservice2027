import { useCallback, useEffect, useRef, useState } from 'react';
import { ChevronDown, ChevronUp, Pause, Play, Repeat, RotateCcw, Volume2, VolumeX } from 'lucide-react';
import VideoTemplate, { SCENE_DURATIONS } from './VideoTemplate';
import { useSceneControls } from './useSceneControls';

const DETAILS: Record<string, { title: string; filePath: string }> = {
  opening: { title: 'Get started', filePath: 'src/components/video/video_scenes/OpeningScene.tsx' },
  upload: { title: 'Upload your logo', filePath: 'src/components/video/video_scenes/UploadScene.tsx' },
  logo: { title: 'Check your logo', filePath: 'src/components/video/video_scenes/LogoScene.tsx' },
  palette: { title: 'Try a palette', filePath: 'src/components/video/video_scenes/PaletteScene.tsx' },
  custom: { title: 'Choose custom colors', filePath: 'src/components/video/video_scenes/CustomScene.tsx' },
  name: { title: 'Add your company name', filePath: 'src/components/video/video_scenes/NameScene.tsx' },
  message: { title: 'Add a welcome message', filePath: 'src/components/video/video_scenes/MessageScene.tsx' },
  save: { title: 'Save your look', filePath: 'src/components/video/video_scenes/SaveScene.tsx' },
  savedLook: { title: 'Preview your saved look', filePath: 'src/components/video/video_scenes/SavedLookScene.tsx' },
};
const formatTime = (ms: number) => `${Math.floor(ms / 60000)}:${Math.floor(ms / 1000 % 60).toString().padStart(2, '0')}`;

function PlaybackStatus({ controls, onJump }: { controls: ReturnType<typeof useSceneControls>; onJump: (index: number) => void }) {
  const { tick, paused, activeIndex, sceneKeys, activeDuration, activeStartTime, totalDuration } = controls;
  const [elapsed, setElapsed] = useState(0);
  const base = useRef(0);
  useEffect(() => { base.current = 0; setElapsed(0); }, [tick]);
  useEffect(() => {
    if (paused) return;
    const start = performance.now();
    const timer = window.setInterval(() => setElapsed(base.current + performance.now() - start), 60);
    return () => { clearInterval(timer); base.current += performance.now() - start; };
  }, [tick, paused]);
  const totalElapsed = Math.min(totalDuration, activeStartTime + Math.min(activeDuration, elapsed));
  return <>
    <div className="scene-segments">{sceneKeys.map((key, i) => <button key={key}
      aria-label={`Jump to scene ${i + 1}: ${DETAILS[key].title}`} title={DETAILS[key].title}
      aria-current={i === activeIndex ? 'true' : undefined} onClick={() => onJump(i)}>
      <span style={{ width: `${i === activeIndex ? Math.min(100, elapsed / activeDuration * 100) : 0}%` }} />
    </button>)}</div>
    <span className="scene-count">{activeIndex + 1}/{sceneKeys.length}</span>
    <span className="playback-time" role="timer" aria-label={`Playback time ${formatTime(totalElapsed)} of ${formatTime(totalDuration)}`}>
      {formatTime(totalElapsed)} / {formatTime(totalDuration)}
    </span>
  </>;
}

export default function VideoWithControls() {
  const controls = useSceneControls(SCENE_DURATIONS, typeof window.startRecording !== 'function');
  const [muted, setMuted] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [hovering, setHovering] = useState(false);
  const [tapPinned, setTapPinned] = useState(false);
  const sensor = useRef<HTMLDivElement>(null);
  const { paused, locked, mountKey, durations, onSceneChange } = controls;
  const jump = useCallback((index: number) => {
    controls.jumpTo(index);
    const detail = DETAILS[controls.sceneKeys[index]];
    window.parent.postMessage({ type: 'REPLIT_VIDEO_SCENE_SELECTED', payload: {
      sceneIndex: index, sceneCount: controls.sceneKeys.length, sceneTitle: detail.title,
      filePath: detail.filePath, lineNumber: 1,
    } }, '*');
  }, [controls.jumpTo, controls.sceneKeys]);
  useEffect(() => {
    if (!paused) return;
    const animations = document.getAnimations().filter(animation => animation.playState === 'running');
    animations.forEach(animation => animation.pause());
    return () => animations.forEach(animation => animation.play());
  }, [paused]);
  useEffect(() => {
    if (!(collapsed && tapPinned)) return;
    const onDown = (event: PointerEvent) => {
      if (event.pointerType !== 'mouse' && !sensor.current?.contains(event.target as Node)) setTapPinned(false);
    };
    document.addEventListener('pointerdown', onDown);
    return () => document.removeEventListener('pointerdown', onDown);
  }, [collapsed, tapPinned]);
  // Only the export renderer starts automatically; normal previews require Play.
  if (typeof window.startRecording === 'function') return <VideoTemplate />;
  const visible = !collapsed || hovering || tapPinned;
  return <div className="video-preview">
    <VideoTemplate key={mountKey} durations={durations} loop paused={paused} muted={muted} onSceneChange={onSceneChange} />
    <div ref={sensor} className="controls-sensor"
      onPointerEnter={e => { if (e.pointerType === 'mouse') setHovering(true); }}
      onPointerLeave={e => { if (e.pointerType === 'mouse') setHovering(false); }}
      onPointerDown={e => { if (e.pointerType !== 'mouse' && collapsed) setTapPinned(true); }}>
      <div className="controls-spacer" aria-hidden="true" />
      <div className={`video-controls ${visible ? 'visible' : ''}`} aria-label="Video controls" aria-hidden={!visible} inert={!visible}>
        <button onClick={controls.togglePause} aria-label={paused ? 'Play' : 'Pause'} title={paused ? 'Play' : 'Pause'}>{paused ? <Play /> : <Pause />}</button>
        <button onClick={controls.toggleLock} aria-label={`Loop current scene: ${locked ? 'on' : 'off'}`} aria-pressed={locked} title="Loop current scene"><Repeat /></button>
        <button onClick={() => setMuted(value => !value)} aria-label={muted ? 'Unmute music' : 'Mute music'} title={muted ? 'Unmute music' : 'Mute music'}>{muted ? <VolumeX /> : <Volume2 />}</button>
        <button onClick={controls.replay} aria-label="Replay video" title="Replay video"><RotateCcw /></button>
        <span className="controls-divider" />
        <PlaybackStatus controls={controls} onJump={jump} />
        <button onClick={() => { setCollapsed(value => !value); setHovering(false); setTapPinned(false); }}
          aria-label={collapsed ? 'Show controls' : 'Hide controls'} title={collapsed ? 'Show controls' : 'Hide controls'} aria-expanded={!collapsed}>
          {collapsed ? <ChevronUp /> : <ChevronDown />}
        </button>
      </div>
    </div>
  </div>;
}