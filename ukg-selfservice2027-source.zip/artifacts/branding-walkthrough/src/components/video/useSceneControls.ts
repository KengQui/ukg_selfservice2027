import { useCallback, useMemo, useState } from 'react';

export function useSceneControls(baseDurations: Record<string, number>, initiallyPaused = true) {
  const sceneKeys = useMemo(() => Object.keys(baseDurations), [baseDurations]);
  const [activeIndex, setActiveIndex] = useState(0);
  const [locked, setLocked] = useState(false);
  const [paused, setPaused] = useState(initiallyPaused);
  const [mountKey, setMountKey] = useState(0);
  const [tick, setTick] = useState(0);
  const durations = useMemo(() => {
    const key = sceneKeys[activeIndex];
    if (locked) return { [`${key}_r1`]: baseDurations[key], [`${key}_r2`]: baseDurations[key] };
    return Object.fromEntries(sceneKeys.map((_, i) => {
      const key = sceneKeys[(activeIndex + i) % sceneKeys.length];
      return [key, baseDurations[key]];
    }));
  }, [baseDurations, sceneKeys, activeIndex, locked]);
  const onSceneChange = useCallback((raw: string) => {
    const index = sceneKeys.indexOf(raw.replace(/_r[12]$/, ''));
    if (index >= 0) setActiveIndex(index);
    setTick(value => value + 1);
  }, [sceneKeys]);
  const jumpTo = useCallback((index: number) => {
    setActiveIndex(index); setPaused(false); setMountKey(value => value + 1);
  }, []);
  const replay = useCallback(() => {
    setLocked(false); setActiveIndex(0); setPaused(false); setMountKey(value => value + 1);
  }, []);
  const toggleLock = useCallback(() => {
    setLocked(value => !value); setPaused(false); setMountKey(value => value + 1);
  }, []);
  return {
    sceneKeys, activeIndex, locked, paused, mountKey, tick, durations, onSceneChange, jumpTo, replay, toggleLock,
    togglePause: () => setPaused(value => !value),
    activeDuration: baseDurations[sceneKeys[activeIndex]],
    activeStartTime: sceneKeys.slice(0, activeIndex).reduce((sum, key) => sum + baseDurations[key], 0),
    totalDuration: Object.values(baseDurations).reduce((sum, ms) => sum + ms, 0),
  };
}