/// <reference lib="dom" />
/// <reference lib="dom.iterable" />
// The workspace base TS config targets Node. Add DOM types without changing
// the managed video scaffold's configuration or runtime files.
import { useEffect, useState } from 'react';
import VideoWithControls from './VideoWithControls';
import { screenUrls } from './screenAssets';

const IMAGES = [
  '01-intro', '02-upload', '03-file-selected', '04-analyzing', '05-analysis-outcome',
  '06-logo-selected', '07-theme', '08-navy', '09-custom', '10-primary', '11-colors',
  '12-login', '13-name-typing', '14-name', '15-message-typing', '16-message',
  '17-completion', '18-saved-login',
];
export default function VideoAssets() {
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    let active = true;
    Promise.all([
      document.fonts.ready,
      // Keep compressed files ready; decoding every 2880px screen at once
      // exceeds browser bitmap-cache budgets. The SVG decodes the visible shot.
      ...IMAGES.map(async name => {
        if (screenUrls[name]) return;
        const response = await fetch(`${import.meta.env.BASE_URL}images/${name}.webp`);
        if (!response.ok) throw new Error(`Walkthrough image could not load: ${name}`);
        screenUrls[name] = URL.createObjectURL(await response.blob());
      }),
      fetch(`${import.meta.env.BASE_URL}audio/bg_music.mp3`).then(response => {
        if (!response.ok) throw new Error('Music could not be loaded');
        return response.arrayBuffer();
      }),
    ]).then(() => { if (active) setReady(true); })
      .catch(error => { console.error('Walkthrough assets could not load', error); if (active) setFailed(true); });
    return () => { active = false; };
  }, []);
  if (failed) return <div className="video-loading"><p>The walkthrough couldn’t load. Reload the page to try again.</p></div>;
  if (!ready) return <div className="video-loading" role="status">Loading walkthrough…</div>;
  return <VideoWithControls />;
}