import { useState } from 'react';
import { motion } from 'framer-motion';
import { useSceneTimer } from '@/lib/video';
import { screenImageUrl } from './screenAssets';

export type Camera = { x: number; y: number; width: number };
export type Point = { x: number; y: number };
export type Cue = {
  at: number;
  image?: string;
  camera?: Camera;
  cursor?: Point | null;
  click?: boolean;
  focus?: { x: number; y: number; width: number; height: number } | null;
  isolate?: { x: number; y: number; width: number; height: number } | null;
  title?: string;
  caption?: string;
};
export type Shot = { title: string; caption: string; duration: number; cues: Cue[] };
export const WIDE: Camera = { x: 0, y: 100, width: 1920 };

/** The only moving canvas contains captured pixels, never recreated product UI. */
export function ScreenShot({ shot }: { shot: Shot }) {
  const [elapsed, setElapsed] = useState(0);
  useSceneTimer(Array.from({ length: Math.ceil(shot.duration / 40) }, (_, index) => ({
    time: index * 40,
    callback: () => setElapsed(index * 40),
  })));
  let image = shot.cues[0].image!;
  let title = shot.title;
  let caption = shot.caption;
  let camera = shot.cues[0].camera ?? WIDE;
  let cursor: Point | null = null;
  let focus: Cue['focus'] = null;
  let isolate: Cue['isolate'] = null;
  let clickAt = -10000;
  let lastCamera = camera;
  let lastCursor = cursor as Point | null;
  for (const cue of shot.cues) {
    if (cue.at > elapsed) break;
    if (cue.image) image = cue.image;
    if (cue.title) title = cue.title;
    if (cue.caption) caption = cue.caption;
    if (cue.focus !== undefined) focus = cue.focus;
    if (cue.isolate !== undefined) isolate = cue.isolate;
    if (cue.click) clickAt = cue.at;
    if (cue.camera) {
      const progress = Math.min(1, Math.max(0, (elapsed - cue.at) / 800));
      const eased = progress * progress * (3 - 2 * progress);
      camera = {
        x: lastCamera.x + (cue.camera.x - lastCamera.x) * eased,
        y: lastCamera.y + (cue.camera.y - lastCamera.y) * eased,
        width: lastCamera.width + (cue.camera.width - lastCamera.width) * eased,
      };
      lastCamera = cue.camera;
    }
    if (cue.cursor !== undefined) {
      const progress = Math.min(1, Math.max(0, (elapsed - cue.at) / 600));
      const eased = progress * progress * (3 - 2 * progress);
      cursor = cue.cursor && lastCursor
        ? { x: lastCursor.x + (cue.cursor.x - lastCursor.x) * eased, y: lastCursor.y + (cue.cursor.y - lastCursor.y) * eased }
        : cue.cursor;
      lastCursor = cue.cursor;
    }
  }
  const ringProgress = Math.min(1, (elapsed - clickAt) / 650);
  return (
    <motion.section className="film-shot" data-shot={shot.cues[0].image} data-elapsed={elapsed}
      initial={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.12 }}>
      <div className="screen-window">
        <svg viewBox={`${camera.x} ${camera.y} ${camera.width} ${camera.width * 900 / 1920}`}
          preserveAspectRatio="xMidYMid slice" className="screen-capture" aria-label={title}>
          {isolate && <defs><clipPath id="saved-preview-crop"><rect {...isolate} /></clipPath></defs>}
          <image href={screenImageUrl(image)} x="0" y="0" width="1920" height="1080"
            clipPath={isolate ? 'url(#saved-preview-crop)' : undefined} />
          {focus && <rect {...focus} x={focus.x - 5} y={focus.y - 5} width={focus.width + 10} height={focus.height + 10}
            rx="8" fill="none" stroke="#D99147" strokeWidth="3" />}
          {cursor && <g transform={`translate(${cursor.x} ${cursor.y})`} aria-hidden="true">
            {ringProgress < 1 && <circle r={12 + ringProgress * 25} fill="#D99147" fillOpacity={(1 - ringProgress) * 0.22}
              stroke="#9A631F" strokeOpacity={1 - ringProgress} strokeWidth="2" />}
            <path d="M0 0 L0 26 L7 19 L13 31 L18 28 L12 17 L23 17 Z"
              fill="#ffffff" stroke="#142E2C" strokeWidth="2" strokeLinejoin="round" />
          </g>}
        </svg>
      </div>
      <div className="film-caption">
        <h1>{title}</h1>
        <p>{caption}</p>
      </div>
    </motion.section>
  );
}