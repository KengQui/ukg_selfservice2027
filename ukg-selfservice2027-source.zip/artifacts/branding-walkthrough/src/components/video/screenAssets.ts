// Compressed blobs avoid simultaneous decoding of all high-resolution frames.
export const screenUrls: Record<string, string> = {};
export function screenImageUrl(name: string) {
  return screenUrls[name] ?? `${import.meta.env.BASE_URL}images/${name}.webp`;
}