import { ScreenShot, type Shot } from '../ScreenShot';
const shot: Shot = {
  title: 'Welcome your team in your own words.',
  caption: 'Update Employee login message and check the sign-in preview.',
  duration: 10000,
  cues: [
    { at: 0, image: '14-name', camera: { x: 0, y: 435, width: 1050 }, cursor: { x: 265, y: 630 } },
    { at: 300, click: true },
    { at: 800, image: '15-message-typing' },
    { at: 2100, image: '16-message', cursor: null },
    { at: 2900, camera: { x: 690, y: 250, width: 1230 } },
    { at: 5000, title: 'Need to stop before you’re done?', caption: 'Save and finish later keeps unfinished work. It does not apply your branding.',
      camera: { x: 890, y: 75, width: 1030 }, focus: { x: 1582, y: 112, width: 169, height: 34 } },
    { at: 7900, focus: null, camera: { x: 0, y: 680, width: 850 } },
    { at: 9000, cursor: { x: 171, y: 1052 } },
  ],
};
export function MessageScene() { return <ScreenShot shot={shot} />; }