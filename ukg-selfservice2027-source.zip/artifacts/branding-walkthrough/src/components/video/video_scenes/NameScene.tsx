import { ScreenShot, type Shot } from '../ScreenShot';
const shot: Shot = {
  title: 'Add the name your team recognizes.',
  caption: 'Company name appears under your logo on the login page.',
  duration: 8000,
  cues: [
    { at: 0, image: '12-login', camera: { x: 0, y: 100, width: 1920 } },
    { at: 1500, camera: { x: 0, y: 300, width: 1000 }, cursor: { x: 480, y: 450 } },
    { at: 2300, cursor: { x: 270, y: 390 } },
    { at: 3000, click: true },
    { at: 3400, image: '13-name-typing' },
    { at: 4400, image: '14-name' },
    { at: 5000, camera: { x: 630, y: 240, width: 1290 }, cursor: null },
    { at: 7000, camera: { x: 0, y: 435, width: 1050 } },
  ],
};
export function NameScene() { return <ScreenShot shot={shot} />; }