import { ScreenShot, WIDE, type Shot } from '../ScreenShot';
const shot: Shot = {
  title: 'A familiar welcome for your team.',
  caption: 'You can return to Edit theme whenever your look changes.',
  duration: 8000,
  cues: [
    { at: 0, image: '18-saved-login', camera: { x: 0, y: 100, width: 1920 } },
    { at: 600, camera: { x: 490, y: 220, width: 1550 }, isolate: { x: 800, y: 245, width: 960, height: 685 } },
    { at: 5700, camera: { x: 430, y: 185, width: 1700 } },
    { at: 7000, image: '01-intro', camera: WIDE, isolate: null, title: 'Make Ready feel like your workplace.',
      caption: 'Start with Add your branding. You can change your look later.' },
  ],
};
export function SavedLookScene() { return <ScreenShot shot={shot} />; }