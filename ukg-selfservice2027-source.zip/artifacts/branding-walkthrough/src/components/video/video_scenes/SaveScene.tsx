import { ScreenShot, type Shot } from '../ScreenShot';
const shot: Shot = {
  title: 'Select Done to save your branding.',
  caption: 'Your logo, colors, and login message are saved together.',
  duration: 7000,
  cues: [
    { at: 0, image: '16-message', camera: { x: 0, y: 680, width: 850 }, cursor: { x: 171, y: 1052 } },
    { at: 1000, click: true },
    { at: 1500, image: '17-completion', camera: { x: 0, y: 190, width: 1250 }, cursor: null },
    { at: 3000, title: 'Your company’s look is saved.', caption: 'From What’s next?, select Preview login.' },
    { at: 4700, cursor: { x: 320, y: 480 } },
    { at: 5100, cursor: { x: 201, y: 564 } },
    { at: 6400, click: true },
    { at: 6800, image: '18-saved-login', camera: { x: 0, y: 100, width: 1920 }, cursor: null },
  ],
};
export function SaveScene() { return <ScreenShot shot={shot} />; }