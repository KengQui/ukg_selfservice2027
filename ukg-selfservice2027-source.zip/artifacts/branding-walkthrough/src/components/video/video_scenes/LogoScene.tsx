import { ScreenShot, type Shot } from '../ScreenShot';
const shot: Shot = {
  title: 'Check the selected logo.',
  caption: 'Use as our brand logo shows which image will appear in Ready.',
  duration: 8000,
  cues: [
    { at: 0, image: '05-analysis-outcome', camera: { x: 460, y: 465, width: 1080 } },
    { at: 1500, image: '06-logo-selected', focus: { x: 674, y: 614, width: 360, height: 52 } },
    { at: 4300, focus: null },
    { at: 5700, cursor: { x: 1050, y: 740 } },
    { at: 6200, cursor: { x: 810, y: 865 } },
    { at: 7100, click: true },
    { at: 7500, image: '07-theme', camera: { x: 0, y: 100, width: 1920 }, cursor: null },
  ],
};
export function LogoScene() { return <ScreenShot shot={shot} />; }