import { ScreenShot, type Shot } from '../ScreenShot';
const shot: Shot = {
  title: 'Select Custom before changing colors.',
  caption: 'Then edit Primary color and Accent color to match your brand.',
  duration: 12000,
  cues: [
    { at: 0, image: '08-navy', camera: { x: 0, y: 100, width: 1920 }, cursor: { x: 881, y: 798 } },
    { at: 300, click: true },
    { at: 600, image: '09-custom', focus: { x: 819, y: 768, width: 125, height: 64 } },
    { at: 1800, camera: { x: 0, y: 610, width: 950 }, focus: null },
    { at: 2400, cursor: { x: 290, y: 731 } },
    { at: 3100, click: true },
    { at: 3600, image: '10-primary' },
    { at: 4600, cursor: { x: 290, y: 849 } },
    { at: 5400, click: true },
    { at: 6200, image: '11-colors', title: 'Check your colors in the application preview.', caption: 'You can adjust them again later.' },
    { at: 7300, camera: { x: 0, y: 100, width: 1920 }, cursor: null },
    { at: 9900, cursor: { x: 280, y: 905 } },
    { at: 10300, cursor: { x: 170, y: 974 } },
    { at: 11200, click: true },
    { at: 11700, image: '12-login', cursor: null },
  ],
};
export function CustomScene() { return <ScreenShot shot={shot} />; }