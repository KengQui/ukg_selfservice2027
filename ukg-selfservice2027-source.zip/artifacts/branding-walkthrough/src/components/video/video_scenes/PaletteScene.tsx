import { ScreenShot, type Shot } from '../ScreenShot';
const shot: Shot = {
  title: 'Try a palette and check the preview.',
  caption: 'Your selection changes the colors your team sees in Ready.',
  duration: 8000,
  cues: [
    { at: 0, image: '07-theme', camera: { x: 0, y: 100, width: 1920 } },
    { at: 700, camera: { x: 520, y: 210, width: 1400 }, cursor: { x: 1100, y: 690 } },
    { at: 2200, cursor: { x: 1280, y: 798 } },
    { at: 3000, click: true },
    { at: 3200, image: '08-navy', focus: { x: 803, y: 245, width: 957, height: 56 } },
    { at: 5500, camera: { x: 0, y: 100, width: 1920 }, focus: null },
    { at: 6600, cursor: { x: 881, y: 798 } },
  ],
};
export function PaletteScene() { return <ScreenShot shot={shot} />; }