import { ScreenShot, WIDE, type Shot } from '../ScreenShot';

const shot: Shot = {
  title: 'Make Ready feel like your workplace.',
  caption: 'Start with Add your branding. You can change your look later.',
  duration: 7000,
  cues: [
    { at: 0, image: '01-intro', camera: WIDE },
    { at: 1000, camera: { x: 0, y: 180, width: 1450 }, cursor: { x: 370, y: 450 } },
    { at: 4200, cursor: { x: 104, y: 618 } },
    { at: 5800, click: true },
    { at: 6100, image: '02-upload', camera: { x: 450, y: 195, width: 1020 }, cursor: null },
  ],
};
export function OpeningScene() { return <ScreenShot shot={shot} />; }