import { ScreenShot, type Shot } from '../ScreenShot';
const shot: Shot = {
  title: 'Upload your company’s logo.',
  caption: 'Choose the logo file, then select Upload.',
  duration: 7000,
  cues: [
    { at: 0, image: '02-upload', camera: { x: 450, y: 195, width: 1020 }, cursor: { x: 820, y: 350 } },
    { at: 650, cursor: { x: 1040, y: 429 } },
    { at: 1400, click: true },
    { at: 2200, image: '03-file-selected', camera: { x: 460, y: 345, width: 1080 }, cursor: null },
    { at: 4000, cursor: { x: 1080, y: 620 } },
    { at: 4500, cursor: { x: 1190, y: 563 } },
    { at: 5200, click: true },
    { at: 5500, image: '04-analyzing', camera: { x: 460, y: 290, width: 1080 }, cursor: null },
  ],
};
export function UploadScene() { return <ScreenShot shot={shot} />; }