import VideoAssets from '@/components/video/VideoAssets';

export default function App() {
  return <VideoAssets />;
}
