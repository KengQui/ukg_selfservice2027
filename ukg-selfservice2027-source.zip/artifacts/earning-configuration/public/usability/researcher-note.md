# Cedar Vale Instruments — researcher note

Keep this note separate from the participant upload files. All company and payroll details are fictional.

## Participant facts

Cedar Vale Instruments has 80 hourly team members: 30 in Engineering and 50 in Manufacturing. The supplied reports cover September 1–15 and September 16–30, 2026. Each person has 80 ordinary paid hours per period, including any paid leave. Overtime is additional.

- REG is ordinary hourly work.
- VAC, SICK and BEREAV pay vacation, sick leave and bereavement leave at the person's regular hourly rate.
- HOL pays a holiday that was not worked, at the regular hourly rate. Eight hours appear in the first period.
- OT ENG and OT MFG both pay the full 1.5-times base hourly rate for overtime hours. They differ only by department. Regular hours do not include those overtime hours.
- MILEAGE pays documented business miles at the fictional company's rate of $0.60 per mile. This is not a statement of an IRS rate or a tax conclusion.
- BONREV recovers a $150 overpayment from an earlier bonus paid before both supplied periods. It appears as a negative amount in the source Earnings section intentionally.
- COVIDSP was extra pay for working on-site during the COVID-19 pandemic. There are no payments under it in either supplied period. The company has not supplied a decision about future use.
- The company also uses BONUS for occasional bonuses. BONUS is intentionally missing from this incomplete code list and these registers. The participant can add it in the additional earning-code step.

## Research boundaries

The code list is incomplete, not a complete inventory of current or historical pay. Do not interpret an absent code or absent recent payments as proof that a code is inactive. Do not invent a recent BONUS or COVIDSP payment.

The built-in review starts with five background matches (REG, VAC, SICK, HOL and BEREAV). The two overtime codes, MILEAGE, BONREV and COVIDSP remain review work. No participant response is prefilled and no AI mapping is guaranteed.

These reports cover earnings/payment detail, not complete tax, withholding or net payroll calculations. Counts by code are distinct people; people can appear under several codes. Period totals reconcile with the employee detail, but adding code counts does not give company headcount.
