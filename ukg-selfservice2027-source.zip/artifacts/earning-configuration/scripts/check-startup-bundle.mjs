import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import { gzipSync } from 'node:zlib'

const output = new URL('../dist/public/', import.meta.url)
const manifest = JSON.parse(await readFile(new URL('.vite/manifest.json', output), 'utf8'))
const entries = Object.entries(manifest)
const entry = entries.find(([, chunk]) => chunk.isEntry)?.[0]
const setup = entries.find(([, chunk]) => chunk.name === 'SetupApp')?.[0]
const presentation = 'src/presentation/question-pipeline/index.tsx'
assert.ok(entry && setup && manifest[presentation], 'Build the app with its Vite manifest first')

// Dynamic entries are NOT part of a route's initial download unless rendering that
// route immediately requests them. Count each static dependency once, including the
// lazy SetupApp module needed to display the intro (not merely the tiny router).
function graph(...roots) {
  const visited = new Set()
  const visit = key => {
    if (visited.has(key)) return
    assert.ok(manifest[key], `Missing manifest entry: ${key}`)
    visited.add(key)
    for (const dependency of manifest[key].imports ?? []) visit(dependency)
  }
  roots.forEach(visit)
  return visited
}

const initialSetup = graph(entry, setup)
const initialPresentation = graph(entry, presentation)
assert.ok(!initialSetup.has(presentation), 'The intro must not download the presentation')
assert.ok(!initialPresentation.has(setup), 'The presentation must not download the setup/session module')
const phaseNames = [
  // Prepared results belong to StepAnalysis; the review overview is its own lazy page.
  'StepCategorySelection', 'StepUpload', 'StepAnalysis', 'StepReviewOverview', 'StepQuestions',
  'StepReview', 'StepOptimization', 'StepOvertime', 'StepSummary',
]
for (const name of phaseNames) {
  const phase = entries.find(([, chunk]) => chunk.name === name)?.[0]
  assert.ok(phase, `${name} must remain a separate, available phase`)
  assert.ok(!initialSetup.has(phase), `${name} must not download with the intro`)
  assert.ok(!initialPresentation.has(phase), `${name} must not download with the presentation`)
  assert.ok(manifest[setup].dynamicImports?.includes(phase), `${name} must be reachable from setup`)
}

async function measure(keys) {
  const files = [...new Set([...keys].map(key => manifest[key].file))].filter(file => file.endsWith('.js'))
  const sizes = await Promise.all(files.map(async file => {
    const bytes = await readFile(new URL(file, output))
    return { file, bytes: bytes.length, gzipBytes: gzipSync(bytes).length }
  }))
  return {
    files: sizes,
    bytes: sizes.reduce((sum, file) => sum + file.bytes, 0),
    gzipBytes: sizes.reduce((sum, file) => sum + file.gzipBytes, 0),
  }
}

// Baseline: unchanged production build before route/phase splitting. Decimal KB.
const baseline = { bytes: 1395548, gzipBytes: 422770 }
const startup = await measure(initialSetup)
const readOnly = await measure(initialPresentation)
// A modest budget catches loss of the benefit without tying checks to exact hashes.
assert.ok(startup.gzipBytes < 400000, `Startup exceeds the 400 KB gzip budget: ${startup.gzipBytes}`)
console.log(JSON.stringify({
  output: fileURLToPath(output),
  baseline,
  startup,
  presentation: readOnly,
  reduction: {
    bytes: baseline.bytes - startup.bytes,
    gzipBytes: baseline.gzipBytes - startup.gzipBytes,
    gzipPercent: Number(((1 - startup.gzipBytes / baseline.gzipBytes) * 100).toFixed(2)),
  },
}, null, 2))