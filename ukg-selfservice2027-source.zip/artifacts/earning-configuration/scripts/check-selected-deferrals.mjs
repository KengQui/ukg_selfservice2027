import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium, expect } = require('@playwright/test')
const base = process.env.EARNING_PREVIEW_URL || 'http://localhost:80/earning-configuration/'
const browser = await chromium.launch({ executablePath: '/repl/tools/bin/chromium' })
const supportingOnly = process.argv.includes('--supporting-only')

// An isolated browser only. No overtime-demo seed, fabricated email, or AI stand-in.
try {
  const page = await browser.newPage({ viewport: { width: 1366, height: 900 } })
  const errors = []
  page.on('pageerror', error => errors.push(error.message))
  await page.goto(base)
  await page.getByRole('button', { name: 'Start', exact: true }).waitFor()
  async function seed(savedPreview = false) {
    await page.evaluate(async ({ savedPreview }) => {
      const dir = new URL('./src/prototypes/earning-configuration/', location.href).href
      const { createSession, reduceSession } = await import(`${dir}session.ts`)
      const { findItem, ASK_CUSTOMER } = await import(`${dir}sampleRegister.ts`)
      const { discussionEntries } = await import(`${dir}deferredReview.ts`)
      const { WORKING_COPY_KEY, SAVED_COPY_KEY } = await import(`${dir}storage.ts`)
      const item = findItem('BONREV')
      let state = { ...createSession(Date.now()), step: 'questions', selectedCategory: 'earnings',
        rounds: [{ number: 2, itemIds: [item.id], submitted: false }] }
      if (savedPreview) {
        for (const action of [
          { type: 'choose', itemId: item.id, choice: ASK_CUSTOMER },
          { type: 'selectDeferredQuestion', itemId: item.id, source: { question: item.question,
            choices: [item.accept.label], options: [{ id: item.accept.id, label: item.accept.label }], control: 'checkbox' } },
          { type: 'submitRound' },
        ]) state = reduceSession(state, action)
        const entry = discussionEntries(state)[0]
        state = reduceSession(state, { type: 'setDiscussionAnswer', itemId: item.id, question: entry.question,
          basis: entry.basis, kind: 'review-choices', change: { choice: item.accept.id } })
        state = reduceSession(state, { type: 'prepareDiscussionReview' })
      }
      sessionStorage.removeItem(WORKING_COPY_KEY)
      localStorage.removeItem(SAVED_COPY_KEY)
      ;(savedPreview ? localStorage : sessionStorage).setItem(savedPreview ? SAVED_COPY_KEY : WORKING_COPY_KEY, JSON.stringify(state))
    }, { savedPreview })
    await page.reload()
  }
  async function setup() {
    return page.evaluate(async () => {
      const { WORKING_COPY_KEY, SAVED_COPY_KEY } = await import(new URL('./src/prototypes/earning-configuration/storage.ts', location.href).href)
      const state = JSON.parse(sessionStorage.getItem(WORKING_COPY_KEY) || localStorage.getItem(SAVED_COPY_KEY))
      return { answers: state.answers, resolutions: state.resolutions, receipts: state.discussionApplications ?? [],
        sent: state.sent, replies: state.customerReplies }
    })
  }
  if (!supportingOnly) {
    await seed()
    await expect(page.getByRole('button', { name: 'Next', exact: true })).toBeDisabled()
    await page.locator('.ec-defer label').click()
    await page.getByRole('button', { name: 'Next', exact: true }).click()
    await page.getByRole('heading', { name: 'Let’s fill in the gaps in your pay code setup', exact: true }).waitFor()
    await expect(page.locator('.ec-discussion__response')).toHaveCount(1)
    await expect(page.getByRole('button', { name: 'Review answers', exact: true })).toHaveCount(0)
    await page.locator('.ec-discussion__response label').click()
    const before = await setup()
    assert.deepEqual(await setup(), before)
    await page.getByRole('button', { name: 'Apply answer', exact: true }).click()
    await expect(page.getByRole('heading', { name: 'Optimize codes', exact: true })).toBeVisible()
    await page.reload()
    assert.equal((await setup()).receipts.length, 1)
    assert.equal((await setup()).sent, undefined)
    assert.equal((await setup()).replies, undefined)
    console.log('PASS: actual Defer, original checkbox, inline Apply and idempotent restoration')
  }
  // These supporting checks can run independently after the manual/live-AI journey.
  await seed(true)
  await page.getByRole('heading', { name: 'Let’s fill in the gaps in your pay code setup', exact: true }).waitFor()
  const savedOnly = await setup()
  assert.equal(savedOnly.resolutions.BONREV.status, 'customer')
  assert.equal(savedOnly.receipts.length, 0)
  await expect(page.locator('[data-testid="row-cheat-BONREV"] .ec-qcard__sequence-answer')).toBeVisible()
  const beforeHelp = await setup()
  await page.getByRole('button', { name: 'About the AI summary' }).click()
  const dialog = page.getByRole('dialog')
  await expect(dialog).toBeVisible()
  await expect(dialog.locator('li')).toHaveCount(7)
  await expect(dialog).toContainText('Keep discussion responses separate from applied decisions.')
  await page.keyboard.press('Escape')
  assert.deepEqual(await setup(), beforeHelp)
  console.log('PASS: saved-only unapplied preview restored; original answer retained; approved help unchanged')

  await page.goto(new URL('presentation/question-pipeline#pipeline', base).href)
  for (const viewport of [{ width: 390, height: 844 }, { width: 1366, height: 900 }]) {
    await page.setViewportSize(viewport)
    await page.getByRole('heading', { name: 'Where the engine uses AI', exact: true }).waitFor()
    const disclosure = page.locator('details').filter({ has: page.locator('summary', { hasText: 'Read the pipeline as text' }) })
    if ((await disclosure.getAttribute('open')) === null) await disclosure.locator('summary').click()
    const geometry = await page.evaluate(() => ({ width: innerWidth, scroll: document.documentElement.scrollWidth }))
    assert(geometry.scroll <= geometry.width + 1, JSON.stringify(geometry))
    await expect(page.locator('.qp-subflow')).toBeVisible()
    await disclosure.locator('summary').focus()
    await page.keyboard.press('Enter')
    console.log(`PASS: pipeline and text branch fit ${viewport.width}px, keyboard disclosure works`)
  }
  assert.deepEqual(errors, [])
} finally {
  await browser.close()
}
