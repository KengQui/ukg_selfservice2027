// Check real stacking and clicks, which jsdom cannot exercise.
// Run against both the preview proxy and a standalone public development link.
// BASE_URL=http://localhost:80 PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH=$(which chromium) \
//   pnpm --filter @workspace/earning-configuration test:demo-bryte-close
// BASE_URL=https://$REPLIT_DEV_DOMAIN PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH=$(which chromium) \
//   pnpm --filter @workspace/earning-configuration test:demo-bryte-close
import assert from 'node:assert/strict'
import { existsSync } from 'node:fs'
import { createRequire } from 'node:module'

const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium, expect } = require('@playwright/test')
const browser = await chromium.launch({
  executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH ||
    (existsSync('/repl/tools/bin/chromium') ? '/repl/tools/bin/chromium' : undefined),
})
const appUrl = new URL('/earning-configuration/', process.env.BASE_URL || 'http://localhost:80').href
const source = '/earning-configuration/src/prototypes/earning-configuration/'

async function seed(page, scenario) {
  await page.evaluate(async ({ source, scenario }) => {
    const { createSession, reduceSession, parseSession } = await import(`${source}session.ts`)
    const { WORKING_COPY_KEY, SAVED_COPY_KEY } = await import(`${source}storage.ts`)
    let session = reduceSession(createSession(), { type: 'startReview' })
    if (scenario === 'follow-up') {
      session.rounds = [
        { ...session.rounds[0], submitted: true },
        { number: 2, itemIds: ['MILEAGE TX'], submitted: false },
      ]
      session.reviewCursor = 0
    }
    const restored = parseSession(JSON.stringify(session))
    if (restored?.step !== 'questions') throw new Error(`Could not restore ${scenario} review`)
    localStorage.removeItem(SAVED_COPY_KEY)
    sessionStorage.setItem(WORKING_COPY_KEY, JSON.stringify(restored))
  }, { source, scenario })
  await page.reload()
  await expect(page.locator('[data-demo-fill]')).toHaveCount(1)
  await expect(page.locator('.ec-review-heading')).toBeVisible()
  // Never dismiss the banner as test setup: that would hide a blocked Close.
  await expect(page.locator('#replit-dev-banner')).toHaveCount(0)
  await expect(page.getByRole('button', { name: 'Close banner', exact: true })).toHaveCount(0)
}

async function snapshot(page) {
  return page.evaluate(async source => {
    const { WORKING_COPY_KEY } = await import(`${source}storage.ts`)
    return sessionStorage.getItem(WORKING_COPY_KEY)
  }, source)
}

try {
  for (const width of [1280, 390, 320]) {
    const page = await browser.newPage({ viewport: { width, height: 900 }, reducedMotion: 'reduce' })
    const errors = []
    page.on('pageerror', error => errors.push(error.message))
    await page.goto(appUrl)
    // Let the provider finish its initial working-copy write before replacing the fixture.
    await expect(page.locator('#ec-pay-heading')).toBeVisible()
    for (const scenario of ['initial', 'follow-up']) {
      await seed(page, scenario)
      const before = await snapshot(page)
      const launcher = page.locator('button.ask-bryte-launcher')
      const panel = page.locator('.ask-bryte-panel [role="dialog"]')
      await launcher.click()
      await expect(panel).toBeVisible()
      const close = panel.getByRole('button', { name: 'Close panel', exact: true })
      const hit = await close.evaluate(button => {
        const box = button.getBoundingClientRect()
        const target = document.elementFromPoint(box.x + box.width / 2, box.y + box.height / 2)
        return { receivesClick: button.contains(target), target: target?.outerHTML.slice(0, 500) }
      })
      assert.ok(hit.receivesClick, `${scenario} at ${width}px: visible Close is covered by ${hit.target}`)
      // No force click or Escape: the visible control must receive a real pointer click.
      await close.click({ timeout: 5000 })
      await expect(panel).toHaveCount(0)
      await expect(launcher).toBeFocused()
      assert.equal(await snapshot(page), before, 'Closing Bryte must not fill or change payroll answers')

      // The same top-right presenter target still runs the original script, without navigation.
      const expected = await page.evaluate(async source => {
        const { WORKING_COPY_KEY } = await import(`${source}storage.ts`)
        const { reviewPages, reviewPosition, reduceSession } = await import(`${source}session.ts`)
        const { demoFill } = await import(`${source}demoAnswers.ts`)
        const session = JSON.parse(sessionStorage.getItem(WORKING_COPY_KEY))
        const ids = reviewPages(session)[reviewPosition(session).index]
        const actions = demoFill(session, ids)
        if (!actions.length) throw new Error('Fixture must exercise scripted demo fill')
        const filled = actions.reduce(reduceSession, session)
        return { answers: filled.answers, step: filled.step, cursor: filled.reviewCursor, rounds: filled.rounds }
      }, source)
      await page.locator('[data-demo-fill]').click({ timeout: 5000 })
      await expect.poll(async () => {
        const session = JSON.parse(await snapshot(page))
        return { answers: session.answers, step: session.step, cursor: session.reviewCursor, rounds: session.rounds }
      }).toEqual(expected)
      console.log(`PASS ${scenario} at ${width}px: visible Close, unchanged answers, restored focus, scripted fill`)
    }
    assert.deepEqual(errors, [], `Browser errors at ${width}px`)
    await page.close()
  }
} finally {
  await browser.close()
}
