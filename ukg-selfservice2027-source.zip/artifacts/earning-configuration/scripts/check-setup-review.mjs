import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium, expect } = require('@playwright/test')
const base = process.env.EARNING_PREVIEW_URL || 'http://localhost:80/earning-configuration/'
const browser = await chromium.launch({ executablePath: '/repl/tools/bin/chromium' })
try {
  const page = await browser.newPage({ viewport: { width: 1366, height: 900 } })
  await page.goto(base)
  await page.getByRole('button', { name: 'Start', exact: true }).waitFor()
  // Restore one original completed Something else, not a Defer or sent reply.
  const label = await page.evaluate(async () => {
    const dir = new URL('./src/prototypes/earning-configuration/', location.href).href
    const { createSession, reduceSession } = await import(`${dir}session.ts`)
    const { findItem } = await import(`${dir}sampleRegister.ts`)
    const { SOMETHING_ELSE_MAIN } = await import(`${dir}somethingElse.ts`)
    const { WORKING_COPY_KEY, SAVED_COPY_KEY } = await import(`${dir}storage.ts`)
    let session = { ...createSession(Date.now()), step: 'questions',
      rounds: [{ number: 2, itemIds: ['TIPS'], submitted: false }] }
    for (const action of [
      { type: 'chooseSomethingElse', itemId: 'TIPS', question: SOMETHING_ELSE_MAIN },
      { type: 'describeSomethingElse', itemId: 'TIPS', description: 'Our pooled tips need a separate setup decision.' },
      { type: 'submitSomethingElse', itemId: 'TIPS' }, { type: 'submitRound' },
    ]) session = reduceSession(session, action)
    sessionStorage.removeItem(WORKING_COPY_KEY)
    localStorage.setItem(SAVED_COPY_KEY, JSON.stringify(session))
    return findItem('TIPS').options[0].label
  })
  async function state() {
    return page.evaluate(async () => {
      const { WORKING_COPY_KEY, SAVED_COPY_KEY } = await import(new URL('./src/prototypes/earning-configuration/storage.ts', location.href).href)
      return JSON.parse(sessionStorage.getItem(WORKING_COPY_KEY) || localStorage.getItem(SAVED_COPY_KEY))
    })
  }
  await page.reload()
  await page.getByRole('heading', { name: 'Review required questions', exact: true }).waitFor()
  await expect(page.locator('.ec-discussion__response')).toHaveCount(0)
  await expect(page.getByTestId('button-continue-optimization')).toHaveCount(0)
  const original = await state()
  await expect(page.getByText('Earlier saved answer', { exact: true })).toBeVisible()
  await page.getByText(label, { exact: true }).click()
  // Back opens history, not a skipped page that immediately sends us forward again.
  const proposal = (await state()).discussionPreview
  await page.getByTestId('button-work-back').click()
  await expect(page.getByText('These answers have already been applied.', { exact: false })).toBeVisible()
  await expect(page.getByTestId('button-apply-answers')).toHaveCount(0)
  await page.reload()
  await page.getByRole('button', { name: 'Return to setup', exact: true }).click()
  assert.deepEqual((await state()).discussionPreview, proposal)
  await page.getByTestId('button-finish-work').click()
  await page.getByRole('heading', { name: 'Review and apply answers', exact: true }).waitFor()
  assert.deepEqual((await state()).resolutions, original.resolutions)
  assert.deepEqual((await state()).answers, original.answers)
  await page.getByRole('button', { name: 'Save and finish later', exact: true }).click()
  await page.waitForURL(url => url.pathname.includes('company-setup'))
  await page.goto(base)
  await page.getByRole('heading', { name: 'Review and apply answers', exact: true }).waitFor()
  await page.evaluate(async () => {
    const { WORKING_COPY_KEY } = await import(new URL('./src/prototypes/earning-configuration/storage.ts', location.href).href)
    sessionStorage.removeItem(WORKING_COPY_KEY)
  })
  await page.reload()
  await page.getByRole('heading', { name: 'Review and apply answers', exact: true }).waitFor()
  await page.getByTestId('button-preview-back').click()
  await page.getByRole('heading', { name: 'Review required questions', exact: true }).waitFor()
  await page.setViewportSize({ width: 390, height: 844 })
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), true)
  await page.getByTestId('button-finish-work').focus()
  await page.keyboard.press('Enter')
  await page.getByTestId('button-apply-answers').click()
  await expect(page.getByRole('heading', { name: 'Optimize codes', exact: true })).toBeVisible()
  const applied = await state()
  assert.equal(applied.resolutions.TIPS.status, 'resolved')
  assert.equal(applied.discussionApplications.length, 1)
  assert.deepEqual(applied.discussionApplications[0].originalAnswers, { TIPS: original.answers.TIPS })
  assert.equal(applied.sent, undefined)
  assert.equal(applied.customerReplies, undefined)
  await page.reload()
  await expect(page.getByRole('heading', { name: 'Optimize codes', exact: true })).toBeVisible()
  assert.equal((await state()).discussionApplications.length, 1)
  console.log('PASS: saved Something else → owning proposal → unchanged setup → saved-only preview → editable Back → explicit Apply → optimization; earlier history retained, narrow layout and keyboard Finish')
} finally {
  await browser.close()
}
