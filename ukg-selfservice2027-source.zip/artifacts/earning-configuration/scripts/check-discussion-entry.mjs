// In-card deferred review, explicit Done, sticky controls, and explicit Apply.
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { existsSync, mkdirSync } from 'node:fs'
const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium, expect } = require('@playwright/test')
const browser = await chromium.launch({ executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH
  || (existsSync('/repl/tools/bin/chromium') ? '/repl/tools/bin/chromium' : undefined) })
const url = new URL('/earning-configuration/', process.env.BASE_URL || 'http://localhost:80').href
const dir = '/earning-configuration/src/prototypes/earning-configuration/'
try {
  for (const width of [1280, 390]) {
    const page = await browser.newPage({ viewport: { width, height: 844 } })
    const errors = []
    page.on('pageerror', error => errors.push(error.message))
    // This check isolates the entry UI, not the external model's availability.
    let checks = 0
    await page.route('**/api/earnings/**', route => {
      const path = new URL(route.request().url()).pathname
      if (path.includes('description')) {
        checks++
        return route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({
          outcome: 'reference', referenceId: 'RDY-E-060', reason: 'Corrects earlier pay.',
          followUpId: null, question: null, answerFormat: null,
        }) })
      }
      return route.fulfill({ status: 503, contentType: 'application/json', body: JSON.stringify({ error: 'Unavailable for this check.' }) })
    })
    await page.route('**/*', route => {
      if (route.request().isNavigationRequest() && new URL(route.request().url()).pathname === '/') {
        return route.fulfill({ status: 200, contentType: 'text/html', body: '<title>Saved review exit</title>' })
      }
      return route.fallback()
    })
    await page.goto(url)
    const seed = async (ids, pending = false) => {
      await page.evaluate(async ({ dir, ids, pending }) => {
        const { discussionEntryFixture } = await import(dir + 'discussionEntry.testing.ts')
        const { WORKING_COPY_KEY, SAVED_COPY_KEY } = await import(dir + 'storage.ts')
        const state = discussionEntryFixture(ids)
        if (pending) state.rounds.push({ number: 2, itemIds: ['TIPS RPT'], submitted: false })
        localStorage.removeItem(SAVED_COPY_KEY)
        sessionStorage.setItem(WORKING_COPY_KEY, JSON.stringify(state))
      }, { dir, ids, pending })
      await page.reload()
      await expect(page.getByRole('heading', { name: 'Let’s fill in the gaps in your pay code setup', exact: true })).toBeVisible()
    }
    const stored = () => page.evaluate(async dir => {
      const { WORKING_COPY_KEY } = await import(dir + 'storage.ts')
      return JSON.parse(sessionStorage.getItem(WORKING_COPY_KEY))
    }, dir)
    const progress = page.getByTestId('discussion-entry-progress')
    const review = page.getByRole('button', { name: 'Apply answers', exact: true })
    const incomplete = page.getByTestId('button-first-incomplete')
    const response = id => page.getByTestId(`discussion-answer-${id}-0`)
    const hit = async locator => {
      assert(await locator.evaluate(el => {
        const r = el.getBoundingClientRect()
        const at = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2)
        return r.left >= 0 && r.right <= innerWidth && r.top >= 0 && r.bottom <= innerHeight
          && !!at && (el.contains(at) || at.contains(el))
      }), `Control obscured at ${width}px: ${await locator.textContent()}`)
    }
    await seed(undefined, true)
    const original = await stored()
    await expect(progress).toHaveText('0 of 4 opening answers entered')
    await expect(review).toBeDisabled()
    assert.equal(checks, 0)
    await page.evaluate(() => scrollTo(0, 650))
    await hit(incomplete)
    await incomplete.focus()
    await page.keyboard.press('Enter')
    await expect(response('BONREV').locator('input')).toBeFocused()
    await page.keyboard.press('Space')
    await expect(progress).toHaveText('1 of 4 opening answers entered')
    await expect(page.getByTestId('row-cheat-BONREV').locator('.ec-setup-summary')).toBeVisible()
    await response('OTPREM').getByText('Something else', { exact: true }).click()
    await expect(response('OTPREM')).toContainText('Add details for the answer you selected.')
    await incomplete.click()
    await expect(response('OTPREM').locator('textarea')).toBeFocused()
    await hit(response('OTPREM').locator('textarea'))
    await response('OTPREM').locator('textarea').fill('   ')
    await expect(progress).toHaveText('1 of 4 opening answers entered')
    await response('OTPREM').locator('textarea').fill('We need to confirm the calculation.')
    await expect(progress).toHaveText('2 of 4 opening answers entered')
    await response('SPPAY').locator('textarea').fill('   ')
    await expect(progress).toHaveText('2 of 4 opening answers entered')
    await response('SPPAY').locator('textarea').fill('x'.repeat(2001))
    await expect(response('SPPAY')).toContainText('Shorten your answer to 2,000 characters or fewer.')
    await incomplete.click()
    await expect(response('SPPAY').locator('textarea')).toBeFocused()
    await response('SPPAY').locator('textarea').fill('Corrections for earlier pay periods.')
    await response('MISC7').locator('textarea').fill('Daily amounts for meals during business travel.')
    await expect(progress).toHaveText('4 of 4 opening answers entered')
    await expect(review).toBeDisabled()
    assert.equal(checks, 0, 'No live assessment on typing page')
    await page.getByTestId('button-clear-discussion-card-MISC7').click()
    await expect(progress).toHaveText('3 of 4 opening answers entered')
    await incomplete.click()
    await expect(response('MISC7').locator('textarea')).toBeFocused()
    await page.keyboard.type('Daily amounts for meals during business travel.')
    await expect(progress).toHaveText('4 of 4 opening answers entered')
    await page.keyboard.press('Tab')
    await hit(page.locator(':focus'))
    assert.deepEqual((await stored()).resolutions, original.resolutions)
    assert.deepEqual((await stored()).answers, original.answers)
    await page.evaluate(() => scrollTo(0, 1000))
    await hit(review)
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1))
    if (process.env.DISCUSSION_ENTRY_SCREENSHOTS) {
      mkdirSync(process.env.DISCUSSION_ENTRY_SCREENSHOTS, { recursive: true })
      await page.screenshot({ path: `${process.env.DISCUSSION_ENTRY_SCREENSHOTS}/entry-${width}.jpg` })
    }
    await page.getByTestId('button-done-discussion-SPPAY-0').click()
    await expect(page.getByRole('heading', { name: 'Let’s fill in the gaps in your pay code setup', exact: true })).toBeVisible()
    await expect(page.getByTestId('row-cheat-SPPAY').locator('.ec-qcard__sequence-answer').first()).toBeVisible()
    await expect.poll(() => checks).toBeGreaterThan(0)
    await expect(page.getByRole('button', { name: /Use.*Retroactive pay/ })).toBeVisible()
    await expect(page.getByTestId('button-apply-answers')).toBeDisabled()
    assert.equal((await stored()).discussionApplications, undefined)
    assert.deepEqual((await stored()).resolutions, original.resolutions)
    const captured = await stored()
    await expect(progress).toHaveText('4 of 4 opening answers entered')
    await page.reload()
    await expect(progress).toHaveText('4 of 4 opening answers entered')
    assert.deepEqual((await stored()).discussionAnswers, captured.discussionAnswers)
    assert.deepEqual((await stored()).callAnswers, captured.callAnswers)
    await page.getByRole('button', { name: 'Save and finish later', exact: true }).click()
    await page.goto(url)
    await page.evaluate(async dir => {
      const { WORKING_COPY_KEY, SAVED_COPY_KEY } = await import(dir + 'storage.ts')
      if (!localStorage.getItem(SAVED_COPY_KEY)) throw new Error('Explicit saved copy missing')
      sessionStorage.removeItem(WORKING_COPY_KEY)
    }, dir)
    await page.reload()
    await expect(progress).toHaveText('4 of 4 opening answers entered')
    assert.deepEqual((await stored()).discussionAnswers, captured.discussionAnswers)
    assert.deepEqual((await stored()).discussionPreview, captured.discussionPreview)
    await page.getByRole('button', { name: 'Back', exact: true }).click()
    await expect(page.getByText('These answers have already been applied.', { exact: false })).toBeVisible()
    await page.getByRole('button', { name: 'Return to setup', exact: true }).click()
    await expect(progress).toHaveText('4 of 4 opening answers entered')
    await page.getByTestId('button-next-round').click()
    assert.equal((await stored()).discussionApplications, undefined)
    assert.equal((await stored()).step, 'questions')
    await seed()
    await page.getByTestId('button-demo-optimization').click()
    assert.equal((await stored()).step, 'optimization')
    assert.equal((await stored()).discussionApplications, undefined)
    // A supported, explicitly selected proposal still needs the final Apply.
    await seed(['BONREV'])
    await response('BONREV').locator('label').click()
    await expect(page.getByTestId('button-apply-answers')).toBeEnabled()
    assert.equal((await stored()).discussionApplications, undefined)
    await page.getByTestId('button-apply-answers').click()
    await expect(page.getByTestId('discussion-applied')).toBeVisible()
    assert.equal((await stored()).discussionApplications.length, 1)
    await page.reload()
    assert.equal((await stored()).discussionApplications.length, 1)
    assert.deepEqual(errors, [])
    console.log(`PASS ${width}px: entry states, keyboard/overlay clearance, in-card review without Apply, Back/refresh/save, pending/demo navigation, receipt history`)
    await page.close()
  }
} finally { await browser.close() }
