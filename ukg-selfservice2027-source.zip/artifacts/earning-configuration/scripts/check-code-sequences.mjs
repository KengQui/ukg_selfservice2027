// Real route, isolated storage and deterministic payment API; never edits a user's review.
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { mkdirSync } from 'node:fs'
const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium, expect: playwrightExpect } = require('@playwright/test')
const expect = playwrightExpect.configure({ timeout: 30_000 })
const browser = await chromium.launch({ executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH })
const app = new URL('/earning-configuration/', process.env.BASE_URL || 'http://localhost:80').href
const output = process.env.SEQUENCE_SCREENSHOTS
if (output) mkdirSync(output, { recursive: true })
try {
  for (const width of [1440, 390, 320]) {
    const context = await browser.newContext({ viewport: { width, height: 1000 } })
    const page = await context.newPage()
    const errors = []
    page.on('pageerror', error => errors.push(error.message))
    await page.route('**/earnings/payment-facts', route => route.fulfill({ json: { facts: [] } }))
    await page.goto(app)
    for (const id of ['MED ER', 'GTL-continuation']) {
      await page.evaluate(async id => {
        const base = '/earning-configuration/src/prototypes/earning-configuration/'
        const [{ createSession, reduceSession, reviewPages, parseSession }, { WORKING_COPY_KEY }] = await Promise.all([
          import(`${base}session.ts`), import(`${base}storage.ts`),
        ])
        const started = reduceSession(createSession(), { type: 'startReview' })
        const session = parseSession(JSON.stringify({ ...started,
          reviewCursor: reviewPages(started).findIndex(page => page.includes(id)),
        }))
        if (!session || session.step !== 'questions') throw new Error('Question fixture did not restore')
        sessionStorage.setItem(WORKING_COPY_KEY, JSON.stringify(session))
      }, id)
      await page.reload()
      const code = id === 'MED ER' ? id : 'GTL'
      const card = page.locator(`.ec-guide-item[aria-label^="${code},"] article.ec-qcard`)
      await expect(card).toBeVisible()
      const first = card.locator(':scope > .mc-card__response > .ec-qcard__answer [role="radio"]').nth(id === 'MED ER' ? 0 : 1)
      await first.focus(); await page.keyboard.press('Space')
      await expect(card.locator('[data-sequence-number="01"]')).toHaveCount(1)
      if (output) await card.screenshot({ path: `${output}/${id.replaceAll(' ', '-')}-${width}-open.jpg` })
      await card.locator('[data-sequence-number="01"] [role="radio"]').first().click()
      await expect(card.locator('[data-sequence-number="02"]')).toHaveCount(id === 'MED ER' ? 0 : 1)
      if (id === 'MED ER') {
        await expect(card.locator('.ec-payment-facts, .ec-conditional-summary')).toHaveCount(0)
        await expect(card).not.toContainText('Preliminary classification')
        const recap = card.getByLabel('MED ER answer summary')
        await expect(recap).toContainText("MED ER as your company's medical contribution")
        await expect(recap).toContainText('You indicated that it does not affect taxable pay.')
        const bounds = await recap.boundingBox()
        const sequenceBounds = await card.locator('.ec-qcard__sequence').boundingBox()
        assert.ok(bounds.y >= sequenceBounds.y + sequenceBounds.height, 'Recap follows the complete sequence')
        assert.ok(bounds.x >= 0 && bounds.x + bounds.width <= width, 'Recap fits the viewport')
        assert.equal(await recap.evaluate(el => el.scrollWidth > el.clientWidth + 1), false, 'Recap text wraps')
        if (output) await recap.screenshot({ path: `${output}/MED-ER-${width}-recap.jpg` })
      }
      await expect(card.locator('.ec-qcard__sequence')).toHaveCount(1)
      if (id === 'GTL-continuation') {
        await expect(card).not.toContainText('funded by your company')
        await expect(card.locator('.ec-payment-facts')).toHaveCount(0)
      }
      await expect(card.getByRole('heading', { name: 'Follow up questions', exact: true })).toHaveCount(1)
      await expect(card.locator('.ec-qcard__sequence-answer')).toHaveCount(1)
      const geometry = await card.evaluate(el => {
        const sequence = el.querySelector('.ec-qcard__sequence')
        const steps = [...el.querySelectorAll('[data-sequence-number]')]
        const bounds = sequence.getBoundingClientRect()
        return {
          numbers: steps.map(step => step.dataset.sequenceNumber),
          grouped: steps.every(step => step.closest('.ec-qcard__sequence') === sequence),
          borders: el.querySelectorAll('.ec-qcard__sequence .ec-qcard__sequence').length,
          insets: steps.map(step => step.getBoundingClientRect().left),
          sequenceLeft: bounds.left, sequenceRight: bounds.right,
          width: document.documentElement.scrollWidth, viewport: innerWidth,
          connected: getComputedStyle(steps[0], '::after').borderLeftWidth,
          overflow: [...el.querySelectorAll('.sc__text, textarea')].some(node => node.scrollWidth > node.clientWidth + 1),
        }
      })
      assert.deepEqual(geometry.numbers, id === 'MED ER' ? ['01'] : ['01', '02'])
      assert.ok(geometry.grouped && !geometry.borders)
      if (id !== 'MED ER') {
        assert.ok(Math.abs(geometry.insets[0] - geometry.insets[1]) <= 1, 'Steps use the same rail inset')
        assert.equal(geometry.connected, '1px')
      }
      assert.ok(geometry.sequenceLeft >= 0 && geometry.sequenceRight <= width)
      assert.ok(geometry.width <= geometry.viewport && !geometry.overflow)
      if (output) await card.screenshot({ path: `${output}/${id.replaceAll(' ', '-')}-${width}-answered.jpg` })
      await page.reload()
      await expect(card.locator('[data-sequence-number="02"]')).toHaveCount(id === 'MED ER' ? 0 : 1)
      await expect(card.locator('.ec-qcard__sequence')).toHaveCount(1)
      const change = card.getByRole('button', { name: 'Change answer to question 1', exact: true })
      await change.focus(); await page.keyboard.press('Enter')
      await expect(card.locator('[data-sequence-number="01"] [role="radio"]')).not.toHaveCount(0)
      const clear = card.getByRole('button', { name: 'Clear all answers', exact: true })
      await clear.focus(); await page.keyboard.press('Enter')
      await expect(card.locator('.ec-qcard__sequence')).toHaveCount(0)
      await expect(card.locator('h3.mc-card__question')).toBeFocused()
    }
    assert.deepEqual(errors, [], `Browser errors at ${width}px`)
    console.log(`MED ER and GTL: one sequence, consecutive steps, rail, bounds, keyboard and reload at ${width}px`)
    await context.close()
  }
} finally {
  await browser.close()
}
