// Focused current-pair rendering/keyboard check; no AI responses or page text are replaced.
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { existsSync, mkdirSync } from 'node:fs'
const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium, expect } = require('@playwright/test')
const browser = await chromium.launch({
  executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH ||
    (existsSync('/repl/tools/bin/chromium') ? '/repl/tools/bin/chromium' : undefined),
})
const output = process.env.OVERTIME_SCREENSHOTS
if (output) mkdirSync(output, { recursive: true })
try {
  for (const width of [1280, 390, 320]) {
    const page = await browser.newPage({ viewport: { width, height: 900 } })
    const errors = []
    page.on('pageerror', error => errors.push(error.message))
    const assertReachable = async () => {
      await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))))
      const target = await page.evaluate(() => {
        const active = document.activeElement
        const bounds = active.getBoundingClientRect()
        const hit = document.elementFromPoint(bounds.left + bounds.width / 2, bounds.top + bounds.height / 2)
        return { text: active.textContent?.slice(0, 80), top: bounds.top, bottom: bounds.bottom,
          hit: hit?.className, reachable: bounds.top >= 0 && bounds.bottom <= innerHeight && !!hit && (active.contains(hit) || hit.contains(active)) }
      })
      assert.ok(target.reachable, `Keyboard focus is visible and unobscured at ${width}px: ${JSON.stringify(target)}`)
    }
    await page.goto(new URL('/earning-configuration/', process.env.BASE_URL || 'http://localhost:80').href)
    const seed = async (mfg = 'full', eng = 'full') => {
      await page.evaluate(async ([mfg, eng]) => {
        const base = '/earning-configuration/src/prototypes/earning-configuration/'
        const [{ overtimeCombinationSession }, { browserStores, writeWorkingCopy }] = await Promise.all([
          import(`${base}overtimeCombination.testing.ts`), import(`${base}storage.ts`),
        ])
        writeWorkingCopy(browserStores(), overtimeCombinationSession(mfg, eng))
      }, [mfg, eng])
      await page.reload()
    }
    await seed()
    const card = page.locator('article.ec-qcard').filter({ has: page.getByRole('heading', {
      name: 'Do you want to combine Overtime MFG and Overtime ENG into one overtime code?', exact: true,
    }) })
    const combine = card.getByRole('radio', { name: /^Combine into a new earnings code, OT/ })
    const keep = card.getByRole('radio', { name: /^Keep Overtime MFG and Overtime ENG/ })
    const other = card.getByRole('radio', { name: /^Something else/ })
    await expect(card).toBeVisible()
    await expect(card.getByRole('radio')).toHaveCount(3)
    await expect(card.locator('[role="radio"][aria-checked="true"]')).toHaveCount(0)
    await expect(page.locator('.ec-ot-example')).toHaveCount(1)
    await expect(card.locator('figcaption')).toHaveText('Both employees use the same OT earnings code')
    await expect(card.locator('.ec-ot-example__qualification')).toContainText('configured cost center and labor distribution settings')
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false, 'No horizontal overflow')
    const title = combine.locator('.sc__title')
    await expect(title).toHaveText('Combine into a new earnings code, OT')
    assert.ok(await title.evaluate(node =>
      node.scrollWidth <= node.clientWidth && node.scrollHeight <= node.clientHeight),
    `Complete combination label fits at ${width}px`)
    const [mfg, eng] = await card.locator('.ec-ot-example__department').evaluateAll(nodes =>
      nodes.map(node => { const { x, y } = node.getBoundingClientRect(); return { x, y } }))
    if (width > 640) assert.ok(eng.x > mfg.x && eng.y === mfg.y, 'Desktop departments are side by side')
    else assert.ok(eng.y > mfg.y && eng.x === mfg.x, 'Narrow departments stack in reading order')
    if (output) {
      await card.screenshot({ path: `${output}/card-${width}.png` })
      await card.locator('.ec-ot-example').screenshot({ path: `${output}/example-${width}.png` })
    }
    // Roving radio controls: keyboard activation, then movement through the three real answers.
    await combine.focus()
    await page.keyboard.press('Space')
    await expect(combine).toHaveAttribute('aria-checked', 'true')
    await assertReachable()
    await page.keyboard.press('ArrowRight')
    await expect(keep).toBeFocused()
    await expect(keep).toHaveAttribute('aria-checked', 'true')
    await assertReachable()
    await page.keyboard.press('ArrowRight')
    await expect(other).toBeFocused()
    await expect(other).toHaveAttribute('aria-checked', 'true')
    await assertReachable()
    const box = card.getByRole('textbox', { name: 'Description', exact: true })
    await page.keyboard.press('Tab')
    await expect(box).toBeFocused()
    await assertReachable()
    await box.fill('Track project costs separately.')
    await page.keyboard.press('Tab')
    await expect(card.getByRole('button', { name: 'Done', exact: true })).toBeFocused()
    await assertReachable()
    // Stop before Done: the mounted unit test covers the actual review boundary without making paid live calls.
    await page.reload()
    await expect(other).toHaveAttribute('aria-checked', 'true')
    await expect(box).toHaveValue('Track project costs separately.')
    await keep.focus()
    await page.keyboard.press('Space')
    await expect(box).toHaveCount(0)
    await expect(card.locator('.ec-defer')).toHaveCount(0)
    for (const pair of [['full', 'double'], ['full', 'ask-customer'], ['ask-customer', 'full']]) {
      await seed(...pair)
      await expect(card).toHaveCount(0)
      await expect(page.locator('.ec-ot-example')).toHaveCount(0)
      await expect(page.getByRole('radio', { name: /^Keep Overtime MFG and Overtime ENG/ })).toHaveCount(0)
    }
    assert.deepEqual(errors, [], 'No browser errors')
    console.log(`PASS ${width}px: current-pair example, no overflow, three distinct answers, keyboard operation, draft refresh and ineligible questions omitted`)
    await page.close()
  }
} finally {
  await browser.close()
}
