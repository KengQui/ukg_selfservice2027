// Focused browser check against the development preview; uses fictional session data only.
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium, expect } = require('@playwright/test')
const browser = await chromium.launch({ executablePath: '/repl/tools/bin/chromium' })
const labels = [
  "We include tips in employees' paychecks.",
  'Employees receive their tips separately (such as cash), and we only report them in payroll.',
  'We do both — some tips are paid in paychecks, and others are already paid.',
  "I'm not sure how the tips are handled",
  'Something else',
]
const errors = []
try {
  const page = await browser.newPage()
  page.on('pageerror', error => errors.push(error.message))
  await page.goto(new URL('/earning-configuration/', process.env.BASE_URL || 'http://localhost:80').href)
  await page.evaluate(async () => {
    const { createSession, reduceSession, reviewPages } = await import('/earning-configuration/src/prototypes/earning-configuration/session.ts')
    const { WORKING_COPY_KEY, SAVED_COPY_KEY } = await import('/earning-configuration/src/prototypes/earning-configuration/storage.ts')
    const session = reduceSession(createSession(), { type: 'startReview' })
    session.reviewCursor = reviewPages(session).findIndex(ids => ids.includes('TIPS'))
    localStorage.removeItem(SAVED_COPY_KEY)
    sessionStorage.setItem(WORKING_COPY_KEY, JSON.stringify(session))
  })
  await page.reload()
  const card = page.locator('.ec-guide-item[aria-label^="TIPS,"] .ec-qcard')
  await expect(card).toBeVisible({ timeout: 30000 })
  const opening = card.locator(':scope > .mc-card__response > .ec-qcard__answer [role="radio"]')
  assert.deepEqual((await opening.allTextContents()).map(text => text.trim()), labels)
  for (const radio of await opening.all()) await expect(radio).toHaveAttribute('aria-checked', 'false')
  assert.equal(await card.getByText('Example:', { exact: false }).count(), 0)
  if (process.env.TIPS_SCREENSHOT) await card.screenshot({ path: process.env.TIPS_SCREENSHOT })
  await opening.nth(2).click()
  await expect(card.getByText('Add a code for tips people have already received?', { exact: true })).toBeVisible()
  await expect(card.getByRole('radio', { name: 'Add TIPS RPT', exact: false })).toHaveAttribute('aria-checked', 'false')
  assert.equal(await card.getByText('Which payment methods do you use for these tips?', { exact: true }).count(), 0)
  await opening.nth(3).click()
  await expect(card.getByText('Add a code for tips people have already received?', { exact: true })).toHaveCount(0)
  await page.reload()
  await expect(opening.nth(3)).toHaveAttribute('aria-checked', 'true', { timeout: 30000 })
  assert.equal(await card.locator('.ec-defer').count(), 1)
  await opening.nth(4).click()
  await expect(card.locator('textarea')).toBeVisible()
  await expect(card.getByRole('button', { name: 'Done', exact: true })).toBeDisabled()
  assert.deepEqual(errors, [])
  console.log('TIPS browser check passed: exact choices, no preselection, mixed confirmation, uncertainty reload, Something else and Defer.')
} finally {
  await browser.close()
}
