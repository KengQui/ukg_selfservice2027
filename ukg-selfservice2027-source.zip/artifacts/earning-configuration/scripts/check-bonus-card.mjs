// Verify the continuous overtime list, independent decisions and its embedded bonus question.
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { existsSync, mkdirSync } from 'node:fs'
const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium, expect } = require('@playwright/test')
const browser = await chromium.launch({
  executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH ||
    (existsSync('/repl/tools/bin/chromium') ? '/repl/tools/bin/chromium' : undefined),
})
const output = process.env.OVERTIME_SCREENSHOTS
if (output) mkdirSync(output, { recursive: true })
try {
  for (const width of [1280, 390, 320]) {
    const page = await browser.newPage({ viewport: { width, height: 900 } })
    const errors = []
    page.on('pageerror', error => errors.push(error.message))
    // Presentation check only: never make paid AI calls for scripted test evidence.
    await page.route('**/api/earnings/payment-facts', route => route.fulfill({
      status: 200, contentType: 'application/json', body: JSON.stringify({ facts: [] }),
    }))
    await page.goto(new URL('/earning-configuration/', process.env.BASE_URL || 'http://localhost:80').href)
    await page.evaluate(async () => {
      const base = '/earning-configuration/src/prototypes/earning-configuration/'
      const [{ actionableOvertimeSession }, { reduceSession, parseSession }, { browserStores, writeWorkingCopy }, { reviewedOvertimeFixture }] = await Promise.all([
        import(`${base}overtimeActionable.testing.ts`), import(`${base}session.ts`), import(`${base}storage.ts`),
        import(`${base}overtimeDiscovery.testing.ts`),
      ])
      let session = actionableOvertimeSession('team')
      session.optimization.answers['split-bonus'] = 'keep'
      // A fictional typed description uses the real missing-description path and normal storage.
      session.answers.REG = { description: 'Regular wages for customer support and administrative work across multiple locations, including SuperLongUnbrokenDescriptionToExerciseWrappingWithoutHorizontalOverflow' }
      session = reviewedOvertimeFixture(session)
      for (const [code, choice] of [['REG', 'include'], ['SICK', 'exclude'], ['VAC', 'unsure'], ['Special Pay', 'unanswered']]) {
        session = reduceSession(session, { type: 'setOvertimeReviewChoice', code, choice })
      }
      if (!parseSession(JSON.stringify(session)) || !writeWorkingCopy(browserStores(), session)) throw new Error('Overtime fixture must restore through normal storage')
    })
    await page.reload()
    const heading = page.getByRole('heading', { name: 'Choose earning codes for weighted average overtime', exact: true })
    await expect(heading).toBeVisible()
    const question = page.locator('[data-mixed-code="BONUS"]')
    const card = code => page.locator(`.ec-dl-row[data-code="${code}"]`)
    const list = page.getByRole('list', { name: /^Earning Codes/ })
    const codes = () => list.locator(':scope > li').evaluateAll(rows => rows.map(row => row.dataset.code))
    const choices = () => page.evaluate(async () => {
      const { browserStores, loadSession } = await import('/earning-configuration/src/prototypes/earning-configuration/storage.ts')
      return loadSession(browserStores()).overtime.reviewChoices
    })
    async function assertInclusionLabels() {
      const controls = await list.locator('.ec-dl-yes-toggle').evaluateAll(labels => labels.map(label => {
        const input = label.querySelector('input')
        const text = label.querySelector('span')
        return {
          code: label.closest('.ec-dl-row').dataset.code,
          checked: input.checked, disabled: input.disabled, name: input.getAttribute('aria-label'),
          text: text.textContent, color: getComputedStyle(text).color,
          opacity: getComputedStyle(label).opacity, inputOpacity: getComputedStyle(input).opacity,
          cursor: getComputedStyle(label).cursor, inputCursor: getComputedStyle(input).cursor,
          textFits: text.scrollWidth <= text.clientWidth,
        }
      }))
      assert.ok(controls.length > 0)
      for (const control of controls) {
        assert.equal(control.text, control.checked ? 'Included' : 'Include', `${control.code}: label matches checked state`)
        assert.equal(control.color, control.checked ? 'rgb(0, 0, 0)' : 'rgb(97, 97, 97)', `${control.code}: computed label color`)
        assert.equal(control.name, `Include ${control.code} in weighted average overtime`)
        assert.equal(control.opacity, '1', 'Label stays readable, including disabled controls')
        assert.equal(control.inputOpacity, control.disabled ? '0.5' : '1')
        assert.equal(control.cursor, control.disabled ? 'not-allowed' : 'pointer')
        assert.equal(control.inputCursor, control.disabled ? 'not-allowed' : 'pointer')
        assert.ok(control.textFits, `${control.code}: label fits its reserved width`)
      }
    }
    const positions = () => list.locator(':scope > li').evaluateAll(rows => rows.map(row => {
      const rect = element => {
        const bounds = element.getBoundingClientRect()
        return [bounds.left, bounds.top + scrollY, bounds.width, bounds.height]
      }
      const input = row.querySelector('[role="switch"]')
      return { code: row.dataset.code, row: rect(row), switch: input ? rect(input) : null }
    }))
    const initialChoices = await choices()
    for (const [code, choice] of [['REG', 'include'], ['SICK', 'exclude'], ['VAC', 'unsure'], ['Special Pay', 'unanswered']]) {
      assert.equal(initialChoices[code]?.choice, choice, `${code}: fixture decision survives restoration`)
      await expect(card(code).getByRole('switch')).toBeChecked({ checked: choice === 'include' })
    }
    async function assertSurface() {
      await assertInclusionLabels()
      await expect(list).toHaveCount(1)
      await expect(page.locator('.ec-dl-choice')).toHaveCount(0)
      const order = await codes()
      assert.deepEqual(order, [...order].sort((a, b) => a.localeCompare(b, 'en-US', { sensitivity: 'base', numeric: true })))
      await expect(page.getByRole('heading', { name: `Earning Codes (${order.length})`, exact: true })).toBeVisible()
      const geometry = await list.evaluate(element => {
        const style = getComputedStyle(element)
        const bounds = element.getBoundingClientRect()
        const rows = [...element.children]
        return {
          boundary: style.borderTopWidth === '1px' && style.borderBottomWidth === '1px' && style.borderLeftWidth === '1px' && style.borderRightWidth === '1px',
          gap: parseFloat(style.rowGap) || 0,
          fits: bounds.left >= 0 && bounds.right <= innerWidth && document.documentElement.scrollWidth <= innerWidth,
          rows: rows.map((row, index) => {
            const css = getComputedStyle(row)
            const rowTop = row.querySelector('.ec-dl-row-top')
            const toggle = rowTop.querySelector('.ec-dl-yes-toggle')
            const identity = rowTop.querySelector('.ec-dl-identity').getBoundingClientRect()
            const toggleBounds = toggle?.getBoundingClientRect()
            return {
              code: row.dataset.code, divider: css.borderTopWidth, bottom: css.borderBottomWidth,
              left: css.borderLeftWidth, right: css.borderRightWidth, radius: css.borderTopLeftRadius,
              contiguous: index === 0 || Math.abs(row.getBoundingClientRect().top - rows[index - 1].getBoundingClientRect().bottom) < 1,
              columns: getComputedStyle(rowTop).gridTemplateColumns.split(' ').length,
              controlFits: !toggleBounds || identity.right <= toggleBounds.left && toggleBounds.right <= bounds.right
                && Math.abs(toggleBounds.top - identity.top + 10) < 1,
              toggleRight: toggleBounds?.right,
              gutter: css.paddingLeft,
            }
          }),
        }
      })
      assert.ok(geometry.boundary && geometry.fits && geometry.gap === 0, JSON.stringify(geometry))
      let alignedRight
      for (const [index, row] of geometry.rows.entries()) {
        assert.equal(row.divider, index === 0 ? '0px' : '1px', `${row.code}: adjacent dividers only`)
        assert.equal(row.bottom, '0px')
        assert.equal(row.left, '0px')
        assert.equal(row.right, '0px')
        assert.equal(row.radius, '0px')
        assert.equal(row.columns, 2, 'No reserved status column')
        assert.equal(row.gutter, width <= 767 ? '16px' : '40px')
        assert.ok(row.contiguous && row.controlFits, JSON.stringify(row))
        if (row.toggleRight !== undefined) {
          alignedRight ??= row.toggleRight
          assert.ok(Math.abs(row.toggleRight - alignedRight) < 1, 'Include controls align')
        }
      }
      const text = await list.locator('.ec-dl-row-top').allTextContents()
      assert.ok(text.every(value => !/Included in the regular rate\.|Not included in the regular rate\.|Your choice|Left open rather than guessing/.test(value)))
      assert.ok(await card('REG').locator('.ec-dl-identity p').evaluate(element => {
        const bounds = element.getBoundingClientRect()
        return element.textContent.includes('SuperLongUnbrokenDescriptionToExerciseWrappingWithoutHorizontalOverflow')
          && bounds.height > parseFloat(getComputedStyle(element).lineHeight) && element.scrollWidth <= element.clientWidth
      }), 'Long description wraps without overflow')
    }
    await assertSurface()
    const originalOrder = await codes()
    // Retain references in the page to detect remounts, not only a coincidentally equal order.
    await list.evaluate(element => { window.ledgerTestRows = [...element.children] })
    const toggle = card('Special Pay').getByRole('switch')
    await toggle.scrollIntoViewIfNeeded()
    await toggle.focus()
    const originalPositions = await positions()
    for (const checked of [true, false]) {
      await page.keyboard.press('Space')
      await expect(toggle).toBeFocused()
      await expect(toggle).toBeChecked({ checked })
      await assertInclusionLabels()
      assert.deepEqual(await positions(), originalPositions, 'Changing the label moves neither switches nor rows')
      await expect(page.locator('.ec-dl-feedback')).toHaveText(
        `Special Pay: ${checked ? 'Included' : 'Not included'}. You can change your choice at any time.`)
      const current = await choices()
      assert.equal(current['Special Pay'].choice, checked ? 'include' : 'exclude')
      for (const code of ['REG', 'SICK', 'VAC']) assert.deepEqual(current[code], initialChoices[code])
      assert.deepEqual(await codes(), originalOrder)
      assert.ok(await list.evaluate(element => [...element.children].every((row, index) => row === window.ledgerTestRows[index])))
      assert.ok(await toggle.evaluate(element => {
        const style = getComputedStyle(element)
        const bounds = element.getBoundingClientRect()
        const row = element.closest('.ec-dl-row').getBoundingClientRect()
        const hit = document.elementFromPoint(bounds.left + bounds.width / 2, bounds.top + bounds.height / 2)
        const clearance = parseFloat(style.outlineWidth) + parseFloat(style.outlineOffset)
        return element.matches(':focus-visible') && parseFloat(style.outlineWidth) >= 2
          && bounds.left - clearance >= row.left && bounds.right + clearance <= row.right
          && bounds.top - clearance >= row.top && bounds.bottom + clearance <= row.bottom
          && bounds.top >= clearance && bounds.bottom + clearance <= innerHeight && hit === element
      }), 'Keyboard focus is visible, unobscured and contained by row padding')
    }
    await page.keyboard.press('Tab')
    const nextSwitch = await card('Special Pay').evaluate(row => {
      let next = row.nextElementSibling
      while (next && !next.querySelector('input[role="switch"]:not(:disabled)')) next = next.nextElementSibling
      return next?.querySelector('input[role="switch"]')?.getAttribute('aria-label')
    })
    assert.equal(await page.locator(':focus').getAttribute('aria-label'), nextSwitch, 'Tab follows alphabetical row order')
    await expect(question).toHaveCount(1)
    await expect(card('BONUS').locator('[data-mixed-code]')).toHaveCount(1)
    await expect(page.locator('#ec-sort-mixed')).toHaveCount(0)
    await expect(card('BONUS').getByRole('switch')).toBeDisabled()
    const beforeDetails = await choices()
    const details = card('BONUS').getByRole('button', { name: 'Review details for BONUS' })
    await details.click()
    const dialog = page.getByRole('dialog', { name: 'Why BONUS needs review' })
    await expect(dialog).toBeVisible()
    await expect(dialog).toContainText('discretionary and non-discretionary')
    await dialog.getByRole('button', { name: 'Close', exact: true }).click()
    await expect(dialog).toHaveCount(0)
    assert.deepEqual(await choices(), beforeDetails)
    const accept = question.getByRole('radio').first()
    await accept.focus()
    await accept.press('Space')
    await expect(card('BONUS-ND').locator('[data-mixed-code]')).toHaveCount(1)
    await expect(question).toBeFocused()
    // Split permission is not a treatment decision for either replacement.
    await expect(card('BONUS-ND')).toHaveAttribute('data-treatment', 'undecided')
    await expect(card('BONUS-D')).toHaveAttribute('data-treatment', 'undecided')
    await expect(question).toHaveCount(1)
    await question.getByRole('button', { name: 'Clear answer', exact: true }).focus()
    await page.keyboard.press('Enter')
    await expect(card('BONUS').locator('[data-mixed-code]')).toHaveCount(1)
    await expect(question).toBeFocused()
    await expect(card('BONUS-ND')).toHaveCount(0)
    await question.getByRole('radio').first().click()
    await page.reload()
    await expect(card('BONUS-ND').locator('[data-mixed-code]')).toHaveCount(1)
    await assertInclusionLabels()
    await expect(question).toHaveCount(1)
    const beforeNavigation = await choices()
    await page.locator('.ec-submit-bar').getByRole('button', { name: 'Back', exact: true }).click()
    await expect(page.locator('.ec-overtime-assessment')).toBeVisible()
    await page.locator('.ec-submit-bar').getByRole('button', { name: 'Next', exact: true }).click()
    await expect(heading).toBeVisible()
    await page.locator('.ec-submit-bar').getByRole('button', { name: 'Continue', exact: true }).click()
    await expect(page.getByRole('heading', { name: 'Earning setup summary', exact: true })).toBeVisible()
    await page.locator('.ec-actions').getByRole('button', { name: 'Back', exact: true }).click()
    await expect(heading).toBeVisible()
    assert.deepEqual(await choices(), beforeNavigation)
    assert.ok(await page.evaluate(async () => {
      const { browserStores, loadSession, saveSession, discardWorkingCopy } = await import('/earning-configuration/src/prototypes/earning-configuration/storage.ts')
      const stores = browserStores()
      return saveSession(stores, loadSession(stores)) && discardWorkingCopy(stores)
    }))
    await page.reload()
    await expect(heading).toBeVisible()
    assert.deepEqual(await choices(), beforeNavigation)
    await assertSurface()
    await question.scrollIntoViewIfNeeded()
    assert.ok(await question.evaluate(element => {
      const bounds = element.getBoundingClientRect()
      return bounds.left >= 0 && bounds.right <= innerWidth &&
        document.documentElement.scrollWidth <= innerWidth
    }), `Bonus question fits at ${width}px`)
    if (output) {
      await heading.scrollIntoViewIfNeeded()
      await page.screenshot({ path: `${output}/ledger-${width}.png` })
    }
    if (output) await card('REG').screenshot({ path: `${output}/long-description-${width}.png` })
    assert.deepEqual(errors, [])
    console.log(`PASS ${width}px: unified surface/dividers, wrapping, independent decisions, focus/order, bonus details/split/clear, reload, saved reentry, Back and Continue`)
    console.log(`PASS ${width}px: Include/Included text and computed gray/black colors, stationary switches/rows, usable off switches and readable disabled labels`)
    await page.close()
  }
} finally {
  await browser.close()
}
