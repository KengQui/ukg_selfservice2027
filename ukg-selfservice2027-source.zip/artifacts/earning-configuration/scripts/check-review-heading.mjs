// Focused presentation check; no AI requests or payroll decisions.
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium, expect } = require('@playwright/test')
const browser = await chromium.launch({ executablePath: '/repl/tools/bin/chromium' })
try {
  const page = await browser.newPage()
  await page.goto(process.env.EARNING_PREVIEW_URL || 'http://localhost:80/earning-configuration/')
  await page.evaluate(async () => {
    const base = new URL('./src/prototypes/earning-configuration/', location.href).href
    const { discussionEntryFixture } = await import(`${base}discussionEntry.testing.ts`)
    const { WORKING_COPY_KEY } = await import(`${base}storage.ts`)
    sessionStorage.setItem(WORKING_COPY_KEY, JSON.stringify(discussionEntryFixture()))
  })
  await page.reload()
  for (const width of [1280, 390, 320]) {
    await page.setViewportSize({ width, height: 844 })
    const heading = page.getByRole('heading', { name: 'Let’s fill in the gaps in your pay code setup', exact: true })
    const help = page.getByRole('button', { name: 'About the AI summary', exact: true })
    await expect(heading).toBeVisible()
    await expect(page.locator('.ec-intro')).toHaveText('Your answers help us understand how you use each code and identify the right setup. Answer what you can now, and return to anything unfinished later.')
    await help.scrollIntoViewIfNeeded()
    const h = await heading.boundingBox()
    const b = await help.boundingBox()
    assert(h && b && h.x + h.width <= b.x, 'Heading must not overlap AI summary control')
    assert(await help.evaluate(el => {
      const r = el.getBoundingClientRect()
      const hit = document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2)
      return el.contains(hit) && r.right <= innerWidth
    }), 'AI summary control remains clickable')
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'No horizontal overflow')
    const before = await page.evaluate(() => JSON.stringify({ ...sessionStorage }))
    await help.click()
    await expect(page.getByRole('dialog')).toBeVisible()
    await page.keyboard.press('Escape')
    await expect(page.getByRole('dialog')).toHaveCount(0)
    assert.equal(await page.evaluate(() => JSON.stringify({ ...sessionStorage })), before)
    console.log(`PASS ${width}px: approved copy, heading clearance, AI summary opens without changing answers`)
  }
} finally {
  await browser.close()
}
