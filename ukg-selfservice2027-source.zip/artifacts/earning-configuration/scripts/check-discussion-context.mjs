// Check the actual owning route and session provider, not an isolated component mount.
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { existsSync, mkdirSync } from 'node:fs'

const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium, expect } = require('@playwright/test')
const browser = await chromium.launch({
  executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH
    || (existsSync('/repl/tools/bin/chromium') ? '/repl/tools/bin/chromium' : undefined),
})
const url = new URL('/earning-configuration/', process.env.BASE_URL || 'http://localhost:80').href
try {
  for (const width of [1280, 390]) {
    const page = await browser.newPage({ viewport: { width, height: 1000 } })
    const errors = []
    const aiRequests = []
    page.on('pageerror', error => errors.push(error.message))
    page.on('request', request => {
      if (/\/api\/earnings\//.test(request.url())) aiRequests.push(request.url())
    })
    // Save exits to the hub. Its availability is not part of this artifact's check.
    await page.route('**/*', route => {
      if (route.request().isNavigationRequest() && new URL(route.request().url()).pathname === '/') {
        return route.fulfill({ status: 200, contentType: 'text/html', body: '<title>Saved review exit</title>' })
      }
      return route.continue()
    })
    await page.goto(url)
    await page.evaluate(async () => {
      const base = '/earning-configuration/src/prototypes/earning-configuration/'
      const [{ createSession, parseSession, namingBasis }, { ASK_CUSTOMER, findItem },
        { WORKING_COPY_KEY }, { SAMPLE_REGISTER_FILES }, { callEvidence }, { deferralBasis },
        { discussionKey, discussionBasis }] = await Promise.all([
        'session.ts', 'sampleRegister.ts', 'storage.ts', 'sampleDocument.ts', 'cheatSheetAnswers.ts',
        'explicitDeferral.ts', 'discussionAnswers.ts',
      ].map(file => import(base + file)))
      const state = parseSession(JSON.stringify({
        ...createSession(1), step: 'review', files: SAMPLE_REGISTER_FILES,
        rounds: [{ number: 1, submitted: true, itemIds: ['OTPREM', 'ADJ2', 'SPPAY', 'MISC7'],
          results: { resolved: [], deferred: ['OTPREM', 'ADJ2', 'SPPAY', 'MISC7'], findings: [] } }],
        answers: {
          OTPREM: { choice: ASK_CUSTOMER },
          ADJ2: { description: 'Corrections for earlier work', descriptionSubmitted: true,
            followUps: { basis: 'hourly', frequency: ASK_CUSTOMER } },
          SPPAY: { choice: ASK_CUSTOMER },
          MISC7: { description: 'A saved payment policy', descriptionSubmitted: true },
        },
        resolutions: {
          OTPREM: { status: 'customer', round: 1 },
          ADJ2: { status: 'customer', round: 1 },
          SPPAY: { status: 'customer', round: 1 },
          MISC7: { status: 'customer', round: 1 },
        },
        customerQuestions: ['OTPREM', 'ADJ2', 'SPPAY'].map(itemId => ({
          itemId, code: findItem(itemId).code, type: findItem(itemId).type, round: 1,
          question: findItem(itemId).customerQuestion,
        })),
        callAnswers: { SPPAY: 'Keep the earlier discussion note.' },
        sent: { at: 1, to: 'payroll@example.test', questionIds: ['classification:SPPAY'],
          questions: [{ id: 'classification:SPPAY', topic: 'allowances', codes: ['SPPAY'],
            question: 'Earlier exact Special Pay wording?', status: 'open' }] },
      }))
      if (!state) throw new Error('Review fixture did not restore')
      for (const itemId of ['OTPREM', 'ADJ2', 'SPPAY']) {
        const selected = callEvidence(findItem(itemId), state.answers[itemId]).questions.find(entry => entry.deferred)
        if (!selected) throw new Error(`No deferred question for ${itemId}`)
        state.answers[itemId].explicitDeferral = {
          question: selected.question, choices: selected.choices, basis: deferralBasis(state.answers[itemId]),
        }
      }
      state.answers.MISC7.check = { basis: namingBasis(state.answers.MISC7), at: 1,
        result: { kind: 'noMatch', reason: 'Keep this stored AI result.' } }
      const oldQuestion = 'Earlier exact Special Pay wording?'
      state.discussionAnswers = { SPPAY: {
        [discussionKey(oldQuestion, discussionBasis(state, 'SPPAY'))]: {
          question: oldQuestion, kind: 'text', text: 'Keep the historical Special Pay answer.',
        },
      } }
      sessionStorage.setItem(WORKING_COPY_KEY, JSON.stringify(state))
    })
    await page.reload()
    await expect(page.getByRole('heading', { name: 'Let’s fill in the gaps in your pay code setup', exact: true })).toBeVisible()
    const stored = () => page.evaluate(async () => {
      const { WORKING_COPY_KEY } = await import('/earning-configuration/src/prototypes/earning-configuration/storage.ts')
      const state = JSON.parse(sessionStorage.getItem(WORKING_COPY_KEY))
      return {
        answers: state.answers, resolutions: state.resolutions, customerQuestions: state.customerQuestions,
        callAnswers: state.callAnswers, sent: state.sent, rounds: state.rounds, files: state.files,
      }
    })
    const before = await stored()
    const assertPresentation = async () => {
      await expect(page.locator('.ec-cheat__row')).toHaveCount(3)
      await expect(page.getByTestId('row-cheat-MISC7')).toHaveCount(0)
      await expect(page.locator('.ec-context, .ec-context__facts, .ec-context__decision')).toHaveCount(0)
      await expect(page.locator('.ec-page')).not.toContainText('What’s known')
      await expect(page.locator('.ec-page')).not.toContainText('What this means for setup')
      await expect(page.locator('.ec-page')).not.toContainText('Corrections for earlier work')
      await expect(page.locator('.ec-page')).not.toContainText('A saved payment policy')
      await expect(page.locator('.ec-page')).not.toContainText('Keep this stored AI result.')
      for (const itemId of ['OTPREM', 'ADJ2', 'SPPAY']) {
        const row = page.getByTestId(`row-cheat-${itemId}`)
        await expect(row.locator('.ec-discussion__response')).toHaveCount(1)
        await expect(row.locator('.ec-cheat__why').first()).toBeVisible()
        await expect(row.locator('.ec-register-details')).toBeVisible()
        assert.equal(await row.evaluate(el => el.scrollWidth <= el.clientWidth), true, `Card overflow at ${width}px`)
      }
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true)
    }
    await assertPresentation()
    const special = page.getByTestId('row-cheat-SPPAY')
    await expect(special.locator('.ec-discussion__response textarea')).toBeVisible()
    await special.locator('.ec-discussion__response textarea').fill('We pay a stipend for using a second language.')
    const overtime = page.getByTestId('row-cheat-OTPREM')
    await overtime.locator('.ec-discussion__options label').first().click()
    const why = special.locator('.ec-cheat__support .ec-cheat__why')
    await why.locator('summary').focus()
    await page.keyboard.press('Enter')
    await expect(why).toHaveAttribute('open', '')
    assert.equal(await special.locator('.ec-register-details[open]').count(), 0)
    await special.locator('.ec-discussion__history summary').click()
    await expect(special.locator('.ec-discussion__history')).toContainText('Keep the historical Special Pay answer.')
    assert.deepEqual(await stored(), before)
    await page.getByRole('button', { name: 'Save and finish later', exact: true }).click()
    await page.goto(url)
    // Clear only this isolated test browser's working copy to verify the explicitly saved copy.
    await page.evaluate(async () => {
      const { WORKING_COPY_KEY, SAVED_COPY_KEY } = await import('/earning-configuration/src/prototypes/earning-configuration/storage.ts')
      if (!localStorage.getItem(SAVED_COPY_KEY)) throw new Error('The review was not saved')
      sessionStorage.removeItem(WORKING_COPY_KEY)
    })
    await page.reload()
    await expect(page.getByRole('heading', { name: 'Let’s fill in the gaps in your pay code setup', exact: true })).toBeVisible()
    await assertPresentation()
    await expect(special.locator('.ec-discussion__response textarea')).toHaveValue('We pay a stipend for using a second language.')
    await expect(overtime.locator('input:checked')).toHaveCount(1)
    assert.deepEqual(await stored(), before)
    assert.deepEqual(aiRequests, [])
    assert.deepEqual(errors, [])
    if (process.env.DISCUSSION_CONTEXT_SCREENSHOTS) {
      mkdirSync(process.env.DISCUSSION_CONTEXT_SCREENSHOTS, { recursive: true })
      await page.screenshot({ path: `${process.env.DISCUSSION_CONTEXT_SCREENSHOTS}/review-restored-${width}.jpg`, fullPage: true })
    }
    console.log(`Actual review route: ${width}px, no removed sections, text/choices, history, disclosures, Save/reopen, unchanged evidence and no AI requests passed`)
    await page.close()
  }
} finally {
  await browser.close()
}
