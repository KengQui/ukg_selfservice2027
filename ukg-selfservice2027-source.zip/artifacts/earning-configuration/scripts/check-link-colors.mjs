// Computed-color regression using the live app and its real shared components.
// BASE_URL=https://$REPLIT_DEV_DOMAIN pnpm --filter @workspace/earning-configuration test:link-colors
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { existsSync } from 'node:fs'
const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium, expect } = require('@playwright/test')
const browser = await chromium.launch({
  executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH ||
    (existsSync('/repl/tools/bin/chromium') ? '/repl/tools/bin/chromium' : undefined),
})
const baseURL = process.env.BASE_URL || 'http://localhost:80'
const green = 'rgb(1, 81, 81)'
const hover = 'rgb(10, 67, 63)'
const active = 'rgb(19, 53, 44)'
async function states(page, locator) {
  await page.mouse.move(0, 0)
  await expect(locator).toHaveCSS('color', green)
  await locator.hover()
  await expect(locator).toHaveCSS('color', hover)
  await page.mouse.down()
  await expect(locator).toHaveCSS('color', active)
  await page.mouse.move(0, 0)
  await page.mouse.up()
}
try {
  const page = await browser.newPage()
  await page.goto(new URL('/earning-configuration/', baseURL).href)
  await states(page, page.locator('.project-return-nav__link'))
  // Mount real components in a separate test host, including a body portal.
  // No persisted customer state or application copy is changed.
  await page.evaluate(async () => {
    const base = '/earning-configuration/src/prototypes/earning-configuration/'
    const [React, DOM, { default: Link }, { default: Button }, { default: Dialog },
      { default: PayrollDocuments }, { default: ReviewStepper }, { CardDisclosure },
      { screeningSession }] = await Promise.all([
      import('/earning-configuration/node_modules/.vite/deps/react.js'),
      import('/earning-configuration/node_modules/.vite/deps/react-dom_client.js'),
      import('/earning-configuration/@fs/home/runner/workspace/lib/ready-dls/src/components/Link/Link.tsx'),
      import('/earning-configuration/@fs/home/runner/workspace/lib/ready-dls/src/components/Button/Button.tsx'),
      import('/earning-configuration/@fs/home/runner/workspace/lib/ready-dls/src/components/Dialog/Dialog.tsx'),
      import(`${base}PayrollDocuments.tsx`), import(`${base}ReviewStepper.tsx`),
      import(`${base}MisclassificationCard.tsx`), import(`${base}overtimeScreening.testing.ts`),
      import(`${base}questionCard.css`), import(`${base}WeightedOvertimeExample.css`),
      import('/earning-configuration/@fs/home/runner/workspace/lib/ready-dls/src/components/GridTable/GridTable.css'),
    ])
    const h = React.default.createElement
    document.getElementById('root').style.display = 'none'
    const host = document.createElement('div')
    document.body.append(host)
    function Fixture() {
      const [open, setOpen] = React.default.useState(false)
      return h(React.default.Fragment, null,
        h(Link, { className: 'test-intake', onClick() {} }, 'Test link'),
        h(Link, { className: 'test-disabled', disabled: true }, 'Disabled'),
        h(Button, { id: 'tertiary', variant: 'tertiary', highEmphasis: true, onClick() {} }, 'Action'),
        h(Button, { id: 'primary' }, 'Primary'),
        h('a', { className: 'test-inline', href: '#download', style: { color: 'var(--color-primary-text)' } }, 'Download'),
        h('div', { className: 'cshell-step--active' }, h('button', { className: 'cshell-step__btn' }, 'Navigation')),
        h('div', { className: 'gt__td--link' }, h('button', null, 'Summary action')),
        h(ReviewStepper, { session: screeningSession(), readOnly: true, currentPage: -1, onGoToPage() {} }),
        h(CardDisclosure, { label: 'Details' }, 'Content'),
        h('details', { className: 'ec-overtime-learn-more' }, h('summary', null, 'Learn more')),
        h('button', { className: 'ec-tip-split__link' }, 'Split'),
        h(PayrollDocuments, { showVideoCallout: true }),
        h(Link, { className: 'test-open', onClick: () => setOpen(true) }, 'Open'),
        h(Dialog, { open, title: 'Test dialog', onClose: () => setOpen(false) },
          h(Link, { className: 'test-portal', href: '#summary' }, 'Summary link')),
      )
    }
    DOM.default.createRoot(host).render(h(Fixture))
  })
  for (const selector of ['.test-intake', '#tertiary', '.ec-stepper__link', '.mc-card__disclosure summary',
    '.ec-overtime-learn-more summary', '.ec-tip-split__link', '.test-inline', '.cshell-step__btn', '.gt__td--link button']) {
    await states(page, page.locator(selector).first())
  }
  await expect(page.locator('.test-disabled')).not.toHaveCSS('color', green)
  await expect(page.locator('#primary')).toHaveCSS('background-color', green)
  await expect(page.locator('.ec-pd__video-play').last()).toHaveCSS('color', green)
  await page.locator('.test-intake').focus()
  await page.keyboard.press('Tab')
  assert.ok(await page.locator(':focus-visible').evaluate(el => parseFloat(getComputedStyle(el).outlineWidth) >= 2))
  await page.locator('.test-open').click()
  await states(page, page.locator('.test-portal'))
  assert.ok(await page.locator('.test-portal').evaluate(el => !!el.closest('[role="dialog"]')))
  await page.keyboard.press('Escape')
  // Remove only the product scope to assert the loaded DLS still supplies blue.
  // This also detects an accidental edit to shared defaults.
  const unchangedTokens = () => page.evaluate(() => {
    const style = getComputedStyle(document.documentElement)
    return ['--color-primary', '--color-focus-border', '--color-primary-text'].map(key => style.getPropertyValue(key))
  })
  const before = await unchangedTokens()
  await page.evaluate(() => delete document.documentElement.dataset.earningConfiguration)
  assert.deepEqual(await unchangedTokens(), before, 'Form, focus and status tokens stay unchanged')
  await expect(page.locator('.test-intake')).toHaveCSS('color', 'rgb(1, 108, 162)')
  await expect(page.locator('#tertiary')).toHaveCSS('color', 'rgb(1, 108, 162)')
  // Exercise the actual saved-theme restoration, not just a synthetic attribute.
  await page.evaluate(() => localStorage.setItem('pg-theme', 'dark'))
  await page.reload()
  await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark')
  await page.evaluate(async () => {
    const [{ default: React }, { default: DOM }, { default: Link }, { default: Button }] = await Promise.all([
      import('/earning-configuration/node_modules/.vite/deps/react.js'),
      import('/earning-configuration/node_modules/.vite/deps/react-dom_client.js'),
      import('/earning-configuration/@fs/home/runner/workspace/lib/ready-dls/src/components/Link/Link.tsx'),
      import('/earning-configuration/@fs/home/runner/workspace/lib/ready-dls/src/components/Button/Button.tsx'),
    ])
    const host = document.createElement('div')
    host.style.background = 'var(--color-bg)'
    document.body.prepend(host)
    DOM.createRoot(host).render(React.createElement(React.Fragment, null,
      React.createElement(Link, { className: 'test-dark-link' }, 'Dark link'),
      React.createElement(Button, { className: 'test-dark-action', variant: 'tertiary', highEmphasis: true }, 'Dark action'),
      React.createElement(Link, { className: 'test-on-dark', onDark: true }, 'On dark'),
    ))
  })
  function luminance(rgb) {
    const channels = rgb.match(/[\d.]+/g).slice(0, 3).map(Number).map(n => {
      const c = n / 255
      return c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4
    })
    return channels[0] * .2126 + channels[1] * .7152 + channels[2] * .0722
  }
  for (const selector of ['.test-dark-link', '.test-dark-action', '.project-return-nav__link']) {
    const control = page.locator(selector)
    await expect(control).toHaveCSS('color', 'rgb(84, 222, 208)')
    for (const state of ['rest', 'hover', 'active']) {
      if (state === 'hover') await control.hover()
      if (state === 'active') await page.mouse.down()
      await expect(control).toHaveCSS('color', state === 'rest' ? 'rgb(84, 222, 208)' : state === 'hover' ? 'rgb(148, 235, 226)' : 'rgb(210, 239, 236)')
      const colors = await control.evaluate(el => {
        let parent = el.parentElement
        while (parent && getComputedStyle(parent).backgroundColor === 'rgba(0, 0, 0, 0)') parent = parent.parentElement
        return [getComputedStyle(el).color, getComputedStyle(parent || document.body).backgroundColor]
      })
      const values = colors.map(luminance).sort((a, b) => b - a)
      assert.ok((values[0] + .05) / (values[1] + .05) >= 4.5, `${selector} ${state}: readable dark-theme contrast`)
    }
    await page.mouse.move(0, 0)
    await page.mouse.up()
  }
  await expect(page.locator('.test-on-dark')).toHaveCSS('color', 'rgb(255, 255, 255)')
  console.log('PASS: link, stepper, disclosure, nested document, dialog, disabled and focus colors; shared defaults unchanged.')
} finally {
  await browser.close()
}
