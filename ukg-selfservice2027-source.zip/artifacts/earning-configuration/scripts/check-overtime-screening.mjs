// Focused real-app layout/keyboard check. Uses a bounded completed-classification fixture,
// not the unrelated demo shortcut. No AI responses or screen text are replaced.
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { existsSync, mkdirSync } from 'node:fs'
const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium, expect } = require('@playwright/test')
const browser = await chromium.launch({
  executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH ||
    (existsSync('/repl/tools/bin/chromium') ? '/repl/tools/bin/chromium' : undefined),
})
const output = process.env.OVERTIME_SCREENSHOTS
const disclosureOnly = process.argv.includes('--disclosure-only')
if (output) mkdirSync(output, { recursive: true })
try {
  for (const width of [1280, 390]) {
    const page = await browser.newPage({ viewport: { width, height: 900 } })
    const errors = []
    page.on('pageerror', error => errors.push(error.message))
    await page.goto(new URL('/earning-configuration/', process.env.BASE_URL || 'http://localhost:80').href)
    await page.evaluate(async () => {
      const base = '/earning-configuration/src/prototypes/earning-configuration/'
      const [{ screeningSession }, { browserStores, writeWorkingCopy }] = await Promise.all([
        import(`${base}overtimeScreening.testing.ts`), import(`${base}storage.ts`),
      ])
      writeWorkingCopy(browserStores(), screeningSession())
    })
    await page.reload()
    const heading = page.locator('.ec-overtime-screening h1')
    await expect(heading).toBeVisible()
    await page.evaluate(() => document.fonts.ready)
    assert.ok(await heading.evaluate(el => {
      const bounds = el.getBoundingClientRect()
      const range = document.createRange()
      range.selectNodeContents(el)
      const style = getComputedStyle(el)
      const introTop = el.nextElementSibling.getBoundingClientRect().top
      // Font ascenders/descenders can extend beyond the line box without being clipped.
      return bounds.left >= 0 && bounds.right <= innerWidth && bounds.top >= 0 && bounds.bottom <= innerHeight
        && [...range.getClientRects()].every(rect => rect.left >= bounds.left - 1 && rect.right <= bounds.right + 1
          && rect.top >= 0 && rect.bottom <= Math.min(innerHeight, introTop)
          && (style.overflowY === 'visible' || (rect.top >= bounds.top && rect.bottom <= bounds.bottom)))
    }), `Full heading fits without clipping at ${width}px`)
    if (output) await page.screenshot({ path: `${output}/overtime-heading-${width}.png` })
    const cards = page.locator('article.ec-qcard')
    const help = cards.first().locator(':scope > details')
    const summaryPadding = () => help.locator('summary').evaluate(el => {
      const style = getComputedStyle(el)
      return [style.paddingTop, style.paddingBottom]
    })
    assert.deepEqual(await summaryPadding(), ['24px', '24px'], 'Collapsed overtime reason padding')
    await help.locator('summary').focus()
    await page.keyboard.press('Enter')
    await expect(help).toHaveAttribute('open', '')
    assert.deepEqual(await summaryPadding(), ['24px', '24px'], 'Expanded overtime reason padding')
    assert.equal(await help.locator('summary').evaluate(el =>
      el.matches(':focus-visible') && parseFloat(getComputedStyle(el).outlineWidth) >= 2),
    true, 'Overtime summary retains visible keyboard focus')
    await expect(help).toContainText('When someone works at different hourly rates in the same week')
    if (!disclosureOnly) {
      const video = help.getByText('Watch video', { exact: true })
      assert.equal(await video.evaluate(el => el.matches('a, button, [tabindex], [role], [href]')), false)
    }
    await page.keyboard.press('Space')
    await expect(help).not.toHaveAttribute('open')
    if (disclosureOnly) {
      assert.deepEqual(errors, [], 'No browser errors')
      console.log(`PASS ${width}px: overtime disclosure padding, keyboard toggle and focus`)
      await page.close()
      continue
    }
    for (let index = 0; index < 5; index++) {
      const card = cards.nth(index)
      await expect(card.getByRole('radio', { name: 'Yes', exact: true })).toBeVisible()
      await card.getByRole('radio', { name: /^No/ }).focus()
      await page.keyboard.press('Space')
      if (index < 4) await expect(cards).toHaveCount(index + 2)
    }
    await expect(page.locator('.ec-result')).toHaveCount(0)
    await expect(page.getByRole('button', { name: 'Continue to summary', exact: true })).toBeEnabled()
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false, 'No horizontal overflow')

    // Exercise normal Tab order across every card, including the longer bonus question.
    await cards.first().getByRole('radio', { name: 'Yes', exact: true }).focus()
    const seen = new Set()
    for (let count = 0; count < 90; count++) {
      await page.keyboard.press('Tab')
      await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))))
      const control = await page.evaluate(() => {
        const active = document.activeElement
        if (!active?.closest('.ec-page')) return null
        const bounds = active.getBoundingClientRect()
        const x = Math.max(0, Math.min(innerWidth - 1, bounds.left + bounds.width / 2))
        const y = Math.max(0, Math.min(innerHeight - 1, bounds.top + bounds.height / 2))
        const hit = document.elementFromPoint(x, y)
        return { text: active.textContent?.trim() || active.getAttribute('aria-label') || active.tagName,
          visible: bounds.top >= 0 && bounds.bottom <= innerHeight,
          reachable: !!hit && (active.contains(hit) || hit.contains(active)) }
      })
      if (!control) continue
      assert.ok(control.visible && control.reachable, `Keyboard target unobscured at ${width}px: ${control.text}`)
      seen.add(control.text)
      if (control.text === 'Continue to summary') break
    }
    assert.ok(seen.has('Why this matters'), 'Tab reaches the first help')
    assert.ok(seen.has('Continue to summary'), 'Tab reaches the footer')
    // Radio groups use roving Tab stops; arrow keys reach the other answers.
    await cards.last().getByRole('radio', { name: /^No/ }).focus()
    await page.keyboard.press('ArrowRight')
    await expect(cards.last().getByRole('radio', { name: 'Something else', exact: true })).toBeFocused()
    await expect(cards.last().getByRole('textbox')).toBeVisible()
    await page.keyboard.press('ArrowLeft')
    await expect(cards.last().getByRole('radio', { name: /^No/ })).toBeFocused()
    const defer = cards.last().locator('.ec-defer input')
    await defer.focus()
    await page.keyboard.press('Space')
    await expect(defer).toBeChecked()
    await page.keyboard.press('Space')
    await expect(defer).not.toBeChecked()
    await cards.last().getByRole('radio', { name: /^No/ }).focus()
    await page.keyboard.press('Space')
    await cards.first().locator(':scope > details summary').focus()
    await page.keyboard.press('Enter')
    if (output) await page.screenshot({ path: `${output}/overtime-${width}.png` })
    await page.reload()
    await expect(cards).toHaveCount(5)
    await expect(page.locator('.ec-result')).toHaveCount(0)
    await cards.nth(1).getByRole('radio', { name: 'Yes', exact: true }).click()
    await expect(cards).toHaveCount(0)
    const resultHeading = page.getByRole('heading', { name: 'Your overtime setup may need additional configuration', exact: true })
    await expect(resultHeading).toBeVisible()
    await expect(resultHeading).toBeFocused()
    await expect(page.locator('.ec-overtime-assessment .ec-intro')).toHaveText([
      'Based on your answers, some employees may receive different rates of pay that need to be considered when calculating overtime.',
      "Weighted average overtime is one method used to account for these differences. We'll help you review the applicable earnings and determine the appropriate setup.",
    ])
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false, 'No assessment horizontal overflow')
    if (output) await page.screenshot({ path: `${output}/assessment-${width}.png` })
    await page.reload()
    await expect(resultHeading).toBeVisible()
    await expect(resultHeading).toBeFocused()
    await page.keyboard.press('Tab')
    await expect(page.getByRole('button', { name: 'Back', exact: true })).toBeFocused()
    await page.keyboard.press('Tab')
    const next = page.getByRole('button', { name: 'Next', exact: true })
    await expect(next).toBeFocused()
    assert.ok(await next.evaluate(el => {
      const rect = el.getBoundingClientRect()
      const hit = document.elementFromPoint(rect.left + rect.width / 2, rect.top + rect.height / 2)
      return rect.top >= 0 && rect.bottom <= innerHeight && !!hit && el.contains(hit)
    }), 'Assessment Next is unobscured')
    await page.keyboard.press('Enter')
    await expect(page.getByRole('heading', { name: 'Identify applicable earning codes', exact: true })).toBeFocused()
    await page.getByRole('button', { name: 'Back', exact: true }).click()
    await expect(resultHeading).toBeVisible()
    await page.getByRole('button', { name: 'Back', exact: true }).click()
    await expect(heading).toBeVisible()
    await expect(cards).toHaveCount(2)
    // Revise the Yes; a stale result can no longer be entered.
    await cards.nth(1).getByRole('radio', { name: /^No/ }).click()
    await expect(cards).toHaveCount(5)
    await expect(page.getByRole('button', { name: 'Next', exact: true })).toHaveCount(0)
    await page.reload()
    await expect(cards).toHaveCount(5)
    assert.deepEqual(errors, [], 'No browser errors')
    console.log(`PASS ${width}px: copy, disclosure keyboard toggle, answer controls, footer/Bryte clearance, refresh and recommendations`)
    await page.close()
  }
} finally {
  await browser.close()
}
