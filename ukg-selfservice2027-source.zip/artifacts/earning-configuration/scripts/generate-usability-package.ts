import { mkdir, writeFile } from 'node:fs/promises'
import { createRequire } from 'node:module'
import { USABILITY_CODE_ROWS, USABILITY_REGISTER_ROWS, USABILITY_FILES, usabilityCsv } from '../src/prototypes/earning-configuration/usabilityData'

// Use the existing server's ExcelJS dependency; the workbook and CSVs share the browser's authored data.
const require = createRequire(new URL('../../api-server/package.json', import.meta.url))
const ExcelJS = require('exceljs')
const directory = new URL('../public/usability/', import.meta.url)
await mkdir(directory, { recursive: true })
const workbook = new ExcelJS.Workbook()
workbook.creator = 'UKG Ready usability research'
for (const [index, rows] of [USABILITY_CODE_ROWS, USABILITY_REGISTER_ROWS].entries()) {
  await writeFile(new URL(USABILITY_FILES[index].name, directory), usabilityCsv(rows))
  const sheet = workbook.addWorksheet(index === 0 ? 'Earning codes' : 'Payment detail')
  sheet.addRows(rows)
  sheet.views = [{ state: 'frozen', ySplit: index === 0 ? 4 : 9 }]
  sheet.columns.forEach((column: { width: number }, i: number) => { column.width = index === 0 && i === 1 ? 78 : 25 })
  sheet.getRow(index === 0 ? 4 : 9).eachCell((cell: { font: unknown; fill: unknown }) => {
    cell.font = { bold: true, color: { argb: 'FFFFFFFF' } }
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF005B55' } }
  })
  sheet.pageSetup = { orientation: 'landscape', fitToPage: true, fitToWidth: 1, fitToHeight: 0 }
}
await workbook.xlsx.writeFile(new URL('cedar-vale-payroll-package.xlsx', directory).pathname)
