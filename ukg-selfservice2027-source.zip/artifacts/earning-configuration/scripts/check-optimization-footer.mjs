import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { existsSync } from 'node:fs'

const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium, expect } = require('@playwright/test')
const browser = await chromium.launch({
  executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH ||
    (existsSync('/repl/tools/bin/chromium') ? '/repl/tools/bin/chromium' : undefined),
})
try {
  for (const width of [1280, 390, 320]) {
    const page = await browser.newPage({ viewport: { width, height: 800 } })
    await page.goto(new URL('/earning-configuration/', process.env.BASE_URL || 'http://localhost:80').href)
    await page.evaluate(async () => {
      const base = '/earning-configuration/src/prototypes/earning-configuration/'
      const [{ overtimeCombinationSession }, { browserStores, writeWorkingCopy }] = await Promise.all([
        import(`${base}overtimeCombination.testing.ts`), import(`${base}storage.ts`),
      ])
      writeWorkingCopy(browserStores(), overtimeCombinationSession())
    })
    await page.reload()
    const footer = page.locator('.ec-optimization > .ec-submit-bar')
    const next = footer.getByRole('button', { name: 'Next', exact: true })
    const back = footer.getByRole('button', { name: 'Back', exact: true })
    await expect(footer).toBeVisible()
    const checkLayout = async () => {
      assert.equal(await footer.evaluate(node => getComputedStyle(node).position), 'static')
      assert.equal((await footer.textContent()).replace(/\s/g, ''), 'BackNext')
      assert.equal(await next.getAttribute('aria-describedby'), null)
      const card = page.locator('.ec-optimization .ec-question-group:visible')
      const [cardBox, footerBox] = await Promise.all([card.boundingBox(), footer.boundingBox()])
      assert.ok(footerBox.y >= cardBox.y + cardBox.height, 'Navigation follows the current card')
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false)
      await back.focus()
      await page.keyboard.press('Tab')
      await expect(next).toBeFocused()
      await next.evaluate(node => node.scrollIntoView({ block: 'center' }))
      assert.ok(await next.evaluate(node => {
        const b = node.getBoundingClientRect()
        const hit = document.elementFromPoint(b.x + b.width / 2, b.y + b.height / 2)
        return b.top >= 0 && b.bottom <= innerHeight && node.contains(hit)
      }), 'Next is reachable and unobscured')
    }
    await checkLayout() // Tall overtime comparison.
    await page.keyboard.press('Enter')
    await expect(page.locator('.ec-optimization h1')).toBeFocused()
    await checkLayout() // Shorter suggestion.
    await back.click()
    await expect(page.locator('[data-optimization-card="combine-current-overtime"]')).toBeVisible()
    await page.close()
    console.log(`Optimization footer layout and keyboard navigation passed at ${width}px`)
  }
} finally {
  await browser.close()
}
