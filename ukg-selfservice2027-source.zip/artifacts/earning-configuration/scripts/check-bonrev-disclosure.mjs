// Focused real-card check, using the running dev app's components and styles.
// BASE_URL=https://$REPLIT_DEV_DOMAIN node artifacts/earning-configuration/scripts/check-bonrev-disclosure.mjs
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { existsSync, mkdirSync } from 'node:fs'
import { resolve } from 'node:path'

const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium, expect } = require('@playwright/test')
const approved = 'Other payroll systems often classify transactions by payroll engine logic ("anything affecting gross wages is an earning"). UKG Ready classifies transactions by business purpose: compensation belongs in Earnings, while employee withholdings and recoveries belong in Deductions. This separation improves tax processing, benefit administration, vendor payments, arrears handling, and reporting.'
const screenshotDir = process.env.BONREV_SCREENSHOTS
if (screenshotDir) mkdirSync(screenshotDir, { recursive: true })
const browser = await chromium.launch({
  executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH ||
    (existsSync('/repl/tools/bin/chromium') ? '/repl/tools/bin/chromium' : undefined),
})
try {
  for (const width of [1280, 390]) {
    const page = await browser.newPage({ viewport: { width, height: 1000 } })
    const errors = []
    page.on('pageerror', error => errors.push(error.message))
    await page.goto(new URL('/earning-configuration/', process.env.BASE_URL || 'http://localhost:80').href)
    await page.evaluate(async () => {
      const base = '/earning-configuration/src/prototypes/earning-configuration/'
      const [react, dom, { default: Card }, { SessionContext }, { createSession }, { findItem }] = await Promise.all([
        import('/earning-configuration/node_modules/.vite/deps/react.js'),
        import('/earning-configuration/node_modules/.vite/deps/react-dom_client.js'),
        import(`${base}MisclassificationCard.tsx`), import(`${base}sessionContext.ts`),
        import(`${base}session.ts`), import(`${base}sampleRegister.ts`), import(`${base}earningConfig.css`),
      ])
      const React = react.default
      const h = React.createElement
      const host = document.createElement('main')
      host.className = 'ec-content'
      host.style.cssText = 'max-width:800px;margin:auto;padding:16px;box-sizing:border-box'
      document.getElementById('root').style.display = 'none'
      document.body.append(host)
      function Fixture() {
        const [selected, onSelect] = React.useState('')
        return h(Card, { item: findItem('BONREV'), selected, onSelect })
      }
      dom.default.createRoot(host).render(h(SessionContext.Provider, {
        value: { session: createSession(), dispatch: () => {}, save: () => true, restart: () => true },
      }, h(Fixture)))
    })
    const card = page.getByTestId('card-misclassification-BONREV')
    await expect(card.getByRole('heading', { name: 'BONREV needs a different setup' })).toBeVisible()
    const disclosure = card.locator('.mc-card__disclosure')
    const summary = disclosure.locator('summary')
    await expect(disclosure).not.toHaveAttribute('open')
    await summary.focus()
    await page.keyboard.press('Enter')
    await expect(disclosure).toHaveAttribute('open', '')
    const paragraphs = disclosure.locator('.mc-card__disclosure-content p')
    await expect(paragraphs).toHaveCount(3)
    await expect(paragraphs.nth(1)).toHaveText(approved)
    await expect(paragraphs.nth(0)).toContainText('The original bonus stays in Earnings.')
    await expect(paragraphs.nth(2)).toContainText('It is not a choice of classification')
    assert.doesNotMatch(await disclosure.textContent(), /remaining decision|accept the proposed deduction|confirms that proposal/i)
    const geometry = await paragraphs.evaluateAll(nodes => nodes.map(node => {
      const rect = node.getBoundingClientRect()
      return { top: rect.top, bottom: rect.bottom, left: rect.left, right: rect.right, lineHeight: getComputedStyle(node).lineHeight }
    }))
    for (const paragraph of geometry) {
      assert.ok(paragraph.left >= 0 && paragraph.right <= width, 'Paragraph fits viewport')
      assert.equal(paragraph.lineHeight, '20px')
    }
    for (let i = 1; i < geometry.length; i++) {
      assert.ok(geometry[i].top - geometry[i - 1].bottom >= 8, 'Readable paragraph spacing')
    }
    const acknowledge = card.locator('#checkbox-accept-BONREV')
    const defer = card.locator('#checkbox-defer-BONREV')
    const acknowledgeLabel = card.locator('label.mc-card__acknowledge')
    const deferLabel = card.locator('.ec-defer label')
    await acknowledgeLabel.click()
    await expect(acknowledge).toBeChecked()
    await acknowledgeLabel.click()
    await expect(acknowledge).not.toBeChecked()
    await deferLabel.click()
    await expect(defer).toBeChecked()
    await expect(acknowledge).not.toBeChecked()
    await acknowledgeLabel.click()
    await expect(defer).not.toBeChecked()
    await deferLabel.click()
    await expect(acknowledge).not.toBeChecked()
    await deferLabel.click()
    await expect(defer).not.toBeChecked()
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false, 'No horizontal overflow')
    if (screenshotDir) await page.screenshot({ path: resolve(screenshotDir, `bonrev-${width}.png`), fullPage: true })
    await summary.focus()
    await page.keyboard.press('Space')
    await expect(disclosure).not.toHaveAttribute('open')
    assert.deepEqual(errors, [], 'No browser errors')
    console.log(`PASS ${width}px: approved paragraph, spacing, wrapping, disclosure keyboard toggle, acknowledgment and Defer`)
    await page.close()
  }
} finally {
  await browser.close()
}
