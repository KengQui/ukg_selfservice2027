// Focused copy and geometry check using the review renderer and styles from the dev app.
// BASE_URL=https://$REPLIT_DEV_DOMAIN node artifacts/earning-configuration/scripts/check-review-intro-layout.mjs
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { existsSync, mkdirSync } from 'node:fs'
import { resolve } from 'node:path'

const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium } = require('@playwright/test')
const browser = await chromium.launch({
  executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH ||
    (existsSync('/repl/tools/bin/chromium') ? '/repl/tools/bin/chromium' : undefined),
})
const guidanceByTopic = [
  'Not sure about something? Select Defer to come back to it later.',
  'Not sure about something? Select Defer to come back to it later.',
  'Do you pay a set amount for work expenses or pay people back for what they spend? Tell us how it works. You can defer anything you’re unsure about.',
  "If you're unsure, select Defer and return to this question later.",
  'Not sure about something? Select Defer to come back to it later.',
  'Not sure about something? Select Defer to come back to it later.',
  'Not sure? Select Defer and come back later.',
]
const screenshots = process.env.REVIEW_INTRO_SCREENSHOTS
if (screenshots) mkdirSync(screenshots, { recursive: true })

try {
  for (const width of [1280, 390]) {
    const page = await browser.newPage({ viewport: { width, height: 1000 } })
    const errors = []
    page.on('pageerror', error => errors.push(error.message))
    await page.goto(new URL('/earning-configuration/', process.env.BASE_URL || 'http://localhost:80').href)
    const count = await page.evaluate(async () => {
      const base = '/earning-configuration/src/prototypes/earning-configuration/'
      const [ReactModule, ReactDOMModule, { default: StepQuestions }, { SessionContext },
        { createSession, reduceSession, parseSession, reviewPages }, { LEAVE_ITEMS }, { REVIEW_TOPICS }] = await Promise.all([
        import('/earning-configuration/node_modules/.vite/deps/react.js'),
        import('/earning-configuration/node_modules/.vite/deps/react-dom_client.js'),
        import(`${base}StepQuestions.tsx`), import(`${base}sessionContext.ts`),
        import(`${base}session.ts`), import(`${base}sampleRegister.ts`), import(`${base}reviewTopics.ts`),
        import(`${base}earningConfig.css`),
      ])
      let session = reduceSession({
        ...createSession(0), answers: Object.fromEntries(LEAVE_ITEMS.map(item => [item.id, {}])),
      }, { type: 'startReview' }, 1)
      // Complete answers keep every saved cursor stable without changing any question rules.
      for (const id of reviewPages(session).flat()) {
        session = reduceSession(session, { type: 'choose', itemId: id, choice: 'ask-customer' }, 2)
      }
      const host = document.createElement('main')
      host.className = 'ec-content'
      document.getElementById('root').style.display = 'none'
      document.body.append(host)
      const root = ReactDOMModule.default.createRoot(host)
      window.renderReviewIntro = (index, restored) => {
        const saved = { ...session, reviewCursor: index }
        root.render(ReactModule.default.createElement(SessionContext.Provider, {
          value: { session: restored ? parseSession(JSON.stringify(saved)) : saved,
            dispatch: () => {}, save: () => true, restart: () => true },
        }, ReactModule.default.createElement(StepQuestions)))
      }
      return REVIEW_TOPICS.length
    })
    assert.equal(count, 7)
    for (const restored of [false, true]) {
      for (let index = 0; index < count; index++) {
        const guidance = guidanceByTopic[index]
        await page.evaluate(({ index, restored }) => window.renderReviewIntro(index, restored), { index, restored })
        await page.waitForFunction(({ guidance, index }) =>
          document.querySelector('.ec-stepper__step[aria-current="step"]')?.textContent?.includes(
            document.querySelector('h1.ec-h1')?.textContent) &&
          document.querySelector('.ec-intro > p:last-child')?.textContent === guidance &&
          [...document.querySelectorAll('.ec-stepper__step')].indexOf(
            document.querySelector('.ec-stepper__step[aria-current="step"]')) === index,
        { guidance, index })
        const layout = await page.locator('.ec-intro').evaluate((intro, guidance) => {
          const paragraphs = [...intro.children]
          const last = paragraphs.at(-1)
          const previous = last.previousElementSibling
          return {
            count: intro.textContent.split(guidance).length - 1,
            last: last.textContent,
            tags: paragraphs.map(p => p.tagName),
            gap: previous ? last.getBoundingClientRect().top - previous.getBoundingClientRect().bottom : null,
            margin: parseFloat(getComputedStyle(last).marginTop),
            allGaps: paragraphs.slice(1).map((p, i) =>
              p.getBoundingClientRect().top - paragraphs[i].getBoundingClientRect().bottom),
            overflow: paragraphs.some(p => p.getBoundingClientRect().right > innerWidth),
            style: [getComputedStyle(last).color, getComputedStyle(last).fontWeight],
            explanationStyle: [getComputedStyle(paragraphs[0]).color, getComputedStyle(paragraphs[0]).fontWeight],
          }
        }, guidance)
        assert.equal(layout.count, 1)
        assert.equal(layout.last, guidance)
        assert.ok(layout.tags.every(tag => tag === 'P'))
        if (layout.tags.length > 1) assert.ok(layout.margin > 0)
        assert.ok(layout.allGaps.every(gap => Math.abs(gap - layout.margin) <= 1))
        assert.equal(layout.overflow, false)
        assert.deepEqual(layout.style, layout.explanationStyle)
        if (screenshots && restored && [0, 2, 5].includes(index)) {
          await page.locator('.ec-intro').screenshot({
            path: resolve(screenshots, `intro-${width}-${index}.png`),
          })
        }
      }
    }
    assert.deepEqual(errors, [])
    console.log(`${width}px: all seven fresh and restored intros have their approved guidance and matching spacing.`)
    await page.close()
  }
} finally {
  await browser.close()
}
