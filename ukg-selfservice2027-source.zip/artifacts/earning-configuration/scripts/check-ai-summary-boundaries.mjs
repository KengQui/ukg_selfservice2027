import assert from 'node:assert/strict'
import { mkdir } from 'node:fs/promises'
import { createRequire } from 'node:module'

const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium, expect } = require('@playwright/test')
const baseURL = process.env.EARNING_PREVIEW_URL || 'http://localhost:80/earning-configuration/'
const output = new URL('../../../generated-artifacts/summary-boundaries/', import.meta.url)
await mkdir(output, { recursive: true })
const browser = await chromium.launch({ executablePath: '/repl/tools/bin/chromium' })

try {
  const page = await browser.newPage()
  const errors = []
  page.on('pageerror', error => errors.push(error.message))
  await page.goto(baseURL)
  await expect(page.getByRole('button', { name: 'Start', exact: true })).toBeVisible()

  async function seed(variant, analysis = false) {
    await page.evaluate(async ({ variant, analysis }) => {
      const base = new URL('./src/prototypes/earning-configuration/', location.href).href
      const { boundariesReviewFixture } = await import(`${base}aiSummaryBoundaries.testing.ts`)
      const { WORKING_COPY_KEY, SAVED_COPY_KEY } = await import(`${base}storage.ts`)
      const state = boundariesReviewFixture(variant)
      if (analysis) state.step = 'analysis'
      state.updatedAt = Date.now()
      sessionStorage.setItem(WORKING_COPY_KEY, JSON.stringify(state))
      localStorage.setItem(SAVED_COPY_KEY, JSON.stringify(state))
    }, { variant, analysis })
    await page.reload()
  }
  async function snapshot() {
    return page.evaluate(async () => {
      const { WORKING_COPY_KEY, SAVED_COPY_KEY } = await import(
        new URL('./src/prototypes/earning-configuration/storage.ts', location.href).href)
      return { working: sessionStorage.getItem(WORKING_COPY_KEY), saved: localStorage.getItem(SAVED_COPY_KEY) }
    })
  }

  for (const variant of ['sample', 'uploaded']) {
    for (const viewport of [{ width: 1366, height: 900 }, { width: 390, height: 844 }, { width: 320, height: 568 }]) {
      await page.setViewportSize(viewport)
      await seed(variant)
      const heading = page.getByRole('heading', { name: variant === 'sample' ? 'Let’s fill in the gaps in your pay code setup' : 'What do we need to review?', exact: true })
      const trigger = page.getByRole('button', { name: 'About the AI summary', exact: true })
      const dialog = page.getByRole('dialog', { name: 'Boundaries for the AI summary', exact: true })
      await expect(heading).toBeVisible()
      await expect(trigger).toBeVisible()
      await expect(dialog).toHaveCount(0)
      if (variant === 'sample') {
        await expect(page.getByTestId('row-cheat-SPPAY')).toBeVisible()
        await expect(page.getByRole('textbox', { name: 'Answer', exact: true })).toHaveValue('A stipend for using a second language.')
      }
      assert.equal(await heading.locator('button').count(), 0)
      const before = await snapshot()
      const contentBefore = await page.locator('.ec-page').innerText()
      const bounds = await trigger.boundingBox()
      const headingBounds = await heading.boundingBox()
      assert(bounds.width >= 44 && bounds.height >= 44)
      assert(bounds.x - (headingBounds.x + headingBounds.width) <= 12, 'Help must be immediately beside the heading')
      await trigger.click()
      await expect(dialog).toBeVisible()
      await dialog.evaluate(el => Promise.all(
        el.parentElement.getAnimations({ subtree: true }).map(animation => animation.finished),
      ))
      const approved = await page.evaluate(async () => (await import(
        new URL('./src/prototypes/earning-configuration/aiSummaryBoundaries.testing.ts', location.href).href)).APPROVED_BOUNDARIES)
      assert.deepEqual(await dialog.locator('li').allTextContents(), approved)
      const close = dialog.getByRole('button', { name: 'Close dialog', exact: true })
      const list = dialog.getByRole('list')
      await expect(close).toBeFocused()
      await page.keyboard.press('Tab')
      await expect(list).toBeFocused()
      await page.keyboard.press('Tab')
      await expect(close).toBeFocused()
      await page.keyboard.press('Shift+Tab')
      await expect(list).toBeFocused()
      // The long mobile list must be scrollable using a keyboard, not just touch.
      await page.keyboard.press('End')
      const body = dialog.locator('.dlg__content')
      await expect.poll(() => body.evaluate(el => el.scrollTop + el.clientHeight >= el.scrollHeight - 2)).toBe(true)
      const size = await body.evaluate(el => ({ width: el.clientWidth, content: el.scrollWidth }))
      assert(size.content <= size.width, 'Dialog content must not clip horizontally')
      await expect(close).toBeInViewport()
      await expect(dialog.locator('li').last()).toBeInViewport()
      await page.keyboard.press('Home')
      await expect.poll(() => body.evaluate(el => el.scrollTop)).toBe(0)
      await page.screenshot({ path: new URL(`${variant}-${viewport.width}.png`, output).pathname, animations: 'disabled' })
      await page.keyboard.press('Escape')
      await expect(dialog).toHaveCount(0)
      await expect(trigger).toBeFocused()
      // Test actual native button activation with both Enter and Space.
      for (const key of ['Enter', 'Space']) {
        const ring = await trigger.evaluate(el => getComputedStyle(el).outlineStyle)
        assert.notEqual(ring, 'none', 'Keyboard focus must be visible')
        await page.keyboard.press(key)
        await expect(dialog).toBeVisible()
        await close.click()
        await expect(dialog).toHaveCount(0)
        await expect(trigger).toBeFocused()
      }
      assert.deepEqual(await snapshot(), before, 'Opening help must not write either copy of progress')
      assert.equal(await page.locator('.ec-page').innerText(), contentBefore)
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false)
      if (variant === 'sample') {
        await page.getByRole('button', { name: 'Back', exact: true }).click()
        await expect(page.getByText('These answers have already been applied.', { exact: false })).toBeVisible()
        await page.getByRole('button', { name: 'Return to results', exact: true }).click()
        await expect(heading).toBeVisible()
        const afterBack = await snapshot()
        const beforeState = JSON.parse(before.working)
        const afterState = JSON.parse(afterBack.working)
        // Navigation may update its timestamp, but not any answer, decision, note or evidence.
        delete beforeState.updatedAt
        delete afterState.updatedAt
        assert.deepEqual(afterState, beforeState)
      } else {
        await page.getByRole('button', { name: 'Back to files', exact: true }).click()
        await expect(page.getByRole('heading', { name: 'Upload pay registers', exact: true })).toBeVisible()
      }
      console.log(`${variant}, ${viewport.width}px: exact copy, pointer/keyboard, focus trap/return, scrolling and unchanged review passed`)
    }
  }
  await seed('uploaded', true)
  await expect(page.getByRole('heading', { name: 'What we read from your files', exact: true })).toBeVisible()
  await expect(page.getByRole('button', { name: 'About the AI summary', exact: true })).toHaveCount(0)
  assert.deepEqual(errors, [], 'No uncaught browser errors')
  console.log('File analysis has no summary help. All AI summary boundaries browser checks passed.')
} finally {
  await browser.close()
}
