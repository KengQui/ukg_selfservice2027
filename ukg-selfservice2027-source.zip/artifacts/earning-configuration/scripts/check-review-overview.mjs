// Focused overview layout and keyboard check; no payroll decisions or AI calls.
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { existsSync, mkdirSync } from 'node:fs'
const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium, expect } = require('@playwright/test')
const browser = await chromium.launch({
  executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH ||
    (existsSync('/repl/tools/bin/chromium') ? '/repl/tools/bin/chromium' : undefined),
})
const output = process.env.OVERVIEW_SCREENSHOTS
if (output) mkdirSync(output, { recursive: true })
try {
  for (const width of [1280, 390]) {
    const page = await browser.newPage({ viewport: { width, height: 900 } })
    const errors = []
    page.on('pageerror', error => errors.push(error.message))
    await page.goto(new URL('/earning-configuration/', process.env.BASE_URL || 'http://localhost:80').href)
    await page.evaluate(async () => {
      const base = '/earning-configuration/src/prototypes/earning-configuration/'
      const [{ createSession, reduceSession }, { browserStores, writeWorkingCopy }] = await Promise.all([
        import(`${base}session.ts`), import(`${base}storage.ts`),
      ])
      writeWorkingCopy(browserStores(), reduceSession({
        ...createSession(), step: 'results', preparationComplete: true,
      }, { type: 'enterReview' }))
    })
    await page.reload()
    const heading = page.getByRole('heading', { name: 'Here’s what the review covers' })
    await expect(heading).toBeVisible()
    await expect(heading).toBeFocused()
    await expect(page.locator('.cshell__header-area')).toBeVisible()
    await expect(page.locator('.ec-ro__stages > li')).toHaveCount(3)
    await expect(page.getByRole('button', { name: 'Save and finish later', exact: true })).toBeVisible()
    await page.evaluate(() => document.fonts.ready)
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false)
    const cards = await page.locator('.ec-ro__stage').evaluateAll(nodes => nodes.map(node => {
      const rect = node.getBoundingClientRect()
      return { x: rect.x, y: rect.y }
    }))
    assert.equal(width < 768 ? cards[0].y < cards[1].y && cards[1].y < cards[2].y
      : cards.every(card => card.y === cards[0].y), true)
    await page.keyboard.press('Tab')
    await expect(page.getByRole('button', { name: 'Back', exact: true })).toBeFocused()
    await page.keyboard.press('Tab')
    await expect(page.getByRole('button', { name: 'Start review', exact: true })).toBeFocused()
    if (output) await page.screenshot({ path: `${output}/overview-${width}.jpg`, fullPage: true })
    assert.deepEqual(errors, [])
    await page.close()
  }
  console.log('Overview desktop, mobile, shell and keyboard checks passed.')
} finally {
  await browser.close()
}
