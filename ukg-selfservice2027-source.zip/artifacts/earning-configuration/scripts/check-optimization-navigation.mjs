import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { existsSync } from 'node:fs'
const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium, expect } = require('@playwright/test')
const browser = await chromium.launch({
  executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH ||
    (existsSync('/repl/tools/bin/chromium') ? '/repl/tools/bin/chromium' : undefined),
})
try {
  for (const width of [1280, 390, 320]) {
    const page = await browser.newPage({ viewport: { width, height: 900 } })
    await page.goto(new URL('/earning-configuration/', process.env.BASE_URL || 'http://localhost:80').href)
    await page.evaluate(async () => {
      const base = '/earning-configuration/src/prototypes/earning-configuration/'
      const [{ overtimeCombinationSession }, { browserStores, writeWorkingCopy }] = await Promise.all([
        import(`${base}overtimeCombination.testing.ts`), import(`${base}storage.ts`),
      ])
      writeWorkingCopy(browserStores(), overtimeCombinationSession())
    })
    await page.reload()
    const cards = page.locator('.ec-question-group:visible')
    await expect(cards).toHaveCount(1)
    const checkSupportingText = async (id) => {
      await expect(cards).toHaveAttribute('data-optimization-card', id)
      const details = cards.locator('.sc__sub-heading')
      assert.ok(await details.count() >= 2, `${id} has supporting text`)
      const checkWeights = async () => {
        for (const detail of await details.all()) await expect(detail).toHaveCSS('font-weight', '400')
        for (const title of await cards.locator('.sc__title').all()) await expect(title).toHaveCSS('font-weight', '500')
        await expect(cards.getByRole('heading', { level: 3 })).toHaveCSS('font-weight', '600')
      }
      await checkWeights()
      for (const option of await cards.getByRole('radio').all()) {
        await option.click()
        await expect(option).toHaveAttribute('aria-checked', 'true')
        await checkWeights()
      }
    }
    await checkSupportingText('combine-current-overtime')
    const first = await cards.getAttribute('data-optimization-card')
    await page.getByRole('radio', { name: /^Something else/ }).click()
    await page.getByRole('textbox', { name: 'Description', exact: true }).fill('Track costs by project.')
    for (const expected of ['2/3', '3/3']) {
      const next = page.locator('.ec-submit-bar').getByRole('button', { name: 'Next', exact: true })
      await next.focus()
      await page.keyboard.press('Enter')
      await expect(cards).toHaveCount(1)
      await expect(cards.locator('.ec-review-card-counter')).toContainText(expected)
      await expect(page.getByRole('heading', { name: 'Optimize codes', exact: true })).toBeFocused()
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false)
      // Hidden cards must not expose their inputs to keyboard or accessibility navigation.
      await expect(page.getByRole('textbox', { name: 'Description', exact: true })).toHaveCount(0)
      await checkSupportingText(expected === '2/3' ? 'split-bonus' : 'inactive-JURY')
    }
    await page.reload()
    await expect(cards.locator('.ec-review-card-counter')).toContainText('3/3')
    const back = page.locator('.ec-submit-bar').getByRole('button', { name: 'Back', exact: true })
    await back.focus(); await page.keyboard.press('Enter')
    await back.focus(); await page.keyboard.press('Enter')
    await expect(cards).toHaveAttribute('data-optimization-card', first)
    await expect(page.getByRole('textbox', { name: 'Description', exact: true })).toHaveValue('Track costs by project.')
    console.log(`Optimization navigation, keyboard focus, draft restore and overflow passed at ${width}px`)
    await page.close()
  }
} finally { await browser.close() }
