// Focused keyboard and navigation check using a scripted, validated tip proposal, not live AI.
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { existsSync } from 'node:fs'
const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium, expect } = require('@playwright/test')
const browser = await chromium.launch({ executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH
  || (existsSync('/repl/tools/bin/chromium') ? '/repl/tools/bin/chromium' : undefined) })
const url = new URL('/earning-configuration/', process.env.BASE_URL || 'http://localhost:80').href
const dir = '/earning-configuration/src/prototypes/earning-configuration/'
try {
  for (const code of ['TIPS', 'TIPS OWED']) {
    const page = await browser.newPage()
    await page.goto(url)
    await page.evaluate(async ({ dir, code }) => {
      const { createSession, reduceSession } = await import(dir + 'session.ts')
      const { tipsBasis } = await import(dir + 'tipsFlow.ts')
      const { WORKING_COPY_KEY, SAVED_COPY_KEY } = await import(dir + 'storage.ts')
      let state = { ...createSession(1), step: 'questions', reviewCursor: 0,
        rounds: [{ number: 1, itemIds: [code], submitted: false }] }
      state = reduceSession(state, { type: 'tips', itemId: code,
        event: { kind: 'answer', id: 'opening', value: 'paid-and-reported' } }, 2)
      state = reduceSession(state, { type: 'tips', itemId: code,
        event: { kind: 'checked', basis: tipsBasis(state.answers[code], code), result: {
          outcome: 'pending', question: null, options: null, rollUp: null, splitReview: true,
          reason: 'Separate earnings codes are needed for tips already received and shared tips still owed. The current setup needs verification.',
        } } }, 3)
      localStorage.removeItem(SAVED_COPY_KEY)
      sessionStorage.setItem(WORKING_COPY_KEY, JSON.stringify(state))
    }, { dir, code })
    await page.reload()
    const summary = page.getByRole('region', { name: `${code} summary`, exact: true })
    const setup = summary.getByRole('button', { name: 'Set up new code', exact: true })
    const later = summary.getByRole('button', { name: 'Do it later', exact: true })
    await expect(setup).toBeVisible()
    const before = await page.evaluate(() => JSON.stringify(sessionStorage))
    const initialUrl = page.url()
    await setup.focus()
    await page.keyboard.press('Enter')
    await expect(summary.getByRole('status')).toContainText('isn’t available here yet')
    await expect(setup).toBeFocused()
    await page.keyboard.press('Tab')
    await expect(later).toBeFocused()
    await page.keyboard.press('Space')
    await expect(summary.getByRole('status')).toContainText('new code still needs setup')
    assert.equal(page.url(), initialUrl)
    assert.equal(await page.evaluate(() => JSON.stringify(sessionStorage)), before)
    await page.reload()
    await expect(setup).toBeVisible()
    await expect(summary).toContainText('current setup needs verification')
    await page.close()
  }
  console.log('Tip split actions: keyboard, feedback, no navigation, unchanged answers and return access passed for both codes.')
} finally {
  await browser.close()
}
