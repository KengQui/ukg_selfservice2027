// Focused geometry check using the real components and styles from the running dev app.
// BASE_URL=https://$REPLIT_DEV_DOMAIN pnpm --filter @workspace/earning-configuration test:why-spacing
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { existsSync, mkdirSync } from 'node:fs'
import { resolve } from 'node:path'

const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium, expect } = require('@playwright/test')
const browser = await chromium.launch({
  executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH ||
    (existsSync('/repl/tools/bin/chromium') ? '/repl/tools/bin/chromium' : undefined),
})
const screenshotDir = process.env.WHY_SPACING_SCREENSHOTS
if (screenshotDir) mkdirSync(screenshotDir, { recursive: true })
const close = (actual, expected, name) =>
  assert.ok(Math.abs(actual - expected) <= 1, `${name}: ${actual} vs ${expected}`)

try {
  for (const width of [1280, 390]) {
    const page = await browser.newPage({ viewport: { width, height: 1000 } })
    const errors = []
    page.on('pageerror', error => errors.push(error.message))
    await page.goto(new URL('/earning-configuration/', process.env.BASE_URL || 'http://localhost:80').href)
    await page.evaluate(async () => {
      const base = '/earning-configuration/src/prototypes/earning-configuration/'
      const [
        ReactModule, ReactDOMModule, { default: QuestionCard, QuestionSection, FollowUpSequence },
        { WhyAsking, ItemQuestion }, { CellReplyQuestion }, { SessionContext }, { createSession }, { findItem },
        { default: TipsQuestions },
        { default: MisclassificationCard, CardDisclosure },
      ] = await Promise.all([
        import('/earning-configuration/node_modules/.vite/deps/react.js'),
        import('/earning-configuration/node_modules/.vite/deps/react-dom_client.js'),
        import(`${base}QuestionCard.tsx`), import(`${base}StepQuestions.tsx`),
        import(`${base}CellQuestions.tsx`), import(`${base}sessionContext.ts`), import(`${base}session.ts`),
        import(`${base}sampleRegister.ts`),
        import(`${base}TipsQuestions.tsx`),
        import(`${base}MisclassificationCard.tsx`),
        import(`${base}earningConfig.css`),
      ])
      const React = ReactModule.default
      const { createRoot } = ReactDOMModule.default
      const h = React.createElement
      const reason = 'The payment purpose is still unclear.\n\nYour answer tells us which payment to review.'
      const options = [{ id: 'yes', title: 'Yes' }, { id: 'no', title: 'No' }]
      const card = (id, props) => h('section', { 'data-fixture': id },
        h(QuestionCard, { label: id, question: 'Which payment should we review?', answered: false, options, ...props }))
      const host = document.createElement('main')
      host.className = 'ec-content'
      host.style.cssText = 'max-width:800px;margin:auto;padding:16px;gap:24px;box-sizing:border-box'
      document.getElementById('root').style.display = 'none'
      document.body.append(host)
      createRoot(host).render(h(SessionContext.Provider, {
        value: { session: createSession(), dispatch: () => {}, save: () => true, restart: () => true },
      },
      card('full-width', {
        variant: 'misclassification',
        why: h(React.Fragment, null, ...reason.split('\n\n').map(text => h('p', { key: text }, text))),
      }),
      card('inline', { context: h(WhyAsking, null, reason) }),
      card('question-first', {
        layout: 'question-first',
        why: h(React.Fragment, null, ...reason.split('\n\n').map(text => h('p', { key: text }, text))),
      }),
      card('nested-follow-up', {
        followUps: h(FollowUpSequence, null, h(QuestionSection, {
          question: 'What is this payment for?', context: h(WhyAsking, null, reason), options,
          sequenceStep: { number: 1, state: 'current' },
        })),
      }),
      h('section', { 'data-fixture': 'customer-reply' },
        h(CellReplyQuestion, { stage: 'purpose', answer: {}, choice: '', onSelect: () => {} })),
      card('no-why', {}),
      h('section', { 'data-fixture': 'unchanged-reason' },
        h(MisclassificationCard, { item: findItem('BONREV'), onSelect: () => {} })),
      h('section', { 'data-fixture': 'unchanged-other' },
        h(CardDisclosure, { label: 'Example' }, h('p', null, 'Example content'))),
      ...['ADJ2', 'MISC7', 'SPPAY'].map(id => h('section', { key: id, 'data-fixture': id },
        h(ItemQuestion, { item: findItem(id), label: id, answer: {} }))),
       ...['TIPS', 'TIPS OWED'].map(code => h('section', { key: code, 'data-fixture': code },
         h(TipsQuestions, { code, answer: {}, onEvent: () => { throw new Error('Disclosure must not change answers') } }))),
      ))
      await document.fonts.ready
    })
    await expect(page.locator('[data-fixture="no-why"] .ec-qcard')).toBeVisible()
    await expect(page.locator('[data-fixture="no-why"] details')).toHaveCount(0)
    // Ordinary disclosures have no effective utility padding in this app.
    // Preserve that baseline rather than expanding the selected reason/overtime change.
    for (const id of ['unchanged-reason', 'unchanged-other']) {
      const disclosure = page.locator(`[data-fixture="${id}"] details.mc-card__disclosure`)
      const summary = disclosure.locator('summary')
      for (const open of [false, true]) {
        await disclosure.evaluate((el, value) => { el.open = value }, open)
        assert.deepEqual(await summary.evaluate(el => {
          const style = getComputedStyle(el)
          return [style.paddingTop, style.paddingBottom]
        }), ['0px', '0px'], `${id}: existing vertical padding preserved`)
      }
    }
    for (const id of ['ADJ2', 'MISC7']) {
      const card = page.locator(`[data-fixture="${id}"] .ec-qcard--question-first`)
      const source = card.locator('.ec-register-details')
      const description = card.locator('.ec-qcard__answer > .ec-describe > .inp > .inp__label-row > .inp__label')
      await expect(description).toBeVisible()
      for (const open of [false, true]) {
        await source.evaluate((el, open) => { el.open = open }, open)
        const sourceBounds = await source.boundingBox()
        const descriptionBounds = await description.boundingBox()
        close(descriptionBounds.y - sourceBounds.y - sourceBounds.height, 24,
          `${id}: source-to-description-label gap (${open ? 'expanded' : 'collapsed'})`)
      }
      await source.evaluate(el => { el.open = false })
    }
    const disclosures = page.locator('.mc-card__disclosure--why, details.ec-asking')
    assert.equal(await disclosures.count(), 7, 'Full-width, inline, question-first, follow-up, customer reply and both current tip cards are covered')
    for (const code of ['TIPS', 'TIPS OWED']) {
      const card = page.locator(`[data-fixture="${code}"]`)
      const headerPadding = await card.locator('.mc-card__header').evaluate(el => {
        const style = getComputedStyle(el)
        return [style.paddingTop, style.paddingRight, style.paddingBottom, style.paddingLeft]
      })
      assert.deepEqual(headerPadding, ['40px', '24px', '12px', '24px'],
        `${code}: 24px horizontal inset preserves header vertical padding`)
      const reason = card.locator('.mc-card__disclosure--why')
      await expect(reason).toHaveCount(1)
      await expect(reason.locator('.mc-card__disclosure-content > p')).toHaveCount(3)
      await expect(card.locator('[role="radio"]')).toHaveCount(5)
      if (screenshotDir) await card.screenshot({ path: resolve(screenshotDir, `tips-why-${code.replace(' ', '-')}-${width}-collapsed.png`) })
    }
    for (const disclosure of await disclosures.all()) {
      const summary = disclosure.locator(':scope > summary')
      const body = disclosure.locator(':scope > div')
      const collapsed = await disclosure.boundingBox()
      await expect(disclosure).not.toHaveAttribute('open')
      await expect(body).not.toBeVisible()
      if (await disclosure.evaluate(el => el.classList.contains('mc-card__disclosure--why'))) {
        const collapsedSpacing = await summary.evaluate(el => {
          const label = document.createRange()
          label.selectNodeContents(el)
          return {
            paddingTop: parseFloat(getComputedStyle(el).paddingTop),
            paddingBottom: parseFloat(getComputedStyle(el).paddingBottom),
            belowLabel: el.getBoundingClientRect().bottom - label.getBoundingClientRect().bottom,
          }
        })
        close(collapsedSpacing.paddingTop, 24, 'Collapsed Why top padding')
        close(collapsedSpacing.paddingBottom, 24, 'Collapsed Why bottom padding')
        close(collapsedSpacing.belowLabel, 24, 'Collapsed Why label-to-row-bottom gap')
        if (await disclosure.evaluate(el => Boolean(el.closest('.ec-qcard--question-first')))) {
          const cardBottomGap = await summary.evaluate(el => {
            const label = document.createRange()
            label.selectNodeContents(el)
            return el.closest('.card').getBoundingClientRect().bottom - label.getBoundingClientRect().bottom
          })
          close(cardBottomGap, 24, 'Question-first collapsed gap includes all footer padding')
        }
      }
      // Native keyboard activation and the existing focus ring remain available.
      await summary.focus()
      await page.keyboard.press('Enter')
      await expect(disclosure).toHaveAttribute('open', '')
      if (await disclosure.evaluate(el => el.classList.contains('mc-card__disclosure--why'))) {
        assert.deepEqual(await summary.evaluate(el => {
          const style = getComputedStyle(el)
          return [style.paddingTop, style.paddingBottom]
        }), ['24px', '24px'], 'Expanded Why vertical padding')
      }
      const measurements = await disclosure.evaluate(el => {
        const summary = el.querySelector('summary')
        const body = el.querySelector(':scope > div')
        const first = body.firstElementChild
        const last = body.lastElementChild
        const r = node => node.getBoundingClientRect()
        const style = getComputedStyle(body)
        return {
          full: el.classList.contains('mc-card__disclosure--why'),
          top: (first ? r(first).top : r(body).top + parseFloat(style.paddingTop)) - r(summary).bottom,
          bottom: r(body).bottom - (last ? r(last).bottom : r(body).bottom - parseFloat(style.paddingBottom)),
          paddingTop: parseFloat(style.paddingTop), paddingBottom: parseFloat(style.paddingBottom),
          marginTop: parseFloat(style.marginTop),
          focusWidth: parseFloat(getComputedStyle(summary).outlineWidth),
          left: r(body).left, right: r(body).right,
          paragraphGap: first && first !== last ? r(first.nextElementSibling).top - r(first).bottom : null,
        }
      })
      close(measurements.top, measurements.full ? 8 : 16, 'Rendered label-to-explanation gap')
      close(measurements.bottom, 24, 'Rendered explanation bottom space')
      close(measurements.paddingBottom, 24, 'Bottom padding')
      if (await disclosure.evaluate(el => Boolean(el.closest('.ec-qcard--question-first')))) {
        const expandedCardGap = await body.evaluate(el =>
          el.closest('.card').getBoundingClientRect().bottom - el.lastElementChild.getBoundingClientRect().bottom)
        close(expandedCardGap, 24, 'Question-first expanded gap includes all footer padding')
      }
      close(measurements.marginTop, 0, 'No stacked top margin')
      assert.ok(measurements.focusWidth >= 2, 'Summary retains visible keyboard focus')
      assert.ok(measurements.left >= 0 && measurements.right <= width, 'Explanation fits viewport')
      const tipCode = await disclosure.evaluate(el => el.closest('[data-fixture]')?.getAttribute('data-fixture'))
      if (tipCode === 'TIPS' || tipCode === 'TIPS OWED') {
        const geometry = await body.evaluate(el => ({
          width: el.clientWidth, scrollWidth: el.scrollWidth,
          first: el.querySelector('p').getBoundingClientRect().height,
          second: el.querySelectorAll('p')[1].getBoundingClientRect().height,
        }))
        assert.ok(geometry.scrollWidth <= geometry.width, `${tipCode}: no overflowing reason text`)
        assert.ok(geometry.first > 0 && geometry.second > 0, `${tipCode}: both paragraphs are readable`)
        if (screenshotDir) await page.locator(`[data-fixture="${tipCode}"]`).screenshot({
          path: resolve(screenshotDir, `tips-why-${tipCode.replace(' ', '-')}-${width}-expanded.png`),
        })
      }
      if (measurements.paragraphGap !== null) close(measurements.paragraphGap, 8, 'Paragraph spacing unchanged')
      await page.keyboard.press('Space')
      await expect(disclosure).not.toHaveAttribute('open')
      close((await disclosure.boundingBox()).height, collapsed.height, 'Collapsed height unchanged')
    }
    await expect(page.getByText('Give me an example', { exact: true })).toHaveCount(0)
    await expect(page.locator('.ec-qcard__help, .ec-qcard__inline-help, .ec-qcard__example')).toHaveCount(0)
    await expect(page.locator('[data-fixture="full-width"] details')).toHaveCount(1)
    // Open all reasons for visual inspection; measure full-width horizontal insets.
    await disclosures.evaluateAll(elements => elements.forEach(el => { el.open = true }))
    const insets = await page.locator('[data-fixture="full-width"] .mc-card__disclosure--why').evaluate(el => {
      const summary = getComputedStyle(el.querySelector('summary'))
      const body = getComputedStyle(el.querySelector(':scope > div'))
      return [summary.paddingLeft, body.paddingLeft, summary.paddingRight, body.paddingRight]
    })
    assert.deepEqual(insets, ['24px', '24px', '24px', '24px'], 'Disclosure insets')
    const outerAreas = page.locator('.card.ec-qcard > .card__body, .card.ec-qcard:not(.ec-qcard--question-first) > .card__footer, .ec-qcard--misclassification > .mc-card__header, .ec-qcard--misclassification > .mc-card__response')
    for (const area of await outerAreas.all()) {
      assert.deepEqual(await area.evaluate(el => {
        const style = getComputedStyle(el)
        return [style.paddingLeft, style.paddingRight]
      }), ['24px', '24px'], 'Heading and response use one 24px inset')
    }
    for (const child of await page.locator('.ec-qcard--misclassification > .mc-card__response > :is(.ec-qcard__answer, .ec-qcard__sections)').all()) {
      assert.deepEqual(await child.evaluate(el => {
        const style = getComputedStyle(el)
        return [style.marginLeft, style.marginRight]
      }), ['0px', '0px'], 'Response children do not double the inset')
    }
    assert.ok(await page.locator('[role="radio"]').count() > 0, 'Answer controls remain present')
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false, 'No horizontal overflow')
    if (screenshotDir) await page.screenshot({ path: resolve(screenshotDir, `why-spacing-${width}.png`), fullPage: true })
    assert.deepEqual(errors, [], 'No browser errors')
    console.log(`PASS ${width}px: source-to-description gap, reason spacing, paragraph rhythm, keyboard toggle/focus, collapsed height, insets and no example controls`)
    await page.close()
  }
} finally {
  await browser.close()
}
