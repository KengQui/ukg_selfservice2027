import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { existsSync } from 'node:fs'

const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium } = require('@playwright/test')
const browser = await chromium.launch({ executablePath: existsSync('/repl/tools/bin/chromium') ? '/repl/tools/bin/chromium' : undefined })
try {
  for (const width of [1280, 390]) {
    const page = await browser.newPage({ viewport: { width, height: 1000 } })
    await page.goto(`${process.env.BASE_URL || 'http://localhost:80'}/earning-configuration/`)
    const results = await page.evaluate(async () => {
      const base = '/earning-configuration/src/prototypes/earning-configuration/'
      const [React, client, DOM, { default: StepQuestions }, { SessionContext }, model, { default: QuestionCard }, { ReviewCardPosition }] = await Promise.all([
        import('/earning-configuration/node_modules/.vite/deps/react.js'),
        import('/earning-configuration/node_modules/.vite/deps/react-dom_client.js'),
        import('/earning-configuration/node_modules/.vite/deps/react-dom.js'),
        import(`${base}StepQuestions.tsx`), import(`${base}sessionContext.ts`), import(`${base}session.ts`),
        import(`${base}QuestionCard.tsx`), import(`${base}ReviewCardCounter.tsx`), import(`${base}earningConfig.css`),
      ])
      document.getElementById('root').style.display = 'none'
      const host = document.createElement('div')
      host.className = 'ec-content'
      document.body.append(host)
      const root = client.default.createRoot(host)
      const h = React.default.createElement
      const { flushSync } = DOM.default
      const { default: AppliedReviewQuestions } = await import(`${base}AppliedReviewQuestions.tsx`)
      const session = model.reduceSession(model.createSession(0), { type: 'startReview' }, 1)
      const results = []
      const check = () => {
        for (const counter of host.querySelectorAll('.ec-guide-item:not([hidden]) .ec-review-card-counter, [data-saved] .ec-review-card-counter')) {
          const card = counter.closest('.ec-qcard, .mc-card')
          const rect = counter.getBoundingClientRect()
          const bounds = card.getBoundingClientRect()
          const style = getComputedStyle(card)
          const header = counter.parentElement
          const heading = header.querySelector('h2,h3')
          results.push({
            text: counter.querySelector('[aria-hidden]').textContent,
            top: rect.top - bounds.top - parseFloat(style.borderTopWidth),
            right: bounds.right - rect.right - parseFloat(style.borderRightWidth),
            padding: parseFloat(getComputedStyle(header).paddingRight),
            clear: !heading || heading.getBoundingClientRect().top >= rect.bottom,
          })
        }
      }
      for (let reviewCursor = 0; reviewCursor < model.reviewPages(session).length; reviewCursor++) {
        flushSync(() => root.render(h(SessionContext.Provider, {
          value: { session: { ...session, reviewCursor }, dispatch() {}, save() {}, restart() {} },
        }, h(StepQuestions))))
        check()
        if (host.querySelector('.ec-section-note')) throw new Error('Standalone counter remains')
      }
      for (const cursor of [0, 1, model.reviewPages(session).length - 1]) {
        flushSync(() => root.render(h(SessionContext.Provider, {
          value: { session: { ...session, rounds: [{ ...session.rounds[0], submitted: true, results: { resolved: [], deferred: [], findings: [] } }], appliedReview: { round: 1, cursor } },
            dispatch() {}, save() {}, restart() {} },
        }, h(AppliedReviewQuestions))))
        if (!host.querySelector('.ec-review-card-counter')) throw new Error('Saved review is missing its counter')
        if (host.querySelector('.ec-section-note')) throw new Error('Saved standalone counter remains')
        check()
      }
      // Saved/read-only rendering, with a multi-digit dynamic count.
      flushSync(() => root.render(h('div', { 'data-saved': true },
        h(ReviewCardPosition.Provider, { value: { current: 12, total: 15 } },
          h(QuestionCard, { label: 'saved', question: 'Saved payment answer', answered: true, disabled: true, answer: 'Earlier answer' })))))
      check()
      const empty = { ...session, rounds: [{ ...session.rounds[0], itemIds: [] }] }
      flushSync(() => root.render(h(SessionContext.Provider, { value: { session: empty, dispatch() {}, save() {}, restart() {} } }, h(StepQuestions))))
      if (host.querySelector('.ec-review-card-counter')) throw new Error('Empty state has a counter')
      root.unmount()
      host.remove()
      return results
    })
    assert.ok(results.length > 10)
    for (const result of results) {
      assert.ok(Math.abs(result.top - 24) < 1, JSON.stringify(result))
      assert.ok(Math.abs(result.right - result.padding) < 1, JSON.stringify(result))
      assert.ok(result.clear, JSON.stringify(result))
      assert.match(result.text, /^\d+\/\d+$/)
    }
    console.log(`${width}px: ${results.length} card counters passed spacing and overlap checks`)
    await page.close()
  }
} finally {
  await browser.close()
}
