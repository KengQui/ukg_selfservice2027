// Real tip-card geometry with deterministic checked evidence, without calling live AI.
// TIP_LAYOUT_SCREENSHOTS=/tmp/tip-layout node scripts/check-tips-payment-layout.mjs
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { existsSync, mkdirSync } from 'node:fs'
import { resolve } from 'node:path'

const require = createRequire(new URL('../../ready-dls-kit/package.json', import.meta.url))
const { chromium, expect } = require('@playwright/test')
const browser = await chromium.launch({
  executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH ||
    (existsSync('/repl/tools/bin/chromium') ? '/repl/tools/bin/chromium' : undefined),
})
const screenshots = process.env.TIP_LAYOUT_SCREENSHOTS
if (screenshots) mkdirSync(screenshots, { recursive: true })
try {
  for (const width of [1280, 390]) {
    const page = await browser.newPage({ viewport: { width, height: 1000 } })
    const errors = []
    page.on('pageerror', error => errors.push(error.message))
    for (const code of ['TIPS', 'TIPS OWED']) {
      for (const complete of [false, true]) {
        await page.goto(new URL('/earning-configuration/', process.env.BASE_URL || 'http://localhost:80').href)
        await page.evaluate(async ({ code, complete }) => {
          const base = '/earning-configuration/src/prototypes/earning-configuration/'
          const [ReactModule, ReactDOMModule, { MemoryRouter }, { SessionContext }, { createSession, reduceSession },
            { reduceTips, tipsBasis }, { paymentRequest }, { ItemQuestion }, { findItem }] = await Promise.all([
            import('/earning-configuration/node_modules/.vite/deps/react.js'),
            import('/earning-configuration/node_modules/.vite/deps/react-dom_client.js'),
            import('/earning-configuration/node_modules/.vite/deps/react-router-dom.js'),
            import(`${base}sessionContext.ts`), import(`${base}session.ts`), import(`${base}tipsFlow.ts`),
            import(`${base}paymentEvidence.ts`), import(`${base}StepQuestions.tsx`), import(`${base}sampleRegister.ts`),
            import(`${base}earningConfig.css`),
          ])
          const React = ReactModule.default
          const { createRoot } = ReactDOMModule.default
          const h = React.createElement
          let answer = reduceTips({}, { kind: 'answer', id: 'opening', value: 'already-received' }, code)
          answer = reduceTips(answer, { kind: 'checked', basis: tipsBasis(answer, code), result: {
            outcome: 'question', question: 'How did your team receive these tips?', options: null,
            reason: 'The payment path helps us find a setup.', rollUp: null, splitReview: false,
          } }, code)
          answer = reduceTips(answer, { kind: 'answer', id: 'follow-up-1', value: 'Our team received cash directly from customers.' }, code)
          answer = reduceTips(answer, { kind: 'checked', basis: tipsBasis(answer, code), result: {
            outcome: 'recommendation', question: null, options: null,
            reason: 'These tips have already been received.', rollUp: 'Cash Tips', splitReview: false,
          } }, code)
          let session = { ...createSession(0), step: 'questions', answers: { [code]: answer },
            rounds: [{ number: 2, itemIds: [code], submitted: false }] }
          let request = paymentRequest(session, code)
          session = reduceSession(session, { type: 'setPaymentFacts', itemId: code, basis: request.checkBasis, result: { facts: [] } })
          if (complete) {
            session = reduceSession(session, { type: 'answerPaymentFact', itemId: code, key: 'voluntaryPassThrough', state: 'yes',
              text: 'All amounts under this code are optional tips from customers, rather than required service charges.' })
            request = paymentRequest(session, code)
            session = reduceSession(session, { type: 'setPaymentFacts', itemId: code, basis: request.checkBasis, result: { facts: [] } })
          }
          document.getElementById('root').style.display = 'none'
          const host = document.createElement('main')
          host.id = 'tip-layout-fixture'
          host.className = 'ec-content'
          host.style.cssText = 'max-width:800px;margin:auto;padding:16px;box-sizing:border-box'
          document.body.append(host)
          createRoot(host).render(h(MemoryRouter, null, h(SessionContext.Provider, {
            value: { session, dispatch: () => {}, save: () => true, restart: () => true },
          }, h(ItemQuestion, { item: findItem(code), label: code, answer }))))
          await document.fonts.ready
        }, { code, complete })
        const fixture = page.locator('#tip-layout-fixture')
        await expect(fixture.locator('.ec-qcard')).toBeVisible()
        await expect(fixture.getByRole('group', { name: 'Follow up questions', exact: true })).toHaveCount(1)
        assert.deepEqual(await fixture.locator('[data-sequence-number]').evaluateAll(nodes => nodes.map(node => node.dataset.sequenceNumber)), ['01', '02'])
        await expect(fixture.getByText(/Suggested:|tip credit|Review this suggestion/)).toHaveCount(0)
        await expect(fixture.getByRole('region', { name: `${code} summary`, exact: true })).toHaveCount(complete ? 1 : 0)
        if (complete) {
          assert.equal(await fixture.locator('.ec-setup-summary').evaluate(el => Boolean(
            !el.closest('.ec-qcard__sequence') &&
            el.compareDocumentPosition(document.querySelector('[data-sequence-number="02"]')) & Node.DOCUMENT_POSITION_PRECEDING,
          )), true)
        } else {
          await expect(fixture.getByText(`Are all amounts reported under ${code} optional tips from customers, rather than required service charges?`, { exact: true })).toBeVisible()
        }
        const overflow = await fixture.evaluate(el => ({ width: el.clientWidth, scroll: el.scrollWidth }))
        assert.ok(overflow.scroll <= overflow.width + 1, `${code}, ${width}: no horizontal overflow`)
        if (screenshots) await fixture.screenshot({ path: resolve(screenshots, `${code.replaceAll(' ', '-')}-${width}-${complete ? 'summary' : 'question'}.png`) })
      }
    }
    assert.deepEqual(errors, [], `${width}: no browser errors`)
    await page.close()
  }
  console.log('Tip payment layout passed for TIPS and TIPS OWED at 1280px and 390px.')
} finally {
  await browser.close()
}
