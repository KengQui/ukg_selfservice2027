# Deferred review verification

Verified October 14, 2026 on the actual `/earning-configuration/` route.

## Current contract

- One card-level Defer targets the first unanswered question, including a follow-up. It stores the
  original stage/target and original option IDs; its placement does not make the parent its target.
- Only explicitly selected current questions appear as discussion requests. Earlier answers,
  reasons, source evidence and discussion history are collapsed, read-only context.
- Capture, notes, supporting AI summaries, saving and preparing a preview do not apply setup.
  The separate preview requires explicit Apply answers, using a current evidence/response basis.
- New questions retain their actual owner. Required questions need an answer or explicit Defer.
  Pending work or unapplied answers blocks optimization even with the demo bypass on.
- A custom name accepted for a checked, clear purpose does not establish a Ready reference,
  tax treatment, combine compatibility or overtime rule.
- Historical selections without reliable answer targets remain history; no target is guessed.
  No sent-email record or customer reply is fabricated to apply discussion answers.

## Executed automated checks

Passed:

```sh
pnpm --filter @workspace/earning-configuration run typecheck
pnpm --filter @workspace/api-server run typecheck
pnpm --filter @workspace/setup-shared run typecheck
pnpm exec tsc -b lib/api-client-react lib/api-zod lib/setup-shared
node --test artifacts/api-server/src/routes/earningDiscussionSummary.test.mjs
pnpm --filter @workspace/earning-configuration exec vitest run --config vitest.config.ts \
  src/prototypes/earning-configuration/deferredReview.spec.ts \
  src/prototypes/earning-configuration/reviewDiscussionChoices.spec.tsx \
  src/prototypes/earning-configuration/discussionContext.spec.tsx \
  src/prototypes/earning-configuration/discussionAnswers.spec.tsx \
  src/presentation/question-pipeline/pipeline.spec.tsx
```

The final focused app run passed 71 tests across five files, including two setup-review
regressions covering the completion-check finding described below. The API run passed six tests
(including its parent test): validated input/output, shared-plus-process prompts, redaction on
both sides, untrusted-source framing, correction limits, documented errors and rate limits.
The API contract was regenerated with `pnpm --filter @workspace/api-spec run codegen`.

Focused model coverage includes exact targeting; blank/uncertain/stale inputs; unrelated versus
relevant summary invalidation; late summary rejection; no summary without earlier answers;
atomic, idempotent Apply; original-fact retention; separately owned TIPS RPT work and Defer;
custom-name purpose acceptance; unknown overtime facts; draft/preview restoration; blocked
storage; stale preview rejection; and strict navigation with the demo switch enabled.
Scripted AI results in those unit tests are explicit test fixtures, not runtime substitutes.

Scoped strict copy checks passed for the changed discussion/preview/work screens, supporting
summary, exit handling and pipeline presentation. The approved boundaries popup was not edited.

## Executed browser journeys

One browser test pass, resumed after a mistaken assumption about the single-Defer control:

- **BONREV:** required original question blocked Apply until answer/Defer. Real Defer opened one
  unchecked acknowledgement. Notes alone did not enable preview. Preview Back retained response
  and note. Explicit Apply created one receipt without sent/reply history; refresh retained one
  receipt and exposed Continue to optimization.
- **TIPS:** real Defer stored the exact pool-method follow-up and `tips-method` target while
  retaining the parent pool answer. The real summary endpoint returned HTTP 200. Selecting Both
  proposed a separately owned TIPS RPT question and withheld Apply until it was answered.
  Original Add then Finish and Apply retained the parent, resolved both owners and did not
  automatically enter optimization.
- **Special Pay:** the open-ended deferred question retained its Answer field and did not
  manufacture an AI summary without earlier answers. A fictional bilingual-service payment used
  the live description-check and naming endpoints (both HTTP 200). The accepted Bilingual name
  showed honest unverified-fact boundaries. Underlying setup before Apply compared equal.
  Explicit Apply retained the purpose and live results; the read-only receipt survived save/return.
- **Saving/exits:** partial response plus notes, complete-but-unapplied preview and applied receipt
  survived Save and finish later and return through Company Setup. A one-shot saved-storage failure
  retained the page and fields with Retry; Retry saved successfully. Keep reviewing preserved the
  draft, Save and leave saved it, and Leave without saving restored the earlier explicit save.
- **Narrow/keyboard:** the applied screen fit 390 × 844; keyboard focus on Back had a visible outline.

The initial narrow pipeline check found page overflow from an intrinsic-width nested grid.
After correction, this targeted supporting check passed:

```sh
node artifacts/earning-configuration/scripts/check-selected-deferrals.mjs --supporting-only
```

It verified saved-only preview reopening after removing the working copy, original selected
answer restoration, the seven-point boundaries dialog without setup changes, and the expanded
pipeline/text branch at 390 and 1366 pixels with keyboard disclosure control and no page overflow.
The script's default mode is the repeatable BONREV regression journey; the supporting-only mode
was used after the already executed browser journey, rather than rerunning it.

Delayed stale-summary transport was not separately driven in the browser. Stale-basis rejection
and capture/cache independence were executed in the model suite; the browser used a real summary.

## Broader-suite boundary

The app's full historical suite is not green on the unchanged baseline: an isolated baseline run
reported 360 failures and 924 passes. Baseline uncertain-match and overtime-demo suites alone
reported 26 failures and six passes. An early, pre-final full working-tree run reported 420 failures;
it is not a final result. Later verification was scoped to the changed behavior above, not claimed
as a passing whole-app run. Older fixtures that choose a generic waiting value without an exact
Defer selection no longer satisfy required navigation; no fake selections were added to runtime
storage to make those fixtures pass. Unrelated broad-suite cleanup remains out of scope.

Both managed workflows restarted cleanly. No deployment or live payroll change was made.

## Unconfirmed setup-review continuation

The completion check identified a navigation dead end for a completed Something else answer
stored as an unconfirmed setup note. Review setup decisions now opens a separate owning-question
proposal, with the earlier note in read-only history and the applied setup unchanged. A supported
answer leads through preview and explicit Apply to optimization. An actual Defer click instead
creates the current discussion request; a status alone never does.

Two added model checks passed: completed Something else → owning proposal → saved-only preview →
Apply → optimization, with the earlier round intact; and restored unconfirmed work → actual
question-level Defer → discussion, still blocked from optimization. Repeated Apply remains a no-op.
The focused browser regression `scripts/check-setup-review.mjs` also passed against the actual
route: saved-only initial restore, visible owning controls, unchanged answers/resolutions before
Apply, explicit save and Company Setup exit, saved-only preview restore, editable Back, narrow
layout, keyboard Finish, explicit Apply, visible optimization continuation and one receipt after
refresh. This was a targeted confirmation of the correction, not another full browser pass.
