import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import App from './App'
import * as storage from './prototypes/earning-configuration/storage'
import { createSession, reduceSession } from './prototypes/earning-configuration/session'

const bryte = vi.hoisted(() => ({ mounted: vi.fn() }))
vi.mock('@workspace/setup-shared/ask-bryte', async importOriginal => {
  const actual = await importOriginal<typeof import('@workspace/setup-shared/ask-bryte')>()
  return {
    ...actual,
    AskBryteProvider: (props: React.ComponentProps<typeof actual.AskBryteProvider>) => {
      bryte.mounted()
      return <actual.AskBryteProvider {...props} />
    },
  }
})

let base: string
let path: string
const ids = ['why-we-ask', 'pipeline', 'three-reasons', 'ai-and-rules', 'finding-to-question', 'examples', 'after-the-answer']
let host: HTMLDivElement
let root: Root

beforeEach(() => {
  (globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
  vi.stubEnv('BASE_URL', '/earning-configuration/')
  base = import.meta.env.BASE_URL.replace(/\/$/, '')
  path = `${base}/presentation/question-pipeline`
  localStorage.clear()
  sessionStorage.clear()
  bryte.mounted.mockClear()
  vi.spyOn(window, 'scrollTo').mockImplementation(() => {})
  vi.spyOn(storage, 'loadSession')
  vi.spyOn(storage, 'writeWorkingCopy')
  vi.spyOn(storage, 'saveSession')
  vi.spyOn(storage, 'clearSessions')
  vi.stubGlobal('fetch', vi.fn(() => { throw new Error('Presentation must not call an API') }))
  host = document.createElement('div')
  document.body.append(host)
  root = createRoot(host)
})

afterEach(() => {
  act(() => root.unmount())
  host.remove()
  localStorage.clear()
  sessionStorage.clear()
  vi.restoreAllMocks()
  vi.unstubAllGlobals()
  vi.unstubAllEnvs()
})

async function renderApp() {
  await act(async () => { root.render(<App />) })
  // The setup route used by the language-link test has a nested phase boundary.
  for (let boundary = 0; boundary < 2; boundary++) {
    await act(async () => { await vi.dynamicImportSettled() })
  }
}

async function mount(hash = '') {
  window.history.replaceState({}, '', `${path}${hash}`)
  await renderApp()
}

function button(label: string) {
  const found = [...host.querySelectorAll('button')].find(b => b.textContent?.trim() === label)
  expect(found, label).toBeDefined()
  return found!
}

function click(label: string) {
  act(() => button(label).click())
}

function key(value: string, extra: KeyboardEventInit = {}, target: EventTarget = window) {
  const event = new KeyboardEvent('keydown', { key: value, bubbles: true, cancelable: true, ...extra })
  act(() => target.dispatchEvent(event))
  return event
}

function expectPosition(n: number) {
  expect(host.querySelector('[data-testid="text-section-position"]')?.textContent).toBe(`Section ${n} of 7`)
  const index = host.querySelectorAll('nav[aria-label="Presentation sections"] button')
  expect(index).toHaveLength(7)
  expect([...index].filter(b => b.getAttribute('aria-current') === 'step')).toEqual([index[n - 1]])
}

function expectNoWorkflow() {
  expect(storage.loadSession).not.toHaveBeenCalled()
  expect(storage.writeWorkingCopy).not.toHaveBeenCalled()
  expect(storage.saveSession).not.toHaveBeenCalled()
  expect(storage.clearSessions).not.toHaveBeenCalled()
  expect(bryte.mounted).not.toHaveBeenCalled()
  expect(fetch).not.toHaveBeenCalled()
  expect(host.querySelector('.cshell__header-area')).toBeNull()
  expect(host.querySelector('[data-ask-bryte-launcher]')).toBeNull()
  expect(host.querySelector('nav[aria-label="Project navigation"]')).toBeNull()
  expect(host.querySelectorAll('main')).toHaveLength(1)
}

function snapshot(store: Storage) {
  return Object.fromEntries(Object.keys(store).sort().map(k => [k, store.getItem(k)]))
}

describe('question pipeline presentation', () => {
  it('opens from English (US) in a new tab without changing the current review or progress', async () => {
    vi.stubGlobal('matchMedia', vi.fn((query: string) => ({
      matches: false, media: query, onchange: null,
      addListener: vi.fn(), removeListener: vi.fn(),
      addEventListener: vi.fn(), removeEventListener: vi.fn(), dispatchEvent: vi.fn(),
    })))
    const open = vi.spyOn(window, 'open').mockReturnValue(null)
    const sample = reduceSession(createSession(100), { type: 'startReview' }, 200)
    sessionStorage.setItem(storage.WORKING_COPY_KEY, JSON.stringify(sample))
    window.history.replaceState({}, '', `${base}/`)
    await renderApp()
    const before = { saved: snapshot(localStorage), working: snapshot(sessionStorage) }
    const language = host.querySelector<HTMLButtonElement>('button[aria-label="Language: English (US)"]')
    expect(language).not.toBeNull()
    act(() => language!.click())
    expect(open).toHaveBeenCalledWith(path, '_blank', 'noopener,noreferrer')
    expect(window.location.pathname).toBe(`${base}/`)
    expect({ saved: snapshot(localStorage), working: snapshot(sessionStorage) }).toEqual(before)
    expect(storage.saveSession).not.toHaveBeenCalled()
    expect(storage.clearSessions).not.toHaveBeenCalled()
  })

  it.each(['empty', 'working', 'saved', 'both', 'legacy'])('does not initialize or mutate %s progress on direct load, walkthrough or reload', async mode => {
    let sample = reduceSession(createSession(100), { type: 'startReview' }, 200)
    sample = reduceSession(sample, { type: 'choose', itemId: 'MISC7', choice: 'ask-customer' }, 300)
    sample = {
      ...sample, reviewCursor: 1, files: [{ id: 'test-file', name: 'pay-register.csv', sizeBytes: 120, docType: 'pay-register' }],
    }
    if (mode === 'working' || mode === 'both') sessionStorage.setItem(storage.WORKING_COPY_KEY, JSON.stringify(sample))
    if (mode === 'saved' || mode === 'both') localStorage.setItem(storage.SAVED_COPY_KEY, JSON.stringify({ ...sample, updatedAt: 400, reviewCursor: 2 }))
    // Opaque older envelopes prove the route cannot normalize or migrate a stored copy.
    if (mode === 'legacy') {
      localStorage.setItem(storage.SAVED_COPY_KEY, '{"version":1,"answers":{"BONREV":{"choice":"ask-customer"}}}')
      sessionStorage.setItem(storage.WORKING_COPY_KEY, '{"version":2,"reviewCursor":4,"files":[{"id":"old"}]}')
    }
    localStorage.setItem('unrelated-setup', 'keep saved content')
    sessionStorage.setItem('unrelated-setup', 'keep working content')
    const before = { saved: snapshot(localStorage), working: snapshot(sessionStorage) }
    await mount()
    expectPosition(1)
    for (let n = 2; n <= 7; n++) {
      click('Next')
      expectPosition(n)
      for (const summary of host.querySelectorAll('summary')) act(() => summary.click())
    }
    for (let n = 6; n >= 1; n--) {
      click('Back')
      expectPosition(n)
    }
    expectNoWorkflow()
    expect({ saved: snapshot(localStorage), working: snapshot(sessionStorage) }).toEqual(before)
    act(() => root.unmount())
    root = createRoot(host)
    await mount('#examples')
    expectPosition(6)
    expectNoWorkflow()
    expect({ saved: snapshot(localStorage), working: snapshot(sessionStorage) }).toEqual(before)
  })

  it.each(ids)('supports a direct section link and fresh mount at #%s', async id => {
    await mount(`#${id}`)
    expectPosition(ids.indexOf(id) + 1)
    act(() => root.unmount())
    root = createRoot(host)
    await renderApp()
    expectPosition(ids.indexOf(id) + 1)
    expect(window.location.pathname).toBe(path)
  })

  it('uses manual controls, keeps focus on the section heading and clamps at both ends', async () => {
    await mount()
    expect(button('Back').disabled).toBe(true)
    expect(button('Next').disabled).toBe(false)
    click('Next')
    expectPosition(2)
    expect(document.activeElement).toBe(host.querySelector('h1'))
    expect(window.location.hash).toBe('#pipeline')
    key('ArrowRight')
    expectPosition(3)
    key('PageDown')
    expectPosition(4)
    key('ArrowLeft')
    expectPosition(3)
    key('PageUp')
    expectPosition(2)
    key('End')
    expectPosition(7)
    expect(button('Next').disabled).toBe(true)
    key('ArrowRight')
    expectPosition(7)
    key('Home')
    expectPosition(1)
    key('ArrowLeft')
    expectPosition(1)
    const index = host.querySelectorAll<HTMLButtonElement>('nav[aria-label="Presentation sections"] button')
    act(() => index[4].click())
    expectPosition(5)
    expect(document.activeElement).toBe(host.querySelector('h1'))
  })

  it('does not capture modified shortcuts or editing keys', async () => {
    await mount()
    for (const modifier of ['altKey', 'ctrlKey', 'metaKey', 'shiftKey']) {
      expect(key('ArrowRight', { [modifier]: true }).defaultPrevented).toBe(false)
      expectPosition(1)
    }
    for (const tag of ['input', 'textarea', 'select']) {
      const input = document.createElement(tag)
      host.append(input)
      expect(key('End', {}, input).defaultPrevented).toBe(false)
      expectPosition(1)
      input.remove()
    }
    expect(key('Tab').defaultPrevented).toBe(false)
    click('Next')
    const diagram = host.querySelector('.qp-diagram__scroll')
    expect(diagram).not.toBeNull()
    expect(key('ArrowRight', {}, diagram!).defaultPrevented).toBe(false)
    expectPosition(2)
  })

  it('follows hash changes, defaults unknown hashes and restores the page title', async () => {
    document.title = 'Previous page'
    const robots = document.createElement('meta')
    robots.name = 'robots'
    robots.content = 'index, follow'
    document.head.append(robots)
    await mount('#unknown')
    expectPosition(1)
    expect(document.title).toBe('How questions surface · Earning Configuration')
    expect(robots.content).toBe('noindex, nofollow')
    expect(document.querySelector('meta[property="og:title"]')?.getAttribute('content')).toBe(document.title)
    window.history.replaceState({}, '', `${path}#after-the-answer`)
    act(() => window.dispatchEvent(new HashChangeEvent('hashchange')))
    expectPosition(7)
    act(() => root.unmount())
    expect(document.title).toBe('Previous page')
    expect(robots.content).toBe('index, follow')
    expect(document.querySelector('meta[property="og:title"]')).toBeNull()
    robots.remove()
    root = createRoot(host)
  })
})