/**
 * What Bryte knows about each Earning Configuration phase: name, purpose, what's on screen, current
 * state, welcome and suggested questions. The flow registers one page key and its facts
 * (prototypes/earning-configuration/bryteFacts.ts); everything Bryte reads lives here, so voice passes
 * edit this file rather than the phase screens.
 *
 * Readers are implementation teams, so every page uses the Experienced register: concise, with
 * industry names alongside plain ones. "Your team" is the implementation team; the customer's workers
 * are "employees". Never put employee names or counts, pay amounts, uploaded file names or contents,
 * or the customer's contact details or replies in these descriptions.
 */
import type { AskBryteFacts, AskBrytePageDescriber } from '@workspace/setup-shared/ask-bryte'
import type { EarningBrytePage } from './prototypes/earning-configuration/bryteFacts'
import { PLAN_LATER_QUESTION } from './prototypes/earning-configuration/answerReviewData'
import { reviewLaterCopy } from './prototypes/earning-configuration/reviewLaterCopy'

const count = (value: unknown) => Math.max(0, Number(value) || 0)
const text = (value: unknown) => (typeof value === 'string' ? value.trim() : '')
const entries = (value: unknown) => text(value).split('\n').map(entry => entry.trim()).filter(Boolean)
const plural = (value: number, one: string, many = `${one}s`) => `${value} ${value === 1 ? one : many}`
/** A labeled line, or nothing when the value is empty. */
const labeled = (label: string, value: unknown) => (text(value) ? [`${label}: ${text(value)}`] : [])
/** One labeled line per entry of a newline-joined fact. */
const each = (label: string, value: unknown) => entries(value).map(entry => `${label}: ${entry}`)
/** Pack short results without dropping code facts or exceeding Bryte's per-line budget. */
const compactEach = (label: string, value: unknown) => entries(value).reduce<string[]>((lines, entry) => {
  const last = lines.at(-1)
  if (last && last.length + entry.length + 2 <= 200) lines[lines.length - 1] = `${last}; ${entry}`
  else lines.push(`${label}: ${entry}`)
  return lines
}, [])

/** Overtime stays within the helper's line budget; open items come first so none reads as confirmed. */
function regularRateState(facts: AskBryteFacts, detailed = false, pageOnly = false): string[] {
  if (facts.included === undefined) return []
  return [
    ...(facts.needsAnswerCodes !== undefined && !text(facts.unresolvedSuggestions) ? [
      ...compactEach(`Needs your answer (${count(facts.needsAnswerCount)} exact code labels)`, facts.needsAnswerCodes || 'None'),
      ...compactEach(`Needs setup team review (${count(facts.needsTeamCount)} exact code labels)`, facts.needsTeamCodes || 'None'),
      ...compactEach(`Already placed, underlying setup open (${count(facts.selectedSetupCount)} exact code labels)`, facts.placedSetupOpenCodes || 'None'),
    ] : []),
    ...compactEach('Awaiting regular-rate review', facts.awaitingBrief),
    ...compactEach('Advice only', entries(facts.unresolvedSuggestions).map(line => line.split('; decision open.')[0] + '; open').join('\n')),
    `Regular-rate review: ${count(facts.included)} included, ${count(facts.excluded)} excluded; open: ${count(facts.needsAnswerCount)} customer, ${count(facts.needsTeamCount)} team; ${count(facts.selectedSetupCount)} placed/setup open.${pageOnly ? '' : ' TIPS and TIPS OWED are different exact code labels; groups are separate.'}`,
    ...compactEach('Customer-selected treatment', facts.customerTreatments),
    ...(detailed ? (text(facts.unresolvedSuggestions) ? [] : compactEach('Recommendation', facts.recommendationGroups)) : [
      ...compactEach('Include', text(facts.include).split(', ').join('\n')),
      ...compactEach('Exclude', text(facts.exclude).split(', ').join('\n')),
      ...compactEach('Changed by you', facts.corrections),
    ]),
    ...(!pageOnly ? compactEach('Overtime payment reference', facts.paymentCodes) : []),
  ]
}

function cellState(facts: AskBryteFacts): string[] {
  return [
    // Until a purpose is chosen, tax isn't set; say why CELL is asked about instead.
    ...(!text(facts.cellPurpose) ? []
      : ['Not answered', 'Deferred'].includes(text(facts.cellPurpose)) && text(facts.cellBasis)
        ? [`How the company pays CELL: ${text(facts.cellPurpose)}. ${text(facts.cellBasis)}`]
        : [`How the company pays CELL: ${text(facts.cellPurpose)}; tax: ${text(facts.cellTreatment)}`]),
    ...(text(facts.cellSetup) ? [`CELL setup: ${text(facts.cellSetup)}${text(facts.cellOpenQuestion) ? `. Still to confirm: ${text(facts.cellOpenQuestion)}` : ''}`] : []),
  ]
}

/**
 * MILEAGE's pick and, when the company pays per mile, the per-mile rate and how it compares with the IRS rate. The rate
 * is the company's mileage policy as your team entered it, not an employee's pay, so it's the one amount Bryte reads.
 */
function mileageState(facts: AskBryteFacts): string[] {
  if (!text(facts.mileageAnswer)) return []
  return [
    `MILEAGE answer (How does the company pay MILEAGE?): ${text(facts.mileageAnswer)}`,
    ...labeled('MILEAGE setup', facts.mileageSetup),
    ...labeled('MILEAGE rules', facts.mileageBasis),
    ...labeled('Reimbursement facts and pending decisions', facts.reimbursementDecisions),
  ]
}

/** On the summary, MILEAGE's pick, rate, IRS comparison and setup share one line: the page has no room for more. */
function mileageSummaryState(facts: AskBryteFacts): string[] {
  if (!text(facts.mileageAnswer)) return []
  const setup = text(facts.mileageSetup).replace(/^MILEAGE: /, '').replace('; MILEAGE TX raised for the taxable part', ', plus MILEAGE TX')
  return [`MILEAGE: ${text(facts.mileageAnswer)}${setup ? `. Setup: ${setup}` : ''}`]
}
/** The question stepper and count stay local; View codes is shared by the review screens. */
const statusLine = (facts: AskBryteFacts) =>
  `Left stepper: ${count(facts.pages)} pages, page ${count(facts.page)} current; finished and reachable pages are links. Under the heading: ${count(facts.deferredCount)} deferred. View codes is above the review`
/**
 * Every fixed question on the review pages ends with Something else, except Misclassified cards (Ready rules) and MED's
 * plan question (its No already describes). CELL's purpose, SPPAY's purpose and the same-pay question keep their own.
 * What each code's Something else answer says reaches Bryte through its decision line.
 */
const SOMETHING_ELSE_ON_SCREEN = 'Questions generally end with Something else, for when no listed answer is true (Defer is for not sure). GTL has three continuation choices; only an unclear payroll purpose opens its four-choice clarification with Something else and I’m not sure. GTL details stay for review without guessing a purpose. Other Something else descriptions get an AI review after Done, and the code awaits setup review'
const SOMETHING_ELSE_UNIDENTIFIED = 'Follow-ups, Keep or remove and Use ‘…’ questions end with Something else. After Done it gets an AI review, and the code awaits setup review: not kept, removed or given a Ready reference or name'
/** Current Tips discovery and fixed taxable-benefit questions, filtered to the codes on the page. */
const TIPS_PAGE_ON_SCREEN = [
  'TIPS starts We identified TIPS as a tip code. How does your company handle these tips? Choose paycheck payment, tips already received, both, unsure or Something else. Relevant follow-ups are AI-led; earlier saved fixed questions keep their original meaning.',
  'GTL asks whether your company will continue providing group-term life insurance after moving to UKG Ready. Yes plans inclusion. No asks when it ends, then about final amounts only if it ends before Ready. Temporary continuation or final amounts retain it for processing; no final amounts excludes it from planned active earnings. Not sure or Defer keeps review open and allows progress.',
  'GTL asks what the payroll amount represents only when source evidence leaves its purpose unclear: company-paid coverage, taxable value, Something else, or I’m not sure. The sample GTL has no description and is under deductions, so its purpose is unclear. Employer premiums are not taxable benefit value. Discovery completion needs the active decisions and applicable purpose, not completed payroll or benefit setup. Never ask funding, plan conditions, coverage, enrollment or calculation questions here.',
  'GTL purpose choices cannot override explicit employee-paid premiums or mixed benefit identities such as life insurance or disability. Keep those sources in review and describe uncertain identities conditionally, not as identified group-term life insurance.',
  'IMP INC asks What benefit does IMP INC add to pay? Its first two answers are We pay for health coverage for someone who isn’t a dependent, and We let employees drive a company car for personal use',
  'IMP INC’s third answer, We give another benefit that isn’t cash, has its own general setup. Something else still comes after it',
  'IMP INC and GTL have illustrative examples, not company figures. GTL keeps its approved coverage example and note that taxable income is not $50,000, with exactly three opening choices. Nothing is preselected; names alone don’t prove meaning',
  'Why we’re asking: paycheck tips add to take-home pay; some non-cash benefits may create taxable income. A life-insurance premium is not automatically taxable benefit value. No GTL answer verifies tax treatment or creates or changes a payroll code.',
  'TIPS shows a read-only Summary after the current check. Current separate-code proposals on editable TIPS and TIPS OWED reviews also offer Set up new code and Do it later. New-code setup is not available here yet; both actions keep the proposal pending and answers intact without changing payroll. A validated single treatment can finish review without another acknowledgment; mixed or uncertain treatments stay pending. No automatic TIPS RPT. Individual answer edits and Clear all answers remain available on editable cards; Save answer and Apply answers are still separate actions.',
]
const SOMETHING_ELSE_FINDING = 'Each finding ends with Something else. After Done it gets an AI review, the finding isn’t added, and the description goes to the setup team’s review. Another pick or Defer clears it'

const STATUS_PANEL = 'View codes opens Code status for the whole review without changing answers. It separates question progress, proposed choices and setup outcomes, keeps original codes with related outputs, and lists open customer questions. Code links appear only in editable question rounds and follow review reachability.'

function roundState(facts: AskBryteFacts): string[] {
  return [
    // Answered placeholders repeat the decision lines and can crowd out answers on a merged topic.
    ...each('Question on screen', facts.questionsInView).filter(line => !line.endsWith(': answered')),
    ...each('Follow-up question', facts.relatedQuestions),
    ...each('TIPS payment question', facts.tipsPaymentQuestion),
    ...each('TIPS answer', facts.tipsPaymentAnswer),
    ...each('TIPS setup rule', facts.tipsPaymentRule),
    ...labeled('TIPS check', facts.tipsAIReview),
    ...labeled('TIPS proposal boundary', facts.tipsVerification),
    ...each('Tip code review', facts.tipCodeReviews),
    ...labeled('Separate tip codes', facts.tipCodeBoundary),
    `Round ${count(facts.round)}: ${count(facts.answered)} of ${count(facts.total)} answered`,
    `Counted once per source: ${count(facts.earningCodes)} earning codes; ${count(facts.benefitPlans)} benefit plans. Answers remain proposals until Apply answers; no payroll changes.`,
    ...(text(facts.category) ? [`${text(facts.category)} · ${count(facts.page)} of ${count(facts.pages)} pages${text(facts.topic) ? ` · ${text(facts.topic)}` : ''}`] : []),
    ...entries(facts.groups),
    ...(text(facts.category) ? labeled('Codes on this page', facts.codesInView) : []),
    ...(text(facts.current) ? [`Code in view: ${text(facts.current)}`] : []),
    ...(text(facts.openItems) ? [`Still open on this page: ${text(facts.openItems)}`]
      : [text(facts.category)
        ? 'Every code on this page is answered; Apply answers also needs every other page settled'
        : 'Every code is answered, so Apply answers is on at the last code']),
    ...each('Decision', facts.decisions),
    ...each('Answer in the company’s words', facts.practiceAnswers),
    ...each('AI review of a typed answer', facts.answerReviewsInView),
    ...each('Purpose to confirm', facts.uncertainMatches),
    ...cellState(facts),
      ...mileageState(facts),
  ]
}

function optimizationState(facts: AskBryteFacts): string[] {
  return [
    `Answered: ${count(facts.answered)} of ${count(facts.total)} suggestions`,
    `Accepted ${count(facts.accepted)}, kept as is ${count(facts.kept)}, deferred ${count(facts.customer)}, Something else ${count(facts.described)}`,
    `Codes to set up after optimization: ${count(facts.codesToSetUp)}${count(facts.leftOut) ? `, ${count(facts.leftOut)} left out` : ''}`,
    ...each('Decision', facts.decisions),
  ]
}

function overtimeReason(facts: AskBryteFacts): string[] {
  return text(facts.appliesBecause) ? [`Weighted average overtime applies because ${text(facts.appliesBecause)}`] : []
}

const OPTIMIZATION_SUGGESTIONS: Record<string, string> = {
  combine: 'When is it safe to combine earning codes?',
  split: 'Why split discretionary and non-discretionary bonuses?',
  inactive: 'Should codes with no activity be left out?',
}

const pageDescriptions = {
  reviewOverview: () => ({
    name: 'Your code review at a glance',
    purpose: 'Explain the three upcoming review stages before the first question. No answers or setup changes are applied on this page.',
    onScreen: [
      'Clarification: confirm what payments are for.',
      'Optimization: review opportunities to simplify code setup.',
      'Weighted average overtime: review which earnings count toward the rate used to calculate overtime, where applicable.',
      'Start review opens the existing first review screen. Back returns to prepared results without removing evidence.',
      'Save and finish later keeps your place without applying setup changes. Uploaded evidence stays separate from sample data.',
    ],
    state: [],
    welcome: 'I can explain the three stages before you begin. Start review opens your first review screen. You can go back to your results or save your place without applying setup changes.',
    suggestions: ['What will I review?', 'What does weighted average overtime mean?', 'Can I save and come back?'],
  }),
  'uploaded-registers': facts => ({
    name: 'What do we need to review? — uploaded registers',
    purpose: 'Review code-level evidence read from private uploaded registers. The evidence is not a confirmed Ready setup.',
    onScreen: [
      'Files read and files not included; Back to files returns to upload for retries or removal',
      'Codes grouped within an identified company, with suggested questions first under Details to confirm and Discussion notes fields',
      'View source expands the source line, filenames, periods, descriptions, sections, source excerpts, amounts and people per report',
      'Conflicting code meanings, duplicate reports and overlapping or unknown periods stay visible',
      'Amounts and people are not added across registers. Sample data stays in a separate review.',
      'Call answers are saved notes, not setup decisions. Save and finish later keeps progress.',
      ...(facts.viewCodes ? ['View codes opens Code status with the consolidated uploaded codes, Needs review or Notes added, and evidence warnings. It never confirms a Ready match or setup.'] : []),
    ],
    state: [`Files: ${count(facts.files)}; read: ${count(facts.read)}; couldn’t read: ${count(facts.failed)}`],
    welcome: 'I can help you compare what the registers show. Expand a code’s register details to check its sources, or return to files to retry one that couldn’t be read.',
    suggestions: ['Why are these reports kept separate?', 'What does a conflicting description mean?', 'Will my customer answers change the setup?'],
  }),
  categorySelection: _facts => ({
    name: 'Choose what to set up',
    purpose: 'Choose which part of payroll to visit. Set up earnings opens Help us identify your payroll codes. View deductions and View taxes open information-only pages. Visiting either does not advance or erase earnings progress.',
    onScreen: [
      'Review one part of payroll at a time. Choose where to start. You can return here and change your choice without losing your work',
      'Three cards: Earnings, Deductions and Taxes. Each has its own navigation button and Assign to others. Card bodies are not interactive',
      'Earnings: Pay your people earn for their work.',
      'Deductions: What is withheld from pay, before or after tax',
      'Taxes: Tax amounts withheld from pay.',
      'Deductions and Taxes each have a separate notice: Information only. Setup isn’t available here yet.',
      'Set up earnings opens Help us identify your payroll codes; existing files and progress remain, including progress from later steps',
      'View deductions opens the existing information-only Deductions page. View taxes opens the existing information-only Taxes page.',
      'Assign to others opens an independent dialog for that category with a sample people list.',
      'Confirm assignment keeps the chosen person with local progress. It does not open a category or advance setup.',
      'Leave unchanged, Close dialog or Escape discards pending changes. No invitations or notifications are sent.',
      'Back returns to the payroll overview. Assigning someone does not make deduction or tax setup available',
    ],
    state: [],
    welcome: 'Choose where to start with payroll. I can explain earnings, deductions or taxes. You can return to these choices without losing your earnings work.',
    suggestions: ['What does each part of payroll cover?', 'Will choosing deductions affect my earnings work?', 'Can I come back to these choices?'],
  }),
  intro: () => ({
    name: 'Let’s get ready to pay your people',
    purpose: 'Introduce the different parts of pay in Ready: earnings, deductions and employee tax withholding. Start opens the payroll choices. Set up earnings opens Help us identify your payroll codes; View deductions and View taxes open information-only pages. Uploaded registers can be read for code evidence, or sample data can be reviewed separately.',
    onScreen: [
      'You know your payroll. We’ll help you match those familiar pay details to Ready’s earning, deduction and tax codes, so you’re set up for payday.',
      'The illustration says What goes into pay, with Ready payroll basics as a secondary label. Three bubbles explain Earnings, Deductions and Tax withholding. It shows no amounts or extracted results',
      'Below Earnings, the Knowledge preview says Learn how we classify earning & deduction. Play is styled as an inline link at the end. The video isn’t available yet, so Play does nothing',
      'At your pace. Time depends on your pay details. Supported formats: PDF, CSV or Excel. Save and finish later anytime',
      'Back returns to Company Setup. Start opens the payroll category choices, where Set up earnings opens Help us identify your payroll codes directly',
      'Bring along: your most recent payroll report (payroll register), showing earnings, deductions and taxes',
      'A list of your payroll codes, if available',
      'Details of any benefits or other deductions, if applicable',
      'Your most recent off-cycle or bonus payroll report, if applicable.',
      'This is general payroll preparation, not a requirement to provide every document. The upload page lists earnings, deduction and tax reports and payroll registers or summaries',
      'Restart demo is in the header. To start at the overtime demo, use Start at overtime in the Earning Configuration card’s Open menu on the Projects page',
    ],
    state: [],
    welcome: 'I can help you understand the different parts of pay in Ready. Start opens the payroll choices so you can choose where to begin.',
    suggestions: ['What are earning codes?', 'What makes up take-home pay?', 'How are deductions and taxes different?'],
  }),
  deductions: () => ({
    name: 'Deductions',
    purpose: 'Information-only page about deductions; there is no deduction setup flow here yet. Visiting does not change earnings answers or progress.',
    onScreen: ['Deductions', 'Keep benefits, retirement contributions and other deductions organized for payday', 'Nothing has changed. You can go back and choose another part of payroll', 'Back to payroll choices returns to the category selection'],
    state: [],
    welcome: 'You’re looking at deductions. I can explain what comes out of pay besides taxes. Back to payroll choices lets you choose another part without losing your earnings work.',
    suggestions: ['What are deductions?', 'How do deductions affect take-home pay?'],
  }),
  taxes: () => ({
    name: 'Taxes',
    purpose: 'Information-only page about tax withholding; there is no tax setup flow here yet. Visiting does not change earnings answers or progress.',
    onScreen: ['Taxes', 'Keep federal, state and local tax withholding organized for payday', 'Nothing has changed. You can go back and choose another part of payroll', 'Back to payroll choices returns to the category selection'],
    state: [],
    welcome: 'You’re looking at taxes. I can explain what’s held back from pay for taxes. Back to payroll choices lets you choose another part without losing your earnings work.',
    suggestions: ['What is employee tax withholding?', 'How is withholding different from deductions?'],
  }),
  upload: facts => ({
    name: 'Help us identify your payroll codes',
    purpose: 'Add payroll registers to read their code-level evidence. Uploaded registers need sign-in and stay private. Next opens the file results; sample data has a separate review.',
    onScreen: [
      'Upload reports from your current payroll system to help identify payroll codes',
      'Log in for private uploads. Choose up to 5 PDF, CSV or Excel (XLSX) files, up to 10 MB each; PDFs can have up to 20 pages',
      'Start with these reports: Earnings code list; Deduction code list; Tax code or tax setup report; Payroll register or payroll summary',
      'Include occasional earnings, recurring and one-time deductions, federal, state and local payroll taxes, and current and prior-year payroll information if available',
      'Upload what you have; all four report types are not required. Add more later or review missing information with your implementation team. This guidance does not add deduction or tax setup',
      'Each file gets a document type, such as pay register or code list',
      'Files show uploading, reading, read or couldn’t read. Try reading again and Check status recover file reading; Remove takes a file out without clearing saved answers',
      'Upload sample data adds two sample pay registers without choosing local files. Both count toward the 5-file limit. Existing sample files are not duplicated; other uploads and saved answers stay in place',
      'Show sample data opens a preview without uploading or changing progress. Close returns to upload',
      'Upload sample data loads two pay registers: September 1–15 and September 16–30, 2026. Show sample data previews both without uploading. Each has separate period payments and the same 12-month amounts and people counts; the review uses those shared 12-month figures once, not twice. The review covers earnings and who pays into four benefit plans, not full deduction setup',
      'Actions: Back, Next (on once a file is uploaded), and Save and finish later in the header',
      'Back returns to the payroll choices. Files, assignments and answers are kept. Set up earnings returns to upload without losing progress, including progress from later steps',
    ],
    state: [
      `Files uploaded: ${count(facts.files)}`,
      ...labeled('Document types', facts.documentTypes),
    ],
    welcome: 'You’re on Help us identify your payroll codes. I can cover which files to add, how the document type is used and what happens after Next.',
    suggestions: ['Which register format works best?', 'Should I add the code list too?', 'What happens after Next?'],
  }),
  analysis: facts => ({
    name: 'Preparing your review',
    purpose: 'UKG Ready prepares the earning code and benefit contribution review one step at a time, matching clear earnings against Ready references and flagging questions for the team. The review uses example codes, not codes read from uploaded documents.',
    onScreen: [
      'Steps with a progress count: Organizing earning codes, Checking earning codes, Preparing your results',
      'Each step shows In progress, Complete or Pending, with a short result once complete',
      'When preparation finishes, the steps stay visible under Preparing your review. The card says Your review is ready, with a summary and optional code details below. Start review opens the three-stage overview',
      `Actions: Back returns to upload. Start review ${facts.canStartEarly ? 'is available now with the demo setting on' : 'is available once preparation finishes'}`,
    ],
    state: ['Preparation is in progress; the completed summary is not visible yet'],
    welcome: 'We’re preparing your review. I can explain what each step checks and what comes next.',
    suggestions: ['What does checking earning codes look for?', 'What does Ready for setup mean?', 'What happens once the review is ready?'],
  }),
  results: facts => ({
    name: 'Preparing your review',
    purpose: 'Preparation has finished on the same Preparing your review screen. All three steps stay visible, with Your review is ready in the card and a summary below. Start review opens the three-stage overview; Continue review resumes existing work.',
    onScreen: [
      `Summary: ${plural(count(facts.total), 'earning code')}, ${count(facts.matched)} Ready for setup, ${count(facts.needInput)} needing input. Separately, ${plural(count(facts.plans), 'benefit plan')} needing confirmation`,
      'Code details show one list of earning codes, their available descriptions and whether each purpose needs review. No pay amounts, people counts or Ready reference columns appear in this list',
      `Start review opens the three-stage overview. Continue review resumes existing work directly. View all ${count(facts.total)} codes opens optional details. Back returns to upload without clearing answers or replaying preparation`,
      'View all codes opens a single table with Code, Description and Review status. Each row says Needs review or No review needed, with a short reason',
      'Matched purposes need no new purpose review. Already handled codes show their current status; other setup decisions remain separate',
      'The original Back and Start review or Continue review buttons stay below the preparation card and summary. Your answers are kept when you return',
    ],
    state: [
      `Earning codes: ${count(facts.total)}`,
      `Need your input: ${count(facts.needInput)}. Matched: ${count(facts.matched)}`,
      `Benefit plans to confirm: ${count(facts.plans)}`,
      ...entries(facts.flaggedCodes),
      ...each('Matched', facts.matchedCodes),
      facts.reviewStarted ? 'You’ve started the review. Counts show what remains until answers are applied' : 'The review hasn’t started yet',
    ],
    welcome: `Your review is ready. I can explain why a code needs review. ${facts.reviewStarted ? 'Continue review returns to your existing work.' : 'Start review shows what to expect in the three stages before you answer questions.'}`,
    suggestions: ['Why do reimbursements need a closer look?', 'Why confirm who pays into each plan?', 'What happens to the matched codes?'],
  }),
  questions: facts => ({
    name: text(facts.category) || 'Review added questions',
    videoCallout: text(facts.codesInView).split(',').some(code => code.trim() === 'MILEAGE')
      ? 'Learn about mileage' : undefined,
    purpose: `${facts.addedQuestions
      ? 'These questions were added after earlier progress was saved. They are not findings from earlier decisions. Answers can change until Apply answers.'
      : 'Eight business sections group related codes. Answers can change until Apply answers. Benefit plans count separately from earnings.'}`,
    onScreen: [
      STATUS_PANEL,
      `${text(facts.category)}${text(facts.topic) ? ` — ${text(facts.topic)}` : ''}: ${text(facts.codesInView)}`,
      statusLine(facts),
      ...(text(facts.topicId) === 'changes' ? [] : [text(facts.topicId) === 'other' ? SOMETHING_ELSE_UNIDENTIFIED : SOMETHING_ELSE_ON_SCREEN]),
      ...(text(facts.topicId) === 'other' ? [
        'MISC7 opens on a description input with Done and Defer. Checks reuse earlier answers; brief answers can suffice.',
        'Done checks the answer against Ready references. It doesn’t confirm the code; only choosing Use ‘Retroactive pay’ or Use ‘Shift differential’ does',
        'An AI custom name comes with a reason, or AI asks for missing detail; Try again appears if it fails. It isn’t a Ready reference: using it saves only the name, and setup stays Awaiting setup review',
        'Earning names tell employees what they were paid for on pay statements. A name doesn’t set tax, overtime or W-2 treatment',
      ] : text(facts.topicId) === 'changes' ? [
        'The intro ends with Watch how we group pay, styled as an inline link. The video isn’t available yet, so the link does nothing',
        'BONREV has a compact fixed Deduction proposal with a business-purpose explanation. Check I understand or select Defer',
        'Defer counts as answered and adds BONREV to the customer questions when answers are applied, alongside other deferred codes. Its Deduction classification does not change',
      ] : text(facts.topicId) === 'pay' ? [
        'Overtime ENG and Overtime MFG each ask how the paid amounts were determined: premium-only, full overtime rate or flat amount. The answer supports determining whether register amounts match what people should have received and identifying amounts needing review. This explains the purpose; no reconciliation or automatic payroll correction has occurred',
        'View source contains the source line naming the pay periods and the actual source rows. A suggested meaning is not a description from the register',
        'Overtime choices: 0.5× (extra half), 1.5× (time and a half), 2× (double time), Flat amount, Something else or Defer. Each has an illustrative example',
        'Special Pay asks whether it is shift pay, a correction to earlier pay or Something else. Typed answers get a description check; follow-ups stay in its card. Defer is available',
        ...TIPS_PAGE_ON_SCREEN.filter(line => line.startsWith('TIPS')),
      ] : text(facts.topicId) === 'expenses' ? [
        'The current step is Allowances & reimbursements. Keep help focused on this category, not cellphone payments.',
        'Explain the difference between a set allowance for work expenses and paying someone back for actual expenses. Use the current questions and answers, not assumptions about tax treatment.',
        'Help with mileage payments when asked. Payment method or receipts alone do not establish tax qualification, and answers do not change live payroll.',
      ] : text(facts.topicId) === 'benefits' ? [
        'MED is not an active question. MED ER asks its purpose, then one numbered question about the selected purpose. Earlier MED answers and confirmed attachments stay in saved history',
        'Company contributions ask only insurance-cost tracking versus taxable pay, with unsure allowed. Unknown tax treatment retains a provisional employer-contribution purpose. Reported answers never validate setup',
        'The closest available medical reference is the employer portion of a medical deduction, not that exact conceptual label. It is only a candidate for setup review, never an automatic attachment to MED',
        'Direct money distinguishes medical allowance from reimbursement. Reimbursement is not automatically taxable wages; a taxable noncash benefit is not ordinary cash pay. Other or unsure can finish requiring review with an optional description',
        'Keep the short reported-answer recap, not a long specialist report. Do not ask W-2 boxes, tax codes, plan adoption or continuation for classification. Plan adoption, funding, cash options and assignment belong to the separate overtime assessment',
        'If a company portion isn’t set up now and the company starts paying later, a new code is needed then alongside the existing deduction',
        'Some setup then has to be updated to use the new code, and until then payroll doesn’t include a company share. Explain this only when asked',
        'Picking an answer gets no AI review. Only typed descriptions after Done and follow-up replies get one',
        'Completing MED ER classification does not confirm regular-rate exclusion, tax compliance or setup readiness. Defer and Clear all answers stay available',
        'If someone writes that their company won’t pay, the answer review accepts it, says a new code would be needed if that changes, and shows an Ask Bryte link',
      ] : text(facts.topicId) === 'leave' ? [
        'VAC, SICK, HOL and JURY ask about purpose only when it is missing, ambiguous or disputed, or an earlier question still needs action. Untouched bundled purpose matches need no new confirmation; they are not customer answers. Neither a name nor inactivity proves leave policy. Nothing is preselected',
        'A confirmed purpose uses its existing Ready leave reference. Something else opens a description with Done and live answer review, and leaves setup awaiting the team’s review without a reference. Defer adds a leave-purpose question for the customer',
        'This confirms purpose only, not accruals, balances, eligibility, statutory rules, tax or overtime policy. JURY’s later keep-or-remove question remains separate',
      ] : text(facts.topicId) === 'tips' ? TIPS_PAGE_ON_SCREEN.filter(line => !line.includes('GTL') && !line.includes('IMP INC'))
        : text(facts.topicId) === 'taxableBenefits' ? TIPS_PAGE_ON_SCREEN.filter(line => !line.includes('TIPS')) : [
        'Each code here needs one more answer about how the company pays or handles it, so we can set it up in Ready. Every code offers Defer',
      ]),
      ...(text(facts.topicId) !== 'expenses' && text(facts.codesInView).split(', ').includes('CELL') ? [
        'CELL asks How does your company use CELL to pay employees for cellphone costs? Choose Fixed amount, Actual expense reimbursement, Both, or Something else. Nothing is preselected.',
        'The supplied mapping context establishes cellphone allowance/reimbursement. This is not a printed description or a verified database lookup. The $40, $35 and $20 examples are illustrative, not customer figures.',
        'Fixed amount asks why the allowance is provided. A bounded live check selects only missing business facts, then the fixed tax-confirmation question. Fixed amounts are not automatically taxable; reimbursement and receipts do not prove nontaxable qualification.',
        'Both keeps allowance and reimbursement facts and tax intent separate. It never automatically splits CELL or creates new codes. Unsupported setup requirements remain with the setup team.',
        'Tax confirmation offers Taxable, Nontaxable with company-confirmed qualification, Not sure, and Something else for special treatment. Pending tax decisions allow other codes to continue but are not ready for final CELL tax setup.',
        'Something else gets a live targeted clarification after Done, not an automatic handoff. Earlier applicable confirmations are reused. Defer preserves learned facts; Clear all answers restarts the editable card. If we can’t check an answer, Try again or Defer are available without invented results.',
      ] : []),
      ...(text(facts.codesInView).split(', ').includes('MILEAGE') ? [
        'MILEAGE ends with a read-only Summary of captured requirements or remaining review. Documentation, tax treatment, actual company settings and payroll testing remain pending; the Summary never confirms setup or changes payroll. Individual answer edits and Clear all answers remain available on editable cards.',
      ] : []),
      'Back returns to the completed summary from the first page, otherwise to the previous page. Next needs an answer for every code on the page, and Defer counts as an answer',
      'Navigation is below the questions; the last page has Apply answers once all are settled. The header has hub return, Back to Projects, Save and finish later, Restart demo, Ask Bryte',
    ],
    state: roundState(facts),
    welcome: facts.addedQuestions ? 'These questions were added after you saved your earlier progress. I can help you answer them without changing your earlier decisions.'
      : text(facts.topicId) === 'other'
       ? 'MISC7 needs a description before we can suggest a setup. I can explain what details help.'
      : text(facts.topicId) === 'changes'
        ? 'We suggest setting up BONREV, your bonus reversal, as a deduction, because it takes back money already paid. I can explain why, or what happens if you select Defer and decide later.'
        : text(facts.topicId) === 'expenses'
          ? 'You’re on Allowances & reimbursements. I can explain the difference between a set allowance and paying someone back for work expenses, or help with mileage payments.'
        : text(facts.topicId) === 'benefits'
          ? 'I can help you distinguish company-paid medical coverage from cash payments and reporting-only amounts. Your answers guide the classification; setup and overtime still need their own checks.'
          : text(facts.topicId) === 'pay' && text(facts.codesInView).split(', ').includes('TIPS')
            ? 'I can explain pay calculations, paid and reported tips, and special payments. Which code would you like to review?'
          : text(facts.codesInView).split(', ').includes('Overtime ENG')
             ? 'I can explain the overtime rates and Overtime ENG’s suggestion before you apply answers.'
            : text(facts.codesInView).split(', ').includes('TIPS')
              ? 'I can explain how paid and reported tips differ, and when a separate code is needed.'
              : `I can help with ${text(facts.category).toLowerCase() || 'these codes'}. Your answers tell us which setup fits.`,
    suggestions: text(facts.topicId) === 'other'
      ? ['What details help identify MISC7?', 'What happens after I select Done?', 'When should I select Defer?']
      : text(facts.topicId) === 'changes'
        ? ['Why is BONREV proposed as a Deduction?', 'What happens if I defer BONREV?', 'Can I return to change this answer?']
        : text(facts.topicId) === 'expenses'
          ? ['How do allowances and reimbursements differ?', 'How should I describe mileage payments?', 'What if I’m not sure about an answer?']
        : text(facts.topicId) === 'benefits'
          ? ['Why ask which code holds my company’s part?', PLAN_LATER_QUESTION, 'What happens if I select Defer?']
          : text(facts.codesInView).split(', ').includes('Overtime ENG') && !facts.addedQuestions
            ? ['What does the 60% suggestion mean for Overtime ENG?', 'How do the overtime rates differ?', 'What happens if I select Defer?']
            : text(facts.codesInView).split(', ').includes('CELL')
              ? ['How do CELL’s answers differ?', 'When would a second code be needed?', 'What happens if I select Defer?']
            : text(facts.codesInView).split(', ').includes('TIPS')
              ? ['How do the TIPS answers differ?', 'What does the TIPS summary mean?', 'What happens if I select Defer?']
              : text(facts.topicId) === 'leave'
                ? ['What does confirming a leave purpose do?', 'What if this code pays for something else?', 'Why does JURY have another question later?']
              : ['How are these payments taxed?', 'When would a second code be needed?', 'What happens if I select Defer?'],
  }),
  'new-findings': facts => ({
    name: 'Review follow-up questions',
    purpose: 'Resume follow-up questions from an earlier applied review. MILEAGE TX and TIPS RPT appear inside their original code’s card with the earlier answer kept read-only. Fresh reviews ask these questions in the original card before Apply answers.',
    onScreen: [
      'One saved follow-up per page, inside the original code’s card',
      'The original answer stays read-only; the follow-up has its question, answer choices and the card’s single Defer',
      SOMETHING_ELSE_FINDING,
      statusLine(facts),
      STATUS_PANEL,
      'Sticky bar: Back, Next once the finding is answered, and on the last one Apply answers or Go to a finding still open',
    ],
    state: roundState(facts),
    welcome: `You’ve reviewed ${count(facts.answered)} of ${count(facts.total)} source codes or plans. I can explain the remaining decisions. Reviewed doesn’t mean ready for setup.`,
    suggestions: [
      text(facts.currentCode) ? `Why was ${text(facts.currentCode)} raised?` : 'Why were these findings raised?',
      'What does each choice set up?',
      'What happens if I select Defer?',
    ],
  }),
  reevaluation: facts => ({
    name: 'Rechecking with your answers',
    purpose: 'We apply the team’s answers and recheck the codes, so anything the answers change comes up before setup rather than after. Open review turns on when the recheck finishes.',
    onScreen: [
      STATUS_PANEL,
      'Recheck steps with a progress count: Apply answers, Recheck classifications, Look for new findings',
      'Each step shows In progress, Complete or Pending, with a short result once complete',
      'Actions: Open review once the recheck finishes',
    ],
    state: [
      `Round applied: ${count(facts.round)}`,
      `Codes resolved: ${entries(facts.resolved).length}`,
      ...labeled('Added to the questions for the customer', facts.deferred),
      ...each('Proposed custom names awaiting setup review (not Ready references)', facts.proposedNamesAwaitingReview),
      ...(entries(facts.findings).length ? each('New finding', facts.findings) : ['No new findings']),
    ],
    welcome: 'We’re rechecking the codes with your answers. I can explain what the recheck looks for and why an answer can raise a new finding.',
    suggestions: ['What does the recheck look for?', 'Why would an answer raise a new finding?', 'What happens to items for the customer?'],
  }),
  'applied-review': facts => ({
    name: 'Saved review answers',
    purpose: 'Look back at the questions and answers from an applied review without changing payroll setup or progress.',
    onScreen: [
      `Saved review round ${count(facts.round)}, page ${count(facts.page)} of ${count(facts.pages)}`,
      'Answers are read-only. There are no editing controls or Apply answers action, and viewing this page does not run AI checks.',
      'Back and Next move between saved question pages. Return to setup opens the page you left, preserving unapplied proposal edits without applying answers again.',
      'Applied review answers contains read-only application history. Pending findings or added questions stay pending.',
    ],
    state: ['Saved answers are locked. Navigation does not change the current open round or later setup progress.'],
    welcome: 'These answers have already been applied. I can help explain them while you look back. Select Return to setup when you’re ready to continue.',
    suggestions: ['How do I return to setup?', 'Can I change these saved answers?'],
  }),
  'confirmation-needed': () => ({
    name: 'Some decisions still need confirmation',
    purpose: 'Keep saved progress safe when a required decision is missing and its owning question cannot be identified.',
    onScreen: [
      'No deferred question cards or answer controls. Saved progress does not identify which question needs an answer.',
      'View saved answers opens read-only history. Save and finish later keeps answers, notes and progress.',
      'Optimization remains unavailable. Do not guess a missing question, select Defer or confirm a setup automatically.',
    ],
    state: ['Earlier answers are preserved, but they do not establish the missing confirmation.'],
    welcome: 'Your earlier answers are kept, but I can’t identify which question needs confirmation from this saved progress. You can view saved answers or save and finish later.',
    suggestions: ['Are my earlier answers kept?', 'Why can’t I continue to optimization?'],
  }),
  review: facts => ({
    name: 'Let’s fill in the gaps in your pay code setup',
    purpose: 'The “Let’s fill in the gaps in your pay code setup” page starts with explicitly deferred questions. Each owning code keeps its opening answer, follow-ups and Summary together; new findings have their own cards. Back opens saved applied answers without changing progress.',
    onScreen: [
      'The bottom bar counts opening answers, not notes or history. Choices advance on selection; typed answers advance on Done. Follow-ups stay in that code’s card without waiting for other cards.',
      'Apply answer commits only that code’s checked outcome and required related findings. Other codes can stay unfinished. Continuing never applies answers or confirms payroll readiness.',
      'Answer entered means required input is present, not approved or saved for later. Blank answers, missing details and text over 2,000 characters need attention. Uncertainty does not confirm a fact.',
      'Each code’s Summary offers Apply answer. Missing details, checks and confirmations stay in that card, with a reason when applying is unavailable.',
      'Continue to optimization is available even with no answers entered. Back returns to pending questions. Only explicitly applied outcomes affect the setup; drafts and notes stay intact.',
      'Back opens the last question page of the most recently applied review. Saved answers remain read-only; pending questions do not start.',
      'To discuss contains only valid explicit Defer selections. A customer status or saved draft alone never creates a card. New findings raised by a prepared answer keep separate owning cards on this page.',
      'Each card shows the code, supporting context, the exact deferred question and its original choices or Answer field. Completed answers collapse to editable pills. Follow-ups and Summary stay inside the card.',
      'The AI summary is context only. It is labeled as AI, adds no questions, options, names, mappings or tax conclusions, and never changes an answer or blocks saving or applying.',
      'The 10px information icon at the bottom left of the review panel opens Section goal. The explanation starts hidden and updates with the current section. The icon toggles only this note, without changing answers or progress.',
      STATUS_PANEL,
      'To discuss contains one card per code that owns an explicitly deferred question, in review order. Without current deferred questions, this page is skipped.',
      'Earlier answers, Why it matters, View source and Earlier discussion responses start collapsed and are read-only.',
      'View source contains the Source line naming the registers, each filename, period, code, original section and figures. The demo registers have no code descriptions',
      'Source details show the payments for each uploaded September 2026 pay period separately. Added codes show their related source code; the two pay periods do not establish a full year of activity',
      'Add discussion notes opens an optional notes field. Existing notes stay visible on return. Notes are saved with progress but are not an answer and don’t change the setup.',
      'New findings stay pending for their own review action; they are not added to a deferred card.',
      'After Apply, any remaining deferred work stays here. Otherwise pending rounds open directly, followed by an owning-question proposal for identifiable unfinished setup decisions, or optimization when its existing prerequisites are met. Earlier answers stay in history.',
      `Actions: Apply answer in each prepared card, Back, Continue to optimization. ${count(facts.nextRoundFindings) ? `Review ${plural(count(facts.nextRoundFindings), 'new finding')}. ` : ''}Continuing keeps unfinished questions open.`,
    ],
    state: [
      `Round ${count(facts.round)} applied`,
      `${count(facts.deferredInputEntered)} of ${count(facts.deferredInputTotal)} current deferred answers entered; ${count(facts.deferredInputRemaining)} need attention. Entry is not approval.`,
      ...each('Saved AI-drafted questions (history, not active page questions)', facts.draftedCustomerQuestions),
      ...compactEach('Saved resolved results (not cards on this page)', facts.resolved),
      ...labeled('Saved customer-status items (not proof of an explicit Defer selection)', facts.deferred),
      ...each('Saved proposed names awaiting setup review (not cards on this page)', facts.proposedNamesAwaitingReview),
      ...each('Pending new findings (not cards on this page)', facts.findings),
       ...cellState(facts),
      ...mileageState(facts),
    ],
    welcome: `This page shows only the questions you selected Defer for. You can review an answer as soon as its input is complete, without waiting for the others. I can help explain what still needs an answer.`,
    suggestions: [
      'What should I review on this page?',
      'Is the AI summary a decision?',
      count(facts.nextRoundFindings) ? 'Why did my answers raise a new finding?' : 'When can I apply my answers?',
      'What comes after classification?',
    ],
  }),
  discussionReview: facts => ({
    name: 'Review and apply answers',
    purpose: 'Preview what each captured deferred answer will change before anything is applied. Apply answers is the only action on this page that changes the setup.',
    onScreen: [
      'Only completed discussion answers appear, with a count of answers still needed. Each code shows its question, answer and supported change or remaining check, detail or confirmation.',
      'If answers changed after this preview was prepared, the page says so and offers Prepare the review again',
      'Required follow-ups and checks use their existing controls in the preview. Entered does not mean checked; Apply answers stays unavailable until all required input and proposal checks are complete.',
      'Continue answering returns to the discussion page without losing text, choices or notes. Back returns to owning questions for a setup-review proposal. Adding answers updates the next preview.',
      'Applying happens once. Refreshing or reopening does not repeat it. Applied answers become read-only history',
    ],
    state: [
      'Nothing on this page is applied until Apply answers is selected.',
      ...(facts.setupReview ? [] : [`Reviewing ${count(facts.reviewedAnswers)} of ${count(facts.deferredInputTotal)} answers; ${count(facts.deferredInputRemaining)} still needed.`]),
    ],
    welcome: 'This is a preview of what your answers will change. Nothing is applied until you select Apply answers.',
    suggestions: ['What happens when I select Apply answers?', 'Why does a code need more answers?', 'Can I change an answer after applying?'],
  }),
  discussionWork: () => ({
    name: 'Review required questions',
    purpose: 'Answer required questions or finish unconfirmed setup decisions using each code’s owning controls. Earlier saved answers stay in history. Nothing is applied here.',
    onScreen: [
      'Each question appears with its original choices and Defer. Follow-ups are never accepted automatically',
      'Actions: Back returns to the preview for deferred-answer work, or opens saved answers read-only for setup-review work. Return to setup brings back the same proposal and edits. Finish opens Review and apply answers. No navigation applies anything',
    ],
    state: ['Answers here update the preview only, not the setup.'],
    welcome: 'Review each required question or select Defer, then select Finish to return to the preview. Your earlier saved answers stay in history.',
    suggestions: ['Why are these questions here?', 'Does Finish apply my answers?'],
  }),
  optimization: facts => ({
    name: 'Optimize codes',
    purpose: 'These suggestions can reduce duplicate setup, separate pay that needs different treatment, and leave out codes you no longer need.',
    onScreen: [
      STATUS_PANEL,
      'Eligible suggestions grouped as Combine, Split and Potential not active; empty groups are omitted. Each has its full context and choices: accept, keep as is and Something else',
      'Something else opens a description box (up to 300 characters) with Done and Edit; another pick clears it',
      'After Done, Something else applies nothing: the codes stay as they are, awaiting setup review with the description, and the suggestion counts as answered',
      'Earlier deferred answers remain saved, but no new deferral is offered here. An editable earlier answer can be cleared or replaced',
      'Combination questions appear only when every code has a confirmed, compatible setup. Different setups have no combination question; unconfirmed setups wait for applied answers. Hidden questions need no answer. If no suggestions are ready, Next continues without adding answers.',
      'Back and Next sit below the current card and scroll with the page. Next opens the next card. On the last card, with every suggestion answered, Next locks the answers and opens overtime review. If unfinished continuation is available, Next leaves unanswered suggestions editable',
      'Back opens the previous card, or returns to the review page from the first card, without changing answers',
    ],
    state: [
      ...optimizationState(facts),
      ...each('Suggestion', facts.suggestions),
      ...labeled('Suggestion being answered', facts.next),
    ],
    welcome: `You’re on optimization, with ${count(facts.answered)} of ${count(facts.total)} suggestions answered. I can weigh each one with you, from combining codes to leaving out inactive ones.`,
    suggestions: [
      OPTIMIZATION_SUGGESTIONS[text(facts.nextKind)] ?? 'What happens when I select Next?',
      'How do these choices affect overtime?',
      'What if none of the listed answers fits?',
    ],
  }),
  optimizationReview: (facts: AskBryteFacts): ReturnType<AskBrytePageDescriber> => earningPages.overtime(facts),
  overtime: facts => ({
    name: 'How does your team earn overtime',
    purpose: 'Different rates and some bonuses can affect overtime. Questions come one at a time; Yes immediately opens the separate overtime assessment. No continues screening. Something else needs a description; Defer keeps the customer question open unless a later Yes supersedes it. Answering does not recalculate payroll or change live pay.',
    onScreen: [
      STATUS_PANEL,
      'Current sources are checked before unanswered questions appear. Findings show their source separately from customer answers; Correct facts opens a current clarification without editing an applied review.',
      'A supported Yes finding enables Next to the separate assessment without earlier redundant answers. Only supported No for every condition means standard overtime. Partial facts narrow the missing question; missing evidence is never No.',
      'Explicit answers remain visible when sources disagree. Correct the facts or change the answer; findings never silently replace it. Try again retries an unavailable check, or the original questions remain available.',
      'Screening questions, one at a time, each with Yes, No, Something else (a description box, up to 300 characters, with Done and Edit) and Defer',
      'Why this matters opens and closes at the bottom of the first card. It explains that overtime may need to reflect both pay earned and hours worked at each rate, rather than one job’s rate. Other cards retain What is weighted average overtime?',
      'Watch video beneath the first explanation is a visual placeholder, not an active link; no video is available yet',
      'Topics: different hourly rates for different jobs in the same workweek; extra shift pay; bonuses for goals set in advance, earned and paid in the same pay period; rewards for work covering more than one pay period; overtime eligibility with a fixed salary and changing weekly hours',
      'Yes immediately opens a separate assessment page. This questionnaire does not display assessment results.',
      'With no Yes, Continue to summary keeps standard, customer and setup-review outcomes distinct; unresolved answers never count as No.',
      'Something else never counts as No. With no Yes, the method is awaiting setup review with the descriptions; a later Yes still applies weighted average overtime, and the descriptions stay in the notes',
      'Sticky bar: Back, question progress, and Next (when returning to a saved Yes) or Continue to summary',
      'Back opens saved answers read-only. Return to setup brings you back with your progress intact. Optimization is available only when required review answers have been confirmed and applied',
      'Start at overtime cannot skip required or unapplied review work. If any remains, the bookmark opens that review rather than confirming it',
    ],
    state: [
      `Overtime method: ${text(facts.method)}`,
      ...overtimeReason(facts),
      `Questions asked: ${count(facts.asked)} of ${count(facts.total)}`,
      ...labeled('Question being answered', facts.current),
      ...each('Answer', facts.answers),
      ...(count(facts.noLongerNeeded) ? [`Questions no longer needed after a Yes: ${count(facts.noLongerNeeded)}`] : []),
      ...(count(facts.somethingElse) ? [`Something else answers in the setup team’s notes: ${count(facts.somethingElse)}`] : []),
    ],
    welcome: 'You’re on the “How does your team earn overtime” page. I can help you answer questions about your pay practices and explain what to review next. Your answers don’t change live payroll.',
    suggestions: ['Why do different hourly rates matter?', 'What happens after I answer Yes?', 'What happens if I select Defer?'],
  }),
  overtimeAssessment: facts => ({
    name: 'Your overtime setup may need additional configuration',
    purpose: 'Explain the supported screening result before reviewing earning codes. This page does not select treatments or change payroll.',
    onScreen: [
      'Different rates of pay may need to be considered when calculating overtime.',
      'Weighted average overtime is one method used to account for these differences.',
      'Next opens Review your overtime earnings directly, with Still to decide, Included and Not included groups. No additional payment questionnaire is required.',
      'Back returns to the answered questionnaire so you can revise answers. Save and finish later keeps your answers and place.',
    ],
    state: [...each('Screening answer', facts.answers)],
    welcome: 'Your answers show that some pay may need a closer look for overtime. I can explain the result. Next opens Review your overtime earnings; Back lets you revise your answers. Nothing here changes live payroll.',
    suggestions: ['What is weighted average overtime?', 'What will I review next?', 'Can I change my answers?'],
  }),
  overtimeSort: facts => ({
    name: 'Review your overtime earnings',
    purpose: 'Review earning-code inclusion in the regular rate—the hourly rate used to calculate overtime. Deterministic federal rules use reviewed payment facts or supported confirmed setup. AI structures supplied facts, not law. A supported recommendation does not confirm Ready setup, taxes, state-law coverage or live payroll.',
    onScreen: [
      'View codes opens Code status without changing answers. It separates question progress, proposed choices and setup outcomes, with related outputs and open questions.',
      'Sections start as Needs your decision, Included, Not included, with source order within the section. Each payment appears once. Section counts describe displayed cards, not current outcomes.',
      'Cards stay in place during the open review, with keyboard focus on the edited card. Results and progress counts update immediately without moving cards. Setup review stays separate.',
      'Each card separates the suggestion from your choice. Change revises it; Use recommendation deliberately adopts a suggestion. Separate setup review stays open.',
      'This page omits the overtime payment-method reference and tips payments. Counts cover displayed payments only. Saved tips answers and overtime decisions remain in the review and summary.',
      'Saved facts may be checked in the background. Pending or unavailable checks never block the list, eligible choices or continuation. Try again repeats an unavailable check without opening questions.',
      'Eligible payments start unchecked: Include, Exclude or Not sure yet. Only explicit inclusion or exclusion counts as decided, even with supported advice. Mixed codes keep their split controls.',
      'Your choice stays explicit alongside a new recommendation. Use recommendation adopts it deliberately. Clear choice removes your selection. Separate setup concerns stay open.',
      'Mixed codes need their existing split controls. Defer asks the customer; a finished Something else description leaves setup review open. Neither gives a whole-code Include or Exclude choice.',
      'Continue keeps saved choices without accepting suggestions. Unanswered and Not sure yet payments stay open. Split permission never selects treatment for the replacement payments.',
      'Back returns to the overtime assessment result. Its Back button opens the answered questionnaire.',
    ],
    state: [
      ...regularRateState(facts, true, true),
    ],
    welcome: 'Payments start under Needs your decision unless you saved a choice. I can explain each suggestion. Choose whether a payment counts, or select Not sure yet to leave it open. You can change or clear your choices without changing live payroll.',
    suggestions: ['Why was this earning included?', 'How are overtime payment codes different?', 'What is still awaiting review?'],
  }),
  summary: facts => ({
    name: 'Earning setup summary',
    purpose: 'The final summary of earning setup and who pays into the four benefit plans: the overtime method, optimization decisions, final earnings, plan contribution answers and questions for the customer, which the team can send, copy, print or download.',
    onScreen: [
      STATUS_PANEL,
      'Stats: codes to set up, suggestions accepted, overtime method, open questions',
      'Questions for the customer, grouped by topic, with Send to the customer, Copy questions and Add answer',
      ...(facts.legacyBonrevReview ? [
        'BONREV needs your team’s review: Review BONREV opens its fixed Deduction proposal. Check I understand, then select Apply answers. Leave for later closes without changes',
        'This is the team’s explicit acknowledgment for an older review, not a customer reply. The earlier question is kept in history but will not be sent again',
      ] : []),
      'Sections: Overtime method, Optimization decisions, Final classification and Who pays into each plan',
      'Review earning recommendations returns to the regular-rate decisions. Awaiting review items remain open; continuing never confirms them. Overtime payment codes is read-only',
      'Download CSV: the final classification and the open questions',
      'Actions: Download CSV, Print or save as PDF, Back, Return to Company Setup',
    ],
    state: [
      ...regularRateState(facts),
      `Codes to set up: ${count(facts.codesToSetUp)}${text(facts.byClassification) ? ` (${text(facts.byClassification)})` : ''}`,
      ...labeled('TIPS answer', facts.tipsAnswer),
      ...labeled('TIPS setup', facts.tipsSetup),
      ...labeled('TIPS OWED answer', facts.tipsOwedAnswer),
      ...labeled('TIPS OWED setup', facts.tipsOwedSetup),
      ...labeled('Left out', facts.leftOut),
      ...each('Combined', facts.combinedCodes),
      ...each('Relationship confirmed', facts.relatedCodes),
      ...labeled('Waiting on the customer', facts.waitingOnCustomer),
      ...labeled('Awaiting setup review; a name or description does not confirm a Ready code', facts.awaitingSetupReview),
      ...labeled('Benefit plans', entries(facts.plans).join('; ')),
      ...cellState(facts),
      ...mileageSummaryState(facts),
      ...(facts.legacyBonrevReview ? ['Needs the team’s acknowledgment: BONREV'] : []),
      `Optimization suggestions: accepted ${count(facts.suggestionsAccepted)}, kept as is ${count(facts.suggestionsKept)}, deferred ${count(facts.suggestionsWithCustomer)}`,
      `Overtime method: ${text(facts.overtimeMethod)}`,
      ...overtimeReason(facts),
      `Questions for the customer: ${count(facts.openQuestions)} open, ${count(facts.answeredQuestions)} answered, ${count(facts.notNeededQuestions)} no longer needed. ${facts.sent ? 'The questions were sent to the customer' : 'The questions haven’t been sent yet'}`,
      ...each('Open', facts.openByTopic),
      ...each('Saved AI-drafted customer questions', facts.draftedCustomerQuestions),
    ],
    welcome: 'You’re on the earning setup summary. I can cover what’s still open, how the questions reach the customer and what the final classification shows.',
    suggestions: ['What’s still open before setup?', 'How do I send the questions to the customer?', 'What does the CSV include?'],
  }),
} satisfies Record<EarningBrytePage | 'deductions' | 'taxes', AskBrytePageDescriber>

// Normalize the presentation glossary, including labels derived from earlier saved states.
// This changes neither facts' keys nor persisted answers.
function displayCopy<T>(value: T): T {
  if (typeof value === 'string') return reviewLaterCopy(value) as T
  if (Array.isArray(value)) return value.map(displayCopy) as T
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, displayCopy(item)])) as T
  }
  return value
}
export const earningPages = Object.fromEntries(
  Object.entries(pageDescriptions).map(([key, describe]) => [key, ((facts: AskBryteFacts) => displayCopy(describe(facts))) satisfies AskBrytePageDescriber]),
) as unknown as typeof pageDescriptions
