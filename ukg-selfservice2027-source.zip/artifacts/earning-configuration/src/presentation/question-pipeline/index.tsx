import { useCallback, useEffect, useRef, useState } from 'react'
import { Button } from '@ready/dls/compatibility'
import { SECTIONS } from './sections'
import './presentation.css'

function indexFromHash() {
  const id = typeof window === 'undefined' ? '' : window.location.hash.slice(1)
  const i = SECTIONS.findIndex(s => s.id === id)
  return i < 0 ? 0 : i
}

function isEditable(target: EventTarget | null) {
  if (!(target instanceof HTMLElement)) return false
  return target.isContentEditable || ['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName)
}

export default function QuestionPipelinePresentation() {
  const [index, setIndex] = useState(indexFromHash)
  const headingRef = useRef<HTMLHeadingElement>(null)
  const moved = useRef(false)
  const section = SECTIONS[index]

  const go = useCallback((next: number) => {
    const clamped = Math.max(0, Math.min(SECTIONS.length - 1, next))
    moved.current = true
    setIndex(clamped)
    window.history.replaceState(window.history.state, '', `#${SECTIONS[clamped].id}`)
  }, [])

  useEffect(() => {
    const previous = document.title
    document.title = 'How questions surface · Earning Configuration'
    const description = 'A read-only walkthrough separating the intended analysis pipeline from the current UI: classification, improvements and overtime review.'
    const metadata = [
      ['name', 'description', description],
      ['name', 'robots', 'noindex, nofollow'],
      ['property', 'og:title', document.title],
      ['property', 'og:description', description],
      ['name', 'twitter:title', document.title],
      ['name', 'twitter:description', description],
    ].map(([attribute, name, content]) => {
      const existing = document.head.querySelector<HTMLMetaElement>(`meta[${attribute}="${name}"]`)
      const element = existing ?? document.createElement('meta')
      const oldContent = element.getAttribute('content')
      element.setAttribute(attribute, name)
      element.content = content
      if (!existing) document.head.append(element)
      return () => {
        if (!existing) element.remove()
        else if (oldContent === null) element.removeAttribute('content')
        else element.content = oldContent
      }
    })
    return () => {
      document.title = previous
      metadata.forEach(restore => restore())
    }
  }, [])

  useEffect(() => {
    const onHash = () => { moved.current = true; setIndex(indexFromHash()) }
    window.addEventListener('hashchange', onHash)
    return () => window.removeEventListener('hashchange', onHash)
  }, [])

  useEffect(() => {
    if (!moved.current) return
    headingRef.current?.focus()
    window.scrollTo({ top: 0 })
  }, [index])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.altKey || e.ctrlKey || e.metaKey || e.shiftKey || isEditable(e.target)) return
      // A focused overflow region needs its native scrolling keys on narrow screens.
      if (e.target instanceof HTMLElement && e.target.closest('.qp-table-wrap, .qp-diagram__scroll')
        && ['ArrowRight', 'ArrowLeft', 'Home', 'End'].includes(e.key)) return
      const map: Record<string, number | undefined> = {
        ArrowRight: index + 1, PageDown: index + 1, ArrowLeft: index - 1, PageUp: index - 1, Home: 0, End: SECTIONS.length - 1,
      }
      const next = map[e.key]
      if (next === undefined) return
      e.preventDefault()
      go(next)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [index, go])

  return (
    <main className="qp" aria-label="Question pipeline presentation" data-testid="presentation-question-pipeline">
      <nav className="qp-index" aria-label="Presentation sections">
        <p className="qp-index__title">How questions surface</p>
        <ol>
          {SECTIONS.map((s, i) => (
            <li key={s.id}>
              <button type="button" aria-current={i === index ? 'step' : undefined} data-testid={`button-section-${s.id}`}
                onClick={() => go(i)}>
                <span className="qp-index__n">{i + 1}</span>{s.title}
              </button>
            </li>
          ))}
        </ol>
        <p className="qp-index__hint">Arrow keys, Page Up and Page Down move between sections.</p>
      </nav>

      <section className="qp-stage" aria-labelledby="qp-heading" key={section.id}>
        <p className="qp-kicker"><span data-testid="text-section-position">Section {index + 1} of {SECTIONS.length}</span> · {section.kicker}</p>
        <h1 id="qp-heading" ref={headingRef} tabIndex={-1} className="qp-heading">{section.title}</h1>
        <p className="qp-subtext" data-testid="text-section-subtext">{section.subtext}</p>
        <div className="qp-body">{section.body}</div>
        <div className="qp-controls">
          <Button variant="secondary" size="large" disabled={index === 0} onClick={() => go(index - 1)} data-testid="button-back">Back</Button>
          <span className="qp-progress" aria-hidden="true">
            {SECTIONS.map((s, i) => <i key={s.id} className={i === index ? 'is-current' : undefined} />)}
          </span>
          <Button variant="primary" size="large" disabled={index === SECTIONS.length - 1} onClick={() => go(index + 1)} data-testid="button-next">Next</Button>
        </div>
      </section>
    </main>
  )
}
