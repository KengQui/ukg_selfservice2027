import { renderToStaticMarkup } from 'react-dom/server'
import { describe, expect, it } from 'vitest'
import { DeferredReviewDiagram, PipelineDiagram, PipelineText } from './PipelineDiagram'
import { MAIN_FLOW, OPTIMIZATION_DEPENDENCY, UI_REVIEW_SEQUENCE, ROUTES, STAGES, SUBFLOW_EDGES, SUBFLOW_NODES } from './pipelineModel'
import { SECTIONS } from './sections'

describe('intended question pipeline contract', () => {
  it('shows the engine directly with explicit AI entry points, rule bypass and human decisions', () => {
    const section = SECTIONS.find(section => section.id === 'pipeline')!
    expect(section.title).toBe('Where the engine uses AI')
    const rendered = renderToStaticMarkup(<>{section.body}</>)
    const doc = new DOMParser().parseFromString(rendered, 'text/html')
    const engine = doc.querySelector('[data-testid="diagram-pipeline"]')!
    expect(engine).not.toBeNull()
    expect(engine.closest('details')).toBeNull()
    expect(doc.querySelector('[data-testid="diagram-ui-workflow"]')).toBeNull()
    expect([...engine.querySelectorAll('.qp-node--ai')].map(node => node.getAttribute('data-stage'))).toEqual(['extraction', 'ai'])
    expect(engine.querySelector('[data-stage="extraction"]')?.textContent).toContain('AI 1 · READ DOCUMENTS')
    expect(engine.querySelector('[data-stage="ai"]')?.textContent).toContain('AI 2 · UNRESOLVED ONLY')
    for (const id of ['evidence', 'rules', 'recommendation']) {
      expect(engine.querySelector(`[data-stage="${id}"]`)?.textContent).toContain('NO AI')
    }
    expect(engine.querySelector('[data-stage="decision"]')?.textContent).toContain('TEAM OR CUSTOMER · NOT AI')
    expect(engine.textContent).toContain('skip AI Analysis')
    expect(engine.textContent).toContain('Unresolved → use AI')
    expect(doc.body.textContent).toContain('Today’s demo uses scripted analysis')
    expect(doc.body.textContent).toContain('Confirmed purpose is a prerequisite')
  })

  it('keeps the two AI stages and requires confirmation before optimization', () => {
    expect(STAGES.filter(stage => stage.kind === 'ai').map(stage => stage.id)).toEqual(['extraction', 'ai'])
    for (const id of ['result', 'diagnosis', 'business', 'decision']) {
      expect(STAGES.find(stage => stage.id === id)?.kind).toBe('neutral')
    }
    for (const id of ['evidence', 'rules', 'recommendation']) {
      expect(STAGES.find(stage => stage.id === id)?.kind).toBe('deterministic')
    }
    expect(STAGES.map(stage => stage.title)).toEqual([
      'Extraction', 'Evidence Diagnosis', 'Deterministic Rules', 'Mapping Result', 'AI Analysis',
      'Mapping Diagnosis', 'Mapping action', 'Confirm mapping', 'Review confirmed',
      'Optimization', 'Optimization action', 'Business decision',
    ])
    expect(MAIN_FLOW.filter(edge => edge.to === 'business').map(edge => edge.from)).toEqual(['confirmed'])
    expect(MAIN_FLOW.some(edge => edge.from === 'diagnosis' && edge.to === 'business')).toBe(false)
    expect(MAIN_FLOW.some(edge => edge.from === 'decision' && edge.to === 'confirmed')).toBe(true)
    const doc = new DOMParser().parseFromString(renderToStaticMarkup(<PipelineDiagram />), 'text/html')
    expect(doc.querySelector('polyline[data-from="confirmed"][data-to="business"]')).not.toBeNull()
    expect(doc.querySelector('[data-stage="confirmed"]')?.textContent).toContain('REQUIRED GATE')
    expect(doc.body.textContent).not.toMatch(/parallel|neither feeds the other/i)
  })

  it('retains both matching paths, the evidence bypass, both return loops and separate deferral', () => {
    expect(ROUTES.map(route => route.id).sort()).toEqual(['lookup', 'unresolved', 'bypass', 'answer', 'documents', 'deferred'].sort())
    expect(ROUTES.find(route => route.id === 'lookup')?.description).toMatch(/skips AI Analysis/)
    expect(ROUTES.find(route => route.id === 'unresolved')?.description).toContain('Proposed')
    expect(ROUTES.find(route => route.id === 'bypass')?.description).toContain('straight to Mapping action')
    expect(ROUTES.find(route => route.id === 'answer')?.description).toContain('Deterministic Rules')
    expect(ROUTES.find(route => route.id === 'documents')?.description).toContain('Extraction')
    expect(ROUTES.find(route => route.id === 'deferred')?.description).toContain('unapplied answers stay pending')
    for (const id of ['bypass', 'answer', 'documents']) {
      expect(ROUTES.find(route => route.id === id)?.dashed).toBe(true)
    }
  })

  it('provides textual stage roles and every route outside the visual diagram', () => {
    const diagram = renderToStaticMarkup(<PipelineDiagram />)
    const text = renderToStaticMarkup(<PipelineText />)
    expect(diagram).toContain('role="img"')
    expect(diagram).toContain('<title')
    expect(diagram).toContain('<desc')
    expect(diagram.match(/qp-node--ai/g)).toHaveLength(2)
    for (const stage of STAGES) expect(text).toContain(stage.title)
    for (const route of ROUTES) expect(text).toContain(route.description)
    expect(text).toContain(OPTIMIZATION_DEPENDENCY)
  })

  it('keeps seven sections and the known-correction example separate from customer classification choices', () => {
    expect(SECTIONS).toHaveLength(7)
    const rendered = renderToStaticMarkup(<>{SECTIONS.find(section => section.id === 'examples')?.body}</>)
    const doc = new DOMParser().parseFromString(rendered, 'text/html')
    const bonus = [...doc.querySelectorAll('article')].find(article => article.querySelector('h3')?.textContent === 'BONREV')
    expect(bonus).toBeDefined()
    expect(bonus?.textContent).toContain('recovers a bonus already paid')
    expect(bonus?.textContent).toContain('I understand')
    expect(bonus?.textContent).toContain('Ask the customer')
    expect(bonus?.textContent).not.toContain('Defer')
    expect(bonus?.querySelector('.qp-quote')).toBeNull()
    expect(bonus?.querySelector('button')).toBeNull()
    const handoff = renderToStaticMarkup(<>{SECTIONS.find(section => section.id === 'finding-to-question')?.body}</>)
    expect(handoff).not.toContain('policy is still open')
    expect(handoff).toContain('Classification, then improvements, then overtime')
    expect(handoff).toContain('Allowances and reimbursements')
    expect(handoff).toContain('Waiting on the customer')
  })

  it('distinguishes the current UI gates from the intended engine confirmation requirement', () => {
    const handoff = renderToStaticMarkup(<>{SECTIONS.find(section => section.id === 'finding-to-question')?.body}</>)
    const doc = new DOMParser().parseFromString(handoff, 'text/html')
    expect([...doc.querySelectorAll('.qp-policy__steps h4')].map(heading => heading.textContent)).toEqual([
      'Classification', 'Improvements', 'Overtime review',
    ])
    for (const text of [
      UI_REVIEW_SEQUENCE.summary,
      UI_REVIEW_SEQUENCE.pending,
      UI_REVIEW_SEQUENCE.singleFinding,
      UI_REVIEW_SEQUENCE.boundary,
    ]) {
      expect(doc.body.textContent).toContain(text)
      expect(renderToStaticMarkup(<PipelineText />)).toContain(text)
    }
    expect(UI_REVIEW_SEQUENCE.boundary).toContain('mapping must be confirmed before optimization starts')
    expect(doc.body.textContent).toContain('counts as reviewed for classification')
    expect(doc.body.textContent).toContain('every question goes on one customer list at the summary')
    expect(doc.body.textContent).not.toContain('Internal Defer')
    expect(doc.body.textContent).toContain('does not automatically reassess or hold')
    expect(renderToStaticMarkup(<PipelineDiagram />)).toContain('not the order of screens')
    expect(handoff).toContain('does not change live questions or review pages')
    expect(doc.querySelector('[data-testid="recommendation-precedence"] button')).toBeNull()
  })

  it('assigns hypothetical combined findings to phases without claiming live per-code reassessment', () => {
    const rendered = renderToStaticMarkup(<>{SECTIONS.find(section => section.id === 'examples')?.body}</>)
    const doc = new DOMParser().parseFromString(rendered, 'text/html')
    const examples = [...doc.querySelectorAll('[data-testid^="card-combined-"]')]
    expect(examples).toHaveLength(3)
    for (const example of examples) {
      expect(example.textContent).toContain('Illustrative')
      expect(example.textContent).toContain('Suppose')
      expect([...example.querySelectorAll('dt')].map(label => label.textContent)).toEqual([
        'Findings', 'Evidence', 'Current classification phase', 'Current improvements phase', 'If pending in the current UI',
      ])
      expect(example.querySelector('button, input, select, textarea')).toBeNull()
    }
    const misc = doc.querySelector('[data-testid="card-combined-MISC7"]')?.textContent
    expect(misc).toContain('Unable to identify + potentially inactive')
    expect(misc).toContain('Ask what MISC7 pays for')
    const overtime = doc.querySelector('[data-testid="card-combined-OTPREM"]')?.textContent
    expect(overtime).toContain('Need more information + possible combination')
    expect(overtime).toContain('does not automatically reassess')
    expect(overtime).toContain('does not create a per-code hold')
    const bonus = doc.querySelector('[data-testid="card-combined-BONREV"]')?.textContent
    expect(bonus).toContain('Misclassified + potentially inactive')
    expect(bonus).toContain('Ask the team to check I understand')
    expect(bonus).toContain('the classification itself doesn’t change')
    expect(bonus).toContain('adds BONREV to the one customer list at the summary')
    expect(bonus).toContain('Acknowledgment is not a payroll write')
  })

  it('keeps engine return paths distinct from current UI answer handling across the presentation', () => {
    const after = renderToStaticMarkup(<>{SECTIONS.find(section => section.id === 'after-the-answer')?.body}</>)
    expect(after).toContain('Current UI: review, then continue')
    expect(after).toContain('Intended engine: where information returns')
    expect(after).toContain('do not run the intended engine or automatically reassess business suggestions')
    const all = renderToStaticMarkup(<>{SECTIONS.map(section => <div key={section.id}>{section.body}</div>)}</>)
    expect(all).not.toContain('A business finding with no unresolved mapping issue can go directly')
    expect(all).not.toContain('both findings stay pending')
    expect(all).not.toContain('Approved recommendation order')
    expect(all).not.toMatch(/parallel|neither feeds the other|independent findings/i)
    expect(all).toContain('Business analysis means optimization')
    expect(all).toContain('Optimization waits for mapping confirmation')
  })

  it('renders the deferred-review subflow from the shared model, linked to the engine Deferred route', () => {
    const section = SECTIONS.find(section => section.id === 'pipeline')!
    const doc = new DOMParser().parseFromString(renderToStaticMarkup(<>{section.body}</>), 'text/html')
    const engine = doc.querySelector('[data-testid="diagram-pipeline"]')!
    const inset = doc.querySelector('[data-testid="diagram-deferred-review"]')!
    expect(inset).not.toBeNull()
    expect(engine.compareDocumentPosition(inset) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy()
    expect(engine.textContent).toContain('Deferred review below')
    expect(engine.querySelector('a[href="#qp-deferred-review"]')).not.toBeNull()
    expect(inset.id).toBe('qp-deferred-review')
    // The summary is support only and never counted as an engine AI stage.
    expect(engine.querySelectorAll('.qp-node--ai')).toHaveLength(2)
    expect(inset.querySelectorAll('.qp-node--ai')).toHaveLength(0)
    expect(inset.querySelector('[data-substage="summary"]')?.textContent).toContain('SUPPORT ONLY')
    expect(SUBFLOW_NODES.filter(node => node.kind === 'support').map(node => node.id)).toEqual(['summary'])
    for (const node of SUBFLOW_NODES) expect(inset.querySelector(`[data-substage="${node.id}"]`)).not.toBeNull()
    for (const edge of SUBFLOW_EDGES) {
      expect(SUBFLOW_NODES.some(node => node.id === edge.from) && SUBFLOW_NODES.some(node => node.id === edge.to)).toBe(true)
      expect(inset.querySelector(`polyline[data-from="${edge.from}"][data-to="${edge.to}"]`)).not.toBeNull()
    }
  })

  it('connects Defer through explicit Apply and recheck to optimization with every branch', () => {
    const next = (from: string) => SUBFLOW_EDGES.filter(edge => edge.from === from && !edge.dashed).map(edge => edge.to)
    const chain = ['defer']
    while (next(chain.at(-1)!).length === 1 && chain.length < 10) chain.push(next(chain.at(-1)!)[0])
    expect(chain).toEqual(['defer', 'summary', 'capture', 'preview', 'apply', 'recheck', 'sub-optimization'])
    const has = (from: string, to: string) => SUBFLOW_EDGES.some(edge => edge.from === from && edge.to === to)
    expect(has('capture', 'save') && has('save', 'capture')).toBe(true)
    expect(has('preview', 'owning') && has('owning', 'preview')).toBe(true)
    expect(has('recheck', 'owning')).toBe(true)
    expect(has('owning', 'apply')).toBe(false)
    expect(has('no-deferral', 'sub-optimization')).toBe(true)
    expect(has('no-deferral', 'owning')).toBe(true)
    expect(has('no-deferral', 'confirmation')).toBe(true)
    expect(SUBFLOW_EDGES.find(edge => edge.id === 'no-deferral-optimization')?.description).toContain('without an empty review stop')
    expect(SUBFLOW_EDGES.find(edge => edge.id === 'no-deferral-optimization')?.description).toContain('confirmation-needed')
    expect(has('owning', 'custom-name')).toBe(true)
    expect(has('custom-name', 'preview')).toBe(true)
    expect(has('custom-name', 'sub-optimization')).toBe(false)
    expect(SUBFLOW_EDGES.find(edge => edge.id === 'capture-save')?.description).toContain('never applies')
    expect(SUBFLOW_EDGES.find(edge => edge.id === 'recheck-owning')?.description).toContain('never added to the deferred card or accepted automatically')
  })

  it('keeps the subflow text equivalent in sync and stays honest about planned AI stages', () => {
    const text = renderToStaticMarkup(<PipelineText />)
    for (const node of SUBFLOW_NODES) expect(text).toContain(node.title)
    for (const edge of SUBFLOW_EDGES) expect(text).toContain(edge.description)
    const inset = renderToStaticMarkup(<DeferredReviewDiagram />)
    expect(inset).toContain('role="img"')
    expect(inset).toContain('makes no decisions')
    const body = renderToStaticMarkup(<>{SECTIONS.find(section => section.id === 'pipeline')!.body}</>)
    expect(body).toContain('not yet implemented')
    expect(body).not.toMatch(/AI 1[^.]*(is|are) (now )?implemented/)
  })
})
