import { DEFERRED_REVIEW_FLOW, DEFERRED_REVIEW_NOTES, KIND_LABEL, SUBFLOW_EDGES, SUBFLOW_NODES, SUB_H, SUB_NODE_H, SUB_NODE_W, SUB_W, type SubflowNode, MAIN_FLOW, NODE_H, NODE_W, OPTIMIZATION_DEPENDENCY, UI_REVIEW_SEQUENCE, ROUTES, STAGES, VIEW_H, VIEW_W, type Point, type Stage } from './pipelineModel'

const pts = (points: Point[]) => points.map(p => p.join(',')).join(' ')

function Node({ stage }: { stage: Stage }) {
  const left = stage.x - NODE_W / 2
  return (
    <g className={`qp-node qp-node--${stage.kind}`} data-stage={stage.id}>
      <rect x={left} y={stage.y} width={NODE_W} height={NODE_H} rx={8} />
      {stage.kind === 'ai' && <rect className="qp-node__inner" x={left + 4} y={stage.y + 4} width={NODE_W - 8} height={NODE_H - 8} rx={5} />}
      <text x={left + 16} y={stage.y + 24} className="qp-node__kind">{stage.badge ?? KIND_LABEL[stage.kind].toUpperCase()}</text>
      <text x={left + 16} y={stage.y + 50} className="qp-node__title">{stage.title}</text>
      {stage.lines.map((line, i) => (
        <text key={line} x={left + 16} y={stage.y + 74 + i * 20} className="qp-node__line">{line}</text>
      ))}
    </g>
  )
}

export function PipelineDiagram() {
  return (
    <figure className="qp-diagram" data-testid="diagram-pipeline">
      <div className="qp-diagram__scroll" tabIndex={0} role="region" aria-label="Mapping pipeline diagram, scroll horizontally on smaller screens">
        <svg viewBox={`0 0 ${VIEW_W} ${VIEW_H}`} role="img" aria-labelledby="qp-diagram-title qp-diagram-desc">
          <title id="qp-diagram-title">Where AI is used in the intended payroll engine</title>
          <desc id="qp-diagram-desc">
            The engine has two AI stages: Extraction reads the documents, and AI Analysis proposes mappings only when
            aliases and authored rules cannot resolve them. A separate supporting AI summary appears only in the deferred review drawn below, and it makes no decisions. Evidence Diagnosis, Deterministic Rules and Recommendation
            do not use AI. Both mapping paths feed Mapping Diagnosis, an authored mapping action and human confirmation.
            Only a confirmed mapping proceeds to Optimization, then an authored optimization action and business decision.
            A deferred question goes through a supporting AI summary, captured answers, a separate review and an explicit Apply before a recheck; only then can optimization start. This describes the intended engine, not the order of screens.
            The UI separates classification, improvements and overtime review. A full text version follows the drawing.
          </desc>
          <defs>
            <marker id="qp-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
              <path d="M0,0 L10,5 L0,10 z" className="qp-arrowhead" />
            </marker>
          </defs>
          {MAIN_FLOW.map((edge, i) => (
            <polyline key={i} data-from={edge.from} data-to={edge.to} points={pts(edge.points)} className="qp-edge" markerEnd={edge.arrow ? 'url(#qp-arrow)' : undefined} />
          ))}
          {ROUTES.map(r => (
            <polyline key={r.id} points={pts(r.points)} className={`qp-edge${r.dashed ? ' qp-edge--dashed' : ''}`}
              markerEnd={r.arrow ? 'url(#qp-arrow)' : undefined} />
          ))}
          {ROUTES.filter(r => r.labelAt).map(r => (
            <text key={r.id} x={r.labelAt![0]} y={r.labelAt![1]} textAnchor={r.anchor} className="qp-route-label">
              {(r.labelLines ?? [r.label]).map((line, i) => <tspan key={line} x={r.labelAt![0]} dy={i ? 19 : 0}>{line}</tspan>)}
            </text>
          ))}
          <text x={612} y={742} className="qp-route-label">Confirmed only</text>
          {STAGES.map(s => <Node key={s.id} stage={s} />)}
        </svg>
      </div>
      <figcaption className="qp-legend">
        <span><i className="qp-swatch qp-swatch--ai" aria-hidden="true" /> AI 1 and AI 2: document reading and unresolved mappings (intended engine)</span>
        <span><i className="qp-swatch qp-swatch--ai" aria-hidden="true" /> AI summary in deferred review: context only, never a decision</span>
        <span><i className="qp-swatch qp-swatch--deterministic" aria-hidden="true" /> No AI: checks, lookups, rules and authored content</span>
        <span><i className="qp-swatch qp-swatch--neutral" aria-hidden="true" /> Gray: results and findings; decisions belong to people</span>
        <span><i className="qp-swatch qp-swatch--dashed" aria-hidden="true" /> Dashed: bypass or return path</span>
        <span><a href="#qp-deferred-review">Deferred route continues in Deferred review</a></span>
      </figcaption>
    </figure>
  )
}

function SubNode({ node }: { node: SubflowNode }) {
  const left = node.x - SUB_NODE_W / 2
  return (
    <g className={`qp-node qp-subnode qp-subnode--${node.kind}`} data-substage={node.id}>
      <rect x={left} y={node.y} width={SUB_NODE_W} height={SUB_NODE_H} rx={8} />
      <text x={left + 12} y={node.y + 22} className="qp-node__kind">{node.badge}</text>
      <text x={left + 12} y={node.y + 48} className="qp-node__title">{node.title}</text>
      {node.lines.map((line, i) => <text key={line} x={left + 12} y={node.y + 72 + i * 19} className="qp-node__line">{line}</text>)}
    </g>
  )
}

/** Focused inset for the engine's Deferred route; the engine diagram stays primary. */
export function DeferredReviewDiagram() {
  return (
    <figure className="qp-diagram qp-subflow" id="qp-deferred-review" data-testid="diagram-deferred-review">
      <p className="qp-subflow__title"><strong>Deferred review</strong> · continues the engine’s Deferred route · in the current UI</p>
      <div className="qp-diagram__scroll" tabIndex={0} role="region" aria-label="Deferred review subflow, scroll horizontally on smaller screens">
        <svg viewBox={`0 0 ${SUB_W} ${SUB_H}`} role="img" aria-labelledby="qp-sub-title qp-sub-desc">
          <title id="qp-sub-title">Deferred review subflow</title>
          <desc id="qp-sub-desc">
            Explicit Defer, then a supporting AI summary that makes no decisions, capture with the original controls, an outcome preview,
            an explicit Apply, a recheck and then optimization. Incomplete answers can be saved and resumed. Missing facts and new findings go
            to their owning questions and back to the preview. With no deferrals the page continues to optimization. An accepted custom name
            with a clear purpose counts as confirmed purpose. A full text version follows.
          </desc>
          <defs>
            <marker id="qp-sub-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
              <path d="M0,0 L10,5 L0,10 z" className="qp-arrowhead" />
            </marker>
          </defs>
          {SUBFLOW_EDGES.map(edge => (
            <polyline key={edge.id} data-from={edge.from} data-to={edge.to} points={pts(edge.points)}
              className={`qp-edge${edge.dashed ? ' qp-edge--dashed' : ''}`} markerEnd="url(#qp-sub-arrow)" />
          ))}
          {SUBFLOW_EDGES.filter(edge => edge.label).map(edge => (
            <text key={edge.id} x={edge.labelAt![0]} y={edge.labelAt![1]} textAnchor={edge.anchor} className="qp-route-label">{edge.label}</text>
          ))}
          {SUBFLOW_NODES.map(node => <SubNode key={node.id} node={node} />)}
        </svg>
      </div>
      <figcaption className="qp-legend">
        <span><i className="qp-swatch qp-swatch--support" aria-hidden="true" /> AI summary: supporting context only, not an engine stage or a decision</span>
        <span><i className="qp-swatch qp-swatch--gate" aria-hidden="true" /> Explicit confirmation and the optimization gate</span>
        <span><i className="qp-swatch qp-swatch--dashed" aria-hidden="true" /> Dashed: save, return or branch path</span>
      </figcaption>
    </figure>
  )
}

export function PipelineText() {
  return (
    <details className="qp-details" data-testid="details-pipeline-text">
      <summary>Read the pipeline as text</summary>
      <div className="qp-details__body">
        <ol className="qp-textflow">
          {STAGES.map(s => (
            <li key={s.id}><strong>{s.title}</strong> ({s.badge ?? KIND_LABEL[s.kind]}): {s.lines.join(' ')}.</li>
          ))}
        </ol>
        <p className="qp-muted">Routes</p>
        <ul className="qp-textflow">
          {ROUTES.map(r => <li key={r.id}><strong>{r.label}:</strong> {r.description}</li>)}
          <li><strong>Required order:</strong> {OPTIMIZATION_DEPENDENCY}</li>
        </ul>
        <p><strong>Current UI review sequence:</strong> {UI_REVIEW_SEQUENCE.summary}</p>
        <ol className="qp-textflow">
          {UI_REVIEW_SEQUENCE.steps.map(step => <li key={step.title}><strong>{step.title}:</strong> {step.detail}</li>)}
        </ol>
        <p>{UI_REVIEW_SEQUENCE.pending}</p>
        <p>{UI_REVIEW_SEQUENCE.singleFinding}</p>
        <p>{UI_REVIEW_SEQUENCE.boundary}</p>
        <p><strong>Deferred review:</strong> Defer, supporting summary, capture, separate review, explicit Apply, recheck, optimization.</p>
        <ol className="qp-textflow" data-testid="list-deferred-review">
          {DEFERRED_REVIEW_FLOW.map(step => (
            <li key={step.title}><strong>{step.title}</strong> ({step.status === 'implemented' ? 'In the current UI' : 'Future'}{step.ai ? ', AI context' : ''}): {step.detail}</li>
          ))}
        </ol>
        <p className="qp-muted">Deferred review subflow stages</p>
        <ol className="qp-textflow" data-testid="list-deferred-subflow">
          {SUBFLOW_NODES.map(node => <li key={node.id}><strong>{node.title}</strong> ({node.badge}): {node.lines.join('. ')}.</li>)}
        </ol>
        <p className="qp-muted">Deferred review subflow routes</p>
        <ul className="qp-textflow">
          {SUBFLOW_EDGES.map(edge => {
            const name = (id: string) => SUBFLOW_NODES.find(node => node.id === id)!.title
            return <li key={edge.id}><strong>{name(edge.from)} to {name(edge.to)}:</strong> {edge.description}</li>
          })}
        </ul>
        <ul className="qp-textflow">
          {DEFERRED_REVIEW_NOTES.map(note => <li key={note.title}><strong>{note.title}:</strong> {note.detail}</li>)}
        </ul>
      </div>
    </details>
  )
}
