/**
 * Intended engine: confirm mapping before optimization, per the approved dependency.
 * Landscape layout so the drawing uses the full content width on a laptop.
 * Change a stage or route here and both the drawing and its text equivalent update.
 */
export type StageKind = 'ai' | 'deterministic' | 'neutral'

export const KIND_LABEL: Record<StageKind, string> = {
  ai: 'AI judgment',
  deterministic: 'Deterministic',
  neutral: 'Neutral',
}

/** The existing UI phase order is separate from the intended engine architecture. */
export const UI_REVIEW_SEQUENCE = {
  title: 'Classification, then improvements, then overtime',
  summary: 'The team reviews classification across the codes before moving to improvements, then overtime review. Business questions are not interleaved after each code’s mapping decision.',
  steps: [
    { title: 'Classification', detail: 'Identify codes, agree to known corrections and answer clarification questions. Apply the answers, then open current deferred work, pending rounds or unfinished setup decisions directly. With no required review work left, continue to optimization without an empty review stop.' },
    { title: 'Improvements', detail: 'The UI calls this Optimize codes. Review suggestions to combine, split or stop using codes. Accept, keep as is or ask the customer, then review the decisions before continuing.' },
    { title: 'Overtime review', detail: 'Review the overtime questions and, when needed, sort the earning codes for weighted average overtime. Continue to the summary, where questions for the customer are collected together.' },
  ],
  pending: 'Ask the customer leaves an answer pending but counts as reviewed for classification round completion, not as a confirmed decision. It works the same way on every code, including BONREV, and every question goes on one customer list at the summary. Required deferred answers still need separate review and explicit Apply before optimization.',
  singleFinding: 'Even a code with no mapping issue waits for the improvements phase. The current UI does not automatically reassess or hold its business suggestion based on a related classification answer.',
  boundary: 'In the intended engine, mapping must be confirmed before optimization starts. Business analysis means optimization. The deferred-review flow below is how the UI enforces this for questions the team selected Defer for.',
}

/**
 * Deferred-review subflow. `status` separates what the current UI does from what is still future engine work.
 * Change a step here and the diagram text equivalent updates with it.
 */
export const DEFERRED_REVIEW_FLOW: { title: string; detail: string; status: 'implemented' | 'future'; ai?: boolean }[] = [
  { title: 'Defer', status: 'implemented', detail: 'Every required question needs an answer or an explicit Defer before moving on. Only the specific deferred question becomes a discussion card, one card per code in review order.' },
  { title: 'Supporting summary', status: 'implemented', ai: true, detail: 'When earlier answers exist, a separate AI process summarizes them, the established facts and the remaining gap. It is context only: it adds no questions, options, names, mappings or tax conclusions, and it never blocks saving or applying.' },
  { title: 'Capture', status: 'implemented', detail: 'Answer the deferred question with its original controls. Notes are optional and separate. Typing never changes the setup. Unfinished answers stay pending when you continue.' },
  { title: 'Inline review', status: 'implemented', detail: 'Each code keeps its follow-ups, checks and Summary in its card. Missing facts and checks keep that code pending without blocking other answers.' },
  { title: 'Explicit Apply', status: 'implemented', detail: 'Apply answer revalidates and commits only that code’s checked outcome and inseparable findings. Other drafts stay intact. Repeating, refreshing or reopening does not duplicate outcomes.' },
  { title: 'Recheck', status: 'implemented', detail: 'Applied answers are rechecked. New findings stay with their own review action and are never accepted automatically.' },
  { title: 'Optimization', status: 'implemented', detail: 'Continue with deferred questions still open, even with none answered. Suggestions use applied outcomes only. Back returns to pending questions; continuing never confirms setup readiness.' },
]

export const DEFERRED_REVIEW_NOTES = [
  { title: 'Unconfirmed setup notes', detail: 'A completed Something else answer may still need a setup decision. With no current deferred questions or pending rounds, the owning-question proposal opens directly. Earlier saved answers remain history; no Defer is invented, and explicit Apply is still required.' },
  { title: 'No deferrals', detail: 'Skip the deferred-review page. Open pending rounds first, then identifiable unfinished setup decisions, or optimization when its existing prerequisites are met. Missing question ownership shows a confirmation-needed state with saved history and Save and finish later, never an invented question.' },
  { title: 'Saved answers', detail: 'Back from optimization returns to pending deferred questions when there are any. Otherwise saved answers open as read-only history. Unapplied edits stay intact. Viewing history never reapplies answers.' },
  { title: 'Checking outcomes', detail: 'Authored choices use their existing rules. Typed answers and adaptive follow-ups use the appropriate live checking process in the owning question flow. The supporting summary never approves either kind of outcome.' },
  { title: 'Save and resume', detail: 'Save and finish later keeps captured answers, notes and the current step. Saving preserves progress; it never applies or completes anything.' },
  { title: 'New findings', detail: 'A finding raised by an applied answer keeps its existing review action and owning code. It is not added to the deferred card.' },
  { title: 'Custom name with a clear purpose', detail: 'A custom name the team accepts for an understood payment purpose counts as confirmed purpose, without inventing a Ready reference, classification, tax treatment or overtime rule. Facts still missing stay open.' },
  { title: 'Still future', detail: 'The scripted demo does not yet run AI Extraction or AI Analysis on uploaded documents. Re-entering Deterministic Rules from an answer is engine design; today the preview uses the prototype’s authored rules and checks.' },
]

export interface Stage {
  id: string
  title: string
  lines: string[]
  kind: StageKind
  /** Visible role label; highlights AI entry points and human decisions. */
  badge?: string
  /** Center x and top y in the drawing. */
  x: number
  y: number
}

export const VIEW_W = 1290
export const VIEW_H = 1090
export const NODE_W = 240
export const NODE_H = 110

export const STAGES: Stage[] = [
  { id: 'extraction', title: 'Extraction', kind: 'ai', badge: 'AI 1 · READ DOCUMENTS', x: 140, y: 40, lines: ['Read the customer’s documents', 'Extract payroll codes and facts'] },
  { id: 'evidence', title: 'Evidence Diagnosis', kind: 'deterministic', badge: 'NO AI · EVIDENCE CHECKS', x: 420, y: 40, lines: ['Unreadable, conflicting or', 'missing, before matching'] },
  { id: 'rules', title: 'Deterministic Rules', kind: 'deterministic', badge: 'NO AI · LOOKUP AND RULES', x: 700, y: 40, lines: ['Known aliases · authored rules', 'Resolve known mappings first'] },
  { id: 'result', title: 'Mapping Result', kind: 'neutral', x: 980, y: 40, lines: ['Provenance: Matched · Rule', 'Not yet a recommendation'] },
  { id: 'ai', title: 'AI Analysis', kind: 'ai', badge: 'AI 2 · UNRESOLVED ONLY', x: 980, y: 220, lines: ['Interpret the code’s meaning', 'Return a proposed mapping'] },
  { id: 'diagnosis', title: 'Mapping Diagnosis', kind: 'neutral', x: 980, y: 410, lines: ['Identify missing facts or', 'corrections needed for mapping'] },
  { id: 'recommendation', title: 'Mapping action', kind: 'deterministic', badge: 'NO AI · AUTHORED CONTENT', x: 980, y: 580, lines: ['Ask for facts or request', 'agreement to a correction'] },
  { id: 'decision', title: 'Confirm mapping', kind: 'neutral', badge: 'TEAM OR CUSTOMER · NOT AI', x: 600, y: 580, lines: ['Clarify · agree to a correction', 'Confirm what the code means'] },
  { id: 'confirmed', title: 'Review confirmed', kind: 'neutral', badge: 'REQUIRED GATE · NOT AI', x: 600, y: 780, lines: ['Required mapping or purpose', 'No unanswered required work'] },
  { id: 'business', title: 'Optimization', kind: 'neutral', badge: 'BUSINESS ANALYSIS', x: 980, y: 780, lines: ['Use confirmed setup facts', 'Consider combine, split, retire'] },
  { id: 'optimization-action', title: 'Optimization action', kind: 'deterministic', badge: 'NO AI · AUTHORED CONTENT', x: 980, y: 960, lines: ['Select the improvement', 'and its business question'] },
  { id: 'optimization-decision', title: 'Business decision', kind: 'neutral', badge: 'TEAM OR CUSTOMER · NOT AI', x: 600, y: 960, lines: ['Accept · keep as is', 'Or ask the customer'] },
]

export type Point = [number, number]

export interface Route {
  id: string
  label: string
  points: Point[]
  dashed?: boolean
  arrow?: boolean
  /** Label lines and position; omit for unlabeled connectors. */
  labelAt?: Point
  labelLines?: string[]
  anchor?: 'start' | 'end' | 'middle'
  description: string
}

/** Unlabeled forward connectors. */
export const MAIN_FLOW: { from: string; to: string; points: Point[]; arrow?: boolean }[] = [
  { from: 'extraction', to: 'evidence', points: [[260, 95], [300, 95]], arrow: true },
  { from: 'evidence', to: 'rules', points: [[540, 95], [580, 95]], arrow: true },
  { from: 'rules', to: 'result', points: [[820, 95], [860, 95]], arrow: true },
  { from: 'ai', to: 'diagnosis', points: [[980, 330], [980, 410]], arrow: true },
  { from: 'diagnosis', to: 'recommendation', points: [[980, 520], [980, 580]], arrow: true },
  { from: 'recommendation', to: 'decision', points: [[860, 635], [720, 635]], arrow: true },
  { from: 'decision', to: 'confirmed', points: [[600, 690], [600, 780]], arrow: true },
  { from: 'confirmed', to: 'business', points: [[720, 835], [860, 835]], arrow: true },
  { from: 'business', to: 'optimization-action', points: [[980, 890], [980, 960]], arrow: true },
  { from: 'optimization-action', to: 'optimization-decision', points: [[860, 1015], [720, 1015]], arrow: true },
]

export const ROUTES: Route[] = [
  {
    id: 'unresolved', label: 'Unresolved → use AI', arrow: true, points: [[980, 150], [980, 220]],
    labelAt: [992, 192], anchor: 'start',
    description: 'An unresolved mapping enters AI Analysis, which returns Proposed provenance.',
  },
  {
    id: 'lookup', label: 'Resolved by lookup or rules, skips AI Analysis', points: [[900, 150], [900, 180], [840, 180], [840, 370], [980, 370]],
    labelAt: [828, 280], labelLines: ['Resolved by lookup or rules:', 'skip AI Analysis'], anchor: 'end',
    description: 'A mapping resolved by aliases or authored rules skips AI Analysis and enters Mapping Diagnosis. It still needs confirmation before optimization.',
  },
  {
    id: 'bypass', label: 'Skips matching entirely', dashed: true, arrow: true,
    points: [[420, 40], [420, 14], [1270, 14], [1270, 635], [1100, 635]], labelAt: [432, 32], anchor: 'start',
    description: 'Evidence Diagnosis can go straight to Mapping action when the documents themselves are the problem. This does not bypass mapping confirmation.',
  },
  {
    id: 'answer', label: 'The customer’s answer re-enters Rules', dashed: true, arrow: true,
    points: [[560, 580], [560, 250], [640, 250], [640, 150]],
    labelAt: [548, 300], labelLines: ['The customer’s answer', 're-enters Rules'], anchor: 'end',
    description: 'A clarification answer returns to Deterministic Rules, not to AI.',
  },
  {
    id: 'documents', label: 'More documents', dashed: true, arrow: true,
    points: [[480, 665], [140, 665], [140, 150]], labelAt: [152, 690], anchor: 'start',
    description: 'New documents return to Extraction.',
  },
  {
    id: 'deferred', label: 'Deferred', arrow: true, points: [[480, 635], [370, 635]], labelAt: [360, 628], anchor: 'end',
    labelLines: ['Deferred: see', 'Deferred review below'],
    description: 'Deferred opens the subflow below: supporting summary, capture, inline outcome, explicit Apply, then recheck. Only applied outcomes inform optimization. You can continue with unanswered questions; unapplied answers stay pending.',
  },
]

export const OPTIMIZATION_DEPENDENCY = 'Confirm mapping or payment purpose before optimization. Business analysis means optimization: combining, splitting or retiring codes using confirmed setup facts. Deferred questions pass this gate only after their answers are reviewed and explicitly applied. An accepted custom name with a clear payment purpose counts as confirmed purpose, without establishing a Ready reference or other setup facts.'


/**
 * Focused deferred-review subflow, drawn as an inset under the engine from this model.
 * `support` is the AI summary: context only, never a decision. It is not one of the two engine AI stages.
 */
export type SubflowKind = 'support' | 'deterministic' | 'neutral' | 'gate'
export interface SubflowNode { id: string; title: string; badge: string; lines: string[]; kind: SubflowKind; x: number; y: number }
export interface SubflowEdge { id: string; from: string; to: string; points: Point[]; dashed?: boolean; label?: string; labelAt?: Point; anchor?: 'start' | 'end' | 'middle'; description: string }

export const SUB_W = 1290
export const SUB_H = 450
export const SUB_NODE_W = 190
export const SUB_NODE_H = 110

export const SUBFLOW_NODES: SubflowNode[] = [
  { id: 'defer', title: 'Explicit Defer', badge: 'TEAM · NOT AI', kind: 'neutral', x: 115, y: 40, lines: ['A required question', 'answered with Defer'] },
  { id: 'summary', title: 'Summary', badge: 'AI · SUPPORT ONLY', kind: 'support', x: 330, y: 40, lines: ['Earlier answers and gap', 'No decisions or options'] },
  { id: 'capture', title: 'Capture', badge: 'TEAM · NOT AI', kind: 'neutral', x: 545, y: 40, lines: ['Original answer controls', 'Notes stay separate'] },
  { id: 'preview', title: 'Inline summary', badge: 'RULES + REQUIRED CHECKS', kind: 'deterministic', x: 760, y: 40, lines: ['Show what this code changes', 'Nothing applied yet'] },
  { id: 'apply', title: 'Explicit Apply', badge: 'TEAM · NOT AI', kind: 'gate', x: 975, y: 40, lines: ['Revalidate and apply', 'once, no duplicates'] },
  { id: 'recheck', title: 'Recheck', badge: 'NO AI · RULES', kind: 'deterministic', x: 1190, y: 40, lines: ['Confirm mapping and', 'purpose decisions'] },
  { id: 'no-deferral', title: 'No deferrals', badge: 'SKIP EMPTY REVIEW', kind: 'neutral', x: 115, y: 260, lines: ['Open required work', 'or continue when ready'] },
  { id: 'confirmation', title: 'Confirmation needed', badge: 'NO SAFE QUESTION', kind: 'neutral', x: 330, y: 260, lines: ['View saved answers', 'Save and finish later'] },
  { id: 'save', title: 'Save and resume', badge: 'PRESERVES · NOT DONE', kind: 'neutral', x: 545, y: 260, lines: ['Incomplete answers', 'kept, never applied'] },
  { id: 'owning', title: 'Owning questions', badge: 'TEAM · NOT AI', kind: 'neutral', x: 760, y: 260, lines: ['Answer or Defer each', 'Never auto-accepted'] },
  { id: 'custom-name', title: 'Custom name', badge: 'ACCEPTED PURPOSE', kind: 'neutral', x: 975, y: 260, lines: ['Clear purpose counts', 'as confirmed purpose'] },
  { id: 'sub-optimization', title: 'Optimization', badge: 'REQUIRED GATE PASSED', kind: 'gate', x: 1190, y: 260, lines: ['Only when no required', 'review work remains'] },
]

export const SUBFLOW_EDGES: SubflowEdge[] = [
  { id: 'defer-summary', from: 'defer', to: 'summary', points: [[210, 95], [235, 95]], description: 'An explicit Defer creates one discussion card for that exact question.' },
  { id: 'summary-capture', from: 'summary', to: 'capture', points: [[425, 95], [450, 95]], description: 'The AI summary supports the discussion only, when relevant earlier answers exist. Otherwise, show the original question and evidence without a summary. It never changes an answer, Defer identity or resolution, and it never blocks saving or applying.' },
  { id: 'capture-preview', from: 'capture', to: 'preview', points: [[640, 95], [665, 95]], description: 'Each code’s checked outcome appears inline without waiting for other deferred answers.' },
  { id: 'preview-apply', from: 'preview', to: 'apply', points: [[855, 95], [880, 95]], description: 'Apply answer commits only this checked code and inseparable findings. Other answers stay pending.' },
  { id: 'apply-recheck', from: 'apply', to: 'recheck', points: [[1070, 95], [1095, 95]], description: 'Applied answers are rechecked with existing rules and checks.' },
  { id: 'recheck-optimization', from: 'recheck', to: 'sub-optimization', points: [[1250, 150], [1250, 260]], label: 'Confirmed only', labelAt: [1238, 195], anchor: 'end', description: 'Optimization opens directly only when mapping and purpose decisions are confirmed and no required review work remains.' },
  { id: 'capture-save', from: 'capture', to: 'save', dashed: true, points: [[525, 150], [525, 260]], label: 'Save and finish later', labelAt: [513, 200], anchor: 'end', description: 'Save and finish later keeps incomplete answers, notes and the current step. Saving preserves progress; it never applies or completes anything.' },
  { id: 'save-capture', from: 'save', to: 'capture', dashed: true, points: [[565, 260], [565, 150]], label: 'Resume', labelAt: [577, 230], anchor: 'start', description: 'Reopening returns to the saved step with answers intact.' },
  { id: 'preview-owning', from: 'preview', to: 'owning', dashed: true, points: [[700, 150], [700, 260]], label: 'Missing facts', labelAt: [688, 245], anchor: 'end', description: 'Missing facts or newly required decisions open the owning question flow. Each needs an answer or an explicit Defer.' },
  { id: 'owning-preview', from: 'owning', to: 'preview', dashed: true, points: [[760, 260], [760, 150]], description: 'Finish shows the inline outcome, without applying it.' },
  { id: 'recheck-owning', from: 'recheck', to: 'owning', dashed: true, points: [[1130, 150], [1130, 222], [820, 222], [820, 260]], label: 'New findings', labelAt: [1118, 214], anchor: 'end', description: 'New findings go back to their owning questions and keep their own review action. They are never added to the deferred card or accepted automatically.' },
  { id: 'owning-custom', from: 'owning', to: 'custom-name', dashed: true, points: [[855, 315], [880, 315]], description: 'The owning flow can confirm a clear payment purpose and an accepted custom name when no supplied Ready reference fits.' },
  { id: 'custom-preview', from: 'custom-name', to: 'preview', dashed: true, points: [[975, 260], [975, 235], [850, 235], [850, 150]], description: 'The accepted custom name returns to the outcome preview and still requires explicit Apply. It confirms purpose, not a Ready reference, classification, tax treatment or overtime rule. Missing facts stay open.' },
  { id: 'no-deferral-owning', from: 'no-deferral', to: 'owning', dashed: true, points: [[115, 260], [115, 200], [680, 200], [680, 260]], description: 'Without deferred questions, pending rounds open first. Otherwise identifiable unfinished setup decisions open their existing owning-question proposal directly, still requiring explicit Apply.' },
  { id: 'no-deferral-confirmation', from: 'no-deferral', to: 'confirmation', dashed: true, points: [[210, 315], [235, 315]], description: 'When a required decision has no safely identifiable question, keep saved answers available and allow saving for later. Do not invent a question or confirm a decision automatically.' },
  { id: 'no-deferral-optimization', from: 'no-deferral', to: 'sub-optimization', points: [[115, 370], [115, 410], [1190, 410], [1190, 370]], label: 'When ready', labelAt: [130, 436], anchor: 'start', description: 'With no deferred questions or pending round and the required purpose decisions confirmed, enter optimization without an empty review stop. If missing decision ownership cannot be established, stay in a confirmation-needed state with saved history and Save and finish later. Never infer confirmation.' },
]
