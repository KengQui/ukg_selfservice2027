import { Tag } from '@ready/dls/compatibility'
import { UI_REVIEW_SEQUENCE } from './pipelineModel'

export function RecommendationPrecedence() {
  const policy = UI_REVIEW_SEQUENCE
  return (
    <section className="qp-policy" aria-labelledby="qp-policy-heading" data-testid="recommendation-precedence">
      <div>
        <p className="qp-lane__kind">Current UI sequence</p>
        <h3 id="qp-policy-heading">{policy.title}</h3>
        <p>{policy.summary}</p>
      </div>
      <ol className="qp-policy__steps">
        {policy.steps.map((step, index) => (
          <li key={step.title}>
            <p className="qp-lane__kind">Step {index + 1} of {policy.steps.length}</p>
            <h4>{step.title}</h4>
            <p>{step.detail}</p>
          </li>
        ))}
      </ol>
      <div className="qp-callouts">
        <p><strong>Deferred or waiting</strong>{policy.pending}</p>
        <p><strong>Improvements stay in their phase</strong>{policy.singleFinding}</p>
        <p><strong>Engine confirmation requirement</strong>{policy.boundary}</p>
      </div>
      <p className="qp-muted">This sequence describes the current UI. The presentation does not change live questions or review pages.</p>
    </section>
  )
}

const COMBINED_EXAMPLES = [
  {
    code: 'MISC7',
    findings: 'Unable to identify + potentially inactive',
    evidence: 'Suppose MISC7 has no description and no activity in the supplied period.',
    first: 'Ask what MISC7 pays for. Its purpose is still unknown; no recent activity does not resolve the mapping.',
    next: 'Any continued-use question belongs in the later improvements phase, not immediately after this code’s answer. This hypothetical suggestion is not in the demo.',
    pending: 'Ask the customer adds the missing purpose to the customer list. Once classification review is complete, the UI can continue even while that answer is pending.',
  },
  {
    code: 'OTPREM',
    findings: 'Need more information + possible combination',
    evidence: 'Suppose OTPREM has unclear rate treatment and appears similar to another overtime code.',
    first: 'Clarify whether OTPREM pays only the extra 0.5× with regular pay paid separately, or the full 1.5× on its own.',
    next: 'Any combination question belongs in the later improvements phase. The current demo does not automatically reassess a combination suggestion using this rate answer.',
    pending: 'Ask the customer keeps rate treatment pending but counts as reviewed for classification. It does not create a per-code hold on improvements.',
  },
  {
    code: 'BONREV',
    findings: 'Misclassified + potentially inactive',
    evidence: 'Suppose BONREV is listed in earnings even though it recovers a paid bonus, and has no recent activity.',
    first: 'Ask the team to check I understand for the known deduction treatment. If the team isn’t sure what BONREV is used for, Ask the customer confirms its purpose; the classification itself doesn’t change.',
    next: 'Review improvements only after classification is complete. A continued-use question would belong there, not immediately after acknowledgment. Acknowledgment is not a payroll write.',
    pending: 'Ask the customer counts as reviewed and adds BONREV to the one customer list at the summary, the same as any other code.',
  },
]

export function CombinedFindingExamples() {
  return (
    <section className="qp-policy" aria-labelledby="qp-combined-heading">
      <div>
        <h3 id="qp-combined-heading">From mapping to optimization</h3>
        <p>In the intended engine, confirm the mapping before starting any optimization check. The examples below compare that dependency with the current demo’s review phases; they are not additional findings in the demo.</p>
      </div>
      <div className="qp-examples">
        {COMBINED_EXAMPLES.map(example => (
          <article key={example.code} className="qp-example" data-testid={`card-combined-${example.code}`}>
            <header><h4>{example.code}</h4><Tag type="status" color="neutral" label="Illustrative" /></header>
            <dl>
              <dt>Findings</dt><dd>{example.findings}</dd>
              <dt>Evidence</dt><dd>{example.evidence}</dd>
              <dt>Current classification phase</dt><dd>{example.first}</dd>
              <dt>Current improvements phase</dt><dd>{example.next}</dd>
              <dt>If pending in the current UI</dt><dd>{example.pending}</dd>
            </dl>
          </article>
        ))}
      </div>
    </section>
  )
}