import type { ReactNode } from 'react'
import { Tag } from '@ready/dls/compatibility'
import { DeferredReviewDiagram, PipelineDiagram, PipelineText } from './PipelineDiagram'
import { CombinedFindingExamples, RecommendationPrecedence } from './RecommendationPrecedence'

export interface Section {
  id: string
  title: string
  kicker: string
  subtext: string
  body: ReactNode
}

function Detail({ summary, children }: { summary: string; children: ReactNode }) {
  return (
    <details className="qp-details">
      <summary>{summary}</summary>
      <div className="qp-details__body">{children}</div>
    </details>
  )
}

const Illustrative = ({ label = 'Illustrative' }: { label?: string }) => <Tag type="status" color="neutral" label={label} />

const WhyWeAsk = (
  <>
    <ol className="qp-principles">
      <li><span>01</span><div><h3>Use what we know first</h3><p>Aliases, authored rules and the documents answer most rows before anyone is asked.</p></div></li>
      <li><span>02</span><div><h3>Ask only for what is still needed</h3><p>A missing fact, or a decision only the team or customer can make.</p></div></li>
      <li><span>03</span><div><h3>Make every recommendation traceable</h3><p>Evidence, provenance and finding travel with the question.</p></div></li>
    </ol>
    <div className="qp-callouts">
      <p><strong>A question is not proof of AI uncertainty.</strong> Questions can come from evidence checks, authored rules or optimization, not only from AI.</p>
      <p><strong>A known mapping can still need a decision.</strong> BONREV is known; the team still acknowledges the change.</p>
      <p><strong>Human review is separate from a proposed match.</strong> Proposed describes where a mapping came from, not whether it is approved.</p>
    </div>
    <p className="qp-not"><strong>Confirm mapping or purpose before optimization.</strong> Business analysis means optimization: deciding whether codes should be combined, split or retired. A clear purpose may use an accepted custom name; only separately confirmed setup facts support those later decisions.</p>
  </>
)

const Pipeline = (
  <div className="qp-stack">
    <div className="qp-ai-guide" aria-label="The two AI stages">
      <div><p className="qp-lane__kind">AI 1 · Extraction</p><h3>Read the documents</h3><p>Turn the customer’s payroll documents into codes and facts that the engine can check.</p></div>
      <div><p className="qp-lane__kind">AI 2 · Mapping analysis</p><h3>Interpret unresolved codes</h3><p>Propose a mapping only when aliases and authored rules cannot resolve it. Known mappings skip this AI stage.</p></div>
    </div>
    <PipelineDiagram />
    <DeferredReviewDiagram />
    <div className="qp-callouts">
      <p><strong>Rules select the questions</strong>Evidence checks and findings lead to authored recommendations. A question does not mean AI was uncertain or generated its wording.</p>
      <p><strong>People make the decisions</strong>The team or customer supplies facts, agrees to corrections and makes business choices. A proposed mapping is not approval.</p>
      <p><strong>Confirmed purpose is a prerequisite</strong>Optimization starts only after required mapping or purpose decisions are confirmed. Deferred answers count only after they are reviewed and explicitly applied; a summary or saved answer is not confirmation.</p>
    </div>
    <p className="qp-muted">AI 1 and AI 2 are intended engine design, not yet implemented. Today’s demo uses scripted analysis and sample questions for them. The deferred-review summary, capture, separate review and explicit Apply are in the current UI.</p>
    <PipelineText />
  </div>
)

const REASONS = [
  {
    origin: 'Evidence Diagnosis', when: 'Documents are unreadable, conflicting or missing. Knowable before matching.',
    need: 'Which source is current, a missing fact, or a readable copy', prompt: 'Your pay register and code list describe this code differently. Which one is current?',
    next: 'Answer returns to Rules; a new document returns to Extraction',
  },
  {
    origin: 'Mapping Diagnosis', when: 'Something is wrong or unresolved: Unable to identify, Misclassified, Need more information.',
    need: 'A missing fact, or agreement to a known correction', prompt: 'What does MISC7 pay for?',
    next: 'Answer returns to Deterministic Rules',
  },
  {
    origin: 'Optimization (business analysis)', when: 'After mapping is confirmed, consider combining, splitting or retiring codes.',
    need: 'A business decision', prompt: 'Can we combine OTMFG and OTSVC into one overtime code?',
    next: 'Accept, keep as is or ask the customer',
  },
]

const ThreeReasons = (
  <>
    <div className="qp-table-wrap" tabIndex={0} role="region" aria-label="Three reasons to ask">
      <table className="qp-table">
        <thead><tr><th scope="col">Origin</th><th scope="col">Triggering condition</th><th scope="col">What needs answering</th><th scope="col">Example prompt</th><th scope="col">Next action</th></tr></thead>
        <tbody>
          {REASONS.map(r => (
            <tr key={r.origin}>
              <th scope="row">{r.origin}</th><td>{r.when}</td><td>{r.need}</td><td className="qp-quote">{r.prompt}</td><td>{r.next}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
    <div className="qp-callouts">
      <p><strong>One code, two stages.</strong> Resolve and confirm its mapping first. Then optimization can assess whether the code could be improved.</p>
      <p><strong>Classification review comes first.</strong> The UI handles classification across the codes before opening the separate improvements phase. It does not interleave business questions after each code.</p>
      <p><strong>Clarification is a response type.</strong> Need more information asks for whatever is missing, which may be a fact rather than a document.</p>
      <p><strong>The evidence prompt is illustrative.</strong> The current demo does not detect document defects.</p>
    </div>
  </>
)

const AiStops = (
  <>
    <div className="qp-lanes">
      <div className="qp-lane qp-lane--ai"><p className="qp-lane__kind">AI judgment · 2 stages</p><ul><li>Extraction</li><li>AI Analysis on unresolved rows</li></ul></div>
      <div className="qp-lane qp-lane--det"><p className="qp-lane__kind">Deterministic</p><ul><li>Evidence Diagnosis</li><li>Aliases and authored rules</li><li>Recommendation lookup, content and routing</li></ul></div>
      <div className="qp-lane qp-lane--neutral"><p className="qp-lane__kind">Results, findings and decisions</p><ul><li>Mapping Result</li><li>Mapping Diagnosis</li><li>Mapping confirmation</li><li>Optimization after confirmation</li><li>Human decision by the team or customer</li></ul></div>
    </div>
    <h3 className="qp-subhead">Provenance says where a mapping came from</h3>
    <dl className="qp-provenance">
      <div><dt>Matched</dt><dd>Known alias lookup</dd></div>
      <div><dt>Rule</dt><dd>An authored rule</dd></div>
      <div><dt>Proposed</dt><dd>AI Analysis</dd></div>
    </dl>
    <p className="qp-not">Not a question category. Not a confidence score. Not an approval state. A Mapping Result is not yet a Recommendation.</p>
  </>
)

const HANDOFF = [
  ['Evidence + provenance', 'Document reference, Matched / Rule / Proposed'],
  ['Finding', 'Mapping diagnosis first; optimization after confirmation'],
  ['Authored recommendation', 'Lookup plus authored question content'],
  ['Requested decision', 'Fact, agreement or business choice'],
  ['Next route', 'Rules, Extraction or Deferred'],
]

const FindingToQuestion = (
  <>
    <RecommendationPrecedence />
    <h3 className="qp-subhead">What the intended engine passes to the review</h3>
    <ol className="qp-handoff">
      {HANDOFF.map(([t, d], i) => <li key={t}><span className="qp-handoff__n">{i + 1}</span><strong>{t}</strong><span>{d}</span></li>)}
    </ol>
    <h3 className="qp-subhead">Three things to keep apart</h3>
    <div className="qp-axes">
      <div><p className="qp-lane__kind">Diagnostic category</p><p>What is wrong or unresolved</p><p className="qp-muted">Unable to identify · Misclassified · Need more information</p></div>
      <div><p className="qp-lane__kind">Customer-list topic</p><p>How it is grouped for the customer</p><p className="qp-muted">Overtime · Allowances and reimbursements</p></div>
      <div><p className="qp-lane__kind">Answer state</p><p>Where it is now</p><p className="qp-muted">Waiting on the customer · Deferred · Answered</p></div>
    </div>
  </>
)

const EXAMPLES = [
  {
    code: 'Document conflict', tag: 'Illustrative', reason: 'Evidence Diagnosis: conflicting sources',
    evidence: 'Two documents describe one code differently.', answer: 'Which description is current, or an updated file.',
    route: 'Answer → Deterministic Rules. New document → Extraction.', prompt: 'Your code list and pay register describe this code differently. Which one should we use?',
  },
  {
    code: 'MISC7 / ADJ2', tag: 'Demo sample', reason: 'Mapping Diagnosis: Unable to identify',
    evidence: 'No description, or only “Adjustments”.', answer: 'What the code pays for.',
    route: 'Current UI: answer in classification, apply and review the results. Intended engine: answer returns to Rules.', prompt: 'What does MISC7 pay for?',
  },
  {
    code: 'OTPREM', tag: 'Demo sample', reason: 'Mapping Diagnosis: Need more information',
    evidence: 'Paid on the same hours as regular pay; rate treatment unclear.', answer: 'A fact: the extra 0.5× only, or the full 1.5× rate.',
    route: 'Current UI: answer in classification, apply and review the results. Intended engine: answer returns to Rules.', prompt: 'For someone who earns $20 an hour, does OTPREM pay only the extra $10 (0.5×) for each overtime hour, with the other $20 paid under regular pay? Or does it pay the full $30 (1.5×) on its own?',
  },
  {
    code: 'BONREV', tag: 'Demo sample', reason: 'Mapping Diagnosis: Misclassified',
    evidence: 'Listed in earnings. It recovers a bonus already paid, so by business purpose it is a deduction.',
    answer: 'Team acknowledgment of a known correction. No classification choice.',
    route: 'Check I understand, or Ask the customer when the team isn’t sure (added to the customer list like any other code)', prompt: null,
  },
  {
    code: 'OTMFG + OTSVC / BONUS', tag: 'Demo sample', reason: 'Optimization: combine or split after mapping is confirmed',
    evidence: 'Same Ready reference by department; one bonus code for two bonus types.', answer: 'A business decision.',
    route: 'In the improvements phase: accept, keep as is or ask the customer', prompt: 'Some of your bonuses are promised ahead of time for meeting a goal. Others are decided afterward, like a holiday gift. Only the promised kind counts toward overtime pay, so can we give each kind its own code?',
  },
]

const Examples = (
  <>
  <div className="qp-examples">
    {EXAMPLES.map(e => (
      <article key={e.code} className="qp-example" data-testid={`card-example-${e.code}`}>
        <header><h3>{e.code}</h3><Illustrative label={e.tag} /></header>
        <dl>
          <dt>Reason</dt><dd>{e.reason}</dd>
          <dt>Evidence</dt><dd>{e.evidence}</dd>
          <dt>Requested</dt><dd>{e.answer}</dd>
          <dt>Route</dt><dd>{e.route}</dd>
        </dl>
        {e.prompt
          ? <p className="qp-quote">{e.prompt}</p>
          : <p className="qp-muted">Never shown to the customer as a choice of classification.</p>}
      </article>
    ))}
  </div>
  <CombinedFindingExamples />
  </>
)

const COMPARE = [
  ['Document reading', 'AI Extraction', 'Scripted sample register'],
  ['Matching', 'Aliases, rules, then AI on the tail', 'Scripted statuses'],
  ['Evidence defects', 'Detected before matching', 'Not detected'],
  ['Questions', 'Authored from findings', 'Sample questions'],
  ['Engine order', 'Confirm mapping or purpose → optimization → business decision', 'Review → explicit Apply → improvements → overtime → summary'],
  ['Pending mapping', 'Optimization waits for mapping confirmation', 'A question on the customer list can allow later phases to proceed'],
  ['Optimization', 'Uses confirmed setup facts to consider combine, split or retire', 'Separate improvement phase; no automatic same-code reassessment'],
  ['Customer answers', 'Clarification returns to Rules', 'Team enters answers from the summary; no engine rerun'],
  ['Progress', 'To be defined', 'Held in the browser'],
]

const AfterAnswer = (
  <>
    <h3 className="qp-subhead">Current UI: review, then continue</h3>
    <p>During classification, the team applies answers, sees a scripted recheck and reviews the results. Any further classification questions stay in that phase. Once every flagged code is resolved or on the customer list, the team can review improvements, then overtime and the summary.</p>
    <p>From the summary, the team can enter answers to questions marked as sent. Those answers update the demo’s saved decisions; they do not run the intended engine or automatically reassess business suggestions.</p>
    <h3 className="qp-subhead">Intended engine: where information returns</h3>
    <div className="qp-routes">
      <div><p className="qp-lane__kind">Clarification answer</p><p>Re-enters Deterministic Rules</p></div>
      <div><p className="qp-lane__kind">New documents</p><p>Return to Extraction</p></div>
      <div><p className="qp-lane__kind">Deferred</p><p>Separate exit, stays pending</p></div>
    </div>
    <p className="qp-not">In the intended engine, these return paths stay in mapping until it is confirmed. Optimization cannot start with an unresolved mapping.</p>
    <h3 className="qp-subhead">Current UI: two decisions, two meanings</h3>
    <div className="qp-routes">
      <div><p className="qp-lane__kind">Team acknowledgment</p><p>The team accepts a known change by checking I understand for BONREV.</p><p className="qp-muted">Recorded as acknowledged. Applied later with the other answers.</p></div>
      <div><p className="qp-lane__kind">Ask the customer</p><p>Only the customer knows the fact or owns the business choice.</p><p className="qp-muted">Added to the customer list. Still awaiting an answer, but counts as reviewed so later phases can proceed.</p></div>
    </div>
    <p className="qp-not">None of these writes to payroll on its own. This page sends nothing and changes nothing.</p>
    <div className="qp-table-wrap" tabIndex={0} role="region" aria-label="Intended design compared with current demo">
      <table className="qp-table qp-table--compact">
        <thead><tr><th scope="col">Area</th><th scope="col">Intended design</th><th scope="col">Current demo</th></tr></thead>
        <tbody>{COMPARE.map(([a, b, c]) => <tr key={a}><th scope="row">{a}</th><td>{b}</td><td>{c}</td></tr>)}</tbody>
      </table>
    </div>
    <Detail summary="Engineering discussion points">
      <p className="qp-muted">Explanatory contracts, not implemented service or schema guarantees.</p>
      <ul className="qp-compact">
        <li><strong>Evidence references:</strong> which document and location supports each finding.</li>
        <li><strong>Provenance:</strong> Matched, Rule or Proposed on every Mapping Result.</li>
        <li><strong>Engine dependency:</strong> required mapping or purpose decisions precede optimization. A clear purpose with an accepted custom name does not establish other setup facts.</li>
        <li><strong>Review phases:</strong> preserve classification, improvements and overtime as separate UI phases.</li>
        <li><strong>Pending mappings:</strong> the intended engine holds optimization until confirmation. The current UI’s customer-list behavior does not yet enforce this dependency.</li>
        <li><strong>Requested decision:</strong> fact, agreement or business choice.</li>
        <li><strong>Unresolved status:</strong> how Deferred and waiting items stay visible.</li>
      </ul>
    </Detail>
  </>
)

export const SECTIONS: Section[] = [
  { id: 'why-we-ask', subtext: 'Separate how findings arise from how the team reviews them. These seven read-only sections explain both; nothing here reads documents or sends questions.', kicker: 'Objective', title: 'Why we ask', body: WhyWeAsk },
  { id: 'pipeline', subtext: 'AI reads documents and helps with unresolved mappings. Confirm mapping or payment purpose before optimization; the diagram shows the AI stages and this required order.', kicker: 'Intended engine', title: 'Where the engine uses AI', body: Pipeline },
  { id: 'three-reasons', subtext: 'Every question has one origin. The origin decides what kind of answer is needed.', kicker: 'Taxonomy', title: 'Three reasons to ask', body: ThreeReasons },
  { id: 'ai-and-rules', subtext: 'The design uses AI in exactly two places. Everything else is lookup, authored content or routing.', kicker: 'Boundaries', title: 'Where AI stops and rules take over', body: AiStops },
  { id: 'finding-to-question', subtext: 'Review classification across the codes before considering improvements, then check overtime. This is the current UI sequence.', kicker: 'Current UI', title: 'The review sequence', body: FindingToQuestion },
  { id: 'examples', subtext: 'Static examples show which review phase each question belongs to. Document defects and combined findings are illustrative, not live detection.', kicker: 'Walkthrough', title: 'Examples people can follow', body: Examples },
  { id: 'after-the-answer', subtext: 'The demo updates review decisions; the intended engine has its own return paths. Keeping them separate makes the limits clear.', kicker: 'UI and engine', title: 'What happens after the answer', body: AfterAnswer },
]
