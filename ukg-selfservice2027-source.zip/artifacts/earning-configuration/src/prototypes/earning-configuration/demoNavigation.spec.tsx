import { act } from 'react'
import { createRoot } from 'react-dom/client'
import { MemoryRouter } from 'react-router-dom'
import { renderToStaticMarkup } from 'react-dom/server'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { EARNING_DEMO_SETTINGS } from './demoSettings'
import { canEnterOptimization, discussionEntries, previewCanApply, previewCurrent, previewWorkIds } from './deferredReview'
import {
  canSubmitRound, createSession, currentRound, demoNavigationAllowed, effectiveOvertime, parseSession,
  reduceSession, reviewPages, reviewPosition, type EarningSession, type SessionAction,
} from './session'
import { routingDeferred, routingLegacy, routingOpen, routingReady, routingRun as run, routingSetup } from './reviewRouting.testing'
import { SAMPLE_REGISTER_FILES } from './sampleDocument'
import { ASK_CUSTOMER, CLEAR_CHOICE } from './sampleRegister'
import { SOMETHING_ELSE } from './somethingElse'
import { overtimeMethod } from './overtime'
import { OPTIMIZATIONS, appliedOptimization, optimizationCounts } from './optimization'
import { canMoveToPage, reviewSteps } from './reviewStatus'
import { sessionCodeStatus } from './sessionCodeStatus'
import { browserStores, loadSession, saveSession, writeWorkingCopy } from './storage'
import { SessionContext } from './sessionContext'
import { EarningSessionProvider, useEarningSession } from './SessionProvider'
import StepReview from './StepReview'
import StepDiscussionWork from './StepDiscussionWork'
import StepDiscussionReview from './StepDiscussionReview'
import StepCategorySelection from './StepCategorySelection'
import { StepOptimization } from './StepOptimization'
import { StepOvertime } from './StepOvertime'
import StepSummary from './StepSummary'
import AppliedReviewQuestions from './AppliedReviewQuestions'
import { TIPS_METHOD_OPTIONS, tipsMethodQuestion } from './tips'
import { finalConfiguration } from './configuration'
import { sortEarnings } from './overtime'
import { customerQuestionList, groupQuestions, questionsEmailText, summaryCsv } from './summary'
import { bryteFacts } from './bryteFacts'

vi.mock('@workspace/api-client-react', () => ({ summarizeEarningDiscussion: () => new Promise(() => {}) }))
const restore = (session: EarningSession) => {
  const parsed = parseSession(JSON.stringify(session))
  expect(parsed).not.toBeNull()
  return parsed!
}
const original = () => run({ ...createSession(1), files: [...SAMPLE_REGISTER_FILES] }, { type: 'startReview' })
const endpoint = (session: EarningSession) => run(session, { type: 'moveReview', index: reviewPages(session).length - 1 })
const skip = (session: EarningSession) => run(session, { type: 'continueDemoReview' })
const onlyNavigation = (session: EarningSession) => {
  const { step, updatedAt, demoReviewReturn, reviewCursor, lastEarningStep, appliedReview, ...data } = session
  return data
}
const markup = (session: EarningSession, node: React.ReactNode) => renderToStaticMarkup(
  <SessionContext.Provider value={{ session, dispatch: () => {}, save: () => true, restart: () => true }}>{node}</SessionContext.Provider>)

beforeEach(() => {
  EARNING_DEMO_SETTINGS.ungateForwardButtons = true
  EARNING_DEMO_SETTINGS.hideOptionalQuestions = true
  localStorage.clear(); sessionStorage.clear()
})
afterEach(() => {
  EARNING_DEMO_SETTINGS.ungateForwardButtons = false
  EARNING_DEMO_SETTINGS.hideOptionalQuestions = false
  localStorage.clear(); sessionStorage.clear()
})

describe('demo navigation is not payroll readiness', () => {
  it.each([false, true])('traverses unanswered original pages with partial work %s without applying it', partial => {
    let session = original()
    if (partial) session = run(session,
      { type: 'choose', itemId: 'TIPS', choice: 'payroll' }, // required method follow-up left open
      { type: 'choose', itemId: 'BONREV', choice: ASK_CUSTOMER },
      { type: 'describe', itemId: 'ADJ2', description: 'An unfinished description' })
    const before = onlyNavigation(session)
    for (let index = 1; index < reviewPages(session).length; index++) {
      expect(canMoveToPage(session, index)).toBe(true)
      session = run(session, { type: 'moveReview', index })
      expect(reviewPosition(session).index).toBe(index)
    }
    expect(reviewSteps(session).some(step => step.state === 'completed')).toBe(false)
    expect(canSubmitRound(session)).toBe(false)
    expect(run(session, { type: 'submitRound' })).toBe(session)
    session = skip(session)
    expect(session.step).toBe('optimization')
    expect(canEnterOptimization(session)).toBe(false)
    const overtime = run(session, { type: 'submitOptimization' })
    expect(overtime.step).toBe('overtime')
    expect(overtime.optimization).toEqual(session.optimization)
    expect(overtimeMethod(effectiveOvertime(overtime)).kind).toBe('open')
    expect(run(overtime, { type: 'reviewOvertimeSort' })).toBe(overtime)
    expect(run(overtime, { type: 'goTo', step: 'overtimeSort' })).toBe(overtime)
    const summary = run(overtime, { type: 'confirmOvertime' })
    expect(summary.step).toBe('summary')
    for (const state of [session, overtime, summary, restore(summary)]) {
      expect(onlyNavigation(state)).toEqual(before)
      const unfinished = sessionCodeStatus(state).rows.filter(row => ['ADJ2', 'MISC7', 'TIPS'].includes(row.code))
      expect(unfinished.some(row => row.status === 'ready' || row.status === 'combined' || row.status === 'split')).toBe(false)
    }
    expect(run(overtime, { type: 'backFromOvertime' }, { type: 'backFromOptimization' }).step).toBe('questions')
  })

  it.each(['added-questions', undefined] as const)('skips incomplete %s rounds and retains applied history', kind => {
    const ready = routingReady()
    let session: EarningSession = { ...ready, step: 'questions', reviewCursor: 0,
      rounds: [...ready.rounds, { number: 3, itemIds: ['TIPS', 'OTMFG'], submitted: false, ...(kind ? { kind } : {}) }] }
    session = endpoint(session)
    const optimization = skip(session)
    expect(optimization.step).toBe('optimization')
    expect(restore(optimization).step).toBe('optimization')
    const back = run(optimization, { type: 'backFromOptimization' })
    expect(back.step).toBe('questions')
    expect(back.rounds).toEqual(session.rounds)
    expect(back.answers).toEqual(session.answers)
    expect(run(back, { type: 'choose', itemId: 'BONREV', choice: ASK_CUSTOMER }).answers.BONREV).toEqual(ready.answers.BONREV)
  })

  it.each(['deferred', 'confirmation', 'setup', 'required', 'proposal'] as const)('preserves %s work, notes and proposals through skip, reload and Back', kind => {
    let session = kind === 'confirmation' ? routingLegacy()
      : kind === 'setup' ? routingSetup() : routingDeferred()
    if (kind === 'required' || kind === 'proposal') {
      const entry = discussionEntries(session)[0]
      session = run(session, { type: 'setDiscussionAnswer', itemId: entry.itemId, question: entry.question,
        basis: entry.basis, kind: 'review-choices', change: { choice: 'accept' } },
      { type: 'prepareDiscussionReview' })
      if (kind === 'required') session = run(session, { type: 'reviewDiscussionWork' })
    }
    session = run(session, { type: 'setCallAnswer', itemId: 'BONREV', text: 'Keep this discussion note.' })
    if (session.discussionPreview) session = run(session, { type: 'setDiscussionWorkDraft', key: 'draft', value: 'Unapplied draft text.' })
    const component = session.step === 'discussionWork' ? <StepDiscussionWork />
      : session.step === 'discussionReview' ? <StepDiscussionReview /> : <StepReview />
    expect(markup(session, component)).toContain('Continue to optimization')
    const before = onlyNavigation(session)
    const optimization = skip(session)
    expect(optimization.step).toBe('optimization')
    expect(onlyNavigation(optimization)).toEqual(before)
    expect(restore(optimization).discussionPreview).toEqual(session.discussionPreview)
    const returned = run(restore(optimization), { type: 'backFromOptimization' })
    expect(returned.step).toBe(session.step)
    expect(onlyNavigation(returned)).toEqual(before)
    if (session.discussionPreview) expect(previewCurrent(returned)).toBe(true)
    const history = run(returned, { type: 'viewAppliedReview' })
    expect(history.appliedReview).toBeDefined()
    expect(markup(history, <AppliedReviewQuestions />)).toContain('These answers have already been applied.')
    expect(run(history, { type: 'choose', itemId: 'BONREV', choice: 'accept' })).toBe(history)
    expect(run(history, { type: 'applyDiscussionReview' })).toBe(history)
    expect(run(restore(history), { type: 'closeAppliedReview' }).discussionPreview).toEqual(session.discussionPreview)
  })

  it('keeps unfinished Optimization editable, including Something else drafts, and requires an actual Yes for sorting', () => {
    let session = skip(endpoint(original()))
    session = run(session, { type: 'chooseOptimization', suggestionId: 'split-bonus', choice: SOMETHING_ELSE },
      { type: 'updatePhaseSomethingElse', key: 'optimization:split-bonus', update: { kind: 'describe', description: 'Unfinished optimization note' } })
    const before = session.optimization
    session = run(session, { type: 'submitOptimization' })
    expect(session.step).toBe('overtime')
    expect(session.optimization).toEqual(before)
    session = run(restore(session), { type: 'backFromOvertime' },
      { type: 'chooseOptimization', suggestionId: 'split-bonus', choice: 'keep' }, { type: 'submitOptimization' })
    expect(session.optimization).toMatchObject({ completed: false, submitted: false, answers: { 'split-bonus': 'keep' } })
    expect(run(session, { type: 'reviewOvertimeSort' })).toBe(session)
    session = run(session, { type: 'answerOvertime', questionId: 'multiRate', answer: 'yes' }, { type: 'reviewOvertimeSort' })
    expect(session.step).toBe('overtimeSort')
    expect(session.resolutions).toEqual({})
    expect(run(session, { type: 'resolveMixedEarning', code: 'BONUS', choice: ASK_CUSTOMER })).toBe(session)
    expect(sortEarnings(finalConfiguration(session)).awaiting.some(row => row.code === 'BONUS')).toBe(true)
    expect(restore(session).optimization).toEqual(session.optimization)
    session = run(session, { type: 'goTo', step: 'overtime' }, { type: 'backFromOvertime' },
      { type: 'chooseOptimization', suggestionId: 'split-bonus', choice: CLEAR_CHOICE })
    expect(restore(session).optimization.answers).toEqual({})
  })

  it('does not promote a partially accepted optimization into confirmed outputs or sorting recommendations', () => {
    const optimization = run(skip(endpoint(original())),
      { type: 'chooseOptimization', suggestionId: 'split-bonus', choice: 'accept' })
    const overtime = run(optimization, { type: 'submitOptimization' })
    const summary = run(overtime, { type: 'confirmOvertime' })
    for (const session of [overtime, summary, restore(summary)]) {
      const rows = finalConfiguration(session)
      expect(rows.some(row => row.code === 'BONUS-ND' || row.code === 'BONUS-D')).toBe(false)
      expect(rows.find(row => row.code === 'BONUS')?.status).toBe('pending')
      expect(sortEarnings(rows).awaiting.some(row => row.code === 'BONUS')).toBe(true)
      expect(session.optimization).toEqual(optimization.optimization)
    }
  })

  it.each(['accept', 'keep', ASK_CUSTOMER, SOMETHING_ELSE] as const)('keeps partial %s choices out of confirmed labels, email, Send and CSV decisions', choice => {
    let session = run(skip(endpoint(original())), { type: 'chooseOptimization', suggestionId: 'split-bonus', choice })
    if (choice === SOMETHING_ELSE) session = run(session, { type: 'updatePhaseSomethingElse',
      key: 'optimization:split-bonus', update: { kind: 'describe', description: 'Keep this draft description.' } })
    const draft = session.optimization
    session = restore(run(session, { type: 'submitOptimization' }, { type: 'confirmOvertime' }))
    expect(session.step).toBe('summary')
    expect(customerQuestionList(session)).toEqual([])
    const suggestion = OPTIMIZATIONS.find(entry => entry.id === 'split-bonus')!
    expect(questionsEmailText(groupQuestions(customerQuestionList(session)))).not.toContain(suggestion.customerQuestion)
    expect(run(session, { type: 'sendQuestions', to: 'payroll@example.test' })).toBe(session)
    expect(session.sent).toBeUndefined()
    const html = markup(session, <MemoryRouter><StepSummary /></MemoryRouter>)
    expect(html).toContain('Draft answer:')
    expect(html).toContain('Finish optimization to confirm this answer.')
    expect(html).not.toContain('Send to the customer')
    expect(html).not.toContain('Copy questions')
    expect(optimizationCounts(appliedOptimization(session.optimization))).toEqual({ accepted: 0, kept: 0, customer: 0, described: 0 })
    expect(bryteFacts(session).facts).toMatchObject({ suggestionsAccepted: 0, suggestionsKept: 0, suggestionsWithCustomer: 0 })
    const csvRow = summaryCsv(session, () => 'Saved earlier').split('\n').find(row => row.startsWith('"Optimization","BONUS"'))!
    expect(csvRow).toContain('"Draft"')
    expect(csvRow).toContain('Draft answer:')
    expect(csvRow).not.toMatch(/"(Accepted|Deferred|Kept as is|Something else)"/)
    expect(session.optimization).toEqual(draft)
    const back = run(session, { type: 'goTo', step: 'overtime' }, { type: 'backFromOvertime' })
    expect(back.optimization).toEqual(draft)
    expect(back.optimization.completed).toBe(false)
  })

  it('creates a sendable optimization question only after actual completion, without rewriting old sent history', () => {
    let session = run(skip(endpoint(original())),
      { type: 'chooseOptimization', suggestionId: 'split-bonus', choice: ASK_CUSTOMER },
      { type: 'submitOptimization' }, { type: 'confirmOvertime' })
    const prior = { id: 'optimization:split-bonus', question: 'Exact wording from an earlier send.' }
    session = run(session, { type: 'goTo', step: 'optimization' })
    for (const suggestion of OPTIMIZATIONS.filter(entry => entry.id !== 'split-bonus'))
      session = run(session, { type: 'chooseOptimization', suggestionId: suggestion.id, choice: 'keep' })
    session = run(session, { type: 'submitOptimization' })
    expect(session.optimization.completed).toBe(true)
    const question = customerQuestionList(session).find(entry => entry.id === prior.id)!
    expect(question.status).toBe('open')
    const summary = run(session, { type: 'confirmOvertime' }, { type: 'sendQuestions', to: 'payroll@example.test' })
    expect(summary.sent?.questionIds).toContain(prior.id)
    const saved = { ...summary, optimization: { ...summary.optimization, completed: false, submitted: false },
      sent: { ...summary.sent!, questions: [{ ...question, question: prior.question }] } }
    const restored = restore(saved)
    expect(restored.sent).toEqual(saved.sent)
    expect(customerQuestionList(restored).find(entry => entry.id === prior.id)).toMatchObject({ question: prior.question, status: 'notNeeded' })
    expect(run(restored, { type: 'sendQuestions', to: 'payroll@example.test' })).toBe(restored)
  })

  it('bypasses genuinely unanswered required findings without allowing Finish or Apply, retaining drafts on return', () => {
    const answer = { choice: 'pool' }
    let session = run({ ...routingOpen(['TIPS']), answers: { TIPS: answer } },
      { type: 'answerFollowUp', itemId: 'TIPS', questionId: 'tips-method', choice: ASK_CUSTOMER },
      { type: 'selectDeferredQuestion', itemId: 'TIPS', source: { question: tipsMethodQuestion(answer),
        choices: TIPS_METHOD_OPTIONS.map(option => option.label), options: [...TIPS_METHOD_OPTIONS] } },
      { type: 'submitRound' })
    const entry = discussionEntries(session)[0]
    session = run(session, { type: 'setDiscussionAnswer', itemId: 'TIPS', question: entry.question, basis: entry.basis,
      kind: 'review-choices', change: { choice: 'both' } }, { type: 'prepareDiscussionReview' }, { type: 'reviewDiscussionWork' },
      { type: 'setDiscussionWorkDraft', key: 'new-finding-note', value: 'Ask about the reporting code.' })
    expect(previewWorkIds(session)).toContain('TIPS RPT')
    expect(previewCanApply(session)).toBe(false)
    expect(run(session, { type: 'finishDiscussionWork' })).toBe(session)
    expect(run(session, { type: 'applyDiscussionReview' })).toBe(session)
    const back = run(restore(run(skip(session), { type: 'submitOptimization' })),
      { type: 'backFromOvertime' }, { type: 'backFromOptimization' })
    expect(back.step).toBe('discussionWork')
    expect(onlyNavigation(back)).toEqual(onlyNavigation(session))
    expect(previewWorkIds(back)).toContain('TIPS RPT')
    expect(back.resolutions['TIPS RPT']).toBeUndefined()
  })

  it('locks genuinely completed Optimization and preserves the normal applied-history Back', () => {
    let session = routingReady()
    for (const suggestion of OPTIMIZATIONS) session = run(session, { type: 'chooseOptimization', suggestionId: suggestion.id, choice: 'keep' })
    session = run(session, { type: 'submitOptimization' })
    expect(session.optimization).toMatchObject({ completed: true, submitted: true })
    expect(run(session, { type: 'chooseOptimization', suggestionId: 'split-bonus', choice: 'accept' })).toBe(session)
    expect(run(session, { type: 'backFromOvertime' }).appliedReview).toBeDefined()
  })

  it.each(['optimization', 'overtime', 'summary'] as const)('recovers the demo %s position from both storage paths and category reentry', step => {
    let session = skip(endpoint(original()))
    if (step !== 'optimization') session = run(session, { type: 'submitOptimization' })
    if (step === 'summary') session = run(session, { type: 'confirmOvertime' })
    writeWorkingCopy(browserStores(), session)
    expect(loadSession(browserStores())).toEqual(session)
    expect(saveSession(browserStores(), session)).toBe(true)
    sessionStorage.clear()
    expect(loadSession(browserStores())).toEqual(session)
    const navigation = run(session, { type: 'goTo', step: 'categorySelection' })
    expect(restore(navigation).lastEarningStep).toBe(step)
    expect(run(restore(navigation), { type: 'goTo', step: navigation.lastEarningStep! }).step).toBe(step)
    EARNING_DEMO_SETTINGS.ungateForwardButtons = false
    const gated = restore(session)
    expect(gated.step).toBe('questions')
    expect(onlyNavigation(gated)).toEqual(onlyNavigation(session))
    expect(restore(navigation).lastEarningStep).toBe('questions')
    expect(skip(gated)).toBe(gated)
    expect(run(gated, { type: 'moveReview', index: 0 }, { type: 'moveReview', index: 1 }).reviewCursor).toBe(0)
  })

  it('keeps later answers when disabling the setting and does not allow incomplete interaction or application', () => {
    let session = skip(endpoint(original()))
    session = run(session, { type: 'chooseOptimization', suggestionId: 'split-bonus', choice: 'keep' },
      { type: 'submitOptimization' }, { type: 'answerOvertime', questionId: 'multiRate', answer: 'yes' })
    EARNING_DEMO_SETTINGS.ungateForwardButtons = false
    for (const action of [
      { type: 'submitOptimization' }, { type: 'answerOvertime', questionId: 'multiRate', answer: 'no' },
      { type: 'reviewOvertimeSort' }, { type: 'confirmOvertime' }, { type: 'goTo', step: 'summary' },
    ] as SessionAction[]) expect(run(session, action)).toBe(session)
    expect(restore(session).optimization).toEqual(session.optimization)
    expect(restore(session).overtime).toEqual(session.overtime)
    const work = routingSetup()
    expect(previewCanApply(work)).toBe(false)
    expect(run(work, { type: 'applyDiscussionReview' })).toBe(work)
    expect(markup(work, <StepDiscussionWork />)).not.toContain('Continue to optimization')
  })

  it('never extends the override to uploaded-register review or an unstarted session', () => {
    for (const session of [createSession(1), { ...routingOpen(), registerSource: 'uploads' as const },
      { ...routingOpen(), files: [{ id: 'real-file', name: 'Register.csv', sizeBytes: 100, docType: 'Pay register' }] }]) {
      expect(demoNavigationAllowed(session)).toBe(false)
      expect(skip(session)).toBe(session)
      expect(run(session, { type: 'goTo', step: 'optimization' })).toBe(session)
      expect(markup(session, <StepDiscussionReview />)).not.toContain('Continue to optimization')
    }
  })
})

it('uses the real category action to reopen skipped overtime with working-copy recovery', () => {
  ;(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
  const session = run(skip(endpoint(original())), { type: 'submitOptimization' }, { type: 'goTo', step: 'categorySelection' })
  writeWorkingCopy(browserStores(), session)
  let current: EarningSession = session
  function Flow() {
    const context = useEarningSession()
    current = context.session
    return current.step === 'categorySelection' ? <StepCategorySelection />
      : current.step === 'overtime' ? <StepOvertime /> : <StepOptimization />
  }
  const host = document.createElement('div')
  document.body.append(host)
  const root = createRoot(host)
  try {
    act(() => root.render(<MemoryRouter><EarningSessionProvider><Flow /></EarningSessionProvider></MemoryRouter>))
    const button = [...host.querySelectorAll('button')].find(node => node.textContent === 'Set up earnings')!
    expect(button).toBeDefined()
    act(() => button.click())
    expect(host.querySelector('h1')?.textContent).toBe('How does your team earn overtime')
    expect(currentRound(current)?.submitted).toBe(false)
    expect(current.answers).toEqual({})
  } finally {
    act(() => root.unmount()); host.remove()
  }
})
