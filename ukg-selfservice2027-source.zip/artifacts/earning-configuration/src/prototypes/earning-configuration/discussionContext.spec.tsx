import { act, useReducer } from 'react'
import { createRoot } from 'react-dom/client'
import { renderToStaticMarkup } from 'react-dom/server'
import { describe, expect, it, vi } from 'vitest'
import { draftEarningCustomerQuestions } from '@workspace/api-client-react'
import { createSession, parseSession, reduceSession, reviewPages, namingBasis, shiftPremiumFor, type EarningSession, type ItemAnswer, type SessionAction } from './session'
import { ASK_CUSTOMER, DESCRIBE_CHOICE, READY, findItem } from './sampleRegister'
import { answerReviewBasis } from './answerReviewData'
import { discussionContext } from './discussionContext'
import { cheatSheetGroups } from './cheatSheet'
import { cellChecked, cellPick, fixedBusiness } from './cellFlow.testing'
import { reduceCell } from './cellFlow'
import { reimbursementAnswer } from './reimbursements'
import { SessionContext } from './sessionContext'
import StepReview from './StepReview'
import DiscussionContext from './DiscussionContext'
import { SAMPLE_REGISTER_FILES } from './sampleDocument'
import { callEvidence } from './cheatSheetAnswers'
import { deferralBasis } from './explicitDeferral'

vi.mock('@workspace/api-client-react', () => ({ draftEarningCustomerQuestions: vi.fn(),
  summarizeEarningDiscussion: vi.fn(() => new Promise(() => {})) }))
const rows = (state: EarningSession) => cheatSheetGroups(state).flatMap(group => group.rows)
const context = (id: string, answer: ItemAnswer) => discussionContext(findItem(id), answer, { status: 'customer', round: 1 }, 'The remaining detail changes the payment proposal.')
function fixture(): EarningSession {
  const state: EarningSession = { ...createSession(1), step: 'review', files: SAMPLE_REGISTER_FILES,
    rounds: [{ number: 1, submitted: true, itemIds: ['OTPREM', 'SPPAY', 'ADJ2', 'CELL-purpose', 'MISC7'],
      results: { resolved: ['OTPREM', 'CELL-purpose'], deferred: ['ADJ2'], review: ['SPPAY'], findings: [], demoUnresolved: ['MISC7'] } }],
    answers: {
      OTPREM: { choice: 'premium' },
      SPPAY: { description: 'Extra weekend pay', descriptionSubmitted: true },
      ADJ2: { description: 'Corrections for earlier work', descriptionSubmitted: true, followUps: { basis: 'hourly', frequency: ASK_CUSTOMER } },
      'CELL-purpose': { cellLegacy: true, choice: 'both', followUps: { treatment: 'qualifying', split: 'accept' } },
    },
    resolutions: {
      OTPREM: { status: 'resolved', round: 1, reference: READY.overtimePremium, combinedInto: 'OTMFG' },
      SPPAY: { status: 'review', round: 1, note: 'Extra weekend pay' },
      ADJ2: { status: 'customer', round: 1 },
      'CELL-purpose': { status: 'resolved', round: 1, reference: READY.cellAllowance,
        outputs: [{ code: 'CELL ALLOW', reference: READY.cellAllowance }, { code: 'CELL REIMB', reference: READY.cellReimbursement }] },
    },
    customerQuestions: [{ itemId: 'ADJ2', code: 'ADJ2', type: 'unidentified', round: 1, question: 'Is this one-time or recurring?' }],
    callAnswers: { OTPREM: 'Keep this note.' },
  }
  const source = callEvidence(findItem('ADJ2'), state.answers.ADJ2).questions.find(entry => entry.deferred)!
  state.answers.ADJ2.explicitDeferral = { question: source.question, choices: source.choices, basis: deferralBasis(state.answers.ADJ2) }
  return state
}

describe('source-grounded discussion context', () => {
  it('keeps partial question-answer pairs and excludes Defer without discarding the earlier description', () => {
    const state = fixture()
    const before = JSON.stringify(state)
    const row = rows(state).find(row => row.id === 'ADJ2')!
    expect(row.context.earlier).toContainEqual(expect.objectContaining({ question: findItem('ADJ2').question, answer: 'Corrections for earlier work' }))
    expect(row.context.earlier.some(entry => /hourly|hour/i.test(entry.answer))).toBe(true)
    expect(row.context.earlier.some(entry => /Defer|ask-customer/.test(entry.answer))).toBe(false)
    expect(row.questions).toHaveLength(1)
    expect(row.context.decision).toContain('paid once or repeatedly')
    expect(JSON.stringify(state)).toBe(before)
  })
  it('retains adaptive component answers and labels migrated answers as history, not current tax confirmation', () => {
    let answer = cellChecked(fixedBusiness())
    answer = { ...answer, cell: { ...answer.cell!, earlier: { choice: 'reimbursement', followUps: { treatment: 'qualifying' } } } }
    answer = reduceCell(answer, { kind: 'defer', checked: true })
    const result = context('CELL-purpose', answer)
    expect(result.supplied.some(entry => /personal|business/i.test(entry.answer))).toBe(true)
    expect(result.earlier.some(entry => entry.historical && /tax-free/i.test(entry.answer))).toBe(true)
    expect(result.supplied.every(entry => !entry.historical)).toBe(true)
    expect(result.reviews[0].reason).toContain('intended tax treatment')

    const payment = cellPick(cellPick(reimbursementAnswer(findItem('MILEAGE'), {})!, 'method', 'per-mile'), 'rate-basis', 'company')
    const mileage = context('MILEAGE', reduceCell(payment, { kind: 'defer', checked: true }))
    expect(mileage.earlier[0].provenance).toBe('supplied')
    expect(mileage.earlier.some(entry => /each business mile/i.test(entry.answer))).toBe(true)
    expect(mileage.earlier.some(entry => /tax-free|nontaxable/.test(entry.answer))).toBe(false)
  })
  it('shows only fresh description checks and typed answer reviews, never retired fixed-pick reviews', () => {
    const answer: ItemAnswer = { description: 'Corrections for earlier work', descriptionSubmitted: true }
    answer.check = { basis: namingBasis(answer), at: 1, result: { kind: 'noMatch', reason: 'No supported reference fits the supplied calculation.' } }
    expect(context('ADJ2', answer).reviews[0].reason).toContain('supplied calculation')
    answer.description = 'A different payment'
    expect(context('ADJ2', answer).reviews).toEqual([])
    const item = findItem('MED')
    const described: ItemAnswer = { choice: 'describe', description: 'Cash payment for premiums', descriptionSubmitted: true }
    // Use the real describe id rather than assuming a stored choice.
    if (item.type !== 'clarification') throw new Error('Expected clarification')
    described.choice = DESCRIBE_CHOICE
    described.reviews = { [item.question]: { basis: answerReviewBasis(described),
      result: { outcome: 'followUp', reason: 'The payment calculation needs review.', suggestion: 'Review the supplied premium amounts.', question: 'How are amounts calculated?', conflictingFact: null },
      thread: [{ question: 'Who receives it?', reply: 'People enrolled in the plan.' }] } }
    const fresh = context('MED', described)
    expect(fresh.reviews[0].suggestion).toContain('premium amounts')
    expect(fresh.earlier.some(entry => entry.answer === 'People enrolled in the plan.')).toBe(true)
    described.description = 'Changed description'
    expect(context('MED', described).reviews).toEqual([])
    expect(context('MED', described).earlier.some(entry => entry.answer === 'People enrolled in the plan.')).toBe(false)
    const fixed: ItemAnswer = { choice: 'premium' }
    fixed.reviews = { [findItem('OTPREM').question]: { basis: answerReviewBasis(fixed), result: {
      outcome: 'confirm', reason: 'Retired fixed-pick reasoning', question: null, conflictingFact: null,
    } } }
    expect(context('OTPREM', fixed).reviews).toEqual([])
  })
  it('keeps fresh shift conversation answers but excludes stale or rejected recommendations', () => {
    const answer: ItemAnswer = { choice: 'shift', sharedSetup: { referenceId: READY.shift.id, choice: ASK_CUSTOMER } }
    // The source has an existing Shift differential reference in the sample register.
    const item = findItem('SPPAY')
    const premium = shiftPremiumFor(item, answer)!
    expect(premium).toBeTruthy()
    answer.shiftPremium = { basis: premium.basis, thread: [{ question: 'When is it paid?', reply: 'Only on weekend shifts.' }],
      result: { outcome: 'separate', question: null, combineInto: null, customerQuestion: null, reason: 'Weekend-only pay differs from the existing shift payment.' } }
    expect(context('SPPAY', answer).earlier.some(entry => entry.answer === 'Only on weekend shifts.')).toBe(true)
    expect(context('SPPAY', answer).reviews[0].reason).toContain('Weekend-only')
    answer.shiftPremium.changed = true
    expect(context('SPPAY', answer).reviews).toEqual([])
    answer.shiftPremium.basis = 'old answers'
    expect(context('SPPAY', answer).earlier.some(entry => entry.answer === 'Only on weekend shifts.')).toBe(false)
  })
  it('explains confirmed, split, combined, removed and optional-unresolved states without adding questions', () => {
    const state = fixture()
    state.rounds[0].itemIds.push('MILEAGE')
    state.resolutions.MILEAGE = { status: 'removed', round: 1 }
    const result = rows(state)
    expect(result.find(row => row.id === 'OTPREM')!.setup).toContain('Combined into OTMFG')
    expect(result.find(row => row.id === 'CELL-purpose')!.setup).toContain('Split CELL')
    expect(result.find(row => row.id === 'MILEAGE')!.context.decision).toContain('Earlier payroll activity is unchanged')
    expect(result.find(row => row.id === 'MISC7')!.context.decision).toContain('No setup decision has been applied')
    for (const row of result) expect(row.deferred || !row.questions.length).toBe(true)
    const team = result.find(row => row.id === 'SPPAY')!
    expect(team.context.supplied[0].answer).toBe('Extra weekend pay')
    expect(team.context.missingReviewReason).toBe(true)
    state.resolutions.SPPAY = { status: 'review', round: 1, customName: { name: 'Weekend pay', provenance: 'ai' } }
    expect(rows(state).find(row => row.id === 'SPPAY')!.setup).toContain('Proposed name: Weekend pay')
    expect(rows(state).find(row => row.id === 'SPPAY')!.setup).toContain('no Ready setup confirmed')
  })
  it('supports older saves with no reasoning and preserves sent text, notes and applied decisions on reentry', () => {
    let state = reduceSession(createSession(1), { type: 'startReview' })
    for (const id of reviewPages(state).flat()) state = reduceSession(state, { type: 'choose', itemId: id, choice: ASK_CUSTOMER })
    state = reduceSession(reduceSession(state, { type: 'submitRound' }), { type: 'finishReevaluation' })
    state.callAnswers = { OTPREM: 'Keep this note.' }
    state.sent = { at: 1, to: 'payroll@example.test', questionIds: ['classification:ADJ2'],
      questions: [{ id: 'classification:ADJ2', topic: 'unidentified', codes: ['ADJ2'], question: 'Earlier exact wording?', status: 'open' }] }
    const restored = parseSession(JSON.stringify(state))!
    expect(restored).not.toBeNull()
    const before = JSON.stringify(restored)
    rows(restored)
    expect(JSON.stringify(restored)).toBe(before)
    expect(restored.sent).toEqual(state.sent)
    expect(restored.resolutions).toEqual(state.resolutions)
    expect(restored.callAnswers).toEqual(state.callAnswers)
  })
})

describe('discussion context presentation', () => {
  it('omits supplied facts and setup meaning without removing other disclosures or changing the model', () => {
    const value = {
      supplied: [{ question: 'Hidden supplied question', answer: 'Hidden supplied body', historical: false, provenance: 'supplied' as const }],
      decision: 'Hidden setup meaning body',
      earlier: [{ question: 'Historical question', answer: 'Historical answer', historical: true, provenance: 'answer' as const }],
      reviews: [{ reason: 'Current AI explanation', suggestion: 'Current suggestion' }],
      missingReviewReason: false,
    }
    const before = JSON.stringify(value)
    const doc = new DOMParser().parseFromString(renderToStaticMarkup(<DiscussionContext context={value} itemId="SPPAY" />), 'text/html')
    expect(doc.body.textContent).not.toMatch(/What’s known|What this means for setup|Hidden supplied|Hidden setup/)
    expect(doc.querySelector('.ec-context__facts, .ec-context__decision, .ec-context__question')).toBeNull()
    expect(doc.body.textContent).toContain('Current AI explanation')
    expect(doc.body.textContent).toContain('Not a setup decision')
    const history = doc.querySelector('details')!
    expect(history.hasAttribute('open')).toBe(false)
    expect(history.textContent).toContain('Historical answer')
    expect(history.querySelector('input,textarea,button')).toBeNull()
    expect(JSON.stringify(value)).toBe(before)
  })

  it('leaves no wrapper, heading or spacing when only the removed sections have content', () => {
    expect(renderToStaticMarkup(<DiscussionContext itemId="SPPAY" context={{
      supplied: [{ question: 'Supplied question', answer: 'Supplied answer', historical: false, provenance: 'answer' }],
      decision: 'Setup meaning', earlier: [], reviews: [], missingReviewReason: false,
    }} />)).toBe('')
  })

  it('does not manufacture an explanation when no earlier answers exist', () => {
    const markup = renderToStaticMarkup(<DiscussionContext itemId="SPPAY" context={{
      supplied: [], decision: 'Hidden setup meaning', earlier: [], reviews: [], missingReviewReason: true,
    }} />)
    expect(markup).toBe('')
    expect(markup).not.toMatch(/What’s known|What this means for setup|Hidden setup meaning/)
  })

  it('keeps deferred response controls and supporting disclosures usable without mounting context or changing setup', () => {
    const state = fixture()
    const host = document.createElement('div'); document.body.append(host)
    const root = createRoot(host)
    let latest = state
    function Harness() {
      const [session, dispatch] = useReducer((state: EarningSession, action: SessionAction) => reduceSession(state, action), state)
      latest = session
      return <SessionContext.Provider value={{ session, dispatch, save: () => true, restart: () => true }}><StepReview /></SessionContext.Provider>
    }
    try {
      act(() => root.render(<Harness />))
      const row = host.querySelector('[data-testid="row-cheat-ADJ2"]')!
      expect(row.querySelector('.ec-context')).toBeNull()
      expect(host.textContent).not.toMatch(/What’s known|What this means for setup/)
      expect(row.querySelector<HTMLDetailsElement>('.ec-context__earlier')?.open).toBe(false)
      const why = row.querySelector<HTMLDetailsElement>('.ec-cheat__support .ec-cheat__why')!
      const register = row.querySelector<HTMLDetailsElement>('.ec-register-details')!
      expect([why.open, register.open]).toEqual([false, false])
      act(() => why.querySelector('summary')!.click())
      expect(why.open).toBe(true)
      expect(register.open).toBe(false)
      expect(row.querySelector('.ec-discussion__response')).not.toBeNull()
      for (const id of ['OTPREM', 'SPPAY', 'CELL-purpose', 'MISC7']) {
        expect(host.querySelector(`[data-testid="row-cheat-${id}"] .ec-discussion__response`)).toBeNull()
      }
      expect(latest.callAnswers).toEqual(state.callAnswers)
      expect(latest.answers).toEqual(state.answers)
      expect(latest.resolutions).toEqual(state.resolutions)
      expect(latest.customerQuestions).toEqual(state.customerQuestions)
      expect(host.querySelectorAll('#review-notes-guidance')).toHaveLength(1)
      expect(draftEarningCustomerQuestions).not.toHaveBeenCalled()
      expect(register.textContent).not.toMatch(/taxable|tax-free|pre-tax/i)
    } finally {
      act(() => root.unmount()); host.remove()
    }
  })
})
