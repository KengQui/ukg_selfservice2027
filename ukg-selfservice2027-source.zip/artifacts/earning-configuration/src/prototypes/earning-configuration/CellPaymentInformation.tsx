import { useState } from 'react'
import { Button, Dialog } from '@ready/dls/compatibility'
import './cellPaymentInformation.css'

/** Presentation-only help. No review, draft, question or AI state enters this component. */
export default function CellPaymentInformation() {
  const [open, setOpen] = useState(false)
  const close = () => setOpen(false)

  return <>
    <Button type="button" variant="tertiary" size="large" borderShape="none"
      iconLeftName="info" iconSize={20} className="ec-cell-info"
      aria-label="About cellphone payments" aria-haspopup="dialog" aria-expanded={open}
      onClick={() => setOpen(true)} />
    <Dialog open={open} onClose={close} title="About cellphone payments" size="wide"
      className="ec-cell-info-dialog" primaryAction={{ label: 'Close', onClick: close }}>
      <div className="ec-cell-info-content" role="region" aria-label="Cellphone payment information" tabIndex={0}
        onKeyDown={event => {
          if (event.target !== event.currentTarget || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey
            || !['Home', 'End'].includes(event.key)) return
          // Native Home can align this inner region below the scroll area's top padding.
          // Use the actual scroll boundaries so both ends remain reachable at any width.
          const body = event.currentTarget.parentElement
          if (body) {
            event.preventDefault()
            body.scrollTop = event.key === 'Home' ? 0 : body.scrollHeight
          }
        }}>
        <p><strong>A fixed cellphone allowance is not automatically taxable.</strong></p>
        <p>For example, under applicable IRS guidance, a reasonable employer-provided cellphone reimbursement may qualify for nontaxable treatment when there are substantial business reasons and the arrangement is not a substitute for wages. The exact facts matter.</p>

        <section>
          <h3>What the AI needs to understand</h3>
          <p>The AI should not use a simple rule such as:</p>
          <div className="ec-cell-info-content__avoid">
            <p><strong>Rule to avoid</strong></p>
            <blockquote>“Fixed amount = taxable; actual reimbursement = nontaxable.”</blockquote>
          </div>
          <p>Instead, the AI should ask enough questions to understand:</p>
          <ul>
            <li>The business purpose.</li>
            <li>The payment arrangement.</li>
            <li>Applicable substantiation or policy requirements.</li>
          </ul>
        </section>

        <section>
          <h3>What we need to confirm</h3>
          <p>These details help us understand how you use CELL.</p>
          <table>
            <thead><tr><th scope="col">Detail</th><th scope="col">CELL example</th></tr></thead>
            <tbody>
              <tr>
                {/* copy-exception(banned/configure): User-supplied technical library field name, preserved under guide A.7. */}
                <th scope="row">Configuration Conditions</th>
                <td>Determine whether payments are fixed allowances, actual business expense reimbursements, or both, and evaluate applicable tax treatment.</td>
              </tr>
              <tr>
                <th scope="row">Required Clarification</th>
                <td>Determine how CELL payments are calculated, their business purpose, and whether relevant reimbursement requirements are met.</td>
              </tr>
              <tr>
                <th scope="row">Decision Criteria</th>
                <td>Apply the approved taxable or nontaxable mapping based on the verified facts and applicable rules.</td>
              </tr>
              <tr>
                {/* copy-exception(banned/configure): User-supplied technical library field name, preserved under guide A.7. */}
                <th scope="row">Configuration Verification</th>
                <td>Confirm the selected Ready earning code, Roll-Up Type, tax setup, and actual payroll results.</td>
              </tr>
            </tbody>
          </table>
          <p>The AI can then generate different customer-friendly questions depending on what information it already has.</p>
        </section>
      </div>
    </Dialog>
  </>
}
