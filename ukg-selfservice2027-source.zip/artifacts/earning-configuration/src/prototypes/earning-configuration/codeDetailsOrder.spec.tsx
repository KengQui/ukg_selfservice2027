import { act } from 'react'
import { createRoot } from 'react-dom/client'
import { expect, it } from 'vitest'
import StepResults from './StepResults'
import { SessionContext } from './sessionContext'
import { createSession } from './session'

it('lists Code details alphabetically when expanded', async () => {
  Object.assign(globalThis, { IS_REACT_ACT_ENVIRONMENT: true })
  const host = document.createElement('div')
  document.body.append(host)
  const root = createRoot(host)
  try {
    await act(async () => root.render(
      <SessionContext.Provider value={{ session: createSession(1), dispatch: () => {}, save: () => true, restart: () => true }}>
        <StepResults actions={<button type="button">Back</button>} />
      </SessionContext.Provider>,
    ))
    await act(async () => host.querySelector<HTMLButtonElement>('[data-testid="button-view-all-codes"]')!.click())
    const panel = host.querySelector('.ec-results-panel')!
    expect(panel.contains(host.querySelector('#ec-all-codes'))).toBe(true)
    expect(panel.querySelector('.ec-results-actions')?.textContent).toBe('Back')
    const codes = [...host.querySelectorAll('tbody tr')].map(row => row.getAttribute('data-code')!)
    expect(codes.length).toBeGreaterThan(1)
    for (const row of host.querySelectorAll('tbody tr')) {
      const status = row.querySelector('strong')!
      expect(!!status.querySelector('.ec-code-review-status__icon')).toBe(status.textContent?.endsWith('Needs review'))
    }
    expect(codes).toEqual([...codes].sort((a, b) => a.localeCompare(b, 'en-US', { sensitivity: 'base', numeric: true })))
    await act(async () => host.querySelector<HTMLButtonElement>('[data-testid="button-view-all-codes"]')!.click())
    expect(panel.querySelector('#ec-all-codes')).toBeNull()
    expect(panel.querySelector('.ec-results-actions')?.textContent).toBe('Back')
  } finally {
    await act(async () => root.unmount())
    host.remove()
  }
})
