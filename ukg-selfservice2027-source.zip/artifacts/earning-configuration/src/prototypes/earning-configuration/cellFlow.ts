import type { CellReviewInput, CellReviewResult } from '@workspace/api-client-react'
import { redactSensitive } from '@workspace/setup-shared/ask-bryte'
import type { Decision, ItemAnswer } from './session'
import { REIMBURSEMENT_POLICIES, REIMBURSEMENT_REASON, MILEAGE_RATE_BASIS, VEHICLE_PURPOSE } from './reimbursementPolicy'
import { parseMileageRate, mileageRateResult, MILEAGE_RATE_REASON } from './mileageRate'
import { isMileage, mileageOpening, mileageBasis, mileageAssessment, nextMileageQuestion, groundedMileageCheck, activeCellDeferral, isMileageReviewFallback } from './mileageQuestions'
import { legacyMileageNext, legacyMileageTaxIntent, legacyMileageTaxQuestion } from './legacyMileageQuestions'
import { MILEAGE_POLICY, MILEAGE_PURPOSE_ID, MILEAGE_CAPTURED, MILEAGE_LEGACY_CAPTURED, MILEAGE_REVIEW_REVISION } from '@workspace/setup-shared/mileage-policy'
import { mileageSetup } from './mileageSetup'

export type CellComponent = 'allowance' | 'reimbursement' | 'payment'
export interface CellQuestion {
  id: string; question: string; context: string; component: CellComponent
  options?: { id: string; label: string; detail?: string; example?: string }[]
  format?: { kind: 'text' } | { kind: 'choices'; options: string[] }
}
export interface CellEntry extends CellQuestion { value: string; answer: string }
export interface CellCheck { basis: string; result: CellReviewResult; at: number; after: number; mileageRevision?: string }
export interface CellFlow {
  version: 2
  policy?: 'reimbursements-1' | typeof MILEAGE_POLICY
  replyRound?: number
  setupConfirmed?: string
  entries: CellEntry[]
  checks: CellCheck[]
  deferred?: CellQuestion
  reviewPaused?: boolean
  /** Old answers are evidence only, never new tax confirmation. */
  earlier?: ItemAnswer
}
export type CellEvent =
  | { kind: 'confirmSetup' }
  | { kind: 'answer'; id: string; value: string; text?: string }
  | { kind: 'change'; id: string }
  | { kind: 'defer'; checked: boolean }
  | { kind: 'recheck' }
  | { kind: 'pauseReview' }
  | { kind: 'checked'; basis: string; result: CellReviewResult; at: number }

export const CELL_OPENING = 'How does your company use CELL to pay employees for cellphone costs?'
// User approved the amount-free description after the demo evidence could not support $40 per recipient (guide A.7).
export const CELL_OVERVIEW = 'Your pay register shows CELL payments. Is this a set amount you pay each pay period?'
export const CELL_REASON = 'The payment method is still missing from the supplied mapping context and pay register amounts.\n\nA fixed amount and reimbursement describe how people are paid, not whether the payment is taxable.\n\nYour answers help identify the business facts and tax decisions needed for CELL. Unconfirmed decisions can stay open while you work on other codes.'
export const CELL_METHODS = [
  { id: 'allowance', label: 'Fixed amount', detail: 'Employees receive a set amount regardless of their actual phone bills.', example: "Example: $40 every month, whether an employee's phone bill is $30 or $90." },
  // copy-exception(banned/submit): Exact CELL wording supplied and approved by the user (guide A.7).
  { id: 'reimbursement', label: 'Actual expense reimbursement', detail: 'Employees are reimbursed based on eligible business cellphone expenses.', example: 'Example: An employee submits $35 in business phone expenses and receives $35.' },
  { id: 'both', label: 'Both', detail: 'Employees receive a fixed allowance plus reimbursement for additional business expenses.', example: 'Example: $20 per month plus approved additional business phone expenses.' },
  { id: 'other', label: 'Something else', detail: 'Please describe how the payment works.' },
]
const otherwise = { id: 'other', label: 'Something else' }
const unsure = { id: 'unsure', label: 'Not sure' }
export const CELL_PURPOSE: CellQuestion = {
  id: 'allowance-purpose', component: 'allowance', question: 'Why does your company provide the cellphone allowance?',
  context: 'The reason for the allowance is still needed. Business phone costs and additional compensation raise different tax considerations. Your answer guides the next question without deciding tax treatment.',
  options: [
    { id: 'business', label: 'Employees need to use their personal phones for work.' },
    { id: 'compensation', label: 'It is an employee benefit or additional compensation.' },
    { id: 'mixed', label: 'Both reasons.' }, unsure,
  ],
}
export const CELL_BASES: Record<string, CellQuestion> = {
  'allowance-basis': {
    id: 'allowance-basis', component: 'allowance', question: 'How is the allowance amount determined?',
    context: 'How the amount relates to phone costs is still unclear. A standard amount alone does not decide tax treatment. Your answer helps the setup team understand the allowance before confirming intended treatment.',
    options: [
      { id: 'estimate', label: "Based on the company's estimate of reasonable cellphone costs." },
      { id: 'standard', label: 'A standard amount provided to eligible employees.' },
      { id: 'other', label: 'Another method.' }, unsure,
    ],
  },
  'reimbursement-basis': {
    id: 'reimbursement-basis', component: 'reimbursement', question: 'How does your company determine the amount to reimburse?',
    context: 'The way the reimbursement amount is determined is still unclear. That helps distinguish expense repayment from additional pay. Your answer supplies the missing business fact; it does not establish tax-free qualification.',
    options: [
      // copy-exception(banned/submit): Exact CELL wording supplied and approved by the user (guide A.7).
      { id: 'expenses', label: 'Employees submit eligible business phone expenses.' },
      { id: 'usage', label: 'Employees report their business phone usage.' },
      { id: 'other', label: 'The company uses another approved method.' }, unsure,
    ],
  },
}
export function cellTaxQuestion(component: CellComponent, both = false): CellQuestion {
  return {
    id: `tax-${component}`, component,
    question: 'How should this cellphone payment be treated for payroll taxes in UKG Ready?',
    context: `${both ? `This question is for the ${component === 'allowance' ? 'fixed allowance' : 'additional reimbursement'} only. ` : ''}We need to confirm the tax treatment before finalizing payroll setup. If you're unsure, you can decide later after checking with your payroll or tax adviser.`,
    options: [
      { id: 'taxable', label: 'Taxable', detail: 'Include this payment in taxable wages.' },
      { id: 'nontaxable', label: 'Nontaxable', detail: 'Our company has confirmed this payment qualifies for tax-free treatment.' },
      { id: 'unsure', label: 'Not sure', detail: 'Review this decision later.' },
      { ...otherwise, detail: 'Different or special treatment applies.' },
    ],
  }
}
export const emptyCell = (): CellFlow => ({ version: 2, policy: 'reimbursements-1', entries: [], checks: [] })
export const paymentMethod = (answer: ItemAnswer) => answer.reimbursement
  ? answer.cell?.entries.find(e => e.id === (isMileage(answer) ? MILEAGE_PURPOSE_ID : 'method'))?.value : answer.choice
export const cellComponents = (answer: ItemAnswer): CellComponent[] => paymentMethod(answer) === 'both'
  || answer.cell?.entries.some(e => e.id === 'allowance-purpose' && e.value === 'mixed') ? ['allowance', 'reimbursement']
  : paymentMethod(answer) === 'allowance' ? ['allowance']
    : ['reimbursement', 'per-mile', 'daily', 'destination'].includes(paymentMethod(answer) ?? '') ? ['reimbursement'] : ['payment']
const opening: CellQuestion = { id: 'method', question: CELL_OPENING, context: CELL_REASON, component: 'payment', options: CELL_METHODS }
export function paymentOpening(answer: ItemAnswer): CellQuestion {
  if (isMileage(answer)) return mileageOpening
  const category = answer.reimbursement?.category
  if (!category || category === 'CELL') return opening
  const policy = REIMBURSEMENT_POLICIES[category]
  return { id: 'method', component: 'payment', question: policy.opening,
    context: REIMBURSEMENT_REASON, options: [...policy.methods] }
}
export function cellInput(answer: ItemAnswer): CellReviewInput {
  const component = cellComponents(answer)[0]
  return {
    ...(answer.reimbursement ? { category: answer.reimbursement.category, purpose: answer.reimbursement.purpose, evidence: answer.reimbursement.evidence } : {
      category: 'CELL', purpose: 'Company payments for use of personal cellphones for work.',
      evidence: [{ type: 'supplied-purpose-context', verification: 'supplied', date: '2026-10-08',
        scope: 'CELL purpose only; not a verified catalog or company tax determination',
        quote: 'Company payments for use of personal cellphones for work.' }],
    }),
    method: cellComponents(answer).length === 2 ? 'both' : component === 'payment' ? 'other' : component,
    answers: [...(answer.reimbursement ? [{ id: 'purpose-evidence', question: 'Previously supplied payment facts',
      answer: answer.reimbursement.purpose, component: 'payment' as const }] : []),
      ...(answer.somethingElse?.submitted ? [{ id: 'earlier-customer-description',
        question: 'Earlier customer description; original response date not recorded',
        answer: answer.somethingElse.description, component: 'payment' as const }] : []),
      ...(answer.descriptionSubmitted && answer.description ? [{ id: 'original-purpose-answer',
        question: 'Original customer description', answer: answer.description, component: 'payment' as const }] : []),
      ...(answer.checkAnswers ?? []).map((entry, index) => ({ id: `purpose-followup-${index}`, question: entry.question,
        answer: entry.answer, component: 'payment' as const })),
      ...(answer.cell?.entries ?? []).map(({ id, question, answer, component }) => ({ id, question, answer, component }))],
  }
}
export const cellBasis = (answer: ItemAnswer) => isMileage(answer) ? mileageBasis(answer) : JSON.stringify(cellInput(answer))
/** Capture dates are provenance, not customer phone numbers. Redact customer text, not valid metadata dates. */
export const cellRequest = (answer: ItemAnswer): CellReviewInput => JSON.parse(JSON.stringify(cellInput(answer), (key, value: unknown) =>
  typeof value === 'string' && !(key === 'date' && /^\d{4}-\d{2}-\d{2}$/.test(value)) ? redactSensitive(value) : value))
export const currentCellCheck = (answer: ItemAnswer) => answer.cell?.checks.findLast(c => c.basis === cellBasis(answer))
/** Recheck old terminal discovery only in unfinished work or a new local reply, never frozen history. */
export function recheckCellPending(answer: ItemAnswer, resumeDeferred = false): ItemAnswer {
  if (isMileage(answer) && isMileageReviewFallback(answer.cell?.deferred)) {
    answer = { ...answer, explicitDeferral: undefined, cell: { ...answer.cell!, deferred: undefined } }
  }
  const current = currentCellCheck(answer)
  if (isMileage(answer)) {
    if (answer.cell) {
      const checks = answer.cell.checks.filter(c => groundedMileageCheck(answer, c))
      if (checks.length !== answer.cell.checks.length) return { ...answer, cell: {
        ...answer.cell, checks, deferred: undefined,
      } }
    }
    const assessment = current?.result.mileage
    const sufficient = assessment?.components.length === 1 && assessment.components.some(c => c.id === 'reimbursement' && c.treatment === 'claimed-nontaxable'
      && ['purpose', 'calculation', 'treatment'].every(topic => c.facts.some(f => f.topic === topic)))
    const obsolete = assessment && sufficient && (current?.result.next === 'clarify'
      ? ['mileageDetails', 'qualification', 'reconciliation', 'excess'].includes(assessment.nextTopic ?? '')
        || assessment.nextTopic === 'presentation' && !assessment.components.some(c => c.facts.some(f => f.topic === 'presentation'))
      : !assessment.recommendedRollUpType)
    if (!answer.cell || !obsolete || answer.cell.deferred && !resumeDeferred) return answer
    return { ...answer, cell: { ...answer.cell, deferred: undefined, checks: answer.cell.checks.filter(c => c !== current) } }
  }
  if (!answer.cell || answer.cell.deferred && !resumeDeferred || current?.result.next !== 'pending' || current.result.discovery) return answer
  return { ...answer, cell: { ...answer.cell, deferred: undefined, checks: answer.cell.checks.filter(c => c !== current) } }
}
function taxIntent(answer: ItemAnswer, component: CellComponent) {
  if (isMileage(answer)) return undefined
  if (answer.reimbursement?.category === 'MILEAGE') return legacyMileageTaxIntent(answer, component)
  const entry = answer.cell?.entries.find(e => e.id === `tax-${component}`)
  const confirmed = answer.cell?.checks.flatMap(c => c.result.confirmations).findLast(c => c.component === component)
  if (entry && entry.value !== 'other') return entry.value
  return confirmed?.intent ?? entry?.value
}
function businessReady(answer: ItemAnswer, component: CellComponent) {
  return answer.cell?.checks.some(c => c.result.component === component
    && (c.result.next === 'tax' || c.result.next === 'pending' && c.result.discovery?.status === 'sufficient')) ?? false
}
function conflict(answer: ItemAnswer, component: CellComponent) {
  const purpose = answer.cell?.entries.find(e => e.id === 'allowance-purpose')?.value
  const apparentCompensation = answer.cell?.entries.some(e => !e.id.startsWith('tax-')
    && (e.component === component || e.component === 'payment')
    && /\b(compensation|wages|salary|bonus|extra pay|pay increase|morale|recruitment)\b/i.test(e.answer.replace(
      /\b(not(?: intended as)?|rather than|instead of) (?:additional )?(compensation|wages|salary|a bonus|extra pay)\b/gi, '')))
  if (taxIntent(answer, component) !== 'nontaxable'
    || !(component === 'allowance' && ['compensation', 'mixed'].includes(purpose ?? '') || apparentCompensation)) return false
  const taxAt = answer.cell?.entries.findIndex(e => e.id === `tax-${component}`) ?? -1
  // A targeted answer and a fresh check are required. A generic confirm cannot clear the contradiction.
  return !answer.cell?.checks.some(c => c.after > taxAt + 1 && c.result.next === 'tax'
    && c.result.component === component && c.result.confirmations.some(x => x.component === component && x.intent === 'nontaxable'
      && x.answerId.startsWith('clarify-') && answer.cell!.entries.findIndex(e => e.id === x.answerId) > taxAt))
}
export type CellNext = { kind: 'question'; question: CellQuestion } | { kind: 'check' } | { kind: 'done' } | { kind: 'pending'; reason: string }
/** MILEAGE uses its purpose-first process; other payments retain their existing discovery. */
export function cellNext(answer: ItemAnswer = {}): CellNext {
  if (isMileage(answer)) return nextMileageQuestion(answer)
  const entries = answer.cell?.entries ?? []
  const method = paymentMethod(answer)
  const category = answer.reimbursement?.category ?? 'CELL'
  const first = paymentOpening(answer)
  if (!first.options?.some(m => m.id === method)) return { kind: 'question', question: first }
  if (method === 'other' && !entries.some(e => e.id === 'description' || e.id === 'method' && e.value === 'other' && e.answer !== 'Something else')) return { kind: 'question', question: {
    id: 'description', component: 'payment', question: category === 'CELL' ? 'How does this cellphone payment work?' : 'How does this payment work?',
    context: 'Describe how the amount is determined and why it is paid. Your answer helps us ask only for facts that are still missing.',
    format: { kind: 'text' },
  } }
  if (category === 'CELL' && ['allowance', 'both'].includes(method!) && !entries.some(e => e.id === CELL_PURPOSE.id)) return { kind: 'question', question: CELL_PURPOSE }
  if (category === 'MILEAGE') return legacyMileageNext(answer, cellComponents(answer))
  if (['MILEAGE', 'AUTO'].includes(category)) {
    if (method === 'allowance' && !entries.some(e => e.id === VEHICLE_PURPOSE.id)) return { kind: 'question', question: VEHICLE_PURPOSE }
    if (method === 'per-mile') {
      if (!entries.some(e => e.id === 'rate-basis')) return { kind: 'question', question: MILEAGE_RATE_BASIS }
      if (entries.find(e => e.id === 'rate-basis')?.value === 'company' && !entries.some(e => e.id === 'company-rate')) return {
        kind: 'question', question: { id: 'company-rate', component: 'reimbursement', question: 'How much does your company pay for each business mile?',
          context: MILEAGE_RATE_REASON, format: { kind: 'text' } },
      }
    }
  }
  const components = cellComponents(answer)
  const completed = components.every(c => businessReady(answer, c) && !!taxIntent(answer, c) && taxIntent(answer, c) !== 'other' && !conflict(answer, c))
  if (completed) return { kind: 'done' }
  const checked = currentCellCheck(answer)?.result
  if (!checked) return { kind: 'check' }
  if (checked.next === 'pending') return { kind: 'pending', reason: checked.reason }
  if (checked.next in CELL_BASES) return category === 'CELL' ? { kind: 'question', question: CELL_BASES[checked.next] }
    : { kind: 'pending', reason: 'The remaining business facts need review.' }
  if (checked.next === 'clarify') return { kind: 'question', question: {
    id: `clarify-${entries.filter(e => e.id.startsWith('clarify-')).length + 1}`, component: checked.component,
    question: checked.question!, context: checked.reason,
    format: checked.answerFormat?.kind === 'choices' ? { kind: 'choices', options: checked.answerFormat.options! } : { kind: 'text' },
  } }
  const component = components.find(c => businessReady(answer, c) && !taxIntent(answer, c))
  if (component) return { kind: 'question', question: { ...cellTaxQuestion(component, components.length === 2),
    ...(method !== 'both' && components.length === 2 ? { context: `This question is for the ${component === 'allowance' ? 'additional-compensation' : 'business-expense'} portion only. Confirm its intended treatment without deciding whether separate codes are needed.` } : {}),
    ...(category !== 'CELL' ? { question: 'How should this payment be treated for payroll taxes in UKG Ready?' } : {}) } }
  // A model that returns an already confirmed component cannot fabricate a new question or resolve another component.
  return { kind: 'pending', reason: components.some(c => conflict(answer, c))
    ? 'The requested nontaxable treatment still needs confirmation in light of the compensation purpose.'
    : 'The remaining payment component still needs business facts and tax confirmation. The setup team needs to review it.' }
}
export function cellOutstanding(answer: ItemAnswer = {}): CellQuestion | undefined {
  const deferred = activeCellDeferral(answer)
  if (deferred) return deferred
  const next = cellNext(answer)
  if (next.kind === 'question') return next.question
  if (isMileage(answer)) return undefined
  if (answer.reimbursement?.category === 'MILEAGE') {
    const uncertain = cellComponents(answer).find(c => ['unsure', 'other'].includes(legacyMileageTaxIntent(answer, c) ?? ''))
    if (uncertain) return legacyMileageTaxQuestion(uncertain, cellComponents(answer).length > 1)
  }
  const uncertain = cellComponents(answer).find(c => taxIntent(answer, c) === 'unsure')
  if (uncertain && next.kind === 'done') return { ...cellTaxQuestion(uncertain, paymentMethod(answer) === 'both'),
    ...(answer.reimbursement ? { question: 'How should this payment be treated for payroll taxes in UKG Ready?' } : {}) }
  return {
    id: 'review', component: 'payment', question: 'What has your company confirmed about the remaining payment decisions?',
    context: next.kind === 'pending' ? next.reason : 'The business facts and intended tax treatment still need review. Earlier answers stay saved.',
    format: { kind: 'text' },
  }
}
export function cellFactsText(answer: ItemAnswer = {}): string {
  const entries = answer.cell?.entries ?? []
  const facts = entries.map(e => `${e.question}${e.id.startsWith('tax-') ? ` (${e.component})` : ''} ${e.answer}`)
  // Customer exports, Ask Bryte and discussions receive facts, never the internal assessment.
  if (isMileage(answer)) return [...facts, mileageAssessment(answer)?.decisionStatus === 'Recommendation Complete' ? MILEAGE_CAPTURED
    : mileageAssessment(answer)?.captured ? MILEAGE_LEGACY_CAPTURED
    : 'Mileage payment questions still need confirmation. No payroll changes have been made.',
    cellNext(answer).kind === 'pending' ? currentCellCheck(answer)?.result.reason : undefined].filter(Boolean).join('\n')
  const intents = cellComponents(answer).map(c => `${c}: ${taxIntent(answer, c) ?? 'tax treatment pending confirmation'}`)
  return [answer.reimbursement?.purpose, ...facts, ...intents, paymentReadiness(answer)].filter(Boolean).join('\n')
}
// copy-exception(banned/configure): User-supplied reimbursement outcome names, in sentence case (guide A.7).
export const PAYMENT_OUTCOMES = ['Ready for configuration', 'Additional information needed', 'Tax treatment pending', 'Configuration review required'] as const
export function paymentReadiness(answer: ItemAnswer = {}): typeof PAYMENT_OUTCOMES[number] | 'Recommendation complete' {
  const next = cellNext(answer)
  if (answer.reimbursement?.category === 'MILEAGE') {
    if (isMileage(answer) && mileageAssessment(answer)?.decisionStatus === 'Recommendation Complete') return 'Recommendation complete'
    if (mileageSetup(answer)?.confirmed) return PAYMENT_OUTCOMES[0]
    if (!isMileage(answer) && (answer.cell?.deferred?.id.startsWith('tax-') || next.kind === 'question' && next.question.id.startsWith('tax-')
      || cellComponents(answer).some(c => ['unsure', 'other'].includes(legacyMileageTaxIntent(answer, c) ?? '')))) return 'Tax treatment pending'
    return next.kind === 'done' ? PAYMENT_OUTCOMES[3] : 'Additional information needed'
  }
  if (answer.cell?.deferred?.id.startsWith('tax-') || next.kind === 'question' && next.question.id.startsWith('tax-')) return 'Tax treatment pending'
  if (next.kind !== 'done') return cellComponents(answer).every(c => businessReady(answer, c)) ? 'Tax treatment pending' : 'Additional information needed'
  if (cellComponents(answer).some(c => !taxIntent(answer, c) || ['unsure', 'other'].includes(taxIntent(answer, c)!))) return 'Tax treatment pending'
  // No current Ready configuration documentation verifies any of the bundled reimbursement references.
  return PAYMENT_OUTCOMES[3]
}
export function cellFlowDecision(answer: ItemAnswer = {}): Decision | undefined {
  if (activeCellDeferral(answer)) return { kind: 'defer' }
  const setup = mileageSetup(answer)
  if (setup) return setup.confirmed ? { kind: 'resolve', reference: setup.reference, raises: [], relatedNote: setup.note } : undefined
  const next = cellNext(answer)
  if (next.kind === 'pending') return { kind: 'describe', note: `${cellFactsText(answer)}\nPending setup review: ${next.reason}` }
  if (next.kind !== 'done') return undefined
  if (isMileage(answer)) return { kind: 'describe', note: cellFactsText(answer),
    ...(mileageAssessment(answer)?.decisionStatus === 'Recommendation Complete' ? { mileageRecommendation: true as const } : {}) }
  if (cellComponents(answer).some(c => taxIntent(answer, c) === 'unsure')) return { kind: 'defer' }
  if (cellComponents(answer).some(c => taxIntent(answer, c) === 'other')) return { kind: 'describe', note: `${cellFactsText(answer)}\nSpecial tax treatment needs setup review.` }
  return { kind: 'describe', note: `${cellFactsText(answer)}\nTax intent is captured. The applicable setup still needs verification; no separate codes have been approved or created.` }
}
function prune(answer: ItemAnswer, question: CellQuestion): ItemAnswer {
  if (question.id === paymentOpening(answer).id) return { ...answer, ...(answer.reimbursement ? {} : { choice: undefined }),
    cell: { ...emptyCell(), policy: answer.cell?.policy ?? 'reimbursements-1', earlier: answer.cell?.earlier } }
  const entries = answer.cell?.entries ?? []
  const index = entries.findIndex(e => e.id === question.id)
  const dependentMileageFacts = answer.reimbursement?.category === 'MILEAGE' && !question.id.startsWith('tax-')
  const kept = index < 0 ? entries : entries.filter((e, i) => i < index || !dependentMileageFacts && question.component !== 'payment' && e.component !== question.component)
  const checks = (answer.cell?.checks ?? []).filter(c => c.after <= index || !dependentMileageFacts && question.component !== 'payment' && c.result.component !== question.component)
    .map(c => ({ ...c, result: { ...c.result, confirmations: c.result.confirmations.filter(x => kept.some(e => e.id === x.answerId)) } }))
  return { ...answer, cell: { ...answer.cell!, entries: kept, checks, deferred: undefined, reviewPaused: undefined, setupConfirmed: undefined } }
}
export function reduceCell(answer: ItemAnswer, event: CellEvent): ItemAnswer {
  if (isMileage(answer) && isMileageReviewFallback(answer.cell?.deferred)) answer = recheckCellPending(answer)
  const cell = answer.cell ?? emptyCell()
  if (event.kind === 'confirmSetup') {
    const setup = mileageSetup(answer)
    return setup ? { ...answer, cell: { ...cell, setupConfirmed: setup.basis } } : answer
  }
  if (event.kind === 'pauseReview') {
    return isMileage(answer) && cellNext(answer).kind === 'check'
      ? { ...answer, cell: { ...cell, reviewPaused: true } } : answer
  }
  if (event.kind === 'recheck') {
    if (cell.reviewPaused) return { ...answer, cell: { ...cell, reviewPaused: undefined } }
    const current = currentCellCheck(answer)
    if (cell.deferred || current?.result.next !== 'pending') return answer
    return { ...answer, cell: { ...cell, checks: cell.checks.filter(c => c !== current) } }
  }
  if (event.kind === 'checked') {
    if (event.basis !== cellBasis(answer) || cell.deferred || cellNext(answer).kind !== 'check') return answer
    if (isMileage(answer) && (!event.result.mileage || event.result.mileage.policyVersion !== MILEAGE_POLICY
      || !['Pending Verification', 'Recommendation Complete'].includes(event.result.mileage.decisionStatus))) return answer
    if (isMileage(answer) && event.result.next !== 'clarify'
      && (typeof event.result.mileage?.customerSummary !== 'string'
        || !event.result.mileage.customerSummary.trim() || event.result.mileage.customerSummary.length > 1200)) return answer
    if (isMileage(answer) && !groundedMileageCheck(answer, {
      basis: event.basis, after: cell.entries.length, result: event.result, at: event.at, mileageRevision: MILEAGE_REVIEW_REVISION,
    })) return answer
    if (event.result.next === 'clarify' && (!event.result.question?.trim() || !isMileage(answer) && !event.result.question.endsWith('?')
      || cell.entries.some(e => e.question.toLowerCase().replace(/\W/g, '') === event.result.question!.toLowerCase().replace(/\W/g, '')))) return answer
    if (event.result.confirmations.some(c => !cellInput(answer).answers.some(e => e.id === c.answerId && e.answer.includes(c.quote)))) return answer
    return { ...answer, cell: { ...cell, checks: [...cell.checks.filter(c => c.basis !== event.basis),
      { basis: event.basis, result: event.result, at: event.at, after: cell.entries.length,
        ...(isMileage(answer) ? { mileageRevision: MILEAGE_REVIEW_REVISION } : {}) }] } }
  }
  if (event.kind === 'defer') {
    const outstanding = cellOutstanding(answer)
    if (event.checked && !outstanding) return answer
    const updated = { ...answer, cell: { ...cell, setupConfirmed: undefined, deferred: event.checked ? outstanding : undefined } }
    return event.checked ? updated : recheckCellPending(updated)
  }
  if (event.kind === 'change') {
    const question = cell.entries.find(e => e.id === event.id)
    return question ? prune(answer, question) : answer
  }
  const next = cellNext(answer)
  const question = cell.deferred ?? (next.kind === 'question' ? next.question : undefined)
  if (!question || question.id !== event.id || !event.value.trim()) return answer
  if (question.id === 'company-rate' && parseMileageRate(event.value) === undefined) return answer
  const option = question.options?.find(o => o.id === event.value)
  if (question.options && !option) return answer
  const needsText = event.value === 'other'
  if (needsText && !event.text?.trim()) return answer
  const text = question.id === 'company-rate' ? answer.reimbursement?.category === 'MILEAGE'
    ? `${event.value.trim()} per business mile`
    : `${event.value.trim()} a mile. ${mileageRateResult(parseMileageRate(event.value)!)}`
    : event.text?.trim() || (option ? [option.label, option.detail].filter(Boolean).join(' — ') : event.value.trim())
  if (!text || text.length > 1000) return answer
  const base = cell.entries.some(e => e.id === question.id) ? prune(answer, question) : answer
  const updatedCell = base.cell ?? emptyCell()
  return {
    ...base, ...(question.id === 'method' && !answer.reimbursement ? { choice: event.value } : {}),
    cell: { ...updatedCell, setupConfirmed: undefined, deferred: undefined, reviewPaused: undefined, entries: [...updatedCell.entries, { ...question, value: event.value, answer: text }], checks: updatedCell.checks },
  }
}
