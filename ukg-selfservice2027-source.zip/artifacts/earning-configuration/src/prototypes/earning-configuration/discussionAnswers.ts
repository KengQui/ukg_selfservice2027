import type { EarningCustomerAnswerKind } from '@workspace/api-client-react'
import type { EarningSession } from './session'
import { CELL_ID, cellCustomerQuestion, cellQuestionStage } from './cell'
import { customerDraftBasis } from './customerQuestionData'
import { findItem } from './sampleRegister'
import { withSomethingElseEnding } from './somethingElse'
import { DISCUSSION_OPTIONS, type DiscussionAnswer, type DiscussionKind } from './discussionFormats'
import { pendingDiscussionQuestions } from './reviewDiscussionChoices'

export function allowedDiscussionKinds(session: EarningSession, itemId: string): EarningCustomerAnswerKind[] {
  if (itemId === CELL_ID) {
    // CELL's component-specific adaptive questions use their own reply flow. Discussion notes never confirm tax setup.
    if (!session.answers[itemId]?.cellLegacy) return []
    const stage = cellQuestionStage(session.answers[itemId])
    return stage === 'purpose' ? ['phone-method'] : stage === 'treatment' ? ['phone-tax'] : []
  }
  if (itemId === 'SPPAY') return ['special-pay']
  if (itemId === 'ADJ2') return ['adjustment-basis', 'adjustment-frequency']
  return []
}

/** Exact known standard wording only. AI questions carry their own checked metadata. */
export function standardDiscussionKind(session: EarningSession, itemId: string, question: string): DiscussionKind {
  const allowed = allowedDiscussionKinds(session, itemId)
  if (itemId === CELL_ID) {
    const stage = cellQuestionStage(session.answers[itemId])
    if (stage && question === cellCustomerQuestion(stage, session.answers[itemId])) return allowed[0] ?? 'text'
  }
  if (itemId === 'SPPAY' && question === withSomethingElseEnding(findItem(itemId).customerQuestion)) return 'special-pay'
  return 'text'
}

export function discussionBasis(session: EarningSession, itemId: string): string {
  const target = session.answers[itemId]?.explicitDeferral?.target
  return JSON.stringify([customerDraftBasis(session.answers[itemId]), session.resolutions[itemId] ?? null, ...(target ? [target] : [])])
}

/** Wording, not array position: reordering questions never transfers a response. */
export function discussionKey(question: string, basis: string, options?: readonly { id: string; label: string }[]): string {
  return JSON.stringify(options ? [question, basis, options.map(option => [option.id, option.label])] : [question, basis])
}

export interface DiscussionEdit {
  type: 'setDiscussionAnswer'
  itemId: string
  basis: string
  question: string
  kind: DiscussionKind
  change: { choice: string } | { text: string } | { detail: string; choice: string } | { clear: true }
}

export function editDiscussionAnswer(session: EarningSession, action: DiscussionEdit): EarningSession {
  if (action.basis !== discussionBasis(session, action.itemId) || !action.question.trim()) return session
  const current = pendingDiscussionQuestions(session, action.itemId).find(entry => entry.question === action.question)
  if (!current || (current.options.length ? action.kind !== 'review-choices' : action.kind !== 'text')) return session
  const sourceOptions = action.kind === 'review-choices'
    ? pendingDiscussionQuestions(session, action.itemId).find(entry => entry.question === action.question)?.options : undefined
  if (action.kind === 'review-choices' && !sourceOptions) return session
  const key = discussionKey(action.question, action.basis, sourceOptions)
  const entries = { ...session.discussionAnswers?.[action.itemId] }
  const previous = entries[key]
  const base: DiscussionAnswer = { question: action.question, kind: action.kind,
    // A typed answer stays visible when choices become available.
    text: previous?.text, ...(previous?.kind === action.kind ? previous : {}),
    ...(sourceOptions ? { options: sourceOptions } : {}) }
  const change = action.change
  if ('clear' in change) delete entries[key]
  else if ('text' in change) entries[key] = { ...base, text: change.text }
  else {
    const option = (sourceOptions ?? DISCUSSION_OPTIONS[action.kind])?.find(option => option.id === change.choice)
    if (!option || ('detail' in change && (!option.details || base.choice !== option.id))) return session
    entries[key] = 'detail' in change
      ? { ...base, details: { ...base.details, [option.id]: change.detail } }
      : { ...base, choice: option.id }
  }
  return { ...session, discussionPreview: undefined, discussionAnswers: { ...session.discussionAnswers, [action.itemId]: entries } }
}
