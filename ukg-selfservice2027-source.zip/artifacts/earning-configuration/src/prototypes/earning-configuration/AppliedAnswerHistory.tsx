import EarlierDeferredSelections from './EarlierDeferredSelections'

/** Application receipts remain saved, but are not displayed on the review page. */
export default function AppliedAnswerHistory() {
  return <EarlierDeferredSelections />
}
