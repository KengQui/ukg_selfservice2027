import { ASK_CUSTOMER, DESCRIBE_CHOICE, findItem } from './sampleRegister'
import { activeCheck, activeNaming, openCheckQuestion, shiftPremiumFor, type EarningSession, type SessionAction } from './session'
import { cellOutstanding } from './cellFlow'
import { tipsOutstanding, isLegacyTipsFallback } from './tipsFlow'
import { isTipsCode } from './tipsIdentity'
import { reimbursementAnswer } from './reimbursements'
import type { DeferredTarget } from './explicitDeferral'
import { conditionalDefinitionFor } from './benefitQuestions'
import { conditionalFollowUps } from './conditionalQuestions'

/** Runs against the state BEFORE the Defer action, while its original stage still exists. */
export function targetOfDeferral(session: EarningSession, action: SessionAction): DeferredTarget | undefined {
  if (!('itemId' in action)) return
  const item = findItem(action.itemId)
  const answer = session.answers[action.itemId] ?? {}
  if (action.type === 'tips' && isTipsCode(action.itemId) && action.event.kind === 'defer' && action.event.checked) {
    const question = tipsOutstanding(answer, action.itemId)
    return question && !isLegacyTipsFallback(question) ? { kind: 'tips', id: question.id } : undefined
  }
  if (action.type === 'cell' && action.event.kind === 'defer' && action.event.checked) {
    const outstanding = cellOutstanding(reimbursementAnswer(item, answer) ?? answer)
    return outstanding ? { kind: 'cell', id: outstanding.id } : undefined
  }
  if (!('choice' in action) || action.choice !== ASK_CUSTOMER) return
  if (action.type === 'answerFollowUp') return { kind: 'followUp', id: action.questionId }
  if (action.type === 'chooseRetention') return { kind: 'retention' }
  if (action.type === 'answerSharedSetup') {
    const shift = shiftPremiumFor(item, answer)
    if (shift?.result?.outcome === 'question' && shift.result.question) return { kind: 'shiftReply', question: shift.result.question }
    if (shift?.result && !shift.state?.changed) return { kind: 'shiftDecision' }
    return { kind: 'shared', referenceId: action.referenceId }
  }
  if (action.type !== 'choose') return
  const conditional = conditionalDefinitionFor(item.id)
  const followUp = conditional
    ? conditionalFollowUps(conditional, answer.conditionalReview).find(question => !answer.conditionalReview?.responses[question.id])
      ?? conditionalFollowUps(conditional, answer.conditionalReview).at(-1) : undefined
  if (followUp) return { kind: 'conditional', id: followUp.id }
  const check = openCheckQuestion(item, answer)
  if (check) return { kind: 'check', question: check.question }
  if (item.type === 'unidentified') {
    if (activeNaming(item, answer)?.outcome === 'suggestion') return { kind: 'choice', stage: 'name' }
    if (activeNaming(item, answer)?.outcome === 'needsInformation') return { kind: 'description', append: true }
    if (activeCheck(item, answer)?.kind === 'reference') return { kind: 'choice', stage: 'reference' }
    if (item.script.kind !== 'uncertainMatch' || item.purposeFirst || answer.description !== undefined)
      return { kind: 'description' }
  }
  if (answer.choice === DESCRIBE_CHOICE) return { kind: 'description' }
  return { kind: 'choice', stage: 'main' }
}
