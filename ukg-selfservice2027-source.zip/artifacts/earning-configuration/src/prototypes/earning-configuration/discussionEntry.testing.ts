import { createSession, reduceSession, type EarningSession } from './session'
import { ASK_CUSTOMER, findItem } from './sampleRegister'
import { SAMPLE_REGISTER_FILES } from './sampleDocument'
import { SOMETHING_ELSE, SOMETHING_ELSE_LABEL } from './somethingElse'

/** Current explicit targets for entry/continuity checks. Never used by the live app. */
export function discussionEntryFixture(ids = ['BONREV', 'OTPREM', 'SPPAY', 'MISC7']): EarningSession {
  let state: EarningSession = { ...createSession(1), step: 'questions', selectedCategory: 'earnings',
    files: SAMPLE_REGISTER_FILES, rounds: [{ number: 1, itemIds: ids, submitted: false }] }
  for (const id of ids) {
    const item = findItem(id)
    const options = item.type === 'misclassification' ? [{ id: item.accept.id, label: item.accept.label }]
      : item.type === 'unidentified' ? []
      : [...item.options.map(option => ({ id: option.id, label: option.label })),
        { id: SOMETHING_ELSE, label: SOMETHING_ELSE_LABEL, details: true }]
    state = reduceSession(state, { type: 'choose', itemId: id, choice: ASK_CUSTOMER }, 2)
    state = reduceSession(state, { type: 'selectDeferredQuestion', itemId: id, source: {
      question: item.type === 'unidentified' ? item.purposeFirst?.question ?? item.question : item.question,
      choices: options.map(option => option.label), options,
      ...(item.type === 'misclassification' ? { control: 'checkbox' as const } : {}),
    } }, 3)
  }
  state = reduceSession(state, { type: 'submitRound' }, 4)
  return { ...state, step: 'review', callAnswers: { SPPAY: 'Keep the discussion note.' },
    discussionAnswers: { SPPAY: { historical: { question: 'An earlier question?', kind: 'text', text: 'Keep the earlier response.' } } } }
}
