/**
 * Client-reported intent, not configuration evidence. Definitions and stored responses are
 * code-independent so another payroll code can reuse the same renderer and decision rules.
 */
export type PreliminaryCategory = 'Potential Employer Contribution' | 'Tax/Reporting Review Required'
  | 'Potential Employee Compensation' | 'Needs Review'

export interface ConditionalOption {
  id: string
  label: string
  detail?: string
  uncertain?: boolean
  taxTreatment?: string
  comment?: 'optional'
  followUp?: ConditionalFollowUp
}
export interface ConditionalFollowUp {
  id: string
  question: string
  options: readonly ConditionalOption[]
  comment?: 'optional'
}
export interface ConditionalPurpose extends ConditionalOption {
  category: PreliminaryCategory
  cashCompensation: string
  followUp?: ConditionalFollowUp
  /** Only explicit contradictions, never inferred tax or configuration rules. */
  conflictingComment?: RegExp
}
export interface ConditionalDefinition {
  gtlEvidence?: import('./gtlPurposeEvidence').GtlEvidence
  gtlHistorical?: boolean
  id: string
  version: number
  code: string
  /** Review identity can differ from the printed pay code when a question's meaning changes. */
  itemId?: string
  presentation?: 'customer'
  codeCategory: 'earning' | 'deduction' | 'employer contribution' | 'unknown'
  question: string
  introduction: string
  example?: string
  exampleNote?: string
  purposes: readonly ConditionalPurpose[]
  recommendedAction: string
  assessment?: (purpose: string, option: string | undefined, conflict: boolean) => import('./medicalClassification').MedicalAssessment
}
export interface ConditionalAnswers {
  definitionId: string
  version: number
  primary: string
  responses: Record<string, string>
  comments: Record<string, string>
}
export type ConditionalEvent =
  | { type: 'primary'; choice: string }
  | { type: 'answer'; questionId: string; choice: string }
  | { type: 'comment'; questionId: string; text: string }

export function conditionalPurpose(definition: ConditionalDefinition, answers?: ConditionalAnswers) {
  return answers?.definitionId === definition.id && answers.version === definition.version
    ? definition.purposes.find(purpose => purpose.id === answers.primary) : undefined
}

export function nextConditionalAnswers(definition: ConditionalDefinition, previous: ConditionalAnswers | undefined,
  event: ConditionalEvent): ConditionalAnswers | undefined {
  if (event.type === 'primary') {
    if (!definition.purposes.some(purpose => purpose.id === event.choice)) return previous
    if (conditionalPurpose(definition, previous)?.id === event.choice) return previous
    return { definitionId: definition.id, version: definition.version, primary: event.choice, responses: {}, comments: {} }
  }
  const purpose = conditionalPurpose(definition, previous)
  if (!purpose?.followUp || !previous) return previous
  const path = conditionalFollowUps(definition, previous)
  const index = path.findIndex(question => question.id === event.questionId)
  if (index < 0) return previous
  const followUp = path[index]
  if (event.type === 'answer') {
    if (!followUp.options.some(option => option.id === event.choice)) return previous
    const option = followUp.options.find(option => option.id === event.choice)!
    const retained = new Set(path.slice(0, index).map(question => question.id))
    return { ...previous, responses: { ...Object.fromEntries(Object.entries(previous.responses).filter(([id]) => retained.has(id))), [followUp.id]: event.choice },
      comments: Object.fromEntries(Object.entries(previous.comments).filter(([id]) => retained.has(id) || id === followUp.id && (followUp.comment || option.comment))) }
  }
  const option = followUp.options.find(option => option.id === previous.responses[followUp.id])
  if (!followUp.comment && !option?.comment) return previous
  return { ...previous, comments: { [followUp.id]: event.text.slice(0, 500) } }
}

export function conditionalFollowUps(definition: ConditionalDefinition, answers?: ConditionalAnswers): ConditionalFollowUp[] {
  const path: ConditionalFollowUp[] = []
  let next = conditionalPurpose(definition, answers)?.followUp
  while (next && path.length < 10) {
    path.push(next)
    next = next.options.find(option => option.id === answers?.responses[next!.id])?.followUp
  }
  return path
}

/** Structural validation is deliberately separate from review/conflict assessment. */
export function validConditionalAnswers(value: unknown): value is ConditionalAnswers {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false
  const data = value as Record<string, unknown>
  const strings = (input: unknown, max: number) => !!input && typeof input === 'object' && !Array.isArray(input)
    && Object.entries(input).length <= 10 && Object.entries(input).every(([key, entry]) =>
      key.length <= 100 && typeof entry === 'string' && entry.length <= max)
  return Object.keys(data).every(key => ['definitionId', 'version', 'primary', 'responses', 'comments'].includes(key))
    && typeof data.definitionId === 'string' && data.definitionId.length <= 100
    && Number.isInteger(data.version) && typeof data.primary === 'string' && data.primary.length <= 100
    && strings(data.responses, 100) && strings(data.comments, 500)
}

export function conditionalReport(definition: ConditionalDefinition, answers?: ConditionalAnswers) {
  const purpose = conditionalPurpose(definition, answers)
  if (!purpose || !answers) return undefined
  const path = conditionalFollowUps(definition, answers)
  if (path.some(question => !question.options.some(option => option.id === answers.responses[question.id]))) return undefined
  const followUp = path.at(-1)
  const option = followUp?.options.find(option => option.id === answers.responses[followUp.id])
  if (followUp && !option) return undefined
  const comment = followUp ? answers.comments[followUp.id]?.trim() : undefined
  const conflict = Object.keys(answers.responses).some(key => !path.some(question => question.id === key))
    || Object.keys(answers.comments).some(key => !path.some(question => question.id === key))
    || !!(comment && purpose.conflictingComment?.test(comment))
  const category: PreliminaryCategory = conflict || purpose.uncertain || option?.uncertain ? 'Needs Review'
    : option?.taxTreatment && option.taxTreatment !== 'Employer contribution tracking only'
    && purpose.category === 'Potential Employer Contribution' ? 'Tax/Reporting Review Required' : purpose.category
  return {
    code: definition.code, purpose: purpose.label, followUp: followUp?.question, answer: option?.label,
    comment, conflict, category, taxTreatment: definition.assessment && option?.id === 'tracking-only'
      ? 'Does not affect taxable pay, as reported; not independently verified'
      : option?.taxTreatment ?? 'Unknown — tax treatment needs review',
    cashCompensation: purpose.cashCompensation,
    configurationVerification: 'Not completed',
    recommendedAction: definition.recommendedAction,
    steps: path.map(question => ({ question: question.question, answer: question.options.find(option => option.id === answers.responses[question.id])!.label })),
    assessment: definition.assessment?.(purpose.id, option?.id, conflict),
  }
}

export function conditionalReportText(definition: ConditionalDefinition, answers?: ConditionalAnswers): string | undefined {
  const report = conditionalReport(definition, answers)
  if (report && definition.presentation === 'customer') return [
    `${definition.question} ${report.purpose}`,
    ...report.steps.map(step => `${step.question} ${step.answer}`),
    ...(report.comment ? [report.comment] : []),
    report.category === 'Needs Review' ? 'Help is needed to determine how this should work.' : '',
    definition.recommendedAction,
  ].filter(Boolean).join('\n')
  return report ? [
    `Payroll Code: ${report.code}`, `Reported Purpose: ${report.purpose}`,
    ...(report.followUp ? [`${report.followUp} ${report.answer}`] : []), ...(report.comment ? [`Additional information: ${report.comment}`] : []),
    `Tax Treatment: ${report.taxTreatment}`, `Cash Compensation: ${report.cashCompensation}`,
    // copy-exception(banned/configure): Exact specialist-summary label supplied by the user (voice guide A.7).
    `Configuration Verification: ${report.configurationVerification}`, `Review Status: ${report.category}`,
    ...(report.conflict ? ['Conflicting information needs review.'] : []),
    `Recommended Action: ${report.recommendedAction}`,
    ...(report.assessment ? [
      `Preliminary classification: ${report.assessment.classification}`,
      report.assessment.reasoning, report.assessment.mapping,
      `Confidence: ${report.assessment.confidence}`,
      `Mapping status: ${report.assessment.mappingStatus}`,
      `Tax provenance: ${report.assessment.taxProvenance}`,
      `Validation needed: ${report.assessment.validationNeeded.join(' ')}`,
      'Classification does not confirm tax compliance, regular-rate exclusion or setup readiness.',
    ] : []),
  ].join('\n') : undefined
}
