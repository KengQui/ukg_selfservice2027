/**
 * The confirmed configuration's two tables: who pays into each benefit plan, and every earning code's final
 * classification, shown in the final summary.
 */
import { useId } from 'react'
import { Tag } from '@ready/dls/compatibility'
import { ClassificationTag } from './QuestionCard'
import { summaryConfiguration, planConfiguration, type ConfigRow } from './configuration'
import { needsLegacyBonrevReview, type EarningSession } from './session'

/** Final classification first, then codes awaiting setup review or the customer, then codes left out. */
const ROW_ORDER = ['Earning', 'Deduction', 'combined', 'review', 'customer', 'notSetUp']
const rowRank = (row: ConfigRow) => ROW_ORDER.indexOf(row.status === 'ready' ? row.reference!.classification : row.status)

export function PlanContributionsSection({ session }: { session: EarningSession }) {
  const headingId = useId()
  const plans = planConfiguration(session)
  return (
    <section className="ec-summary-section" aria-labelledby={headingId}>
      <h2 id={headingId} className="text-caption ec-eyebrow">Who pays into each plan</h2>
      <p className="text-body ec-section-intro">Check which plan codes stay and which need adding before payroll starts. Plans are separate from the earning code counts below.</p>
      <div className="ec-table-wrap">
        <table className="ec-table ec-table--config">
          <caption className="ec-visually-hidden">Plan contributions and codes to set up</caption>
          <thead>
            <tr><th scope="col">Plan</th><th scope="col">Who pays</th><th scope="col">Codes kept</th><th scope="col">Codes to add</th><th scope="col">Still to confirm</th></tr>
          </thead>
          <tbody>
            {plans.map(plan => (
              <tr key={plan.code}>
                <td><span className="ec-code">{plan.code}</span> {plan.name}</td>
                <td>{plan.whoPays}</td>
                <td>{plan.kept.length ? plan.kept.join(', ') : '—'}</td>
                <td>{plan.added.length ? plan.added.join(', ') : '—'}</td>
                <td>{plan.waiting.length ? plan.waiting.join('; ') : '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  )
}

export function FinalClassificationSection({ session }: { session: EarningSession }) {
  const headingId = useId()
  const rows = summaryConfiguration(session)
  const legacyBonrev = needsLegacyBonrevReview(session)
  const orderedRows = [...rows].sort((a, b) => rowRank(a) - rowRank(b))
  return (
    <section className="ec-summary-section" aria-labelledby={headingId}>
      <h2 id={headingId} className="text-caption ec-eyebrow">Final classification ({rows.length} codes)</h2>
      <div className="ec-table-wrap">
        <table className="ec-table ec-table--config">
          <caption className="ec-visually-hidden">Final classification of earning codes</caption>
          <thead>
            <tr><th scope="col">Code</th><th scope="col">Description</th><th scope="col">Classification</th><th scope="col">Ready code</th><th scope="col">Notes</th></tr>
          </thead>
          <tbody>
            {orderedRows.map(row => (
              <tr key={row.code}>
                <td><span className="ec-code">{row.code}</span></td>
                <td>{row.description || '—'}</td>
                <td className="ec-table__tag">
                  {row.discoveryStatus && <Tag type="status" color={row.discoveryStatus === 'Complete' ? 'success' : 'warning'}
                    label={row.discoveryStatus === 'Complete' ? 'Discovery complete' : 'Needs review'} />}
                  {row.status === 'ready' && <ClassificationTag value={row.reference!.classification} />}
                  {row.status === 'customer' && <Tag type="status" color="warning" label={row.code === 'BONREV' && legacyBonrev ? 'Needs your review' : 'Waiting on the customer'} />}
                  {row.status === 'pending' && <Tag type="status" color="neutral" label="Needs an answer or review action" />}
                  {row.status === 'review' && <Tag type="status" color="warning" label="Awaiting setup review" />}
                  {row.status === 'notSetUp' && <Tag type="status" color="neutral" label="Not set up" />}
                  {row.status === 'combined' && <Tag type="status" color="neutral" label="Combined" />}
                </td>
                <td>{row.reference ? <>{row.combinedInto ? <>Combined into {row.combinedInto} · Set up as </> : null}{row.reference.name}<span className="ec-table__note">{row.reference.id}</span></> : '—'}</td>
                <td>
                  {row.customName && <span className="ec-table__proposed">Proposed name: <strong>{row.customName}</strong></span>}
                  {row.code === 'BONREV' && legacyBonrev ? 'Review BONREV to acknowledge the Deduction classification' : row.notes.length ? row.notes.join('. ') : '—'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  )
}
