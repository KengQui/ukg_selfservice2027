/**
 * Custom-name requests for description-led codes. Called only after the reference lookup explicitly found no suitable
 * reference; the server's AI then suggests one name or asks for the missing information. A failure never becomes a
 * stand-in name.
 */
import { suggestEarningName, type EarningNameInput } from '@workspace/api-client-react'
import { redactSensitive } from '@workspace/setup-shared/ask-bryte'
import { findCode, type ReviewItem } from './sampleRegister'
import { describedAnswers } from './descriptionCheck'
import { lookupResult, namingBasis, type ItemAnswer, type NamingResult } from './session'

export type NamingErrorCode = 'invalid_request' | 'rate_limited' | 'unavailable' | 'timed_out' | 'invalid_response'
const NAMING_ERROR_CODES: readonly NamingErrorCode[] = ['invalid_request', 'rate_limited', 'unavailable', 'timed_out', 'invalid_response']

/** Shown when the server's message can't be trusted as written, or the request never reached it. */
export const NAMING_FALLBACK_ERROR = 'We can’t suggest a name right now. Try again, or select Review later.'

export type NamingResponse =
  | { ok: true; result: NamingResult }
  | { ok: false; message: string }

const SOURCE_LABEL = 'Pay register data'

/** The request for a code whose lookup found no suitable reference; undefined for every other lookup result. */
export function namingRequest(item: ReviewItem, answer: ItemAnswer): EarningNameInput | undefined {
  const lookup = lookupResult(item, answer)
  if (lookup.kind !== 'noMatch' || item.type !== 'unidentified') return undefined
  // The same answers the check read, including answers to the AI's own questions.
  const answers = describedAnswers(item, answer)
  const sourceDescription = findCode(item.code)?.description || null
  return {
    code: item.code,
    source: { label: SOURCE_LABEL, description: sourceDescription },
    // Sensitive identifiers are removed here as well as on the server, so they never leave the browser.
    description: redactSensitive(answer.description?.trim() ?? ''),
    answers,
    lookup: { outcome: 'noSuitableReference', reason: lookup.reason },
  }
}

function errorMessage(error: unknown): string {
  if (typeof error !== 'object' || error === null || !('data' in error)) return NAMING_FALLBACK_ERROR
  const data = (error as { data: unknown }).data
  if (typeof data !== 'object' || data === null) return NAMING_FALLBACK_ERROR
  const { code, error: message } = data as { code?: unknown; error?: unknown }
  // Only this endpoint's documented errors carry a message written for this screen.
  return typeof code === 'string' && NAMING_ERROR_CODES.includes(code as NamingErrorCode)
    && typeof message === 'string' && message.trim() ? message : NAMING_FALLBACK_ERROR
}

export async function requestCustomName(input: EarningNameInput, signal: AbortSignal): Promise<NamingResponse> {
  try {
    const result = await suggestEarningName(input, { signal })
    if (result.outcome === 'suggestion' && result.name && result.rationale) {
      return { ok: true, result: { outcome: 'suggestion', name: result.name, rationale: result.rationale } }
    }
    if (result.outcome === 'needsInformation' && result.question) {
      return { ok: true, result: { outcome: 'needsInformation', question: result.question } }
    }
    return { ok: false, message: 'We couldn’t come up with a clear name this time. Try again, or select Review later.' }
  } catch (error) {
    if (signal.aborted) throw error
    return { ok: false, message: errorMessage(error) }
  }
}

export { namingBasis }
