import { useContext, useId } from 'react'
import TextArea from '@ready/dls/components/TextArea/TextArea'
import Link from '@ready/dls/components/Link/Link'
import { Button } from '@ready/dls/compatibility'
import type { ItemAnswer, SessionAction } from './session'
import { InlineDiscussionCard } from './inlineDiscussionPresentation'

/**
 * The description box inside a clarification's describe answer (Done locks it, and the code then waits for review), or
 * the optional note box inside a pick such as DEN's No (Done locks it for the live answer review; the pick stands alone).
 */
export default function DescribeAnswerBox({ itemId, answer, dispatch, label = 'Description', noun = 'description', caption }: {
  itemId: string; answer: ItemAnswer; dispatch: (action: SessionAction) => void; label?: string; noun?: 'description' | 'note'; caption?: string
}) {
  return <DescribeBoxView label={label} noun={noun} caption={caption}
    description={answer.description ?? ''} submitted={!!answer.descriptionSubmitted}
    onChange={description => dispatch({ type: 'describe', itemId, description })}
    onDone={() => dispatch({ type: 'submitDescription', itemId })}
    onEdit={() => dispatch({ type: 'editDescription', itemId })} />
}

/** The box itself: a 300-character description, Done to lock it and Edit to change it. */
export function DescribeBoxView({ label = 'Description', noun = 'description', caption, description, submitted, onChange, onDone, onEdit }: {
  label?: string; noun?: 'description' | 'note'; caption?: string; description: string; submitted: boolean
  onChange: (description: string) => void; onDone: () => void; onEdit: () => void
}) {
  const descriptionId = useId()
  const inline = useContext(InlineDiscussionCard)
  const tooLong = description.trim().length > 300
  if (inline && submitted && noun === 'description') return null
  return <div className="ec-describe">
    <TextArea id={descriptionId} label={label} value={description} rows={3} readOnly={submitted}
      onChange={onChange}
      warningText={tooLong ? `Keep the ${noun} within 300 characters.` : undefined} />
    <div className="ec-describe__actions">
      {submitted
        ? <Link size="sm" onClick={onEdit}>Edit {noun}</Link>
        : <Button variant="secondary" size="small" disabled={!description.trim() || tooLong} onClick={onDone}>Done</Button>}
    </div>
    {caption && !submitted && <p className="text-caption">{caption}</p>}
  </div>
}
