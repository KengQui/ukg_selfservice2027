import type { EarningSession } from './session'

const STORAGE_KEY = 'earning-response-cache-tab'
let fallback: string | undefined

/** An opaque browser namespace, never a company identifier or an authorization credential. */
function tabId() {
  try {
    const saved = sessionStorage.getItem(STORAGE_KEY)
    if (saved) return saved
    const id = crypto.randomUUID()
    sessionStorage.setItem(STORAGE_KEY, id)
    return id
  } catch {
    return fallback ??= crypto.randomUUID()
  }
}

export async function earningCacheHeaders(session: EarningSession, request: { method: string; url: string }): Promise<HeadersInit> {
  const url = new URL(request.url, window.location.origin)
  if (url.origin !== window.location.origin || request.method !== 'POST' || !/^\/api\/earnings\//.test(url.pathname)) return {}
  // Cache availability must never gate a live review in browsers without secure-context crypto.
  if (!globalThis.crypto?.subtle || !globalThis.crypto?.randomUUID) return {}
  const source = JSON.stringify([
    tabId(), session.registerOwnerId ?? null, session.registerSource ?? null,
    session.files.map(file => [file.id, file.sha256 ?? null]).sort(([a], [b]) => String(a).localeCompare(String(b))),
  ])
  // Only the digest leaves this browser; no raw company or document identity is put in a header.
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(source))
  return { 'X-Earning-Cache-Scope': Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('') }
}
