import { useEffect, useId, useState } from 'react'
import './deferCoffee.css'
import cupImage from './review-later-cup-base.png'
import teaBagImage from './review-later-teabag.png'

/** Local decoration only: restored selections stay still; only a new check starts steam. */
export default function DeferCoffee({ checked }: { checked: boolean }) {
  const cupMaskId = useId()
  const [previous, setPrevious] = useState(checked)
  const [steaming, setSteaming] = useState(false)
  if (previous !== checked) {
    setPrevious(checked)
    setSteaming(checked)
  }

  useEffect(() => {
    if (!checked || !steaming) return
    const timer = window.setTimeout(() => setSteaming(false), 8000)
    return () => window.clearTimeout(timer)
  }, [checked, steaming])

  const className = ['ec-defer-coffee', checked && 'ec-defer-coffee--checked',
    checked && steaming && 'ec-defer-coffee--steaming'].filter(Boolean).join(' ')
  return (
    <svg className={className} viewBox="0 0 40 40" aria-hidden="true" focusable="false" data-testid="defer-coffee">
      <g className="ec-defer-coffee__steam" fill="none" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round">
        <path d="M14 16c-3-3 3-4 0-7" />
        <path d="M20 16c-3-3 3-4 0-7" />
        <path d="M26 16c-3-3 3-4 0-7" />
      </g>
      <defs>
        <mask id={cupMaskId} maskUnits="userSpaceOnUse" x="2" y="17" width="36" height="20" style={{ maskType: 'alpha' }}>
          <image href={cupImage} x="2" y="17" width="36" height="20" />
        </mask>
      </defs>
      {/* The source mask is an outline, so its transparent bowl needs its own fill.
          Keep the handle opening clear and the original outline above the body. */}
      <path className="ec-defer-coffee__body" d="M3.55 18.7H30.2C29.5 25.8 25.2 35.7 16.9 36.1C9.3 36.1 4.4 26.9 3.55 18.7Z" fill="#0a433f" />
      <rect x="2" y="17" width="36" height="20" fill="#0a433f" mask={`url(#${cupMaskId})`} />
      <g className="ec-defer-coffee__teabag">
        <image href={teaBagImage} x="13.01294" y="18.53" width="4.25" height="12.03" />
      </g>
    </svg>
  )
}
