import { describe, expect, it } from 'vitest'
import { createSession } from './session'
import { bryteFacts } from './bryteFacts'
import { earningPages } from '../../askBrytePages'

describe('Ask Bryte on Allowances & reimbursements', () => {
  it('uses the current category without CELL guidance or suggestions', () => {
    const session = { ...createSession(1), step: 'questions' as const, registerSource: 'sample' as const,
      rounds: [{ number: 1, itemIds: ['CELL-purpose', 'MILEAGE'], submitted: false }] }
    const { key, facts } = bryteFacts(session)
    const page = earningPages[key](facts)
    expect(facts.topicId).toBe('expenses')
    expect(page.name).toBe('Allowances & reimbursements')
    expect(page.welcome).toContain('You’re on Allowances & reimbursements')
    expect(page.suggestions).toContain('How do allowances and reimbursements differ?')
    expect(JSON.stringify({ facts, page })).not.toContain('CELL')
    expect(facts.codesInView).toContain('MILEAGE')
    expect(facts).not.toHaveProperty('cellPurpose')
  })
})
