import { reviewEarningAnswer, type EarningAnswerReviewInput } from '@workspace/api-client-react'
import { redactSensitive } from '@workspace/setup-shared/ask-bryte'
import { cellFollowUpQuestions, CELL_ID } from './cell'
import { CHECK_FALLBACK_ERROR, type CheckErrorCode } from './descriptionCheck'
import { validFreshReview, type AnswerReviewTurn } from './answerReviewData'
import { ASK_CUSTOMER, EMPLOYER_CODE_QUESTION, EXISTING_CODE, SUGGESTED_CODE, findCode, typedNoteOption, type ReviewItem } from './sampleRegister'
import { askedFollowUps, reviewProcessFor, sharedSetupFor, somethingElseQuestion, type ItemAnswer } from './session'
import type { EarningSession } from './session'
import { usabilityFacts } from './usabilityFacts'

const ERROR_CODES: CheckErrorCode[] = ['invalid_request', 'rate_limited', 'unavailable', 'timed_out', 'invalid_response']
/** The thread exactly as the endpoint takes it: every field redacted again and within its length. */
export function threadRequest(thread: readonly AnswerReviewTurn[]): EarningAnswerReviewInput['thread'] {
  return thread.map(turn => ({
    ...(turn.reason ? { reason: redactSensitive(turn.reason).slice(0, 300) } : {}),
    ...(turn.suggestion ? { suggestion: redactSensitive(turn.suggestion).slice(0, 300) } : {}),
    question: redactSensitive(turn.question).slice(0, 200), reply: redactSensitive(turn.reply).slice(0, 500),
  }))
}

export function reviewRequest(item: ReviewItem, answer: ItemAnswer, question: string, label: string, detail: string,
  thread: readonly AnswerReviewTurn[] = [], session?: EarningSession): EarningAnswerReviewInput {
  const code = findCode(item.code)
  const options = item.type === 'unidentified' ? item.script.kind === 'uncertainMatch' ? item.script.options : []
    : item.type === 'misclassification' ? [item.accept] : item.options
  const earlier: { question: string; answer: string }[] = []
  const opening = options.find(option => option.id === answer.choice)
  if (opening) earlier.push({ question: item.question, answer: opening.label })
  // A clarification's typed text is either the describe answer (MED's No) or an optional note under the pick (DEN's No).
  if (answer.description?.trim()) earlier.push({
    question: item.type !== 'clarification' ? 'What does this code pay for?'
      : typedNoteOption(item, answer.choice) ? 'Anything you’d like to add about your answer?'
        // CELL's Something else describes another way the company pays it; MED's No describes what the code holds.
        : item.id === CELL_ID ? 'How else does the company pay CELL?' : `What does ${item.code} hold instead?`,
    answer: answer.description,
  })
  const followUps = item.id === CELL_ID ? cellFollowUpQuestions(answer) : askedFollowUps(item, answer)
  for (const entry of followUps) {
    const selected = entry.options.find(option => option.id === answer.followUps?.[entry.id])
    if (selected) earlier.push({ question: entry.question, answer: selected.label })
  }
  if (item.type === 'clarification' && item.employerCode) {
    const pick = answer.followUps?.[EMPLOYER_CODE_QUESTION]
    const picked = pick === SUGGESTED_CODE ? item.employerCode.suggested.label : pick === EXISTING_CODE ? item.employerCode.existing.label : undefined
    if (picked) earlier.push({ question: item.employerCode.question, answer: picked })
  }
  const shared = sharedSetupFor(item, answer)
  const sharedChoice = shared?.options.find(option => option.id === answer.sharedSetup?.choice)
  if (shared && sharedChoice) earlier.push({ question: shared.question, answer: sharedChoice.title })
  if (answer.sharedSetup?.description) earlier.push({ question: 'How is this pay different?', answer: answer.sharedSetup.description })
  if (answer.retain && answer.retain !== ASK_CUSTOMER) earlier.push({ question: 'Keep or remove this code?', answer: answer.retain })
  // The shared Something else: the description given instead of the listed answers to one question.
  const otherwise = answer.somethingElse && somethingElseQuestion(item, answer)
  if (otherwise && answer.somethingElse?.description.trim()) earlier.push({
    question: `Something else, instead of the listed answers to: ${otherwise}`, answer: answer.somethingElse.description.trim(),
  })
  return {
    code: item.code,
    // The server builds the prompt from the shared general part plus this process's part only.
    process: reviewProcessFor(item),
    facts: usabilityFacts(session, item.code) ?? {
      description: code?.description ? redactSensitive(code.description) : null,
      section: code?.section ?? null, peopleCount: code?.employees ?? null, amount: code?.amount ?? null,
      observedReference: code?.reference ? redactSensitive(`${code.reference.name} (${code.reference.id})`) : null,
    },
    question: redactSensitive(question), answer: redactSensitive(label), setupDetail: redactSensitive(detail),
    earlierAnswers: earlier.filter(entry => entry.question !== question).map(entry => ({
      question: redactSensitive(entry.question).slice(0, 500), answer: redactSensitive(entry.answer).slice(0, 500),
    })).slice(-20),
    thread: threadRequest(thread),
  }
}

const CODE_LABEL = /^[A-Za-z0-9][A-Za-z0-9 _-]{0,15}$/
export async function requestAnswerReview(input: EarningAnswerReviewInput, signal: AbortSignal) {
  try {
    const result = await reviewEarningAnswer(input, { signal })
    return validFreshReview(result)
      ? { ok: true as const, result }
      : { ok: false as const, message: 'We couldn’t review your answer this time. Try again, or keep going.' }
  } catch (error) {
    if (signal.aborted) throw error
    const data = error && typeof error === 'object' && 'data' in error ? error.data : undefined
    const known = data as { code?: CheckErrorCode; error?: unknown } | undefined
    const message = known?.code && ERROR_CODES.includes(known.code) && typeof known.error === 'string' && known.error.trim()
      ? known.error : CHECK_FALLBACK_ERROR
    return { ok: false as const, message }
  }
}

/**
 * A Something else description on an Optimization or Overtime question. It goes to the general-only
 * optimizationOvertime process: the shared general part and the answer review contract, no process rules. `codes` are the
 * pay codes the question is about (none for a screening question with no matched code), `context` the card's
 * explanation and `options` its listed answers.
 */
export function phaseReviewRequest({ codes, question, description, context, options, thread = [] }: {
  codes: readonly string[]; question: string; description: string; context: string; options: readonly string[]
  thread?: readonly AnswerReviewTurn[]
}): EarningAnswerReviewInput {
  const joined = codes.join(' ')
  const label = CODE_LABEL.test(joined) ? joined : codes.find(code => CODE_LABEL.test(code)) ?? 'OVERTIME'
  const code = codes.length === 1 ? findCode(codes[0]) : undefined
  return {
    code: label,
    process: 'optimizationOvertime',
    facts: {
      description: code?.description ? redactSensitive(code.description) : null,
      section: code?.section ?? null, peopleCount: code?.employees ?? null, amount: code?.amount ?? null,
      observedReference: code?.reference ? redactSensitive(`${code.reference.name} (${code.reference.id})`) : null,
    },
    question: redactSensitive(question).slice(0, 500), answer: 'Something else', setupDetail: redactSensitive(context).slice(0, 1000),
    earlierAnswers: [
      { question: `Listed answers to: ${question}`, answer: options.join('; ') },
      { question: `Something else, instead of the listed answers to: ${question}`, answer: description.trim() },
    ].map(entry => ({ question: redactSensitive(entry.question).slice(0, 500), answer: redactSensitive(entry.answer).slice(0, 500) })),
    thread: threadRequest(thread),
  }
}
