import { Button } from '@ready/dls/compatibility'
import { useEarningSession } from './sessionContext'
import { appliedConsequence } from './discussionConsequences'

export default function DiscussionAcknowledgment() {
  const { session, dispatch } = useEarningSession()
  const receipt = session.discussionApplications?.find(entry => entry.id === session.discussionAcknowledgment)
  if (!receipt || session.appliedReview || session.step === 'optimization') return null
  const next = session.step === 'review' ? 'Continue with the remaining discussion questions below.'
    : session.step === 'questions' ? 'Next, review the remaining questions below.'
      : session.step === 'discussionWork' ? 'Next, confirm the unfinished setup decisions below.'
        : ['overtime', 'overtimeSort', 'standardOvertime'].includes(session.step) ? 'Continue with your saved overtime review below.'
          : 'Continue with your saved review below.'
  return <section className="ec-page ec-page--wide" role="status" data-testid="discussion-applied">
    <h2 className="text-heading">Answers applied</h2>
    <ul>{Object.entries(receipt.outcomes).map(([id, outcome]) => <li key={id}>{appliedConsequence(id, outcome)}</li>)}</ul>
    <p>{next} Your live payroll is unchanged.</p>
    <Button variant="tertiary" size="small" onClick={() => dispatch({ type: 'dismissDiscussionAcknowledgment' })}>Dismiss</Button>
  </section>
}
