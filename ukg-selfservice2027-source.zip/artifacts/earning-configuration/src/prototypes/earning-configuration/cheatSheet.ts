import { DESCRIBE_CHOICE, codesAddedBy, findCode, findItem, isReviewItem, relatedNoteText, type ReviewItem } from './sampleRegister'
import { usabilityFacts } from './usabilityFacts'
import { activeCheck, retentionAsked, sharedSetupFor, type EarningSession, type Resolution } from './session'
import { itemInSession, MILEAGE_RATE_REASON, PER_MILE } from './mileage'
import { cellQuestionStage, cellFollowUpQuestions, CELL_ID } from './cell'
import { reimbursementAnswer } from './reimbursements'
import { needsTipsMethod, tipsMethodContext } from './tips'
import { medicalTarget, MEDICAL_COMPANY_ONLY } from './medical'
import { MED_NO_REASON, MED_ATTACHMENT_REASON, MED_COMPANY_ONLY_REASON, MED_DISPLAY_REASON } from './medicalReasons'
import { REVIEW_TOPICS, reviewTopicFor } from './reviewTopics'
import { callEvidence } from './cheatSheetAnswers'
import { pendingDiscussionQuestions } from './reviewDiscussionChoices'
import { sampleRegistersFor } from './sampleDocument'
import { cellOutstanding } from './cellFlow'
import { appliedDemoSkip } from './optionalDemoQuestions'
import { EARNING_DEMO_SETTINGS } from './demoSettings'
import { discussionContext, type DiscussionContext } from './discussionContext'

export interface CheatSheetRow {
  id: string; code: string; topic: string; evidence: string[]; answers: string[]
  setup: string; questions: string[]; reason: string; deferred: boolean
  context: DiscussionContext
}
export interface CheatSheetGroup { id: 'ask' | 'confirm' | 'setup'; title: string; rows: CheatSheetRow[] }

const money = (amount: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 2 }).format(amount)

export function registerEvidence(item: ReviewItem, session?: EarningSession): string[] {
  if (session?.scenario === 'usability') {
    const facts = usabilityFacts(session, item.code)!
    return [
      ...(facts.section ? ['Earnings'] : []),
      ...(facts.description ? [`Description: ${facts.description}`] : []),
      ...(facts.amount !== null ? [`Total across supplied periods: ${money(facts.amount)}`] : []),
      ...(facts.peopleCount !== null ? [`Distinct people across supplied periods: ${facts.peopleCount}`] : []),
    ]
  }
  const source = findCode(item.code)
  if (source?.code === 'ADJ2') {
    const registers = session ? sampleRegistersFor(session.files).filter(register =>
      session.files.some(file => file.id === register.file.id)) : []
    return [
      'ADJ2 appears in earnings without a description.',
      ...registers.flatMap(register => {
        const row = register.rows.find(row => row.code === source.code)
        return row ? [
          `${register.period} · Reported period amount: ${row.periodAmount === undefined ? 'Not provided' : money(row.periodAmount)}`,
        ] : []
      }),
    ]
  }
  if (!source) {
    const parent = item.type === 'finding' ? findCode(findItem(item.raisedBy).code) : undefined
    return ['Not shown as a separate code in the pay register data.', ...(parent ? [
      `Source ${parent.code}: ${parent.section === 'earnings' ? 'Earnings' : 'Deductions'}`,
      ...(parent.description ? [`Source description: ${parent.description}`] : []),
    ] : [])]
  }
  return [
    source.section === 'earnings' ? 'Earnings' : 'Deductions',
    ...(source.description ? [`Description: ${source.description}`] : []),
  ]
}

export function setupText(session: EarningSession, item: ReviewItem, resolution: Resolution): string {
  if (resolution.status === 'recommended') return 'Recommendation complete. No payroll setup changes have been made.'
  if (resolution.status === 'customer') return 'Ready setup: Waiting for the customer’s answer.'
  if (resolution.status === 'removed') return 'Removed from the setup.'
  if (resolution.status === 'review') return resolution.customName
    ? `Proposed name: ${resolution.customName.name}. Awaiting setup review; no Ready setup confirmed.`
    : 'Awaiting setup review; no Ready setup confirmed.'
  if (resolution.outputs) return `Ready setup: Split ${item.code} into ${resolution.outputs.map(output => `${output.code} — ${output.reference.name}`).join(' and ')}.`
  if (item.type === 'finding' && item.addedCodes) return `Ready setup: ${item.addedCodes.map(output => `${output.code} — ${output.reference.name}`).join('; ')}.`
  return [
    resolution.combinedInto ? `Combined into ${resolution.combinedInto}.` : '',
    `Ready setup: ${resolution.reference.name} (${resolution.reference.classification}).`,
    resolution.relatedNote ? relatedNoteText(resolution.reference.id, item.code, resolution.relatedNote) : '',
    ...codesAddedBy(item, session.answers[item.id]).map(output => `Also set up ${output.code} as ${output.reference.name}.`),
  ].filter(Boolean).join(' ')
}

/** Current reasons follow the decision, never additional requests from a saved draft. */
function reasonFor(item: ReviewItem, session: EarningSession, deferred: boolean): string {
  const answer = session.answers[item.id] ?? {}
  let content = item.type === 'misclassification' ? item.why : item.context
  const payment = reimbursementAnswer(item, answer)
  if (payment) return cellOutstanding(payment)?.context ?? ''
  if (!deferred && item.type === 'clarification' && item.options.some(option => option.id === 'premium')) {
    return `The ${item.code} confirmation distinguishes payment of only the additional overtime premium, the full overtime rate or a flat amount.\n\nThat answer supports determining whether the register amounts match what people should have received and identifying what needs to be reviewed if they do not. The result above is a review decision, not confirmation that amounts have been reconciled.`
  }
  if (item.id === CELL_ID) {
    const stage = cellQuestionStage(answer)
    content = !answer.cellLegacy ? cellOutstanding(answer)?.context ?? ''
      : cellFollowUpQuestions(answer).find(question => question.id === stage)?.context ?? content
  }
  if (item.id === 'MILEAGE' && answer.choice === PER_MILE) content = MILEAGE_RATE_REASON
  if (item.id === 'TIPS' && needsTipsMethod(answer)) content = tipsMethodContext(answer)
  if (item.id === 'MED') content = answer.choice === DESCRIBE_CHOICE ? MED_NO_REASON
    : 'The MED confirmation identifies the employee medical deduction. The company contribution can then be attached to the employer portion of that deduction, rather than proposed as a separate earning.'
  if (item.id === 'MED ER' && answer.choice === 'only-records') {
    const target = medicalTarget(session)
    content = !target ? MED_ATTACHMENT_REASON
      : !target.code && !answer.followUps?.[MEDICAL_COMPANY_ONLY] ? MED_COMPANY_ONLY_REASON : MED_DISPLAY_REASON
  }
  if (item.type === 'unidentified') {
    const check = activeCheck(item, answer)
    const followUp = item.script.kind !== 'uncertainMatch' && check?.kind === 'followUp'
      ? item.script.questions.find(question => question.id === check.questionId) : undefined
    const shared = sharedSetupFor(item, answer)
    content = followUp?.context ?? (shared && !answer.sharedSetup ? shared.context : content)
    if (check?.kind === 'needsInformation') content = `The detail in the current question is still missing: ${check.question}\n\nIt distinguishes the available payment proposals without guessing from the code name.\n\nThe reply is considered with the earlier answers before a reference or name is proposed. It does not accept or apply that proposal.`
    if (answer.retain === 'remove' || !deferred) return 'The payment’s purpose, calculation and use support a reference proposal or a custom name for review. Keeping or leaving out a code is a separate decision and does not delete earlier payroll activity.\n\nThe result above shows what was confirmed or left with the setup team. A name proposal alone does not establish payroll or tax treatment.'
    if (item.retention && retentionAsked(item, answer) && (!answer.retain || answer.retain === 'ask-customer')) content = item.retention.prompt
  }
  // Results no longer ask for the opening missing fact. Keep the purpose AND use of the answer,
  // not an arbitrary final sentence that loses the business reason.
  return deferred ? content : content.split(/\n\s*\n/).filter(Boolean).slice(content.includes('\n\n') ? 1 : 0).join('\n\n')
}

export function cheatSheetGroups(session: EarningSession): CheatSheetGroup[] {
  const ids = [...new Set(session.rounds.filter(round => round.submitted).flatMap(round => round.itemIds))]
    // Keep skipped examples out of the demo presentation, not out of saved history or readiness.
    // Explicit deferrals and confirmed decisions remain visible even for optional example codes.
    .filter(id => isReviewItem(id) && (!!session.resolutions[id]
      || (!EARNING_DEMO_SETTINGS.hideOptionalQuestions && appliedDemoSkip(session, id))))
  const position = (id: string) => {
    const item = findItem(id)
    const topic = reviewTopicFor(item)
    const root = item.type === 'finding' ? item.raisedBy : id
    return REVIEW_TOPICS.indexOf(topic) * 100 + Math.max(0, topic.itemIds.indexOf(root))
  }
  ids.sort((a, b) => position(a) - position(b))
  const groups: CheatSheetGroup[] = [
    { id: 'ask', title: 'To discuss', rows: [] },
    { id: 'confirm', title: 'Review results', rows: [] },
    { id: 'setup', title: 'With the setup team', rows: [] },
  ]
  for (const id of ids) {
    const item = itemInSession(findItem(id), session.answers)
    const resolution = session.resolutions[id]
    if (!resolution) {
      const evidence = callEvidence(item, session.answers[id], false)
      groups[1].rows.push({
        id, code: item.code, topic: reviewTopicFor(item).title, evidence: registerEvidence(item, session),
        answers: evidence.answers.map(entry => `${entry.question} ${entry.answer}`),
        setup: 'Unresolved — no setup decision applied.',
        questions: [], reason: 'This code still needs an answer or review action before its setup can be confirmed.', deferred: false,
        context: discussionContext(item, session.answers[id], undefined, ''),
      })
      continue
    }
    const deferred = resolution.status === 'customer'
    const evidence = callEvidence(item, session.answers[id], session.resolutions[id]?.status === 'resolved')
    const questions = pendingDiscussionQuestions(session, id)
    groups[deferred ? 0 : resolution.status === 'review' ? 2 : 1].rows.push({
      id, code: item.code, topic: reviewTopicFor(item).title, evidence: registerEvidence(item, session),
      answers: [...evidence.answers.map(entry => `${entry.question} ${entry.answer}`), ...(deferred ? ['Not answered yet']
        : evidence.answers.length ? [] : [resolution.status === 'review' && resolution.note ? resolution.note : 'No answer saved from this review.'])],
      setup: setupText(session, item, resolution),
      questions: questions.map(entry => entry.question),
      reason: reasonFor(item, session, deferred), deferred,
      context: discussionContext(item, session.answers[id], resolution,
        reasonFor(item, session, deferred)),
    })
  }
  return groups.filter(group => group.rows.length)
}
