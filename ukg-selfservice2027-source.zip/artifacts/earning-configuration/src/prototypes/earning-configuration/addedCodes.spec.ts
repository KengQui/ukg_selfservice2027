import { describe, expect, it } from 'vitest'
import { addedCodesDecided, addedCodesPending, reduceAddedCodes, validAddedCodes, type AddedCodesState } from './addedCodes'
import { addedCodesPageIndex, canFinishInitialReview, createSession, parseSession, reduceSession, reviewPages, reviewPosition, type EarningSession } from './session'
import { canMoveToPage, reviewSteps } from './reviewStatus'
import { REVIEW_TOPICS } from './reviewTopics'
import { summaryCsv } from './summary'

const add = (state: AddedCodesState | undefined, code: string, name: string, description: string) => {
  let next = reduceAddedCodes(state, { kind: 'start' })
  next = reduceAddedCodes(next, { kind: 'change', field: 'code', value: code })
  next = reduceAddedCodes(next, { kind: 'change', field: 'name', value: name })
  next = reduceAddedCodes(next, { kind: 'change', field: 'description', value: description })
  return reduceAddedCodes(next, { kind: 'save' })
}

describe('added codes state', () => {
  it('allows the fresh blank form to continue without inventing an answer', () => {
    const fresh = reduceAddedCodes(undefined, { kind: 'start' })
    expect(addedCodesDecided(fresh)).toBe(true)
    expect(addedCodesPending(fresh)).toBeUndefined()
    expect(fresh.entries).toEqual([])
    expect(fresh.none).toBeUndefined()
    expect(addedCodesDecided(reduceAddedCodes(fresh, { kind: 'change', field: 'description', value: 'Annual bonus' }))).toBe(false)
  })
  it('allows continuing after cancelling or removing additions without recording none', () => {
    const cancelled = reduceAddedCodes(reduceAddedCodes(undefined, { kind: 'start' }), { kind: 'cancel' })
    const removed = reduceAddedCodes(add(undefined, '', 'Bonus', 'Annual payment'), { kind: 'remove', id: 'added-1' })
    for (const state of [cancelled, removed, validAddedCodes({ entries: [] })!]) {
      expect(addedCodesDecided(state)).toBe(true)
      expect(addedCodesPending(state)).toBeUndefined()
      expect(state.none).toBeUndefined()
    }
  })

  it('can add a code after restoring a former none selection', () => {
    const restored = parseSession(JSON.stringify({ ...createSession(1), addedCodes: { entries: [], none: true } }))!
    const state = add(restored.addedCodes, '', 'Bonus', 'Annual payment')
    expect(state.entries).toHaveLength(1)
    expect(state.none).toBeUndefined()
    expect(addedCodesDecided(state)).toBe(true)
  })

  it('adds, edits and removes several codes', () => {
    let state = add(undefined, 'BONYR', 'Yearly bonus', 'Paid each December')
    state = add(state, '', 'Referral bonus', 'Paid when a referred hire stays 90 days')
    expect(state.entries.map(entry => entry.id)).toEqual(['added-1', 'added-2'])
    state = reduceAddedCodes(state, { kind: 'edit', id: 'added-1' })
    expect(addedCodesDecided(state)).toBe(false)
    state = reduceAddedCodes(state, { kind: 'change', field: 'name', value: 'Annual bonus' })
    state = reduceAddedCodes(state, { kind: 'save' })
    expect(state.entries[0]).toMatchObject({ id: 'added-1', code: 'BONYR', name: 'Annual bonus' })
    state = reduceAddedCodes(state, { kind: 'remove', id: 'added-1' })
    expect(state.entries.map(entry => entry.id)).toEqual(['added-2'])
    expect(add(state, 'X', 'X', 'x').entries.at(-1)!.id).toBe('added-3')
  })

  it('saves and restores an intention without a code or name', () => {
    const state = add(undefined, '', '', 'A yearly bonus paid each December')
    expect(state.entries).toHaveLength(1)
    expect(state.draft).toBeUndefined()
    const stable = (value: AddedCodesState | undefined) => ({ ...value, entries: value!.entries.map(({ check, ...entry }) => ({ ...entry, status: check?.status })) })
    expect(stable(validAddedCodes(state))).toEqual(stable(state))
    const session = { ...createSession(1), addedCodes: state }
    expect(stable(parseSession(JSON.stringify(session))!.addedCodes)).toEqual(stable(state))
    expect(summaryCsv(session, () => 'now')).toContain('A yearly bonus paid each December')
  })

  it('still requires a description', () => {
    const state = add(undefined, '', 'Bonus', ' ')
    expect(state.entries).toEqual([])
    expect(state.draft).toBeDefined()
    expect(addedCodesPending(state)).toMatch(/Save the code/)
  })

  it('records an explicit none only without entries', () => {
    expect(addedCodesDecided(undefined)).toBe(false)
    const none = reduceAddedCodes(undefined, { kind: 'none', value: true })
    expect(addedCodesDecided(none)).toBe(true)
    const withEntry = add(undefined, 'A', '', 'a')
    expect(reduceAddedCodes(withEntry, { kind: 'none', value: true }).none).toBeUndefined()
    expect(reduceAddedCodes(none, { kind: 'start' }).none).toBeUndefined()
  })

  it('restores valid saved state and drops malformed entries', () => {
    const restored = validAddedCodes({ entries: [{ id: 'added-1', code: 'A', name: '', description: 'a' }, { id: 'bad', code: 'B', name: '', description: 'b' }],
      none: true, draft: { editing: 'added-1', code: 'A', name: 'x', description: 'a' } })
    expect(restored).toEqual({ entries: [{ id: 'added-1', code: 'A', name: '', description: 'a' }],
      draft: { editing: 'added-1', code: 'A', name: 'x', description: 'a' } })
    expect(validAddedCodes('nope')).toBeUndefined()
  })
})

const startBundled = (): EarningSession => reduceSession(createSession(0), { type: 'startReview' }, 1)

describe('added codes page in the initial review', () => {
  it('is the last step after Other codes, and gates Next until answered', () => {
    const session = startBundled()
    expect(session.rounds).toHaveLength(1)
    const pages = reviewPages(session)
    expect(addedCodesPageIndex(session)).toBe(pages.length)
    expect(reviewPosition(session).total).toBe(pages.length + 1)
    const steps = reviewSteps(session)
    expect(steps.at(-1)!.label).toBe('Additional earning codes')
    expect(steps.at(-2)!.label).toBe(REVIEW_TOPICS.at(-1)!.title)
    expect(canFinishInitialReview(session)).toBe(false)
  })

  it('resumes on the added-codes page, keeps Back to Other codes, and blocks skipping ahead', () => {
    const session = startBundled()
    const last = reviewPages(session).length
    // Unanswered earlier pages block a forward jump to the last step.
    expect(canMoveToPage(session, last)).toBe(false)
    const saved = parseSession(JSON.stringify({ ...session, reviewCursor: last, reviewItemId: 'additional-codes' }))!
    expect(reviewPosition(saved).index).toBe(last)
    expect(reduceSession(saved, { type: 'moveReview', index: last - 1 }, 2).reviewCursor).toBe(last - 1)
    const none = reduceSession(saved, { type: 'addedCodes', event: { kind: 'none', value: true } }, 3)
    expect(none.addedCodes).toEqual({ entries: [], none: true })
    // Register evidence and answers are untouched by additions.
    expect(none.files).toEqual(saved.files)
    expect(none.answers).toEqual(saved.answers)
  })

  it('keeps additions and drafts across save and reload', () => {
    let session: EarningSession = { ...createSession(1), addedCodes: add(undefined, 'BONYR', 'Yearly bonus', 'Paid each December') }
    session = reduceSession(session, { type: 'addedCodes', event: { kind: 'start' } }, 2)
    session = reduceSession(session, { type: 'addedCodes', event: { kind: 'change', field: 'code', value: 'REF' } }, 3)
    const restored = parseSession(JSON.stringify(session))!
    expect(restored.addedCodes!.entries).toHaveLength(1)
    expect(restored.addedCodes!.draft!.code).toBe('REF')
    // Older saves without additions still restore.
    const { addedCodes: _omit, ...old } = session
    expect(parseSession(JSON.stringify(old))!.addedCodes).toBeUndefined()
  })

  it('exports additions as awaiting setup review without a Ready code', () => {
    const session: EarningSession = { ...createSession(1), addedCodes: add(undefined, 'BONYR', 'Yearly bonus', 'Paid each December') }
    const csv = summaryCsv(session, () => 'now')
    const line = csv.split('\r\n').find(row => row.startsWith('"Added by your team"'))!
    expect(line).toContain('"BONYR","Yearly bonus","","","","Awaiting setup review"')
    expect(line).toContain('Paid each December')
  })

  it('does not allow moving past the page count', () => {
    expect(canMoveToPage(createSession(1), 0)).toBe(false)
  })
})
