import { ASK_CUSTOMER, EMPLOYER_CODE_QUESTION, EXISTING_CODE, SUGGESTED_CODE, legacyTipsOption, type ReviewItem } from './sampleRegister'
import { askedFollowUps, sharedSetupFor, somethingElseQuestion, type ItemAnswer } from './session'
import { CELL_ID, cellFollowUpQuestions } from './cell'
import { TIPS_ID, TIPS_METHOD, needsTipsMethod, tipsMethodQuestion, tipsMethodOptions } from './tips'
import { MEDICAL_DISPLAY, MEDICAL_COMPANY_ONLY } from './medical'
import { answerReviewBasis } from './answerReviewData'
import { SOMETHING_ELSE_MAIN_ITEMS } from './somethingElse'
import { cellOutstanding } from './cellFlow'
import { tipsOutstanding } from './tipsFlow'
import { isTipsCode } from './tipsIdentity'
import { historicalCellItem } from './cellHistory'
import { reimbursementAnswer } from './reimbursements'

export interface CallQuestion { question: string; choices: string[]; deferred?: boolean }
export interface CallAnswer { question: string; answer: string }

export function callEvidence(item: ReviewItem, answer: ItemAnswer = {}, applied = false): { questions: CallQuestion[]; answers: CallAnswer[] } {
  if (isTipsCode(item.id) && answer.tipsReview) {
    const open = tipsOutstanding(answer, item.id)
    return { questions: open ? [{ question: open.question, choices: open.options ?? [], deferred: !!answer.tipsReview.deferred }] : [],
      answers: answer.tipsReview.entries.map(entry => ({ question: entry.question, answer: entry.answer })) }
  }
  const payment = reimbursementAnswer(item, answer)
  if (payment) {
    const open = cellOutstanding(payment)
    return { questions: open ? [{ question: open.question, choices: open.options?.map(o => [o.label, o.detail].filter(Boolean).join(' — '))
      ?? (open.format?.kind === 'choices' ? open.format.options : []), deferred: !!payment.cell?.deferred }] : [],
      answers: [{ question: 'Previously supplied payment facts', answer: payment.reimbursement!.purpose },
        ...(payment.cell?.entries ?? []).map(e => ({ question: `${e.question} (${e.component})`, answer: e.answer }))] }
  }
  if (item.id === CELL_ID && answer.cellLegacy) item = historicalCellItem()
  if (item.id === CELL_ID && answer.cell) {
    const open = cellOutstanding(answer)
    return {
      questions: open ? [{ question: open.question, choices: open.options?.map(o => [o.label, o.detail].filter(Boolean).join(' — '))
        ?? (open.format?.kind === 'choices' ? open.format.options : []),
        deferred: !!answer.cell.deferred || (answer.choice === ASK_CUSTOMER && !answer.cell.entries.length) }] : [],
      answers: [
        ...(answer.cell.earlier ? callEvidence(historicalCellItem(), { ...answer.cell.earlier, cellLegacy: true }, true).answers
          .map(e => ({ ...e, question: `Earlier answer (history): ${e.question}` })) : []),
        ...answer.cell.entries.map(e => ({ question: `${e.question}${e.id.startsWith('tax-') ? ` (${e.component})` : ''}`, answer: e.answer })),
      ],
    }
  }
  const questions: CallQuestion[] = []
  const answers: CallAnswer[] = []
  const pendingReview = Object.values(answer.reviews ?? {}).find(review =>
    review.basis === answerReviewBasis(answer) && !review.dismissed && review.result.question && !review.reply)
  const typedDeferredQuestion = answer.choice === ASK_CUSTOMER
    ? (answer.check?.result.kind === 'needsInformation' ? answer.check.result.question : pendingReview?.result.question)
    : undefined
  const add = (question: string, choices: { id: string; label: string; detail?: string }[], choice?: string) => {
    questions.push({ question, choices: choices.map(option => [option.label, option.detail].filter(Boolean).join(' — ')),
      deferred: choice === ASK_CUSTOMER })
    const selected = choices.find(option => option.id === choice)
    if (selected && choice !== ASK_CUSTOMER) answers.push({ question, answer: [selected.label, selected.detail].filter(Boolean).join(' — ') })
  }
  // Purpose-first input is text. Script options belong to an older, different question.
  // Keep that older question only when a saved answer actually selected one of its options.
  const purposeFirst = item.type === 'unidentified' && item.purposeFirst
    && !(item.script.kind === 'uncertainMatch' && item.script.options.some(option => option.id === answer.choice))
    ? item.purposeFirst : undefined
  const openingQuestion = purposeFirst?.question ?? item.question
  const choices = purposeFirst ? [] : item.type === 'misclassification' ? [item.accept]
    : item.type !== 'unidentified' ? item.options
      : item.script.kind === 'uncertainMatch' ? item.script.options : []
  const legacyTips = legacyTipsOption(item, answer.choice)
  const openingChoices = legacyTips
    ? ['payroll', 'reported', 'pool', 'multiple', ...(answer.choice === 'both' ? ['both'] : [])]
      .flatMap(choice => { const option = legacyTipsOption(item, choice); return option ? [option] : [] })
    : choices
  add(openingQuestion, openingChoices, answer.choice)
  if (typedDeferredQuestion) questions[0].deferred = false
  if (item.type === 'clarification' && item.describe) questions[0].choices.push(item.describe.label)
  if (openingChoices.length && SOMETHING_ELSE_MAIN_ITEMS.includes(item.id)) questions[0].choices.push('Something else')
  if (answer.description?.trim()) answers.push({ question: openingQuestion, answer: answer.description.trim() })
  const followUps = item.id === CELL_ID ? cellFollowUpQuestions(answer) : askedFollowUps(item, answer)
  for (const followUp of followUps) add(followUp.question, followUp.options, answer.followUps?.[followUp.id])
  if (item.id === TIPS_ID && needsTipsMethod(answer, applied)) add(tipsMethodQuestion(answer), [...tipsMethodOptions(answer)], answer.followUps?.[TIPS_METHOD])
  if (item.type === 'clarification' && item.employerCode && answer.choice === 'both') {
    const employer = item.employerCode
    add(employer.question, [
      { id: SUGGESTED_CODE, label: employer.suggested.label },
      { id: EXISTING_CODE, label: employer.existing.label },
    ], answer.followUps?.[EMPLOYER_CODE_QUESTION])
    if (answer.employerCodeName?.name) answers.push({ question: employer.existing.nameLabel, answer: answer.employerCodeName.name })
  }
  if (answer.mileageRate?.amount) answers.push({ question: 'How much do you pay for each mile?', answer: `$${answer.mileageRate.amount} a mile` })
  if (item.id === 'MED ER' && answer.choice === 'only-records') {
    add('Show the company’s medical amount on pay statements?', [{ id: 'yes', label: 'Yes' }, { id: 'no', label: 'No' }], answer.followUps?.[MEDICAL_DISPLAY])
    if (answer.followUps?.[MEDICAL_COMPANY_ONLY]) add('Use a company-only medical setup?', [{ id: 'accept', label: 'Use the company-only medical setup' }], answer.followUps[MEDICAL_COMPANY_ONLY])
  }
  const shared = sharedSetupFor(item, answer)
  if (shared) {
    add(shared.question, shared.options.map(option => ({ id: option.id, label: option.title })), answer.sharedSetup?.choice)
    const savedQuestion = answer.sharedSetup?.customerQuestion
    if (savedQuestion && answer.sharedSetup?.choice === ASK_CUSTOMER) {
      const question = questions.at(-1)!
      question.question = savedQuestion
      question.choices = answer.shiftPremium?.result?.question === savedQuestion
        && answer.shiftPremium.result.format?.kind === 'choices' ? answer.shiftPremium.result.format.options : []
    } else if (answer.sharedSetup?.choice === ASK_CUSTOMER && answer.shiftPremium?.result?.outcome === 'question') {
      questions.at(-1)!.deferred = false
    }
  }
  if (answer.sharedSetup?.description?.trim()) answers.push({ question: 'How is this pay different?', answer: answer.sharedSetup.description.trim() })
  if (item.type === 'unidentified' && item.retention && answer.retain) add(item.retention.question, item.retention.options, answer.retain)
  if (answer.somethingElse?.description?.trim()) answers.push({
    question: somethingElseQuestion(item, answer) ?? item.question, answer: `Something else: ${answer.somethingElse.description.trim()}`,
  })
  for (const entry of answer.checkAnswers ?? []) answers.push({ question: entry.question, answer: entry.answer })
  for (const review of Object.values(answer.reviews ?? {})) {
    if (review.basis !== answerReviewBasis(answer)) continue
    for (const turn of review.thread ?? []) answers.push({ question: turn.question, answer: turn.reply })
    if (review.reply && review.result.question) answers.push({ question: review.result.question, answer: review.reply })
    if (review.result.question && !review.reply) questions.push({ question: review.result.question, choices: [],
      deferred: review.result.question === typedDeferredQuestion })
  }
  for (const turn of answer.shiftPremium?.thread ?? []) answers.push({ question: turn.question, answer: turn.reply })
  const pendingShift = answer.shiftPremium?.result
  if (pendingShift?.outcome === 'question' && pendingShift.question) questions.push({ question: pendingShift.question, choices: pendingShift.format?.kind === 'choices' ? pendingShift.format.options : [],
    deferred: answer.sharedSetup?.choice === ASK_CUSTOMER && !answer.sharedSetup.customerQuestion })
  if (answer.check?.result.kind === 'needsInformation') questions.push({
    question: answer.check.result.question, choices: answer.check.result.format?.kind === 'choices' ? answer.check.result.format.options : [],
    deferred: answer.check.result.question === typedDeferredQuestion,
  })
  // Defer identifies a gap, not a business answer.
  return { questions, answers: answers.filter(entry => entry.answer !== ASK_CUSTOMER) }
}
