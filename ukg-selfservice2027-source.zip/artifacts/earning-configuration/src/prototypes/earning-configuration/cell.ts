import { ASK_CUSTOMER, DESCRIBE_CHOICE, READY, findItem, type FollowUpQuestion } from './sampleRegister'
import type { Decision, ItemAnswer } from './session'
import { somethingElseNote, withSomethingElseEnding } from './somethingElse'
import { cellFlowDecision, cellNext, cellOutstanding, reduceCell, type CellQuestion } from './cellFlow'

export const CELL_ID = 'CELL-purpose'
export type CellStage = 'purpose' | 'treatment' | 'split' | `v2-${string}`
export const isCellQuestion = (id: string) => id.startsWith('CELL-v2-') || ['CELL-purpose', 'CELL-treatment', 'CELL-split'].includes(id)
export const cellStageFromId = (id: string): CellStage => id.startsWith('CELL-v2-') ? id.slice(5) as CellStage : id === 'CELL-treatment' ? 'treatment' : id === 'CELL-split' ? 'split' : 'purpose'
const purposes = ['allowance', 'reimbursement', 'both']
const treatments = ['qualifying', 'taxable']
/** The purpose answers a reply or a saved answer may hold: the three listed purposes and Something else. */
export const CELL_PURPOSE_CHOICES: readonly string[] = [...purposes, DESCRIBE_CHOICE]

/** Something else's description, once Done locks it within 300 characters; it never sets up CELL. */
function describedNote(answer: ItemAnswer): string | undefined {
  const note = answer.description?.trim()
  return answer.choice === DESCRIBE_CHOICE && answer.descriptionSubmitted && note && note.length <= 300 ? note : undefined
}

/**
 * The tax or split question a Something else answers, while that question is the one still open. Purpose keeps its
 * own Something else (DESCRIBE_CHOICE), so only the follow-ups use the shared answer.
 */
export function cellSomethingElseQuestion(answer: ItemAnswer = {}, key = answer.somethingElse?.question): string | undefined {
  if (key !== 'treatment' && key !== 'split') return undefined
  if (answer.followUps?.[key]) return undefined
  const upstream: ItemAnswer = { choice: answer.choice, followUps: key === 'split' ? { treatment: answer.followUps?.treatment ?? '' } : {} }
  return cellFollowUpQuestions(upstream).find(question => question.id === key)?.question
}

export function cellQuestionStage(answer: ItemAnswer = {}): CellStage | undefined {
  if (!answer.cellLegacy) {
    if (cellFlowDecision(answer)?.kind === 'resolve' || cellFlowDecision(answer)?.kind === 'describe') return undefined
    const outstanding = cellOutstanding(answer)
    return outstanding ? `v2-${outstanding.id}-r${answer.cell?.replyRound ?? 0}` : undefined
  }
  // A described Something else asks nothing more: CELL waits for the setup team's review.
  if (describedNote(answer)) return undefined
  if (cellSomethingElseQuestion(answer) && somethingElseNote(answer.somethingElse)) return undefined
  if (!purposes.includes(answer.choice ?? '')) return 'purpose'
  if (answer.choice === 'allowance') return undefined
  if (!treatments.includes(answer.followUps?.treatment ?? '')) return 'treatment'
  return answer.choice === 'both' && answer.followUps?.split !== 'confirm' ? 'split' : undefined
}

export function cellFollowUpQuestions(answer: ItemAnswer = {}): FollowUpQuestion[] {
  if (!answer.cellLegacy) {
    const next = cellNext(answer)
    const questions: CellQuestion[] = [...(answer.cell?.entries ?? []).filter(e => e.id !== 'method'),
      ...(next.kind === 'question' && next.question.id !== 'method' ? [next.question] : [])]
    return questions.map(q => ({ ...q, id: `v2-${q.id}`, options: q.options ?? [] }))
  }
  if (answer.choice !== 'reimbursement' && answer.choice !== 'both') return []
  const questions: FollowUpQuestion[] = [{
    id: 'treatment',
    question: 'Should the phone payback be taxed?',
    context: 'You’ve confirmed that CELL repays business phone costs, but not the tax treatment your payroll or tax adviser has confirmed.\n\nA payback is only tax-free when it meets the applicable rules; receipts alone aren’t enough to establish that.\n\nYour answer selects tax-free or taxable treatment for the payback portion. If that treatment hasn’t been confirmed, select Review later rather than guessing.',
    options: [
      { id: 'qualifying', label: 'No, it’s tax-free', detail: 'Our adviser confirmed it meets the rules' },
      // Neither detail starts with “We”: the labels are the customer's answer, and a product “We’ll…” beside them blurs who’s speaking.
      { id: 'taxable', label: 'Yes, tax it as pay', detail: 'It’s taxed the same way as wages' },
    ],
  }]
  if (answer.choice === 'both' && treatments.includes(answer.followUps?.treatment ?? '')) questions.push({
    id: 'split',
    question: 'Can we split CELL into two codes?',
    context: `You’ve confirmed both a fixed allowance and a business phone payback, including the payback’s tax treatment. Permission to separate them is still needed.\n\nThe two purposes need their own codes even when both are taxed as pay.\n\nConfirming replaces CELL in the proposed setup with CELL-ALLOW for the allowance (taxed as pay) and CELL-REIMB for the payback (${answer.followUps?.treatment === 'qualifying' ? 'tax-free' : 'taxed as pay'}). This separates the purposes without changing the amounts people receive.`,
    options: [{ id: 'confirm', label: 'Yes, split CELL into two codes', detail: 'CELL-ALLOW and CELL-REIMB replace CELL' }],
  })
  return questions
}

export function cellDecision(answer: ItemAnswer = {}): Decision | undefined {
  if (!answer.cellLegacy) return cellFlowDecision(answer)
  if (answer.choice === ASK_CUSTOMER) return { kind: 'defer' }
  if (answer.choice === DESCRIBE_CHOICE) {
    const note = describedNote(answer)
    return note ? { kind: 'describe', note } : undefined
  }
  const question = cellSomethingElseQuestion(answer)
  if (question) {
    const note = somethingElseNote(answer.somethingElse)
    return note ? { kind: 'describe', note, question } : undefined
  }
  if (!purposes.includes(answer.choice ?? '')) return undefined
  if (answer.choice === 'allowance') return { kind: 'resolve', reference: READY.cellAllowance, raises: [] }
  if (answer.followUps?.treatment === ASK_CUSTOMER) return { kind: 'defer' }
  if (!treatments.includes(answer.followUps?.treatment ?? '')) return undefined
  const reference = answer.followUps?.treatment === 'qualifying' ? READY.cellReimbursement : READY.cellReimbursementTaxable
  if (answer.choice === 'reimbursement') return { kind: 'resolve', reference, raises: [] }
  if (answer.followUps?.split === ASK_CUSTOMER) return { kind: 'defer' }
  if (answer.followUps?.split !== 'confirm') return undefined
  return { kind: 'resolve', reference: READY.cellAllowance, raises: [], outputs: [
    { code: 'CELL-ALLOW', reference: READY.cellAllowance }, { code: 'CELL-REIMB', reference },
  ] }
}

/**
 * One changed upstream choice always drops downstream confirmation. Something else opens an empty description (the
 * session's describe actions fill it in); choosing it again keeps what's typed, and any other choice clears it.
 */
export function updateCellAnswer(answer: ItemAnswer, stage: CellStage, choice: string): ItemAnswer | undefined {
  if (!answer.cellLegacy) {
    if (choice === ASK_CUSTOMER) return reduceCell(answer, { kind: 'defer', checked: true })
    return reduceCell(answer, { kind: 'answer', id: stage === 'purpose' ? 'method' : stage.replace(/^v2-/, ''), value: choice })
  }
  if (stage === 'purpose') {
    if (choice === DESCRIBE_CHOICE) return answer.choice === DESCRIBE_CHOICE ? answer : { choice, description: '' }
    return [...purposes, ASK_CUSTOMER].includes(choice) ? { choice } : undefined
  }
  const question = cellFollowUpQuestions(answer).find(candidate => candidate.id === stage)
  if (!question || (choice !== ASK_CUSTOMER && !question.options.some(option => option.id === choice))) return undefined
  return { choice: answer.choice, followUps: stage === 'treatment'
    ? { treatment: choice } : { treatment: answer.followUps!.treatment, split: choice } }
}

export function cellCustomerQuestion(stage: CellStage, answer: ItemAnswer = {}): string {
  if (!answer.cellLegacy) {
    const q = cellOutstanding(answer)
    if (!q) return ''
    return [q.question, q.context, ...(q.options ?? []).map(o => [o.label, o.detail, o.example].filter(Boolean).join(' '))].join('\n\n')
  }
  if (stage === 'purpose') return findItem(CELL_ID).customerQuestion
  return withSomethingElseEnding(cellFollowUpCustomerQuestion(stage as 'treatment' | 'split', answer))
}

function cellFollowUpCustomerQuestion(stage: 'treatment' | 'split', answer: ItemAnswer): string {
  const purpose = answer.choice === 'both'
    ? 'pays a set amount for phones and also pays people back for business phone use'
    : 'pays your people back for what they spend on business phone use'
  if (stage === 'treatment') return `You told us CELL ${purpose}. Should the phone payback be taxed? Paying people back for phone costs is only tax-free when it meets certain rules, and receipts alone aren’t enough. Your payroll or tax adviser can tell you if yours qualifies.`
  const taxFree = answer.followUps?.treatment === 'qualifying'
  return `You told us CELL ${purpose}, and that the payback ${taxFree ? 'is tax-free' : 'should be taxed as pay'}. CELL pays for two different things, so we need two codes: CELL-ALLOW for the allowance (taxed as pay) and CELL-REIMB for the payback (${taxFree ? 'tax-free' : 'taxed as pay'}). Can we split CELL into two codes? Your people get the same amounts as today.`
}
