import { act, StrictMode } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { MemoryRouter, useLocation } from 'react-router-dom'
import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import StepCategorySelection from './StepCategorySelection'
import { EarningSessionProvider, useEarningSession } from './SessionProvider'
import { createSession } from './session'
import { WORKING_COPY_KEY, SAVED_COPY_KEY } from './storage'

let host: HTMLDivElement
let root: Root
function Controls() {
  const { save, restart } = useEarningSession()
  const location = useLocation()
  return <><output data-testid="route">{location.pathname}</output><button onClick={save}>Save progress</button><button onClick={restart}>Restart</button></>
}
beforeEach(() => {
  Object.assign(globalThis, { IS_REACT_ACT_ENVIRONMENT: true })
  localStorage.clear()
  sessionStorage.clear()
  sessionStorage.setItem(WORKING_COPY_KEY, JSON.stringify({ ...createSession(0), step: 'categorySelection' }))
  host = document.createElement('div')
  document.body.append(host)
  root = createRoot(host)
  act(() => root.render(<StrictMode><MemoryRouter><EarningSessionProvider><StepCategorySelection /><Controls /></EarningSessionProvider></MemoryRouter></StrictMode>))
})
afterEach(() => {
  act(() => root.unmount())
  host.remove()
  sessionStorage.clear()
  localStorage.clear()
})
const buttons = () => [...document.querySelectorAll<HTMLButtonElement>('button')]
const button = (label: string) => buttons().find(el => el.textContent === label)!
const trigger = (category: string) => document.querySelector<HTMLButtonElement>(`[aria-label="Assign to others: ${category}"]`)!
const click = (el: HTMLElement) => act(() => el.click())
const state = () => JSON.parse(sessionStorage.getItem(WORKING_COPY_KEY)!)
const route = () => document.querySelector('[data-testid="route"]')?.textContent
function pick(value: string) {
  act(() => {
    const select = document.querySelector('select')!
    select.value = value
    select.dispatchEvent(new Event('change', { bubbles: true }))
  })
}
function key(el: Element, key: string, shiftKey = false) {
  act(() => el.dispatchEvent(new KeyboardEvent('keydown', { key, shiftKey, bubbles: true, cancelable: true })))
}

describe('category assignment dialogs', () => {
  it.each(['Earnings', 'Deductions', 'Taxes'])('confirms only %s without selecting or advancing', category => {
    const origin = trigger(category)
    expect(origin.closest('[role="radio"]')).toBeNull()
    click(origin)
    expect(document.querySelector('[role="dialog"] h2')?.textContent).toBe(`Assign ${category.toLowerCase()}`)
    expect(document.querySelector('label[for="ec-category-person"]')?.textContent).toBe('Person (sample list)')
    expect(document.querySelector('select')?.value).toBe('')
    expect(button('Confirm assignment').disabled).toBe(true)
    expect(document.body.textContent).toContain('no invitation or notification is sent')
    expect(document.body.textContent).toContain('Choose a person to confirm the assignment.')
    pick('sample-alex')
    click(button('Confirm assignment'))
    expect(document.querySelector('[role="dialog"]')).toBeNull()
    expect(document.activeElement).toBe(origin)
    expect(state().categoryAssignments).toEqual({ [category.toLowerCase()]: 'sample-alex' })
    expect(state().selectedCategory).toBeUndefined()
    expect(state().step).toBe('categorySelection')
    expect(route()).toBe('/')
    expect(buttons().some(el => el.textContent === 'Next')).toBe(false)
    for (const label of ['Set up earnings', 'View deductions', 'View taxes']) expect(button(label).disabled).toBe(false)
    expect(host.querySelectorAll('.ec-cat__assignee')).toHaveLength(1)
  })

  it('keeps assignments independent, replaces only on confirmation, and discards every dismissal', () => {
    for (const category of ['Earnings', 'Deductions', 'Taxes']) {
      click(trigger(category)); pick('sample-alex'); click(button('Confirm assignment'))
    }
    for (const dismiss of ['Leave unchanged', 'escape', 'close', 'backdrop']) {
      click(trigger('Earnings'))
      expect(document.querySelector('select')?.value).toBe('sample-alex')
      pick('sample-jordan')
      if (dismiss === 'escape') key(document.querySelector('select')!, 'Escape')
      else if (dismiss === 'close') click(document.querySelector('[aria-label="Close dialog"]')!)
      else if (dismiss === 'backdrop') click(document.querySelector('.dlg-backdrop')!)
      else click(button(dismiss))
      expect(state().categoryAssignments.earnings).toBe('sample-alex')
      expect(state().selectedCategory).toBeUndefined()
      expect(route()).toBe('/')
      expect(document.activeElement).toBe(trigger('Earnings'))
    }
    click(trigger('Earnings')); pick('sample-jordan'); click(button('Confirm assignment'))
    expect(state().categoryAssignments).toEqual({ earnings: 'sample-jordan', deductions: 'sample-alex', taxes: 'sample-alex' })
    expect(localStorage.getItem(SAVED_COPY_KEY)).toBeNull()
    click(button('Save progress'))
    expect(JSON.parse(localStorage.getItem(SAVED_COPY_KEY)!).categoryAssignments).toEqual(state().categoryAssignments)
    click(button('Restart'))
    expect(state().categoryAssignments ?? {}).toEqual({})
    expect(localStorage.getItem(SAVED_COPY_KEY)).toBeNull()
  })

  it('keeps existing files, answers and earnings progress untouched while assigning and dismissing', () => {
    act(() => root.unmount())
    const progress = {
      ...createSession(100),
      step: 'categorySelection' as const,
      selectedCategory: 'earnings' as const,
      lastEarningStep: 'results' as const,
      files: [{ id: 'register-1', name: 'regular-payroll.csv', sizeBytes: 1024, docType: 'Pay register' }],
      answers: { MISC7: { description: 'A retained answer' } },
      // Include the current scenario so assignment changes cannot trigger its save migration.
      rounds: [{ number: 1, itemIds: ['MISC7', 'SPPAY', 'OTMFG', 'OTSVC', 'MED ER'], submitted: false }],
      reviewCursor: 0,
      reviewLayout: 'business-topics' as const,
    }
    sessionStorage.setItem(WORKING_COPY_KEY, JSON.stringify(progress))
    root = createRoot(host)
    act(() => root.render(<StrictMode><MemoryRouter><EarningSessionProvider><StepCategorySelection /><Controls /></EarningSessionProvider></MemoryRouter></StrictMode>))
    const retained = {
      step: 'categorySelection',
      selectedCategory: 'earnings',
      lastEarningStep: 'results',
      files: progress.files,
      answers: progress.answers,
      rounds: progress.rounds,
      reviewCursor: progress.reviewCursor,
      reviewLayout: progress.reviewLayout,
    }
    click(trigger('Deductions'))
    pick('sample-alex')
    click(button('Confirm assignment'))
    expect(state()).toMatchObject({ ...retained, categoryAssignments: { deductions: 'sample-alex' } })
    click(trigger('Taxes'))
    pick('sample-taylor')
    click(button('Leave unchanged'))
    expect(state()).toMatchObject({ ...retained, categoryAssignments: { deductions: 'sample-alex' } })
    expect(state().categoryAssignments.taxes).toBeUndefined()
    expect(route()).toBe('/')
    click(button('Save progress'))
    expect(JSON.parse(localStorage.getItem(SAVED_COPY_KEY)!)).toMatchObject(retained)
  })

  it('keeps native category and assignment buttons in DOM tab order and traps assignment focus', () => {
    const categories = [...host.querySelectorAll('.ec-cat__category[data-category]')]
    expect(categories).toHaveLength(3)
    expect(host.querySelector('[role="radio"], [role="radiogroup"], [aria-checked]')).toBeNull()
    expect(categories.map(category => [...category.querySelectorAll('button')].map(el => [el.textContent?.trim(), el.tabIndex]))).toEqual([
      [['Set up earnings', 0], ['Assign to others', 0]],
      [['View deductions', 0], ['Assign to others', 0]],
      [['View taxes', 0], ['Assign to others', 0]],
    ])
    expect(categories.every(category => {
      const card = category.querySelector('.card')!
      return !card.hasAttribute('tabindex')
        && !card.querySelector('.card__header button, .card__body button, .card__header [tabindex], .card__body [tabindex]')
    })).toBe(true)
    click(trigger('Taxes'))
    const close = document.querySelector<HTMLElement>('[aria-label="Close dialog"]')!
    expect(document.activeElement).toBe(close)
    key(close, 'Tab', true)
    expect(document.activeElement).toBe(button('Leave unchanged'))
    key(button('Leave unchanged'), 'Tab')
    expect(document.activeElement).toBe(close)
    pick('sample-taylor')
    expect(document.activeElement).toBe(close)
    key(close, 'Tab', true)
    expect(document.activeElement).toBe(button('Confirm assignment'))
    key(button('Confirm assignment'), 'Tab')
    expect(document.activeElement).toBe(close)
    key(close, 'Escape')
    expect(document.activeElement).toBe(trigger('Taxes'))
    expect(state().selectedCategory).toBeUndefined()
    expect(route()).toBe('/')
    expect(categories.map(category => [...category.querySelectorAll('button')].map(el => el.tabIndex))).toEqual([[0, 0], [0, 0], [0, 0]])
  })
})