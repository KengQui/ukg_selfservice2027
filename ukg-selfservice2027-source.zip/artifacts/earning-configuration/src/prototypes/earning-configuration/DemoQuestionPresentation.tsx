import { createContext, useContext, useState, type ReactNode } from 'react'
import Button from '@ready/dls/components/Button/Button'
import { categorizedRound, optionalDemoQuestion } from './optionalDemoQuestions'
import { reviewTopicFor } from './reviewTopics'
import { findItem } from './sampleRegister'
import { addedCodesPageIndex, currentRound, reviewPages, reviewPosition } from './session'
import { useEarningSession } from './sessionContext'

interface Presentation {
  displayed: (id: string) => boolean
  reveal: (id: string) => void
  control: ReactNode
  visiblePages: number[]
  currentPage: number
}
const Context = createContext<Presentation | undefined>(undefined)

/** Shared by the code panel and cards. Never stored in the payroll session. */
export function DemoQuestionPresentation({ children }: { children: ReactNode }) {
  const parent = useContext(Context)
  const { session } = useEarningSession()
  const key = JSON.stringify([session.registerOwnerId, session.registerSource,
    session.files.map(file => [file.id, file.sha256]), currentRound(session)?.number])
  return parent ? children : <PresentationOwner key={key}>{children}</PresentationOwner>
}

function PresentationOwner({ children }: { children: ReactNode }) {
  const { session } = useEarningSession()
  const [revealed, setRevealed] = useState<ReadonlySet<string>>(() => new Set())
  const round = currentRound(session)
  const pages = reviewPages(session)
  const hideable = (id: string) => categorizedRound(round) && optionalDemoQuestion(session, id)
  const topic = (id: string) => reviewTopicFor(findItem(id)).id
  const displayed = (id: string) => !hideable(id) || revealed.has(topic(id))
  const visiblePages = pages.flatMap((page, index) => page.some(displayed) ? [index] : [])
  const added = addedCodesPageIndex(session)
  if (added >= 0) visiblePages.push(added)
  const saved = reviewPosition(session).index
  const currentPage = visiblePages.includes(saved) ? saved : visiblePages.find(index => index > saved) ?? visiblePages.at(-1) ?? 0
  const page = pages[currentPage] ?? []
  const optional = pages.flat().find(id => hideable(id) && topic(id) === (page[0] ? topic(page[0]) : undefined))
  const shown = !!optional && revealed.has(topic(optional))
  const label = shown ? 'Hide hidden questions' : 'Show hidden questions'
  const reveal = (id: string) => {
    if (hideable(id)) setRevealed(previous => new Set([...previous, topic(id)]))
  }
  const control = optional ? <Button variant="tertiary" size="xSmall" iconLeftName="eye"
    className="ec-hidden-questions-toggle" aria-label={label} title={label} aria-pressed={shown}
    onClick={event => {
      // Keep focus on the control even in browsers that don't focus clicked buttons.
      event.currentTarget.focus({ preventScroll: true })
      setRevealed(previous => {
        const next = new Set(previous)
        if (shown) next.delete(topic(optional)); else next.add(topic(optional))
        return next
      })
    }} /> : null
  return <Context.Provider value={{
    displayed, reveal, control, visiblePages, currentPage,
  }}>{children}</Context.Provider>
}

export function useDemoQuestionPresentation() {
  const value = useContext(Context)
  if (!value) throw new Error('DemoQuestionPresentation is required')
  return value
}
