import { useContext } from 'react'
import TextArea from '@ready/dls/components/TextArea/TextArea'
import QuestionCard, { DiscussionLockedQuestions, QuestionSection } from './QuestionCard'
import { ASK_CUSTOMER } from './sampleRegister'
import { conditionalFollowUps, conditionalPurpose, conditionalReport, type ConditionalDefinition } from './conditionalQuestions'
import { GTL_QUESTIONS, gtlDiscovery } from './gtlQuestions'
import type { ItemAnswer, SessionAction } from './session'
import { medicalAnswerRecap } from './medicalAnswerRecap'
import SetupSummary from './SetupSummary'

/** Reuses the existing card, radio and sequence styles for any registered payroll code. */
export default function ConditionalQuestionCard({ definition, label, answer, dispatch, onClearAnswers }: {
  definition: ConditionalDefinition
  label: string
  answer: ItemAnswer
  dispatch: (action: SessionAction) => void
  onClearAnswers?: () => void
}) {
  const locked = useContext(DiscussionLockedQuestions)
  const purpose = conditionalPurpose(definition, answer.conditionalReview)
  const path = conditionalFollowUps(definition, answer.conditionalReview)
  const followUp = path.find(question => !answer.conditionalReview?.responses[question.id]) ?? path.at(-1)
  const response = followUp && answer.conditionalReview?.responses[followUp.id]
  const selectedOption = followUp?.options.find(option => option.id === response)
  const report = conditionalReport(definition, answer.conditionalReview)
  const deferred = answer.choice === ASK_CUSTOMER
  const gtl = definition.id === GTL_QUESTIONS.id ? gtlDiscovery(answer.conditionalReview, deferred, definition.gtlEvidence, definition.gtlHistorical) : undefined
  const recap = !deferred && medicalAnswerRecap(definition, answer.conditionalReview)
  const itemId = definition.itemId ?? definition.code
  const send = (event: Extract<SessionAction, { type: 'conditionalReview' }>['event']) =>
    dispatch({ type: 'conditionalReview', itemId, event })
  const comment = followUp && (followUp.comment || selectedOption?.comment)
  const details = followUp && comment ? <div className="ec-description">
    <TextArea label="Additional information (optional)" value={answer.conditionalReview?.comments[followUp.id] ?? ''}
      readOnly={deferred || Object.hasOwn(locked, followUp.question)}
      onChange={text => send({ type: 'comment', questionId: followUp.id, text })} />
    <p className="text-caption">You can leave this blank. Up to 500 characters. Your answers describe what the code should do, not verified setup.</p>
  </div> : undefined
  return <QuestionCard label={label} sourceItemId={itemId} question={definition.question}
    variant="misclassification" knownFact={<>
      {definition.introduction.split('\n\n').map(text => <p key={text} className="ec-qcard__prompt">{text}</p>)}
      {definition.example && <div className="ec-description"><strong>Example</strong><p>{definition.example}</p><p className="text-caption">{definition.exampleNote}</p></div>}
    </>}
    answered={deferred || !!report}
    onClearAnswers={onClearAnswers}
    deferredQuestion={followUp ? {
      question: followUp.question, control: 'choices',
      choices: followUp.options.map(option => option.label),
      options: followUp.options.map(option => ({ id: option.id, label: option.label })),
    } : undefined}
    options={definition.purposes.map(option => ({
      id: option.id, title: option.label, subHeading: option.detail,
    }))}
    selected={purpose?.id}
    onSelect={choice => dispatch({ type: 'choose', itemId, choice })}
    defer deferSelected={deferred ? ASK_CUSTOMER : undefined}
    onDeferSelect={choice => dispatch({ type: 'choose', itemId, choice })}
    afterOptions={!purpose && (answer.choice || answer.somethingElse) && !deferred
      ? <p className="ec-qcard__prompt">Your earlier answer is kept in your saved review. Choose a purpose above to answer the updated questions.</p> : undefined}
    followUpSequenceCount={path.length}
    followUpSequence={path.length ? <>
        {path.map((question, index) => <QuestionSection key={question.id} question={question.question}
          sequenceStep={{ number: index + 1, state: answer.conditionalReview?.responses[question.id] ? 'answered' : 'current', continues: index < path.length - 1 }}
          options={question.options.map(option => ({ id: option.id, title: option.label }))}
          selected={answer.conditionalReview?.responses[question.id]}
          disabled={deferred}
          onSelect={choice => send({ type: 'answer', questionId: question.id, choice })} />)}
        {details}
      </> : undefined}
    followUps={report || deferred || gtl && purpose ? <>
      {recap && <SetupSummary code={definition.code} summary={recap} />}
      {gtl?.status === 'Complete' && definition.presentation === 'customer'
        ? <><SetupSummary code={definition.code} summary={gtl.summary} /><p className="text-caption">{definition.recommendedAction}</p></>
        : !deferred && (report || gtl) && definition.presentation === 'customer' && <p role="status" className="ec-qcard__prompt">
        {gtl && <><strong>{gtl.status}</strong> · {gtl.summary} </>}{definition.recommendedAction}
      </p>}
      {report?.conflict && definition.presentation !== 'customer' && <p role="status" className="ec-qcard__prompt">
        These answers conflict. Check the purpose and treatment answers above, or select Review later to ask the customer. The setup team needs to review the discrepancy.
      </p>}
    </> : undefined} />
}
