import { act, StrictMode } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { readFileSync } from 'node:fs'
import DeferCheckbox from './DeferCheckbox'
import { ASK_CUSTOMER, CLEAR_CHOICE } from './sampleRegister'

let host: HTMLDivElement
let root: Root
const onChange = vi.fn()
beforeEach(() => {
  vi.useFakeTimers()
  onChange.mockClear()
  Object.assign(globalThis, { IS_REACT_ACT_ENVIRONMENT: true })
  host = document.body.appendChild(document.createElement('div'))
  root = createRoot(host)
})
afterEach(() => {
  act(() => root.unmount())
  host.remove()
  vi.useRealTimers()
})
const render = (checked: boolean, disabled = false) => act(() => root.render(
  <StrictMode><h3 id="q">Question</h3><DeferCheckbox checked={checked} disabled={disabled} labelledBy="q" onChange={onChange} /></StrictMode>,
))
const cup = () => host.querySelector<SVGSVGElement>('.ec-defer > svg.ec-defer-coffee')!
const steaming = () => cup().classList.contains('ec-defer-coffee--steaming')
const tick = (ms: number) => act(() => vi.advanceTimersByTime(ms))
const checkbox = () => host.querySelector<HTMLInputElement>('input[type="checkbox"]')!

describe('Review later coffee decoration', () => {
  it.each([false, true])('fills the bowl itself with dark green, not only its outline (checked=%s)', checked => {
    render(checked)
    const body = cup().querySelector('.ec-defer-coffee__body')!
    expect(body.getAttribute('fill')).toBe('#0a433f')
    expect(body.hasAttribute('mask')).toBe(false)
    expect(cup().querySelector('rect[mask]')?.getAttribute('fill')).toBe('#0a433f')
    expect(cup().querySelector('.ec-defer-coffee__teabag image')).not.toBeNull()
  })
  it('is decorative, nonfocusable and follows the unchanged labelled checkbox', () => {
    render(false)
    expect(cup().getAttribute('aria-hidden')).toBe('true')
    expect(cup().getAttribute('focusable')).toBe('false')
    expect(cup().hasAttribute('tabindex')).toBe(false)
    expect(cup().previousElementSibling?.matches('label.cbx')).toBe(true)
    expect(host.querySelector('.ec-defer')?.textContent?.trim()).toBe('Review later')
    expect(host.querySelector('.ec-defer')?.getAttribute('aria-labelledby')).toBe('q')
    expect(steaming()).toBe(false)
    expect(vi.getTimerCount()).toBe(0)
  })

  it('stops at eight seconds and does not restart on rerenders', () => {
    render(false)
    render(true)
    expect(steaming()).toBe(true)
    tick(4000)
    render(true)
    tick(3999)
    expect(steaming()).toBe(true)
    tick(1)
    expect(steaming()).toBe(false)
    render(true)
    expect(steaming()).toBe(false)
    expect(checkbox().checked).toBe(true)
    expect(vi.getTimerCount()).toBe(0)
  })

  it('does not replay restored checked selections, including remounts', () => {
    render(true)
    expect(steaming()).toBe(false)
    expect(vi.getTimerCount()).toBe(0)
    act(() => root.render(null))
    render(true)
    expect(steaming()).toBe(false)
    expect(vi.getTimerCount()).toBe(0)
  })

  it('cancels immediately on uncheck and gives a recheck its own eight seconds', () => {
    render(false)
    render(true)
    tick(3000)
    render(false)
    expect(steaming()).toBe(false)
    expect(vi.getTimerCount()).toBe(0)
    render(true)
    tick(5000) // The first check's original deadline must not stop the new one.
    expect(steaming()).toBe(true)
    tick(3000)
    expect(steaming()).toBe(false)
  })

  it('cleans up an active timer on unmount', () => {
    render(false)
    render(true)
    expect(vi.getTimerCount()).toBe(1)
    act(() => root.render(null))
    expect(vi.getTimerCount()).toBe(0)
  })

  it('keeps native focus and the original deferral actions', () => {
    render(false)
    checkbox().focus()
    act(() => checkbox().click())
    expect(onChange).toHaveBeenLastCalledWith(ASK_CUSTOMER)
    render(true)
    expect(document.activeElement).toBe(checkbox())
    act(() => checkbox().click())
    expect(onChange).toHaveBeenLastCalledWith(CLEAR_CHOICE)
  })

  it.each([false, true])('does not activate a disabled checkbox (checked=%s)', checked => {
    render(checked, true)
    act(() => checkbox().click())
    expect(onChange).not.toHaveBeenCalled()
    expect(checkbox().checked).toBe(checked)
    expect(steaming()).toBe(false)
  })

  it('adds four pixels of separation without changing the cup or wrapping rules', () => {
    const css = readFileSync('src/prototypes/earning-configuration/deferCoffee.css', 'utf8')
    const layout = readFileSync('src/prototypes/earning-configuration/deferCheckbox.css', 'utf8')
    expect(css).toContain('margin-left: 0;')
    expect(css).toContain('width: 40px;')
    expect(css).toContain('height: 34px;')
    expect(css).toContain('translate: 0 -7.5px;')
    expect(css).toContain('scale: 0.85 1;')
    expect(layout).toContain('flex-wrap: wrap;')
    expect(layout).toContain('gap: 0;')
    expect(layout).toContain('max-width: 100%;')
  })

  it('uses finite motion with a static checked cue for reduced motion', () => {
    const css = readFileSync('src/prototypes/earning-configuration/deferCoffee.css', 'utf8')
    expect(css).toContain('animation: ec-defer-coffee-steam 2s ease-out 4')
    expect(css).toMatch(/__steam\s*\{\s*opacity: 0/)
    expect(css).toMatch(/@media \(prefers-reduced-motion: reduce\)[\s\S]*--checked .ec-defer-coffee__steam\s*\{\s*animation: none;\s*transform: none;\s*opacity: .65;/)
    expect(css).toContain('pointer-events: none')
    expect(css).toContain('overflow: hidden')
  })
})
