import { act } from 'react'
import { createRoot } from 'react-dom/client'
import { renderToStaticMarkup } from 'react-dom/server'
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest'
import { ASK_CUSTOMER, EARNING_CODES, LEAVE_ITEMS, PAY_CODES, READY, REVIEW_INITIAL_ITEMS, findItem } from './sampleRegister'
import { createSession, decisionFor, parseSession, reduceSession, reviewPages, reviewProcessFor, questionCardVariant, canSubmitRound, type EarningSession, type SessionAction } from './session'
import { ORIGINAL_REVIEW_TOPICS, PREVIOUS_REVIEW_TOPICS, REVIEW_TOPICS, SEPARATE_TIPS_REVIEW_TOPICS, reviewTopicFor } from './reviewTopics'
import { finalConfiguration, startingMatchedCodes } from './configuration'
import { readinessSummary } from './readinessSummary'
import { customerQuestionList, summaryCsv } from './summary'
import { sortEarnings } from './overtime'
import { demoFill } from './demoAnswers'
import { createOvertimeDemoSession } from './overtimeDemo'
import { SAMPLE_REGISTER_FILES } from './sampleDocument'
import { SOMETHING_ELSE_MAIN } from './somethingElse'
import { reviewSteps, reviewStatusGroups } from './reviewStatus'
import { SessionContext } from './sessionContext'
import StepQuestions, { ItemQuestion } from './StepQuestions'
import { bryteFacts } from './bryteFacts'
import { EARNING_DEMO_SETTINGS } from './demoSettings'
import { loadSession, saveSession, writeWorkingCopy } from './storage'
import CustomerReplyDialog from './CustomerReplyDialog'

const run = (s: EarningSession, ...actions: SessionAction[]) => actions.reduce((state, action) => reduceSession(state, action, 1), s)
const start = () => run(createSession(0), { type: 'startReview' })
// Existing/disputed purpose work must stay actionable, unlike fresh known matches.
const withLeave = () => run({ ...createSession(0), answers: Object.fromEntries(LEAVE_ITEMS.map(item => [item.id, {}])) }, { type: 'startReview' })
const choose = (itemId: string, choice: string): SessionAction => ({ type: 'choose', itemId, choice })
const allDeferred = () => run(withLeave(), ...REVIEW_INITIAL_ITEMS.map(item => choose(item.id, ASK_CUSTOMER)))
const apply = (s: EarningSession) => run(s, { type: 'submitRound' }, { type: 'finishReevaluation' })
beforeAll(() => vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT', true))
afterAll(() => vi.unstubAllGlobals())

describe('business topics and bounded leave purposes', () => {
  it('uses exactly seven unique sections independently of processes and styles', () => {
    const session = withLeave()
    const titles = ['How employees are paid', 'Time off & paid leave', 'Allowances & reimbursements', 'Imputed Income', 'Benefits & employer contributions', 'Corrections & reversals', "Other codes we couldn't identify"]
    expect(REVIEW_TOPICS.map(t => t.title)).toEqual(titles)
    expect(reviewPages(session)).toEqual(REVIEW_TOPICS.map(t => t.itemIds))
    expect(new Set(reviewPages(session).flat()).size).toBe(REVIEW_INITIAL_ITEMS.length)
    expect(new Set(PAY_CODES.map(c => c.code)).size).toBe(PAY_CODES.length)
    expect(reviewSteps(session).map(s => s.label)).toEqual(titles)
    expect(reviewStatusGroups(session).map(s => s.title)).toEqual(titles)
    expect(reviewProcessFor(findItem('SPPAY'))).toBe('unableToIdentify')
    expect(reviewTopicFor(findItem('SPPAY')).id).toBe('other')
    expect(reviewTopicFor({ ...findItem('SPPAY'), id: 'future-special-pay' }).id).toBe('other')
    expect(reviewTopicFor(findItem('TIPS')).id).toBe('pay')
    expect(reviewTopicFor(findItem('TIPS RPT')).id).toBe('pay')
    expect(reviewPages(session)[0]).toContain('TIPS')
    expect(reviewTopicFor({ ...findItem('MISC7'), id: 'future-code', code: 'UNKNOWN' }).id).toBe('other')
    for (const id of ['MED']) {
      expect(reviewProcessFor(findItem(id))).toBe('planContributions')
      expect(questionCardVariant(id)).toBe('misclassification')
    }
    for (const item of LEAVE_ITEMS) {
      expect(reviewProcessFor(item)).toBe('needMoreInformation')
      expect(questionCardVariant(item.id)).toBe('misclassification')
    }
    expect(questionCardVariant('SPPAY')).toBe('standard')
    expect(questionCardVariant('TIPS RPT')).toBe('standard')
  })

  it('groups Special Pay with unidentified codes without changing its process or duplicating it', () => {
    const session = start()
    const pages = reviewPages(session)
    expect(pages[0]).not.toContain('SPPAY')
    expect(pages.at(-1)).toEqual(['SPPAY', 'ADJ2', 'MISC7'])
    expect(pages.flat().filter(id => id === 'SPPAY')).toHaveLength(1)
    expect(reviewProcessFor(findItem('SPPAY'))).toBe('unableToIdentify')
    expect(reviewStatusGroups(session).find(group => group.rows.some(row => row.id === 'SPPAY'))?.title)
      .toBe("Other codes we couldn't identify")
    for (const topics of [SEPARATE_TIPS_REVIEW_TOPICS, ORIGINAL_REVIEW_TOPICS]) {
      expect(topics.flatMap(topic => topic.itemIds).filter(id => id === 'SPPAY')).toHaveLength(1)
      expect(reviewTopicFor(findItem('SPPAY'), topics).id).toBe('pay')
    }
  })

  it('renders Special Pay only on the unidentified-code page with its existing opening question', () => {
    const session = start()
    const renderPage = (index: number) => new DOMParser().parseFromString(renderToStaticMarkup(
      <SessionContext.Provider value={{ session: { ...session, reviewCursor: index }, dispatch: () => {}, save: () => true, restart: () => true }}>
        <StepQuestions />
      </SessionContext.Provider>,
    ), 'text/html')
    expect(renderPage(0).querySelector('[data-review-item="SPPAY"]')).toBeNull()
    const page = renderPage(reviewPages(session).length - 1)
    expect(page.querySelector('h1.ec-h1')?.textContent).toBe("Other codes we couldn't identify")
    expect(page.querySelector('[data-review-item="SPPAY"]')?.textContent).toContain('What does Special Pay pay for?')
  })

  it('preserves saved Special Pay input and round membership after regrouping', () => {
    const session = run(start(), { type: 'describe', itemId: 'SPPAY', description: 'We pay a monthly language stipend.' })
    const restored = parseSession(JSON.stringify({ ...session, reviewCursor: reviewPages(session).length - 1 }))!
    expect(restored).toBeDefined()
    expect(restored.answers).toEqual(session.answers)
    expect(restored.rounds).toEqual(session.rounds)
    expect(reviewPages(restored).at(-1)).toContain('SPPAY')
    expect(bryteFacts(restored).facts.category).toBe("Other codes we couldn't identify")
    expect(parseSession(JSON.stringify(restored))).toEqual(restored)
  })

  it.each(LEAVE_ITEMS)('$code is unconfirmed until answered and keeps each outcome through outputs and replies', item => {
    expect(decisionFor(item, {})).toBeUndefined()
    expect(finalConfiguration(withLeave()).find(row => row.code === item.code)?.reference).toBeUndefined()
    expect(startingMatchedCodes(withLeave()).some(row => row.code === item.code)).toBe(false)
    let confirmed = apply(run(allDeferred(), choose(item.id, 'confirm-purpose')))
    expect(confirmed.resolutions[item.id]).toMatchObject({ status: 'resolved', reference: item.options[0].resolution })
    expect(finalConfiguration(confirmed).find(row => row.code === item.code)).toMatchObject({ status: 'ready', reference: item.options[0].resolution })
    expect(summaryCsv(confirmed, () => 'time')).toContain(item.options[0].resolution!.name)
    let described = run(allDeferred(),
      { type: 'chooseSomethingElse', itemId: item.id, question: SOMETHING_ELSE_MAIN })
    described = run(described, { type: 'describeSomethingElse', itemId: item.id, description: 'We use this for another paid absence.' },
      { type: 'submitSomethingElse', itemId: item.id })
    expect(decisionFor(item, described.answers[item.id])?.kind).toBe('describe')
    described = apply(described)
    expect(finalConfiguration(described).find(row => row.code === item.code)?.status).toBe('review')
    expect(finalConfiguration(described).find(row => row.code === item.code)?.reference).toBeUndefined()
    expect(summaryCsv(described, () => 'time')).toContain('We use this for another paid absence.')
    const sorted = sortEarnings(finalConfiguration(described))
    expect([...sorted.include, ...sorted.exclude].some(row => row.code === item.code)).toBe(false)
    const deferred = apply(allDeferred())
    const question = customerQuestionList(deferred).find(q => q.id === `classification:${item.id}`)!
    expect(question).toMatchObject({ topic: 'leave', codes: [item.code], status: 'open' })
    expect(question.question).toContain('something else')
    const sent = run({ ...deferred, step: 'summary' }, { type: 'sendQuestions', to: 'team@example.com' })
    const replied = run(sent, { type: 'saveCustomerReply', questionId: question.id, answer: { choice: 'confirm-purpose' } })
    expect(replied.resolutions[item.id]).toMatchObject({ status: 'resolved', reference: item.options[0].resolution })
    expect(parseSession(JSON.stringify({ ...replied, step: 'review' }))?.customerReplies).toEqual(replied.customerReplies)
  })

  it('derives fresh counts and keeps benefit plans out of earnings', () => {
    expect(readinessSummary(start())).toMatchObject({ total: EARNING_CODES.length, matched: 7, needInput: 12, plans: 0 })
    expect(EARNING_CODES.some(code => ['MED', 'DEN'].includes(code.code))).toBe(false)
  })

  it.each(LEAVE_ITEMS)('lets the team record $code’s fixed purpose in the customer reply dialog', item => {
    const session = { ...apply(allDeferred()), step: 'summary' as const }
    const question = customerQuestionList(session).find(q => q.id === `classification:${item.id}`)!
    const dispatch = vi.fn()
    const onClose = vi.fn()
    const host = document.createElement('div'); document.body.append(host)
    const root = createRoot(host)
    const fetchSpy = vi.spyOn(globalThis, 'fetch')
    try {
      act(() => root.render(<SessionContext.Provider value={{ session, dispatch, save: () => true, restart: () => true }}>
        <CustomerReplyDialog question={question} onClose={onClose} />
      </SessionContext.Provider>))
      const dialog = document.querySelector<HTMLElement>('[role="dialog"]')!
      expect(dialog.textContent).toContain(item.question)
      const save = () => [...dialog.querySelectorAll('button')].find(button => button.textContent === 'Save answer')!
      expect(save().disabled).toBe(true)
      act(() => dialog.querySelector<HTMLElement>('[role="radio"]')!.click())
      expect(save().disabled).toBe(false)
      act(() => save().click())
      expect(dispatch).toHaveBeenCalledWith(expect.objectContaining({
        type: 'saveCustomerReply', questionId: question.id, answer: expect.objectContaining({ choice: 'confirm-purpose' }),
      }))
      expect(onClose).toHaveBeenCalledOnce()
      expect(fetchSpy).not.toHaveBeenCalled()
    } finally { act(() => root.unmount()); host.remove(); fetchSpy.mockRestore() }
  })

  it('migrates six-page cursors by identity, returning to earlier unfinished work', () => {
    const oldPages = [['SPPAY', 'ADJ2', 'MISC7'], ['BONREV'], ['OTPREM', 'OTMFG', 'OTSVC'], ['CELL-purpose', 'MILEAGE'], ['TIPS', 'GTL-review', 'IMP INC'], ['MED', 'DEN']]
    for (const [cursor, ids] of oldPages.entries()) {
      const old = allDeferred()
      // A real earlier six-page review still contained the now-retired MED question.
      old.rounds[0].itemIds.push('MED')
      old.answers.MED = { choice: ASK_CUSTOMER }
      old.rounds[0].itemIds = old.rounds[0].itemIds.filter(id => !id.endsWith('-purpose') || id === 'CELL-purpose')
      for (const item of LEAVE_ITEMS) delete old.answers[item.id]
      old.reviewLayout = 'categories'
      old.reviewCursor = cursor
      const restored = parseSession(JSON.stringify(old))!
      const target = reviewPages(restored)[restored.reviewCursor!]
      expect(target).toContain(ids[0] === 'MED' ? 'MED ER' : ids[0])
      expect(restored.answers).toEqual(old.answers)
      expect(restored.reviewLayout).toBe('business-topics')
    }
    const old = { ...start(), reviewLayout: 'categories' as const, reviewCursor: 5 }
    expect(parseSession(JSON.stringify(old))?.reviewCursor).toBe(0)
  })

  it('preserves an applied legacy review, sent wording and both storage paths without invented answers', () => {
    const old = createOvertimeDemoSession(10)
    for (const item of LEAVE_ITEMS) {
      delete old.answers[item.id]
      delete old.resolutions[item.id]
      for (const round of old.rounds) {
        round.itemIds = round.itemIds.filter(id => id !== item.id)
        if (round.results) round.results.resolved = round.results.resolved.filter(id => id !== item.id)
      }
    }
    old.reviewLayout = 'categories'
    old.sent = { at: 1, to: 'Sample team', questionIds: [], questions: [] }
    const restored = parseSession(JSON.stringify(old))!
    expect(restored.step).toBe('overtime')
    expect(restored.answers).toEqual(old.answers)
    expect(restored.sent).toEqual(old.sent)
    for (const item of LEAVE_ITEMS) {
      expect(restored.rounds.some(round => round.itemIds.includes(item.id))).toBe(false)
      expect(finalConfiguration(restored).find(row => row.code === item.code)?.reference).toEqual(item.options[0].resolution)
    }
    const stores = { working: sessionStorage, saved: localStorage }
    sessionStorage.clear(); localStorage.clear()
    writeWorkingCopy(stores, restored)
    expect(loadSession(stores)).toEqual(restored)
    saveSession(stores, restored)
    sessionStorage.clear()
    expect(loadSession(stores)).toEqual(restored)
    sessionStorage.clear(); localStorage.clear()
  })

  it('fills leave without navigation, submitting text or calling AI; demo still starts after optimization', () => {
    const session = { ...withLeave(), reviewCursor: 1 }
    const actions = demoFill(session, REVIEW_TOPICS[1].itemIds)
    expect(actions).toEqual(LEAVE_ITEMS.map(item => choose(item.id, 'confirm-purpose')))
    const filled = run(session, ...actions)
    expect(filled.step).toBe('questions')
    expect(filled.reviewCursor).toBe(1)
    expect(bryteFacts(filled).facts.category).toBe('Time off & paid leave')
    expect(createOvertimeDemoSession().step).toBe('overtime')
    expect(canSubmitRound(filled)).toBe(false)
    EARNING_DEMO_SETTINGS.ungateForwardButtons = true
    try {
      const last = reviewPages(start()).length - 1
      expect(run(start(), { type: 'moveReview', index: last }).reviewCursor).toBe(last)
    }
    finally { EARNING_DEMO_SETTINGS.ungateForwardButtons = false }
  })

  it('renders the same fixed leave options without preselection and dispatches a keyboard choice with no request', () => {
    const item = LEAVE_ITEMS[0]
    const dispatch = vi.fn()
    const session = start()
    const element = <SessionContext.Provider value={{ session, dispatch, save: () => true, restart: () => true }}>
      <ItemQuestion item={item} label="VAC" answer={{}} />
    </SessionContext.Provider>
    expect(renderToStaticMarkup(element)).toContain('Something else')
    const host = document.createElement('div'); document.body.append(host)
    const root = createRoot(host)
    const fetchSpy = vi.spyOn(globalThis, 'fetch')
    try {
      act(() => root.render(element))
      const radio = host.querySelector<HTMLElement>('[role="radio"]')!
      expect(radio.getAttribute('aria-checked')).toBe('false')
      act(() => radio.dispatchEvent(new KeyboardEvent('keydown', { key: ' ', bubbles: true })))
      expect(dispatch).toHaveBeenCalledWith(choose(item.id, 'confirm-purpose'))
      expect(fetchSpy).not.toHaveBeenCalled()
    } finally { act(() => root.unmount()); host.remove(); fetchSpy.mockRestore() }
  })

  it('walks the requested order with matching headings, gates, help and saved answers', () => {
    let session = withLeave()
    const files = SAMPLE_REGISTER_FILES
    session = run(session, { type: 'setFiles', files })
    for (const [index, topic] of REVIEW_TOPICS.entries()) {
      expect(session.reviewCursor).toBe(index)
      expect(reviewSteps(session).find(step => step.state === 'current')?.label).toBe(topic.title)
      expect(bryteFacts(session).facts.category).toBe(topic.title)
      const html = renderToStaticMarkup(<SessionContext.Provider value={{ session, dispatch: () => {}, save: () => true, restart: () => true }}>
        <StepQuestions />
      </SessionContext.Provider>)
      const doc = new DOMParser().parseFromString(html, 'text/html')
      expect(doc.querySelector('h1.ec-h1')?.textContent).toBe(topic.title)
      const guidance = topic.id === 'other' ? 'Not sure? Select Defer and come back later.'
        : topic.id === 'benefits' ? "If you're unsure, select Defer and return to this question later."
        : topic.id === 'expenses' ? topic.description
        : 'Not sure about something? Select Defer to come back to it later.'
      const intro = doc.querySelector('.ec-intro')!
      expect(intro.lastElementChild?.tagName).toBe('P')
      expect(intro.lastElementChild?.textContent).toBe(guidance)
      expect(intro.textContent?.split(guidance)).toHaveLength(2)
      if (index < REVIEW_TOPICS.length - 1) expect(run(session, { type: 'moveReview', index: index + 1 })).toBe(session)
      session = run(session, ...topic.itemIds.map(id => choose(id, ASK_CUSTOMER)))
      const saved = parseSession(JSON.stringify(session))!
      expect(saved.reviewCursor).toBe(index)
      expect(saved.answers).toEqual(session.answers)
      expect(saved.files).toEqual(files)
      const restoredDoc = new DOMParser().parseFromString(renderToStaticMarkup(
        <SessionContext.Provider value={{ session: saved, dispatch: () => {}, save: () => true, restart: () => true }}>
          <StepQuestions />
        </SessionContext.Provider>,
      ), 'text/html')
      expect(restoredDoc.querySelector('.ec-intro')?.outerHTML).toBe(intro.outerHTML)
      expect(parseSession(JSON.stringify(saved))).toEqual(saved)
      session = run(saved, { type: 'moveReview', index: index + 1 })
    }
    expect(canSubmitRound(session)).toBe(true)
    expect(reviewSteps(start()).map(step => step.label)).toEqual(REVIEW_TOPICS.filter(topic => topic.id !== 'leave').map(topic => topic.title))
  })

  it.each([false, true])('migrates correction-first saves by topic identity with leave=%s', includeLeave => {
    const answered = run(includeLeave ? withLeave() : start(),
      ...reviewPages(includeLeave ? withLeave() : start()).flat().map(id => choose(id, ASK_CUSTOMER)))
    const topics = ORIGINAL_REVIEW_TOPICS.filter(topic => includeLeave || topic.id !== 'leave')
    for (const [index, topic] of topics.entries()) {
      const legacy = { ...answered, reviewTopicOrder: undefined, reviewCursor: index }
      const restored = parseSession(JSON.stringify(legacy))!
      expect(reviewTopicFor(findItem(reviewPages(restored)[restored.reviewCursor!][0])).id).toBe(topic.id === 'tips' ? 'pay' : topic.id)
      expect(restored.answers).toEqual(answered.answers)
      expect(restored.rounds).toEqual(answered.rounds)
      expect(restored.reviewTopicOrder).toBe(4)
      expect(parseSession(JSON.stringify(restored))).toEqual(restored)
    }
  })

  it('returns an old correction-first save to earlier unfinished pay without altering its answers', () => {
    const legacy = { ...start(), reviewTopicOrder: undefined, reviewCursor: 0, answers: { BONREV: { choice: ASK_CUSTOMER } } }
    const restored = parseSession(JSON.stringify(legacy))!
    expect(restored.reviewCursor).toBe(0)
    expect(bryteFacts(restored).facts.category).toBe('How employees are paid')
    expect(restored.answers).toEqual(legacy.answers)
  })

  it.each([false, true])('migrates every separate-Tips page to its new topic with leave=%s', includeLeave => {
    const base = includeLeave ? withLeave() : start()
    const answered = run(base, ...reviewPages(base).flat().map(id => choose(id, ASK_CUSTOMER)))
    const topics = SEPARATE_TIPS_REVIEW_TOPICS.filter(topic => includeLeave || topic.id !== 'leave')
    for (const [index, topic] of topics.entries()) {
      const legacy = { ...answered, reviewTopicOrder: 2 as const, reviewCursor: index }
      const restored = parseSession(JSON.stringify(legacy))!
      const ids = reviewPages(restored)[restored.reviewCursor!]
      expect(reviewTopicFor(findItem(ids[0])).id).toBe(topic.id === 'tips' ? 'pay' : topic.id)
      expect(restored.answers).toEqual(answered.answers)
      expect(restored.rounds).toEqual(answered.rounds)
      expect(restored.reviewTopicOrder).toBe(4)
      expect(parseSession(JSON.stringify(restored))).toEqual(restored)
    }
  })

  it('preserves the topic and answers when restoring the previous benefits order', () => {
    const base = start()
    const answered = run(base, ...reviewPages(base).flat().map(id => choose(id, ASK_CUSTOMER)))
    const topics = PREVIOUS_REVIEW_TOPICS.filter(topic => topic.id !== 'leave')
    for (const [index, topic] of topics.entries()) {
      const restored = parseSession(JSON.stringify({ ...answered, reviewTopicOrder: 3, reviewCursor: index }))!
      expect(reviewTopicFor(findItem(reviewPages(restored)[restored.reviewCursor!][0])).id).toBe(topic.id)
      expect(restored.answers).toEqual(answered.answers)
      expect(restored.reviewTopicOrder).toBe(4)
    }
  })

  it('returns to unfinished TIPS on the merged pay page without losing earlier pay answers', () => {
    const base = start()
    const answeredPay = run(base, ...['OTPREM', 'OTMFG', 'OTSVC', 'SPPAY'].map(id => choose(id, ASK_CUSTOMER)))
    const legacy = { ...answeredPay, reviewTopicOrder: 2 as const, reviewCursor: 2 }
    const restored = parseSession(JSON.stringify(legacy))!
    expect(restored.reviewCursor).toBe(0)
    expect(reviewPages(restored)[0]).toContain('TIPS')
    expect(restored.answers).toEqual(answeredPay.answers)
  })

  it('does not insert a corrections page when no correction needs review', () => {
    const base = start()
    const session = { ...base, rounds: base.rounds.map(round => ({ ...round, itemIds: round.itemIds.filter(id => id !== 'BONREV') })) }
    expect(reviewSteps(session).some(step => step.label === 'Corrections & reversals')).toBe(false)
    expect(reviewStatusGroups(session).some(group => group.title === 'Corrections & reversals')).toBe(false)
    expect(reviewPages(session).flat()).not.toContain('BONREV')
  })

  it('keeps a related tip finding under pay when restoring an added-question round', () => {
    const base = apply(allDeferred())
    const session = { ...base, step: 'questions' as const, reviewTopicOrder: 2 as const, reviewCursor: 0,
      answers: { ...base.answers, 'TIPS RPT': { choice: ASK_CUSTOMER } },
      rounds: [...base.rounds, { number: 2, kind: 'added-questions' as const, itemIds: ['TIPS RPT', 'MED'], submitted: false }] }
    const restored = parseSession(JSON.stringify(session))!
    expect(reviewPages(restored)[restored.reviewCursor!]).toEqual(['TIPS RPT'])
    expect(bryteFacts(restored).facts.topicId).toBe('pay')
    expect(restored.answers).toEqual(session.answers)
  })

  it('migrates added-question topics but leaves later single-code rounds in their saved order', () => {
    const base = apply(allDeferred())
    const ids = ['BONREV', 'TIPS', 'MED']
    const answers = Object.fromEntries(ids.map(id => [id, { choice: ASK_CUSTOMER }]))
    const added = { ...base, step: 'questions' as const, reviewCursor: 1, reviewTopicOrder: undefined, answers: { ...base.answers, ...answers },
      rounds: [...base.rounds, { number: 2, kind: 'added-questions' as const, itemIds: ids, submitted: false }] }
    const restored = parseSession(JSON.stringify(added))!
    expect(reviewPages(restored)).toEqual([['TIPS'], ['BONREV']])
    expect(reviewPages(restored)[restored.reviewCursor!]).toEqual(['BONREV'])
    expect(restored.answers).toEqual(added.answers)
    const later = { ...added, rounds: [...base.rounds, { number: 2, itemIds: ids, submitted: false }] }
    const laterRestored = parseSession(JSON.stringify(later))!
    expect(reviewPages(laterRestored)).toEqual(ids.filter(id => id !== 'MED').map(id => [id]))
    expect(laterRestored.reviewCursor).toBe(1)
  })
})
