import { renderToStaticMarkup } from 'react-dom/server'
import { describe, expect, it } from 'vitest'
import { ASK_CUSTOMER, CLEAR_CHOICE, READY } from './sampleRegister'
import { combinationSourceDetails, combineBlockedReason, finalConfiguration, savedOvertimeReference } from './configuration'
import { sessionCodeStatus } from './sessionCodeStatus'
import { USABILITY_FILES } from './usabilityData'
import { OPTIMIZATIONS, findOptimization, allOptimizationsAnswered } from './optimization'
import { parseSession, reduceSession, type EarningSession, type SessionAction } from './session'
import { overtimeCombinationSession as confirmed } from './overtimeCombination.testing'
import { SOMETHING_ELSE } from './somethingElse'
import { browserStores, loadSession, saveSession, writeWorkingCopy } from './storage'
import { SessionContext } from './sessionContext'
import { StepOptimization } from './StepOptimization'
import { customerQuestionList, summaryCsv } from './summary'
import { sortEarnings } from './overtime'

const suggestionId = 'combine-current-overtime'
const suggestion = findOptimization(suggestionId)
const run = (session: EarningSession, ...actions: SessionAction[]) =>
  actions.reduce((state, action) => reduceSession(state, action, 1000), session)

function optimizationDoc(session: EarningSession) {
  return new DOMParser().parseFromString(renderToStaticMarkup(
    <SessionContext.Provider value={{ session, dispatch: () => {}, save: () => true, restart: () => true }}>
      <StepOptimization />
    </SessionContext.Provider>,
  ), 'text/html')
}

describe('current overtime combination in optimization', () => {
  it('does not confirm a saved rate overridden by Advanced Options', () => {
    let session: EarningSession = { ...confirmed('full', 'full'), scenario: 'usability', step: 'questions',
      registerSource: 'sample', files: USABILITY_FILES.map(file => ({ ...file })),
      answers: { 'OT ENG': { choice: 'full' }, 'OT MFG': { choice: 'full' } },
      resolutions: {}, rounds: [{ number: 1, itemIds: ['OT ENG', 'OT MFG', 'MILEAGE'], submitted: false }] }
    expect(savedOvertimeReference(session, 'OT ENG')?.id).toBe(READY.overtimeFull.id)
    session = run(session, { type: 'setRollUpType', cardId: 'OT ENG', value: 'Custom Earning' })
    expect(savedOvertimeReference(session, 'OT ENG')).toBeUndefined()
    expect(finalConfiguration(session).find(row => row.code === 'OT ENG')?.status).not.toBe('ready')
    expect(combineBlockedReason(session, suggestion)).toContain('confirmed setup')
    const status = sessionCodeStatus(session).rows.find(row => row.code === 'OT ENG')
    expect(status).toBeDefined()
    expect(status?.status).not.toBe('ready')
    expect(status?.reference).toBeUndefined()
  })
  it('treats saved overtime rates as confirmed without an applied round', () => {
    const session = confirmed('full', 'full')
    delete session.resolutions.OTPREM
    const details = combinationSourceDetails(session, suggestion)
    expect(details[0].detail).toBe(`Confirmed setup: ${READY.overtimeFull.name}.`)
    expect(details[1].detail).toBe(`Confirmed setup: ${READY.overtimeFull.name}.`)
    delete session.answers.OTPREM
    expect(combinationSourceDetails(session, suggestion)[1].detail).toBe('The overtime rate question has not been answered.')
  })

  it('offers usability combination from saved matching rates while other questions remain unfinished', () => {
    const session = { ...confirmed('full', 'full'), scenario: 'usability' as const,
      answers: { 'OT ENG': { choice: 'full' }, 'OT MFG': { choice: 'full' } },
      resolutions: {}, rounds: [{ number: 1, itemIds: ['OT ENG', 'OT MFG', 'MILEAGE'], submitted: false }] }
    expect(combineBlockedReason(session, suggestion)).toBeUndefined()
    expect(finalConfiguration(session).filter(row => ['OT ENG', 'OT MFG'].includes(row.code))
      .every(row => row.status === 'ready' && row.reference?.id === READY.overtimeFull.id)).toBe(true)
    expect(combineBlockedReason({ ...session, answers: { ...session.answers, 'OT ENG': { choice: 'double' } } }, suggestion)).toContain('different')
    expect(combineBlockedReason({ ...session, answers: { 'OT MFG': { choice: 'full' } } }, suggestion)).toContain('confirmed setup')
  })

  it('shows the actual differing references rather than asking for already confirmed rates', () => {
    const session = { ...confirmed('premium', 'double'), registerSource: 'uploads' as const }
    const details = combinationSourceDetails(session, suggestion)
    expect(details.map(row => row.detail)).toEqual([
      `Confirmed setup: ${READY.overtimePremium.name}.`,
      `Confirmed setup: ${READY.overtimeDouble.name}.`,
    ])
    expect(combineBlockedReason(session, suggestion)).toContain('different setups')
  })
  it.each([
    ['premium', READY.overtimePremium],
    ['full', READY.overtimeFull],
    ['double', READY.overtimeDouble],
  ] as const)('offers matching %s setups and preserves the confirmed rate when combined and restored', (choice, reference) => {
    const session = confirmed(choice, choice)
    expect(OPTIMIZATIONS).toContain(suggestion)
    expect(suggestion.codes).toEqual(['Overtime MFG', 'Overtime ENG'])
    expect(combineBlockedReason(session, suggestion)).toBeUndefined()
    const doc = optimizationDoc(session)
    expect(doc.body.textContent).toContain(suggestion.question)
    expect(doc.body.textContent).toContain('Combine into a new earnings code, OT')
    expect(doc.body.textContent).not.toContain('OTSVC')
    const accepted = run(session, { type: 'chooseOptimization', suggestionId, choice: 'accept' })
    expect(accepted.optimization.answers[suggestionId]).toBe('accept')
    for (const state of [accepted, parseSession(JSON.stringify(accepted))!]) {
      expect(state).not.toBeNull()
      const rows = finalConfiguration(state)
      expect(rows.find(row => row.code === 'OT')).toMatchObject({ reference, status: 'ready' })
      expect(rows.some(row => suggestion.codes.includes(row.code))).toBe(false)
      expect(sortEarnings(rows, {}).exclude.some(row => row.code === 'OT')).toBe(true)
      expect(summaryCsv(state, () => 'Today')).toContain(reference.name)
    }
  })

  it.each([['premium', 'double'], ['full', ASK_CUSTOMER], [ASK_CUSTOMER, 'full'], [ASK_CUSTOMER, ASK_CUSTOMER]] as const)('keeps overtime information visible without offering ineligible combinations (%s / %s)', (mfg, eng) => {
    const session = { ...confirmed(mfg, eng), registerSource: 'uploads' as const }
    expect(combineBlockedReason(session, suggestion)).toBeTruthy()
    const doc = optimizationDoc(session)
    expect(doc.body.textContent).not.toContain(combineBlockedReason(session, suggestion))
    expect(doc.body.textContent).not.toContain(suggestion.question)
    expect(doc.body.textContent).not.toContain(suggestion.keep.title)
    expect(doc.body.textContent).not.toContain('Combine into a new earnings code, OT')
    expect(doc.querySelector('[data-testid="overtime-optimization-information"]')).not.toBeNull()
    expect(doc.querySelector('.ec-ot-example')).not.toBeNull()
    expect(doc.body.textContent).toContain('Both employees use the same')
    expect(doc.body.textContent).toContain(suggestion.context.split('\n\n')[0])
    const attempted = reduceSession(session, { type: 'chooseOptimization', suggestionId, choice: 'accept' }, 1001)
    expect(attempted).toBe(session)
    // Even an obsolete accepted decision cannot replace different or unconfirmed setups.
    const stale = { ...session, optimization: { ...session.optimization, answers: { [suggestionId]: 'accept' as const } } }
    const rows = finalConfiguration(stale)
    expect(rows.some(row => row.code === 'OT')).toBe(false)
    expect(rows).toEqual(finalConfiguration(session))
  })

  it.each([['premium', 'double'], [ASK_CUSTOMER, ASK_CUSTOMER]] as const)('always offers a working combine decision in the demo (%s / %s)', (mfg, eng) => {
    const session = confirmed(mfg, eng)
    const doc = optimizationDoc(session)
    expect(doc.body.textContent).toContain(suggestion.question)
    expect(doc.body.textContent).toContain('Combine into a new earnings code, OT')
    expect(doc.querySelector('[data-testid="overtime-optimization-information"]')).toBeNull()
    const accepted = reduceSession(session, { type: 'chooseOptimization', suggestionId, choice: 'accept' }, 1001)
    expect(accepted.optimization.answers[suggestionId]).toBe('accept')
    expect(accepted.answers).toEqual(session.answers)
    expect(finalConfiguration(accepted).some(row => row.code === 'OT')).toBe(true)
    const restored = parseSession(JSON.stringify(accepted))!
    expect(restored.optimization.answers[suggestionId]).toBe('accept')
    const kept = reduceSession(accepted, { type: 'chooseOptimization', suggestionId, choice: 'keep' }, 1002)
    expect(finalConfiguration(kept).some(row => row.code === 'OT')).toBe(false)
  })

  it('keeps both codes separate when requested', () => {
    const session = run(confirmed('double', 'double'), { type: 'chooseOptimization', suggestionId, choice: 'keep' })
    const rows = finalConfiguration(session).filter(row => suggestion.codes.includes(row.code))
    expect(rows).toHaveLength(2)
    expect(rows.every(row => row.reference?.id === READY.overtimeDouble.id)).toBe(true)
  })

  it('includes the current pair in deferred customer questions without reusing the legacy decision', () => {
    const draft = run(confirmed('full', 'full'), { type: 'chooseOptimization', suggestionId, choice: ASK_CUSTOMER })
    const session = { ...draft, optimization: { ...draft.optimization, submitted: true, completed: true } }
    const question = customerQuestionList(session).find(entry => entry.id === `optimization:${suggestionId}`)
    expect(question?.codes).toEqual(suggestion.codes)
    expect(question?.question).toContain('Overtime MFG and Overtime ENG')
    expect(question?.question).not.toContain('OTSVC')
    const legacy = { ...draft, optimization: { ...draft.optimization, answers: { 'combine-overtime': 'accept' as const } } }
    const restored = parseSession(JSON.stringify(legacy))!
    expect(restored.optimization.answers['combine-overtime']).toBe('accept')
    expect(restored.optimization.answers[suggestionId]).toBeUndefined()
    expect(finalConfiguration(restored).some(row => row.code === 'OT')).toBe(false)
  })

  it('counts the current combine decision before continuing directly to overtime', () => {
    let session: EarningSession = { ...confirmed('full', 'full'), step: 'optimization' }
    for (const entry of OPTIMIZATIONS.filter(entry => entry.id !== suggestionId)) {
      session = run(session, { type: 'chooseOptimization', suggestionId: entry.id, choice: 'keep' })
    }
    expect(allOptimizationsAnswered(session.optimization)).toBe(false)
    session = run(session, { type: 'chooseOptimization', suggestionId, choice: 'accept' })
    expect(allOptimizationsAnswered(session.optimization)).toBe(true)
    const next = reduceSession(session, { type: 'submitOptimization' }, 1001)
    expect(next.step).toBe('overtime')
    expect(next.optimization.completed).toBe(true)
    expect(run(next, { type: 'chooseOptimization', suggestionId, choice: 'keep' })).toBe(next)
    expect(run(next, { type: 'chooseOptimization', suggestionId, choice: CLEAR_CHOICE })).toBe(next)
  })

  it.each(['accept', 'keep', SOMETHING_ELSE] as const)('keeps saved %s answers and sent wording through both stores', choice => {
    sessionStorage.clear(); localStorage.clear()
    let session = run(confirmed(), { type: 'chooseOptimization', suggestionId, choice })
    if (choice === SOMETHING_ELSE) session = run(session,
      { type: 'updatePhaseSomethingElse', key: `optimization:${suggestionId}`, update: { kind: 'describe', description: 'Track project costs separately.' } },
      { type: 'updatePhaseSomethingElse', key: `optimization:${suggestionId}`, update: { kind: 'submit' } })
    session = { ...session, sent: { at: 1, to: 'payroll@example.com', questionIds: [`optimization:${suggestionId}`],
      questions: [{ id: `optimization:${suggestionId}`, codes: suggestion.codes, topic: 'overtime', status: 'open',
        question: 'Previously sent overtime question. Keep this exact wording.' }] } }
    for (const save of [writeWorkingCopy, saveSession]) {
      save(browserStores(), session)
      const restored = loadSession(browserStores())
      expect(restored.optimization).toEqual(session.optimization)
      expect(restored.sent).toEqual(session.sent)
      expect(finalConfiguration(restored)).toEqual(finalConfiguration(session))
      sessionStorage.clear()
    }
    localStorage.clear()
  })
})
