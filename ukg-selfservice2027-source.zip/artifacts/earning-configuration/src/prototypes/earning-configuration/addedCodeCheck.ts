import { checkAddedEarningCode } from '@workspace/api-client-react'
import type { AddedCheckResult, AddedCode, AddedCodesEvent } from './addedCodes'

const GENERIC = 'We can’t check this code right now. Try again.'
/** Tokens already sent, so a remount or rerender never sends the same check twice. */
const inflight = new Set<string>()

export function errorMessage(error: unknown): string {
  const data = error && typeof error === 'object' && 'data' in error ? (error as { data: unknown }).data : undefined
  const text = data && typeof data === 'object' && 'error' in data ? (data as { error: unknown }).error : undefined
  const code = data && typeof data === 'object' && 'code' in data ? (data as { code: unknown }).code : undefined
  const status = error && typeof error === 'object' && 'status' in error ? (error as { status: unknown }).status : undefined
  const expected: Record<string, number> = { invalid_request: 400, rate_limited: 429, unavailable: 502, timed_out: 504, invalid_response: 502 }
  return typeof code === 'string' && Object.hasOwn(expected, code) && expected[code] === status && typeof text === 'string' && text.trim() ? text : GENERIC
}

/**
 * Sends one live check for the entry's current intention and replies. The response is dispatched with the token it was
 * sent for; the reducer drops it if the code was edited, removed or replaced meanwhile. A failure never becomes a result.
 */
export function runAddedCheck(entry: AddedCode, send: (event: AddedCodesEvent) => void,
  request: typeof checkAddedEarningCode = checkAddedEarningCode, timeoutMs = 35_000) {
  if (entry.check?.status !== 'checking' || inflight.has(entry.check.token)) return
  const token = entry.check.token
  inflight.add(token)
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)
  request({ description: entry.description, thread: entry.thread ?? [] }, { signal: controller.signal })
    .then(result => send({ kind: 'checkResult', id: entry.id, token, result: result as AddedCheckResult }))
    .catch(error => send({ kind: 'checkError', id: entry.id, token,
      message: controller.signal.aborted ? 'Checking this code took too long. Try again.' : errorMessage(error) }))
    .finally(() => { clearTimeout(timer); inflight.delete(token) })
}
