import { useContext, useId } from 'react'
import Checkbox from '@ready/dls/components/Checkbox/Checkbox'
import { ASK_CUSTOMER, CLEAR_CHOICE } from './sampleRegister'
import DeferCoffee from './DeferCoffee'
import './deferCheckbox.css'
import { ExplicitDeferralContext, type DeferredQuestion } from './explicitDeferral'

interface DeferCheckboxProps {
  checked: boolean
  /** Receives ASK_CUSTOMER when checked and CLEAR_CHOICE when unchecked. */
  onChange: (choice: typeof ASK_CUSTOMER | typeof CLEAR_CHOICE) => void
  disabled?: boolean
  /** The question it defers, so “Defer” isn't announced without context when a page has several. */
  labelledBy: string
  id?: string
  source?: DeferredQuestion
  /** A shared card records each target in its owning question's context. */
  recordSelection?: boolean
}

/**
 * The one control for leaving a decision for the customer, at the bottom right of the question it defers, below its
 * options, with a decorative coffee cup beside it. The original answer action still owns gating and setup;
 * the explicit selection separately identifies which question the shared review may ask. Clearing removes both.
 * BONREV's retired team-only Defer is a different, older choice.
 */
export default function DeferCheckbox({ checked, onChange, disabled = false, labelledBy, id, source, recordSelection = true }: DeferCheckboxProps) {
  const generatedId = useId()
  const context = useContext(ExplicitDeferralContext)
  return (
    <div className="ec-defer" role="group" aria-labelledby={labelledBy}>
      <Checkbox id={id ?? generatedId} label="Review later" checked={checked} disabled={disabled}
        onChange={isChecked => {
          onChange(isChecked ? ASK_CUSTOMER : CLEAR_CHOICE)
          if (context && recordSelection) context.dispatch({ type: 'selectDeferredQuestion', itemId: context.itemId,
            source: isChecked ? source : undefined })
        }} />
      <DeferCoffee checked={checked} />
    </div>
  )
}
