import { checkedAnswer, reduceChecked } from './scriptedChecks.testing'
import { describe, expect, it } from 'vitest'
import { earningPages } from '../../askBrytePages'
import { bryteFacts, type EarningBrytePage } from './bryteFacts'
import { OPTIMIZATIONS } from './optimization'
import { ALL_ITEMS, ASK_CUSTOMER, PAY_CODES } from './sampleRegister'
import { createSession, reduceSession, type EarningSession, type SessionAction } from './session'

function run(session: EarningSession, ...actions: SessionAction[]) {
  return actions.reduce((current, action, index) => reduceChecked(current, action, 1_000 + index), session)
}

// Values that must never reach Bryte: an uploaded file name, descriptions typed by the team and the
// customer, and the customer's email address.
const FILE_NAME = 'Planted register for Jane Roe.pdf'
const TEAM_DESCRIPTION = 'Planted team description: Jane Roe gets 1,234 dollars'
const CUSTOMER_DESCRIPTION = 'Planted customer description from Maria Lopez'
const CUSTOMER_EMAIL = 'planted.payroll@acme.example'

const uploaded: SessionAction = { type: 'setFiles', files: [{ id: 'f1', name: FILE_NAME, sizeBytes: 2048, docType: 'Pay register' }] }

// Keep all new earnings and plan questions on the customer list in this fixture, without raising findings.
const firstRound: SessionAction[] = [
  { type: 'choose', itemId: 'BONREV', choice: 'accept' },
  { type: 'choose', itemId: 'OTPREM', choice: 'premium' },
  { type: 'choose', itemId: 'MISC7', choice: ASK_CUSTOMER },
  { type: 'choose', itemId: 'OTMFG', choice: 'full' }, { type: 'choose', itemId: 'OTSVC', choice: 'full' },
  { type: 'choose', itemId: 'CELL-purpose', choice: 'allowance' },
  { type: 'choose', itemId: 'SPPAY', choice: ASK_CUSTOMER },
  { type: 'describe', itemId: 'ADJ2', description: TEAM_DESCRIPTION },
  { type: 'submitDescription', itemId: 'ADJ2' },
  { type: 'answerFollowUp', itemId: 'ADJ2', questionId: 'basis', choice: 'flat' },
  { type: 'answerFollowUp', itemId: 'ADJ2', questionId: 'frequency', choice: 'one-time' },
  { type: 'chooseRetention', itemId: 'ADJ2', choice: 'keep' },
  { type: 'choose', itemId: 'ADJ2', choice: 'accept' },
  ...['MILEAGE', 'TIPS',
    'GTL-review', 'IMP INC', 'MED', 'MED ER']
    .map(itemId => ({ type: 'choose', itemId, choice: ASK_CUSTOMER } as SessionAction)),
  ...['VAC', 'SICK', 'HOL', 'JURY'].map(code => ({ type: 'choose' as const, itemId: `${code}-purpose`, choice: 'confirm-purpose' })),
]

/** Every phase in order, walked with the same actions the screens dispatch. */
function walk(splitBonus: 'accept' | 'keep' = 'accept') {
  const steps: EarningSession[] = []
  let session = createSession(0)
  const visit = (...actions: SessionAction[]) => { session = run(session, ...actions); steps.push(session) }
  visit()
  visit({ type: 'goTo', step: 'upload' }, uploaded)
  visit({ type: 'goTo', step: 'analysis' })
  visit({ type: 'goTo', step: 'results' })
  visit({ type: 'startReview' }, ...firstRound.slice(0, 3))
  visit(...firstRound.slice(3), { type: 'submitRound' })
  visit({ type: 'finishReevaluation' })
  visit({ type: 'complete' }, { type: 'chooseOptimization', suggestionId: 'combine-overtime', choice: 'accept' })
  visit(
    { type: 'chooseOptimization', suggestionId: 'split-bonus', choice: splitBonus },
    { type: 'chooseOptimization', suggestionId: 'inactive-JURY', choice: ASK_CUSTOMER },
    { type: 'submitOptimization' },
  )
  visit({ type: 'completeOptimization' })
  visit({ type: 'startOvertime' }, { type: 'answerOvertime', questionId: 'multiRate', answer: 'no' })
  visit({ type: 'answerOvertime', questionId: 'shiftDiff', answer: 'yes' }, { type: 'reviewOvertimeSort' })
  if (splitBonus === 'keep') visit({ type: 'resolveMixedEarning', code: 'BONUS', choice: ASK_CUSTOMER })
  visit({ type: 'confirmOvertime' }, { type: 'sendQuestions', to: CUSTOMER_EMAIL })
  // The customer's reply settles MISC7 as a new earning, which sends the team back to confirm the sorting.
  visit({ type: 'saveCustomerReply', questionId: 'classification:MISC7', answer: checkedAnswer('MISC7', {
    description: CUSTOMER_DESCRIPTION, descriptionSubmitted: true, choice: 'accept',
    sharedSetup: { referenceId: 'RDY-E-020', choice: 'separate' },
  }) })
  return steps
}

function describePage(session: EarningSession) {
  const { key, facts } = bryteFacts(session)
  return { key, facts, page: earningPages[key](facts) }
}

describe('Ask Bryte facts', () => {
  it.each([0, 1])('uses payroll review summary terminology with %i new findings', nextRoundFindings => {
    const facts = { round: 1, nextRoundFindings, cheatSheetGroups: 'To discuss: MILEAGE' }
    const recheck = earningPages.reevaluation(facts)
    expect(recheck.purpose).toContain('Open review')
    expect(recheck.onScreen).toContain('Actions: Open review once the recheck finishes')
    const page = earningPages.review(facts)
    expect(page.name).toBe('Let’s fill in the gaps in your pay code setup')
    expect(page.purpose).toContain('Let’s fill in the gaps in your pay code setup')
    expect(page.onScreen).toContain('Each code starts with Details to confirm and Discussion notes. Why it matters and View source start collapsed. No stats')
    expect(page.onScreen.join(' ')).toContain('suggestions, not instructions')
    expect(page.state).toContain('Review group: To discuss: MILEAGE')
    expect(page.welcome).not.toContain('What do we need to review?')
    expect(page.welcome).toContain('Details to confirm')
    expect(page.suggestions).toContain('What should I review on this page?')
    expect(page.suggestions).toContain('What does Details to confirm cover?')
    expect(page.onScreen).toContain(`Actions: ${nextRoundFindings ? 'Review 1 new finding' : 'Complete classification'}`)
    expect(JSON.stringify({ recheck, page })).not.toMatch(/cheat sheet|Suggested questions to ask/i)
  })
  it('describes direct upload navigation without a retired introduction page', () => {
    expect(earningPages).not.toHaveProperty('earningIntro')
    expect(earningPages.intro().onScreen.join(' ')).toContain('Set up earnings opens Help us identify your payroll codes directly')
    expect(earningPages.categorySelection({}).onScreen.join(' ')).toContain('Set up earnings opens Help us identify your payroll codes')
    expect(earningPages.upload({}).name).toBe('Help us identify your payroll codes')
    expect(earningPages.upload({}).welcome).toContain('Help us identify your payroll codes')
    // The overtime demo starts from the Projects page, not from a header button.
    expect(earningPages.intro().onScreen.join(' ')).toContain('Start at overtime in the Earning Configuration card’s Open menu on the Projects page')
    expect(earningPages.intro().onScreen.join(' ')).not.toMatch(/Start at overtime (are|is) in the header/)
    const upload = describePage(run(createSession(0), { type: 'goTo', step: 'upload' }))
    expect(upload.page.onScreen.join(' ')).toContain('Back returns to the payroll choices')
    expect(upload.page.onScreen.join(' ')).toContain('Files, assignments and answers are kept')
    expect(upload.page.onScreen.join(' ')).toContain('progress from later steps')
  })
  it('gives neutral chooser guidance regardless of legacy category bookkeeping', () => {
    const chooser = run(createSession(0), { type: 'goTo', step: 'categorySelection' })
    const neutral = describePage(chooser)
    expect(neutral.facts).toEqual({})
    expect(neutral.page.state).toEqual([])
    for (const selectedCategory of ['earnings', 'deductions', 'taxes'] as const) {
      expect(describePage({ ...chooser, selectedCategory })).toEqual(neutral)
    }
    expect(neutral.page.welcome).toContain('Choose where to start')
    expect(neutral.page.welcome).not.toContain('available')
    expect(neutral.page.onScreen.join(' ')).toContain('Three cards: Earnings, Deductions and Taxes')
    expect(neutral.page.onScreen.join(' ')).toContain('Card bodies are not interactive')
    expect(neutral.page.onScreen.join(' ')).toContain('Set up earnings opens Help us identify your payroll codes')
    expect(neutral.page.onScreen.join(' ')).toContain('View deductions opens the existing information-only Deductions page')
    expect(neutral.page.onScreen.join(' ')).toContain('View taxes opens the existing information-only Taxes page')
    expect(neutral.page.onScreen.join(' ')).toContain('Assign to others opens an independent dialog')
    expect(neutral.page.onScreen.join(' ')).toContain('Leave unchanged, Close dialog or Escape discards pending changes')
    expect(neutral.page.onScreen.join(' ')).not.toContain('Next opens')
    for (const key of ['deductions', 'taxes'] as const) {
      expect(earningPages[key]().onScreen.join(' ')).toContain('Back to payroll choices')
      expect(earningPages[key]().purpose).toContain('does not change earnings answers or progress')
      expect(earningPages[key]().welcome).not.toContain('available')
    }
  })
  it('registers a page for every phase, with new findings separate from the first round', () => {
    const steps = walk('keep')
    expect(steps.map(session => bryteFacts(session).key)).toEqual<EarningBrytePage[]>([
      'intro', 'upload', 'analysis', 'results', 'questions', 'reevaluation', 'review',
      'optimization', 'optimizationReview', 'overtime', 'overtime', 'overtimeSort', 'overtimeSort', 'summary', 'overtimeSort',
    ])
    // The earning sample raises no new findings, but a later round of questions still gets its own page.
    const questions = describePage(steps[4])
    const laterRound = { ...steps[4], reviewCursor: 0, rounds: [
      ...steps[4].rounds, { number: 2, itemIds: ['BONREV', 'CELL-purpose'], submitted: false },
    ] }
    expect(bryteFacts(laterRound).key).toBe('new-findings')
  })

  it('describes each first-round category using only its on-screen codes, while later rounds retain detail', () => {
    const steps = walk('keep')
    const questions = describePage({ ...steps[4], reviewCursor: 7 })
    expect(questions.facts).toMatchObject({ round: 1, answered: 3, total: 14, currentCode: 'ADJ2', category: 'Other codes', page: 7, pages: 7, codesInView: 'ADJ2, MISC7' })
    expect(questions.page.state).toContain('Round 1: 3 of 14 answered')
    expect(questions.page.state).toContain('Codes on this page: ADJ2, MISC7')
    expect(questions.page.state).toContain('Other codes · 7 of 7 pages')
    // The screen shows the left stepper with the round's count and the current page, not a Page X of Y line.
    expect(questions.page.onScreen[0]).toBe('Other codes: ADJ2, MISC7')
    expect(questions.page.onScreen[1]).toBe('Left stepper: 7 pages, page 7 current; finished and reachable pages are links. Under the heading: 1 deferred, View code status')
    expect(questions.page.onScreen.join(' ')).not.toContain('step indicator')
    expect(questions.page.onScreen.join(' ')).not.toMatch(/Page \d+ of \d+/)
    expect(questions.page.state).toContain('Still open on this page: ADJ2')
    expect(questions.page.state).toContain('Decision: MISC7: Deferred (added to the questions for the customer)')
    expect(questions.page.state.find(line => line.startsWith('Code in view: '))).toMatch(/^Code in view: ADJ2 \(1 of 2 · Other codes\): /)
    expect(questions.page.suggestions).toContain('Why does ADJ2 ask whether to keep it?')
    expect(JSON.stringify({ facts: questions.facts, page: questions.page })).not.toContain('OTPREM')
    // ADJ2 is described first; whether to keep it comes after its follow-ups.
    expect(questions.page.onScreen.join(' ')).toContain('ADJ2 and MISC7 open on a description input with Done and Defer')
    expect(questions.page.onScreen.join(' ')).toContain('after its follow-ups it asks Keep ADJ2 or Remove ADJ2, or Defer')
    expect(questions.page.welcome).toContain('ADJ2 and MISC7 need descriptions')
    expect(questions.page.onScreen.join(' ')).not.toContain('SPPAY')
    expect(questions.page.onScreen.join(' ')).toContain('Keep or remove and Use ‘…’ questions end with Something else')
    expect(questions.page.onScreen.join(' ')).not.toMatch(/possible (Shift differential )?match/i)
    expect(questions.page.onScreen.join(' ')).toContain('Back returns to the completed summary from the first page')
    expect(questions.page.onScreen.join(' ')).toContain('Save and finish later, Restart demo, Ask Bryte')
    expect(questions.page.onScreen.join(' ')).not.toContain('Start at overtime')
    // The saved cursor is the BONREV page, with its own code and earlier decisions in round state.
    const moved = describePage(reduceChecked(run(steps[4], ...firstRound.slice(3)), { type: 'moveReview', index: 0 }))
    expect(moved.facts.currentCode).toBe('BONREV')
    expect(moved.facts.codesInView).toBe('BONREV')
    expect(moved.page.state).toContain('Codes on this page: BONREV')
    expect(moved.page.state).toContain('Changes we found · 1 of 7 pages')
    expect(moved.page.state).toContain('Round 1: 14 of 14 answered')
    expect(moved.page.state).toContain('Decision: BONREV: set up as Bonus reversal (Deduction)')
    expect(moved.page.suggestions).toContain('What happens if I defer BONREV?')
    expect(JSON.stringify({ facts: moved.facts, page: moved.page })).not.toContain('OTPREM')
    const finalCategory = describePage(reduceChecked(run(steps[4], ...firstRound.slice(3)), { type: 'moveReview', index: 1 }))
    expect(finalCategory.facts).toMatchObject({ category: 'How employees are paid', page: 2, codesInView: 'OTPREM, OTMFG, OTSVC, SPPAY' })
    expect(finalCategory.facts.uncertainMatches).toContain('SPPAY: each option sets it up as a Ready reference, Shift differential or Retroactive pay')
    expect(finalCategory.page.welcome).not.toContain('CELL')
    expect(finalCategory.page.suggestions.join(' ')).not.toContain('CELL')
    expect(finalCategory.page.onScreen.join(' ')).not.toContain('60% AI match')
    expect(finalCategory.page.suggestions).toContain('What does the 60% suggestion mean for OTPREM?')
    const laterRound = { ...steps[4], reviewCursor: 0, rounds: [
      ...steps[4].rounds, { number: 2, itemIds: ['BONREV', 'CELL-purpose'], submitted: false },
    ] }
    const later = describePage(laterRound)
    expect(later.key).toBe('new-findings')
    expect(later.facts).toMatchObject({ page: 1, pages: 2 })
    expect(later.facts).not.toHaveProperty('category')
    expect(later.page.onScreen.join(' ')).toContain('Left stepper: 2 pages, page 1 current')
    expect(later.page.state).toContain('Round 2: 1 of 2 answered')
    const inView = later.page.state.find(line => line.startsWith('Code in view: '))
    expect(inView).toMatch(/^Code in view: BONREV \(1 of 2 · Potential misclassification\): answered, set up as /)
    expect(later.page.suggestions[0]).toBe('Why was BONREV raised?')

    const results = describePage(steps[3])
    expect(results.page.state).toContain('Earning codes: 20')
    expect(results.page.state).toContain('Need your input: 12. Matched: 8')
    expect(results.page.state).toContain('Benefit plans to confirm: 2')
    expect(results.page.state.map(line => line.match(/^(.*?) \(\d+\):/)?.[1]).filter(Boolean)).toEqual([
      'Changes we found', 'How employees are paid', 'Allowances & reimbursements', 'Benefits & employer contributions',
      'Tips', 'Taxable benefits', 'Other codes',
    ])
    expect(results.page.state.some(line => /401K|ERHLTH|SPEC4/.test(line))).toBe(false)

    const optimization = describePage(steps[8])
    expect(optimization.facts).toMatchObject({ answered: 1, total: OPTIMIZATIONS.length, nextKind: 'split' })

    const overtime = describePage(steps[11])
    expect(overtime.page.state.some(line => line.startsWith('Question being answered: Q2'))).toBe(true)

    const sorting = describePage(steps[12])
    expect(sorting.page.state.some(line => line.startsWith('Weighted average overtime applies because the customer pays a shift differential'))).toBe(true)

    const summary = describePage(steps[14])
    expect(summary.facts.sent).toBe(true)
    expect(summary.page.state.some(line => line.endsWith('The questions were sent to the customer'))).toBe(true)
  })

  it('shows a mixed code on the sorting page until the team decides it', () => {
    const steps = walk('keep')
    const sorting = describePage(steps[12])
    expect(sorting.key).toBe('overtimeSort')
    expect(sorting.page.state.some(line => line.startsWith('Mixed code that needs a decision: BONUS'))).toBe(true)
    const decided = describePage(steps[13])
    expect(decided.page.state).toContain('Mixed codes decided here: BONUS: Deferred')
  })

  it('keeps every page within the description limits and the experienced register', () => {
    for (const session of [...walk(), ...walk('keep')]) {
      const { key, page } = describePage(session)
      expect(page.name, key).not.toBe('')
      expect(page.purpose.length, key).toBeLessThanOrEqual(400)
      expect(page.onScreen.length, key).toBeLessThanOrEqual(12)
      expect(page.state.length, key).toBeLessThanOrEqual(16)
      for (const line of [...page.onScreen, ...page.state]) expect(line.length, `${key}: ${line}`).toBeLessThanOrEqual(200)
      expect(page.suggestions.length, key).toBeGreaterThanOrEqual(2)
      expect(page.suggestions.length, key).toBeLessThanOrEqual(4)
      expect(new Set(page.suggestions).size, key).toBe(page.suggestions.length)
    }
  })

  it('never includes names, pay amounts, file names or contents, typed descriptions or the customer’s details', () => {
    const planted = [FILE_NAME, 'Jane Roe', 'Maria Lopez', TEAM_DESCRIPTION, CUSTOMER_DESCRIPTION, CUSTOMER_EMAIL]
    // Questions and context written for the customer quote amounts and how many people are paid a code.
    const itemTexts = ALL_ITEMS.flatMap(item => [
      item.context, item.customerQuestion, ...(item.type === 'clarification' && item.overview ? [item.overview] : []),
      ...(item.type === 'unidentified' && item.script.kind === 'followUp'
        ? [...item.script.questions.map(question => question.context),
          ...item.script.outcomes.flatMap(outcome => (outcome.kind === 'noMatch' ? [outcome.customerQuestion] : []))]
        : []),
    ]).filter(Boolean)
    const optimizationTexts = OPTIMIZATIONS.flatMap(suggestion => [suggestion.context, suggestion.customerQuestion])
    const amounts = PAY_CODES.filter(code => code.amount >= 1_000).map(code => code.amount.toLocaleString('en-US'))
    for (const session of [...walk(), ...walk('keep')]) {
      const { key, facts, page } = describePage(session)
      // The one amount Bryte reads is MILEAGE's per-mile rate and the IRS rate it's compared with: company policy, not pay.
      const sent = JSON.stringify({ facts, page }).replace(/\$\d+\.\d{2,3} a mile/g, '')
      for (const value of [...planted, ...itemTexts, ...optimizationTexts, ...amounts]) expect(sent, `${key} includes "${value}"`).not.toContain(value)
      expect(sent, key).not.toMatch(/\$|\d[\d,]*\s+(employees|people)/)
    }
  })
})
