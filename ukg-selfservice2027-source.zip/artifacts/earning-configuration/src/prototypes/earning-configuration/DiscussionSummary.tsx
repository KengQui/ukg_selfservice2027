import { useEffect, useRef, useState } from 'react'
import { summarizeEarningDiscussion } from '@workspace/api-client-react'
import { Button } from '@ready/dls/compatibility'
import { redactSensitive } from '@workspace/setup-shared/ask-bryte'
import { useEarningSession } from './sessionContext'
import { discussionSummaryBasis, discussionSummaryInput } from './discussionSummary'
import { useAppliedDiscussion } from './appliedDiscussionPresentation'

const FALLBACK = 'We can’t summarize this context right now. Your answers are unchanged. Try again, or continue with the original answers.'
function summaryError(error: unknown) {
  if (!error || typeof error !== 'object' || !('data' in error) || !('status' in error)) return FALLBACK
  const data = error.data as { code?: string; error?: unknown }
  const codes: Record<string, number> = { invalid_request: 400, rate_limited: 429, unavailable: 502, invalid_response: 502, timed_out: 504 }
  return data?.code && codes[data.code] === error.status && typeof data.error === 'string' ? data.error : FALLBACK
}

export default function DiscussionSummary({ itemId }: { itemId: string }) {
  const { session, dispatch } = useEarningSession()
  const readOnly = useAppliedDiscussion()
  const basis = discussionSummaryBasis(session, itemId)
  const saved = session.discussionSummaries?.[itemId]
  const summary = saved && (readOnly || saved.basis === basis) ? saved.summary : undefined
  const [retry, setRetry] = useState(0)
  const [state, setState] = useState<{ basis: string; error?: string }>()
  const latest = useRef({ session, dispatch, basis })
  latest.current = { session, dispatch, basis }
  useEffect(() => {
    if (readOnly || !basis || summary) return
    const controller = new AbortController()
    const input = discussionSummaryInput(latest.current.session, itemId)
    if (!input) return
    setState({ basis })
    summarizeEarningDiscussion(input, { signal: controller.signal }).then(result => {
      if (controller.signal.aborted || latest.current.basis !== basis) return
      if (!result.summary?.trim() || result.summary.length > 600) { setState({ basis, error: FALLBACK }); return }
      latest.current.dispatch({ type: 'setDiscussionSummary', itemId, basis, summary: redactSensitive(result.summary) })
    }).catch(error => { if (!controller.signal.aborted) setState({ basis, error: summaryError(error) }) })
    return () => controller.abort()
  }, [basis, itemId, retry, summary])
  if (!basis || readOnly && !summary) return null
  const error = state?.basis === basis ? state.error : undefined
  return <section className="ec-discussion-summary" aria-label="What we know so far">
    <strong className="text-caption">What we know so far</strong>
    <div role="status">{summary ? <p className="ec-cheat__text">{summary}</p>
      : error ? <><p className="ec-section-note">{error}</p><Button variant="tertiary" size="small" onClick={() => setRetry(value => value + 1)}>Retry summary</Button></>
        : <p className="ec-section-note">We’re summarizing the earlier answers. You can keep reviewing.</p>}</div>
  </section>
}
