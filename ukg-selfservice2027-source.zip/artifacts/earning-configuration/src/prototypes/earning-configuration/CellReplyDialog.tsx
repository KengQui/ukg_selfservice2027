import { useState } from 'react'
import { Dialog } from '@ready/dls/compatibility'
import type { SummaryQuestion } from './summary'
import { useEarningSession } from './sessionContext'
import AdaptiveCellQuestions from './AdaptiveCellQuestions'
import { CELL_ID } from './cell'
import { cellFlowDecision, cellOutstanding, recheckCellPending, reduceCell } from './cellFlow'
import type { ItemAnswer } from './session'
import { reimbursementAnswer } from './reimbursements'
import { findItem } from './sampleRegister'
import { isMileage } from './mileageQuestions'

export default function CellReplyDialog({ question, onClose }: { question: SummaryQuestion; onClose: () => void }) {
  const { session, dispatch } = useEarningSession()
  const itemId = question.id.startsWith('reimbursement:') ? question.id.split(':')[1] : CELL_ID
  const saved = reimbursementAnswer(findItem(itemId), session.answers[itemId]) ?? session.answers[itemId] ?? {}
  const outstanding = cellOutstanding(saved)
  const recovered = recheckCellPending(saved, outstanding?.id === 'review')
  const [draft, setDraft] = useState<ItemAnswer>(() => question.reply && typeof question.reply.answer === 'object'
    ? question.reply.answer : recovered !== saved ? recovered
      : { ...saved, cell: { ...saved.cell!, deferred: outstanding } })
  const [answered, setAnswered] = useState(false)
  const lockedIds = (saved.cell?.entries ?? []).filter(e => e.id !== outstanding?.id).map(e => e.id)
  const readOnly = !!question.reply
  const ready = !readOnly && answered && !!cellFlowDecision(draft) && !draft.cell?.deferred
  return <Dialog open onClose={onClose} title={`Customer answer: ${question.codes[0]}`}
    secondaryAction={{ label: 'Leave it open', onClick: onClose }}
    primaryAction={{ label: 'Save answer', disabled: !ready, onClick: () => {
      if (!ready) return
      dispatch({ type: 'saveCustomerReply', questionId: question.id, answer: draft })
      onClose()
    } }}>
    <p className="text-body ec-intro">Earlier saved answers stay unchanged. Nothing changes until you save this reply.</p>
    <section aria-label="Question for the customer"><h2 className="text-caption ec-eyebrow">What we asked the customer</h2>
      {question.question.split('\n\n').map((text, index) => <p className="text-body" key={index}>{text}</p>)}
    </section>
    <AdaptiveCellQuestions answer={draft} label={question.codes[0]} sourceItemId={itemId} lockedIds={lockedIds} readOnly={readOnly}
      onEvent={event => {
        const next = reduceCell(draft, event)
        if (next === draft) return
        // A refreshed MILEAGE assessment can finish on facts already committed before the
        // obsolete duplicate was deferred. Saving is still explicit; no extra answer is needed.
        if (event.kind === 'answer' || event.kind === 'checked' && isMileage(saved) && recovered !== saved) setAnswered(true)
        setDraft(next)
      }} />
    {!readOnly && !ready && <p className="text-body">Answer the outstanding question and let the check finish before saving. You can leave this open if the customer isn’t sure.</p>}
  </Dialog>
}
