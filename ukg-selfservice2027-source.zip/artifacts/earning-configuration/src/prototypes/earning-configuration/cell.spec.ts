import { describe, expect, it } from 'vitest'
import { CELL_ID, cellDecision, cellQuestionStage } from './cell'
import { cellBasis, cellFlowDecision, cellNext, cellOutstanding, paymentReadiness, reduceCell } from './cellFlow'
import { cellChecked, cellPick, cellResult, cellSession, fixedBusiness, readyCell, sentCell } from './cellFlow.testing'
import { migrateCellFlow, validCellFlow } from './cellPersistence'
import { createSession, isAnswered, parseSession, reduceSession } from './session'
import { findItem, READY } from './sampleRegister'
import { customerQuestionList, summaryCsv } from './summary'
import { finalConfiguration } from './configuration'
import { customerDraftRequest } from './customerQuestionDraft'
import { bryteFacts } from './bryteFacts'

describe('CELL payment facts and independent tax intent', () => {
  it('starts unselected, asks the fixed allowance reason, and never resolves a fixed amount automatically', () => {
    expect(cellNext({})).toMatchObject({ kind: 'question', question: { id: 'method' } })
    const method = cellPick({}, 'method', 'allowance')
    expect(cellNext(method)).toMatchObject({ kind: 'question', question: { id: 'allowance-purpose' } })
    expect(cellDecision(method)).toBeUndefined()
    expect(cellNext(fixedBusiness())).toEqual({ kind: 'check' })
  })
  it.each(['taxable', 'nontaxable'])('captures explicit %s allowance intent after business facts', intent => {
    const answer = readyCell(intent)
    expect(cellNext(answer).kind).toBe('done')
    expect(answer.cell?.entries.at(-1)?.value).toBe(intent)
    expect(cellDecision(answer)?.kind).toBe('describe')
    // No applicable setup documentation is verified for either intended treatment.
  })
  it.each(['taxable', 'nontaxable'])('reimbursement requires explicit %s confirmation', intent => {
    let answer = cellPick({}, 'method', 'reimbursement')
    expect(cellDecision(answer)).toBeUndefined()
    answer = cellChecked(answer, cellResult('reimbursement-basis', 'reimbursement'))
    answer = cellPick(answer, 'reimbursement-basis', 'expenses')
    expect(cellDecision(answer)).toBeUndefined()
    answer = cellChecked(answer, cellResult('tax', 'reimbursement'))
    answer = cellPick(answer, 'tax-reimbursement', intent)
    expect(cellDecision(answer)).toMatchObject({ kind: 'describe', note: expect.stringContaining('Configuration review required') })
    expect(JSON.stringify(answer.cell?.entries)).not.toMatch(/receipt|accountable plan/i)
  })
  it('skips an unnecessary calculation question when all business facts and an applicable confirmation are known', () => {
    let answer = cellPick({}, 'method', 'other', 'We reimburse business phone costs; our company has confirmed it qualifies for tax-free treatment.')
    expect(cellNext(answer)).toEqual({ kind: 'check' })
    answer = cellChecked(answer, cellResult('tax', 'payment', { confirmations: [{
      component: 'payment', intent: 'nontaxable', answerId: 'method', quote: 'our company has confirmed it qualifies for tax-free treatment.',
    }] }))
    expect(cellNext(answer).kind).toBe('done')
    expect(answer.cell?.entries).toHaveLength(1)
    expect(cellDecision(answer)?.kind).toBe('describe')
  })
  it('keeps Both components independent and does not create or require split codes', () => {
    let answer = cellPick(cellPick({}, 'method', 'both'), 'allowance-purpose', 'business')
    answer = cellPick(cellChecked(answer), 'tax-allowance', 'taxable')
    expect(cellNext(answer)).toEqual({ kind: 'check' })
    answer = cellChecked(answer, cellResult('tax', 'reimbursement'))
    answer = cellPick(answer, 'tax-reimbursement', 'nontaxable')
    expect(cellNext(answer).kind).toBe('done')
    expect(cellDecision(answer)).toMatchObject({ kind: 'describe', note: expect.stringContaining('no separate codes') })
    expect(cellDecision(answer)).not.toHaveProperty('outputs')
    expect(answer.cell?.entries.filter(e => e.id.startsWith('tax-')).map(e => e.value)).toEqual(['taxable', 'nontaxable'])
  })
  it('Not sure on one component allows the other to continue, but never counts as tax ready', () => {
    let answer = cellPick(cellPick({}, 'method', 'both'), 'allowance-purpose', 'business')
    answer = cellPick(cellChecked(answer), 'tax-allowance', 'unsure')
    expect(cellNext(answer).kind).toBe('check')
    answer = cellPick(cellChecked(answer, cellResult('tax', 'reimbursement')), 'tax-reimbursement', 'taxable')
    expect(cellDecision(answer)).toEqual({ kind: 'defer' })
    expect(cellOutstanding(answer)?.id).toBe('tax-allowance')
  })
  it('clarifies compensatory nontaxable intent instead of silently approving it', () => {
    let answer = cellPick(cellPick({}, 'method', 'allowance'), 'allowance-purpose', 'compensation')
    answer = cellPick(cellChecked(answer), 'tax-allowance', 'nontaxable')
    expect(cellDecision(answer)).toBeUndefined()
    answer = cellChecked(answer, cellResult('clarify', 'allowance', {
      question: 'What has your adviser confirmed about this allowance’s compensation purpose?', answerFormat: { kind: 'text', options: null },
    }))
    answer = cellPick(answer, 'clarify-1', 'Our adviser is still checking.')
    answer = cellChecked(answer, cellResult('pending', 'allowance', { reason: 'The compensation purpose and requested tax-free treatment still need confirmation.' }))
    expect(cellDecision(answer)).toMatchObject({ kind: 'describe', note: expect.stringContaining('Pending setup review') })
  })
  it('Something else continues after Done and accepts choices or text, not a purpose-identification question', () => {
    let answer = cellPick({}, 'method', 'other', 'A phone allowance varies with the employee’s business calls.')
    answer = cellChecked(answer, cellResult('clarify', 'payment', {
      question: 'Is the amount capped at the employee’s phone costs?', answerFormat: { kind: 'choices', options: ['Yes', 'No', 'Not sure'] },
    }))
    expect(cellNext(answer)).toMatchObject({ kind: 'question', question: { format: { kind: 'choices' } } })
    expect(cellDecision(answer)).toBeUndefined()
    answer = cellPick(answer, 'clarify-1', 'Yes')
    answer = cellChecked(answer, cellResult('tax', 'payment'))
    expect(cellNext(answer)).toMatchObject({ kind: 'question', question: { id: 'tax-payment' } })
  })
  it('special tax treatment receives live clarification rather than terminal description', () => {
    const answer = cellPick(cellChecked(fixedBusiness()), 'tax-allowance', 'other', 'Part of the amount has special treatment.')
    expect(cellNext(answer).kind).toBe('check')
    expect(cellDecision(answer)).toBeUndefined()
  })
  it('keeps unanswered decisions pending at the cap; generic confirmation never counts as tax approval', () => {
    let answer = cellPick({}, 'method', 'other', 'The method varies.')
    for (let i = 1; i <= 6; i++) {
      answer = cellChecked(answer, cellResult('clarify', 'payment', { question: `Which rule applies to part ${i}?`, answerFormat: { kind: 'text', options: null } }))
      answer = cellPick(answer, `clarify-${i}`, 'Confirm')
    }
    expect(JSON.parse(cellBasis(answer)).questionsLeft).toBe(0)
    answer = cellChecked(answer, cellResult('pending', 'payment', { reason: 'The remaining payment facts and tax intent need review.' }))
    expect(cellDecision(answer)).toMatchObject({ kind: 'describe' })
    expect(cellDecision(answer)).not.toHaveProperty('reference')
  })
  it('preserves learned facts on Defer and ignores stale responses', () => {
    const answer = fixedBusiness()
    const deferred = reduceCell(answer, { kind: 'defer', checked: true })
    expect(deferred.cell?.entries).toEqual(answer.cell?.entries)
    expect(cellChecked(deferred)).toEqual(deferred)
    const edited = reduceCell(answer, { kind: 'change', id: 'allowance-purpose' })
    expect(reduceCell(edited, { kind: 'checked', basis: cellBasis(answer), result: cellResult(), at: 1 })).toEqual(edited)
    expect(reduceCell(deferred, { kind: 'defer', checked: false }).cell?.entries).toEqual(answer.cell?.entries)
  })
  it('asks the approved tax question for known actual monthly phone expenses, even at the business cap', () => {
    let answer = cellPick({}, 'method', 'other', "We reimburse actual monthly service costs on employees' personal cellphones needed for work. Tax intent has not been confirmed.")
    for (let i = 1; i <= 6; i++) {
      answer = cellChecked(answer, cellResult('clarify', 'payment', { question: `Which business arrangement fact ${i} applies?`, answerFormat: { kind: 'text', options: null } }))
      answer = cellPick(answer, `clarify-${i}`, 'A supplied business fact')
    }
    expect(JSON.parse(cellBasis(answer)).questionsLeft).toBe(0)
    answer = cellChecked(answer, cellResult('tax', 'payment'))
    expect(cellNext(answer)).toMatchObject({ kind: 'question', question: {
      question: 'How should this cellphone payment be treated for payroll taxes in UKG Ready?',
      options: [{ id: 'taxable' }, { id: 'nontaxable' }, { id: 'unsure' }, { id: 'other' }],
    } })
    expect(cellFlowDecision(answer)).toBeUndefined()
    answer = cellPick(answer, 'tax-payment', 'taxable')
    expect(cellFlowDecision(answer)).toMatchObject({ kind: 'describe', note: expect.stringContaining('Configuration review required') })
  })
  it('changes only dependent component answers, and Clear all answers restarts CELL', () => {
    let answer = cellPick(cellPick({}, 'method', 'both'), 'allowance-purpose', 'business')
    answer = cellPick(cellChecked(answer), 'tax-allowance', 'taxable')
    answer = cellPick(cellChecked(answer, cellResult('tax', 'reimbursement')), 'tax-reimbursement', 'nontaxable')
    const edited = reduceCell(answer, { kind: 'change', id: 'allowance-purpose' })
    expect(edited.cell?.entries.some(e => e.id === 'tax-allowance')).toBe(false)
    expect(edited.cell?.entries.some(e => e.id === 'tax-reimbursement' && e.value === 'nontaxable')).toBe(true)
    const cleared = reduceSession(cellSession(answer), { type: 'clearAnswers', itemId: CELL_ID }, 3)
    expect(cleared.answers[CELL_ID].cell).toBeUndefined()
    expect(cellNext(cleared.answers[CELL_ID])).toMatchObject({ kind: 'question', question: { id: 'method' } })
  })
})

describe('CELL readiness, replies and persistence', () => {
  it('recovers unfinished legacy stops without losing answers, but preserves applied and sent history', () => {
    const answer = cellChecked(cellPick({}, 'method', 'other', 'We repay monthly personal cellphone service needed for work.'),
      cellResult('pending', 'payment', { discovery: undefined, reason: 'Company tax intent has not been confirmed.' }))
    const open = cellSession(answer)
    const restored = parseSession(JSON.stringify(open))!
    expect(restored.answers[CELL_ID].cell?.entries).toEqual(answer.cell?.entries)
    expect(restored.answers[CELL_ID].cell?.checks).toEqual([])
    expect(cellNext(restored.answers[CELL_ID])).toEqual({ kind: 'check' })
    const sent = sentCell({ ...answer, cell: { ...answer.cell!, checks: answer.cell!.checks.map(c => ({
      ...c, result: { ...c.result, discovery: { status: 'missing', missingFact: 'Business arrangement needs review.', answerIds: ['method'] } },
    })) } })
    sent.answers[CELL_ID] = answer
    const history = parseSession(JSON.stringify({ ...sent, step: 'intro' }))!
    expect(history.answers[CELL_ID]).toEqual(answer)
    expect(history.resolutions).toEqual(sent.resolutions)
    expect(history.sent).toEqual(sent.sent)
    expect(history.customerQuestions).toEqual(sent.customerQuestions)
  })
  it('offers explicit recheck for a current pending result and preserves entries and stale protection', () => {
    const answer = cellChecked(fixedBusiness(), cellResult('pending'))
    const retried = reduceCell(answer, { kind: 'recheck' })
    expect(retried.cell?.entries).toEqual(answer.cell?.entries)
    expect(cellNext(retried)).toEqual({ kind: 'check' })
    const deferred = reduceCell(answer, { kind: 'defer', checked: true })
    expect(reduceCell(deferred, { kind: 'recheck' })).toEqual(deferred)
    expect(validCellFlow({ ...answer.cell, checks: [{ ...answer.cell!.checks[0], result: { ...answer.cell!.checks[0].result, discovery: { status: 'sufficient', missingFact: 'Tax intent', answerIds: [] } } }] })).toBe(false)
  })
  it('labels an already unanswered tax decision separately from missing business information', () => {
    const uncertain = cellPick(cellChecked(fixedBusiness()), 'tax-allowance', 'unsure')
    const pending = { ...uncertain, cell: { ...uncertain.cell!, checks: [{
      basis: cellBasis(uncertain), result: cellResult('pending', 'allowance', {
        discovery: { status: 'sufficient', missingFact: null, answerIds: ['method', 'tax-allowance'] },
        reason: 'Intended tax treatment remains unconfirmed.',
      }), at: 3, after: uncertain.cell!.entries.length,
    }] } }
    expect(paymentReadiness(pending)).toBe('Tax treatment pending')
    expect(cellFlowDecision(pending)).toEqual({ kind: 'defer' })
    expect(cellOutstanding(pending)?.id).toBe('tax-allowance')
  })
  it('pending CELL applies as deferred and all final surfaces retain facts without ready status', () => {
    const answer = cellPick(cellChecked(fixedBusiness()), 'tax-allowance', 'unsure')
    const session = sentCell(answer)
    expect(isAnswered(findItem(CELL_ID), answer)).toBe(true)
    expect(session.resolutions[CELL_ID].status).toBe('customer')
    expect(finalConfiguration(session).find(row => row.code === 'CELL')).toMatchObject({ status: 'customer' })
    expect(summaryCsv(session, String)).toMatch(/CELL tax setup is not complete/)
    const question = customerQuestionList(session).find(q => q.codes.includes('CELL'))!
    expect(question.id).toBe('classification:CELL-v2-tax-allowance-r0')
    expect(question.question).toContain('payroll taxes in UKG Ready')
    const draft = customerDraftRequest(session, CELL_ID)
    expect(draft.earlierAnswers.some(e => e.answer.includes('Not sure'))).toBe(true)
    expect(draft.standardQuestion).not.toMatch(/split CELL/)
    expect(JSON.stringify(bryteFacts(session))).toMatch(/CELL setup is not complete/)
  })
  it('customer reply resumes exactly the outstanding tax question and preserves sent words and saved replies', () => {
    const pending = cellPick(cellChecked(fixedBusiness()), 'tax-allowance', 'unsure')
    const session = sentCell(pending)
    const question = customerQuestionList(session).find(q => q.codes.includes('CELL'))!
    const reply = cellPick({ ...pending, cell: { ...pending.cell!, deferred: cellOutstanding(pending) } }, 'tax-allowance', 'taxable')
    const saved = reduceSession(session, { type: 'saveCustomerReply', questionId: question.id, answer: reply }, 60)
    expect(saved.resolutions[CELL_ID].status).toBe('review')
    expect(saved.sent).toEqual(session.sent)
    expect(saved.customerReplies?.[question.id].answer).toEqual(reply)
    expect(reduceSession(saved, { type: 'saveCustomerReply', questionId: question.id, answer: readyCell('nontaxable') }, 61)).toEqual(saved)
    const restored = parseSession(JSON.stringify({ ...saved, step: 'intro' }))
    expect(restored?.customerReplies).toEqual(saved.customerReplies)
  })
  it('does not save a reply that rewrites an earlier locked business answer', () => {
    const pending = cellPick(cellChecked(fixedBusiness()), 'tax-allowance', 'unsure')
    const session = sentCell(pending)
    const id = customerQuestionList(session).find(q => q.codes.includes('CELL'))!.id
    const changed = readyCell()
    changed.cell!.entries[1].answer = 'Changed earlier answer'
    expect(reduceSession(session, { type: 'saveCustomerReply', questionId: id, answer: changed }, 80)).toEqual(session)
  })
  it('round-trips current unfinished facts and rejects malformed optional CELL state', () => {
    const answer = cellChecked(fixedBusiness())
    const session = cellSession(answer)
    expect(parseSession(JSON.stringify(session))?.answers[CELL_ID]).toEqual(answer)
    expect(validCellFlow({ version: 2, entries: 'bad', checks: [] })).toBe(false)
    expect(validCellFlow({ ...answer.cell, replyRound: '1' })).toBe(false)
    expect(parseSession(JSON.stringify({ ...session, answers: { [CELL_ID]: { cell: { version: 2, entries: 'bad' } } } }))).toBeNull()
  })
  it('migrates only open legacy CELL, retaining old facts but not automatic tax decisions', () => {
    const old = { choice: 'allowance', followUps: { treatment: 'taxable', split: 'confirm' } }
    const migrated = migrateCellFlow(cellSession(old))
    expect(migrated.answers[CELL_ID].cell?.earlier).toEqual(old)
    expect(migrated.answers[CELL_ID].cell?.entries.map(e => e.id)).toEqual(['method'])
    expect(cellNext(migrated.answers[CELL_ID])).toMatchObject({ kind: 'question', question: { id: 'allowance-purpose' } })
    expect(cellDecision(migrated.answers[CELL_ID])).toBeUndefined()
  })
  it('keeps earlier applied CELL decisions, sent wording and replies as history, not new confirmation', () => {
    const old = { choice: 'allowance' }
    const session = { ...cellSession(old), rounds: [{ number: 1, itemIds: [CELL_ID], submitted: true }],
      resolutions: { [CELL_ID]: { status: 'resolved' as const, reference: READY.cellAllowance, round: 1 } } }
    const migrated = migrateCellFlow(session)
    expect(migrated.answers[CELL_ID].cellLegacy).toBe(true)
    expect(migrated.answers[CELL_ID].cell).toBeUndefined()
    expect(migrated.resolutions).toEqual(session.resolutions)
    expect(migrated.rounds).toEqual(session.rounds)
    expect(cellDecision(migrated.answers[CELL_ID])).toMatchObject({ kind: 'resolve', reference: READY.cellAllowance })
    expect(parseSession(JSON.stringify({ ...session, step: 'intro' }))?.resolutions).toEqual(session.resolutions)
  })
  it('does not reopen an applied pre-payment-method CELL decision', () => {
    const original = { status: 'resolved' as const, round: 1, reference: { ...READY.cellAllowance, name: 'Earlier cellphone reference name' } }
    const saved = { ...cellSession(), version: 4, step: 'intro', answers: { CELL: { choice: 'accept' } },
      rounds: [{ number: 1, itemIds: ['CELL'], submitted: true }], resolutions: { CELL: original } }
    const restored = parseSession(JSON.stringify(saved))!
    expect(restored).not.toBeNull()
    expect(restored.legacyCell?.resolution).toEqual(original)
    expect(restored.rounds.some(r => r.itemIds.includes(CELL_ID))).toBe(false)
    expect(finalConfiguration(restored).find(r => r.code === 'CELL')).toMatchObject({ status: 'ready', reference: original.reference })
  })
  it('does not accept nontaxable intent for an apparent compensatory Something else without clarification', () => {
    let answer = cellPick({}, 'method', 'other', 'We pay a cellphone bonus as additional compensation.')
    answer = cellChecked(answer, cellResult('tax', 'payment'))
    answer = cellPick(answer, 'tax-payment', 'nontaxable')
    expect(cellNext(answer).kind).toBe('check')
    expect(cellDecision(answer)).toBeUndefined()
    answer = cellChecked(answer, cellResult('pending', 'payment'))
    expect(cellDecision(answer)?.kind).toBe('describe')
  })
  it('keeps a Not sure reply read-only under its own identity while the next tax question stays outstanding', () => {
    const answer = cellPick(cellChecked(fixedBusiness()), 'tax-allowance', 'unsure')
    const state = sentCell(answer)
    const question = customerQuestionList(state).find(q => q.codes.includes('CELL'))!
    const draft = reduceCell({ ...answer, cell: { ...answer.cell!, deferred: cellOutstanding(answer) } },
      { kind: 'answer', id: 'tax-allowance', value: 'unsure' })
    const saved = reduceSession(state, { type: 'saveCustomerReply', questionId: question.id, answer: draft }, 90)
    expect(saved.resolutions[CELL_ID].status).toBe('customer')
    expect(saved.customerReplies?.[question.id].answer).toEqual(draft)
    expect(customerQuestionList(saved).find(q => q.codes.includes('CELL') && q.status === 'open')?.id).not.toBe(question.id)
    expect(parseSession(JSON.stringify({ ...saved, step: 'intro' }))?.customerReplies).toEqual(saved.customerReplies)
  })
})
