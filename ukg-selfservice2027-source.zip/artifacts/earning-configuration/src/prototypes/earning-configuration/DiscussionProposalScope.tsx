import { useMemo, type ReactNode } from 'react'
import { SessionContext, useEarningSession, type SessionContextValue } from './sessionContext'
import { previewWorkSession } from './deferredReview'
import { DiscussionWorkDraftContext } from './discussionWorkDraft'
import { ProposalAssessmentContext } from './proposalAssessment'

/** All callbacks carry the proposal identity captured at mount, including late network responses. */
export default function DiscussionProposalScope({ children }: { children: ReactNode }) {
  const outer = useEarningSession()
  const { session, dispatch } = outer
  const work = previewWorkSession(session)
  const preview = session.discussionPreview
  const identity = preview?.identity
  const scope = useMemo<SessionContextValue | null>(() => work ? {
    ...outer, session: work,
    dispatch: action => dispatch({ type: 'editDiscussionWork', identity, action }),
  } : null, [outer, work, identity, dispatch])
  if (!scope || !preview) return null
  return <SessionContext.Provider value={scope}>
    <ProposalAssessmentContext.Provider value={{
      checks: preview.checks ?? {},
      change: (key, check) => dispatch({ type: 'setDiscussionCheck', identity, key, check }),
    }}>
      <DiscussionWorkDraftContext.Provider value={{
        values: preview.drafts ?? {},
        change: (key, value) => dispatch({ type: 'setDiscussionWorkDraft', identity, key, value }),
      }}>{children}</DiscussionWorkDraftContext.Provider>
    </ProposalAssessmentContext.Provider>
  </SessionContext.Provider>
}
