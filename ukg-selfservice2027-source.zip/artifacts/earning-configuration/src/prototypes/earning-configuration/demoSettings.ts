/**
 * Temporary demo settings for Earning Configuration.
 *
 * `ungateForwardButtons`: while true, Next and the other forward buttons stay clickable at all times, so presenters can
 * move through the flow without answering every question or waiting for a step to finish. It covers upload (Next with
 * nothing uploaded loads the sample pay register), the analysis and recheck continue buttons, every page of the
 * bundled original review (including follow-ups), Optimization, and overtime. A separate Continue to optimization
 * action bypasses unfinished review work without applying it. Incomplete Optimization stays editable.
 * This navigation exception never applies to the real uploaded-register review.
 * Apply answers and genuine setup readiness stay gated independently. The separate hideOptionalQuestions policy
 * allows only MISC7, MILEAGE and IMP INC groups in the bundled demo to remain unresolved.
 *
 * Set both options to false to bring back all cards and normal gating.
 */
export const EARNING_DEMO_SETTINGS = {
  ungateForwardButtons: true,
  /** Only the bundled categorized review: hide three optional source groups, without changing their eligibility. */
  hideOptionalQuestions: true,
}

/** Whether forward buttons skip their usual progress checks for the demo. */
export const forwardButtonsUngated = () => EARNING_DEMO_SETTINGS.ungateForwardButtons
