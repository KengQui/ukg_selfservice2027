import { act, useReducer } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { checkEarningDescription, suggestEarningName, reviewEarningAnswer } from '@workspace/api-client-react'
import { SessionContext } from './sessionContext'
import StepDiscussionReview from './StepDiscussionReview'
import DiscussionAcknowledgment from './DiscussionAcknowledgment'
import AppliedAnswerHistory from './AppliedAnswerHistory'
import { deferredProposalFixture } from './deferredProposal.testing'
import { previewCanApply, previewItems, previewWorkSession, discussionEntries } from './deferredReview'
import { ACCEPT_NAME, CHECK_QUESTION_LIMIT, parseSession, reduceSession, type EarningSession, type SessionAction } from './session'
import { saveSession, loadSession } from './storage'
import { findItem, ASK_CUSTOMER, READY } from './sampleRegister'
import { createSession } from './session'
import { SOMETHING_ELSE } from './somethingElse'

vi.mock('@workspace/api-client-react', () => ({
  checkEarningDescription: vi.fn(), suggestEarningName: vi.fn(), reviewEarningAnswer: vi.fn(), reviewShiftPremium: vi.fn(), reviewCellPayment: vi.fn(),
}))
const check = vi.mocked(checkEarningDescription)
const name = vi.mocked(suggestEarningName)
const noMatch = { outcome: 'noMatch' as const, reason: 'No supplied reference fits project leadership pay.',
  referenceId: null, followUpId: null, question: null, answerFormat: null }
const suggestion = { outcome: 'suggestion' as const, name: 'Project lead', rationale: 'Describes temporary project leadership pay.', question: null }
let host: HTMLDivElement
let root: Root
let current: EarningSession
let send: (action: SessionAction) => void
function Harness({ initial }: { initial: EarningSession }) {
  const [session, dispatch] = useReducer((state: EarningSession, action: SessionAction) => reduceSession(state, action, state.updatedAt + 1), initial)
  current = session
  send = dispatch
  return <SessionContext.Provider value={{ session, dispatch, save: () => true, restart: () => true }}>
    {session.step === 'discussionReview' ? <StepDiscussionReview /> : <><DiscussionAcknowledgment /><AppliedAnswerHistory /></>}
  </SessionContext.Provider>
}
const mount = async (session = deferredProposalFixture()) => { await act(async () => root.render(<Harness initial={session} />)) }
const click = async (label: string) => {
  const button = [...host.querySelectorAll<HTMLButtonElement>('button')].find(button => button.textContent?.trim() === label)
  expect(button, `button ${label}`).toBeTruthy()
  await act(async () => button!.click())
}
const edit = async (action: SessionAction) => act(async () => send({ type: 'editDiscussionWork', identity: current.discussionPreview?.identity, action }))
beforeEach(() => {
  (globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
  vi.clearAllMocks()
  check.mockResolvedValue(noMatch)
  name.mockResolvedValue(suggestion)
  host = document.createElement('div')
  document.body.appendChild(host)
  root = createRoot(host)
})
afterEach(() => { act(() => root.unmount()); host.remove(); vi.useRealTimers() })
const store = () => {
  const entries = new Map<string, string>()
  return { getItem: (key: string) => entries.get(key) ?? null, setItem: (key: string, value: string) => { entries.set(key, value) },
    removeItem: (key: string) => { entries.delete(key) } }
}

describe('isolated deferred answer assessment', () => {
  it('keeps keep/remove explicit and does not report a blocked naming check before that choice', async () => {
    await mount(deferredProposalFixture('ADJ2'))
    expect(name).not.toHaveBeenCalled()
    expect(previewItems(current)[0].assessment.status).toBe('confirmation')
    expect(previewItems(current)[0].outcome).toContain('keep or remove')
    await edit({ type: 'chooseRetention', itemId: 'ADJ2', choice: 'remove' })
    expect(previewCanApply(current)).toBe(true)
    await click('Apply answers')
    expect(current.resolutions.ADJ2.status).toBe('removed')
    expect(host.textContent).toContain('Earlier payroll activity is unchanged')
  })

  it('never accepts a live reference match for the user', async () => {
    check.mockResolvedValue({ ...noMatch, outcome: 'reference', referenceId: READY.retro.id, reason: 'Corrects earlier pay.' })
    await mount()
    expect(previewItems(current)[0].assessment.status).toBe('confirmation')
    expect(name).not.toHaveBeenCalled()
    expect(previewCanApply(current)).toBe(false)
    await edit({ type: 'choose', itemId: 'SPPAY', choice: 'accept' })
    expect(previewCanApply(current)).toBe(true)
    expect(previewItems(current)[0].outcome).toContain('Retroactive pay')
  })
  it('retains a typed-answer review thread and unsent reply through Back and reload', async () => {
    vi.useFakeTimers()
    const item = findItem('TIPS')
    if (item.type !== 'clarification') throw new Error('fixture')
    let initial: EarningSession = { ...createSession(1), step: 'questions', rounds: [{ number: 1, itemIds: ['TIPS'], submitted: false }] }
    const options = [...item.options.map(o => ({ id: o.id, label: o.label })), { id: SOMETHING_ELSE, label: 'Something else', details: true }]
    for (const action of [
      { type: 'choose', itemId: item.id, choice: ASK_CUSTOMER },
      { type: 'selectDeferredQuestion', itemId: item.id, source: { question: item.question, options, choices: options.map(o => o.label) } },
      { type: 'submitRound' },
    ] as SessionAction[]) initial = reduceSession(initial, action, 2)
    const entry = discussionEntries(initial)[0]
    for (const change of [{ choice: SOMETHING_ELSE }, { choice: SOMETHING_ELSE, detail: 'Tips are shared after each shift.' }])
      initial = reduceSession(initial, { type: 'setDiscussionAnswer', itemId: item.id, question: entry.question, basis: entry.basis, kind: 'review-choices', change }, 3)
    initial = reduceSession(initial, { type: 'prepareDiscussionReview' }, 4)
    vi.mocked(reviewEarningAnswer).mockResolvedValueOnce({
      outcome: 'followUp', reason: 'The distribution method is unclear.', suggestion: 'Explain who distributes tips.',
      question: 'Who distributes the tips?', conflictingFact: null,
    }).mockResolvedValue({ outcome: 'confirm', reason: 'The business practice is clear.', suggestion: 'Keep the explanation for setup review.',
      question: null, conflictingFact: null })
    await mount(initial)
    await act(async () => { await vi.advanceTimersByTimeAsync(500) })
    expect(previewItems(current)[0].assessment.status).toBe('missing')
    const textarea = host.querySelector<HTMLTextAreaElement>('.ec-answer-review textarea')!
    await act(async () => {
      Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')!.set!.call(textarea, 'The company distributes them.')
      textarea.dispatchEvent(new Event('input', { bubbles: true }))
    })
    const restored = parseSession(JSON.stringify(current))!
    act(() => root.unmount())
    root = createRoot(host)
    await mount(restored)
    expect(host.querySelector<HTMLTextAreaElement>('.ec-answer-review textarea')!.value).toBe('The company distributes them.')
    await click('Send')
    await act(async () => { await vi.advanceTimersByTimeAsync(500) })
    expect(vi.mocked(reviewEarningAnswer).mock.calls.at(-1)![0].thread?.[0].reply).toBe('The company distributes them.')
    expect(previewItems(current)[0].assessment.status).toBe('specialist')
    expect(previewCanApply(current)).toBe(false) // A successful answer review is not a confirmed payroll mapping.
    vi.useRealTimers()
  })

  it('blocks a mixed batch until every supported decision is explicitly confirmed', async () => {
    const typed = deferredProposalFixture()
    const fixed = deferredProposalFixture('BONREV')
    let mixed: EarningSession = { ...typed, discussionPreview: undefined,
      answers: { ...typed.answers, ...fixed.answers }, resolutions: { ...typed.resolutions, ...fixed.resolutions },
      rounds: [{ ...typed.rounds[0], itemIds: ['SPPAY', 'BONREV'] }],
      discussionAnswers: { ...typed.discussionAnswers, ...fixed.discussionAnswers } }
    mixed = reduceSession(mixed, { type: 'prepareDiscussionReview' }, 8)
    await mount(mixed)
    expect(previewItems(current).find(item => item.itemId === 'BONREV')?.ready).toBe(true)
    expect(previewCanApply(current)).toBe(false)
    await act(async () => send({ type: 'applyDiscussionReview' }))
    expect(current.discussionApplications).toBeUndefined()
    await edit({ type: 'choose', itemId: 'SPPAY', choice: ACCEPT_NAME })
    expect(previewCanApply(current)).toBe(true)
    await click('Apply answers')
    expect(Object.keys(current.discussionApplications![0].outcomes).sort()).toEqual(['BONREV', 'SPPAY'])
  })
  it('checks on preview entry, requires explicit name acceptance, applies once and shows receipt consequences', async () => {
    const initial = deferredProposalFixture()
    await mount(initial)
    expect(check).toHaveBeenCalledTimes(1)
    expect(name).toHaveBeenCalledTimes(1)
    expect(current.resolutions).toEqual(initial.resolutions)
    expect(host.querySelector<HTMLTextAreaElement>('.ec-describe textarea')?.readOnly).toBe(true)
    expect(previewItems(current)[0].assessment.status).toBe('confirmation')
    expect(previewCanApply(current)).toBe(false)
    await edit({ type: 'choose', itemId: 'SPPAY', choice: ACCEPT_NAME })
    expect(previewCanApply(current)).toBe(true)
    expect(host.textContent).toContain('No Ready reference, tax treatment or overtime rule is confirmed')
    await click('Apply answers')
    expect(current.discussionApplications).toHaveLength(1)
    expect(discussionEntries(current)).toEqual([])
    expect(host.textContent).toContain('Answers applied')
    expect(host.textContent).toContain('Accepted Project lead')
    expect(host.textContent).toContain(initial.discussionAnswers!.SPPAY[Object.keys(initial.discussionAnswers!.SPPAY)[0]].question)
    await act(async () => send({ type: 'applyDiscussionReview' }))
    expect(current.discussionApplications).toHaveLength(1)
  })

  it('does not call AI for an authored choice', async () => {
    await mount(deferredProposalFixture('BONREV'))
    expect(check).not.toHaveBeenCalled()
    expect(name).not.toHaveBeenCalled()
    expect(previewCanApply(current)).toBe(true)
  })

  it('keeps a technical failure distinct, retains it over save/reopen and retries explicitly', async () => {
    check.mockRejectedValueOnce({ data: { code: 'unavailable', error: 'We can’t check this answer right now.' } })
    await mount()
    expect(previewItems(current)[0].assessment.status).toBe('problem')
    expect(host.textContent).not.toContain('Needs more answers')
    const stores = { working: store(), saved: store() }
    expect(saveSession(stores, current)).toBe(true)
    const restored = loadSession({ working: store(), saved: stores.saved })
    act(() => root.unmount())
    root = createRoot(host)
    await mount(restored)
    expect(check).toHaveBeenCalledTimes(1)
    await click('Try again')
    expect(check).toHaveBeenCalledTimes(2)
    expect(previewItems(current)[0].assessment.status).toBe('confirmation')
  })

  it('asks only the missing detail, preserves the earlier reply and rechecks the complete conversation', async () => {
    check.mockResolvedValueOnce({ ...noMatch, outcome: 'needsInformation', question: 'Which work receives the additional pay?',
      answerFormat: { kind: 'choices', options: ['Project leadership', 'Evening shifts'] } })
    await mount()
    expect(previewItems(current)[0].assessment.status).toBe('missing')
    expect(host.textContent).toContain('Which work receives the additional pay?')
    await edit({ type: 'answerCheckQuestion', itemId: 'SPPAY', answer: 'Project leadership' })
    expect(check).toHaveBeenCalledTimes(2)
    expect(check.mock.calls[1][0].answers).toContainEqual({ question: 'Which work receives the additional pay?', answer: 'Project leadership' })
    expect(previewWorkSession(current)!.answers.SPPAY.description).toBe('Extra pay for temporary project leadership')
    expect(previewItems(current)[0].assessment.status).toBe('confirmation')
    await edit({ type: 'choose', itemId: 'SPPAY', choice: ACCEPT_NAME })
    await click('Apply answers')
    expect(current.discussionApplications![0].confirmedAnswers!.SPPAY).toContainEqual({
      question: 'Which work receives the additional pay?', answer: 'Project leadership',
    })
    expect(host.textContent).toContain('Which work receives the additional pay?')
  })

  it('continues a naming follow-up without editing or losing the opening description', async () => {
    name.mockResolvedValueOnce({ outcome: 'needsInformation', name: null, rationale: null, question: 'What responsibility earns the extra pay?' })
    await mount()
    expect(previewItems(current)[0].assessment.status).toBe('missing')
    await edit({ type: 'answerCheckQuestion', itemId: 'SPPAY', answer: 'Leading a temporary project team' })
    expect(check.mock.calls[1][0].answers).toContainEqual({ question: 'What responsibility earns the extra pay?', answer: 'Leading a temporary project team' })
    expect(name).toHaveBeenCalledTimes(2)
  })

  it('blocks a bounded unresolved conversation without inventing an assignment or another answer', async () => {
    check.mockResolvedValue({ ...noMatch, outcome: 'needsInformation', question: 'What purpose is still unconfirmed?', answerFormat: { kind: 'text', options: null } })
    await mount()
    for (let index = 0; index < CHECK_QUESTION_LIMIT; index++) await edit({ type: 'answerCheckQuestion', itemId: 'SPPAY', answer: `Additional fact ${index}` })
    expect(previewItems(current)[0].assessment.status).toBe('specialist')
    expect(previewCanApply(current)).toBe(false)
    expect(host.textContent).toContain('Save and finish later')
    expect(host.textContent).toContain('no one has been notified or assigned')
    expect(parseSession(JSON.stringify(current))!.discussionPreview!.answers.SPPAY.checkAnswers).toHaveLength(CHECK_QUESTION_LIMIT)
  })

  it('rejects results from another proposal identity even with identical input', async () => {
    check.mockImplementation(() => new Promise(() => {}))
    await mount()
    const before = current
    await act(async () => send({ type: 'editDiscussionWork', identity: 'another-company-proposal',
      action: { type: 'checkDescription', itemId: 'SPPAY', basis: 'unused', result: { kind: 'noMatch', reason: 'wrong result' } } }))
    expect(current).toBe(before)
    expect(previewItems(current)[0].assessment.status).toBe('checking')
    expect(previewCanApply(current)).toBe(false)
  })

  it('reports an unusable result as a retry problem, never as a missing answer or approved match', async () => {
    check.mockResolvedValue({ ...noMatch, outcome: 'reference', referenceId: 'not-a-supplied-reference', reason: 'Unusable fixture.' })
    await mount()
    expect(previewItems(current)[0].assessment.status).toBe('problem')
    expect(previewCanApply(current)).toBe(false)
    expect(host.textContent).toContain('Try again')
    expect(name).not.toHaveBeenCalled()
  })

  it.each(['retry', 'defer'] as const)('keeps a captured SPPAY reply intact through the naming error %s action', async action => {
    name.mockRejectedValueOnce({ status: 502, data: { code: 'unavailable', error: 'We can’t suggest a name right now.' } })
    await mount()
    const description = previewWorkSession(current)!.answers.SPPAY.description
    const assertKept = () => {
      const answer = previewWorkSession(current)!.answers.SPPAY
      expect(answer.description).toBe(description)
      expect(answer.descriptionSubmitted).toBe(true)
      expect(host.querySelector<HTMLTextAreaElement>('.ec-describe textarea')?.readOnly).toBe(true)
      expect(host.textContent).not.toContain('Edit description')
      expect(host.textContent).not.toContain('Clear all answers')
    }
    assertKept()
    expect(previewItems(current)[0].assessment.status).toBe('problem')
    expect(previewCanApply(current)).toBe(false)
    expect([...host.querySelectorAll('.ec-naming__actions button')].map(button => button.textContent?.trim())).toEqual(['Try again'])
    if (action === 'retry') {
      const stores = { working: store(), saved: store() }
      expect(saveSession(stores, current)).toBe(true)
      act(() => root.unmount())
      root = createRoot(host)
      await mount(loadSession({ working: store(), saved: stores.saved }))
      assertKept()
      expect(name).toHaveBeenCalledTimes(1)
      await click('Try again')
      assertKept()
      expect(check).toHaveBeenCalledTimes(1)
      expect(name).toHaveBeenCalledTimes(2)
      expect(name.mock.calls[1][0]).toEqual(name.mock.calls[0][0])
      expect(previewItems(current)[0].assessment.status).toBe('confirmation')
      await edit({ type: 'choose', itemId: 'SPPAY', choice: ACCEPT_NAME })
      expect(previewCanApply(current)).toBe(true)
    } else {
      const label = host.querySelector<HTMLLabelElement>('.ec-defer label')!
      await act(async () => label.click())
      assertKept()
      expect(previewItems(current)[0].assessment.status).toBe('deferred')
      expect(current.discussionApplications).toBeUndefined()
      expect(current.discussionPreview!.answers.SPPAY.explicitDeferral?.question).toBe('What should we call Special Pay?')
    }
  })

  it('ignores a late response after the captured reply is changed and a new proposal opens', async () => {
    let finish: (value: typeof noMatch) => void = () => {}
    check.mockImplementationOnce(() => new Promise(resolve => { finish = resolve }))
    await mount()
    const oldIdentity = current.discussionPreview!.identity
    const entry = discussionEntries(current)[0]
    await act(async () => {
      send({ type: 'setDiscussionAnswer', itemId: entry.itemId, question: entry.question, basis: entry.basis, kind: 'text',
        change: { text: 'A different temporary project leadership payment' } })
      send({ type: 'prepareDiscussionReview' })
    })
    expect(current.discussionPreview!.identity).not.toBe(oldIdentity)
    expect(check.mock.calls[0][1]?.signal?.aborted).toBe(true)
    await act(async () => finish({ ...noMatch, reason: 'STALE RESULT' }))
    expect(JSON.stringify(current)).not.toContain('STALE RESULT')
    expect(previewWorkSession(current)!.answers.SPPAY.description).toBe('A different temporary project leadership payment')
  })
})
