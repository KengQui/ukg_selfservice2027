import type { EarningCustomerAnswerKind } from '@workspace/api-client-react'

export type DiscussionKind = EarningCustomerAnswerKind | 'confirmation' | 'review-choices'
export interface DiscussionOption { id: string; label: string; details?: boolean }
const other: DiscussionOption = { id: 'other', label: 'Something else', details: true }
const unsure: DiscussionOption = { id: 'unsure', label: 'Not sure yet' }
export const DISCUSSION_OPTIONS: Record<DiscussionKind, readonly DiscussionOption[]> = {
  text: [],
  'review-choices': [],
  'phone-method': [
    { id: 'set-amount', label: 'We pay a set amount, regardless of phone costs' },
    { id: 'payback', label: 'We pay people back for business phone costs' },
    { id: 'both', label: 'We do both' }, other, unsure,
  ],
  'phone-tax': [
    { id: 'taxed', label: 'Taxed as pay' },
    { id: 'tax-free', label: 'Tax-free—confirmed by our payroll or tax adviser' }, other, unsure,
  ],
  'special-pay': [
    { id: 'shift', label: 'Extra pay for working a shift' },
    { id: 'correction', label: 'A correction to pay from an earlier period' }, other, unsure,
  ],
  'adjustment-basis': [
    { id: 'flat', label: 'A flat amount' },
    { id: 'hourly', label: 'An hourly rate' },
    { id: 'both', label: 'Both, depending on the payment' }, other, unsure,
  ],
  'adjustment-frequency': [
    { id: 'once', label: 'A one-time payment' },
    { id: 'recurring', label: 'A recurring payment' },
    { id: 'both', label: 'Both, depending on the situation' }, other, unsure,
  ],
  confirmation: [
    { id: 'yes', label: 'Yes, that’s right' },
    { id: 'partly', label: 'Partly—some details need to change', details: true },
    { id: 'no', label: 'No—that’s not how we use it', details: true }, unsure,
  ],
}

export const isDiscussionKind = (value: unknown): value is DiscussionKind =>
  typeof value === 'string' && Object.hasOwn(DISCUSSION_OPTIONS, value)

export function validAnswerKinds(value: unknown, count: number): value is EarningCustomerAnswerKind[] {
  return Array.isArray(value) && value.length === count
    && value.every(kind => kind !== 'confirmation' && kind !== 'review-choices' && isDiscussionKind(kind))
}

/** Discussion-only data: never an ItemAnswer or a customer reply that settles payroll setup. */
export interface DiscussionAnswer {
  question: string
  kind: DiscussionKind
  choice?: string
  text?: string
  details?: Record<string, string>
  /** Frozen labels retain what a selected response meant when the question was answered. */
  options?: DiscussionOption[]
}
export type DiscussionAnswers = Record<string, Record<string, DiscussionAnswer>>

export function validDiscussionAnswer(value: unknown): value is DiscussionAnswer {
  if (!value || typeof value !== 'object') return false
  const entry = value as DiscussionAnswer
  const options = entry.kind === 'review-choices' ? entry.options : DISCUSSION_OPTIONS[entry.kind]
  if (!Array.isArray(options) || (entry.kind === 'review-choices' && (!options.length || options.length > 20
    || options.some(option => !option || typeof option.id !== 'string' || !option.id.trim()
      || typeof option.label !== 'string' || !option.label.trim()
      || (option.details !== undefined && typeof option.details !== 'boolean'))
    || new Set(options.map(option => option.id)).size !== options.length))) return false
  return typeof entry.question === 'string' && !!entry.question.trim() && isDiscussionKind(entry.kind)
    && (entry.choice === undefined || options.some(option => option.id === entry.choice))
    && (entry.text === undefined || typeof entry.text === 'string')
    && (entry.details === undefined || !!entry.details && typeof entry.details === 'object' && !Array.isArray(entry.details)
      && Object.entries(entry.details).every(([id, text]) => typeof text === 'string'
        && options.some(option => option.id === id && option.details)))
}
