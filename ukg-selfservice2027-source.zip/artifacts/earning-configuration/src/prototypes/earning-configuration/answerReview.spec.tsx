import { afterEach, describe, expect, it, vi } from 'vitest'
import { act, StrictMode, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { requestAnswerReview, reviewRequest } from './answerReview'
import AnswerReview, { AnswerReviewProvider } from './AnswerReview'
import { answerReviewBasis, PLAN_LATER_QUESTION, validAnswerReview } from './answerReviewData'
import { AskBrytePage, AskBryteProvider } from '@workspace/setup-shared/ask-bryte'
import { createSession, reduceSession, parseSession, decisionFor, activeCheck, pendingCheckBasis, reviewPages, type SessionAction } from './session'
import { ASK_CUSTOMER, DESCRIBE_CHOICE, PLAN_INITIAL_ITEMS, REVIEW_INITIAL_ITEMS, findItem } from './sampleRegister'
import { typedAnswerFor } from './answerReviewScope'
import { bryteFacts } from './bryteFacts'
import { sharedSetupFor } from './session'
import { finalConfiguration } from './configuration'
import { summaryCsv } from './summary'
import { reviewCodeStatus } from './reviewStatus'
import { withShiftRegister } from './shiftRegister.testing'
import { CELL_ID } from './cell'

withShiftRegister()

vi.mock('@workspace/api-client-react', () => ({ reviewEarningAnswer: vi.fn(), checkEarningDescription: vi.fn() }))
import { reviewEarningAnswer } from '@workspace/api-client-react'
const confirm = { outcome: 'confirm' as const, reason: 'This fits the payment purpose.', suggestion: 'We’ll set up SPPAY as weekend shift pay.', question: null, conflictingFact: null }
const started = (): ReturnType<typeof createSession> => ({ ...reduceSession(createSession(), { type: 'startReview' }), reviewCursor: 1 })
/** CELL's Something else still needs the general typed-answer review. */
const SOMETHING_ELSE = [{ id: DESCRIBE_CHOICE, title: 'Something else' }]
/** Typed and Done: a typed answer is reviewed only after Done. */
const typedSppay = (description = 'Extra pay for weekend shifts') =>
  reduceSession(reduceSession(started(), { type: 'describe', itemId: 'SPPAY', description }), { type: 'submitDescription', itemId: 'SPPAY' })
const typedCell = (description = 'We pay both an allowance and business phone expenses'): ReturnType<typeof createSession> => {
  const session = [
    { type: 'choose', itemId: CELL_ID, choice: DESCRIBE_CHOICE } as const,
    { type: 'describe', itemId: CELL_ID, description } as const,
    { type: 'submitDescription', itemId: CELL_ID } as const,
  ].reduce((session, action) => reduceSession(session, action), started())
  return { ...session, reviewCursor: reviewPages(session).findIndex(page => page.includes(CELL_ID)) }
}

afterEach(() => { vi.resetAllMocks(); vi.useRealTimers() })

describe('answer review state and requests', () => {
  it('persists results for their answer basis and ignores a stale response', () => {
    let session = reduceSession(started(), { type: 'choose', itemId: 'SPPAY', choice: 'retro' })
    const basis = answerReviewBasis(session.answers.SPPAY)
    session = reduceSession(session, { type: 'answerReview', itemId: 'SPPAY', key: 'question', review: { basis, result: confirm } })
    expect(parseSession(JSON.stringify(session))?.answers.SPPAY.reviews?.question.result).toEqual(confirm)
    session = reduceSession(session, { type: 'choose', itemId: 'SPPAY', choice: 'shift' })
    const before = session.answers.SPPAY
    session = reduceSession(session, { type: 'answerReview', itemId: 'SPPAY', key: 'question', review: { basis, result: confirm } })
    expect(session.answers.SPPAY).toEqual(before)
  })
  it('recognizes notNeeded description checks without offering a custom name, and reuses removal semantics', () => {
    let session = reduceSession(started(), { type: 'describe', itemId: 'SPPAY', description: 'this is an old code we no longer use' })
    session = reduceSession(session, { type: 'submitDescription', itemId: 'SPPAY' })
    const item = findItem('SPPAY')
    const basis = pendingCheckBasis(item, session.answers.SPPAY)!
    session = reduceSession(session, { type: 'checkDescription', itemId: item.id, basis, result: { kind: 'notNeeded', reason: 'You no longer use this code.' } })
    expect(activeCheck(item, session.answers.SPPAY)?.kind).toBe('notNeeded')
    expect(parseSession(JSON.stringify(session))?.answers.SPPAY.check?.result.kind).toBe('notNeeded')
    session = reduceSession(session, { type: 'omitCode', itemId: item.id, remove: true })
    expect(decisionFor(item, session.answers.SPPAY)).toEqual({ kind: 'remove' })
    expect(parseSession(JSON.stringify(session))?.answers.SPPAY.retain).toBe('remove')
    session = reduceSession(session, { type: 'omitCode', itemId: item.id, remove: false })
    expect(decisionFor(item, session.answers.SPPAY)).toBeUndefined()
  })
  it('redacts typed answers before sending and includes register facts', () => {
    const input = reviewRequest(findItem('SPPAY'), { description: 'owner@example.com no longer uses this code' }, 'Purpose?', 'Something else', 'Describe this payment')
    expect(JSON.stringify(input)).not.toContain('owner@example.com')
    expect(input.facts.amount).not.toBeNull()
  })
  it('uses Not set up in summary and existing answered status for an omitted SPPAY', () => {
    let session = reduceSession(started(), { type: 'omitCode', itemId: 'SPPAY', remove: true })
    expect(reviewCodeStatus(findItem('SPPAY'), session.answers.SPPAY)).toBe('answered')
    for (const item of REVIEW_INITIAL_ITEMS.filter(item => item.id !== 'SPPAY')) {
      session = reduceSession(session, { type: 'choose', itemId: item.id, choice: item.id === 'BONREV' ? 'accept' : ASK_CUSTOMER })
    }
    session = reduceSession(session, { type: 'submitRound' })
    expect(session.resolutions.SPPAY?.status).toBe('removed')
    expect(finalConfiguration(session).find(row => row.code === 'Special Pay')?.status).toBe('notSetUp')
    expect(summaryCsv(session, () => 'Today').split('\r\n').find(line => line.startsWith('"Code","Special Pay"'))).toContain('Not set up')
    expect(session.customerQuestions.some(question => question.code === 'Special Pay')).toBe(false)
  })
  it('shows only documented server error messages', async () => {
    const input = reviewRequest(findItem('SPPAY'), {}, 'Purpose?', 'Something else', '')
    vi.mocked(reviewEarningAnswer).mockRejectedValueOnce({ data: { code: 'unavailable', error: 'We can’t review this right now.' } })
    expect(await requestAnswerReview(input, new AbortController().signal)).toEqual({ ok: false, message: 'We can’t review this right now.' })
    vi.mocked(reviewEarningAnswer).mockRejectedValueOnce({ data: { error: 'Internal details' } })
    expect((await requestAnswerReview(input, new AbortController().signal)).ok).toBe(false)
  })
  it('reviews typed answers under StrictMode, cancels changed answers and skips Defer', async () => {
    vi.useFakeTimers()
    ;(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
    const host = document.createElement('div')
    const root = createRoot(host)
    const dispatch = vi.fn()
    const item = findItem(CELL_ID)
    let signal: AbortSignal | undefined
    vi.mocked(reviewEarningAnswer).mockImplementation((_input, options) => {
      signal = options?.signal as AbortSignal
      return new Promise(() => {})
    })
    const render = (choice: string, submitted = true) => act(() => root.render(<StrictMode>
      <AnswerReviewProvider item={item} answer={choice === DESCRIBE_CHOICE ? { choice, description: 'Business phone expenses', descriptionSubmitted: submitted } : { choice }} dispatch={dispatch}>
        <AnswerReview question={item.question} selected={choice} options={SOMETHING_ELSE} />
      </AnswerReviewProvider>
    </StrictMode>))
    // Still typing: no request, loader or AI mark until Done.
    render(DESCRIBE_CHOICE, false)
    await act(async () => { await vi.advanceTimersByTimeAsync(2000) })
    expect(reviewEarningAnswer).not.toHaveBeenCalled()
    expect(host.textContent).not.toContain('reviewing')
    expect(host.querySelector('.ec-answer-review')).toBeNull()
    render(DESCRIBE_CHOICE)
    await act(async () => { await vi.advanceTimersByTimeAsync(500) })
    expect(reviewEarningAnswer).toHaveBeenCalledTimes(1)
    expect(host.querySelector('[role="status"]')?.textContent).toContain('reviewing')
    render('ask-customer')
    expect(signal?.aborted).toBe(true)
    await act(async () => { await vi.advanceTimersByTimeAsync(500) })
    expect(reviewEarningAnswer).toHaveBeenCalledTimes(1)
    act(() => root.unmount())
  })
  const typeInto = (box: HTMLTextAreaElement, value: string) => act(() => {
    Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')!.set!.call(box, value)
    box.dispatchEvent(new Event('input', { bubbles: true }))
  })
  const clickButton = (host: HTMLElement, label: string) => act(() => [...host.querySelectorAll('button')].find(button => button.textContent === label)!.click())
  it('keeps asking one question at a time with the whole thread, then resolves with a next step', async () => {
    vi.useFakeTimers()
    const host = document.createElement('div')
    const root = createRoot(host)
    const item = findItem(CELL_ID)
    const first = { ...confirm, outcome: 'followUp' as const, reason: 'Weekend shifts could be a shift premium or overtime.',
      suggestion: 'If it’s a fixed extra amount for weekend shifts, we’d set it up as a shift differential.', question: 'Is this a fixed extra amount for each weekend shift?' }
    const second = { ...first, reason: 'A fixed amount per shift points to a shift premium.', suggestion: 'We’d set it up as a shift differential paid per shift.',
      question: 'Does everyone who works a weekend shift get the same amount?' }
    vi.mocked(reviewEarningAnswer).mockResolvedValueOnce(first).mockResolvedValueOnce(second).mockResolvedValue(confirm)
    let latest = typedCell()
    function Harness() {
      const [session, setSession] = useState(() => typedCell())
      latest = session
      const dispatch = (action: SessionAction) => setSession(value => reduceSession(value, action))
      return <AnswerReviewProvider item={item} answer={session.answers[item.id]} dispatch={dispatch}>
        <AnswerReview question={item.question} selected={DESCRIBE_CHOICE} options={SOMETHING_ELSE} />
      </AnswerReviewProvider>
    }
    act(() => root.render(<Harness />))
    await act(async () => { await vi.advanceTimersByTimeAsync(500) })
    expect(vi.mocked(reviewEarningAnswer).mock.calls[0][0].thread).toEqual([])
    // Reason, then the suggested next step on its own line, then one question with a box and Send.
    expect(host.querySelector('[role="status"]')?.textContent).toContain(first.reason)
    expect(host.querySelector('.ec-answer-review__suggestion')?.textContent).toBe(first.suggestion)
    expect(host.querySelector('label')?.textContent).toContain(first.question)
    expect(host.querySelector('.ec-answer-review__thread')).toBeNull()
    typeInto(host.querySelector('textarea')!, 'Yes, owner@example.com confirmed it.')
    clickButton(host, 'Send')
    // The pending reply already shows in the thread while the review runs.
    expect(host.querySelector('.ec-answer-review__thread')?.textContent).toContain(first.question)
    await act(async () => { await vi.advanceTimersByTimeAsync(500) })
    const secondRequest = vi.mocked(reviewEarningAnswer).mock.calls[1][0]
    expect(secondRequest.thread).toHaveLength(1)
    expect(secondRequest.thread[0]).toMatchObject({ question: first.question, reason: first.reason, suggestion: first.suggestion })
    expect(secondRequest.thread[0].reply).not.toContain('owner@example.com')
    expect(host.querySelector('label')?.textContent).toContain(second.question)
    expect(host.querySelector('.ec-answer-review__suggestion')?.textContent).toBe(second.suggestion)
    expect(host.querySelector('.ec-answer-review__thread')?.textContent).toContain(first.question)
    expect(host.querySelector('textarea')?.value).toBe('')
    typeInto(host.querySelector('textarea')!, 'Yes, the same amount.')
    clickButton(host, 'Send')
    await act(async () => { await vi.advanceTimersByTimeAsync(500) })
    const thirdRequest = vi.mocked(reviewEarningAnswer).mock.calls[2][0]
    expect(thirdRequest.thread.map(turn => turn.question)).toEqual([first.question, second.question])
    expect(thirdRequest.thread[1].reply).toBe('Yes, the same amount.')
    // Resolved: no question, but still a next step, with the earlier turns above it.
    expect(host.querySelector('textarea')).toBeNull()
    expect(host.querySelector('[role="status"]')?.textContent).toContain(confirm.reason)
    expect(host.querySelector('.ec-answer-review__suggestion')?.textContent).toBe(confirm.suggestion)
    expect([...host.querySelectorAll('.ec-answer-review__thread li')].map(entry => entry.textContent))
      .toEqual([expect.stringContaining(first.question), `${second.question}Your reply: Yes, the same amount.`])
    const stored = latest.answers[CELL_ID].reviews?.[item.question]
    expect(stored?.thread).toHaveLength(2)
    expect(parseSession(JSON.stringify(latest))?.answers[CELL_ID].reviews?.[item.question]).toEqual(stored)
    expect(bryteFacts(latest).facts.answerReviewsInView).toContain(`CELL: confirm, conversation resolved; suggested next step: ${confirm.suggestion}`)
    act(() => root.unmount())
  })
  it('starts a fresh conversation when the typed answer changes', async () => {
    vi.useFakeTimers()
    const host = document.createElement('div')
    const root = createRoot(host)
    const item = findItem(CELL_ID)
    const followUp = { ...confirm, outcome: 'followUp' as const, question: 'Is this a fixed extra amount for each weekend shift?' }
    vi.mocked(reviewEarningAnswer).mockResolvedValueOnce(followUp).mockResolvedValue(followUp)
    let setOuter: (description: string) => void = () => {}
    function Harness() {
      const [session, setSession] = useState(() => typedCell())
      // Edit description, type the new answer and select Done again.
      setOuter = description => setSession(value => [
        { type: 'editDescription', itemId: CELL_ID } as const, { type: 'describe', itemId: CELL_ID, description } as const,
        { type: 'submitDescription', itemId: CELL_ID } as const,
      ].reduce((state, action) => reduceSession(state, action), value))
      return <AnswerReviewProvider item={item} answer={session.answers[item.id]} dispatch={action => setSession(value => reduceSession(value, action))}>
        <AnswerReview question={item.question} selected={DESCRIBE_CHOICE} options={SOMETHING_ELSE} />
      </AnswerReviewProvider>
    }
    act(() => root.render(<Harness />))
    await act(async () => { await vi.advanceTimersByTimeAsync(500) })
    typeInto(host.querySelector('textarea')!, 'Yes.')
    act(() => setOuter('Extra pay for holiday shifts'))
    await act(async () => { await vi.advanceTimersByTimeAsync(500) })
    expect(vi.mocked(reviewEarningAnswer).mock.calls.at(-1)?.[0].thread).toEqual([])
    expect(host.querySelector('.ec-answer-review__thread')).toBeNull()
    expect(host.querySelector('textarea')?.value).toBe('')
    act(() => root.unmount())
  })
  it('loads an older saved review with a single stored reply as a one-turn thread', async () => {
    vi.useFakeTimers()
    const host = document.createElement('div')
    const root = createRoot(host)
    const item = findItem(CELL_ID)
    const base = typedCell()
    // Saved before threads and suggestions: the latest result and the single reply, nothing else.
    const legacy = { basis: answerReviewBasis(base.answers[CELL_ID]), reply: 'It was for an earlier period.',
      result: { outcome: 'followUp', reason: 'This could be a correction.', question: 'Which pay period did it correct?', conflictingFact: null } }
    const saved = { ...base, answers: { ...base.answers, [CELL_ID]: { ...base.answers[CELL_ID], reviews: { [item.question]: legacy } } } }
    const loaded = parseSession(JSON.stringify(saved))!
    expect(loaded.answers[CELL_ID].reviews?.[item.question]).toEqual(legacy)
    expect(bryteFacts(loaded).facts.answerReviewsInView).toContain('CELL: followUp, conversation open')
    vi.mocked(reviewEarningAnswer).mockResolvedValue(confirm)
    function Harness() {
      const [session, setSession] = useState(loaded)
      return <AnswerReviewProvider item={item} answer={session.answers[item.id]} dispatch={action => setSession(value => reduceSession(value, action))}>
        <AnswerReview question={item.question} selected={DESCRIBE_CHOICE} options={SOMETHING_ELSE} />
      </AnswerReviewProvider>
    }
    act(() => root.render(<Harness />))
    await act(async () => { await vi.advanceTimersByTimeAsync(500) })
    expect(reviewEarningAnswer).not.toHaveBeenCalled()
    expect(host.querySelector('[role="status"]')?.textContent).toContain(legacy.result.reason)
    expect(host.querySelector('.ec-answer-review__suggestion')).toBeNull()
    expect(host.querySelector('.ec-answer-review__thread')).toBeNull()
    typeInto(host.querySelector('textarea')!, 'March.')
    clickButton(host, 'Send')
    await act(async () => { await vi.advanceTimersByTimeAsync(500) })
    expect(vi.mocked(reviewEarningAnswer).mock.calls[0][0].thread).toEqual([{ reason: legacy.result.reason, question: legacy.result.question, reply: 'March.' }])
    expect(host.querySelector('.ec-answer-review__thread')?.textContent).toContain(legacy.result.question)
    expect(host.querySelector('.ec-answer-review__suggestion')?.textContent).toBe(confirm.suggestion)
    act(() => root.unmount())
  })
  it('keeps follow-up questions available beyond six replies and accepts longer saved threads', async () => {
    vi.useFakeTimers()
    const host = document.createElement('div')
    const root = createRoot(host)
    const item = findItem(CELL_ID)
    const base = typedCell()
    // An explicitly historical typed CELL answer still uses the general review.
    // Current CELL uses the separate adaptive payment review.
    base.answers[CELL_ID] = { ...base.answers[CELL_ID], choice: DESCRIBE_CHOICE,
      description: 'We pay both an allowance and business phone expenses', descriptionSubmitted: true, cellLegacy: true }
    const thread = Array.from({ length: 12 }, (_, index) => ({ question: `Question ${index + 1}?`, reply: `Reply ${index + 1}` }))
    const review = { basis: answerReviewBasis(base.answers[CELL_ID]), thread,
      result: { ...confirm, outcome: 'conflict' as const, conflictingFact: 'description' as const, reason: 'The register description says special pay.', question: 'Is it special pay?' } }
    expect(validAnswerReview(review)).toBe(true)
    expect(validAnswerReview({ ...review, thread: [...thread, thread[0]] })).toBe(true)
    expect(validAnswerReview({ ...review, result: { ...confirm, question: 'Anything else?' } })).toBe(false)
    expect(validAnswerReview({ ...review, result: { ...confirm, outcome: 'followUp', question: null } })).toBe(false)
    const session = reduceSession(base, { type: 'answerReview', itemId: CELL_ID, key: item.question, review })
    act(() => root.render(<AnswerReviewProvider item={item} answer={session.answers[CELL_ID]} dispatch={vi.fn()}>
      <AnswerReview question={item.question} selected={DESCRIBE_CHOICE} options={SOMETHING_ELSE} />
    </AnswerReviewProvider>))
    await act(async () => { await vi.advanceTimersByTimeAsync(500) })
    expect(reviewEarningAnswer).not.toHaveBeenCalled()
    expect(host.querySelector('textarea')).not.toBeNull()
    expect(host.querySelectorAll('.ec-answer-review__thread li')).toHaveLength(12)
    expect([...host.querySelectorAll('button')].map(button => button.textContent)).toContain('Keep my answer')
    expect(bryteFacts(session).facts.answerReviewsInView).toContain('CELL: conflict, conversation open, waiting for a reply (12 follow-up questions answered)')
    act(() => root.unmount())
  })
  it('rejects a fresh result without a suggestion', async () => {
    const input = reviewRequest(findItem('SPPAY'), {}, 'Purpose?', 'Something else', '')
    vi.mocked(reviewEarningAnswer).mockResolvedValueOnce({ ...confirm, suggestion: undefined } as unknown as typeof confirm)
    expect((await requestAnswerReview(input, new AbortController().signal)).ok).toBe(false)
  })
  it('offers Keep my answer on conflicts and retries a documented failure', async () => {
    vi.useFakeTimers()
    const host = document.createElement('div')
    const root = createRoot(host)
    const item = findItem(CELL_ID)
    vi.mocked(reviewEarningAnswer).mockRejectedValueOnce({ data: { code: 'unavailable', error: 'We can’t review this right now.' } })
      .mockResolvedValue({ ...confirm, outcome: 'conflict', conflictingFact: 'description', reason: 'The register description says special pay.' })
    function Harness() {
      const [session, setSession] = useState(() => typedCell())
      return <AnswerReviewProvider item={item} answer={session.answers[item.id]} dispatch={action => setSession(value => reduceSession(value, action))}>
        <AnswerReview question={item.question} selected={DESCRIBE_CHOICE} options={SOMETHING_ELSE} />
      </AnswerReviewProvider>
    }
    act(() => root.render(<Harness />))
    await act(async () => { await vi.advanceTimersByTimeAsync(500) })
    expect(host.textContent).toContain('We can’t review this right now.')
    act(() => [...host.querySelectorAll('button')].find(button => button.textContent === 'Try again')!.click())
    await act(async () => { await vi.advanceTimersByTimeAsync(500) })
    expect(host.textContent).toContain('The register description says special pay.')
    act(() => [...host.querySelectorAll('button')].find(button => button.textContent === 'Keep my answer')!.click())
    expect(host.textContent).toBe('')
    act(() => root.unmount())
  })

  describe('medical review remains available without a retired plan-page link', () => {
    const declined = { ...confirm, askBryte: true, reason: 'We won’t set up a company contribution. If your company starts paying later, we’ll need to set up a new code then.' }
    const pages = { questions: () => ({ name: 'Who pays into each plan', purpose: 'Plans.', onScreen: [], state: [], welcome: 'Who pays into MED and DEN?', suggestions: [] }) }
    async function mount({ result = declined, itemId = 'MED ER', offerAskBryte }: { result?: typeof confirm & { askBryte?: boolean }; itemId?: string; offerAskBryte?: boolean } = {}) {
      vi.useFakeTimers()
      vi.stubGlobal('matchMedia', vi.fn((query: string) => ({ matches: false, media: query, addEventListener: vi.fn(), removeEventListener: vi.fn() })))
      vi.mocked(reviewEarningAnswer).mockResolvedValue(result)
      const ask = vi.fn().mockResolvedValue({ answer: 'If your company starts paying later, we set up a new code next to DEN.' })
      const host = document.createElement('div')
      document.body.append(host)
      const root = createRoot(host)
      const item = findItem(itemId)
      // A typed answer: MED's No description after Done, the note under DEN's No after Done, or SPPAY's Something else.
      const choice = itemId === 'DEN' ? 'employee-only' : DESCRIBE_CHOICE
      const options = item.type === 'clarification' && itemId === 'DEN' ? item.options.map(option => ({ id: option.id, title: option.label }))
        : [{ id: DESCRIBE_CHOICE, title: item.type === 'clarification' ? item.describe!.label : 'Something else' }]
      const typed = item.type === 'clarification'
        ? [{ type: 'choose', itemId, choice } as const, { type: 'describe', itemId, description: 'My company won’t ever pay for this' } as const, { type: 'submitDescription', itemId } as const]
        : [{ type: 'describe', itemId, description: 'My company won’t ever pay for this' } as const, { type: 'submitDescription', itemId } as const]
      function Harness() {
        const [session, setSession] = useState(() => typed.reduce<ReturnType<typeof started>>((state, action) => reduceSession(state, action), started()))
        return <AskBryteProvider app="earning-configuration" pages={pages} ask={ask}>
          <AskBrytePage page="questions" />
          <AnswerReviewProvider item={item} answer={session.answers[item.id]} dispatch={action => setSession(value => reduceSession(value, action))} offerAskBryte={offerAskBryte}>
            <AnswerReview question={item.question} selected={choice} options={options} />
          </AnswerReviewProvider>
        </AskBryteProvider>
      }
      act(() => root.render(<Harness />))
      await act(async () => { await vi.advanceTimersByTimeAsync(500) })
      const link = () => host.querySelector<HTMLButtonElement>('.ec-answer-review__ask button')
      return { host, root, ask, link, cleanup: () => { act(() => root.unmount()); host.remove(); vi.unstubAllGlobals() } }
    }
    it('still reviews a typed MED ER description', async () => {
      const { host, link, cleanup } = await mount()
      expect(reviewEarningAnswer).toHaveBeenCalledTimes(1)
      expect(host.querySelector('.ec-answer-review [role="status"]')?.textContent).toContain(declined.reason)
      expect(link()).toBeNull()
      cleanup()
    })
    it('does not reuse the retired plan-page link on the current medical card', async () => {
      const { host, ask, link, cleanup } = await mount()
      expect(host.querySelector('.ec-answer-review [role="status"]')?.textContent).toContain(declined.reason)
      expect(link()).toBeNull()
      expect(ask).not.toHaveBeenCalled()
      cleanup()
    })
    it('leaves the link out without the signal, off plan cards and in the reply dialog', async () => {
      for (const options of [{ result: { ...declined, askBryte: false } }, { result: confirm }, { itemId: 'SPPAY' }, { offerAskBryte: false }]) {
        const { host, link, cleanup } = await mount(options)
        expect(host.querySelector('.ec-answer-review [role="status"]')?.textContent ?? '').not.toContain('reviewing')
        expect(link()).toBeNull()
        cleanup()
      }
    })
    it('keeps older saved reviews and rejects the signal on anything but confirm', () => {
      expect(validAnswerReview({ basis: '', result: confirm })).toBe(true)
      expect(validAnswerReview({ basis: '', result: declined })).toBe(true)
      expect(validAnswerReview({ basis: '', result: { ...declined, outcome: 'notNeeded' } })).toBe(false)
      expect(validAnswerReview({ basis: '', result: { ...declined, askBryte: 'yes' } })).toBe(false)
    })
  })
  describe('fixed picks get no review', () => {
    it('treats every fixed option on every card as a pick, and only typed text as reviewable', () => {
      for (const item of [...REVIEW_INITIAL_ITEMS, ...PLAN_INITIAL_ITEMS]) {
        const options = item.type === 'misclassification' ? [item.accept]
          : item.type === 'unidentified' ? (item.script.kind === 'uncertainMatch' ? item.script.options : [])
            : item.options
        for (const option of options) {
          const answer = { choice: option.id }
          expect(typedAnswerFor(item, answer, item.question, option.id), `${item.code} ${option.label}`).toBeUndefined()
          // DEN's employer-code picks and its short code name get no AI review either.
          const employerCode = item.type === 'clarification' ? item.employerCode : undefined
          if (employerCode) {
            expect(typedAnswerFor(item, { choice: 'both', followUps: { employerCode: 'suggested' } }, employerCode.question, 'suggested')).toBeUndefined()
            expect(typedAnswerFor(item, { choice: 'both', followUps: { employerCode: 'existing' }, employerCodeName: { name: 'DENCO', submitted: true } },
              employerCode.question, 'existing')).toBeUndefined()
          }
        }
      }
      const sppay = findItem('SPPAY')
      // Still typing: no review until Done.
      expect(typedAnswerFor(sppay, { description: '  Weekend shift pay ' }, sppay.question, DESCRIBE_CHOICE)).toBeUndefined()
      expect(typedAnswerFor(sppay, { description: '  Weekend shift pay ', descriptionSubmitted: true }, sppay.question, DESCRIBE_CHOICE)).toBeUndefined()
      expect(typedAnswerFor(sppay, { description: '', descriptionSubmitted: true }, sppay.question, DESCRIBE_CHOICE)).toBeUndefined()
      const med = findItem('MED')
      expect(typedAnswerFor(med, { choice: DESCRIBE_CHOICE, description: 'Both parts' }, med.question, DESCRIBE_CHOICE)).toBeUndefined()
      expect(typedAnswerFor(med, { choice: DESCRIBE_CHOICE, description: 'Both parts', descriptionSubmitted: true }, med.question, DESCRIBE_CHOICE)).toBe('Both parts')
      // DEN's No is a pick; its optional note is typed once Done locks it.
      const den = findItem('DEN')
      expect(typedAnswerFor(den, { choice: 'employee-only', description: 'Never' }, den.question, 'employee-only')).toBeUndefined()
      expect(typedAnswerFor(den, { choice: 'employee-only', description: 'Never', descriptionSubmitted: true }, den.question, 'employee-only')).toBe('Never')
      // The in-use question: Separate pay is a pick; its Something else text is typed.
      const shift = { choice: 'shift' }
      const shared = sharedSetupFor(sppay, shift)!
      const referenceId = shared.reference.id
      expect(typedAnswerFor(sppay, { ...shift, sharedSetup: { referenceId, choice: 'separate' } }, shared.question, 'separate')).toBeUndefined()
      expect(typedAnswerFor(sppay, { ...shift, sharedSetup: { referenceId, choice: 'other', description: 'Higher rate' } }, shared.question, 'other')).toBeUndefined()
      expect(typedAnswerFor(sppay, { ...shift, sharedSetup: { referenceId, choice: 'other', description: 'Higher rate', descriptionSubmitted: true } }, shared.question, 'other')).toBe('Higher rate')
    })

    it('sends no request and shows no loader for fixed medical and BONREV picks', async () => {
      vi.useFakeTimers()
      const host = document.createElement('div')
      const root = createRoot(host)
      for (const [itemId, choice] of [['MED ER', 'only-records'], ['MED', 'employee'], ['BONREV', 'accept'], ['SPPAY', 'retro']] as const) {
        const item = findItem(itemId)
        const options = item.type === 'clarification' ? item.options.map(option => ({ id: option.id, title: option.label }))
          : item.type === 'misclassification' ? [{ id: item.accept.id, title: item.accept.label }] : [{ id: 'retro', title: 'Retroactive pay' }]
        act(() => root.render(<AnswerReviewProvider item={item} answer={{ choice }} dispatch={vi.fn()}>
          <AnswerReview question={item.question} selected={choice} options={options} />
        </AnswerReviewProvider>))
        await act(async () => { await vi.advanceTimersByTimeAsync(500) })
        expect(host.textContent).toBe('')
      }
      expect(reviewEarningAnswer).not.toHaveBeenCalled()
      act(() => root.unmount())
    })

    it('loads saved reviews of fixed picks but neither shows them nor reports them to Ask Bryte', async () => {
      vi.useFakeTimers()
      let session = reduceSession(started(), { type: 'choose', itemId: 'SPPAY', choice: 'retro' })
      const item = findItem('SPPAY')
      const old = { ...confirm, reason: 'You said SPPAY is retroactive pay, and that fits.' }
      session = reduceSession(session, { type: 'answerReview', itemId: 'SPPAY', key: item.question, review: { basis: answerReviewBasis(session.answers.SPPAY), result: old } })
      const loaded = parseSession(JSON.stringify(session))!
      expect(loaded.answers.SPPAY.reviews?.[item.question].result).toEqual(old)
      expect(bryteFacts(loaded).facts.answerReviewsInView).not.toContain('SPPAY')
      const host = document.createElement('div')
      const root = createRoot(host)
      act(() => root.render(<AnswerReviewProvider item={item} answer={loaded.answers.SPPAY} dispatch={vi.fn()}>
        <AnswerReview question={item.question} selected="retro" options={[{ id: 'retro', title: 'Retroactive pay' }]} />
      </AnswerReviewProvider>))
      await act(async () => { await vi.advanceTimersByTimeAsync(500) })
      expect(host.textContent).not.toContain(old.reason)
      expect(reviewEarningAnswer).not.toHaveBeenCalled()
      act(() => root.unmount())
      // A redundant typed opening review stays stored but is not shown or reported.
      let typed = typedSppay()
      typed = reduceSession(typed, { type: 'answerReview', itemId: 'SPPAY', key: item.question, review: { basis: answerReviewBasis(typed.answers.SPPAY), result: confirm } })
      expect(parseSession(JSON.stringify(typed))?.answers.SPPAY.reviews?.[item.question].result).toEqual(confirm)
      expect(bryteFacts(typed).facts.answerReviewsInView).not.toContain('Special Pay: confirm')
    })
  })
})
