import { discussionBasis, discussionKey } from './discussionAnswers'
import { pendingDiscussionQuestions } from './reviewDiscussionChoices'
import { ASK_CUSTOMER, DESCRIBE_CHOICE, EMPLOYER_CODE_QUESTION, EXISTING_CODE, findItem, isReviewItem } from './sampleRegister'
import { activeCheck, openCheckQuestion, canSubmitRound, classificationComplete, currentRound, decisionFor, reduceSession,
  reviewPages, sharedSetupFor, somethingElseQuestion, type EarningSession, type ItemAnswer, type Resolution, type RoundRecord, type SessionAction } from './session'
import type { DiscussionAnswers } from './discussionFormats'
import { SOMETHING_ELSE, SOMETHING_ELSE_MAIN, SOMETHING_ELSE_NAME, SOMETHING_ELSE_REFERENCE, SOMETHING_ELSE_RETENTION } from './somethingElse'
import { appliedDemoSkip, optionalDemoQuestion } from './optionalDemoQuestions'
import { selectedDeferral } from './explicitDeferral'
import { questionApplies } from './questionApplicability'
import { answerReviewBasis } from './answerReviewData'
import { typedAnswerFor } from './answerReviewScope'
import { legacyDeferredSelection, setupReviewTarget, setupReviewQuestion } from './setupReview'
import { callEvidence } from './cheatSheetAnswers'
import type { DiscussionAnswer } from './discussionFormats'
import { assessDeferredItem, checkedTipsForSetupReview } from './deferredAssessment'
import { discussionInputComplete, discussionProgress } from './discussionProgress'
import { cheatSheetGroups, type CheatSheetRow } from './cheatSheet'
import { discussionSummaryBasis } from './discussionSummary'

export interface DiscussionPreview {
  /** Codes prepared for review, in a card or the separate preview; never applied by preparation. */
  inlineItems?: string[]
  identity?: string
  checks?: Record<string, import('./proposalAssessment').ProposalCheck>
  basis: string
  /** Explicit owning-question continuation for unconfirmed setup notes; not an invented Defer. */
  setupItems?: string[]
  /** Only prospective answers and round ownership; never applied resolutions or sent data. */
  answers: Record<string, ItemAnswer>
  round: RoundRecord
  pendingDeferralTarget?: EarningSession['pendingDeferralTarget']
  drafts?: Record<string, string>
}
export interface DiscussionApplication {
  /** Only individual applications retain an in-place, frozen presentation. Older/batch receipts stay history. */
  inlineCard?: {
    itemId: string
    session: Pick<EarningSession, 'answers' | 'resolutions' | 'rounds' | 'discussionAnswers' | 'discussionPreview' | 'discussionSummaries' | 'callAnswers' | 'paymentReviews'>
    outcome: string
    row: CheatSheetRow
    entries: ReturnType<typeof discussionEntries>
  }
  id: string
  round: number
  at: number
  basis: string
  originalAnswers: Record<string, ItemAnswer>
  responses: DiscussionAnswers
  outcomes: Record<string, Resolution>
  originalResolutions: Record<string, Resolution>
  appliedAnswers?: Record<string, ItemAnswer>
  /** Frozen question wording for follow-ups answered within this proposal. */
  confirmedAnswers?: Record<string, { question: string; answer: string }[]>
  source?: 'discussion' | 'setupReview'
}

export function discussionEntries(session: EarningSession) {
  const ids = [...new Set(session.rounds.filter(round => round.submitted).flatMap(round => round.itemIds))]
  return ids.flatMap(itemId => pendingDiscussionQuestions(session, itemId).map(entry => {
    const basis = discussionBasis(session, itemId)
    const key = discussionKey(entry.question, basis, entry.options.length ? entry.options : undefined)
    return { ...entry, itemId, key, basis, answer: session.discussionAnswers?.[itemId]?.[key] }
  }))
}

export function discussionsComplete(session: EarningSession) {
  return discussionProgress(discussionEntries(session)).complete
}

/** Notes and supporting summaries cannot change the proposal. Evidence and confirmed related facts can. */
export function discussionReviewBasis(session: EarningSession) {
  return JSON.stringify([discussionEntries(session), session.answers, session.resolutions, session.rounds, session.files, session.sampleRegisterVersion,
    session.registerOwnerId, session.registerSource])
}
export const previewCurrent = (session: EarningSession) =>
  !!session.discussionPreview && session.discussionPreview.basis === discussionReviewBasis(session)

export function canEnterOptimization(session: EarningSession): boolean {
  return classificationComplete(session) && !discussionEntries(session).length
    && session.rounds.flatMap(round => round.itemIds).filter(isReviewItem).every(id => {
      if (!questionApplies(findItem(id), session) || optionalDemoQuestion(session, id) || appliedDemoSkip(session, id)) return true
      const result = session.resolutions[id]
      // A confirmed clear-purpose custom name isn't an unresolved purpose. It still has no tax/reference facts.
      return result?.status === 'resolved' || result?.status === 'removed' || result?.status === 'recommended'
        || result?.status === 'review' && !!result.customName
    })
}

function workspace(session: EarningSession, preview: DiscussionPreview): EarningSession {
  return { ...session, discussionPreview: undefined, appliedReview: undefined, pendingDeferralTarget: preview.pendingDeferralTarget,
    step: 'questions', answers: preview.answers,
    rounds: [...session.rounds.filter(round => round.submitted), preview.round],
    reviewCursor: 0 }
}
export function previewWorkSession(session: EarningSession) {
  return previewCurrent(session) ? workspace(session, session.discussionPreview!) : undefined
}

function responseActions(entry: ReturnType<typeof discussionEntries>[number], original: ItemAnswer): SessionAction[] {
  const { itemId, target, answer, options } = entry
  if (!target || !answer) return []
  const choice = answer.choice ?? ''
  const selected = options.find(option => option.id === choice)
  const text = (selected?.details ? answer.details?.[choice] : options.length ? selected?.label : answer.text)?.trim() ?? ''
  const action = (type: 'choose' | 'chooseRetention', value = choice): SessionAction =>
    type === 'choose' ? { type, itemId, choice: value }
      : { type, itemId, choice: value as 'keep' | 'remove' | typeof ASK_CUSTOMER }
  const otherwise = (question: string): SessionAction[] => [
    { type: 'chooseSomethingElse', itemId, question },
    { type: 'describeSomethingElse', itemId, description: text },
    { type: 'submitSomethingElse', itemId },
  ]
  switch (target.kind) {
    case 'tips': return [{ type: 'tips', itemId, event: { kind: 'answer', id: target.id,
      value: target.id === 'opening' ? choice === SOMETHING_ELSE ? 'other' : choice : text,
      ...(selected?.details ? { text } : {}) } }]
    case 'conditional': return original.conditionalReview ? [
      action('choose', original.conditionalReview.primary),
      { type: 'conditionalReview', itemId, event: { type: 'answer', questionId: target.id, choice } },
    ] : []
    case 'cell': return [{ type: 'cell', itemId, event: { kind: 'answer', id: target.id,
      value: choice.startsWith('option-') || choice === SOMETHING_ELSE ? text : choice || text,
      ...(selected?.details ? { text } : {}) } }]
    case 'check': return [{ type: 'answerCheckQuestion', itemId, answer: text }]
    case 'shiftReply': return [{ type: 'shiftPremium', itemId, event: { kind: 'reply', reply: text } }]
    case 'shiftDecision': return [{ type: 'shiftPremium', itemId, event: {
      kind: choice === 'confirm' ? 'confirm' : choice === 'separate' ? 'keepSeparate' : 'change',
    } }]
    case 'description': return target.append && openCheckQuestion(findItem(itemId), original)
      ? [{ type: 'answerCheckQuestion', itemId, answer: text }] : [
      ...(original.descriptionSubmitted ? [{ type: 'editDescription', itemId } as SessionAction] : []),
      { type: 'describe', itemId, description: target.append ? [original.description, text].filter(Boolean).join('\n') : text },
      { type: 'submitDescription', itemId },
    ]
    case 'retention': return choice === SOMETHING_ELSE ? otherwise(SOMETHING_ELSE_RETENTION) : [action('chooseRetention')]
    case 'followUp': return choice === SOMETHING_ELSE ? otherwise(target.id)
      : [{ type: 'answerFollowUp', itemId, questionId: target.id, choice },
        ...(target.id === EMPLOYER_CODE_QUESTION && choice === EXISTING_CODE ? [
          { type: 'nameEmployerCode', itemId, name: text } as SessionAction,
          { type: 'submitEmployerCodeName', itemId } as SessionAction,
        ] : [])]
    case 'shared': return [
      { type: 'answerSharedSetup', itemId, referenceId: target.referenceId, choice },
      ...(choice === 'other' ? [
        { type: 'describeSharedSetup', itemId, referenceId: target.referenceId, description: text } as SessionAction,
        { type: 'submitSharedSetupDescription', itemId, referenceId: target.referenceId } as SessionAction,
      ] : []),
    ]
    case 'choice':
      if (choice === SOMETHING_ELSE) return otherwise(target.stage === 'name' ? SOMETHING_ELSE_NAME
        : target.stage === 'reference' ? SOMETHING_ELSE_REFERENCE : SOMETHING_ELSE_MAIN)
      // SPPAY's other is a description-check target, not a generic Something else note.
      if (choice === 'other' && findItem(itemId).type === 'unidentified')
        return [action('choose'), { type: 'describe', itemId, description: text }, { type: 'submitDescription', itemId }]
      return [action('choose'), ...(choice === DESCRIBE_CHOICE ? [
        { type: 'describe', itemId, description: text } as SessionAction, { type: 'submitDescription', itemId } as SessionAction,
      ] : [])]
  }
}

export function prepareDiscussionReview(session: EarningSession): EarningSession {
  const eligible = discussionEntries(session).filter(discussionInputComplete)
  if (!eligible.length) return session
  const existing = previewCurrent(session) && !session.discussionPreview?.setupItems ? session.discussionPreview : undefined
  const prepared = existing?.inlineItems ?? existing?.round.itemIds ?? []
  // Preserve checked results, follow-ups and drafts for unchanged answers when more input arrives.
  const next = prepareDiscussionItems(session, [...new Set(eligible.map(entry => entry.itemId))].filter(id => !prepared.includes(id)))
  return { ...next, step: 'discussionReview' }
}

/** Prepare one owning code without requiring answers from the other discussion cards. */
export function prepareInlineDiscussion(session: EarningSession, itemId: string): EarningSession {
  if (session.step !== 'review') return session
  const entries = discussionEntries(session).filter(entry => entry.itemId === itemId)
  if (!entries.length || !discussionProgress(entries).complete) return session
  return prepareDiscussionItems(session, [itemId])
}

/** Shares the existing owning checks between in-card work and the separate answer preview. */
function prepareDiscussionItems(session: EarningSession, itemIds: string[]): EarningSession {
  if (!itemIds.length) return session
  const entries = discussionEntries(session).filter(entry => itemIds.includes(entry.itemId) && discussionInputComplete(entry))
  const existing = previewCurrent(session) && !session.discussionPreview?.setupItems ? session.discussionPreview : undefined
  const inlineItems = [...new Set([...(existing?.inlineItems ?? (existing ? discussionEntries(session).map(entry => entry.itemId) : [])), ...itemIds])]
  const preview: DiscussionPreview = existing ?? {
    basis: discussionReviewBasis(session), answers: { ...session.answers },
    round: { number: Math.max(0, ...session.rounds.map(round => round.number)) + 1, itemIds: [], submitted: false },
  }
  let draft = workspace(session, { ...preview,
    answers: { ...preview.answers, ...Object.fromEntries(itemIds.map(id => [id, session.answers[id] ?? {}])) },
    round: { ...preview.round, itemIds: [...new Set([...preview.round.itemIds, ...itemIds])] } })
  for (const entry of entries) {
    if (!entry.target) continue
    const { itemId } = entry
    const before = draft.answers[itemId] ?? {}
    draft = { ...draft, answers: { ...draft.answers, [itemId]: { ...before, explicitDeferral: undefined } } }
    for (const action of responseActions(entry, before)) draft = reduceSession(draft, action)
  }
  return { ...session, discussionPreview: {
    ...preview, inlineItems, identity: crypto.randomUUID(), basis: discussionReviewBasis(session),
    answers: draft.answers, round: currentRound(draft)!, pendingDeferralTarget: draft.pendingDeferralTarget,
  } }
}

/** Editing an opening answer discards only that code's proposal, never another code's saved work. */
export function invalidateInlineDiscussion(before: EarningSession, next: EarningSession, itemId: string): EarningSession {
  const preview = before.discussionPreview
  if (!preview?.inlineItems || !previewCurrent(before) || before === next) return next
  const changed = preview.inlineItems.includes(itemId)
  const answers = { ...preview.answers, [itemId]: next.answers[itemId] ?? {} }
  const inlineItems = preview.inlineItems.filter(id => id !== itemId)
  const raises = (id: string, answer: ItemAnswer) => {
    const decision = decisionFor(findItem(id), answer)
    return decision?.kind === 'resolve' ? decision.raises : []
  }
  const raised = new Set(raises(itemId, preview.answers[itemId] ?? {}))
  // A finding still raised by another prepared answer retains its own work.
  for (const id of inlineItems) for (const raisedId of raises(id, answers[id] ?? {})) raised.delete(raisedId)
  for (const id of raised) answers[id] = next.answers[id] ?? {}
  const reset = new Set([itemId, ...raised])
  return { ...next, discussionPreview: {
    ...preview, inlineItems, answers, basis: discussionReviewBasis(next),
    identity: changed ? crypto.randomUUID() : preview.identity,
    round: { ...preview.round, itemIds: preview.round.itemIds.filter(id => id !== itemId && !raised.has(id)) },
    checks: Object.fromEntries(Object.entries(preview.checks ?? {}).filter(([key]) => ![...reset].some(id => key.startsWith(`${id}:`)))),
    drafts: Object.fromEntries(Object.entries(preview.drafts ?? {}).filter(([key]) => ![...reset].some(id => key.startsWith(`["${id}",`)))),
    pendingDeferralTarget: preview.pendingDeferralTarget && !reset.has(preview.pendingDeferralTarget.itemId)
      ? preview.pendingDeferralTarget : undefined,
  } }
}

/** Every typed target uses its existing review process. A stored, unchecked description is not a proposal. */
function checksComplete(itemId: string, answer: ItemAnswer): boolean {
  const item = findItem(itemId)
  const questions = [item.question, somethingElseQuestion(item, answer), ...Object.keys(answer.reviews ?? {})].filter((q): q is string => !!q)
  const shared = answer.sharedSetup
  // A shared description has a dynamic source question.
  if (shared?.choice === 'other') {
    const question = sharedSetupFor(item, answer)?.question
    const stored = question ? answer.reviews?.[question] : undefined
    if (!stored || stored.basis !== answerReviewBasis(answer) || stored.result.outcome !== 'confirm') return false
  }
  for (const question of questions) {
    const selected = answer.somethingElse && somethingElseQuestion(item, answer) === question ? SOMETHING_ELSE : answer.choice
    if (!typedAnswerFor(item, answer, question, selected)) continue
    const review = answer.reviews?.[question]
    if (!review || review.basis !== answerReviewBasis(answer) || !['confirm', 'notNeeded'].includes(review.result.outcome)) return false
  }
  const check = activeCheck(item, answer)
  return check?.kind !== 'needsInformation'
}

export function previewItems(session: EarningSession) {
  const draft = previewWorkSession(session)
  if (!draft) return []
  const setup = !!session.discussionPreview?.setupItems
  const entries = setup ? session.discussionPreview!.setupItems!.map(itemId => ({
    itemId, question: setupReviewQuestion(session, itemId),
    target: legacyDeferredSelection(session, itemId) ? undefined : setupReviewTarget(session.answers[itemId] ?? {}),
    options: [] as { id: string; label: string; details?: boolean }[], answer: undefined as DiscussionAnswer | undefined,
  })) : discussionEntries(session).filter(entry => discussionInputComplete(entry)
    && (session.discussionPreview!.inlineItems ?? session.discussionPreview!.round.itemIds).includes(entry.itemId))
  return entries.map(entry => {
    const decision = setup || entry.target ? decisionFor(findItem(entry.itemId), draft.answers[entry.itemId]) : undefined
    const selected = entry.options.find(option => option.id === entry.answer?.choice)
    const newDeferral = selectedDeferral(draft.answers[entry.itemId])
    const movedToNewQuestion = decision?.kind === 'defer' && !!newDeferral?.target
      && (setup || newDeferral.question !== entry.question)
    const candidateReady = !!decision && (movedToNewQuestion || decision.kind !== 'defer'
      && (decision.kind !== 'describe' || decision.mileageRecommendation === true || checkedTipsForSetupReview(entry.itemId, draft.answers[entry.itemId]))
      && checksComplete(entry.itemId, draft.answers[entry.itemId]))
    const actionable = setup || !!entry.target
    const assessment = actionable ? assessDeferredItem(session, entry.itemId, draft.answers[entry.itemId] ?? {}, candidateReady, movedToNewQuestion)
      : { status: 'specialist' as const, message: 'The original answer control was not saved. This response stays in history and cannot be applied.' }
    const ready = candidateReady && ['ready', 'deferred', 'setupReview'].includes(assessment.status)
    const outcome = !setup && !entry.target ? 'The original answer control was not saved. This response can be saved as history, but cannot be applied.'
      : !ready ? assessment.message
      : assessment.status === 'setupReview' ? assessment.message
      : movedToNewQuestion ? `Keep the new question for discussion: ${newDeferral!.question} Continuing won’t confirm this decision.`
      : decision?.kind === 'resolve' ? [
        `Set up as ${decision.reference.name}.`,
        decision.combinedInto ? `Combine into ${decision.combinedInto}.` : '',
        decision.outputs ? `Split into ${decision.outputs.map(output => output.code).join(' and ')}.` : '',
        decision.raises.length ? `Review new findings: ${decision.raises.join(', ')}.` : '',
      ].filter(Boolean).join(' ')
      : decision?.kind === 'describe' && decision.mileageRecommendation
        ? 'Keep the mileage recommendation from your answers. Payroll setup and tax eligibility still need validation.'
      : decision?.kind === 'name' ? `Accept ${decision.name} for the described payment purpose. No Ready reference, tax treatment or overtime rule is confirmed.`
      : decision?.kind === 'remove' ? 'Remove this code from the setup. Earlier payroll activity is unchanged.'
      : 'More information is needed.'
    return { itemId: entry.itemId, code: findItem(entry.itemId).code, question: entry.question, ready, outcome, assessment, actionable,
      answerText: setup ? callEvidence(findItem(entry.itemId), draft.answers[entry.itemId]).answers.map(answer => answer.answer).join(' — ')
        : [selected?.label, selected?.details ? entry.answer?.details?.[selected.id] : '', entry.answer?.text].filter(Boolean).join(' — ') }
  })
}
export function previewCanApply(session: EarningSession, scoped = false) {
  const draft = previewWorkSession(session)
  if (!scoped && !session.discussionPreview?.setupItems && (!discussionsComplete(session)
    || discussionEntries(session).some(entry =>
      !(session.discussionPreview?.inlineItems ?? session.discussionPreview?.round.itemIds ?? []).includes(entry.itemId)))) return false
  return !!draft && previewItems(session).length > 0 && previewItems(session).every(item => item.ready)
    && canSubmitRound(draft) && reviewPages(draft).flat().every(id => {
      const answer = draft.answers[id] ?? {}
      const decision = decisionFor(findItem(id), answer)
      const deferred = decision?.kind === 'defer' && !!selectedDeferral(answer)?.target
      return deferred || (decision?.kind !== 'describe' || decision.mileageRecommendation === true || checkedTipsForSetupReview(id, answer)) && checksComplete(id, answer)
        && ['ready', 'setupReview'].includes(assessDeferredItem(session, id, answer, !!decision, false).status)
    })
}
export const previewWorkComplete = previewCanApply

/** Includes newly derived questions under their actual owners, not only the original discussion cards. */
export function previewWorkIds(session: EarningSession) {
  const draft = previewWorkSession(session)
  if (!draft) return []
  return reviewPages(draft).flat().filter(id => {
    const original = previewItems(session).find(item => item.itemId === id)
    const answer = draft.answers[id] ?? {}
    const decision = decisionFor(findItem(id), answer)
    if (original) return !original.ready
    if (decision?.kind === 'defer' && selectedDeferral(answer)?.target) return false
    return !decision || !checksComplete(id, answer)
      || !['ready', 'setupReview'].includes(assessDeferredItem(session, id, answer, decision.kind !== 'describe', false).status)
  })
}

function preservesEarlierFacts(session: EarningSession, itemId: string, next: ItemAnswer) {
  const original = session.answers[itemId] ?? {}
  if (session.discussionPreview?.setupItems?.includes(itemId) && legacyDeferredSelection(session, itemId)) {
    // No old response is replayed. New owning controls can fill uncertainty while retaining earlier facts.
    return (!original.choice || original.choice === ASK_CUSTOMER || original.choice === next.choice || next.retain === 'remove')
      && (!original.descriptionSubmitted || !!next.description?.startsWith(original.description ?? ''))
      && Object.entries(original.followUps ?? {}).every(([id, value]) => value === ASK_CUSTOMER || next.followUps?.[id] === value)
      && (original.cell?.entries ?? []).every((entry, index) => JSON.stringify(entry) === JSON.stringify(next.cell?.entries[index]))
      && (original.checkAnswers ?? []).every((entry, index) => JSON.stringify(entry) === JSON.stringify(next.checkAnswers?.[index]))
  }
  const target = session.discussionPreview?.setupItems?.includes(itemId) ? setupReviewTarget(original) : original.explicitDeferral?.target
  if (!target) return !session.resolutions[itemId] // Newly required, separately owned question.
  const same = (left: unknown, right: unknown) => JSON.stringify(left) === JSON.stringify(right)
  if (target.kind === 'choice' && target.stage === 'main' || target.kind === 'description') return true
  if (!same(original.description, next.description) || original.descriptionSubmitted !== next.descriptionSubmitted) return false
  if (target.kind !== 'followUp' && !same(original.followUps, next.followUps)) return false
  if (target.kind === 'followUp' && !Object.entries(original.followUps ?? {}).every(([id, value]) =>
    id === target.id || next.followUps?.[id] === value)) return false
  if (target.kind === 'conditional' && (!original.conditionalReview
    || original.conditionalReview.primary !== next.conditionalReview?.primary
    || !Object.entries(original.conditionalReview.responses).every(([id, value]) =>
      id === target.id || next.conditionalReview?.responses[id] === value))) return false
  if (target.kind === 'cell' && !(original.cell?.entries ?? []).every((entry, index) => same(entry, next.cell?.entries[index]))) return false
  if (target.kind === 'tips' && !(original.tipsReview?.entries ?? []).every((entry, index) => same(entry, next.tipsReview?.entries[index]))) return false
  if (['followUp', 'shared', 'shiftReply', 'shiftDecision', 'retention'].includes(target.kind) && original.choice !== next.choice) return false
  if (!(original.checkAnswers ?? []).every((entry, index) => same(entry, next.checkAnswers?.[index]))) return false
  return true
}

export function editDiscussionWork(session: EarningSession, action: SessionAction): EarningSession {
  const draft = previewWorkSession(session)
  if (!draft || !(['discussionWork', 'discussionReview'].includes(session.step)
    || session.step === 'review' && !!session.discussionPreview?.inlineItems) || !('itemId' in action)
    || !draft.rounds.at(-1)?.itemIds.includes(action.itemId)) return session
  const next = reduceSession(draft, action)
  if (!preservesEarlierFacts(session, action.itemId, next.answers[action.itemId] ?? {})) return session
  // A changed business input invalidates pending/problem presentation, too. A disappearing
  // owning control must not leave its old failure blocking a different, supported choice.
  const input = (answer: ItemAnswer = {}) => {
    const { reviews: _reviews, check: _check, naming: _naming, shiftPremium, cell, ...facts } = answer
    const { checks: _checks, ...cellFacts } = cell ?? {}
    return JSON.stringify([facts, cellFacts, shiftPremium?.thread, shiftPremium?.changed])
  }
  const changed = input(draft.answers[action.itemId]) !== input(next.answers[action.itemId])
  const checks = changed ? Object.fromEntries(Object.entries(session.discussionPreview!.checks ?? {})
    .filter(([key]) => !key.startsWith(`${action.itemId}:`))) : session.discussionPreview!.checks
  return next === draft ? session : { ...session, discussionPreview: { ...session.discussionPreview!,
    answers: next.answers, round: currentRound(next)!, checks, pendingDeferralTarget: next.pendingDeferralTarget } }
}

/** Project only the owning code and recursively raised findings into the existing checked transaction. */
function codeProposal(session: EarningSession, itemId: string): EarningSession | undefined {
  const preview = session.discussionPreview
  if (!previewCurrent(session) || !preview || preview.setupItems
    || !(preview.inlineItems ?? preview.round.itemIds).includes(itemId)) return
  const ids = new Set([itemId])
  for (const id of ids) {
    const decision = decisionFor(findItem(id), preview.answers[id] ?? {})
    if (decision?.kind === 'resolve') for (const raised of decision.raises) {
      if (preview.round.itemIds.includes(raised)) ids.add(raised)
    }
  }
  return { ...session, discussionPreview: { ...preview,
    inlineItems: [...ids], round: { ...preview.round, itemIds: [...ids] },
    answers: { ...session.answers, ...Object.fromEntries([...ids].map(id => [id, preview.answers[id] ?? {}])) },
  } }
}

export function codeApplicationIssue(session: EarningSession, itemId: string): string | undefined {
  const scoped = codeProposal(session, itemId)
  if (!scoped) return 'Finish this answer to see what it means for your setup.'
  const items = previewItems(scoped)
  const own = items.filter(item => item.itemId === itemId)
  if (!own.length) return 'Finish this answer to see what it means for your setup.'
  const unfinished = own.find(item => !item.ready)
  if (unfinished) return unfinished.outcome
  if (!previewCanApply(scoped, true)) return 'Finish the related findings and checks before applying this answer.'
  return undefined
}

export function applyDiscussionCode(session: EarningSession, itemId: string, now: number): EarningSession {
  if (session.step !== 'review' || codeApplicationIssue(session, itemId)) return session
  const scoped = codeProposal(session, itemId)!
  const committed = applyDiscussionReview(scoped, now, true)
  if (committed === scoped) return session
  const preview = session.discussionPreview!
  const applied = new Set(scoped.discussionPreview!.round.itemIds)
  const remaining = preview.round.itemIds.filter(id => !applied.has(id))
  const receipt = committed.discussionApplications!.at(-1)!
  const inlineCard: NonNullable<DiscussionApplication['inlineCard']> = {
    itemId,
    row: cheatSheetGroups(session).flatMap(group => group.rows).find(row => row.id === itemId)!,
    entries: discussionEntries(session).filter(entry => entry.itemId === itemId),
    session: {
      answers: session.answers, resolutions: session.resolutions, rounds: session.rounds,
      discussionAnswers: session.discussionAnswers, discussionPreview: scoped.discussionPreview,
      discussionSummaries: session.discussionSummaries?.[itemId] && session.discussionSummaries[itemId].basis === discussionSummaryBasis(session, itemId)
        ? { [itemId]: session.discussionSummaries![itemId] } : undefined,
      callAnswers: session.callAnswers, paymentReviews: session.paymentReviews,
    },
    outcome: previewItems(scoped).find(entry => entry.itemId === itemId)!.outcome,
  }
  return { ...committed, discussionAcknowledgment: session.discussionAcknowledgment,
    discussionApplications: [...committed.discussionApplications!.slice(0, -1), { ...receipt, inlineCard }],
    discussionPreview: remaining.length ? {
    ...preview, basis: discussionReviewBasis(committed),
    // Keep unrelated mounted checks alive; input basis guards still reject stale results.
    inlineItems: (preview.inlineItems ?? preview.round.itemIds).filter(id => !applied.has(id)),
    answers: { ...preview.answers, ...Object.fromEntries([...applied].map(id => [id, committed.answers[id]])) },
    round: { ...preview.round, number: Math.max(...committed.rounds.map(round => round.number)) + 1, itemIds: remaining },
    checks: Object.fromEntries(Object.entries(preview.checks ?? {}).filter(([key]) => ![...applied].some(id => key.startsWith(`${id}:`)))),
    drafts: Object.fromEntries(Object.entries(preview.drafts ?? {}).filter(([key]) => ![...applied].some(id => key.startsWith(`["${id}",`)))),
    pendingDeferralTarget: preview.pendingDeferralTarget && !applied.has(preview.pendingDeferralTarget.itemId) ? preview.pendingDeferralTarget : undefined,
  } : undefined }
}

export function applyDiscussionReview(session: EarningSession, now: number, scoped = false): EarningSession {
  if (!(session.step === 'discussionReview' || session.step === 'review' && !!session.discussionPreview?.inlineItems)
    || !previewCanApply(session, scoped)) return session
  const preview = session.discussionPreview!
  if (!scoped && session.discussionApplications?.some(receipt => receipt.basis === preview.basis)) return session
  const draft = previewWorkSession(session)!
  // The final route must see prior pending work and the receipt, not this temporary workspace.
  const committed = reduceSession(draft, { type: 'submitRound' }, now, false)
  if (committed === draft || !committed.rounds.find(round => round.number === preview.round.number)?.submitted) return session
  const ids = preview.round.itemIds
  const receipt: DiscussionApplication = {
    id: `discussion:${preview.round.number}:${now}`, round: preview.round.number, at: now, basis: preview.basis,
    originalAnswers: Object.fromEntries(ids.map(id => [id, session.answers[id] ?? {}])),
    responses: Object.fromEntries(ids.map(id => [id, session.discussionAnswers?.[id] ?? {}])),
    outcomes: Object.fromEntries(ids.filter(id => committed.resolutions[id]).map(id => [id, committed.resolutions[id]])),
    originalResolutions: Object.fromEntries(ids.filter(id => session.resolutions[id]).map(id => [id, session.resolutions[id]])),
    appliedAnswers: Object.fromEntries(ids.map(id => [id, committed.answers[id] ?? {}])),
    confirmedAnswers: Object.fromEntries(ids.map(id => [id, callEvidence(findItem(id), committed.answers[id] ?? {}).answers])),
    source: preview.setupItems ? 'setupReview' : 'discussion',
  }
  // Retain pending rounds, exact sent wording, previous responses and later-phase work.
  const priorPending = session.rounds.filter(round => !round.submitted)
  const newRounds = committed.rounds.filter(round => round.number >= preview.round.number)
  const unfinished = [...priorPending, ...newRounds.filter(round => !round.submitted)]
  const pendingIds = [...new Set(unfinished.flatMap(round => round.itemIds))]
    .filter(id => committed.resolutions[id]?.round !== preview.round.number)
  const rounds = [...session.rounds.filter(round => round.submitted), ...newRounds.filter(round => round.submitted)]
  if (pendingIds.length) rounds.push({ number: Math.max(...rounds.map(round => round.number)) + 1, itemIds: pendingIds, submitted: false,
    ...(unfinished.some(round => round.kind === 'added-questions') ? { kind: 'added-questions' as const } : {}) })
  return { ...session, answers: committed.answers, resolutions: committed.resolutions, rounds, updatedAt: now,
    customerQuestions: committed.customerQuestions,
    discussionPreview: undefined, discussionApplications: [...session.discussionApplications ?? [], receipt],
    discussionAcknowledgment: receipt.id, step: 'review' }
}
