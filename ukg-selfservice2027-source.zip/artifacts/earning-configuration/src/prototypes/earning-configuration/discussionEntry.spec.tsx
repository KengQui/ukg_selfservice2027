import { act, useReducer, useRef } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { SessionContext } from './sessionContext'
import { reduceSession, parseSession, type EarningSession, type SessionAction } from './session'
import StepReview from './StepReview'
import StepDiscussionReview from './StepDiscussionReview'
import DiscussionQuestions, { type DiscussionEntryView } from './DiscussionQuestions'
import DiscussionEntryActions from './DiscussionEntryActions'
import { discussionInputComplete, discussionInputIssue, discussionProgress } from './discussionProgress'
import { discussionEntries, discussionsComplete, previewCanApply } from './deferredReview'
import { discussionEntryFixture } from './discussionEntry.testing'
import { saveSession, loadSession, writeWorkingCopy } from './storage'
import { SOMETHING_ELSE } from './somethingElse'
import { earningPages } from '../../askBrytePages'
import { bryteFacts } from './bryteFacts'

vi.mock('@workspace/api-client-react', () => ({
  summarizeEarningDiscussion: vi.fn(() => new Promise(() => {})),
  checkEarningDescription: vi.fn(() => new Promise(() => {})),
  reviewEarningAnswer: vi.fn(() => new Promise(() => {})),
}))
let host: HTMLDivElement
let root: Root | undefined
let latest: EarningSession
let send: (action: SessionAction) => void
const originalScrollIntoView = HTMLElement.prototype.scrollIntoView
function mount(initial = discussionEntryFixture(), entries?: DiscussionEntryView[]) {
  vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT', true)
  HTMLElement.prototype.scrollIntoView = vi.fn()
  host = document.createElement('div'); document.body.append(host); root = createRoot(host)
  function Harness() {
    const [session, dispatch] = useReducer((s: EarningSession, a: SessionAction) => reduceSession(s, a, s.updatedAt + 1), initial)
    const page = useRef<HTMLDivElement>(null)
    latest = session; send = dispatch
    return <SessionContext.Provider value={{ session, dispatch, save: () => true, restart: () => true }}>
      {entries ? <div ref={page}><DiscussionQuestions entries={entries} /><DiscussionEntryActions entries={entries} page={page} /></div>
        : session.step === 'discussionReview' ? <StepDiscussionReview /> : <StepReview />}
    </SessionContext.Provider>
  }
  act(() => root!.render(<Harness />))
}
const el = <T extends HTMLElement = HTMLElement,>(selector: string) => host.querySelector<T>(selector)!
const click = (id: string) => act(() => {
  const node = el(`[data-testid="${id}"]`)
  ;(node.querySelector('label') ?? node).click()
})
const type = (id: string, value: string) => act(() => {
  const field = el<HTMLTextAreaElement>(`[data-testid="discussion-answer-${id}-0"] textarea`)
  field.focus()
  Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')!.set!.call(field, value)
  field.dispatchEvent(new Event('input', { bubbles: true }))
})
const progress = () => el('[data-testid="discussion-entry-progress"]').textContent
const review = () => host.querySelector<HTMLButtonElement>('[data-testid^="button-apply-answer-"]') ?? { disabled: true }
const store = () => {
  const data = new Map<string, string>()
  return { getItem: (key: string) => data.get(key) ?? null, setItem: (key: string, value: string) => { data.set(key, value) },
    removeItem: (key: string) => { data.delete(key) } }
}
afterEach(() => { if (root) act(() => root!.unmount()); root = undefined; host?.remove()
  HTMLElement.prototype.scrollIntoView = originalScrollIntoView
  vi.restoreAllMocks(); vi.unstubAllGlobals() })

describe('deferred answer entry feedback and progress', () => {
  it('does not direct people to an incomplete opening answer when none remain', () => {
    mount(discussionEntryFixture(), [])
    expect(host.querySelector('[data-testid="discussion-entry-progress"]')).toBeNull()
    expect(host.querySelector('[data-testid="button-first-incomplete"]')).toBeNull()
    expect(host.textContent).not.toContain('0 of 0')
    expect(host.textContent).not.toContain('Apply each checked answer')
    expect(host.querySelector('[data-testid="button-continue-optimization"]')).toBeTruthy()
  })
  it('continues to optimization with unanswered questions without applying or discarding them', () => {
    const initial = discussionEntryFixture(['BONREV'])
    initial.registerSource = 'uploads'
    mount(initial, [])
    const before = JSON.stringify([latest.answers, latest.resolutions, latest.discussionApplications])
    expect(el<HTMLButtonElement>('[data-testid="button-continue-optimization"]').disabled).toBe(false)
    click('button-continue-optimization')
    expect(latest.step).toBe('optimization')
    expect(JSON.stringify([latest.answers, latest.resolutions, latest.discussionApplications])).toBe(before)
    expect(parseSession(JSON.stringify(latest))?.step).toBe('optimization')
  })
  it('shows the approved pay code setup copy and keeps Bryte aligned without renaming uploaded evidence', () => {
    mount(discussionEntryFixture())
    const title = 'Let’s fill in the gaps in your pay code setup'
    expect(host.querySelector('h1')?.textContent).toBe(title)
    expect(host.querySelector('.ec-intro')?.textContent?.trim()).toBe('Your answers help us understand how you use each code and identify the right setup. Answer what you can now, and return to anything unfinished later.')
    const page = earningPages.review(bryteFacts(latest).facts)
    expect(page.name).toBe(title)
    expect(page.purpose).toContain(title)
    expect(page.purpose.length).toBeLessThanOrEqual(400)
    expect(earningPages['uploaded-registers']({}).name).toBe('What do we need to review? — uploaded registers')
    expect(host.querySelector('button[aria-label="About the AI summary"]')).not.toBeNull()
    expect(host.querySelector('#review-notes-guidance')?.textContent).toContain('Nothing changes for a code until you select Apply answer.')
  })

  it('opens only completed answers and returns with incomplete choices, text and notes intact', () => {
    const initial = discussionEntryFixture()
    mount(initial)
    const entryAction = () => el<HTMLButtonElement>('[data-testid="button-continue-optimization"]')
    expect(entryAction().disabled).toBe(false)
    expect(host.textContent).toContain('You can continue with questions still open')
    act(() => el<HTMLLabelElement>('[data-testid="discussion-answer-BONREV-0"] label').click())
    click(`choice-discussion-OTPREM-0-${SOMETHING_ELSE}`)
    type('OTPREM', '  ')
    type('SPPAY', '\n ')
    act(() => send({ type: 'setCallAnswer', itemId: 'SPPAY', text: 'Keep these call notes.' }))
    expect(entryAction().disabled).toBe(false)
    const captured = latest.discussionAnswers
    click('button-continue-optimization')
    act(() => send({ type: 'backFromOptimization' }))
    expect(latest.step).toBe('review')
    expect(latest.discussionAnswers).toEqual(captured)
    expect(el<HTMLTextAreaElement>('[data-testid="discussion-answer-OTPREM-0"] textarea').value).toBe('  ')
    expect(el<HTMLTextAreaElement>('[data-testid="discussion-answer-SPPAY-0"] textarea').value).toBe('\n ')
    expect(latest.callAnswers?.SPPAY).toBe('Keep these call notes.')
    type('SPPAY', 'We pay for bilingual customer support.')
    click('button-done-discussion-SPPAY-0')
    expect(el<HTMLButtonElement>('[data-testid="button-apply-answer-SPPAY"]').disabled).toBe(true)
    expect(latest.answers).toEqual(initial.answers)
    expect(latest.resolutions).toEqual(initial.resolutions)
    expect(latest.discussionApplications).toBeUndefined()
  })

  it('excludes notes/history, counts each current question, and keeps capture separate from setup', async () => {
    const initial = discussionEntryFixture()
    mount(initial)
    expect(discussionEntries(initial)).toHaveLength(4)
    expect(progress()).toBe('0 of 4 opening answers entered')
    expect(review().disabled).toBe(true)
    act(() => send({ type: 'setCallAnswer', itemId: 'SPPAY', text: 'Only a note.' }))
    expect(progress()).toBe('0 of 4 opening answers entered')
    click('button-first-incomplete')
    expect(document.activeElement).toBe(el('[data-testid="discussion-answer-BONREV-0"] input'))
    act(() => el<HTMLLabelElement>('[data-testid="discussion-answer-BONREV-0"] label').click())
    expect(progress()).toBe('1 of 4 opening answers entered')
    expect(el('[data-testid="row-cheat-BONREV"] .ec-qcard__sequence-answer')).not.toBeNull()
    expect(latest.answers).toEqual(initial.answers)
    expect(latest.resolutions).toEqual(initial.resolutions)
    click('button-clear-discussion-card-BONREV')
    await act(async () => { await Promise.resolve() })
    expect(progress()).toBe('0 of 4 opening answers entered')
    expect(el('[data-testid="discussion-answer-BONREV-0"]').textContent).not.toContain('Answer entered.')
    expect(document.activeElement).toBe(el('[data-testid="discussion-answer-BONREV-0"] input'))
    // Prove the focus listener is attached after the parent host ref, not only link-click scrolling.
    vi.mocked(HTMLElement.prototype.scrollIntoView).mockClear()
    act(() => el<HTMLTextAreaElement>('[data-testid="discussion-answer-SPPAY-0"] textarea').focus())
    expect(HTMLElement.prototype.scrollIntoView).toHaveBeenCalledWith({ block: 'center', behavior: 'instant' })
    expect(el('.ec-discussion-entry').style.getPropertyValue('--discussion-bar-height')).toBe('0px')
  })

  it('requires choice details, explains whitespace and length, and only announces completion changes', () => {
    mount(discussionEntryFixture(['OTPREM', 'SPPAY']))
    click(`choice-discussion-OTPREM-0-${SOMETHING_ELSE}`)
    expect(host.textContent).toContain('Add details for the answer you selected.')
    click('button-first-incomplete')
    expect(document.activeElement).toBe(el('[data-testid="discussion-answer-OTPREM-0"] textarea'))
    type('OTPREM', '   ')
    expect(progress()).toBe('0 of 2 opening answers entered')
    type('OTPREM', 'We need to confirm this.')
    expect(progress()).toBe('1 of 2 opening answers entered')
    type('SPPAY', '   ')
    expect(progress()).toBe('1 of 2 opening answers entered')
    type('SPPAY', 'x'.repeat(2001))
    expect(progress()).toBe('1 of 2 opening answers entered')
    const field = el('[data-testid="discussion-answer-SPPAY-0"] textarea')
    expect(field.getAttribute('aria-invalid')).toBe('true')
    expect(document.getElementById(field.getAttribute('aria-describedby')!)?.textContent).toContain('2,000')
    for (const control of host.querySelectorAll('[aria-describedby]')) {
      for (const id of control.getAttribute('aria-describedby')!.split(' ')) expect(document.getElementById(id)).not.toBeNull()
    }
    expect(host.textContent).toContain('You can continue with questions still open')
    expect(host.textContent).toContain('Shorten your answer')
    type('SPPAY', 'x'.repeat(2000))
    expect(progress()).toBe('2 of 2 opening answers entered')
    expect(review().disabled).toBe(true)
    expect(host.textContent).toContain('Apply each checked answer in its code card.')
    const status = el('[data-testid="discussion-entry-progress"]')
    const before = status.textContent
    type('SPPAY', 'More complete text.')
    expect(status.textContent).toBe(before)
    expect(el('.ec-cheat__questions').hasAttribute('aria-live')).toBe(false)
    expect(document.activeElement).toBe(field)
    type('SPPAY', '')
    expect(review().disabled).toBe(true)
    expect(progress()).toBe('1 of 2 opening answers entered')
  })

  it('reviews within the card, retains drafts on refresh/save, and commits only on Apply', () => {
    mount(discussionEntryFixture(['BONREV']))
    act(() => el<HTMLLabelElement>('[data-testid="discussion-answer-BONREV-0"] label').click())
    const original = latest
    expect(host.querySelector('h1')?.textContent).toBe('Let’s fill in the gaps in your pay code setup')
    expect(host.querySelector('.ec-intro')?.textContent?.trim()).toBe('Your answers help us understand how you use each code and identify the right setup. Answer what you can now, and return to anything unfinished later.')
    expect(host.querySelector('[data-testid="row-cheat-BONREV"] .ec-setup-summary')).not.toBeNull()
    expect(latest.discussionApplications).toBeUndefined()
    expect(latest.resolutions).toEqual(original.resolutions)
    const proposal = latest.discussionPreview
    expect(progress()).toBe('1 of 1 opening answer entered')
    expect(latest.discussionPreview).toEqual(proposal)
    const stores = { working: store(), saved: store() }
    writeWorkingCopy(stores, latest)
    expect(loadSession(stores).discussionAnswers).toEqual(latest.discussionAnswers)
    expect(saveSession(stores, latest)).toBe(true)
    const restored = loadSession({ working: store(), saved: stores.saved })
    expect(restored.discussionPreview).toEqual(proposal)
    expect(restored.callAnswers).toEqual(latest.callAnswers)
    expect(previewCanApply(latest)).toBe(true)
    click('button-apply-answer-BONREV')
    expect(latest.discussionApplications).toHaveLength(1)
    expect(latest.discussionAcknowledgment).toBe(latest.discussionApplications![0].id)
    expect(parseSession(JSON.stringify(latest))?.discussionApplications).toEqual(latest.discussionApplications)
  })

  it('keeps entered text unassessed until Done and blocks premature Apply', () => {
    mount(discussionEntryFixture(['SPPAY']))
    type('SPPAY', 'Extra pay for project leadership.')
    expect(discussionsComplete(latest)).toBe(true)
    expect(latest.discussionPreview).toBeUndefined()
    click('button-done-discussion-SPPAY-0')
    expect(previewCanApply(latest)).toBe(false)
    expect(el<HTMLButtonElement>('[data-testid="button-apply-answer-SPPAY"]').disabled).toBe(true)
    const before = latest.resolutions
    act(() => send({ type: 'applyDiscussionReview' }))
    expect(latest.resolutions).toEqual(before)
    expect(latest.discussionApplications).toBeUndefined()
  })

  it('counts two questions in one card separately and focuses the incomplete question', () => {
    const entries: DiscussionEntryView[] = [
      { itemId: 'SPPAY', key: 'one', basis: '', question: 'First question?', options: [],
        answer: { question: 'First question?', kind: 'text', text: 'Entered' } },
      { itemId: 'SPPAY', key: 'two', basis: '', question: 'Second question?', options: [] },
    ]
    mount(discussionEntryFixture(['SPPAY']), entries)
    expect(progress()).toBe('1 of 2 opening answers entered')
    click('button-first-incomplete')
    expect(document.activeElement).toBe(el('[data-testid="discussion-answer-SPPAY-1"] textarea'))
  })

  it('shares the gate without treating uncertainty as approval or limiting choice details differently', () => {
    const uncertain = { options: [{ id: 'unsure', label: 'Not sure yet' }],
      answer: { question: 'Question?', kind: 'review-choices' as const, choice: 'unsure' } }
    expect(discussionInputComplete(uncertain)).toBe(true)
    expect(discussionInputIssue({ options: [], answer: { question: '?', kind: 'text', text: ' \n ' } })).toBe('answer')
    expect(discussionProgress([]).complete).toBe(false)
    expect(discussionProgress([uncertain, { options: [] }])).toEqual({ entered: 1, total: 2, remaining: 1, complete: false })
    expect(discussionInputComplete({ options: [{ id: 'other', label: 'Something else', details: true }],
      answer: { question: '?', kind: 'review-choices', choice: 'other', details: { other: 'x'.repeat(2001) } } })).toBe(true)
  })

  it('gives Bryte the current counts and new action within its actual request limits', () => {
    const registration = bryteFacts(discussionEntryFixture())
    expect(registration.key).toBe('review')
    expect(registration.facts).toMatchObject({ deferredInputTotal: 4, deferredInputEntered: 0, deferredInputRemaining: 4 })
    const description = earningPages.review(registration.facts)
    expect(description.name).toBe('Let’s fill in the gaps in your pay code setup')
    const sentLines = description.onScreen.slice(0, 12).map(line => line.slice(0, 200)).join(' ')
    expect(sentLines).toContain('Follow-ups stay in that code’s card without waiting for other cards.')
    expect(sentLines).toContain('Apply answer commits only that code’s checked outcome')
    expect(sentLines).toContain('Uncertainty does not confirm a fact.')
    for (const line of description.onScreen.slice(0, 3)) expect(line.length).toBeLessThanOrEqual(200)
    expect(description.state.join(' ')).toContain('0 of 4 current deferred answers entered; 4 need attention.')
  })
})
