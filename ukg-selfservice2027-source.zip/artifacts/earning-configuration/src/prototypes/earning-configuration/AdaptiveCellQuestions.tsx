import { useContext, useEffect, useRef, useState, type ComponentProps } from 'react'
import { useDiscussionWorkDraft } from './discussionWorkDraft'
import { reviewCellPayment, reviewMileagePayment } from '@workspace/api-client-react'
import { redactSensitive } from '@workspace/setup-shared/ask-bryte'
import { MILEAGE_PREFIX, MILEAGE_POLICY, MILEAGE_BROWSER_DEADLINE_MS } from '@workspace/setup-shared/mileage-policy'
import { activeCellDeferral, isMileage, mileageInput, mileageAssessment } from './mileageQuestions'
import { Button, InlineMessage } from '@ready/dls/compatibility'
import { AILoader } from '@ready/dls/ai'
import QuestionCard, { CardReviewStatus, DiscussionLockedQuestions, QuestionSection } from './QuestionCard'
import { AiQuestionStep } from './AiQuestionStep'
import { DescribeBoxView } from './DescribeAnswerBox'
import ReasonParagraphs from './ReasonParagraphs'
import SetupSummary from './SetupSummary'
import { mileageSetup } from './mileageSetup'
import { ASK_CUSTOMER, findItem } from './sampleRegister'
import type { ItemAnswer } from './session'
import { CELL_OVERVIEW, cellBasis, cellFlowDecision, cellOutstanding, cellRequest, cellNext, paymentOpening, paymentMethod, paymentReadiness, type CellEvent, type CellQuestion } from './cellFlow'
import { mileageRateError, legacyMileageOption } from './mileage'
import { useProposalCheck } from './proposalAssessment'
import CellPaymentInformation from './CellPaymentInformation'
import { DiscussionCompletionSummary, InlineDiscussionCard } from './inlineDiscussionPresentation'
import { useAppliedDiscussion } from './appliedDiscussionPresentation'
import { useMileageSupportingCopy } from './SourceFinding'

const ERROR = 'We can’t check this payment right now. Try again, or select Review later.'
/** Other reimbursement categories keep their existing status presentation. */
function PaymentQuestionStatus({ children, ...props }: ComponentProps<typeof CardReviewStatus>) {
  const inline = useContext(InlineDiscussionCard)
  if (inline) return <CardReviewStatus {...props}>{children}</CardReviewStatus>
  return <QuestionSection {...props} question="" context={children} />
}
function message(error: unknown) {
  if (!error || typeof error !== 'object' || !('data' in error) || !('status' in error)) return ERROR
  const data = error.data as { code?: string; error?: unknown }
  const statuses: Record<string, number> = { invalid_request: 400, rate_limited: 429, unavailable: 502, invalid_response: 502, timed_out: 504 }
  return data?.code && statuses[data.code] === error.status && typeof data.error === 'string' ? data.error : ERROR
}

/** One scoped request per exact snapshot; abort on edits, Defer, dialog close or navigation. */
function useCellCheck(answer: ItemAnswer, onEvent: (event: CellEvent) => void, readOnly: boolean, ownerId: string) {
  const [retry, setRetry] = useState(0)
  const [state, setState] = useState<{ basis: string; error?: string; checking?: boolean }>()
  const callback = useRef(onEvent)
  callback.current = onEvent
  const basis = cellBasis(answer)
  const needed = !readOnly && !answer.cell?.reviewPaused && !activeCellDeferral(answer) && cellNext(answer).kind === 'check'
  const assessment = useProposalCheck(`${ownerId}:payment`, needed ? basis : undefined)
  useEffect(() => {
    if (assessment.readOnly || !needed || assessment.problem) return
    const controller = new AbortController()
    let settled = false
    const timer = isMileage(answer) ? setTimeout(() => {
      if (settled) return
      settled = true
      controller.abort()
      const text = 'Checking this payment took too long. Your answers are kept. Try again, or select Review later.'
      assessment.fail(text)
      setState({ basis, error: text })
    }, MILEAGE_BROWSER_DEADLINE_MS) : undefined
    setState({ basis, checking: true })
    assessment.start()
    const request = isMileage(answer)
      ? reviewMileagePayment(JSON.parse(JSON.stringify(mileageInput(answer), (_key, value: unknown) =>
        typeof value === 'string' ? redactSensitive(value) : value)), { signal: controller.signal })
      : reviewCellPayment(cellRequest(answer), { signal: controller.signal })
    request.then(result => {
      if (controller.signal.aborted) return
      settled = true
      clearTimeout(timer)
      assessment.finish()
      callback.current({ kind: 'checked', basis, result, at: Date.now() })
      setState({ basis })
    }).catch(error => {
      if (!controller.signal.aborted) {
        settled = true
        clearTimeout(timer)
        const original = message(error)
        const text = isMileage(answer)
          ? original.replace(/Try again, or select (?:Defer|Review later)\./g, 'Try again.')
            + (/Your answers (?:are kept|stay saved)/i.test(original) ? '' : ' Your answers are kept.')
          : original
        assessment.fail(text)
        setState({ basis, error: text })
      }
    })
    return () => { settled = true; clearTimeout(timer); controller.abort() }
  }, [basis, needed, retry, ownerId, assessment.readOnly])
  const unusable = needed && state?.basis === basis && !state.error && !state.checking
  useEffect(() => {
    if (unusable && !assessment.problem) {
      const error = 'We couldn’t use this payment check. Try again; your answers are kept.'
      assessment.fail(error)
      if (isMileage(answer)) setState({ basis, error })
    }
  }, [unusable, basis])
  return { checking: needed && !assessment.problem && state?.basis === basis && state.checking,
    error: assessment.problem ?? (needed && state?.basis === basis ? state.error : undefined),
    retry: () => { assessment.finish(); setRetry(n => n + 1) } }
}

function FixedCellQuestion({ question, number, onEvent, deferred, initialValue }: {
  question: CellQuestion; number: number; onEvent: (event: CellEvent) => void; deferred: boolean; initialValue?: string
}) {
  const [choice, setChoice] = useDiscussionWorkDraft(question.question, 'choice', initialValue)
  const [description, setDescription] = useDiscussionWorkDraft(question.question, 'text')
  return <QuestionSection label="CELL" question={question.question} context={question.context}
    selected={choice} defer deferSelected={deferred ? ASK_CUSTOMER : choice}
    onDeferSelect={value => onEvent({ kind: 'defer', checked: value === ASK_CUSTOMER })}
    options={question.options?.map(option => ({ id: option.id, title: option.label, subHeading: option.detail, example: option.example,
      ...(option.id === 'other' ? { discussionDetails: true, content: <DescribeBoxView description={description} submitted={false} onChange={setDescription}
        onEdit={() => undefined} onDone={() => onEvent({ kind: 'answer', id: question.id, value: 'other', text: description })} /> } : {}),
    }))}
    onSelect={value => {
      setChoice(value)
      if (value !== 'other') onEvent({ kind: 'answer', id: question.id, value })
    }}
    sequenceStep={{ number, state: 'current' }} />
}

export default function AdaptiveCellQuestions({ answer, label = 'CELL', sourceItemId = 'CELL-purpose', onEvent, onClearAnswers, lockedIds = [], readOnly = false }: {
  answer: ItemAnswer; label?: string; onEvent: (event: CellEvent) => void; onClearAnswers?: () => void
  lockedIds?: string[]; readOnly?: boolean; sourceItemId?: string
}) {
  const lockedQuestions = useContext(DiscussionLockedQuestions)
  const completionOwnedByDiscussion = useContext(DiscussionCompletionSummary)
  const appliedDiscussion = useAppliedDiscussion()
  const mileageSupportingCopy = useMileageSupportingCopy()
  lockedIds = [...lockedIds, ...(answer.cell?.entries ?? []).filter(entry => Object.hasOwn(lockedQuestions, entry.question)).map(entry => entry.id)]
  const check = useCellCheck(answer, onEvent, readOnly, sourceItemId)
  const [methodDraft, setMethodDraft] = useDiscussionWorkDraft(paymentOpening(answer).question, 'choice')
  const sourceItem = findItem(sourceItemId)
  const earlierChoice = legacyMileageOption(sourceItem, answer.cell?.earlier?.choice)
    ?? (sourceItem.type === 'clarification' ? sourceItem.options.find(o => o.id === answer.cell?.earlier?.choice) : undefined)
  const [description, setDescription] = useDiscussionWorkDraft(paymentOpening(answer).question, 'text')
  const entries = answer.cell?.entries ?? []
  const historicalMileage = isMileage(answer) && readOnly && answer.cell?.policy !== MILEAGE_POLICY
  const opening = historicalMileage && entries[0] ? entries[0] : paymentOpening(answer)
  const method = entries.find(e => e.id === opening.id)
  const methodValue = historicalMileage ? method?.value : paymentMethod(answer)
  const next = cellNext(answer)
  const open = activeCellDeferral(answer) ?? (next.kind === 'question' ? next.question : undefined)
  const outstanding = cellOutstanding(answer)
  const decision = cellFlowDecision(answer)
  const setup = mileageSetup(answer)
  const mileageSummary = isMileage(answer) ? mileageAssessment(answer)?.customerSummary : undefined
  const Status = isMileage(answer) ? CardReviewStatus : PaymentQuestionStatus
  const completedEntries = entries.filter(e => e.id !== opening.id && (readOnly || e.id !== open?.id))
  const deferred = !!activeCellDeferral(answer)
  const methodLocked = readOnly || lockedIds.includes(opening.id)
  const selected = methodDraft || methodValue
  const deferSelect = (value: string) => onEvent({ kind: 'defer', checked: value === ASK_CUSTOMER })
  return <QuestionCard label={label} sourceItemId={sourceItemId} question={opening.question} variant="misclassification"
    suppressSourceFinding={isMileage(answer) && !historicalMileage && !appliedDiscussion}
    introduction={isMileage(answer) && !historicalMileage ? appliedDiscussion ? MILEAGE_PREFIX : mileageSupportingCopy : undefined}
    headingAction={sourceItemId === 'CELL-purpose' && (!answer.reimbursement || answer.reimbursement.category === 'CELL')
      ? <CellPaymentInformation /> : undefined}
    knownFact={isMileage(answer) ? undefined : <p className="ec-qcard__prompt">{answer.reimbursement
      ? 'overview' in sourceItem && sourceItem.overview ? sourceItem.overview
        : 'Confirm how this payment works so the remaining business, tax and setup decisions can be reviewed separately.'
       : CELL_OVERVIEW}</p>} why={<ReasonParagraphs text={opening.context} />}
    answered={!!decision} onClearAnswers={onClearAnswers ? () => {
      setMethodDraft(''); setDescription(''); onClearAnswers()
    } : undefined} disabled={methodLocked}
    defer={!readOnly && !methodValue}
    selected={!methodValue && deferred ? ASK_CUSTOMER : selected}
    options={opening.options!.map(option => ({
      id: option.id, title: option.label, subHeading: option.detail, example: 'example' in option ? option.example : undefined,
      ...(option.id === 'other' ? { discussionDetails: true, content: method?.value === 'other'
        ? methodLocked ? <p className="ec-qcard__prompt">{method.answer}</p>
          : <DescribeBoxView description={method.answer} submitted onChange={() => undefined} onDone={() => undefined}
             onEdit={() => { onEvent({ kind: 'change', id: opening.id }); setMethodDraft('other'); setDescription(method.answer) }} />
        : <DescribeBoxView description={description} submitted={false} onChange={setDescription} onEdit={() => undefined}
           onDone={() => { onEvent({ kind: 'answer', id: opening.id, value: 'other', text: description }); setMethodDraft('') }} /> } : {}),
    }))}
    onSelect={value => {
      if (value === ASK_CUSTOMER || value === '') { deferSelect(value); return }
      if (method) onEvent({ kind: 'change', id: opening.id })
      setDescription('')
      setMethodDraft(value)
      if (value !== 'other') { onEvent({ kind: 'answer', id: opening.id, value }); setMethodDraft('') }
    }}
     beforeFollowUps={isMileage(answer) && answer.cell?.earlier && <details className="ec-asking"><summary>Earlier mileage answers</summary>
         <div className="ec-asking__body">
           <p>These answers are kept with their earlier wording. They do not answer the new purpose question or confirm tax treatment.</p>
           {(answer.cell.earlier.cell?.entries ?? []).map(e => <p key={e.id}><strong>{e.question}</strong> {e.answer}</p>)}
            {!answer.cell.earlier.cell?.entries.length && earlierChoice && <p>{earlierChoice.label}</p>}
            {!answer.cell.earlier.cell?.entries.length && mileageInput(answer).historicalAnswers.map(e =>
              <p key={e.id}><strong>{e.question}</strong> {e.answer}</p>)}
         </div>
       </details>}
     followUpSequenceCount={completedEntries.length + (!readOnly && open && open.id !== opening.id ? 1 : 0)}
     followUpSequence={(methodValue || historicalMileage) && (completedEntries.length > 0 || !readOnly && open && open.id !== opening.id) ? <>
      {completedEntries.map((entry, index) => <AiQuestionStep key={entry.id} question={entry.question} format={{ kind: 'text' }}
        number={index + 1} answered={entry.answer} continues
        onChange={!readOnly && !lockedIds.includes(entry.id) ? () => onEvent({ kind: 'change', id: entry.id }) : undefined} />)}
       {!readOnly && open && open.id !== opening.id && (open.options
        ? <FixedCellQuestion key={`${open.id}-${entries.length}`} question={open} number={completedEntries.length + 1} onEvent={onEvent} deferred={deferred} />
        : <AiQuestionStep key={`${open.id}-${entries.length}`} question={open.question} context={open.context} format={open.format ?? { kind: 'text' }}
          number={completedEntries.length + 1} onAnswer={text => {
            if (open.id === 'company-rate' && mileageRateError(text)) { setDescription(mileageRateError(text)!); return }
            setDescription(''); onEvent({ kind: 'answer', id: open.id, value: text })
          }}
          defer deferSelected={deferred ? ASK_CUSTOMER : undefined} onDeferSelect={deferSelect} />)}
      </> : undefined}
     followUps={(methodValue || historicalMileage) && <>
      {open?.id === 'company-rate' && description && <p role="alert">{description}</p>}
       {(!readOnly || setup || isMileage(answer) && !historicalMileage) && (!open || historicalMileage && setup) && <Status
        deferredQuestion={outstanding ? { question: outstanding.question,
          choices: outstanding.options?.map(option => [option.label, option.detail, option.example].filter(Boolean).join(' — '))
            ?? (outstanding.format?.kind === 'choices' ? outstanding.format.options : []) } : undefined}
         defer={!!outstanding && !readOnly && !setup?.confirmed} selected={deferred ? ASK_CUSTOMER : undefined} onSelect={deferSelect}
       >
          {check.checking && <div role="status">We’re checking the missing payment facts <AILoader /></div>}
      {answer.cell?.reviewPaused ? <p role="status">Payment check left for later. Your answers are kept. <Button variant="secondary" size="small" onClick={() => { onEvent({ kind: 'recheck' }); check.retry() }}>Resume review</Button></p>
        : check.error && <><InlineMessage theme="error">{check.error}</InlineMessage><Button variant="secondary" size="small" onClick={check.retry}>Try again</Button>
          {isMileage(answer) && !readOnly && <Button variant="secondary" size="small" onClick={() => onEvent({ kind: 'pauseReview' })}>Review later</Button>}</>}
           {next.kind === 'pending' && <>{isMileage(answer)
              ? mileageSummary ? <SetupSummary code={label} summary={mileageSummary} /> : null
              : <p role="status">{paymentReadiness(answer)}. {next.reason}</p>}
              {!readOnly && <Button variant="secondary" size="small" onClick={() => onEvent({ kind: 'recheck' })}>Try again</Button>}</>}
          {setup ? <SetupSummary code={label} summary={`${setup.summary}${setup.confirmed ? ' Previously confirmed in this review.' : ''}`} />
          : next.kind === 'done' && !completionOwnedByDiscussion && (isMileage(answer) ? mileageSummary
            ? <SetupSummary code={label} summary={mileageSummary} /> : null : <p role="status">{decision?.kind === 'resolve'
            ? 'The intended tax treatment is confirmed for this review. Apply your answers to use the proposed CELL setup.'
            : decision?.kind === 'defer' ? 'Tax treatment is pending confirmation. Your other answers stay saved, and you can continue with other codes.'
              : `${paymentReadiness(answer)}. The payment facts and intended treatment are saved. The applicable setup still needs verification; no separate codes have been created.`}</p>)}
       </Status>}
     </>} />
}
