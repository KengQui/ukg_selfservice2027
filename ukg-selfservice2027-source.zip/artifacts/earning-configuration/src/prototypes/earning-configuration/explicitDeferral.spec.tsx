import { act, useReducer } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { ItemQuestion } from './StepQuestions'
import StepReview from './StepReview'
import AppliedReviewQuestions from './AppliedReviewQuestions'
import { SessionContext } from './sessionContext'
import { ASK_CUSTOMER, findItem } from './sampleRegister'
import { createSession, reduceSession, parseSession, namingBasis, type EarningSession, type SessionAction } from './session'
import { pendingDiscussionQuestions } from './reviewDiscussionChoices'
import { customerDraftBasis } from './customerQuestionData'
import { deferralBasis } from './explicitDeferral'
import { saveSession, loadSession, type SessionStores } from './storage'
import { cellNext, cellOutstanding, paymentOpening } from './cellFlow'
import { reimbursementAnswer } from './reimbursements'
import { cellChecked, cellResult, fixedBusiness } from './cellFlow.testing'

vi.mock('@workspace/api-client-react', () => ({
  draftEarningCustomerQuestions: vi.fn(),
  reviewCellPayment: vi.fn(() => new Promise(() => {})),
  checkEarningDescription: vi.fn(() => new Promise(() => {})),
}))

let host: HTMLDivElement
let root: Root | undefined
let latest: EarningSession
let dispatch: (action: SessionAction) => void
function mount(itemId: string, initial: EarningSession) {
  vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT', true)
  host = document.createElement('div')
  document.body.append(host)
  root = createRoot(host)
  function App() {
    const [session, send] = useReducer((state: EarningSession, action: SessionAction) => reduceSession(state, action, 2), initial)
    latest = session
    dispatch = send
    return <SessionContext.Provider value={{ session, dispatch: send, save: () => true, restart: () => true }}>
      {session.appliedReview ? <AppliedReviewQuestions /> : session.step === 'review' ? <StepReview />
        : <ItemQuestion item={findItem(itemId)} label={itemId} answer={session.answers[itemId] ?? {}} />}
    </SessionContext.Provider>
  }
  act(() => root!.render(<App />))
}
function open(itemId: string): EarningSession {
  return { ...createSession(1), step: 'questions', files: [],
    rounds: [{ number: 2, itemIds: [itemId], submitted: false }] }
}
function defer() { act(() => host.querySelector<HTMLInputElement>('.ec-defer input')!.click()) }
function send(action: SessionAction) { act(() => dispatch(action)) }
function unmount() {
  if (root) act(() => root!.unmount())
  root = undefined
  host?.remove()
}
afterEach(() => { unmount(); vi.unstubAllGlobals() })

describe('explicit question selection through real Defer controls and session actions', () => {
  it('fills only the Special Pay description from its phone button without submitting or reviewing it', () => {
    mount('SPPAY', open('SPPAY'))
    const button = host.querySelector<HTMLButtonElement>('[data-testid="button-demo-answer-SPPAY"]')!
    expect(button.closest('.ec-qcard__heading')).not.toBeNull()
    act(() => button.click())
    expect(host.querySelector<HTMLTextAreaElement>('textarea')?.value).toBe(
      'A monthly stipend for employees who use a second language with customers')
    expect(latest.answers.SPPAY.descriptionSubmitted).not.toBe(true)
    expect(latest.answers.SPPAY.check).toBeUndefined()
    expect(latest.answers.SPPAY.explicitDeferral).toBeUndefined()
    expect(latest.rounds[0].submitted).toBe(false)
    unmount()
    mount('MISC7', open('MISC7'))
    expect(host.querySelector('[data-testid="button-demo-answer-SPPAY"]')).toBeNull()
  })

  it('keeps Special Pay’s open-ended Answer after real Defer, Apply, navigation and saved-only restoration', () => {
    mount('SPPAY', open('SPPAY'))
    defer()
    const selection = structuredClone(latest.answers.SPPAY.explicitDeferral)
    expect(selection?.question).toBe('What does Special Pay pay for?')
    expect(selection?.choices).toEqual([])
    send({ type: 'submitRound' })
    const original = structuredClone({ answers: latest.answers, resolutions: latest.resolutions,
      customerQuestions: latest.customerQuestions, rounds: latest.rounds })
    const type = (text: string) => act(() => {
      const field = host.querySelector<HTMLTextAreaElement>('.ec-discussion__response textarea')!
      Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')!.set!.call(field, text)
      field.dispatchEvent(new Event('input', { bubbles: true }))
    })
    expect(host.querySelector('.ec-discussion__response label')?.textContent).toBe('Answer')
    expect(host.querySelectorAll('input[type="radio"]')).toHaveLength(0)
    type('A stipend for using a second language.')
    send({ type: 'viewAppliedReview' })
    send({ type: 'closeAppliedReview' })
    expect(host.querySelector<HTMLTextAreaElement>('textarea')?.value).toBe('A stipend for using a second language.')
    const store = () => {
      const data = new Map<string, string>()
      return { getItem: (key: string) => data.get(key) ?? null,
        setItem: (key: string, value: string) => { data.set(key, value) }, removeItem: (key: string) => { data.delete(key) } }
    }
    const stores: SessionStores = { saved: store(), working: store() }
    expect(saveSession(stores, latest)).toBe(true)
    const restored = loadSession({ ...stores, working: store() })
    unmount()
    mount('SPPAY', restored)
    expect(host.querySelector<HTMLTextAreaElement>('textarea')?.value).toBe('A stipend for using a second language.')
    act(() => host.querySelector<HTMLButtonElement>('[data-testid="button-clear-discussion-SPPAY-0"]')!.click())
    expect(host.querySelector<HTMLTextAreaElement>('textarea')?.value).toBe('')
    expect({ answers: latest.answers, resolutions: latest.resolutions,
      customerQuestions: latest.customerQuestions, rounds: latest.rounds }).toEqual(original)
  })

  it('recovers older Special Pay only after explicitly selecting its question through Back', () => {
    const state = open('SPPAY')
    state.answers.SPPAY = { choice: ASK_CUSTOMER }
    const applied = reduceSession(state, { type: 'submitRound' }, 2)
    applied.callAnswers = { SPPAY: 'Keep the earlier note.' }
    applied.discussionAnswers = { SPPAY: { old: {
      question: 'Earlier special pay question?', kind: 'text', text: 'Keep the earlier reply.',
    } } }
    const original = structuredClone(applied)
    mount('SPPAY', parseSession(JSON.stringify(applied))!)
    expect(host.querySelector('textarea')).toBeNull()
    expect(host.textContent).toContain('Use Back')
    act(() => [...host.querySelectorAll<HTMLButtonElement>('button')].find(button => button.textContent === 'Back')!.click())
    expect(host.textContent).toContain('What does Special Pay pay for?')
    defer()
    send({ type: 'closeAppliedReview' })
    expect(host.querySelector('.ec-discussion__response label')?.textContent).toBe('Answer')
    expect(host.querySelector('.ec-discussion__history')?.textContent).toContain('Keep the earlier reply.')
    expect(latest.resolutions).toEqual(original.resolutions)
    expect(latest.callAnswers).toEqual(original.callAnswers)
    expect(latest.discussionAnswers).toEqual(original.discussionAnswers)
    expect(latest.customerQuestions).toEqual(original.customerQuestions)
    expect(latest.rounds).toEqual(original.rounds)
    const { explicitDeferral: _selection, ...answer } = latest.answers.SPPAY
    expect(answer).toEqual(original.answers.SPPAY)
  })

  it('rejects inferred, off-page, historical and changed-question recovery without editing saved answers', () => {
    const state = open('SPPAY')
    state.answers.SPPAY = { choice: ASK_CUSTOMER }
    const applied = reduceSession(state, { type: 'submitRound' }, 2)
    const view = reduceSession(applied, { type: 'viewAppliedReview' }, 3)
    const action: SessionAction = { type: 'selectDeferredQuestion', itemId: 'SPPAY',
      source: { question: 'What does Special Pay pay for?', choices: [] } }
    expect(reduceSession(applied, action)).toBe(applied)
    expect(reduceSession(view, { ...action, source: { question: 'A different question?', choices: [] } })).toBe(view)
    expect(reduceSession(view, { ...action, source: { question: action.source!.question, choices: ['Shift pay'] } })).toBe(view)
    for (const history of [
      { sppayFromAiQuestions: true as const },
      { customerReplies: { 'classification:SPPAY': { answer: 'Earlier reply', text: 'Earlier reply', at: 1 } } },
      { answers: { SPPAY: {} } },
    ]) {
      const historical = { ...view, ...history }
      expect(reduceSession(historical, action)).toBe(historical)
    }
  })

  it('applies only the selected follow-up, preserves the answered opening, saves and reopens choices without preselection', () => {
    mount('TIPS', open('TIPS'))
    send({ type: 'choose', itemId: 'TIPS', choice: 'multiple' })
    const followUp = host.querySelector('.ec-qcard__section h3')!.textContent!
    const choices = [...host.querySelectorAll('.ec-qcard__section .sc__title')].map(node => node.textContent!)
    defer()
    expect(latest.answers.TIPS.choice).toBe('multiple')
    expect(latest.answers.TIPS.explicitDeferral?.question).toBe(followUp)
    send({ type: 'submitRound' })
    expect(latest.step).toBe('review')
    expect(pendingDiscussionQuestions(latest, 'TIPS').map(entry => entry.question)).toEqual([followUp])
    expect(host.querySelectorAll('.ec-discussion__response')).toHaveLength(1)
    expect(host.querySelectorAll('.ec-discussion__response input:checked')).toHaveLength(0)
    if (choices.length) expect(pendingDiscussionQuestions(latest, 'TIPS')[0].options.map(option => option.label.split(' — ')[0])).toEqual(choices)
    const store = () => {
      const data = new Map<string, string>()
      return { getItem: (key: string) => data.get(key) ?? null,
        setItem: (key: string, value: string) => { data.set(key, value) }, removeItem: (key: string) => { data.delete(key) } }
    }
    const stores: SessionStores = { saved: store(), working: store() }
    expect(saveSession(stores, latest)).toBe(true)
    const restored = loadSession({ ...stores, working: store() })
    expect(pendingDiscussionQuestions(restored, 'TIPS')).toEqual(pendingDiscussionQuestions(latest, 'TIPS'))
    unmount()
    mount('TIPS', restored)
    expect(host.querySelectorAll('.ec-discussion__response')).toHaveLength(1)
    expect(host.querySelectorAll('input:checked')).toHaveLength(0)
  })

  it('does not replace an opening Defer with a stale AI check or expand a saved draft', () => {
    const state = open('TIPS')
    state.answers.TIPS = { check: { basis: 'stale', at: 1,
      result: { kind: 'needsInformation', question: 'Which other department uses a different calculation?' } } }
    mount('TIPS', state)
    defer()
    send({ type: 'submitRound' })
    const selected = pendingDiscussionQuestions(latest, 'TIPS')
    expect(selected[0].question).toBe(findItem('TIPS').question)
    const saved = latest.customerQuestions[0]
    const withDraft: EarningSession = { ...latest, customerQuestions: [{ ...saved,
      draft: { basis: customerDraftBasis(latest.answers.TIPS),
        questions: [selected[0].question, 'Which other department needs a different code?'],
        reason: 'Which other department needs a different code?', answerKinds: ['text', 'text'] } }] }
    unmount()
    mount('TIPS', parseSession(JSON.stringify(withDraft))!)
    expect(host.querySelectorAll('.ec-discussion__response')).toHaveLength(1)
    expect(host.textContent).not.toContain('Which other department needs a different code?')
    expect(latest.customerQuestions[0].draft).toEqual(withDraft.customerQuestions[0].draft)
  })

  it('clears selection and never revives it after the underlying answer or AI question changes', () => {
    mount('TIPS', open('TIPS'))
    defer()
    expect(latest.answers.TIPS.explicitDeferral).toBeDefined()
    defer()
    expect(latest.answers.TIPS.explicitDeferral).toBeUndefined()
    defer()
    send({ type: 'choose', itemId: 'TIPS', choice: 'multiple' })
    expect(latest.answers.TIPS.explicitDeferral).toBeUndefined()
    send({ type: 'choose', itemId: 'TIPS', choice: ASK_CUSTOMER })
    send({ type: 'submitRound' })
    expect(pendingDiscussionQuestions(latest, 'TIPS')).toEqual([])
  })

  it('records only the live AI follow-up and keeps its actual choices', () => {
    const state = open('SPPAY')
    const answer = { description: 'A separate company payment', descriptionSubmitted: true }
    state.answers.SPPAY = { ...answer, check: { basis: namingBasis(answer), at: 1,
      result: { kind: 'needsInformation', question: 'How is this payment calculated?',
        format: { kind: 'choices', options: ['Actual expenses', 'A set amount'] } } } }
    mount('SPPAY', state)
    defer()
    expect(latest.answers.SPPAY.explicitDeferral?.question).toBe('How is this payment calculated?')
    expect(latest.answers.SPPAY.description).toBe(answer.description)
    expect(latest.answers.SPPAY.check).toEqual(state.answers.SPPAY.check)
    send({ type: 'submitRound' })
    expect(pendingDiscussionQuestions(latest, 'SPPAY')).toHaveLength(1)
    expect(pendingDiscussionQuestions(latest, 'SPPAY')[0].options.map(option => option.label)).toContain('Actual expenses')
    expect(host.querySelectorAll('.ec-discussion__response')).toHaveLength(1)
    expect(host.querySelectorAll('input:checked')).toHaveLength(0)
  })

  it.each(['CELL-purpose', 'MILEAGE'])('records the exact adaptive %s question, not its replacement or opening', itemId => {
    const state = open(itemId)
    if (itemId === 'MILEAGE') state.answers[itemId] = { choice: 'per-mile' }
    mount(itemId, state)
    send({ type: 'cell', itemId, event: { kind: 'answer', id: 'method', value: 'allowance' } })
    const payment = reimbursementAnswer(findItem(itemId), latest.answers[itemId]) ?? latest.answers[itemId]
    const outstanding = cellOutstanding(payment)
    if (!outstanding) throw Error('Missing actionable payment question')
    expect(outstanding.question).not.toBe(paymentOpening(payment).question)
    defer()
    const source = latest.answers[itemId].explicitDeferral!
    expect(source.question).toBe(outstanding.question)
    expect(source.basis).toBe(deferralBasis(latest.answers[itemId]))
    send({ type: 'submitRound' })
    expect(pendingDiscussionQuestions(latest, itemId)).toHaveLength(1)
    expect(pendingDiscussionQuestions(latest, itemId)[0].question).toBe(source.question)
    const restored = parseSession(JSON.stringify(latest))!
    expect(pendingDiscussionQuestions(restored, itemId)).toEqual(pendingDiscussionQuestions(latest, itemId))
  })

  it('does not authorize other unanswered questions or a code with an inferred customer answer', () => {
    const state = open('TIPS')
    state.rounds[0].itemIds.push('SPPAY')
    state.answers.SPPAY = { choice: ASK_CUSTOMER }
    mount('TIPS', state)
    defer()
    send({ type: 'submitRound' })
    expect(latest.resolutions.SPPAY.status).toBe('customer')
    expect(pendingDiscussionQuestions(latest, 'SPPAY')).toEqual([])
    expect(host.querySelectorAll('.ec-discussion__response')).toHaveLength(1)
    expect(host.querySelector('[data-testid="row-cheat-SPPAY"]')).toBeNull()
  })

  it('records a related-code section on its own code, not on the parent card', () => {
    mount('TIPS', open('TIPS'))
    send({ type: 'choose', itemId: 'TIPS', choice: 'paid-and-reported' })
    const question = host.querySelector('.ec-qcard__section h3')!.textContent!
    defer()
    expect(latest.answers.TIPS.choice).toBe('paid-and-reported')
    expect(latest.answers.TIPS.explicitDeferral).toBeUndefined()
    expect(latest.answers['TIPS RPT'].explicitDeferral?.question).toBe(question)
    send({ type: 'submitRound' })
    expect(latest.resolutions.TIPS.status).toBe('resolved')
    expect(pendingDiscussionQuestions(latest, 'TIPS')).toEqual([])
    expect(pendingDiscussionQuestions(latest, 'TIPS RPT')[0].question).toBe(question)
    expect(host.querySelectorAll('.ec-discussion__response')).toHaveLength(1)
  })

  it.each(['check', 'pending'] as const)('keeps the exact adaptive question selected while payment review is %s through Apply and save/reopen', stage => {
    const state = open('CELL-purpose')
    state.answers['CELL-purpose'] = stage === 'check' ? fixedBusiness()
      : cellChecked(fixedBusiness(), cellResult('pending', 'payment'))
    expect(cellNext(state.answers['CELL-purpose']).kind).toBe(stage)
    const outstanding = cellOutstanding(state.answers['CELL-purpose'])
    if (!outstanding) throw Error('Missing actionable CELL question')
    const earlier = structuredClone(state.answers['CELL-purpose'].cell!.entries)
    mount('CELL-purpose', state)
    // This is the real check/status-only section, whose heading is intentionally empty.
    expect([...host.querySelectorAll('.ec-qcard__section h3')].some(node => !node.textContent)).toBe(true)
    defer()
    expect(latest.answers['CELL-purpose'].explicitDeferral?.question).toBe(outstanding.question)
    expect(latest.answers['CELL-purpose'].cell!.deferred?.question).toBe(outstanding.question)
    expect(latest.answers['CELL-purpose'].cell!.entries).toEqual(earlier)
    send({ type: 'submitRound' })
    expect(latest.step).toBe('review')
    expect(pendingDiscussionQuestions(latest, 'CELL-purpose')).toEqual([{ question: outstanding.question, options: [] }])
    expect(host.querySelectorAll('.ec-discussion__response')).toHaveLength(1)
    expect(host.querySelector('.ec-discussion__response textarea')).not.toBeNull()
    const store = () => {
      const data = new Map<string, string>()
      return { getItem: (key: string) => data.get(key) ?? null,
        setItem: (key: string, value: string) => { data.set(key, value) }, removeItem: (key: string) => { data.delete(key) } }
    }
    const stores: SessionStores = { saved: store(), working: store() }
    expect(saveSession(stores, latest)).toBe(true)
    const restored = loadSession({ ...stores, working: store() })
    expect(pendingDiscussionQuestions(restored, 'CELL-purpose')).toEqual(pendingDiscussionQuestions(latest, 'CELL-purpose'))
    unmount()
    mount('CELL-purpose', restored)
    expect(host.querySelectorAll('.ec-discussion__response')).toHaveLength(1)
    expect(host.querySelector('.ec-cheat__lines')?.textContent).toContain(outstanding.question)
    expect(latest.answers['CELL-purpose'].cell!.entries).toEqual(earlier)
  })

  it('invalidates a selected AI follow-up when the check moves to another question', () => {
    const state = open('SPPAY')
    const answer = { description: 'A separate company payment', descriptionSubmitted: true }
    state.answers.SPPAY = { ...answer, check: { basis: namingBasis(answer), at: 1,
      result: { kind: 'needsInformation', question: 'How is this payment calculated?' } } }
    mount('SPPAY', state)
    defer()
    expect(latest.answers.SPPAY.explicitDeferral?.question).toBe('How is this payment calculated?')
    send({ type: 'answerCheckQuestion', itemId: 'SPPAY', answer: 'A set amount each month.' })
    send({ type: 'checkDescription', itemId: 'SPPAY', basis: namingBasis(latest.answers.SPPAY),
      result: { kind: 'needsInformation', question: 'Who receives this payment?' } })
    expect(latest.answers.SPPAY.check?.result).toEqual({ kind: 'needsInformation', question: 'Who receives this payment?' })
    expect(latest.answers.SPPAY.explicitDeferral).toBeUndefined()
  })

  it('keeps older customer statuses, historical deferrals and their answers without authorizing any current question', () => {
    const session: EarningSession = { ...open('TIPS'), step: 'review',
      rounds: [{ number: 2, itemIds: ['TIPS', 'CELL-purpose'], submitted: true, results: { resolved: [], deferred: ['TIPS', 'CELL-purpose'], findings: [] } }],
      answers: { TIPS: { choice: ASK_CUSTOMER }, 'CELL-purpose': { choice: ASK_CUSTOMER, cellLegacy: true } },
      resolutions: { TIPS: { status: 'customer', round: 2 }, 'CELL-purpose': { status: 'customer', round: 2 } },
      discussionAnswers: { TIPS: { old: { question: 'Earlier tips question?', kind: 'text', text: 'Keep this earlier answer.' } } },
      callAnswers: { TIPS: 'Keep this note.' } }
    mount('TIPS', parseSession(JSON.stringify(session))!)
    expect(host.querySelectorAll('.ec-discussion__response')).toHaveLength(0)
    expect(host.querySelector('[data-testid="row-cheat-TIPS"]')).toBeNull()
    expect(latest.discussionAnswers).toEqual(session.discussionAnswers)
    expect(latest.callAnswers).toEqual(session.callAnswers)
    expect(latest.resolutions.TIPS).toEqual(session.resolutions.TIPS)
  })
})
