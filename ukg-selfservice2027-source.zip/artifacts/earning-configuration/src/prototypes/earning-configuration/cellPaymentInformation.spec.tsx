import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { reviewCellPayment } from '@workspace/api-client-react'
import AdaptiveCellQuestions from './AdaptiveCellQuestions'
import CellQuestions from './CellQuestions'
import QuestionCard, { DiscussionLockedQuestions } from './QuestionCard'
import { DiscussionWorkDraftContext } from './discussionWorkDraft'
import { ExplicitDeferralContext } from './explicitDeferral'
import { SessionContext } from './sessionContext'
import { CELL_OPENING, CELL_OVERVIEW, CELL_REASON, cellRequest, reduceCell } from './cellFlow'
import { cellPick, cellSession, readyCell } from './cellFlow.testing'
import { customerQuestionList } from './summary'
import { SAVED_COPY_KEY, WORKING_COPY_KEY } from './storage'
import type { ItemAnswer } from './session'
import type { ReimbursementCategory } from './reimbursementPolicy'

vi.mock('@workspace/api-client-react', async original => ({
  ...await original<typeof import('@workspace/api-client-react')>(), reviewCellPayment: vi.fn(),
}))

const TITLE = 'About cellphone payments'
const ROWS = [
  ['Configuration Conditions', 'Determine whether payments are fixed allowances, actual business expense reimbursements, or both, and evaluate applicable tax treatment.'],
  ['Required Clarification', 'Determine how CELL payments are calculated, their business purpose, and whether relevant reimbursement requirements are met.'],
  ['Decision Criteria', 'Apply the approved taxable or nontaxable mapping based on the verified facts and applicable rules.'],
  ['Configuration Verification', 'Confirm the selected Ready earning code, Roll-Up Type, tax setup, and actual payroll results.'],
]
const closing = 'The AI can then generate different customer-friendly questions depending on what information it already has.'

describe('CELL opening information', () => {
  let host: HTMLDivElement, root: Root
  beforeEach(() => {
    vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT', true)
    vi.stubGlobal('fetch', vi.fn())
    vi.mocked(reviewCellPayment).mockReset()
    host = document.createElement('div')
    document.body.append(host)
    root = createRoot(host)
  })
  afterEach(() => {
    act(() => root.unmount())
    host.remove()
    vi.restoreAllMocks()
    localStorage.clear()
    sessionStorage.clear()
    vi.unstubAllGlobals()
  })

  function mount(answer: ItemAnswer = {}, props: { readOnly?: boolean; lockedIds?: string[]; sourceItemId?: string } = {}) {
    const session = cellSession(answer)
    const before = JSON.stringify(session)
    const request = JSON.stringify(cellRequest(answer))
    const questions = JSON.stringify(customerQuestionList(session))
    sessionStorage.setItem(WORKING_COPY_KEY, before)
    localStorage.setItem(SAVED_COPY_KEY, before)
    const write = vi.spyOn(Storage.prototype, 'setItem')
    const remove = vi.spyOn(Storage.prototype, 'removeItem')
    const dispatch = vi.fn(), save = vi.fn(), restart = vi.fn(), onEvent = vi.fn(), changeDraft = vi.fn()
    const values = {
      [JSON.stringify(['CELL-purpose', CELL_OPENING, 'choice'])]: 'other',
      [JSON.stringify(['CELL-purpose', CELL_OPENING, 'text'])]: 'An unfinished payment description.',
    }
    act(() => root.render(
      <SessionContext.Provider value={{ session, dispatch, save, restart }}>
        <ExplicitDeferralContext.Provider value={{ itemId: 'CELL-purpose', dispatch }}>
          <DiscussionWorkDraftContext.Provider value={{ values, change: changeDraft }}>
            <AdaptiveCellQuestions answer={answer} onEvent={onEvent} {...props} />
          </DiscussionWorkDraftContext.Provider>
        </ExplicitDeferralContext.Provider>
      </SessionContext.Provider>,
    ))
    return () => {
      expect(JSON.stringify(session)).toBe(before)
      expect(JSON.stringify(cellRequest(answer))).toBe(request)
      expect(JSON.stringify(customerQuestionList(session))).toBe(questions)
      expect(sessionStorage.getItem(WORKING_COPY_KEY)).toBe(before)
      expect(localStorage.getItem(SAVED_COPY_KEY)).toBe(before)
      for (const callback of [write, remove, dispatch, save, restart, onEvent, changeDraft, reviewCellPayment, fetch]) {
        expect(callback).not.toHaveBeenCalled()
      }
    }
  }

  it.each([
    ['fresh', {}],
    ['resumed follow-up', cellPick({}, 'method', 'allowance')],
    ['deferred', reduceCell(cellPick({}, 'method', 'allowance'), { kind: 'defer', checked: true })],
    ['completed', readyCell()],
  ] as const)('opens, scrolls, dismisses and reopens without affecting the %s review', (_state, answer) => {
    const unchanged = mount(answer)
    const trigger = host.querySelector<HTMLButtonElement>(`button[aria-label="${TITLE}"]`)!
    const heading = host.querySelector('h3')!
    expect(heading.textContent).toBe(CELL_OPENING)
    expect(heading.contains(trigger)).toBe(false)
    expect(heading.nextElementSibling).toBe(trigger)
    expect(host.querySelectorAll(`button[aria-label="${TITLE}"]`)).toHaveLength(1)
    expect(host.querySelector('.ec-qcard__section button[aria-label]')?.getAttribute('aria-label')).not.toBe(TITLE)
    const group = host.querySelector('[role="radiogroup"]')!
    expect(document.getElementById(group.getAttribute('aria-labelledby')!)?.textContent).toBe(CELL_OPENING)
    expect(host.querySelector('.ec-qcard__prompt')?.textContent).toBe(CELL_OVERVIEW)
    expect(host.textContent).toContain('Why we’re asking')
    for (const paragraph of CELL_REASON.split('\n\n')) expect(host.textContent).toContain(paragraph)
    expect(host.querySelector('.ec-register-support, .ec-register-details')).not.toBeNull()
    expect(trigger.getAttribute('aria-haspopup')).toBe('dialog')
    const contentBefore = host.innerHTML
    const draftBefore = host.querySelector('textarea')?.value

    for (const dismissal of ['escape', 'close', 'header', 'backdrop']) {
      act(() => { trigger.focus(); trigger.click() })
      const dialog = document.querySelector<HTMLElement>('[role="dialog"]')!
      expect(document.getElementById(dialog.getAttribute('aria-labelledby')!)?.textContent).toBe(TITLE)
      expect(dialog.getAttribute('aria-modal')).toBe('true')
      expect(trigger.getAttribute('aria-expanded')).toBe('true')
      expect(dialog.querySelector('strong')?.textContent).toBe('A fixed cellphone allowance is not automatically taxable.')
      expect(dialog.textContent).toContain('For example, under applicable IRS guidance, a reasonable employer-provided cellphone reimbursement may qualify for nontaxable treatment when there are substantial business reasons and the arrangement is not a substitute for wages. The exact facts matter.')
      expect(dialog.querySelector('blockquote')?.textContent).toBe('“Fixed amount = taxable; actual reimbursement = nontaxable.”')
      expect(dialog.querySelector('blockquote')?.previousElementSibling?.textContent).toBe('Rule to avoid')
      expect([...dialog.querySelectorAll('li')].map(li => li.textContent)).toEqual([
        'The business purpose.', 'The payment arrangement.', 'Applicable substantiation or policy requirements.',
      ])
      expect([...dialog.querySelectorAll('thead th')].map(th => th.textContent)).toEqual(['Library field', 'CELL example'])
      expect([...dialog.querySelectorAll('tbody tr')].map(row => [...row.children].map(cell => cell.textContent))).toEqual(ROWS)
      expect(dialog.querySelectorAll('tbody th[scope="row"]')).toHaveLength(4)
      expect(dialog.querySelector('.ec-cell-info-content section:last-child > p:last-child')?.textContent).toBe(closing)
      const headerClose = dialog.querySelector<HTMLButtonElement>('button[aria-label="Close dialog"]')!
      const close = dialog.querySelector<HTMLButtonElement>('.dlg__footer button')!
      const region = dialog.querySelector<HTMLElement>('[role="region"]')!
      expect(close.textContent).toBe('Close')
      expect(document.activeElement).toBe(headerClose)
      act(() => headerClose.dispatchEvent(new KeyboardEvent('keydown', { key: 'Tab', shiftKey: true, bubbles: true, cancelable: true })))
      expect(document.activeElement).toBe(close)
      act(() => close.dispatchEvent(new KeyboardEvent('keydown', { key: 'Tab', bubbles: true, cancelable: true })))
      expect(document.activeElement).toBe(headerClose)
      act(() => {
        region.focus()
        const body = dialog.querySelector('.dlg__content')!
        body.scrollTop = 200
        body.dispatchEvent(new Event('scroll'))
      })
      expect(document.activeElement).toBe(region)
      expect(document.querySelector('[role="dialog"]')).toBe(dialog)
      const body = dialog.querySelector<HTMLElement>('.dlg__content')!
      Object.defineProperty(body, 'scrollHeight', { value: 1600, configurable: true })
      act(() => region.dispatchEvent(new KeyboardEvent('keydown', { key: 'End', bubbles: true, cancelable: true })))
      expect(body.scrollTop).toBe(1600)
      act(() => region.dispatchEvent(new KeyboardEvent('keydown', { key: 'Home', bubbles: true, cancelable: true })))
      expect(body.scrollTop).toBe(0)
      unchanged()
      act(() => {
        if (dismissal === 'escape') region.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }))
        else if (dismissal === 'close') close.click()
        else if (dismissal === 'header') headerClose.click()
        else dialog.parentElement!.click()
      })
      expect(document.querySelector('[role="dialog"]')).toBeNull()
      expect(document.activeElement).toBe(trigger)
      expect(host.innerHTML).toBe(contentBefore)
      expect(host.querySelector('textarea')?.value).toBe(draftBefore)
      unchanged()
    }
  })

  it.each([{ readOnly: true }, { lockedIds: ['method'] }])('keeps help available independently of answer editability: %j', props => {
    const unchanged = mount(cellPick({}, 'method', 'allowance'), props)
    const trigger = host.querySelector<HTMLButtonElement>(`button[aria-label="${TITLE}"]`)!
    expect(trigger.disabled).toBe(false)
    expect(host.querySelector('input[type="radio"]:disabled')).not.toBeNull()
    act(() => trigger.click())
    expect(document.querySelector('[role="dialog"]')).not.toBeNull()
    unchanged()
  })

  it('keeps help available when saved questions are read-only', () => {
    act(() => root.render(<SessionContext.Provider value={{ session: cellSession(), dispatch: vi.fn(), save: vi.fn(), restart: vi.fn() }}>
      <DiscussionLockedQuestions.Provider value={{ [CELL_OPENING]: 'Fixed amount' }}>
        <AdaptiveCellQuestions answer={cellPick({}, 'method', 'allowance')} onEvent={vi.fn()} />
      </DiscussionLockedQuestions.Provider>
    </SessionContext.Provider>))
    expect(host.querySelector(`button[aria-label="${TITLE}"]`)).not.toBeNull()
    expect(host.querySelector('.ec-qcard__answer')?.textContent).toContain('Fixed amount')
  })

  it.each<ReimbursementCategory>(['MILEAGE', 'AUTO', 'PERDIEM', 'INTERNET', 'UNIFORM', 'TOOLS'])('does not add help to %s or its heading', category => {
    mount({ reimbursement: { category, code: 'MILEAGE', purpose: 'Supplied purpose', evidence: [] } }, { sourceItemId: 'MILEAGE' })
    expect(host.querySelector(`button[aria-label="${TITLE}"]`)).toBeNull()
    expect(host.querySelector('.ec-qcard__inline-heading')).toBeNull()
  })

  it('does not add CELL help to a different code with a cellphone purpose, historical CELL or unrelated cards', () => {
    mount({ reimbursement: { category: 'CELL', code: 'MISC7', purpose: 'Phone costs', evidence: [] } }, { sourceItemId: 'MISC7' })
    expect(host.querySelector(`button[aria-label="${TITLE}"]`)).toBeNull()
    act(() => root.render(<SessionContext.Provider value={{ session: cellSession(), dispatch: vi.fn(), save: vi.fn(), restart: vi.fn() }}>
      <CellQuestions answer={{ cellLegacy: true }} label="CELL" onAnswer={vi.fn()} />
    </SessionContext.Provider>))
    expect(host.querySelector(`button[aria-label="${TITLE}"]`)).toBeNull()
    act(() => root.render(<QuestionCard label="TIPS" question="Unrelated question" variant="misclassification" answered={false} />))
    expect(host.querySelector('.ec-qcard__inline-heading')).toBeNull()
    act(() => root.render(<QuestionCard label="SPPAY" question="Existing heading action" layout="question-first"
      headingAction={<button type="button">Existing action</button>} answered={false} />))
    expect(host.querySelector('.ec-qcard__heading > button')?.textContent).toBe('Existing action')
    expect(host.querySelector('h3')?.textContent).toBe('Existing heading action')
  })
})
