import { createContext, useContext, useEffect, useId, useRef, useState, type ReactNode } from 'react'
import TextArea from '@ready/dls/components/TextArea/TextArea'
import Link from '@ready/dls/components/Link/Link'
import { Button, InlineMessage } from '@ready/dls/compatibility'
import { AILoader, AILogo } from '@ready/dls/ai'
import { redactSensitive, useAskBryteQuestion } from '@workspace/setup-shared/ask-bryte'
import { ASK_CUSTOMER, PLAN_INITIAL_ITEMS, type ReviewItem } from './sampleRegister'
import { activeCheck, type ItemAnswer, type SessionAction } from './session'
import { answerReviewBasis, PLAN_LATER_QUESTION, validAnswerReview, type AnswerReviewRecord, type AnswerReviewTurn } from './answerReviewData'
import { requestAnswerReview, reviewRequest } from './answerReview'
import type { EarningAnswerReviewInput } from '@workspace/api-client-react'
import { reviewShown, typedAnswerFor } from './answerReviewScope'
import { useCardFollowUp } from './cardFollowUp'
import { currentMedicalReview, medicalProposalKey } from './medical'
import { ExplicitDeferralContext } from './explicitDeferral'
import { useProposalCheck } from './proposalAssessment'
import { useDiscussionWorkDraft } from './discussionWorkDraft'
import { SessionContext } from './sessionContext'

/** The benefit plan cards on the “Who pays into each plan” page (MED, DEN and the rest). */
const isPlanItem = (item: ReviewItem) => item.type === 'clarification' && PLAN_INITIAL_ITEMS.some(plan => plan.id === item.id)

interface ReviewContext {
  item: ReviewItem
  answer: ItemAnswer
  dispatch: (action: SessionAction) => void
}
interface ProvidedContext extends ReviewContext {
  /** Whether the review may show its Ask Bryte link. Off where Ask Bryte can’t open, such as the modal reply dialog. */
  offerAskBryte: boolean
}
const Context = createContext<ProvidedContext | null>(null)
export function AnswerReviewProvider({ children, offerAskBryte = true, ...value }: ReviewContext & { children: ReactNode; offerAskBryte?: boolean }) {
  return <ExplicitDeferralContext.Provider value={{ itemId: value.item.id, dispatch: value.dispatch }}>
    <Context.Provider value={{ ...value, offerAskBryte }}>{children}</Context.Provider>
  </ExplicitDeferralContext.Provider>
}

/**
 * The live AI review of a typed answer: the fixed question, the selected approved wording and the typed text reach the
 * model, never rendered HTML or an AI-written opener. A fixed option pick gets no review, because the app already sets
 * its outcome; any follow-up section it reveals appears straight away.
 */
export default function AnswerReview({ question, selected, options }: {
  question: ReactNode
  selected?: string
  options?: { id: string; title: string; subHeading?: string }[]
}) {
  const context = useContext(Context)
  const option = options?.find(entry => entry.id === selected)
  if (!context || typeof question !== 'string' || !option || selected === ASK_CUSTOMER) return null
  if (!reviewShown(context.item, context.answer, question)
    || typedAnswerFor(context.item, context.answer, question, selected) === undefined) return null
  return <LiveReview {...context} question={question} label={option.title} detail={option.subHeading ?? ''} />
}

/** A typed review-card answer's conversation, saved on the card's answer under the question it answers. */
function LiveReview({ item, answer, dispatch, offerAskBryte, question, label, detail }: ProvidedContext & { question: string; label: string; detail: string }) {
  const sessionContext = useContext(SessionContext)
  const askBryte = useAskBryteQuestion()
  const key = question
  const latest = useRef({ item, answer })
  latest.current = { item, answer }
  return <ReviewConversation
    basis={answerReviewBasis(answer)}
    ownerId={item.id}
    saved={answer.reviews?.[key] ?? (item.id === 'MED ER' ? currentMedicalReview(item.id, answer) : undefined)}
    requestKey={JSON.stringify([question, label, detail])}
    request={thread => reviewRequest(latest.current.item, latest.current.answer, question, label, detail, thread, sessionContext?.session)}
    onReview={review => dispatch({ type: 'answerReview', itemId: item.id, key, review })}
    extras={result => <>
      {item.id === 'MED' && medicalProposalKey(answer) && (answer.medicalAccepted === medicalProposalKey(answer)
        ? <p role="status">This setup is confirmed. Apply your answers to include it.</p>
        : <><p>The proposed MED setup is ready, but your confirmation is still needed.</p>
          <p>It establishes what MED represents and which medical deduction, if any, can hold your company’s contribution.</p>
          <p>Use this setup confirms the proposal for when you apply your answers. It does not change live payroll.</p>
          <Button variant="secondary" size="small" onClick={() => dispatch({
          type: 'acceptMedicalSetup', itemId: 'MED', proposal: medicalProposalKey(answer)!,
        })}>Use this setup</Button></>)}
      {result.outcome === 'notNeeded' && answer.retain !== 'remove' && <Button variant="secondary" size="small"
        onClick={() => dispatch({ type: 'omitCode', itemId: item.id, remove: true })}>Don’t set up this code</Button>}
      {/* Only for a typed plan answer where the person insists their company won’t pay. The link is ours, never AI text. */}
      {result.outcome === 'confirm' && result.askBryte && offerAskBryte && askBryte && isPlanItem(item) && (
        <p className="ec-answer-review__ask"><Link size="sm" onClick={() => askBryte(PLAN_LATER_QUESTION)}>Ask Bryte</Link></p>
      )}
    </>}
  />
}

/**
 * A short conversation: each reply gives a reason and a suggested next step and, until the answer is resolved, asks one
 * question. Earlier questions and replies stay above the latest reply; every new review gets the whole thread. `basis`
 * fingerprints the typed answer; `saved` is the stored review, used only while its basis matches.
 */
export function ReviewConversation({ basis, saved, requestKey, request, onReview, extras, ownerId = 'answer' }: {
  basis: string
  ownerId?: string
  saved?: AnswerReviewRecord
  /** Changes when the question or option sent with the answer changes. */
  requestKey: string
  request: (thread: AnswerReviewTurn[]) => EarningAnswerReviewInput
  onReview: (review: AnswerReviewRecord) => void
  extras?: (result: AnswerReviewRecord['result']) => ReactNode
}) {
  const current = saved?.basis === basis ? saved : undefined
  const [retry, setRetry] = useState(0)
  const [state, setState] = useState<{ basis: string; error?: string }>()
  const [reply, setReply] = useDiscussionWorkDraft(requestKey, 'review-reply')
  // The thread sent with the newest reply, until its review arrives.
  const [pendingText, setPendingText] = useDiscussionWorkDraft(requestKey, 'review-thread')
  let sent: { basis: string; thread: AnswerReviewTurn[] } | undefined
  try {
    const parsed = pendingText ? JSON.parse(pendingText) : undefined
    if (parsed && validAnswerReview({ ...parsed, result: { outcome: 'confirm', reason: 'Pending reply', question: null, conflictingFact: null } })
      && Array.isArray(parsed.thread)) sent = parsed
  } catch { /* Ignore an incomplete older draft. */ }
  const setSent = (value: typeof sent) => setPendingText(value ? JSON.stringify(value) : '')
  const latest = useRef({ request, onReview })
  latest.current = { request, onReview }
  const id = useId()
  const answered = current?.thread?.length ?? 0
  const responding = sent?.basis === basis && sent.thread.length > answered
  const assessment = useProposalCheck(`${ownerId}:answer:${requestKey}`, !current || responding ? basis : undefined)
  const previousBasis = useRef(basis)
  useEffect(() => {
    if (previousBasis.current !== basis) { setReply(''); setSent(undefined); previousBasis.current = basis }
  }, [basis])
  useEffect(() => {
    if (assessment.readOnly || current && !responding || assessment.problem) return
    const controller = new AbortController()
    const { request, onReview } = latest.current
    // Older saved reviews have no thread: a reply to them starts one.
    const thread = responding && sent ? sent.thread : []
    const input = request(thread)
    setState({ basis })
    assessment.start()
    const timer = window.setTimeout(() => { requestAnswerReview(input, controller.signal).then(response => {
      if (controller.signal.aborted) return
       if (!response.ok) { assessment.fail(response.message); setState({ basis, error: response.message }); return }
       assessment.finish()
      onReview({ basis, result: response.result, ...(thread.length ? { thread } : {}) })
      setState(undefined)
      setSent(undefined)
      setReply('')
    }, () => { /* Cancelled on unmount or when the answer changed. */ }) }, 450)
    return () => { window.clearTimeout(timer); controller.abort() }
  }, [basis, requestKey, retry, current, responding, pendingText])
  const error = assessment.problem ?? (state?.basis === basis ? state.error : undefined)
  const dismiss = () => current && onReview({ ...current, dismissed: true })
  const thread = responding && sent ? sent.thread : current?.thread ?? []
  const result = current && !responding ? current.result : undefined
  const asking = result?.question != null
  useCardFollowUp(!current?.dismissed && (asking || thread.length > 0))
  if (current?.dismissed) return null
  const send = () => {
    if (!current || !result?.question) return
    // Redacted before it's stored or sent; the thread shows what's kept.
    const turn: AnswerReviewTurn = {
      reason: result.reason, ...(result.suggestion ? { suggestion: result.suggestion } : {}),
      question: result.question, reply: redactSensitive(reply.trim()).slice(0, 500),
    }
    setSent({ basis, thread: [...current.thread ?? [], turn] })
  }
  return <div className="ec-describe ec-answer-review">
    {thread.length > 0 && <ol className="ec-answer-review__thread" aria-label="Earlier questions and your replies">
      {thread.map((turn, index) => <li key={index}>
        <p className="ec-answer-review__asked">{turn.question}</p>
        <p className="ec-answer-review__replied">Your reply: {turn.reply}</p>
      </li>)}
    </ol>}
    <div role="status" className="ec-answer-review__status">
      <span>
        <AILogo variant="secondary" size={16} />{' '}
        {!result ? error ?? <>We’re reviewing your answer <AILoader /></> : result.reason}
      </span>
      {result?.suggestion && <span className="ec-answer-review__suggestion">{result.suggestion}</span>}
    </div>
    {error && <Button variant="secondary" size="small" onClick={() => { assessment.finish(); setRetry(value => value + 1) }}>Try again</Button>}
    {result && !error && <>
      {asking && <>
        <TextArea id={id} label={result.question!} value={reply} onChange={setReply} rows={2} />
        <Button variant="secondary" size="small" disabled={!reply.trim() || reply.length > 500} onClick={send}>Send</Button>
      </>}
      {extras?.(result)}
      {(result.outcome === 'notNeeded' || result.outcome === 'conflict') && (
        <Button variant="secondary" size="small" onClick={dismiss}>Keep my answer</Button>
      )}
    </>}
  </div>
}

/** Description checks use the same removal decision as ADJ2, rather than a second omitted-code concept. */
export function DescriptionNotNeeded({ item, answer, dispatch }: ReviewContext) {
  const checked = activeCheck(item, answer)
  const basis = answerReviewBasis(answer)
  if (answer.retain === 'remove') return <div className="ec-describe">
    <InlineMessage theme="info">We won’t set up {item.code}. You can change this before applying your answers.</InlineMessage>
    <Button variant="secondary" size="small" onClick={() => dispatch({ type: 'omitCode', itemId: item.id, remove: false })}>Keep this code</Button>
  </div>
  if (checked?.kind !== 'notNeeded' || answer.reviews?.['description-not-needed']?.basis === basis) return null
  return <div className="ec-describe">
    <p role="status"><AILogo variant="secondary" size={16} /> {checked.reason}</p>
    <Button variant="secondary" size="small" onClick={() => dispatch({ type: 'omitCode', itemId: item.id, remove: true })}>Don’t set up this code</Button>
    <Button variant="secondary" size="small" onClick={() => dispatch({
      type: 'answerReview', itemId: item.id, key: 'description-not-needed',
      review: { basis, dismissed: true, result: { outcome: 'notNeeded', reason: checked.reason, question: null, conflictingFact: null } },
    })}>Keep my answer</Button>
  </div>
}
