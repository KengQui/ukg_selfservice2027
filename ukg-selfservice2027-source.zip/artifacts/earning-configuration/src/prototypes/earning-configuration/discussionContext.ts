import { callEvidence, type CallAnswer } from './cheatSheetAnswers'
import { answerReviewBasis } from './answerReviewData'
import { reviewShown } from './answerReviewScope'
import { activeCheck, activeNaming, askedFollowUps, shiftPremiumFor, type ItemAnswer, type Resolution } from './session'
import { currentCellCheck } from './cellFlow'
import { reimbursementAnswer } from './reimbursements'
import { ASK_CUSTOMER, type ReviewItem } from './sampleRegister'

export interface DiscussionAnswer extends CallAnswer { historical: boolean; provenance: 'answer' | 'supplied' }
export interface DiscussionReview { reason: string; suggestion?: string }
export interface DiscussionContext {
  supplied: DiscussionAnswer[]
  earlier: DiscussionAnswer[]
  decision: string
  reviews: DiscussionReview[]
  missingReviewReason: boolean
}

/** Excerpts are presentation only. The full supplied text stays in the read-only disclosure. */
export const contextExcerpt = (text: string) => text.length > 280 ? `${text.slice(0, 280).trimEnd()}…` : text

/**
 * Derive presentation from existing evidence, never a new decision or AI request.
 * Answer-review and shift evidence follow the same freshness/typed-answer gates as their cards.
 */
export function discussionContext(item: ReviewItem, answer: ItemAnswer = {}, resolution: Resolution | undefined,
  reason: string): DiscussionContext {
  const reviews = Object.fromEntries(Object.entries(answer.reviews ?? {}).filter(([question, review]) =>
    review.basis === answerReviewBasis(answer) && reviewShown(item, answer, question)))
  const shift = shiftPremiumFor(item, answer)
  const source: ItemAnswer = {
    ...answer, reviews, shiftPremium: shift?.state,
    // Explicitly unfinished edits are not supplied answers. Older saves lack the flag.
    ...(answer.descriptionSubmitted === false ? { description: undefined } : {}),
    ...(answer.sharedSetup?.descriptionSubmitted === false
      ? { sharedSetup: { ...answer.sharedSetup, description: undefined } } : {}),
  }
  const payment = reimbursementAnswer(item, source) ?? source
  const entries = callEvidence(item, source, resolution?.status === 'resolved').answers
  const earlier: DiscussionAnswer[] = entries.map(entry => ({
    ...entry, historical: entry.question.startsWith('Earlier answer (history):'),
    provenance: entry.question === 'Previously supplied payment facts'
      && payment.reimbursement?.evidence.some(e => e.type !== 'customer-answer') ? 'supplied' : 'answer',
  }))
  // Adaptive reimbursements keep the source description and description-check replies too.
  if (payment.reimbursement) {
    if (source.description?.trim()) earlier.unshift({ question: item.question, answer: source.description.trim(), historical: false, provenance: 'answer' })
    for (const entry of source.checkAnswers ?? []) earlier.push({ ...entry, historical: false, provenance: 'answer' })
    if (payment.cell?.earlier) {
      const history = callEvidence(item, { ...payment.cell.earlier, reimbursementLegacy: true, cellLegacy: true }, true)
      earlier.push(...history.answers.map(entry => ({ ...entry, historical: true, provenance: 'answer' as const })))
    }
  }
  // A setup-review note is supplied text, not an explanation fabricated from its status.
  if (resolution?.status === 'review' && resolution.note?.trim()
    && !payment.cell && !earlier.some(entry => entry.answer === resolution.note)) {
    earlier.push({ question: resolution.question ?? 'Supplied description', answer: resolution.note, historical: false, provenance: 'answer' })
  }
  const unique = earlier.filter((entry, index, all) => all.findIndex(other =>
    other.question === entry.question && other.answer === entry.answer && other.historical === entry.historical) === index)
  const current = unique.filter(entry => !entry.historical)
  const supplied = current.length <= 3 ? current : [...current.slice(0, 2), current.at(-1)!]
  const reasoning: DiscussionReview[] = []
  for (const review of Object.values(reviews)) {
    // A retired single reply has consumed that result; it is no longer the current explanation.
    if (!review.reply) reasoning.push({ reason: review.result.reason, suggestion: review.result.suggestion })
  }
  const check = activeCheck(item, source)
  if (check && 'reason' in check && check.reason) reasoning.push({ reason: check.reason })
  const naming = activeNaming(item, source)
  if (naming?.outcome === 'suggestion' && naming.rationale) reasoning.push({
    reason: naming.rationale, suggestion: `Proposed name: ${naming.name}. A name alone does not confirm payroll or tax treatment.`,
  })
  if (shift?.result && !shift.state?.changed) reasoning.push({ reason: shift.result.reason })
  const cell = currentCellCheck(payment)
  if (cell) reasoning.push({ reason: cell.result.reason })
  // Partial fixed conversations keep their answered parent facts. Explain the deferred section,
  // rather than falling back to an opening-purpose explanation.
  const deferredSection = askedFollowUps(item, answer).find(entry => answer.followUps?.[entry.id] === ASK_CUSTOMER)
  const currentReason = resolution?.status === 'customer' && deferredSection ? deferredSection.context : reason
  const decision = !resolution
    ? 'No setup decision has been applied. This code still needs an answer or review action.'
    : resolution.status === 'removed'
      ? 'The code was left out of this setup. Earlier payroll activity is unchanged.'
      : resolution.status === 'review'
        ? payment.cell
          ? 'The supplied payment facts and intended tax treatment need setup review. No applicable setup has been confirmed.'
          : 'The supplied description needs setup review before a Ready setup can be confirmed.'
        : currentReason.split(/\n\s*\n/).filter(Boolean).slice(0, 2).join('\n\n')
          || 'No supporting explanation was saved for this review decision.'
  return { supplied, earlier: unique, decision, missingReviewReason: resolution?.status === 'review' && !reasoning.length,
    reviews: reasoning.filter((entry, index, all) =>
    all.findIndex(other => other.reason === entry.reason && other.suggestion === entry.suggestion) === index) }
}
