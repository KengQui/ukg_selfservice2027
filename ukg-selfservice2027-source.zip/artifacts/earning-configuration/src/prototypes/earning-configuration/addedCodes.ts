/**
 * Earning codes the team adds because they aren't in the payroll register. They are user-provided: never register
 * evidence, never a Ready reference, never ready for setup. Each one waits for setup review.
 */
export const ADDED_CODE_MAX = 20
export const ADDED_NAME_MAX = 60
export const ADDED_DESCRIPTION_MAX = 500

export const ADDED_CODES_TITLE = 'Additional earning codes'
export const ADDED_CODES_INTRO = 'Add any earning codes missing from your payroll register and tell us what they pay for. If you don’t have any codes to add, select Next.'
export const ADDED_CODES_STATUS = 'Added by you · Awaiting setup review'

export const ADDED_THREAD_MAX = 4
export const ADDED_REPLY_MAX = 500
export const ADDED_PLAN_QUESTION = 'Can we add this earning code to your setup plan?'
export const ADDED_CHANGE_QUESTION = 'What would you like to change about this earning code?'
export const REFERRAL_BONUS_SETUP = {
  referenceId: 'demo-employee-referral-bonus',
  code: 'REFBON',
  name: 'Referral bonus',
  // copy-exception(review/employees): Exact result description approved by the user (guide A.7).
  description: 'We’ll set up REFBON for bonuses paid to employees when someone they refer is hired.',
} as const

/** Mirrors the API result. Reference identity always comes from the server's demo library. */
export interface AddedCheckResult {
  outcome: 'match' | 'question' | 'noMatch'
  summary: string
  facts: string[]
  question: string | null
  reason: string
  reference: { id: string; name: string; library: 'demo' } | null
}
export interface AddedTurn { question: string; answer: string }
/** One live check. The token ties a response to the exact request, so a late answer can't land on an edited, removed or reused code. */
export type AddedCheck =
  | { status: 'checking'; token: string }
  | { status: 'error'; token: string; message: string }
  | { status: 'result'; token: string; result: AddedCheckResult }
/** A confirmed setup-plan record. A revision moves it to history; it never changes payroll. */
export interface AddedPlanRecord { referenceId: string; referenceName: string; summary: string; facts: string[]; description: string; at: number }

export interface AddedCode {
  id: string; code: string; name: string; description: string
  thread?: AddedTurn[]
  check?: AddedCheck
  replyDraft?: string
  deferred?: true
  plan?: AddedPlanRecord
  history?: AddedPlanRecord[]
}
export interface AddedCodeDraft { editing?: string; code: string; name: string; description: string }
export interface AddedCodesState {
  entries: AddedCode[]
  /** Explicit answer: there are no codes to add. Only valid with no entries. */
  none?: true
  /** The form in progress, kept across navigation and reload. */
  draft?: AddedCodeDraft
}

export type AddedCodesEvent =
  | { kind: 'start' }
  | { kind: 'change'; field: 'code' | 'name' | 'description'; value: string }
  | { kind: 'save' }
  | { kind: 'cancel' }
  | { kind: 'edit'; id: string }
  | { kind: 'remove'; id: string }
  | { kind: 'none'; value: boolean }
  | { kind: 'check'; id: string }
  | { kind: 'checkResult'; id: string; token: string; result: AddedCheckResult }
  | { kind: 'checkError'; id: string; token: string; message: string }
  | { kind: 'replyChange'; id: string; value: string }
  | { kind: 'reply'; id: string }
  | { kind: 'confirm'; id: string; at: number }
  | { kind: 'defer'; id: string }
  | { kind: 'resume'; id: string }
  | { kind: 'requestChange'; id: string }

let tokenCount = 0
const newToken = () => `${Date.now().toString(36)}-${(++tokenCount).toString(36)}-${Math.random().toString(36).slice(2, 10)}`
const checking = (): AddedCheck => ({ status: 'checking', token: newToken() })

/** Changing the intention invalidates the result, the reply thread and any decision; an earlier confirmation becomes history. */
function revise(entry: AddedCode, description: string, extra: Partial<AddedCode> = {}): AddedCode {
  const history = [...(entry.history ?? []), ...(entry.plan ? [entry.plan] : [])]
  return { id: entry.id, code: entry.code, name: entry.name, description, ...extra, ...(history.length ? { history } : {}), check: checking() }
}

const currentMatch = (entry: AddedCode) =>
  entry.check?.status === 'result' && entry.check.result.outcome === 'match' && entry.check.result.reference ? entry.check.result : undefined

function updateEntry(state: AddedCodesState, id: string, update: (entry: AddedCode) => AddedCode | undefined): AddedCodesState {
  const entry = state.entries.find(item => item.id === id)
  const next = entry && update(entry)
  if (!next || next === entry) return state
  return { ...state, entries: state.entries.map(item => item.id === id ? next : item) }
}

const MAX: Record<'code' | 'name' | 'description', number> = { code: ADDED_CODE_MAX, name: ADDED_NAME_MAX, description: ADDED_DESCRIPTION_MAX }

export function addedDraftError(draft: AddedCodeDraft): string | undefined {
  if (draft.code.length > ADDED_CODE_MAX) return `Keep the code within ${ADDED_CODE_MAX} characters.`
  if (draft.name.length > ADDED_NAME_MAX) return `Keep the name within ${ADDED_NAME_MAX} characters.`
  if (draft.description.length > ADDED_DESCRIPTION_MAX) return `Keep the description within ${ADDED_DESCRIPTION_MAX} characters.`
  if (!draft.description.trim()) return 'Tell us what this code pays for.'
  return undefined
}

/** Empty additions are optional, not a customer confirmation. Keep unfinished edits gated. */
export function addedCodesDecided(state: AddedCodesState | undefined): boolean {
  if (!state) return false
  const draft = state.draft
  return !draft || (!draft.editing && !draft.code.trim() && !draft.name.trim() && !draft.description.trim())
}

export function addedCodesPending(state: AddedCodesState | undefined): string | undefined {
  if (state?.draft && !addedCodesDecided(state)) return 'Save the code you’re adding.'
  return undefined
}

export function reduceAddedCodes(state: AddedCodesState | undefined, event: AddedCodesEvent): AddedCodesState {
  const current: AddedCodesState = state ?? { entries: [] }
  switch (event.kind) {
    case 'start':
      if (current.draft) return current
      return { entries: current.entries, draft: { code: '', name: '', description: '' } }
    case 'change': {
      if (!current.draft) return current
      return { ...current, draft: { ...current.draft, [event.field]: event.value.slice(0, MAX[event.field] + 50) } }
    }
    case 'save': {
      const draft = current.draft
      if (!draft || addedDraftError(draft)) return current
      const entry = { code: draft.code.trim(), name: draft.name.trim(), description: draft.description.trim() }
      const editing = draft.editing && current.entries.some(item => item.id === draft.editing) ? draft.editing : undefined
      const next = Math.max(0, ...current.entries.map(item => Number(item.id.replace(/^added-/, '')) || 0)) + 1
      const entries = editing
        ? current.entries.map(item => item.id !== editing ? item
          : item.description === entry.description && item.check ? { ...item, ...entry } : revise({ ...item, ...entry }, entry.description))
        : [...current.entries, { id: `added-${next}`, ...entry, check: checking() }]
      return { entries }
    }
    case 'cancel':
      return { entries: current.entries, ...(current.none ? { none: true as const } : {}) }
    case 'edit': {
      const entry = current.entries.find(item => item.id === event.id)
      if (!entry) return current
      return { entries: current.entries, draft: { editing: entry.id, code: entry.code, name: entry.name, description: entry.description } }
    }
    case 'remove': {
      const entries = current.entries.filter(item => item.id !== event.id)
      const draft = current.draft?.editing === event.id ? undefined : current.draft
      return { entries, ...(draft ? { draft } : {}) }
    }
    case 'none':
      if (!event.value) return { entries: current.entries, ...(current.draft ? { draft: current.draft } : {}) }
      if (current.entries.length) return current
      return { entries: [], none: true }
    case 'check':
      return updateEntry(current, event.id, entry => entry.check?.status === 'checking' || entry.check?.status === 'result' ? entry
        : { ...entry, check: checking() })
    case 'checkResult':
      return updateEntry(current, event.id, entry => {
        if (entry.check?.status !== 'checking' || entry.check.token !== event.token) return entry
        const { deferred: _deferred, replyDraft: _reply, ...rest } = entry
        return { ...rest, check: { status: 'result', token: event.token, result: event.result } }
      })
    case 'checkError':
      return updateEntry(current, event.id, entry => entry.check?.status !== 'checking' || entry.check.token !== event.token ? entry
        : { ...entry, check: { status: 'error', token: event.token, message: event.message } })
    case 'replyChange':
      return updateEntry(current, event.id, entry => entry.check?.status === 'result' && entry.check.result.outcome === 'question'
        ? { ...entry, replyDraft: event.value.slice(0, ADDED_REPLY_MAX + 50) } : entry)
    case 'reply':
      return updateEntry(current, event.id, entry => {
        const answer = entry.replyDraft?.trim() ?? ''
        if (entry.check?.status !== 'result' || !entry.check.result.question || !answer || answer.length > ADDED_REPLY_MAX) return entry
        const thread = [...(entry.thread ?? []), { question: entry.check.result.question, answer }].slice(-ADDED_THREAD_MAX)
        const { replyDraft: _reply, ...rest } = entry
        return { ...rest, thread, check: checking() }
      })
    case 'confirm':
      return updateEntry(current, event.id, entry => {
        const match = currentMatch(entry)
        if (!match || entry.plan) return entry
        const { deferred: _deferred, ...rest } = entry
        const referral = match.reference!.id === REFERRAL_BONUS_SETUP.referenceId
        return { ...rest, ...(referral ? { code: REFERRAL_BONUS_SETUP.code, name: REFERRAL_BONUS_SETUP.name } : {}), plan: { referenceId: match.reference!.id, referenceName: match.reference!.name, summary: referral ? REFERRAL_BONUS_SETUP.description : match.summary,
          facts: match.facts, description: entry.description, at: event.at } }
      })
    case 'defer':
      return updateEntry(current, event.id, entry => {
        if (entry.check?.status !== 'result') return entry
        const { plan, ...rest } = entry
        return { ...rest, deferred: true, ...(plan ? { history: [...(entry.history ?? []), plan] } : {}) }
      })
    case 'resume':
      return updateEntry(current, event.id, entry => {
        const { deferred: _deferred, ...rest } = entry
        return rest
      })
    case 'requestChange':
      return updateEntry(current, event.id, entry => {
        if (!currentMatch(entry)) return entry
        const { plan, deferred: _deferred, replyDraft: _reply, ...rest } = entry
        const generatedReferral = currentMatch(entry)?.reference?.id === REFERRAL_BONUS_SETUP.referenceId
          && entry.code === REFERRAL_BONUS_SETUP.code && entry.name === REFERRAL_BONUS_SETUP.name
        return { ...rest, ...(generatedReferral ? { code: '', name: '' } : {}),
          ...(plan ? { history: [...(entry.history ?? []), plan] } : {}),
          check: { status: 'result', token: newToken(), result: {
            outcome: 'question', question: ADDED_CHANGE_QUESTION, reference: null,
            summary: '', facts: [], reason: '',
          } } }
      })
  }
}

const isText = (value: unknown, max: number): value is string => typeof value === 'string' && value.length <= max
const isTextList = (value: unknown, max: number): value is string[] => Array.isArray(value) && value.every(item => isText(item, max))

function validResult(value: unknown): AddedCheckResult | undefined {
  if (!value || typeof value !== 'object') return undefined
  const r = value as Record<string, unknown>
  if (!['match', 'question', 'noMatch'].includes(r.outcome as string) || !isText(r.summary, 400) || !isText(r.reason, 300) || !isTextList(r.facts, 200)) return undefined
  const ref = r.reference as Record<string, unknown> | null
  const reference = ref && typeof ref === 'object' && typeof ref.id === 'string' && typeof ref.name === 'string' && ref.library === 'demo'
    ? { id: ref.id, name: ref.name, library: 'demo' as const } : null
  if ((r.outcome === 'match') !== !!reference) return undefined
  const question = r.outcome === 'question' && isText(r.question, 300) && r.question.trim() ? r.question : null
  if (r.outcome === 'question' && !question) return undefined
  return { outcome: r.outcome as AddedCheckResult['outcome'], summary: r.summary as string, facts: r.facts as string[], question, reason: r.reason as string, reference }
}

function validPlan(value: unknown): AddedPlanRecord | undefined {
  if (!value || typeof value !== 'object') return undefined
  const p = value as Record<string, unknown>
  if (typeof p.referenceId !== 'string' || typeof p.referenceName !== 'string' || !isText(p.summary, 400) || !isTextList(p.facts, 200)
    || !isText(p.description, ADDED_DESCRIPTION_MAX) || typeof p.at !== 'number') return undefined
  return { referenceId: p.referenceId, referenceName: p.referenceName, summary: p.summary, facts: p.facts, description: p.description, at: p.at }
}

/** Saved checks, replies and decisions. A check interrupted by reload restarts with a fresh token. */
function restoreCheck(raw: Record<string, unknown>): Partial<AddedCode> {
  const out: Partial<AddedCode> = {}
  if (Array.isArray(raw.thread)) {
    const thread = raw.thread.flatMap(turn => turn && typeof turn === 'object' && isText((turn as AddedTurn).question, 300) && isText((turn as AddedTurn).answer, ADDED_REPLY_MAX)
      ? [{ question: (turn as AddedTurn).question, answer: (turn as AddedTurn).answer }] : []).slice(-ADDED_THREAD_MAX)
    if (thread.length) out.thread = thread
  }
  const check = raw.check as Record<string, unknown> | undefined
  if (check && typeof check === 'object' && typeof check.token === 'string') {
    if (check.status === 'checking') out.check = checking()
    else if (check.status === 'error' && typeof check.message === 'string') out.check = { status: 'error', token: check.token, message: check.message }
    else if (check.status === 'result') {
      const result = validResult(check.result)
      out.check = result ? { status: 'result', token: check.token, result } : checking()
    }
  }
  if (out.check?.status === 'result' && out.check.result.outcome === 'question' && typeof raw.replyDraft === 'string') out.replyDraft = raw.replyDraft.slice(0, ADDED_REPLY_MAX + 50)
  if (out.check?.status === 'result' && raw.deferred === true) out.deferred = true
  const plan = validPlan(raw.plan)
  if (plan) out.plan = plan
  const history = Array.isArray(raw.history) ? raw.history.flatMap(item => validPlan(item) ?? []) : []
  if (history.length) out.history = history
  return out
}

/** Restores saved additions; anything malformed is dropped field by field, never the rest of the session. */
export function validAddedCodes(value: unknown): AddedCodesState | undefined {
  if (!value || typeof value !== 'object') return undefined
  const raw = value as Record<string, unknown>
  const seen = new Set<string>()
  const entries = (Array.isArray(raw.entries) ? raw.entries : []).flatMap((entry): AddedCode[] => {
    if (!entry || typeof entry !== 'object') return []
    const { id, code, name, description } = entry as Record<string, unknown>
    if (typeof id !== 'string' || !/^added-\d+$/.test(id) || seen.has(id)) return []
    if (!isText(code, ADDED_CODE_MAX) || !isText(name, ADDED_NAME_MAX) || !isText(description, ADDED_DESCRIPTION_MAX)) return []
    if (!description.trim()) return []
    seen.add(id)
    return [{ id, code, name, description, ...restoreCheck(entry as Record<string, unknown>) }]
  })
  const d = raw.draft as Record<string, unknown> | undefined
  const draft = d && typeof d === 'object' && typeof d.code === 'string' && typeof d.name === 'string' && typeof d.description === 'string'
    ? { ...(typeof d.editing === 'string' && entries.some(entry => entry.id === d.editing) ? { editing: d.editing } : {}),
        code: d.code.slice(0, ADDED_CODE_MAX + 50), name: d.name.slice(0, ADDED_NAME_MAX + 50), description: d.description.slice(0, ADDED_DESCRIPTION_MAX + 50) }
    : undefined
  return { entries, ...(raw.none === true && !entries.length ? { none: true as const } : {}), ...(draft ? { draft } : {}) }
}

export const addedCodeLabel = (entry: AddedCode) => [entry.code, entry.name].filter(Boolean).join(' · ')

export const ADDED_STATUS = {
  plan: 'In your setup plan',
  deferred: 'Review later',
  noMatch: 'No match found · Awaiting setup review',
  pending: 'Awaiting setup review',
} as const
export type AddedStatus = keyof typeof ADDED_STATUS

export function addedCodeStatus(entry: AddedCode): AddedStatus {
  if (entry.plan) return 'plan'
  if (entry.check?.status === 'result' && entry.check.result.outcome === 'noMatch') return 'noMatch'
  if (entry.deferred) return 'deferred'
  return 'pending'
}

/**
 * Summary/export lines. Only an explicit Yes puts a code in the setup plan, with its demo reference. Everything else
 * stays the team's own information awaiting setup review. Earlier confirmations are history only.
 */
export function addedCodeRows(state: AddedCodesState | undefined) {
  return (state?.entries ?? []).map(entry => {
    const status = addedCodeStatus(entry)
    const result = entry.check?.status === 'result' ? entry.check.result : undefined
    return {
      id: entry.id, code: entry.code, name: entry.name, description: entry.description,
      status: ADDED_STATUS[status], kind: status,
      plan: entry.plan,
      facts: entry.plan?.facts ?? (status === 'noMatch' ? result?.facts ?? [] : []),
      thread: entry.thread ?? [],
      history: entry.history ?? [],
    }
  })
}
