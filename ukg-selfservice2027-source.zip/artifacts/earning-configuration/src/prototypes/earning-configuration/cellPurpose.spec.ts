import { describe, expect, it } from 'vitest'
import { CELL_ID, cellCustomerQuestion, cellQuestionStage } from './cell'
import { CELL_METHODS, CELL_OPENING, CELL_OVERVIEW, CELL_REASON, CELL_PURPOSE, cellNext, cellTaxQuestion, paymentMethod } from './cellFlow'
import { findCode, findItem } from './sampleRegister'
import { historicalCellItem } from './cellHistory'
import { SAMPLE_PAY_REGISTERS } from './sampleDocument'
import { bryteFacts } from './bryteFacts'
import { cellSession } from './cellFlow.testing'

describe('approved CELL wording and evidence boundaries', () => {
  it('asks customers to confirm the ongoing practice without asserting an unsupported amount', () => {
    expect(findItem(CELL_ID).question).toBe('How does your company use CELL to pay employees for cellphone costs?')
    expect(findCode('CELL')?.description).toBe('')
    expect(CELL_OVERVIEW).toBe('Your pay register shows CELL payments. Is this a set amount you pay each pay period?')
    expect(findItem(CELL_ID)).toMatchObject({ overview: CELL_OVERVIEW })
    expect(findItem(CELL_ID).customerQuestion).toContain(CELL_OVERVIEW)
    expect(CELL_OVERVIEW).not.toMatch(/\$|tax|supplied mapping context|verified|database/i)
    expect(CELL_REASON.split('\n\n')).toHaveLength(3)
    expect(paymentMethod({})).toBeUndefined()
    expect(cellNext({})).toMatchObject({ kind: 'question', question: { id: 'method', question: CELL_OPENING } })
  })
  it('has period payment evidence but no evidence for $40 per recipient', () => {
    const rows = SAMPLE_PAY_REGISTERS.map(register => register.rows.find(row => row.code === 'CELL')!)
    expect(rows.map(row => row.periodAmount)).toEqual([864, 936])
    expect(rows.every(row => row.periodAmount! > 0)).toBe(true)
    // employees is the annual count, not a pay-period recipient count.
    expect(rows.map(row => row.employees)).toEqual([36, 36])
    expect(SAMPLE_PAY_REGISTERS.every(register => register.csv.includes('People (last 12 months)'))).toBe(true)
  })
  it('shares the current description with Bryte without inferring a payment method or tax intent', () => {
    const { facts } = bryteFacts(cellSession())
    expect(facts.cellBasis).toContain(CELL_OVERVIEW)
    expect(facts.cellPurpose).toBe('Not answered')
    expect(facts.cellTreatment).toContain('tax treatment pending confirmation')
    expect(facts.cellBasis).not.toContain('$40')
  })
  it('retains the supplied wording exceptions, descriptions and illustrative examples', () => {
    expect(CELL_METHODS.map(o => o.label)).toEqual(['Fixed amount', 'Actual expense reimbursement', 'Both', 'Something else'])
    expect(CELL_METHODS.slice(0, 3).map(o => 'example' in o ? o.example : '')).toEqual([
      "Example: $40 every month, whether an employee's phone bill is $30 or $90.",
      'Example: An employee submits $35 in business phone expenses and receives $35.',
      'Example: $20 per month plus approved additional business phone expenses.',
    ])
    expect(CELL_PURPOSE.question).toBe('Why does your company provide the cellphone allowance?')
    expect(CELL_PURPOSE.options?.map(o => o.id)).toEqual(['business', 'compensation', 'mixed', 'unsure'])
  })
  it('names explicit company confirmation and pending/special treatment without a receipt checklist', () => {
    const tax = cellTaxQuestion('reimbursement', true)
    expect(tax.question).toBe('How should this cellphone payment be treated for payroll taxes in UKG Ready?')
    expect(tax.context).toContain('additional reimbursement')
    expect(tax.options?.map(o => o.label)).toEqual(['Taxable', 'Nontaxable', 'Not sure', 'Something else'])
    expect(tax.options?.[1].detail).toContain('company has confirmed')
    expect(JSON.stringify(tax)).not.toMatch(/receipts|accountable plan/i)
  })
  it('versions current meanings while preserving retired wording for history only', () => {
    expect(cellQuestionStage({})).toBe('v2-method-r0')
    expect(cellCustomerQuestion('v2-method-r0')).toContain(CELL_OPENING)
    expect(historicalCellItem().question).toBe('How does the company pay CELL?')
    expect(cellQuestionStage({ cellLegacy: true })).toBe('purpose')
  })
})
