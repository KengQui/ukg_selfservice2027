import type { EarningSession, ItemAnswer } from './session'
import { CELL_ID } from './cell'
import { emptyCell, CELL_METHODS, CELL_OPENING, CELL_REASON, recheckCellPending, type CellFlow } from './cellFlow'
import { MILEAGE_POLICY, MILEAGE_KNOWLEDGE_VERSION } from '@workspace/setup-shared/mileage-policy'
import { isMileage, isMileageReviewFallback } from './mileageQuestions'

/** Retire only unfinished synthetic work. Sent/replied/applied records keep their original content. */
function resumeMileageStatus(session: EarningSession): EarningSession {
  const answer = session.answers.MILEAGE
  const resolution = session.resolutions.MILEAGE
  if (!answer || !isMileage(answer) || !isMileageReviewFallback(answer.cell?.deferred)
    || resolution && resolution.status !== 'customer') return session
  const id = `reimbursement:MILEAGE:${answer.cell?.replyRound ?? 0}:${answer.cell!.deferred!.id}`
  if (session.customerReplies?.[id]) return session
  const sent = session.sent
  const original = session.customerQuestions.find(q => q.itemId === 'MILEAGE')
  const snapshots = [...(sent?.questions ?? [])]
  if (sent?.questionIds.includes(id) && original && !snapshots.some(q => q.id === id)) snapshots.push({
    id, topic: 'allowances', codes: [original.code],
    question: original.draft?.questions.join('\n\n') ?? original.question, status: 'notNeeded',
  })
  const { MILEAGE: _retired, ...resolutions } = session.resolutions
  const pending = session.rounds.find(round => !round.submitted)
  const rounds = !resolution ? session.rounds : pending
    ? session.rounds.map(round => round === pending && !round.itemIds.includes('MILEAGE')
      ? { ...round, itemIds: [...round.itemIds, 'MILEAGE'] } : round)
    : [...session.rounds, { number: Math.max(0, ...session.rounds.map(r => r.number)) + 1,
      kind: 'added-questions' as const, itemIds: ['MILEAGE'], submitted: false }]
  return { ...session, resolutions, rounds,
    answers: { ...session.answers, MILEAGE: recheckCellPending(answer) },
    customerQuestions: session.customerQuestions.filter(q => q.itemId !== 'MILEAGE'),
    ...(sent ? { sent: { ...sent, questions: snapshots } } : {}),
    ...(session.pendingDeferralTarget?.itemId === 'MILEAGE' ? { pendingDeferralTarget: undefined } : {}),
    ...(resolution ? { step: 'questions', reviewCursor: 0, appliedReview: undefined } : {}) }
}

const record = (value: unknown): value is Record<string, unknown> => !!value && typeof value === 'object' && !Array.isArray(value)
export function validCellFlow(value: unknown): value is CellFlow {
  if (!record(value) || value.version !== 2 || !Array.isArray(value.entries) || value.entries.length > 24
    || !Array.isArray(value.checks) || value.checks.length > 24) return false
  if (value.replyRound !== undefined && (typeof value.replyRound !== 'number' || !Number.isSafeInteger(value.replyRound) || value.replyRound < 0)) return false
  if (value.setupConfirmed !== undefined && typeof value.setupConfirmed !== 'string') return false
  const question = (entry: unknown) => record(entry) && typeof entry.id === 'string' && typeof entry.question === 'string'
    && typeof entry.context === 'string' && ['allowance', 'reimbursement', 'payment'].includes(String(entry.component))
    && (entry.options === undefined || Array.isArray(entry.options) && entry.options.every(o => record(o) && typeof o.id === 'string' && typeof o.label === 'string'))
    && (entry.format === undefined || record(entry.format) && (entry.format.kind === 'text' || entry.format.kind === 'choices' && Array.isArray(entry.format.options) && entry.format.options.every(o => typeof o === 'string')))
  if (!value.entries.every(e => question(e) && record(e) && typeof e.value === 'string' && typeof e.answer === 'string')) return false
  if (new Set(value.entries.map(e => e.id)).size !== value.entries.length) return false
  if (value.deferred !== undefined && !question(value.deferred)) return false
  if (value.policy === MILEAGE_POLICY && !value.checks.every(c => record(c) && record(c.result) && record(c.result.mileage)
    && c.result.mileage.policyVersion === MILEAGE_POLICY && c.result.mileage.knowledgeVersion === MILEAGE_KNOWLEDGE_VERSION
    && c.result.mileage.earningsCode === 'MILEAGE' && ['Pending Verification', 'Recommendation Complete'].includes(String(c.result.mileage.decisionStatus))
    && c.result.mileage.documentationVerification === 'supplied-citations-only'
    && c.result.mileage.tenantVerification === 'not-inspected' && c.result.mileage.payrollValidation === 'not-performed'
    && ['Additional Clarification Needed', 'Pending Documentation Verification', 'Recommendation complete'].includes(String(c.result.mileage.outputStatus))
    && Array.isArray(c.result.mileage.components) && Array.isArray(c.result.mileage.outstandingQuestions)
    && Array.isArray(c.result.mileage.knownGaps) && Array.isArray(c.result.mileage.supportingUKGDocumentation)
    && typeof c.result.mileage.captured === 'boolean'
    && (c.result.mileage.customerSummary == null || typeof c.result.mileage.customerSummary === 'string'
      && !!c.result.mileage.customerSummary.trim() && c.result.mileage.customerSummary.length <= 1200)
    && (c.result.mileage.decisionStatus !== 'Recommendation Complete' || c.result.mileage.captured === true
      && c.result.mileage.outputStatus === 'Recommendation complete'
      && c.result.mileage.outstandingQuestions.length === 0 && c.result.mileage.components.length > 0
      && c.result.mileage.components.every(part => record(part) && part.decisionRuleStatus === 'recommendation_complete'
        && typeof part.selectionRationale === 'string' && !!part.selectionRationale.trim()
        && typeof part.recommendedRollUpType === 'string'
        && Array.isArray(part.documentationEvidence) && part.documentationEvidence.length > 0
        && part.documentationEvidence.every(e => record(e) && ['S1', 'S2', 'S3'].includes(String(e.source)) && typeof e.behavior === 'string')
        && Array.isArray(part.outstandingQuestions) && part.outstandingQuestions.length === 0)))) return false
  return value.checks.every(c => record(c) && typeof c.basis === 'string' && typeof c.at === 'number' && typeof c.after === 'number'
    && (c.mileageRevision === undefined || typeof c.mileageRevision === 'string')
    && record(c.result) && ['allowance-basis', 'reimbursement-basis', 'clarify', 'tax', 'pending'].includes(String(c.result.next))
    && ['allowance', 'reimbursement', 'payment'].includes(String(c.result.component))
    && typeof c.result.reason === 'string' && Array.isArray(c.result.confirmations)
    && (c.result.discovery === undefined || record(c.result.discovery)
      && ['sufficient', 'missing', 'conflict', 'unsupported'].includes(String(c.result.discovery.status))
      && (c.result.discovery.status === 'sufficient' ? c.result.discovery.missingFact === null
        : typeof c.result.discovery.missingFact === 'string' && !!c.result.discovery.missingFact.trim() && c.result.discovery.missingFact.length <= 300)
      && Array.isArray(c.result.discovery.answerIds) && c.result.discovery.answerIds.length > 0
      && c.result.discovery.answerIds.length <= 24 && c.result.discovery.answerIds.every(id => typeof id === 'string' && id.length <= 100))
    && c.result.confirmations.every(x => record(x) && ['allowance', 'reimbursement', 'payment'].includes(String(x.component))
      && ['taxable', 'nontaxable'].includes(String(x.intent)) && typeof x.answerId === 'string' && typeof x.quote === 'string')
    && (c.result.next !== 'clarify' || typeof c.result.question === 'string' && record(c.result.answerFormat)
      && (c.result.answerFormat.kind === 'text' || c.result.answerFormat.kind === 'choices' && Array.isArray(c.result.answerFormat.options))))
}

/** Applied decisions/sent text are history. Only unfinished work adopts the new question meanings. */
export function migrateCellFlow(session: EarningSession): EarningSession {
  session = resumeMileageStatus(session)
  const recovered = Object.fromEntries(Object.entries(session.answers).map(([id, answer]) =>
    [id, session.resolutions[id] ? answer : recheckCellPending(answer)]))
  if (Object.keys(recovered).some(id => recovered[id] !== session.answers[id])) session = { ...session, answers: recovered }
  const answer = session.answers[CELL_ID]
  if (answer?.cell && !answer.cell.policy && session.resolutions[CELL_ID]?.status === 'resolved') {
    return { ...session, answers: { ...session.answers, [CELL_ID]: { ...answer, cellLegacy: true } } }
  }
  if (!answer || answer.cell || answer.cellLegacy) return session
  const applied = session.resolutions[CELL_ID]
  if (applied && applied.status !== 'customer') return { ...session, answers: { ...session.answers, [CELL_ID]: { ...answer, cellLegacy: true } } }
  const method = CELL_METHODS.find(m => m.id === answer.choice)
  const cell: CellFlow = { ...emptyCell(), earlier: answer }
  // Carry known payment method/descriptions, never the old automatically taxable allowance or shared tax setting.
  if (method && (method.id !== 'other' || answer.descriptionSubmitted && answer.description?.trim())) cell.entries.push({
    id: 'method', question: CELL_OPENING, context: CELL_REASON, component: 'payment', options: CELL_METHODS,
    value: method.id, answer: method.id === 'other' ? answer.description! : [method.label, method.detail].join(' — '),
  })
  if ((method?.id === 'reimbursement' || method?.id === 'both') && ['taxable', 'qualifying'].includes(answer.followUps?.treatment ?? '')) {
    cell.entries.push({ id: 'prior-reimbursement-intent', component: 'reimbursement',
      question: 'Should the phone payback be taxed?', context: 'Earlier explicit answer, for reimbursement only.',
      value: answer.followUps!.treatment, answer: answer.followUps!.treatment === 'qualifying'
        ? 'No, it’s tax-free — Our adviser confirmed it meets the rules'
        : 'Yes, tax it as pay — It’s taxed the same way as wages' })
  }
  const next: ItemAnswer = { ...(method ? { choice: method.id } : {}), cell }
  return { ...session, answers: { ...session.answers, [CELL_ID]: next },
    customerQuestions: session.customerQuestions.map(q => q.itemId === CELL_ID ? { ...q, draft: undefined, draftBasis: undefined } : q) }
}
