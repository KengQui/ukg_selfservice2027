import { createContext, useContext, useLayoutEffect } from 'react'

/** A card counts its mounted follow-up questions, including live AI conversations. */
export const CardFollowUpContext = createContext<(() => () => void) | null>(null)

export function useCardFollowUp(active = true) {
  const register = useContext(CardFollowUpContext)
  useLayoutEffect(() => active ? register?.() : undefined, [register, active])
}
