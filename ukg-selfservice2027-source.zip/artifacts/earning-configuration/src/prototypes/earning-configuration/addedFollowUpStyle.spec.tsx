import { renderToStaticMarkup } from 'react-dom/server'
import { expect, it } from 'vitest'
import AddedCodesSection from './AddedCodesSection'
import { SessionContext } from './sessionContext'
import { createSession } from './session'

it.each([undefined, { entries: [] }, { entries: [], none: true as const }])('shows the question immediately for an empty session %j', addedCodes => {
  const session = { ...createSession(0), addedCodes }
  const doc = new DOMParser().parseFromString(renderToStaticMarkup(
    <SessionContext.Provider value={{ session, dispatch: () => {}, save: () => true, restart: () => true }}>
      <AddedCodesSection />
    </SessionContext.Provider>,
  ), 'text/html')
  expect(doc.querySelector('[data-testid="form-added-code"]')).not.toBeNull()
  expect(doc.querySelector('.ec-qcard--question-first .ec-qcard__title')?.textContent).toBe('What will this code pay for?')
  expect(doc.querySelector('[data-testid="form-added-code"] textarea')).not.toBeNull()
  expect(doc.querySelector('[data-testid="button-add-code"]')).toBeNull()
})

it('uses the shared numbered sequence for saved and current additional-code replies', () => {
  const session = createSession(0)
  session.addedCodes = { entries: [{
    id: 'added-1', code: '', name: '', description: 'Referral bonus',
    thread: [{ question: 'How much do you pay?', answer: '$500' }],
    check: { status: 'result', token: 'test', result: {
      outcome: 'question', question: 'When do you pay it?', summary: 'Referral bonus',
      facts: [], reason: 'Timing is missing', reference: null,
    } },
  }] }
  const doc = new DOMParser().parseFromString(renderToStaticMarkup(
    <SessionContext.Provider value={{ session, dispatch: () => {}, save: () => true, restart: () => true }}>
      <AddedCodesSection />
    </SessionContext.Provider>,
  ), 'text/html')
  expect(doc.querySelector('.ec-qcard__sequence-heading')?.textContent).toBe('Follow up questions')
  expect(doc.querySelector('.ec-qcard__heading .ec-qcard__title')?.textContent).toBe('What will this code pay for?')
  const savedAnswer = doc.querySelector('.ec-added__saved-answer textarea') as HTMLTextAreaElement
  expect(savedAnswer.value).toBe('Referral bonus')
  expect(savedAnswer.readOnly).toBe(true)
  expect(doc.querySelector('.ec-qcard__sequence-step--answered')?.getAttribute('data-sequence-number')).toBe('01')
  expect(doc.querySelector('.ec-qcard__sequence-answer')?.textContent).toBe('$500')
  expect(doc.querySelector('.ec-qcard__sequence-step--current')?.getAttribute('data-sequence-number')).toBe('02')
  expect(doc.querySelector('[data-testid="button-send-added-reply-added-1"]')?.textContent).toBe('Done')
})
