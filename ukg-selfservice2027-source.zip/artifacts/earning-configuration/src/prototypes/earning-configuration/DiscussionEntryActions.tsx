import { useEffect, useRef, type RefObject } from 'react'
import { Button } from '@ready/dls/compatibility'
import { useEarningSession } from './sessionContext'
import type { DiscussionInput } from './discussionProgress'

/** Checks stay in their owning cards; applying the complete proposal remains explicit. */
export default function DiscussionEntryActions({ page }: {
  entries: readonly DiscussionInput[]
  page: RefObject<HTMLDivElement | null>
}) {
  const { dispatch } = useEarningSession()
  const bar = useRef<HTMLDivElement>(null)
  // A passive effect runs after the parent page's host ref has been attached.
  useEffect(() => {
    const element = bar.current
    const container = page.current
    if (!element || !container) return
    // Native Tab scrolling considers sticky overlays visible. Keep focused content above this bar.
    const revealTarget = (target: EventTarget | null) => {
      if (!(target instanceof HTMLElement) || !container.contains(target) || element.contains(target)) return
      const rect = target.getBoundingClientRect()
      if (rect.bottom > element.getBoundingClientRect().top - 16 || rect.top < 80) {
        target.scrollIntoView({ block: 'center', behavior: 'instant' })
      }
    }
    const measure = () => {
      container.style.setProperty('--discussion-bar-height', `${element.getBoundingClientRect().height}px`)
      revealTarget(document.activeElement)
    }
    measure()
    const observer = typeof ResizeObserver === 'undefined' ? undefined : new ResizeObserver(measure)
    observer?.observe(element)
    const reveal = (event: FocusEvent) => revealTarget(event.target)
    container.addEventListener('focusin', reveal)
    return () => { observer?.disconnect(); container.removeEventListener('focusin', reveal) }
  }, [page])

  return <div ref={bar} className="ec-discussion-entry__bar" role="region" aria-label="Review navigation" data-testid="discussion-entry-actions">
    <div className="ec-discussion-entry__buttons">
      <Button variant="primary" size="large" data-testid="button-continue-optimization"
        onClick={() => dispatch({ type: 'startOptimization' })}>Continue to optimization</Button>
    </div>
  </div>
}
