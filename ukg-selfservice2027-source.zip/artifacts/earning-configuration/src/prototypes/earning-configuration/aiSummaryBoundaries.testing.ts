import { createSession, currentRound, reduceSession, type EarningSession } from './session'
import { ASK_CUSTOMER } from './sampleRegister'
import { consolidateRegisters } from './registerEvidence'
import { SAMPLE_REGISTER_FILES } from './sampleDocument'
import { discussionBasis } from './discussionAnswers'

// Independent copy fixture: changes to the presentation must not silently change approved wording.
export const APPROVED_BOUNDARIES = [
  'Summarize relevant answers, not the entire review. Include answers from a related code when they explain the current question.',
  'Distinguish facts from suggestions. An AI-proposed name or match is not an accepted decision until the user accepts it.',
  'Do not add questions. AI can explain the remaining gap, but the active question must still be the one explicitly deferred.',
  'Do not infer missing facts, especially tax treatment, from a code name or register.',
  'Keep discussion responses separate from applied decisions. Something recorded during the call must not be described as an approved setup change.',
  'Keep the original answers accessible. The summary helps people understand them; it does not replace them.',
  'If there are no earlier answers, do not manufacture context. Show the question and available source evidence.',
]

/** Fictional in-memory fixtures only; never imported by the shipped app. */
export function boundariesReviewFixture(variant: 'sample' | 'uploaded'): EarningSession {
  if (variant === 'sample') {
    let session: EarningSession = { ...createSession(1), files: [...SAMPLE_REGISTER_FILES],
      callAnswers: { SPPAY: 'Keep this discussion note separate from setup.' },
    }
    session = reduceSession(session, { type: 'startReview' }, 2)
    for (const itemId of currentRound(session)!.itemIds) {
      session = reduceSession(session, { type: 'choose', itemId, choice: itemId === 'BONREV' ? 'accept' : ASK_CUSTOMER }, 2)
    }
    const question = 'What does Special Pay pay for?'
    session = reduceSession(session, { type: 'selectDeferredQuestion', itemId: 'SPPAY', source: { question, choices: [] } }, 2)
    session = reduceSession(session, { type: 'submitRound' }, 3)
    session = reduceSession(session, { type: 'finishReevaluation' }, 4)
    return reduceSession(session, { type: 'setDiscussionAnswer', itemId: 'SPPAY', question,
      kind: 'text', basis: discussionBasis(session, 'SPPAY'), change: { text: 'A stipend for using a second language.' } }, 5)
  }
  const session: EarningSession = { ...createSession(1), step: 'review', registerSource: 'uploads',
    files: [{
      id: 'boundary-fixture', name: 'fictional-register.csv', docType: 'Pay register', sizeBytes: 100,
      status: 'ready', evidence: { warnings: [], reports: [{
        company: 'Fictional Harbor Co', companyId: 'DEMO-HARBOR',
        periodStart: '2026-01-01', periodEnd: '2026-01-15', periodLabel: 'January, first payroll',
        reportId: null, currency: 'USD',
        rows: [{ code: 'REG', description: 'Regular pay', section: 'earnings', amount: 1000,
          people: 4, locator: 'CSV, row 2', quote: 'REG | Regular pay | 1000 | 4' }],
      }] },
    }],
  }
  session.callAnswers = { [consolidateRegisters(session.files)[0].id]: 'Confirm the policy on the call.' }
  return session
}
