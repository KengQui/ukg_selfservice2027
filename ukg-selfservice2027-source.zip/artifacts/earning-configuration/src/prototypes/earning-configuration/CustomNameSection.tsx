import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react'
import Link from '@ready/dls/components/Link/Link'
import { Button, InlineMessage } from '@ready/dls/compatibility'
import { AILoader } from '@ready/dls/ai'
import { QuestionSection, type QuestionSequenceStep } from './QuestionCard'
import type { UnidentifiedItem } from './sampleRegister'
import { ACCEPT_NAME, KEEP_NAME, activeNaming, lookupResult, namingBasis, openCheckQuestion, type ItemAnswer, type SessionAction } from './session'
import { AiQuestionStep } from './AiQuestionStep'
import { namingRequest, requestCustomName } from './customName'
import { somethingElseChoice } from './SomethingElseOption'
import { SOMETHING_ELSE_NAME } from './somethingElse'
import { useEarningSession } from './sessionContext'
import { useProposalCheck } from './proposalAssessment'

type RequestState = { basis: string; status: 'loading' } | { basis: string; status: 'error'; message: string }

/**
 * Failures by code and answers, kept across remounts so moving between pages doesn't send the same request again on
 * its own. Try again always sends a new one.
 */
const failures = new Map<string, { basis: string; message: string }>()

interface CustomNameSectionProps {
  item: UnidentifiedItem
  answer: ItemAnswer
  dispatch: (action: SessionAction) => void
  sequenceNumber?: number
  sequenceContinues?: boolean
}

/**
 * Shown only when the reference lookup explicitly found no suitable reference. Asks the AI for one custom name, or for
 * the missing information, once per set of answers. It appears as a follow-up section inside the code's card.
 * A failure keeps every answer and offers Try again or Defer; it never stands in a name.
 */
export default function CustomNameSection({ item, answer, dispatch, sequenceNumber, sequenceContinues }: CustomNameSectionProps) {
  const basis = namingBasis(answer)
  const { session } = useEarningSession()
  const storedNaming = activeNaming(item, answer)
  const resolution = session.resolutions[item.id]
  const appliedName = resolution?.status === 'review' && resolution.customName?.name === storedNaming?.name
  // Refresh the existing Special Pay proposal, not an accepted setup-review name
  // or another code's saved suggestion. Never substitute a canned short label.
  const refreshLongProposal = item.id === 'SPPAY' && storedNaming?.outcome === 'suggestion'
    && (storedNaming.name?.length ?? 0) > 12 && !appliedName && answer.choice !== KEEP_NAME
  const naming = refreshLongProposal ? undefined : storedNaming
  const attemptKey = refreshLongProposal ? `${basis}:compact` : basis
  const assessment = useProposalCheck(`${item.id}:name`, naming ? undefined : attemptKey)
  const lookup = lookupResult(item, answer)
  const failure = assessment.scoped ? undefined : failures.get(item.id)
  const [request, setRequest] = useState<RequestState | undefined>(
    failure?.basis === basis ? { basis, status: 'error', message: failure.message } : undefined)
  // The in-flight request and the answers it was sent for, so only that request is cancelled when they change.
  const controller = useRef<{ basis: string; abort: AbortController } | undefined>(undefined)
  const currentBasis = useRef(basis)
  currentBasis.current = basis
  const attempted = useRef<string | undefined>(failure?.basis === basis ? attemptKey : undefined)

  const run = useCallback(() => {
    const input = namingRequest(item, answer)
    if (!input) return
    controller.current?.abort.abort()
    const active = new AbortController()
    const requestBasis = basis
    controller.current = { basis: requestBasis, abort: active }
    attempted.current = attemptKey
    if (!assessment.scoped) failures.delete(item.id)
    setRequest({ basis: requestBasis, status: 'loading' })
    assessment.start()
    requestCustomName(input, active.signal).then(response => {
      // A response for answers that have since changed, or for a closed section, no longer applies.
      if (active.signal.aborted || currentBasis.current !== requestBasis) return
      if (controller.current?.abort === active) controller.current = undefined
      if (response.ok) {
        assessment.finish()
        setRequest(undefined)
        dispatch({ type: 'setNaming', itemId: item.id, basis: requestBasis, result: response.result })
      } else {
        assessment.fail(response.message)
        if (!assessment.scoped) failures.set(item.id, { basis: requestBasis, message: response.message })
        setRequest({ basis: requestBasis, status: 'error', message: response.message })
      }
    }, () => { /* aborted */ })
  }, [item, answer, basis, attemptKey, dispatch])

  useEffect(() => {
    if (assessment.readOnly || assessment.problem) return
    if (naming || attempted.current === attemptKey) return
    run()
  }, [attemptKey, naming, run])

  // Changed answers make an in-flight request for the earlier answers stale. A replacement request started for the
  // current answers is left running.
  useEffect(() => {
    const inFlight = controller.current
    if (!inFlight || inFlight.basis === basis) return
    inFlight.abort.abort()
    controller.current = undefined
    setRequest(current => current?.status === 'loading' && current.basis !== basis ? undefined : current)
  }, [basis])
  // Closing the section cancels its request. A request cancelled before it finished never happened, so a remount (or
  // React's development double mount) sends it again instead of waiting on a response that won't arrive.
  useEffect(() => () => {
    const inFlight = controller.current
    if (!inFlight) return
    inFlight.abort.abort()
    controller.current = undefined
    if (!failures.has(item.id)) attempted.current = undefined
    setRequest(current => current?.status === 'loading' ? undefined : current)
  }, [item.id])

  const unusable = !naming && attempted.current === attemptKey && !request && !controller.current
  useEffect(() => {
    if (unusable && !assessment.problem) assessment.fail('We couldn’t suggest a usable name this time. Try again.')
  }, [unusable, attemptKey])
  if (lookup.kind !== 'noMatch') return null
  const pending: RequestState | undefined = assessment.problem
    ? { basis, status: 'error', message: assessment.problem } : request?.basis === basis ? request : undefined
  const editDescription = assessment.scoped ? undefined : (
    <div className="ec-naming__actions">
      <Link size="sm" onClick={() => dispatch({ type: 'editDescription', itemId: item.id })}>Edit description</Link>
    </div>
  )
  const announcement = naming?.outcome === 'suggestion' ? `We suggested the name ${naming.name}.`
    : naming?.outcome === 'needsInformation' ? 'We need more information to suggest a name.'
      : pending?.status === 'loading' ? 'We’re suggesting a name…'
        : pending?.status === 'error' ? pending.message : ''
  const choose = (choice: string) => dispatch({ type: 'choose', itemId: item.id, choice })
  const otherwise = somethingElseChoice({ itemId: item.id, question: SOMETHING_ELSE_NAME, answer, dispatch })
  const accepted = answer.choice === ACCEPT_NAME
  const kept = answer.choice === KEEP_NAME
  const answeredSomethingElse = answer.somethingElse?.question === SOMETHING_ELSE_NAME && !!answer.somethingElse.submitted
  const sequenceStep: QuestionSequenceStep | undefined = sequenceNumber === undefined ? undefined : {
    number: sequenceNumber,
    state: accepted || kept || answeredSomethingElse ? 'answered' : 'current',
    summary: kept ? `Keep ‘${item.code}’` : accepted && naming?.name ? `Use ‘${naming.name}’` : answeredSomethingElse ? answer.somethingElse?.description.trim() : undefined,
    continues: sequenceContinues,
  }

  return (
    <div className="ec-naming">
      <p className="ec-visually-hidden" role="status">{announcement}</p>
      {naming?.outcome === 'suggestion' && naming.name ? (
        <QuestionSection
          question={`Use ‘${naming.name}’ for ${item.code}?`}
          context={
            <div className="ec-naming__details">
               <p>{naming.rationale}</p>
               <span className="ec-reference">Suggested by AI</span>
            </div>
          }
          answer={editDescription}
          options={[
             { id: ACCEPT_NAME, title: `Use ‘${naming.name}’`, subHeading: 'Accept this name for the described payment purpose. Tax and setup details stay separate.' },
            { id: KEEP_NAME, title: `Keep ‘${item.code}’`, subHeading: 'Keep your existing name for the described payment purpose. Your live payroll stays unchanged.' },
            otherwise.option,
          ]}
          defer
          selected={otherwise.selected(answer.choice)}
          onSelect={otherwise.onSelect(choose)}
          sequenceStep={sequenceStep}
        />
      ) : naming?.outcome === 'needsInformation' && assessment.scoped && openCheckQuestion(item, answer) ? (
        <AiQuestionStep question={naming.question!} format={{ kind: 'text' }} number={sequenceNumber ?? 1}
          context="This detail helps give the payment a clear name. Your earlier description and replies are kept; a name does not confirm tax treatment or a Ready reference."
          onAnswer={reply => dispatch({ type: 'answerCheckQuestion', itemId: item.id, answer: reply })}
          defer deferSelected={answer.choice} onDeferSelect={choose} />
      ) : naming?.outcome === 'needsInformation' && assessment.scoped ? (
        <p className="ec-section-note">The purpose still needs a setup specialist’s review: {naming.question} Your earlier answers are kept.</p>
      ) : naming?.outcome === 'needsInformation' ? (
        <QuestionSection
          question={naming.question}
          context={
            <div className="ec-naming__details">
               <p>The purpose detail asked above is still missing for {item.code}.</p>
               <p>{lookup.reason} A name needs to explain what this payment is for on a pay statement, rather than repeat an unclear code.</p>
               <p>Add that detail to the description to get a name proposal for your confirmation, or select Review later. A name does not determine tax treatment or finish setup.</p>
            </div>
          }
          answer={editDescription}
          defer
          selected={answer.choice}
          onSelect={choose}
          sequenceStep={sequenceStep}
        />
      ) : (
        <QuestionSection
          question={`What should we call ${item.code}?`}
          context={
            <div className="ec-naming__details">
              <p>{lookup.reason} We’ll suggest a clear name based on what it pays for.</p>
              {pending?.status === 'loading' && (
                <span className="ec-naming__loading" aria-hidden="true">We’re suggesting a name <AILoader /></span>
              )}
              {pending?.status === 'error' && <InlineMessage theme="error">{pending.message}</InlineMessage>}
            </div>
          }
          answer={pending?.status === 'error' ? (
            <div className="ec-naming__actions">
              <Button variant="secondary" size="small" onClick={run}>Try again</Button>
              {!assessment.scoped && <Link size="sm" onClick={() => dispatch({ type: 'editDescription', itemId: item.id })}>Edit description</Link>}
            </div>
          ) : undefined}
          defer
          selected={answer.choice}
          onSelect={choose}
          sequenceStep={sequenceStep}
        />
      )}
    </div>
  )
}
