import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import DemoFill from './DemoFill'
import { DEMO_CHOICES, DEMO_DESCRIPTIONS, DEMO_MILEAGE_RATE, demoFill } from './demoAnswers'
import { ALL_ITEMS, ASK_CUSTOMER, EARNING_FINDINGS, EMPLOYER_CODE_QUESTION, EXISTING_CODE, SUGGESTED_CODE, READY, REVIEW_INITIAL_ITEMS, findItem } from './sampleRegister'
import { ACCEPT_NAME, createSession, decisionFor, namingBasis, reduceSession, reviewPages, sharedSetupFor, shiftPremiumFor, type DescriptionCheck, type EarningSession, type SessionAction } from './session'
import { SessionContext } from './sessionContext'
import { checkRequest } from './descriptionCheck'
import { cellBasis } from './cellFlow'
import { cellResult } from './cellFlow.testing'

const run = (session: EarningSession, ...actions: SessionAction[]) => actions.reduce((state, action) => reduceSession(state, action, 1), session)
const started = () => run(createSession(0), { type: 'startReview' })
const fill = (session: EarningSession, ids: string[]) => run(session, ...demoFill(session, ids))
const check = (session: EarningSession, itemId: string, result: DescriptionCheck) => run(session,
  { type: 'checkDescription', itemId, basis: namingBasis(session.answers[itemId]), result })
const done = (session: EarningSession, itemId: string) => run(session, { type: 'submitDescription', itemId })

describe('presenter demo answers', () => {
  it.each([...new Set([...REVIEW_INITIAL_ITEMS, ...EARNING_FINDINGS].map(item => item.id))])(
    'covers current review item %s through a real offered action', id => {
      const session = started()
      const before = JSON.stringify(session)
      const actions = demoFill(session, [id])
      const item = findItem(id)
      expect(actions.length).toBeGreaterThan(0)
      if (item.type === 'unidentified') {
        expect(actions).toContainEqual({ type: 'describe', itemId: id, description: DEMO_DESCRIPTIONS[id] })
      } else if (id === 'CELL-purpose') {
        expect(actions).toEqual([{ type: 'cell', itemId: id, event: { kind: 'answer', id: 'method', value: 'allowance' } }])
      } else if (id === 'MILEAGE') {
        expect(actions).toEqual([{ type: 'cell', itemId: id, event: { kind: 'answer', id: 'method', value: 'per-mile' } }])
      } else {
        // MILEAGE also types the demo's per-mile rate; Done stays manual.
        expect(actions).toEqual([{ type: 'choose', itemId: id, choice: DEMO_CHOICES[id].choice },
          ...(id === 'MED ER' ? [{ type: 'answerFollowUp', itemId: id, questionId: 'medical-display', choice: 'yes' }] : []),
          ...(id === 'TIPS' ? [{ type: 'answerFollowUp', itemId: id, questionId: 'tips-method', choice: 'payroll' }] : []),
          ...(id === 'MILEAGE' ? [{ type: 'enterMileageRate', itemId: id, amount: DEMO_MILEAGE_RATE }] : [])])
        const offered = item.type === 'misclassification' ? [item.accept.id] : item.options.map(option => option.id)
        expect(offered).toContain(DEMO_CHOICES[id].choice)
      }
      expect(JSON.stringify(session)).toBe(before)
      expect(actions.every(action => !('choice' in action) || action.choice !== ASK_CUSTOMER)).toBe(true)
      expect(actions.every(action => ['choose', 'describe', 'enterMileageRate', 'answerFollowUp', 'cell'].includes(action.type))).toBe(true)
    },
  )

  it('keeps every map entry tied to an actual option, including legacy findings', () => {
    for (const [id, script] of Object.entries(DEMO_CHOICES)) {
      const item = ALL_ITEMS.find(item => item.id === id)!
      expect(item, id).toBeDefined()
      if (item.type === 'unidentified') throw new Error(`Unexpected described choice: ${id}`)
      const offered = item.type === 'misclassification' ? [item.accept.id] : item.options.map(option => option.id)
      expect(offered, id).toContain(script.choice)
      expect(script.choice).not.toBe(ASK_CUSTOMER)
    }
  })

  it('fills only supplied cards once, leaving descriptions unsubmitted for the presenter', () => {
    const session = fill(started(), ['SPPAY', 'SPPAY', 'MISC7'])
    expect(Object.keys(session.answers).sort()).toEqual(['MISC7', 'SPPAY'])
    expect(session.answers.SPPAY.description).toBe(DEMO_DESCRIPTIONS.SPPAY)
    expect(session.answers.MISC7.description).toBe(DEMO_DESCRIPTIONS.MISC7)
    expect(session.answers.SPPAY.descriptionSubmitted).not.toBe(true)
    expect(session.answers.MISC7.descriptionSubmitted).not.toBe(true)
    expect(demoFill(session, ['SPPAY', 'MISC7'])).toEqual([])
  })

  it.each([EXISTING_CODE, ASK_CUSTOMER])('never overwrites existing choices, text, follow-ups, relationship answers or Defer with DEN employer code %s', pick => {
    const session: EarningSession = {
      ...started(), answers: {
        BONREV: { choice: ASK_CUSTOMER },
        OTPREM: { choice: 'full' },
        SPPAY: { choice: 'retro' },
        MISC7: { description: 'The presenter’s own description' },
        ADJ2: { retain: 'remove', description: '' },
        DEN: { choice: 'both', followUps: { [EMPLOYER_CODE_QUESTION]: pick } },
        'CELL-purpose': { choice: 'both', followUps: { treatment: 'qualifying', split: 'confirm' } },
      },
    }
    expect(demoFill(session, Object.keys(session.answers))).toEqual([])
    const described = check(done(fill(started(), ['MISC7']), 'MISC7'), 'MISC7',
      { kind: 'reference', referenceId: READY.shift.id, reason: 'Night shift purpose; SHIFT2 already uses Shift differential.' })
    const accepted = run(described, { type: 'choose', itemId: 'MISC7', choice: 'accept' },
      { type: 'answerSharedSetup', itemId: 'MISC7', referenceId: READY.shift.id, choice: 'other' })
    expect(demoFill(accepted, ['MISC7'])).toEqual([])
    expect(demoFill({ ...started(), answers: { ADJ2: { retain: 'keep', description: '' } } }, ['ADJ2'])).toEqual([])
    expect(demoFill({ ...started(), answers: { 'CELL-purpose': { choice: 'both', followUps: { split: 'confirm' } } } }, ['CELL-purpose'])).toEqual([])
  })

  it('accepts the live SPPAY custom name only once it is available', () => {
    let session = done(fill(started(), ['SPPAY']), 'SPPAY')
    expect(demoFill(session, ['SPPAY'])).toEqual([])
    session = check(session, 'SPPAY', { kind: 'noMatch', reason: 'The supplied references do not cover a language stipend.' })
    expect(demoFill(session, ['SPPAY'])).toEqual([])
    session = run(session, { type: 'setNaming', itemId: 'SPPAY', basis: namingBasis(session.answers.SPPAY),
      result: { outcome: 'suggestion', name: 'Language stipend', rationale: 'A monthly payment for using a second language.' } })
    expect(demoFill(session, ['SPPAY'])).toEqual([{ type: 'choose', itemId: 'SPPAY', choice: ACCEPT_NAME }])
    expect(demoFill(fill(session, ['SPPAY']), ['SPPAY'])).toEqual([])
  })

  it('accepts the per diem match without a same-pay decision or shift follow-ups', () => {
    let session = check(done(fill(started(), ['MISC7']), 'MISC7'), 'MISC7',
      { kind: 'reference', referenceId: READY.perDiem.id, reason: 'A meal allowance at the federal rate for overnight work travel.' })
    expect(demoFill(session, ['MISC7'])).toEqual([{ type: 'choose', itemId: 'MISC7', choice: 'accept' }])
    session = fill(session, ['MISC7'])
    const item = findItem('MISC7')
    expect(session.answers.MISC7.description).toBe('A daily meal allowance at the federal per diem rate when employees travel overnight for work')
    expect(sharedSetupFor(item, session.answers.MISC7)).toBeUndefined()
    expect(shiftPremiumFor(item, session.answers.MISC7)).toBeUndefined()
    expect(decisionFor(item, session.answers.MISC7)).toBeUndefined()
    expect(session.answers.MISC7.reimbursement?.category).toBe('PERDIEM')
    expect(session.answers.MISC7.sharedSetup).toBeUndefined()
    expect(session.answers.MISC7.shiftPremium).toBeUndefined()
    expect(demoFill(session, ['MISC7'])).toEqual([])
  })

  it('sends the exact per diem description to the live check with no invented existing shift or per diem code', () => {
    const session = done(fill(started(), ['MISC7']), 'MISC7')
    const item = findItem('MISC7')
    if (item.type !== 'unidentified') throw new Error('Expected a described code')
    const request = checkRequest(item, session.answers.MISC7)
    expect(request.description).toBe(DEMO_DESCRIPTIONS.MISC7)
    expect(request.references.find(reference => reference.id === READY.perDiem.id)).toEqual({
      id: READY.perDiem.id, name: 'Per diem (non-taxable)',
    })
    expect(request.references.find(reference => reference.id === READY.shift.id)?.inUseBy).toBeUndefined()
  })

  it('answers only the ADJ2 follow-up actually asked, then keeps and accepts it in stage order', () => {
    let session = done(fill(started(), ['ADJ2']), 'ADJ2')
    session = check(session, 'ADJ2', { kind: 'followUp', questionId: 'basis' })
    expect(demoFill(session, ['ADJ2'])).toEqual([{ type: 'answerFollowUp', itemId: 'ADJ2', questionId: 'basis', choice: 'flat' }])
    session = fill(session, ['ADJ2'])
    expect(demoFill(session, ['ADJ2'])).toEqual([])
    session = check(session, 'ADJ2', { kind: 'followUp', questionId: 'frequency' })
    expect(demoFill(session, ['ADJ2'])).toEqual([{ type: 'answerFollowUp', itemId: 'ADJ2', questionId: 'frequency', choice: 'one-time' }])
    session = check(fill(session, ['ADJ2']), 'ADJ2', { kind: 'reference', referenceId: READY.retro.id, reason: 'A correction to earlier pay.' })
    expect(demoFill(session, ['ADJ2'])).toEqual([{ type: 'chooseRetention', itemId: 'ADJ2', choice: 'keep' }])
    session = fill(session, ['ADJ2'])
    expect(demoFill(session, ['ADJ2'])).toEqual([{ type: 'choose', itemId: 'ADJ2', choice: 'accept' }])
    expect(demoFill(fill(session, ['ADJ2']), ['ADJ2'])).toEqual([])
  })

  it('leaves requests for more information and stale AI results to the presenter', () => {
    for (const id of ['SPPAY', 'MISC7', 'ADJ2']) {
      const session = check(done(fill(started(), [id]), id), id, { kind: 'needsInformation', question: 'What purpose does this payment cover?' })
      expect(demoFill(session, [id])).toEqual([])
    }
    let named = check(done(fill(started(), ['SPPAY']), 'SPPAY'), 'SPPAY', { kind: 'noMatch', reason: 'No supplied reference fits.' })
    named = run(named, { type: 'setNaming', itemId: 'SPPAY', basis: namingBasis(named.answers.SPPAY),
      result: { outcome: 'needsInformation', question: 'How is the stipend calculated?' } })
    expect(demoFill(named, ['SPPAY'])).toEqual([])
    const stale = check(done(fill(started(), ['MISC7']), 'MISC7'), 'MISC7',
      { kind: 'reference', referenceId: READY.shift.id, reason: 'Night shift purpose.' })
    expect(demoFill({ ...stale, answers: { ...stale.answers, MISC7: { ...stale.answers.MISC7, description: 'A different purpose' } } }, ['MISC7'])).toEqual([])
  })

  it('fills CELL by stage, fills MED ER and display Yes, and never fills DEN', () => {
    const allowance = fill(started(), ['CELL-purpose'])
    expect(allowance.answers['CELL-purpose'].choice).toBe('allowance')
    expect(demoFill(allowance, ['CELL-purpose'])).toEqual([{ type: 'cell', itemId: 'CELL-purpose', event: { kind: 'answer', id: 'allowance-purpose', value: 'business' } }])
    let cell = fill(allowance, ['CELL-purpose'])
    expect(demoFill(cell, ['CELL-purpose'])).toEqual([]) // The live check is never fabricated.
    cell = run(cell, { type: 'cell', itemId: 'CELL-purpose', event: { kind: 'checked', basis: cellBasis(cell.answers['CELL-purpose']), result: cellResult(), at: 1 } })
    expect(demoFill(cell, ['CELL-purpose'])).toEqual([{ type: 'cell', itemId: 'CELL-purpose', event: { kind: 'answer', id: 'tax-allowance', value: 'taxable' } }])
    expect(demoFill(fill(cell, ['CELL-purpose']), ['CELL-purpose'])).toEqual([])
    const medical = fill(started(), ['MED', 'MED ER'])
    expect(medical.answers['MED ER']).toMatchObject({ choice: 'only-records', followUps: { 'medical-display': 'yes' } })
    expect(demoFill(medical, ['MED ER', 'DEN'])).toEqual([])
    expect(medical.answers.DEN).toBeUndefined()
    expect(medical.rounds[0].submitted).toBe(false)
  })

  it('does nothing outside review, on submitted rounds, or for already applied cards', () => {
    expect(demoFill(createSession(0), ['BONREV'])).toEqual([])
    expect(demoFill({ ...started(), step: 'summary' }, ['BONREV'])).toEqual([])
    expect(demoFill({ ...started(), rounds: [{ ...started().rounds[0], submitted: true }] }, ['BONREV'])).toEqual([])
    expect(demoFill({ ...started(), resolutions: { BONREV: { status: 'resolved', reference: READY.bonusReversal, round: 1 } } }, ['BONREV'])).toEqual([])
  })
})

describe('invisible presenter control', () => {
  let host: HTMLDivElement
  let root: Root
  beforeEach(() => {
    (globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
    host = document.createElement('div')
    document.body.append(host)
    root = createRoot(host)
  })
  afterEach(() => {
    act(() => root.unmount())
    host.remove()
  })
  const render = (session: EarningSession, dispatch = vi.fn()) => {
    act(() => root.render(
      <SessionContext.Provider value={{ session, dispatch, save: () => true, restart: () => true }}>
        <DemoFill />
      </SessionContext.Provider>,
    ))
    return dispatch
  }

  it('is invisible, untabbable and unlabelled, and is absent on every other step', () => {
    render(started())
    const button = host.querySelector<HTMLButtonElement>('[data-demo-fill]')!
    expect(button.tabIndex).toBe(-1)
    expect(button.getAttribute('aria-hidden')).toBe('true')
    expect(button.hasAttribute('aria-label')).toBe(false)
    expect(button.hasAttribute('title')).toBe(false)
    expect(button.textContent).toBe('')
    expect(button.style.position).toBe('fixed')
    expect(button.style.top).toBe('0px')
    expect(button.style.right).toBe('0px')
    expect(button.style.opacity).toBe('0')
    expect(button.style.width).toBe('48px')
    expect(Number(button.style.zIndex)).toBeGreaterThan(1)
    expect(Number(button.style.zIndex)).toBeLessThan(400)
    for (const step of ['intro', 'categorySelection', 'upload', 'analysis', 'results', 'reevaluation', 'review',
      'optimization', 'optimizationReview', 'overtime', 'overtimeSort', 'summary'] as const) {
      render({ ...started(), step })
      expect(host.querySelector('button')).toBeNull()
    }
  })

  it('dispatches only the current page’s actions, including plans and an added-question round', () => {
    const session = started()
    const pages = reviewPages(session)
    for (let index = 0; index < pages.length; index++) {
      const current = { ...session, reviewCursor: index }
      const dispatch = render(current)
      act(() => host.querySelector<HTMLButtonElement>('button')!.click())
      expect(dispatch.mock.calls.map(([action]) => action)).toEqual(demoFill(current, pages[index]))
    }
    const added: EarningSession = { ...session, rounds: [
      { ...session.rounds[0], submitted: true },
      { number: 2, itemIds: ['HSA ER', 'DEN ER'], submitted: false, kind: 'added-questions' },
    ], reviewCursor: 0 }
    const dispatch = render(added)
    act(() => host.querySelector<HTMLButtonElement>('button')!.click())
    expect(dispatch.mock.calls.map(([action]) => action)).toEqual(demoFill(added, reviewPages(added)[0]))
  })
})