import { useCallback } from 'react'
import { useNavigate } from '@workspace/setup-shared/prototypes/_shared/navigation'
import { useEarningSession } from './sessionContext'

/** Company Setup's hub; the shared navigation keeps the demo query when it leaves this app. */
export const HUB_ROUTE = '/prototypes/company-setup-hub'

/** Save and finish later: writes the saved copy, then returns to the hub. False when the save failed. */
export function useSaveAndExit() {
  const { save } = useEarningSession()
  const navigate = useNavigate()
  return useCallback(() => {
    if (!save()) return false
    navigate(HUB_ROUTE)
    return true
  }, [save, navigate])
}
