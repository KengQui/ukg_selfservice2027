import type { ReactNode } from 'react'
import QuestionCard, { QuestionSection, type QuestionOption } from './QuestionCard'
import DescribeAnswerBox, { DescribeBoxView } from './DescribeAnswerBox'
import { SOMETHING_ELSE, SOMETHING_ELSE_LABEL } from './somethingElse'
import { CELL_ID, cellFollowUpQuestions, cellDecision, cellCustomerQuestion, type CellStage } from './cell'
import { ASK_CUSTOMER, DESCRIBE_CHOICE, findItem, type ClarificationItem } from './sampleRegister'
import { questionCardVariant, type ItemAnswer, type SessionAction } from './session'
import { somethingElseChoice } from './SomethingElseOption'
import ReasonParagraphs from './ReasonParagraphs'
import AdaptiveCellQuestions from './AdaptiveCellQuestions'
import { historicalCellItem } from './cellHistory'

/** Each option's title, detail and, for the purpose question's “We…” options, its example on its own line. */
const optionsOf = (options: { id: string; label: string; detail?: string; example?: string }[]) =>
  options.map(option => ({ id: option.id, title: option.label, subHeading: option.detail, ...(option.example ? { example: option.example } : {}) }))

/** The purpose options, then Something else with no subtitle; its description box opens inside it once selected. */
function purposeOptions(item: ClarificationItem, describeBox?: ReactNode): QuestionOption[] {
  return [
    ...optionsOf(item.options),
    ...(item.describe ? [{ id: DESCRIBE_CHOICE, title: item.describe.label, ...(describeBox ? { content: describeBox } : {}) }] : []),
  ]
}

/** The visible line says what the answer does; the reasons stay under Why we’re asking. */
function purposeIntro(item: ClarificationItem, variant: 'standard' | 'misclassification') {
  const overview = item.overview ? <p className="ec-qcard__prompt">{item.overview}</p> : undefined
  return variant === 'misclassification'
    ? { knownFact: overview, why: <ReasonParagraphs text={item.context} /> }
    : { context: <>{overview}<details className="ec-asking"><summary>Why we’re asking</summary><div className="ec-asking__body"><ReasonParagraphs text={item.context} /></div></details></> }
}

/** CELL's purpose question; the treatment and split questions appear inside the same card as they arrive. */
export default function CellQuestions({ answer, label, onAnswer, onClearAnswers }: {
  answer: ItemAnswer; label: string; onAnswer: (action: SessionAction) => void; onClearAnswers?: () => void
}) {
  if (!answer.cellLegacy) return <AdaptiveCellQuestions answer={answer} label={label} onClearAnswers={onClearAnswers}
    onEvent={event => onAnswer({ type: 'cell', itemId: CELL_ID, event })} />
  const item = historicalCellItem()
  const variant = questionCardVariant(CELL_ID)
  const questions = cellFollowUpQuestions(answer)
  return <div className="ec-thread" role="group" aria-label="CELL questions">
    <QuestionCard label={label} sourceItemId={item.id} question={item.question} variant={variant} {...purposeIntro(item, variant)}
      onClearAnswers={onClearAnswers}
      answered={!!cellDecision(answer)} selected={answer.choice}
      options={purposeOptions(item, <DescribeAnswerBox itemId={CELL_ID} answer={answer} dispatch={onAnswer} />)} defer
      onSelect={choice => onAnswer({ type: 'choose', itemId: CELL_ID, choice })}
      followUpSequenceCount={questions.length}
      followUpSequence={questions.length > 0 && <>
        {questions.map((question, index) => {
          // The tax and split questions end with Something else; purpose keeps its own above.
          const otherwise = somethingElseChoice({ itemId: CELL_ID, question: question.id, answer, dispatch: onAnswer })
          const selected = otherwise.selected(answer.followUps?.[question.id])
          const pendingSomethingElse = selected === otherwise.option.id
            && answer.somethingElse?.question === question.id && !answer.somethingElse.submitted
          const answered = !!selected && selected !== ASK_CUSTOMER && !pendingSomethingElse
          const summary = selected === otherwise.option.id && answer.somethingElse?.question === question.id
            ? answer.somethingElse.description.trim() || undefined
            : undefined
          return <QuestionSection key={question.id} label="CELL"
            question={question.question} context={question.context}
            options={[...optionsOf(question.options), otherwise.option]} defer
            selected={selected}
            onSelect={otherwise.onSelect(choice => onAnswer({ type: 'answerFollowUp', itemId: CELL_ID, questionId: question.id, choice }))}
            sequenceStep={{ number: index + 1, state: answered ? 'answered' : 'current', summary, continues: index < questions.length - 1 }} />
        })}
      </>} />
  </div>
}

/**
 * A reply answers only its outstanding question. It shows CELL's one card with the questions the customer already
 * answered read-only above it, the same way the review shows them. On the purpose question, Something else opens the
 * same description box as in the review; `reply` holds the dialog's unsaved description.
 */
export function CellReplyQuestion({ stage, answer, choice, onSelect, reply = {}, onDescribe }: {
  stage: CellStage; answer: ItemAnswer; choice: string; onSelect: (choice: string) => void
  reply?: ItemAnswer; onDescribe?: (action: SessionAction) => void
}) {
  const item = findItem(CELL_ID) as ClarificationItem
  const outstanding = { selected: choice, onSelect }
  if (stage === 'purpose') {
    return <QuestionCard label="CELL" sourceItemId={item.id} question={item.question} variant={questionCardVariant(CELL_ID)}
      answered={choice === DESCRIBE_CHOICE ? cellDecision(reply)?.kind === 'describe' : !!choice}
      options={purposeOptions(item, onDescribe && <DescribeAnswerBox itemId={CELL_ID} answer={reply} dispatch={onDescribe} />)} {...purposeIntro(item, questionCardVariant(CELL_ID))} {...outstanding} />
  }
  const followUps = cellFollowUpQuestions(answer)
  const treatment = followUps.find(question => question.id === 'treatment')
  const split = followUps.find(question => question.id === 'split')
  // The open tax or split question ends with Something else; its box holds the reply's unsaved description.
  const otherwise = { id: SOMETHING_ELSE, title: SOMETHING_ELSE_LABEL, ...(onDescribe ? { content:
    <DescribeBoxView description={reply.somethingElse?.description ?? ''} submitted={!!reply.somethingElse?.submitted}
      onChange={description => onDescribe({ type: 'describeSomethingElse', itemId: CELL_ID, description })}
      onDone={() => onDescribe({ type: 'submitSomethingElse', itemId: CELL_ID })}
      onEdit={() => onDescribe({ type: 'editSomethingElse', itemId: CELL_ID })} /> } : {}) }
  return (
    <QuestionCard label="CELL" sourceItemId={item.id} question={item.question} variant={questionCardVariant(CELL_ID)} answered={choice === SOMETHING_ELSE ? !!reply.somethingElse?.submitted : !!choice} disabled
      options={purposeOptions(item)} selected={answer.choice}
      followUpSequenceCount={stage === 'split' && split ? 2 : treatment ? 1 : 0}
      followUpSequence={<>
        {treatment && <QuestionSection label="CELL" question={treatment.question} context={treatment.context}
          options={stage === 'treatment' ? [...optionsOf(treatment.options), otherwise] : optionsOf(treatment.options)}
          {...(stage === 'treatment' ? outstanding : { disabled: true, selected: answer.followUps?.treatment })}
          sequenceStep={stage === 'split' ? {
            number: 1,
            state: 'answered',
            summary: treatment.options.find(option => option.id === answer.followUps?.treatment)?.label,
            continues: true,
            changeable: false,
          } : { number: 1, state: 'current' }} />}
        {stage === 'split' && split && <QuestionSection label="CELL" question={split.question} context={split.context} options={[...optionsOf(split.options), otherwise]} {...outstanding}
          sequenceStep={{ number: 2, state: 'current' }} />}
      </>} />
  )
}
