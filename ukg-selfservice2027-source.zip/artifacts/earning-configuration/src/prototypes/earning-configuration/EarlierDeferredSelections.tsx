import { selectedDeferral } from './explicitDeferral'
import { findItem } from './sampleRegister'
import { useEarningSession } from './sessionContext'
import { EarlierDiscussionAnswers } from './DiscussionQuestions'
import { callEvidence } from './cheatSheetAnswers'

/** Legacy source selections and responses stay read-only, including after a new owning proposal is applied. */
export default function EarlierDeferredSelections({ itemId }: { itemId?: string }) {
  const { session } = useEarningSession()
  const records = new Map<string, { id: string; answers: typeof session.answers[string]; selection: NonNullable<ReturnType<typeof selectedDeferral>> }>()
  for (const answers of [session.answers, ...session.discussionApplications?.map(receipt => receipt.originalAnswers) ?? []]) {
    for (const [id, answer] of Object.entries(answers)) {
      const selection = selectedDeferral(answer)
      if (selection && !selection.target && (!itemId || itemId === id))
        records.set(JSON.stringify([id, selection]), { id, answers: answer, selection })
    }
  }
  if (!records.size) return null
  return <details className="ec-cheat__why" data-testid="earlier-deferred-selections">
    <summary>Earlier deferred questions</summary>
    <p>These earlier selections and responses are kept as history. Review the owning question to confirm a new answer.</p>
    {[...records.values()].map(({ id, answers, selection }, index) => <section key={index}>
      <h3 className="text-caption">{findItem(id).code}</h3>
      {callEvidence(findItem(id), answers).answers.map((entry, i) => <p key={i}>{entry.question} {entry.answer}</p>)}
      <p>{selection.question}</p>
      {!!selection.choices.length && <ul>{selection.choices.map((label, i) => <li key={i}>{label}</li>)}</ul>}
      <EarlierDiscussionAnswers itemId={id} currentKeys={[]} />
      {session.callAnswers?.[id] && <p>Discussion notes: {session.callAnswers[id]}</p>}
    </section>)}
  </details>
}
