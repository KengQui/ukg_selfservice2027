import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { MemoryRouter } from 'react-router-dom'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { reduceChecked } from './scriptedChecks.testing'
import { routingReady } from './reviewRouting.testing'
import { EARNING_DEMO_SETTINGS } from './demoSettings'
import StepUpload from './StepUpload'
import { StepAnalysis } from './StepAnalysis'
import StepQuestions from './StepQuestions'
import { StepOptimization, StepOptimizationReview } from './StepOptimization'
import { StepOvertime, StepOvertimeSort } from './StepOvertime'
import StepOvertimeAssessment from './StepOvertimeAssessment'
import StepSummary from './StepSummary'
import { EarningSessionProvider, useEarningSession } from './SessionProvider'
import { ASK_CUSTOMER } from './sampleRegister'
import { SAMPLE_REGISTER_FILE, SAMPLE_REGISTER_FILES } from './sampleDocument'
import {
  createSession, currentRound, effectiveOvertime, firstUnansweredIndex, parseSession, reduceSession, reviewPosition, roundProgress,
  type EarningSession, type SessionAction,
} from './session'
import { overtimeMethod } from './overtime'
import { screeningSession } from './overtimeScreening.testing'
import { WORKING_COPY_KEY } from './storage'
import { applicableOptimizations } from './configuration'
import { optimizationPages } from './optimizationPages'

const run = (session: EarningSession, ...actions: SessionAction[]) =>
  actions.reduce((state, action) => reduceChecked(state, action, 1000), session)

/** A deterministic applied round; unrelated question/AI changes must not alter navigation coverage. */
const classified = routingReady

let host: HTMLDivElement
let root: Root

beforeEach(() => {
  HTMLElement.prototype.scrollIntoView = vi.fn()
  EARNING_DEMO_SETTINGS.ungateForwardButtons = true
  ;(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
  localStorage.clear()
  sessionStorage.clear()
  host = document.createElement('div')
  document.body.append(host)
  root = createRoot(host)
})

afterEach(() => {
  act(() => root.unmount())
  host.remove()
  vi.useRealTimers()
  localStorage.clear()
  sessionStorage.clear()
  EARNING_DEMO_SETTINGS.ungateForwardButtons = false
})

let current: EarningSession
function Flow() {
  const { session } = useEarningSession()
  current = session
  return <>
    {session.step === 'upload' && <StepUpload />}
    {(session.step === 'analysis' || session.step === 'results') && <StepAnalysis />}
    {session.step === 'questions' && <StepQuestions />}
    {session.step === 'optimization' && <StepOptimization />}
    {session.step === 'optimizationReview' && <StepOptimizationReview />}
    {session.step === 'overtime' && <StepOvertime />}
    {session.step === 'overtimeAssessment' && <StepOvertimeAssessment />}
    {session.step === 'overtimeSort' && <StepOvertimeSort />}
    {session.step === 'summary' && <StepSummary />}
  </>
}

function mount(session: EarningSession) {
  sessionStorage.setItem(WORKING_COPY_KEY, JSON.stringify(session))
  act(() => root.render(<MemoryRouter><EarningSessionProvider><Flow /></EarningSessionProvider></MemoryRouter>))
}

function button(label: string) {
  const result = [...host.querySelectorAll<HTMLButtonElement>('button')].find(candidate => candidate.textContent?.trim() === label)
  expect(result, `Missing button ${label}`).toBeDefined()
  return result!
}

const click = (label: string) => {
  const target = button(label)
  expect(target.disabled, `${label} should be clickable`).toBe(false)
  act(() => target.click())
}

const heading = () => host.querySelector('h1')?.textContent

describe('payroll upload guidance', () => {
  it('shows the approved optional report guidance above the unchanged upload control', () => {
    mount({ ...createSession(100), step: 'upload' })
    expect(heading()).toBe('Help us identify your payroll codes')
    const paragraphs = [...host.querySelectorAll('p.ec-intro')].map(p => p.textContent?.trim())
    expect(paragraphs).toEqual([
      "Upload reports from your current payroll system. We'll use them to identify how your company pays employees, what deductions are taken, and which payroll taxes are used.",
      "You can upload Excel, CSV, or PDF files. If you don't have all these reports, upload what you have. You can add more later or review missing information with your implementation team.",
    ])
    const guidance = host.querySelector('.ec-upload-guidance')!
    expect(guidance.querySelector('p strong')?.textContent).toBe('Start with these reports:')
    expect([...guidance.querySelectorAll('li')].map(li => li.textContent)).toEqual([
      'Earnings code list — Include regular pay, overtime, bonuses, commissions, one-time payments, and other occasional earnings.',
      'Deduction code list — Include recurring and one-time deductions.',
      'Tax code or tax setup report — Include federal, state, and local payroll taxes.',
      'Payroll register or payroll summary — Include current and prior-year payroll information, if available, to help identify codes used infrequently.',
    ])
    expect([...guidance.querySelectorAll('li strong')].map(label => label.textContent)).toEqual([
      'Earnings code list', 'Deduction code list', 'Tax code or tax setup report', 'Payroll register or payroll summary',
    ])
    const input = host.querySelector<HTMLInputElement>('input[type="file"]')!
    expect(input.accept).toBe('.pdf,.csv,.xlsx,application/pdf,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    expect(input.multiple).toBe(true)
    expect(guidance.compareDocumentPosition(input) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy()
    expect(host.textContent).toContain('Choose up to 5 PDF, CSV or Excel (XLSX) files, up to 10 MB each. PDFs can have up to 20 pages.')
    expect(host.textContent).not.toContain('Upload pay registers')
    expect(host.textContent).not.toContain('Add your documents to start the review')
    expect(button('Next').disabled).toBe(true)
    click('Back')
    expect(current.step).toBe('categorySelection')
  })

  it('allows Next with one report rather than requiring all four report types', () => {
    mount({ ...createSession(100), step: 'upload', files: [SAMPLE_REGISTER_FILES[0]] })
    click('Next')
    expect(current.step).toBe('analysis')
    expect(current.files).toEqual([SAMPLE_REGISTER_FILES[0]])
  })
})

describe('demo setting: forward buttons skip their gating', () => {
  it('moves from sample analysis to unanswered review without waiting for analysis to finish', () => {
    vi.useFakeTimers()
    mount({ ...createSession(100), files: [...SAMPLE_REGISTER_FILES], step: 'analysis' })
    expect(current.step).toBe('analysis')
    expect(current.files.map(file => file.id)).toEqual(SAMPLE_REGISTER_FILES.map(file => file.id))
    // The analysis continue button works before the steps finish.
    click('Start review')
    expect(current.step).toBe('questions')
    expect(current.preparationComplete).toBe(true)
    expect(current.rounds).toHaveLength(1)
    expect(current.answers).toEqual({})
    click('Back')
    expect(current.step).toBe('results')
    expect(host.textContent).toContain('Your review is ready')
  })

  it('pages through the review with unanswered codes, keeping Apply answers gated and the counts honest', () => {
    mount(reduceSession({ ...createSession(100), files: [...SAMPLE_REGISTER_FILES] }, { type: 'startReview' }))
    const { total } = reviewPosition(current)
    for (let page = 1; page < total; page++) {
      click('Next')
      expect(reviewPosition(current).index).toBe(page)
      expect(heading()).toBeTruthy()
    }
    expect(heading()).toBeTruthy()
    expect(button('Apply answers').disabled).toBe(true)
    expect(roundProgress(current).answered).toBe(0)
    expect(firstUnansweredIndex(current)).toBe(0)
    expect(Object.keys(current.answers)).toEqual([])
    const before = current
    click('Continue to optimization')
    expect(heading()).toBe('Optimize codes')
    expect(current.answers).toEqual(before.answers)
    expect(current.rounds).toEqual(before.rounds)
    expect(current.resolutions).toEqual({})
    click('Next')
    expect(heading()).toBe('How does your team earn overtime?')
    expect(current.optimization.completed).toBe(false)
    click('Back')
    expect(heading()).toBe('Optimize codes')
    click('Back')
    expect(current.step).toBe('questions')
    expect(reviewPosition(current).index).toBe(total - 1)
    expect(button('Apply answers').disabled).toBe(true)
  })

  it('continues directly from optimization to overtime with nothing answered in the demo', () => {
    const start = classified()
    expect(start.step).toBe('optimization')
    mount(start)
    expect(host.querySelector('.ec-submit-bar')?.textContent?.replace(/\s/g, '')).toBe('BackNext')
    const suggestions = applicableOptimizations(current)
    const pages = optimizationPages(suggestions, !suggestions.some(item => item.id === 'combine-current-overtime'))
    for (const _page of pages) click('Next')
    expect(current.step).toBe('overtime')
    expect(current.optimization.answers).toEqual({})
    expect(current.optimization.completed).toBe(false)
    expect(current.optimization.submitted).toBe(false)
    expect(overtimeMethod(effectiveOvertime(current)).kind).toBe('open')
    click('Continue to summary')
    expect(current.step).toBe('summary')
    expect(heading()).toBeTruthy()
    expect(host.textContent).toContain('Not decided')
    // A reload keeps the skipped-ahead session instead of discarding it.
    expect(parseSession(JSON.stringify(current))?.step).toBe('summary')
    expect(current.optimization.answers).toEqual({})
    expect(current.overtime.answers).toEqual({})
  })

  it('confirms the overtime sorting with a mixed code still undecided', () => {
    const sorting = run(classified(),
      { type: 'chooseOptimization', suggestionId: 'split-bonus', choice: 'keep' },
      { type: 'submitOptimization' }, { type: 'completeOptimization' }, { type: 'startOvertime' },
      { type: 'answerOvertime', questionId: 'multiRate', answer: 'yes' }, { type: 'reviewOvertimeSort' })
    expect(sorting.step).toBe('overtimeSort')
    mount(sorting)
    click('Confirm and continue')
    expect(current.step).toBe('summary')
    expect(heading()).toBeTruthy()
    expect(parseSession(JSON.stringify(current))?.step).toBe('summary')
  })

  it('does not bypass the separate assessment after an explicit Yes even with demo navigation enabled', () => {
    mount(screeningSession())
    act(() => (host.querySelector('[role="radio"]') as HTMLElement).click())
    expect(current.step).toBe('overtimeAssessment')
    expect(heading()).toBe('Your overtime setup may need additional configuration')
    expect(button('Next').disabled).toBe(false)
    expect(parseSession(JSON.stringify(current))?.step).toBe('overtimeAssessment')
    click('Back')
    expect(current.step).toBe('overtime')
    click('Next')
    expect(current.step).toBe('overtimeAssessment')
    click('Next')
    expect(current.step).toBe('overtimeSort')
    expect(heading()).toBe('Identify applicable earning codes')
  })

  it('brings back the normal gating when the demo setting is off', () => {
    EARNING_DEMO_SETTINGS.ungateForwardButtons = false
    mount({ ...createSession(100), step: 'upload' })
    expect(button('Next').disabled).toBe(true)
    const review = reduceSession({ ...createSession(100), files: [SAMPLE_REGISTER_FILE] }, { type: 'startReview' })
    expect(reduceSession(review, { type: 'moveReview', index: 1 })).toBe(review)
    const optimization = classified()
    expect(reduceSession(optimization, { type: 'submitOptimization' })).toBe(optimization)
    expect(currentRound(review)?.submitted).toBe(false)
  })
})
