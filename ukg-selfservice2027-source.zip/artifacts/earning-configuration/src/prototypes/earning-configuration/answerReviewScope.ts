import { DESCRIBE_CHOICE, typedNoteOption, type ReviewItem } from './sampleRegister'
import { activeCheck, isAiChecked, isOtherPurpose, sharedSetupFor, somethingElseQuestion, type ItemAnswer } from './session'
import { SOMETHING_ELSE, somethingElseNote } from './somethingElse'

/**
 * The text the person typed for the answer to one card section (keyed by its fixed question), or undefined when that
 * section's answer is a fixed option pick. Only typed answers get a live AI review: a fixed pick's outcome is already set
 * by the app, so a review could only repeat it back. The dedicated description check owns description-led naming;
 * those opening descriptions get no separate review. Other typed answers are Something else descriptions,
 * MED's No description, an optional note under a pick such as DEN's No, the in-use question's Something else ("How is
 * this pay different?") and the shared Something else on any other question. Each counts only once Done locks it, so
 * nothing is reviewed while it's being typed.
 */
export function typedAnswerFor(item: ReviewItem, answer: ItemAnswer, question: string, selected: string | undefined): string | undefined {
  if (selected === SOMETHING_ELSE) {
    const note = somethingElseNote(answer.somethingElse)
    return note && somethingElseQuestion(item, answer) === question ? note : undefined
  }
  if (question === item.question) {
    // Apply by process, not source code: also covers customer replies and future description-led items.
    if (isAiChecked(item)) return undefined
    if (item.type === 'clarification' && item.describe && selected === DESCRIBE_CHOICE && answer.choice === DESCRIBE_CHOICE) {
      return answer.descriptionSubmitted ? answer.description?.trim() || undefined : undefined
    }
    // An optional note under a pick (DEN's No) once Done locks it. The pick alone stays unreviewed.
    if (selected === answer.choice && typedNoteOption(item, selected)) {
      return answer.descriptionSubmitted ? answer.description?.trim() || undefined : undefined
    }
    return undefined
  }
  const shared = sharedSetupFor(item, answer)
  if (shared && question === shared.question && selected === 'other' && answer.sharedSetup?.referenceId === shared.reference.id
    && answer.sharedSetup.choice === 'other') {
    return answer.sharedSetup.descriptionSubmitted ? answer.sharedSetup.description?.trim() || undefined : undefined
  }
  return undefined
}

/** The section's selected answer, as the card passes it to the review: Something else stands for its description. */
function selectedFor(item: ReviewItem, answer: ItemAnswer, question: string): string | undefined {
  if (answer.somethingElse && somethingElseQuestion(item, answer) === question) return SOMETHING_ELSE
  if (question === item.question) return item.type === 'unidentified' && isOtherPurpose(answer) ? DESCRIBE_CHOICE : answer.choice
  const shared = sharedSetupFor(item, answer)
  return shared && answer.sharedSetup?.referenceId === shared.reference.id ? answer.sharedSetup.choice : undefined
}

/**
 * Whether a stored review (keyed by its fixed question) is one the card shows now. Reviews saved for fixed picks before
 * reviews were limited to typed answers still load, but they're never shown, so nothing else may describe them either.
 * The description check owns its unused-code suggestion, so an opening review is hidden while that suggestion stands.
 */
export function reviewShown(item: ReviewItem, answer: ItemAnswer, question: string): boolean {
  if (item.code === 'CELL' && !answer.cellLegacy) return false
  if (typedAnswerFor(item, answer, question, selectedFor(item, answer, question)) === undefined) return false
  return !(question === item.question && activeCheck(item, answer)?.kind === 'notNeeded')
}
