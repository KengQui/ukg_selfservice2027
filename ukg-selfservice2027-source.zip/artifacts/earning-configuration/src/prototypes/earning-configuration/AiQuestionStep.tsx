import { useState, type ReactNode } from 'react'
import { useDiscussionWorkDraft } from './discussionWorkDraft'
import { DescribeBoxView } from './DescribeAnswerBox'
import { QuestionSection, type QuestionOption } from './QuestionCard'
import { SOMETHING_ELSE, SOMETHING_ELSE_LABEL } from './somethingElse'
import type { AnswerFormat } from './session'

/**
 * One AI-written question as a numbered step of the card's follow-up sequence (the description check's question, or a
 * Shift differential follow-up). The AI picks the format: listed choices, to which the app adds Something else, or a
 * text box. A listed pick answers at once; typed text answers only on Done, so nothing is reviewed while it's typed.
 * An answered step collapses to its answer pill, and Change reopens it.
 */
export function AiQuestionStep({ question, format, context, number, continues, answered, initialDraft = '', initialChoice, onDraftChange, onAnswer, onChange, defer, deferSelected, onDeferSelect }: {
  question: string; format: AnswerFormat; context?: ReactNode; number: number; continues?: boolean
  /** The saved answer; the step shows it as a pill. */
  answered?: string
  /** Text to start the box with, such as an earlier typed answer reopened by Change. */
  initialDraft?: string
  initialChoice?: string
  onDraftChange?: (text: string, choice?: string) => void
  onAnswer?: (answer: string) => void
  onChange?: () => void
  defer?: boolean; deferSelected?: string; onDeferSelect?: (choice: string) => void
}) {
  const [picked, setPicked] = useDiscussionWorkDraft(question, 'choice', initialChoice ?? (format.kind === 'choices' && initialDraft ? SOMETHING_ELSE : ''))
  const [draft, setDraft] = useDiscussionWorkDraft(question, 'text', initialDraft)
  const deferProps = { defer, deferSelected, onDeferSelect }
  if (answered !== undefined) {
    return <QuestionSection question={question} selected={answered} {...deferProps} defer={false}
      sequenceStep={{ number, state: 'answered', summary: answered, continues, changeable: !!onChange, onChange }} />
  }
  const typed = (label: string) => <DescribeBoxView label={label} noun="description" description={draft} submitted={false}
    onChange={value => { setDraft(value); onDraftChange?.(value, picked) }} onDone={() => onAnswer?.(draft.replace(/\s+/g, ' ').trim())} onEdit={() => undefined} />
  if (format.kind === 'text') {
    return <QuestionSection question={question} context={context} answer={typed('Your answer')} {...deferProps}
      sequenceStep={{ number, state: 'current', continues }} />
  }
  const options: QuestionOption[] = [
    ...format.options.map((label, index) => ({ id: `option-${index}`, title: label })),
    { id: SOMETHING_ELSE, title: SOMETHING_ELSE_LABEL, discussionDetails: true, content: typed('Description') },
  ]
  return <QuestionSection question={question} context={context} options={options} selected={picked} {...deferProps}
    onSelect={choice => {
      const label = format.options[Number(choice.replace('option-', ''))]
      if (choice === SOMETHING_ELSE) { setPicked(choice); onDraftChange?.(draft, choice) }
      else if (choice.startsWith('option-') && label) onAnswer?.(label)
    }}
    sequenceStep={{ number, state: 'current', continues }} />
}
