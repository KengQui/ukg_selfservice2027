import { useEffect, useId, useRef } from 'react'
import TextArea from '@ready/dls/components/TextArea/TextArea'
import Link from '@ready/dls/components/Link/Link'
import { Button, InlineMessage, Tag } from '@ready/dls/compatibility'
import { AILogo } from '@ready/dls/ai'
import { useEarningSession } from './sessionContext'
import {
  ADDED_DESCRIPTION_MAX, ADDED_PLAN_QUESTION, ADDED_REPLY_MAX, ADDED_STATUS, addedCodeStatus, addedDraftError, REFERRAL_BONUS_SETUP,
  type AddedCode, type AddedCodeDraft, type AddedCodesEvent,
} from './addedCodes'
import { runAddedCheck } from './addedCodeCheck'
import QuestionCard, { FollowUpSequence, QuestionSection } from './QuestionCard'
import './addedCodes.css'
import DeferCheckbox from './DeferCheckbox'
import { ASK_CUSTOMER } from './sampleRegister'

const STATUS_COLOR = { plan: 'success', deferred: 'neutral', noMatch: 'warning', pending: 'warning' } as const
const INTENTION_QUESTION = 'What will this code pay for?'
const INTENTION_GUIDANCE = 'Describe what the payment is for, who receives it and when it is paid. For example: a yearly bonus paid each December to people with a full year of service.'

/** One form for adding or editing a code. Every keystroke is saved with the session, so a draft survives reload. */
function AddedCodeForm({ draft, send }: { draft: AddedCodeDraft; send: (event: AddedCodesEvent) => void }) {
  const id = useId()
  const error = addedDraftError(draft)
  const tooLong = error && /within/.test(error) ? error : undefined
  return (
    <div className="ec-added__form" role="group" aria-label={draft.editing ? 'Edit earning code' : 'Add an earning code'} data-testid="form-added-code">
      <QuestionCard label="" layout="question-first" question={INTENTION_QUESTION} context={INTENTION_GUIDANCE}
        answered={false} advancedOptions={false} answer={<div className="ec-describe">
      <TextArea id={`${id}-description`} aria-label={INTENTION_QUESTION} rows={4} value={draft.description} data-testid="input-added-description"
        onChange={value => send({ kind: 'change', field: 'description', value })} />
      {draft.description.length > ADDED_DESCRIPTION_MAX && <p className="text-caption" role="status">Keep the description within {ADDED_DESCRIPTION_MAX} characters.</p>}
      <div className="ec-describe__actions">
        <Button variant="secondary" size="small" disabled={!!error} onClick={() => send({ kind: 'save' })} data-testid="button-save-added-code">
          {draft.editing ? 'Save changes' : 'Add'}
        </Button>
      </div>
      {tooLong && <span className="ec-visually-hidden" role="status">{tooLong}</span>}
      </div>} />
    </div>
  )
}

function Facts({ facts }: { facts: string[] }) {
  return facts.length ? <ul className="ec-added__facts">{facts.map((fact, index) => <li key={index}>{fact}</li>)}</ul> : null
}

/** The live check for one code: in progress, failed, a follow-up, a proposed match or no match, then the decision. */
function AddedCodeCheckPanel({ entry, send, locked }: { entry: AddedCode; send: (event: AddedCodesEvent) => void; locked: boolean }) {
  const replyId = useId()
  const check = entry.check
  const thread = entry.thread ?? []
  const referral = check?.status === 'result' && check.result.outcome === 'match'
    && check.result.reference?.id === REFERRAL_BONUS_SETUP.referenceId
  // The approved referral result goes straight into the setup plan, not live payroll.
  useEffect(() => {
    if (referral && !entry.plan && !entry.deferred && !locked) send({ kind: 'confirm', id: entry.id, at: Date.now() })
  }, [referral, entry.id, entry.plan, entry.deferred, locked, send])
  return (
    <div className="ec-added__check" data-testid={`panel-added-check-${entry.id}`}>
      {(thread.length > 0 || check?.status === 'result' && check.result.outcome === 'question') && (
        <FollowUpSequence>
          {thread.map((turn, index) => (
            <QuestionSection key={index} question={turn.question} selected={turn.answer}
              sequenceStep={{ number: index + 1, state: 'answered', summary: turn.answer, changeable: false,
                continues: index < thread.length - 1 || check?.status === 'checking' || check?.status === 'result' && check.result.outcome === 'question' }} />
          ))}
          {check?.status === 'result' && check.result.outcome === 'question' && (
            <QuestionSection question={check.result.question ?? ''}
              sequenceStep={{ number: thread.length + 1, state: 'current' }}
              answer={<div className="ec-describe" data-testid={`text-added-question-${entry.id}`}>
                <TextArea id={replyId} label="Your answer" rows={3} readOnly={locked || !!entry.deferred} value={entry.replyDraft ?? ''} data-testid={`input-added-reply-${entry.id}`}
                  onChange={value => send({ kind: 'replyChange', id: entry.id, value })}
                  warningText={(entry.replyDraft?.length ?? 0) > ADDED_REPLY_MAX ? `Keep your reply within ${ADDED_REPLY_MAX} characters.` : undefined} />
                <div className="ec-describe__actions">
                  <Button variant="secondary" size="small" disabled={locked || !!entry.deferred || !entry.replyDraft?.trim() || entry.replyDraft.length > ADDED_REPLY_MAX}
                    onClick={() => send({ kind: 'reply', id: entry.id })} data-testid={`button-send-added-reply-${entry.id}`}>Done</Button>
                </div>
              </div>} />
          )}
        </FollowUpSequence>
      )}
      <div aria-live="polite">
        {check?.status === 'checking' && (
          <div className="ec-added__checking" role="status" data-testid={`status-added-checking-${entry.id}`}>
            <span className="ec-added__shimmer" aria-hidden="true" />
            <span className="text-caption">Reviewing your answer…</span>
          </div>
        )}
        {check?.status === 'error' && (
          <div className="ec-added__result">
            <InlineMessage theme="error">{check.message}</InlineMessage>
            <div><Button variant="secondary" size="small" onClick={() => send({ kind: 'check', id: entry.id })} data-testid={`button-retry-added-${entry.id}`}>Try again</Button></div>
          </div>
        )}
        {!check && (
          <div className="ec-added__result">
            <Button variant="secondary" size="small" disabled={locked} onClick={() => send({ kind: 'check', id: entry.id })} data-testid={`button-check-added-${entry.id}`}>Review this code</Button>
          </div>
        )}
        {check?.status === 'result' && check.result.outcome === 'noMatch' && (
          <div className="ec-added__result" data-testid={`text-added-nomatch-${entry.id}`}>
            <p className="ec-added__lead">Your setup team needs to review this code.</p>
            <p className="text-body">{check.result.summary}</p>
            <Facts facts={check.result.facts} />
            <p className="text-caption">We’ll keep what you told us so your setup team can review this code.</p>
          </div>
        )}
        {check?.status === 'result' && check.result.outcome === 'match' && check.result.reference && (
          referral ? (
            <div className="ec-added__result ec-added__match ec-added__match--done" data-testid={`text-added-referral-${entry.id}`}>
              <p className="ec-added__lead">{REFERRAL_BONUS_SETUP.code} — {REFERRAL_BONUS_SETUP.name}</p>
              <p className="text-body">{entry.deferred ? 'You chose to review this code later. It isn’t in your setup plan.' : REFERRAL_BONUS_SETUP.description}</p>
            </div>
          ) : entry.plan ? (
            <div className="ec-added__result ec-added__match ec-added__match--done" data-testid={`text-added-plan-${entry.id}`}>
              <p className="ec-added__lead">Added to your setup plan as {entry.plan.referenceName}</p>
              <p className="text-body">{entry.plan.summary}</p>
              <p className="text-caption">This updates your setup plan only. Payroll doesn’t change until setup.</p>
            </div>
          ) : (
            <div className="ec-added__result ec-added__match" data-testid={`card-added-match-${entry.id}`}>
              <p className="ec-added__eyebrow text-caption"><AILogo variant="secondary" size={14} /> Proposed match</p>
              <p className="ec-added__lead">
                {check.result.reference.name}
              </p>
              <p className="text-body">{check.result.summary}</p>
              <Facts facts={check.result.facts} />
              <p className="ec-added__question">{ADDED_PLAN_QUESTION}</p>
              {entry.deferred && <p className="text-caption">You chose to review this later. You can still add it now.</p>}
              <div className="ec-added__decision">
                <Button variant="primary" size="small" disabled={locked} onClick={() => send({ kind: 'confirm', id: entry.id, at: Date.now() })} data-testid={`button-confirm-added-${entry.id}`}>Yes, add to my setup plan</Button>
              </div>
            </div>
          )
        )}
      </div>
      {check?.status === 'result' && (check.result.outcome === 'match' || check.result.outcome === 'question') && (
        <div className="ec-qcard__footer-actions">
          {check.result.outcome === 'match' && <Button variant="secondary" size="small" disabled={locked}
            onClick={() => send({ kind: 'requestChange', id: entry.id })}
            data-testid={`button-change-added-${entry.id}`}>Make a change</Button>}
          <span id={`${replyId}-review-context`} className="ec-visually-hidden">Review this earning code later</span>
          <DeferCheckbox checked={!!entry.deferred} disabled={locked} labelledBy={`${replyId}-review-context`}
            recordSelection={false} id={`checkbox-defer-added-${entry.id}`}
            onChange={choice => send({ kind: choice === ASK_CUSTOMER ? 'defer' : 'resume', id: entry.id })} />
        </div>
      )}
      {entry.history && entry.history.length > 0 && (
        <p className="text-caption ec-added__history" data-testid={`text-added-history-${entry.id}`}>
          Earlier setup plan: {entry.history.map(item => item.referenceName).join(', ')}
        </p>
      )}
    </div>
  )
}

/**
 * The last page of the initial review: codes the payroll register doesn't show. Each intention is checked live against
 * the reference library; only an explicit Yes puts it in the setup plan. Nothing here touches register evidence.
 */
export default function AddedCodesSection() {
  const { session, dispatch } = useEarningSession()
  // Empty saved sessions and removal of the last code also start with the question.
  useEffect(() => {
    if (!session.addedCodes?.entries.length && !session.addedCodes?.draft) {
      dispatch({ type: 'addedCodes', event: { kind: 'start' } })
    }
  }, [session.addedCodes, dispatch])
  const state = session.addedCodes ?? { entries: [] }
  const visibleDraft = state.draft ?? (state.entries.length === 0 ? { code: '', name: '', description: '' } : undefined)
  const send = (event: AddedCodesEvent) => dispatch({ type: 'addedCodes', event })
  const sendRef = useRef(send)
  sendRef.current = send
  const checkingKey = state.entries.map(entry => entry.check?.status === 'checking' ? entry.check.token : '').join('|')
  const entriesRef = useRef(state.entries)
  entriesRef.current = state.entries
  useEffect(() => {
    for (const entry of entriesRef.current) runAddedCheck(entry, event => sendRef.current(event))
  }, [checkingKey])
  const editing = state.draft?.editing
  return (
    <section className="ec-added" aria-label="Additional earning codes" data-testid="section-added-codes">
      {state.entries.length > 0 ? (
          <ul className="ec-added__list">
            {state.entries.map(entry => {
              const status = addedCodeStatus(entry)
              return (
                <li key={entry.id} className="ec-added__row" data-testid={`row-added-code-${entry.id}`}>
                  {editing === entry.id && state.draft ? <AddedCodeForm draft={state.draft} send={send} /> : <>
                    <QuestionCard label="" layout="question-first" question={INTENTION_QUESTION} context={INTENTION_GUIDANCE}
                      answered advancedOptions={false} answer={
                    <div className="ec-added__text">
                      {(entry.code || entry.name) && <p className="ec-added__name">
                        {entry.code && <span className="ec-code">{entry.code}</span>} {entry.name}
                      </p>}
                      <div className="ec-added__saved-answer">
                        <TextArea aria-label={INTENTION_QUESTION} rows={3}
                          value={entry.description} readOnly onChange={() => {}}
                          data-testid={`input-added-saved-description-${entry.id}`} />
                      </div>
                      {status !== 'plan' && status !== 'pending' && <Tag type="status" color={STATUS_COLOR[status]} label={ADDED_STATUS[status]} data-testid={`status-added-${entry.id}`} />}
                    </div>}
                    followUps={<AddedCodeCheckPanel entry={entry} send={send} locked={!!state.draft && !!editing} />}
                    footerAction={
                    <div className="ec-added__actions">
                      <Link size="sm" disabled={!!state.draft} onClick={() => send({ kind: 'edit', id: entry.id })} data-testid={`button-edit-added-${entry.id}`}>Edit</Link>
                      <Link size="sm" onClick={() => send({ kind: 'remove', id: entry.id })} data-testid={`button-remove-added-${entry.id}`}>Remove</Link>
                    </div>} />
                  </>}
                </li>
              )
            })}
          </ul>
      ) : null}
      {visibleDraft && !editing && <AddedCodeForm draft={visibleDraft} send={send} />}
      {!visibleDraft && (
        <div className="ec-added__add">
          <Button variant="secondary" size="small" onClick={() => send({ kind: 'start' })} data-testid="button-add-code">
            {state.entries.length ? 'Add another code' : 'Add a code'}
          </Button>
        </div>
      )}
    </section>
  )
}
