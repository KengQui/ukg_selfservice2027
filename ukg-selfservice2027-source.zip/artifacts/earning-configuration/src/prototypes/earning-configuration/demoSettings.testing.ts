/**
 * Vitest setup: the suite checks the normal forward-button gating, so it runs with the demo setting off.
 * Specs that cover the demo behavior turn it on themselves.
 */
import { EARNING_DEMO_SETTINGS } from './demoSettings'

EARNING_DEMO_SETTINGS.ungateForwardButtons = false
EARNING_DEMO_SETTINGS.hideOptionalQuestions = false
