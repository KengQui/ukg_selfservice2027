import { act, useReducer } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { draftEarningCustomerQuestions, type EarningCustomerQuestionDraft } from '@workspace/api-client-react'
import { createSession, parseSession, reduceSession, reviewPages, type EarningSession, type SessionAction } from './session'
import { ASK_CUSTOMER, READY, findItem } from './sampleRegister'
import { callEvidence } from './cheatSheetAnswers'
import { deferralBasis } from './explicitDeferral'
import { customerDraftBasis } from './customerQuestionData'
import { allowedDiscussionKinds, discussionBasis, discussionKey, standardDiscussionKind } from './discussionAnswers'
import { pendingDiscussionQuestions } from './reviewDiscussionChoices'
import { cellCustomerQuestion, cellFollowUpQuestions } from './cell'
import { SOMETHING_ELSE, SOMETHING_ELSE_LABEL } from './somethingElse'
import { SessionContext } from './sessionContext'
import { loadSession, saveSession, writeWorkingCopy, type SessionStores } from './storage'
import StepReview from './StepReview'
import { routingDeferred } from './reviewRouting.testing'

vi.mock('@workspace/api-client-react', () => ({ draftEarningCustomerQuestions: vi.fn(),
  summarizeEarningDiscussion: () => new Promise(() => {}) }))
const reason = 'Your answer helps confirm how your company uses this payment.'
const taxDraft: EarningCustomerQuestionDraft = {
  questions: ['What tax treatment has been confirmed for the phone payback?'], answerKinds: ['phone-tax'], reason,
}
function stateFor(ids: string[] = ['CELL-purpose']): EarningSession {
  // Explicit historical selections without invented application targets.
  const state: EarningSession = { ...createSession(1), step: 'review',
    answers: Object.fromEntries(ids.map(id => [id, { choice: ASK_CUSTOMER, ...(id === 'CELL-purpose' ? { cellLegacy: true } : {}) }])),
    rounds: [{ number: 1, itemIds: ids, submitted: true, results: { resolved: [], deferred: ids, findings: [] } }],
    resolutions: Object.fromEntries(ids.map(id => [id, { status: 'customer' as const, round: 1 }])),
    customerQuestions: ids.map(itemId => ({ itemId, code: findItem(itemId).code, type: findItem(itemId).type,
      question: findItem(itemId).customerQuestion, round: 1 })),
  }
  for (const id of ids) selectHistoricalQuestion(state, id)
  return state
}
function selectHistoricalQuestion(state: EarningSession, id: string) {
  const source = callEvidence(findItem(id), state.answers[id]).questions.find(question => question.deferred)!
  state.answers[id].explicitDeferral = { question: source.question, choices: source.choices, basis: deferralBasis(state.answers[id]) }
}
const draft = (state: EarningSession, id: string, value: EarningCustomerQuestionDraft): EarningSession => ({
  ...state, customerQuestions: state.customerQuestions.map(question => question.itemId === id ? {
    ...question, draft: { ...value, basis: customerDraftBasis(state.answers[id]) },
  } : question),
})
function taxState() {
  const state = stateFor()
  state.answers['CELL-purpose'] = { cellLegacy: true, choice: 'reimbursement', followUps: { treatment: ASK_CUSTOMER } }
  selectHistoricalQuestion(state, 'CELL-purpose')
  const original = cellFollowUpQuestions(state.answers['CELL-purpose'])[0]
  state.answers['CELL-purpose'].explicitDeferral!.options = [
    ...original.options.map(option => ({ id: option.id, label: [option.label, option.detail].filter(Boolean).join(' — ') })),
    { id: SOMETHING_ELSE, label: SOMETHING_ELSE_LABEL, details: true },
  ]
  state.answers['CELL-purpose'].explicitDeferral!.choices = state.answers['CELL-purpose'].explicitDeferral!.options!.map(option => option.label)
  state.callAnswers = { 'CELL-purpose': 'Keep this earlier discussion note.' }
  return draft(state, 'CELL-purpose', taxDraft)
}
let root: Root | undefined
let host: HTMLDivElement
let latest: EarningSession
function mount(state: EarningSession) {
  vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT', true)
  host = document.createElement('div'); document.body.append(host); root = createRoot(host)
  function Harness() {
    const [session, dispatch] = useReducer((state: EarningSession, action: SessionAction) => reduceSession(state, action), state)
    latest = session
    return <SessionContext.Provider value={{ session, dispatch, save: () => true, restart: () => true }}><StepReview /></SessionContext.Provider>
  }
  act(() => root!.render(<Harness />))
}
const click = (testId: string) => act(() => {
  const element = host.querySelector<HTMLElement>(`[data-testid="${testId}"]`)!
  ;(element.querySelector<HTMLElement>('label') ?? element).click()
})
const type = (selector: string, text: string) => act(() => {
  const field = host.querySelector<HTMLTextAreaElement>(selector)!
  Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')!.set!.call(field, text)
  field.dispatchEvent(new Event('input', { bubbles: true }))
})
const settle = async () => { await act(async () => { await Promise.resolve(); await Promise.resolve() }) }
const answerFor = (id: string, question: string) => Object.values(latest.discussionAnswers?.[id] ?? {}).find(answer => answer.question === question)
const sourceQuestion = () => pendingDiscussionQuestions(latest, 'CELL-purpose')[0]
const chooseSource = (optionId: string) => click(`choice-discussion-CELL-purpose-0-${optionId}`)
afterEach(() => { if (root) act(() => root!.unmount()); root = undefined; host?.remove(); vi.resetAllMocks() })

describe('summary discussion choices', () => {
  it('applies the scoped DLS hierarchy to every card in the review section', () => {
    mount(routingDeferred())
    const section = host.querySelector('[data-testid="group-cheat-ask"]')!
    const cards = [...section.querySelectorAll('.ec-cheat__card')]
    expect(cards.length).toBeGreaterThan(0)
    for (const card of cards) {
      expect(card.classList.contains('ec-deferred-card')).toBe(true)
      expect(card.querySelector('.ec-cheat__head')).not.toBeNull()
      expect(card.querySelector('.ec-cheat__questions')).not.toBeNull()
    }
    expect(host.querySelectorAll('.ec-deferred-card')).toHaveLength(cards.length)
  })

  it('keeps optional discussion notes visible on return, separate from the response', () => {
    const state = stateFor(['OTPREM'])
    state.callAnswers = { OTPREM: 'Keep the saved discussion note.' }
    const question = state.customerQuestions.find(question => question.itemId === 'OTPREM')!.question
    const kind = allowedDiscussionKinds(state, 'OTPREM')[0] ?? 'text'
    mount(draft(state, 'OTPREM', { questions: [question], answerKinds: [kind], reason }))
    const row = host.querySelector('[data-testid="row-cheat-OTPREM"]')!
    expect(row.textContent).toContain(pendingDiscussionQuestions(state, 'OTPREM')[0].question)
    expect(row.textContent).toContain('Discussion notes')
    expect(row.querySelector<HTMLTextAreaElement>('textarea[id^="call-answer-"]')?.value).toBe('Keep the saved discussion note.')
    expect(row.querySelector('.ec-discussion__response input, .ec-discussion__response textarea')).not.toBeNull()
    expect(latest.callAnswers).toEqual(state.callAnswers)
    expect(parseSession(JSON.stringify(latest))?.callAnswers).toEqual(state.callAnswers)
  })

  it('keeps phone method and confirmed tax treatment distinct, with no guesses or preselection', () => {
    const state = taxState()
    expect(allowedDiscussionKinds(state, 'CELL-purpose')).toEqual(['phone-tax'])
    expect(standardDiscussionKind(state, 'CELL-purpose', cellCustomerQuestion('treatment', state.answers['CELL-purpose']))).toBe('phone-tax')
    expect(standardDiscussionKind(state, 'CELL-purpose', 'Who approves these phone bills?')).toBe('text')
    mount(state)
    expect(host.querySelectorAll('input:checked')).toHaveLength(0)
    expect(host.querySelectorAll('input[type="radio"]')).toHaveLength(3)
    for (const option of sourceQuestion().options) expect(host.textContent).toContain(option.label)
    expect(host.textContent).not.toContain('We pay a set amount, regardless of phone costs')
    chooseSource('taxable')
    expect(answerFor('CELL-purpose', sourceQuestion().question)?.choice).toBe('taxable')
    expect(latest.answers).toEqual(state.answers)
    expect(latest.resolutions).toEqual(state.resolutions)
    expect(latest.customerQuestions).toEqual(state.customerQuestions)
    expect(latest.customerReplies).toEqual(state.customerReplies)
    expect(latest.callAnswers).toEqual(state.callAnswers)
    expect(draftEarningCustomerQuestions).not.toHaveBeenCalled()
  })
  it('opens and preserves Something else details, and clears only that question', () => {
    mount(taxState())
    const question = sourceQuestion()
    const other = question.options.find(option => option.details)!.id
    const selected = question.options.find(option => !option.details && option.id !== 'unsure')!.id
    chooseSource(other)
    type('[data-testid="discussion-answer-CELL-purpose-0"] textarea', 'The adviser is checking two groups.')
    chooseSource(selected)
    expect(host.querySelector('[data-testid="discussion-answer-CELL-purpose-0"] textarea')).toBeNull()
    chooseSource(other)
    expect(host.querySelector<HTMLTextAreaElement>('[data-testid="discussion-answer-CELL-purpose-0"] textarea')?.value).toBe('The adviser is checking two groups.')
    click('button-clear-discussion-CELL-purpose-0')
    expect(host.querySelectorAll('input:checked')).toHaveLength(0)
    expect(answerFor('CELL-purpose', question.question)).toBeUndefined()
    expect(latest.callAnswers?.['CELL-purpose']).toBe('Keep this earlier discussion note.')
  })
  it('saves the deferred answer and keeps older multi-question responses as history across reload', () => {
    const questions = ['What does ADJ2 pay for?', 'Is it a flat amount or an hourly rate?', 'Is it one-time or recurring?']
    let state = draft(stateFor(['ADJ2']), 'ADJ2', { questions,
      answerKinds: ['text', 'adjustment-basis', 'adjustment-frequency'], reason })
    const basis = discussionBasis(state, 'ADJ2')
    // Older captures remain history; current edits cannot create answers to unselected questions.
    state.discussionAnswers = { ADJ2: {
      [discussionKey(questions[1], basis)]: { question: questions[1], kind: 'adjustment-basis', choice: 'hourly' },
      [discussionKey(questions[2], basis)]: { question: questions[2], kind: 'adjustment-frequency', choice: 'once' },
    } }
    state.callAnswers = { ADJ2: 'Customer will send an example.' }
    mount(state)
    type('[data-testid="discussion-answer-ADJ2-0"] textarea', 'Corrections from earlier pay periods.')
    const deferredQuestion = pendingDiscussionQuestions(state, 'ADJ2')[0].question
    expect(host.querySelectorAll('.ec-discussion__response')).toHaveLength(1)
    expect(answerFor('ADJ2', deferredQuestion)?.text).toBe('Corrections from earlier pay periods.')
    expect(answerFor('ADJ2', questions[1])?.choice).toBe('hourly')
    expect(answerFor('ADJ2', questions[2])?.choice).toBe('once')
    const memoryStore = () => {
      const data = new Map<string, string>()
      return { getItem: (key: string) => data.get(key) ?? null, setItem: (key: string, value: string) => { data.set(key, value) }, removeItem: (key: string) => { data.delete(key) } }
    }
    const stores: SessionStores = { working: memoryStore(), saved: memoryStore() }
    writeWorkingCopy(stores, latest)
    expect(loadSession(stores).discussionAnswers).toEqual(latest.discussionAnswers)
    expect(saveSession(stores, latest)).toBe(true)
    const restored = loadSession({ ...stores, working: memoryStore() })
    expect(restored.discussionAnswers).toEqual(latest.discussionAnswers)
    expect(restored.callAnswers).toEqual(latest.callAnswers)
    act(() => root!.unmount()); host.remove()
    mount(restored)
    expect(host.querySelectorAll('input:checked')).toHaveLength(0)
    expect(host.querySelector('.ec-discussion__history')?.textContent).toContain(questions[1])
    expect(host.querySelector<HTMLTextAreaElement>('[data-testid="discussion-answer-ADJ2-0"] textarea')?.value).toBe('Corrections from earlier pay periods.')
    expect(latest.resolutions).toEqual(state.resolutions)
  })
  it('shows a resolved result without questions and preserves older confirmation answers as read-only history', () => {
    let state = stateFor(['OTPREM'])
    state.answers.OTPREM = { choice: 'premium' }
    state.resolutions.OTPREM = { status: 'resolved', round: 1, reference: READY.overtimePremium }
    const question = 'Does the answer we discussed for OTPREM match how your company uses it?'
    const basis = discussionBasis(state, 'OTPREM')
    state = reduceSession(state, { type: 'setDiscussionAnswer', itemId: 'OTPREM', question, basis,
      kind: 'confirmation', change: { choice: 'partly' } })
    state = reduceSession(state, { type: 'setDiscussionAnswer', itemId: 'OTPREM', question, basis,
      kind: 'confirmation', change: { detail: 'Some shifts use a different rate.', choice: 'partly' } })
    state.callAnswers = { OTPREM: 'Keep the saved discussion note.' }
    mount(state)
    expect(host.textContent).not.toContain('Let’s fill in the gaps in your pay code setup')
    expect(host.textContent).not.toContain('Answer the questions you selected Defer for.')
    expect(host.querySelector('.ec-cheat__cell--ask')).toBeNull()
    expect(host.querySelector('.ec-discussion__response')).toBeNull()
    expect(host.querySelectorAll('input[type="radio"]')).toHaveLength(0)
    expect(host.querySelector('[data-testid="row-cheat-OTPREM"]')).toBeNull()
    expect(latest.discussionAnswers).toEqual(state.discussionAnswers)
    expect(latest.resolutions).toEqual(state.resolutions)
    const restored = parseSession(JSON.stringify(latest))!
    expect(restored.discussionAnswers).toEqual(state.discussionAnswers)
    expect(restored.callAnswers).toEqual(state.callAnswers)
    expect(draftEarningCustomerQuestions).not.toHaveBeenCalled()
  })
  it('does not replace the deferred source question when an AI draft changes wording', async () => {
    const state = taxState()
    mount(state)
    const original = sourceQuestion()
    chooseSource(original.options.find(option => !option.details && option.id !== 'unsure')!.id)
    const prior = latest
    const changed = structuredClone(latest)
    changed.customerQuestions[0].draft!.questions = ['What tax treatment did your adviser confirm this month?']
    act(() => root!.unmount()); host.remove()
    mount(changed)
    expect(host.querySelectorAll('input:checked')).toHaveLength(1)
    expect(host.textContent).toContain(original.question)
    expect(host.textContent).not.toContain(changed.customerQuestions[0].draft!.questions[0])
    expect(latest.discussionAnswers).toEqual(prior.discussionAnswers)
    await settle()
    expect(draftEarningCustomerQuestions).not.toHaveBeenCalled()
  })
  it('shows the original deferred choices without rewriting an older AI draft or requesting formats', async () => {
    const state = taxState()
    delete state.customerQuestions[0].draft!.answerKinds
    vi.mocked(draftEarningCustomerQuestions).mockResolvedValue({ ...taxDraft, reason: 'A different reason that should not replace the original.' })
    mount(state)
    expect(host.textContent).not.toContain('Loading answer choices')
    chooseSource(sourceQuestion().options.find(option => option.details)!.id)
    type('[data-testid="discussion-answer-CELL-purpose-0"] textarea', 'The adviser is reviewing this.')
    await settle()
    expect(draftEarningCustomerQuestions).not.toHaveBeenCalled()
    expect(latest.customerQuestions[0].draft?.reason).toBe(reason)
    expect(latest.customerQuestions[0].draft?.questions).toEqual(taxDraft.questions)
    expect(host.querySelectorAll('input[type="radio"]')).toHaveLength(3)
    expect(host.querySelector<HTMLTextAreaElement>('[data-testid="discussion-answer-CELL-purpose-0"] textarea')?.value).toBe('The adviser is reviewing this.')
    expect(latest.callAnswers).toEqual(state.callAnswers)
    act(() => root!.unmount()); host.remove()
    mount(parseSession(JSON.stringify(latest))!)
    await settle()
    expect(draftEarningCustomerQuestions).not.toHaveBeenCalled()
  })
  it('keeps original deferred choices usable without depending on the draft endpoint', async () => {
    const state = taxState()
    delete state.customerQuestions[0].draft!.answerKinds
    vi.mocked(draftEarningCustomerQuestions).mockRejectedValueOnce(new Error('unavailable')).mockResolvedValueOnce(taxDraft)
    mount(state)
    await settle()
    expect(host.textContent).not.toContain('We couldn’t load answer choices.')
    chooseSource(sourceQuestion().options.find(option => option.details)!.id)
    type('[data-testid="discussion-answer-CELL-purpose-0"] textarea', 'Check with our adviser.')
    await settle()
    expect(draftEarningCustomerQuestions).not.toHaveBeenCalled()
    expect(host.querySelectorAll('input[type="radio"]')).toHaveLength(3)
    expect(host.querySelector<HTMLTextAreaElement>('[data-testid="discussion-answer-CELL-purpose-0"] textarea')?.value).toBe('Check with our adviser.')
  })
  it('ignores stale writes and malformed optional responses without dropping payroll or notes', () => {
    const state = taxState()
    expect(reduceSession(state, { type: 'setDiscussionAnswer', itemId: 'CELL-purpose', basis: 'stale',
      question: taxDraft.questions[0], kind: 'phone-tax', change: { choice: 'taxed' } })).toBe(state)
    const restored = parseSession(JSON.stringify({ ...state, discussionAnswers: { 'CELL-purpose': {
      bad: { kind: 'phone-tax', choice: 'guessed', question: 'Wrong choice?' },
    } } }))
    expect(restored?.discussionAnswers?.['CELL-purpose']).toEqual({})
    expect(restored?.callAnswers).toEqual(state.callAnswers)
    expect(restored?.resolutions).toEqual(state.resolutions)
  })
})
