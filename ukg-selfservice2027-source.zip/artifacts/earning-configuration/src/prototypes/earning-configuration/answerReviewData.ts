import type { EarningAnswerReviewResult } from '@workspace/api-client-react'
import type { ItemAnswer } from './session'

/** Asked by the answer review's Ask Bryte link, and one of the plan page's suggested questions. */
export const PLAN_LATER_QUESTION = 'What if my company starts paying later?'

/** A stored result. Reviews saved before suggestions existed don't have one. */
export type StoredReviewResult = Omit<EarningAnswerReviewResult, 'suggestion'> & { suggestion?: string }

/** One earlier turn of the review conversation: the question the review asked and the person's (redacted) reply. */
export interface AnswerReviewTurn {
  reason?: string
  suggestion?: string
  question: string
  reply: string
}

export interface AnswerReviewRecord {
  basis: string
  /** The latest result. */
  result: StoredReviewResult
  dismissed?: boolean
  /** Earlier turns, oldest first. Reviews saved before threads existed have none and show as a one-turn thread. */
  thread?: AnswerReviewTurn[]
  /** Retired: the single reply older reviews stored. Kept so they still load; never written. */
  reply?: string
}

/** A current question remains open until answered or explicitly dismissed, regardless of thread length. */
export function reviewOpen(record: AnswerReviewRecord): boolean {
  return !record.dismissed && record.result.question !== null
}

/** Only user answers affect a review. Receiving another AI result must not start a request loop. */
export function answerReviewBasis(answer: ItemAnswer): string {
  // Something else joins only when present, so reviews saved before it existed keep their basis.
  return JSON.stringify([answer.choice, answer.description, answer.descriptionSubmitted, answer.followUps, answer.sharedSetup, answer.retain,
    ...(answer.somethingElse ? [answer.somethingElse] : [])])
}

const optionalText = (value: unknown, max: number) => value === undefined || typeof value === 'string' && value.length > 0 && value.length <= max

function validTurn(value: unknown): value is AnswerReviewTurn {
  if (!value || typeof value !== 'object') return false
  const turn = value as AnswerReviewTurn
  return typeof turn.question === 'string' && turn.question.length > 0 && turn.question.length <= 200
    && typeof turn.reply === 'string' && turn.reply.length > 0 && turn.reply.length <= 500
    && optionalText(turn.reason, 300) && optionalText(turn.suggestion, 300)
}

export function validAnswerReview(value: unknown): value is AnswerReviewRecord {
  if (!value || typeof value !== 'object') return false
  const record = value as AnswerReviewRecord
  const result = record.result
  return typeof record.basis === 'string' && !!result
    && (result.medicalSetup == null || (
      typeof result.medicalSetup.name === 'string' && !!result.medicalSetup.name.trim() && result.medicalSetup.name.length <= 100
      && ['Earning', 'Deduction'].includes(result.medicalSetup.classification)
      && (result.medicalSetup.employeeMedicalCode === null || typeof result.medicalSetup.employeeMedicalCode === 'string'
        && !!result.medicalSetup.employeeMedicalCode.trim() && result.medicalSetup.employeeMedicalCode.length <= 20)
      && result.outcome === 'confirm'))
    && ['confirm', 'conflict', 'followUp', 'notNeeded'].includes(result.outcome)
    && typeof result.reason === 'string' && result.reason.length > 0 && result.reason.length <= 300
    // Reviews saved before suggestions existed don't have one.
    && optionalText(result.suggestion, 300)
    && (result.question === null || typeof result.question === 'string' && result.question.length > 0 && result.question.length <= 200)
    // followUp always asks; confirm and notNeeded resolve the answer; a conflict may ask to settle the disagreement.
    && (result.outcome === 'followUp' ? result.question !== null : result.outcome === 'conflict' || result.question === null)
    && (result.conflictingFact === null || ['description', 'section', 'peopleCount', 'amount', 'observedReference'].includes(result.conflictingFact))
    && (result.outcome === 'conflict') === (result.conflictingFact !== null)
    // Reviews saved before the Ask Bryte signal existed don't have it; only a confirm may carry it.
    && (result.askBryte === undefined || typeof result.askBryte === 'boolean' && (!result.askBryte || result.outcome === 'confirm'))
    && (record.dismissed === undefined || typeof record.dismissed === 'boolean')
    && (record.thread === undefined || Array.isArray(record.thread) && record.thread.every(validTurn))
    && (record.reply === undefined || typeof record.reply === 'string' && record.reply.length <= 500)
}

/** A fresh result from the server must carry a suggestion; only stored older reviews may lack one. */
export function validFreshReview(result: unknown): result is EarningAnswerReviewResult {
  const suggestion = (result as { suggestion?: unknown } | null)?.suggestion
  return validAnswerReview({ basis: '', result }) && typeof suggestion === 'string' && suggestion.trim().length > 0
}
