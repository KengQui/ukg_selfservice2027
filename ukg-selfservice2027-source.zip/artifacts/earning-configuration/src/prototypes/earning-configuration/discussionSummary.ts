import type { EarningDiscussionSummaryInput } from '@workspace/api-client-react'
import { redactSensitive } from '@workspace/setup-shared/ask-bryte'
import { discussionContext } from './discussionContext'
import { pendingDiscussionQuestions } from './reviewDiscussionChoices'
import { findItem } from './sampleRegister'
import { sampleRegistersFor } from './sampleDocument'
import { sharedSetupFor, type EarningSession, type SessionAction } from './session'
import { discussionBasis, discussionKey } from './discussionAnswers'

/** No discussion text is used as a confirmed fact; no name or register section implies a match. */
export function discussionSummaryInput(session: EarningSession, itemId: string): EarningDiscussionSummaryInput | undefined {
  const question = pendingDiscussionQuestions(session, itemId)[0]
  if (!question) return
  const item = findItem(itemId)
  const context = discussionContext(item, session.answers[itemId], session.resolutions[itemId], item.context)
  const earlier = context.earlier.filter(entry => entry.question !== question.question)
  if (!earlier.some(entry => !entry.historical && entry.provenance === 'answer')) return
  const evidence: EarningDiscussionSummaryInput['evidence'] = earlier.map(entry => ({
    kind: entry.historical ? 'historicalAnswer' : entry.provenance === 'supplied' ? 'suppliedContext' : 'customerAnswer',
    source: entry.question, text: entry.answer,
  }))
  for (const register of sampleRegistersFor(session.files).filter(register => session.files.some(file => file.id === register.file.id))) {
    const owner = item.type === 'finding' ? findItem(item.raisedBy).code : item.code
    const row = register.rows.find(row => row.code === owner)
    if (row) evidence.push({ kind: 'document', source: `${register.file.id} | ${register.file.name} | ${register.period}`,
      text: `${owner === item.code ? 'Register code' : 'Related source code, not a register row for the proposed code'}: ${owner}. Section: ${row.section}. Period amount: ${row.periodAmount ?? 'not supplied'}.` })
  }
  for (const review of context.reviews) evidence.push({ kind: 'aiSuggestion', source: 'Earlier AI check, not approval',
    text: [review.reason, review.suggestion].filter(Boolean).join(' ') })
  const key = discussionKey(question.question, discussionBasis(session, itemId), question.options.length ? question.options : undefined)
  for (const [oldKey, response] of Object.entries(session.discussionAnswers?.[itemId] ?? {})) {
    if (oldKey === key) continue
    const choice = response.options?.find(option => option.id === response.choice)?.label
    const text = [choice, response.choice && response.details?.[response.choice], response.text].filter(Boolean).join(' ')
    const applied = session.discussionApplications?.some(receipt => !!receipt.responses[itemId]?.[oldKey])
    if (text) evidence.push({ kind: applied ? 'historicalAnswer' : 'unappliedResponse',
      source: `Earlier ${applied ? 'applied' : 'unapplied'} captured response to ${response.question}`, text })
  }
  const shared = sharedSetupFor(item, session.answers[itemId])
  for (const related of shared?.codes ?? []) {
    const accepted = session.resolutions[related.code]
    if (accepted?.status === 'resolved') evidence.push({ kind: 'acceptedDecision', source: `Confirmed review for ${related.code}`,
      text: `${related.code} uses ${accepted.reference.name}. Its relationship to ${item.code} remains unconfirmed.` })
  }
  return { code: item.code, question: question.question, evidence: evidence.slice(0, 60).map(entry => ({
    kind: entry.kind, source: redactSensitive(entry.source).slice(0, 500), text: redactSensitive(entry.text).slice(0, 2000),
  })) }
}

export function discussionSummaryBasis(session: EarningSession, itemId: string) {
  const input = discussionSummaryInput(session, itemId)
  // Refresh supporting summaries created before the facts-only wording policy.
  // Captured answers, proposals and application identities have independent bases and stay unchanged.
  return input ? JSON.stringify({ wording: 'concise-facts-no-ai', input }) : undefined
}

export function saveDiscussionSummary(session: EarningSession, action: Extract<SessionAction, { type: 'setDiscussionSummary' }>, now: number) {
  if (action.basis !== discussionSummaryBasis(session, action.itemId)
    || !action.summary.trim() || action.summary.length > 600) return session
  return { ...session, updatedAt: now, discussionSummaries: { ...session.discussionSummaries,
    [action.itemId]: { basis: action.basis, summary: redactSensitive(action.summary) } } }
}
