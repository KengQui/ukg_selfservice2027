import { act } from 'react'
import { createRoot } from 'react-dom/client'
import { renderToStaticMarkup } from 'react-dom/server'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { createSession, reduceSession, parseSession, reviewPages, addedCodesPageIndex, canSubmitRound, isAnswered, type EarningSession, type SessionAction } from './session'
import { ASK_CUSTOMER, findItem } from './sampleRegister'
import { REVIEW_TOPICS, reviewTopicForPage, sectionReviewPages } from './reviewTopics'
import { reviewSteps, reviewCodeRows } from './reviewStatus'
import { SessionContext } from './sessionContext'
import StepQuestions from './StepQuestions'
import { EARNING_DEMO_SETTINGS } from './demoSettings'
import { OPTIONAL_DEMO_SOURCES } from './optionalDemoQuestions'
import { sourceGroups } from './questionApplicability'
import { loadSession, saveSession } from './storage'
import { requestDescriptionCheck } from './descriptionCheck'

vi.mock('./descriptionCheck', async original => ({
  ...await original<typeof import('./descriptionCheck')>(),
  requestDescriptionCheck: vi.fn(() => new Promise(() => {})),
}))
const run = (session: EarningSession, ...actions: SessionAction[]) => actions.reduce((state, action) => {
  const next = reduceSession(state, action.type === 'choose' && action.itemId === 'MILEAGE' && action.choice === ASK_CUSTOMER
    ? { type: 'cell', itemId: 'MILEAGE', event: { kind: 'defer', checked: true } } : action, 100)
  return action.type === 'choose' && action.choice === ASK_CUSTOMER
    ? reduceSession(next, { type: 'selectDeferredQuestion', itemId: action.itemId, source: { question: findItem(action.itemId).question, choices: [] } }, 100)
    : next
}, session)
const start = () => run(createSession(0), { type: 'startReview' })
const pageFor = (session: EarningSession, id: string) => reviewPages(session).findIndex(page => page.includes(id))
const defer = (itemId: string): SessionAction => ({ type: 'choose', itemId, choice: ASK_CUSTOMER })
const context = (session: EarningSession, dispatch = (_action: SessionAction) => {}) => ({ session, dispatch, save: () => true, restart: () => true })
const doc = (session: EarningSession) => new DOMParser().parseFromString(renderToStaticMarkup(
  <SessionContext.Provider value={context(session)}><StepQuestions /></SessionContext.Provider>), 'text/html')
const visible = (root: ParentNode) => [...root.querySelectorAll<HTMLElement>('[data-review-item]')].filter(node => !node.hidden)

beforeEach(() => {
  vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT', true)
  EARNING_DEMO_SETTINGS.hideOptionalQuestions = false
  EARNING_DEMO_SETTINGS.ungateForwardButtons = false
})
afterEach(() => { vi.unstubAllGlobals(); vi.clearAllMocks(); EARNING_DEMO_SETTINGS.hideOptionalQuestions = false; EARNING_DEMO_SETTINGS.ungateForwardButtons = false })

describe('one clarification card per page', () => {
  it('keeps topic order, unique sidebar topics and exact code destinations', () => {
    const session = start()
    const pages = reviewPages(session)
    const topics = [...new Set(pages.map(page => reviewTopicForPage(page)!.id))]
    expect(topics).toEqual(REVIEW_TOPICS.filter(topic => pages.flat().some(id => reviewTopicForPage([id])?.id === topic.id)).map(topic => topic.id))
    expect(reviewSteps(session).map(step => step.label)).toEqual([...topics.map(id => REVIEW_TOPICS.find(topic => topic.id === id)!.title), 'Additional earning codes'])
    for (const [index, page] of pages.entries()) {
      expect(sourceGroups(page)).toHaveLength(1)
      const screen = doc({ ...session, reviewCursor: index })
      expect(visible(screen)).toHaveLength(1)
      expect(visible(screen)[0].dataset.reviewItem).toBe(page[0])
      expect(screen.querySelector('h1')?.textContent).toBe(reviewTopicForPage(page)?.title)
      const section = sectionReviewPages(pages, pages.map((_, index) => index), index)
      expect(screen.querySelector('.ec-section-note')).toBeNull()
      expect(screen.querySelector('.ec-review-card-counter [aria-hidden]')?.textContent).toBe(`${section.indexOf(index) + 1}/${section.length}`)
      expect(screen.querySelectorAll('[aria-current="step"]')).toHaveLength(1)
    }
    for (const row of reviewCodeRows(session)) expect(pages[row.page]).toContain(row.id)
  })

  it('gates Next per card, preserves deferrals and keeps additions last', () => {
    let session = start()
    expect(run(session, { type: 'moveReview', index: 1 })).toBe(session)
    session = run(session, defer(reviewPages(session)[0][0]), { type: 'moveReview', index: 1 })
    expect(session.reviewCursor).toBe(1)
    const answers = session.answers
    session = run(session, { type: 'moveReview', index: 0 })
    expect(session.answers).toEqual(answers)
    session = run(session, ...reviewPages(session).flat().map(defer))
    expect(reviewPages(session).flat().filter(id => !isAnswered(findItem(id), session.answers[id]))).toEqual([])
    const added = addedCodesPageIndex(session)
    expect(added).toBe(reviewPages(session).length)
    session = run(session, { type: 'moveReview', index: added })
    expect(visible(doc(session))).toHaveLength(0)
    expect(doc(session).querySelector('h1')?.textContent).toBe('Additional earning codes')
    expect(parseSession(JSON.stringify(session))?.reviewCursor).toBe(added)
    const next = run(session, { type: 'startOptimization' })
    expect(next.step).toBe('optimization')
    expect(next.answers).toEqual(session.answers)
  })

  it('keeps related findings inside their parent card in initial and added-question rounds', () => {
    const base = run(start(), { type: 'choose', itemId: 'TIPS', choice: 'both' })
    const pages = reviewPages(base)
    expect(pages.find(page => page.includes('TIPS'))).toEqual(['TIPS', 'TIPS RPT'])
    expect(pages.flat().filter(id => id === 'TIPS RPT')).toHaveLength(1)
    expect(visible(doc({ ...base, reviewCursor: pageFor(base, 'TIPS') }))).toHaveLength(1)
    const added: EarningSession = { ...base, rounds: [{ number: 2, kind: 'added-questions', submitted: false, itemIds: ['TIPS', 'TIPS RPT', 'BONREV'] }] }
    expect(reviewPages(added)).toEqual([['TIPS', 'TIPS RPT'], ['BONREV']])
    expect(addedCodesPageIndex(added)).toBe(-1)
  })

  it('migrates topic cursors to the first unfinished card without changing answers', () => {
    const base = run(start(), defer('OTPREM'))
    const old = { ...base, reviewCardVersion: undefined, reviewItemId: undefined, reviewCursor: 0 }
    const restored = parseSession(JSON.stringify(old))!
    expect(reviewPages(restored)[restored.reviewCursor!]).toContain('OTMFG')
    expect(restored.answers).toEqual(old.answers)
    expect(parseSession(JSON.stringify(restored))).toEqual(restored)
    const answered = run(base, ...reviewPages(base).flat().map(defer))
    const topics = [...new Set(reviewPages(answered).map(page => reviewTopicForPage(page)!.id))]
    for (const [index, topic] of topics.entries()) {
      const migrated = parseSession(JSON.stringify({ ...answered, reviewCardVersion: undefined, reviewItemId: undefined, reviewCursor: index }))!
      expect(reviewTopicForPage(reviewPages(migrated)[migrated.reviewCursor!])?.id).toBe(topic)
      expect(migrated.answers).toEqual(answered.answers)
    }
    const additional = parseSession(JSON.stringify({ ...answered, reviewCardVersion: undefined, reviewItemId: undefined, reviewCursor: topics.length }))!
    expect(additional.reviewCursor).toBe(addedCodesPageIndex(additional))
  })

  it('restores stable card identity and draft text without making an answer', () => {
    let session = run(start(), ...reviewPages(start()).flat().map(defer))
    session = run(session, { type: 'moveReview', index: pageFor(session, 'SPPAY') },
      { type: 'reviewDraft', key: JSON.stringify(['SPPAY', 'Payment question', 'text']), value: 'Still checking' })
    const restored = parseSession(JSON.stringify({ ...session, reviewCursor: 0 }))!
    expect(reviewPages(restored)[restored.reviewCursor!]).toContain('SPPAY')
    expect(restored.reviewDrafts).toEqual(session.reviewDrafts)
    expect(restored.answers).toEqual(session.answers)
    const stores = { working: sessionStorage, saved: localStorage }
    sessionStorage.clear(); localStorage.clear()
    expect(saveSession(stores, session)).toBe(true)
    sessionStorage.clear()
    const reopened = loadSession(stores)
    expect(reviewPages(reopened)[reopened.reviewCursor!]).toContain('SPPAY')
    expect(reopened.reviewDrafts).toEqual(session.reviewDrafts)
    expect(reopened.answers).toEqual(session.answers)
    sessionStorage.clear(); localStorage.clear()
  })

  it('never creates blank pages or exposes optional examples on saved cursors', () => {
    EARNING_DEMO_SETTINGS.hideOptionalQuestions = true
    const session = start()
    for (let index = 0; index < reviewPages(session).length; index++) {
      const screen = doc({ ...session, reviewCursor: index })
      const cards = visible(screen)
      if (cards.length) {
        expect(cards).toHaveLength(1)
        expect(OPTIONAL_DEMO_SOURCES).not.toContain(cards[0].dataset.reviewItem)
      } else expect(screen.querySelector('h1')?.textContent).toBe('Additional earning codes')
    }
    expect(session.answers).toEqual({})
  })

  it('can finish an added round containing only hidden examples without applying a decision', () => {
    EARNING_DEMO_SETTINGS.hideOptionalQuestions = true
    const session: EarningSession = { ...start(), rounds: [{ number: 2, kind: 'added-questions', submitted: false, itemIds: ['MISC7'] }] }
    const screen = doc(session)
    expect(visible(screen)).toHaveLength(0)
    expect(screen.body.textContent).toContain('There are no questions to show. Select Next to continue.')
    expect(screen.body.textContent).not.toContain('Page 0 of 0')
    expect(canSubmitRound(session)).toBe(true)
    const applied = run(session, { type: 'submitRound' })
    expect(applied.resolutions.MISC7).toBeUndefined()
    expect(applied.answers).toEqual(session.answers)
  })

  it('keeps the visited card, its text and its pending request mounted across Back and Next', () => {
    EARNING_DEMO_SETTINGS.ungateForwardButtons = true
    let session: EarningSession = { ...start(), reviewCursor: pageFor(start(), 'SPPAY') }
    const host = document.createElement('div'); document.body.append(host)
    const root = createRoot(host)
    const dispatch = (action: SessionAction) => { session = run(session, action); render() }
    const render = () => root.render(<SessionContext.Provider value={context(session, dispatch)}><StepQuestions /></SessionContext.Provider>)
    try {
      act(render)
      const card = visible(host)[0]
      act(() => dispatch({ type: 'describe', itemId: 'SPPAY', description: 'A monthly payment for language skills' }))
      act(() => dispatch({ type: 'submitDescription', itemId: 'SPPAY' }))
      expect(requestDescriptionCheck).toHaveBeenCalledTimes(1)
      const signal = vi.mocked(requestDescriptionCheck).mock.calls[0][1]!
      act(() => dispatch({ type: 'moveReview', index: 0 }))
      expect(card.hidden).toBe(true)
      expect(visible(host)).toHaveLength(1)
      act(() => dispatch({ type: 'moveReview', index: pageFor(session, 'SPPAY') }))
      expect(visible(host)[0]).toBe(card)
      expect(signal.aborted).toBe(false)
      expect(requestDescriptionCheck).toHaveBeenCalledTimes(1)
      expect(document.activeElement).toBe(host.querySelector('h1'))
    } finally { act(() => root.unmount()); host.remove() }
  })
})
