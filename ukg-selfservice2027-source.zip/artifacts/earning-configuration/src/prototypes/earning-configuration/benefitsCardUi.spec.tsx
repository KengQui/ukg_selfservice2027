import { act, type ReactNode } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import StepQuestions from './StepQuestions'
import CustomerReplyDialog from './CustomerReplyDialog'
import { SessionContext } from './sessionContext'
import { ASK_CUSTOMER, findItem } from './sampleRegister'
import { createSession, decisionFor, isAnswered, parseSession, reduceSession, reviewPages, type EarningSession, type SessionAction } from './session'
import { customerQuestionList } from './summary'
import { MEDICAL_DISPLAY_QUESTION } from './medical'
import { MEDICAL_CONTRIBUTION_QUESTIONS as definition } from './benefitQuestions'
import { conditionalReport } from './conditionalQuestions'
import { GTL_ID, GTL_QUESTIONS } from './gtlQuestions'
import { DiscussionLockedQuestions } from './QuestionCard'
import { routingOpen } from './reviewRouting.testing'
import type { PaymentSequenceProps } from './paymentSupplement'

// This suite isolates conditional benefit presentation. The real supplement/API composition
// is exercised with deterministic results in codeSequenceComposition.spec.tsx.
vi.mock('./PaymentFactQuestions', () => ({
  default: ({ children }: { children?: PaymentSequenceProps['children'] }) =>
    children?.({ questions: null, hasQuestions: false }) ?? null,
}))

let host: HTMLDivElement
let root: Root
let session: EarningSession
beforeEach(() => {
  vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT', true)
  host = document.createElement('div'); document.body.append(host); root = createRoot(host)
  const started = reduceSession(createSession(0), { type: 'startReview' })
  session = { ...started, reviewCursor: reviewPages(started).findIndex(page => page.includes('MED ER')) }
})
afterEach(() => { act(() => root.unmount()); host.remove(); vi.unstubAllGlobals() })
function dispatch(action: SessionAction) { session = reduceSession(session, action); render() }
const provider = (children: ReactNode, handler = dispatch) =>
  <SessionContext.Provider value={{ session, dispatch: handler, save: () => true, restart: () => true }}>{children}</SessionContext.Provider>
const render = () => act(() => root.render(provider(<StepQuestions />)))
const card = (id: string) => host.querySelector<HTMLElement>(`.ec-guide-item[aria-label^="${id},"] article.ec-qcard`)!
const radio = (scope: ParentNode, title: string) => [...scope.querySelectorAll<HTMLElement>('[role="radio"]')]
  .find(node => node.querySelector('.sc__title')?.textContent === title)!
const button = (scope: ParentNode, title: string) => [...scope.querySelectorAll<HTMLButtonElement>('button')]
  .find(node => node.textContent?.trim() === title)!
const chooseByKeyboard = (scope: ParentNode, title: string) => act(() =>
  radio(scope, title).dispatchEvent(new KeyboardEvent('keydown', { key: ' ', bubbles: true })))
const fillComment = (text: string) => act(() => {
  const details = card('MED ER').querySelector('textarea')!
  Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')!.set!.call(details, text)
  details.dispatchEvent(new Event('input', { bubbles: true }))
})

function expectRecap(scope = card('MED ER')) {
  const recap = scope.querySelector('[aria-label="MED ER answer summary"]')
  expect(recap).not.toBeNull()
  expect(recap?.textContent).toContain('This reflects your answers, not verified tax treatment or completed Ready setup.')
  const sequence = scope.querySelector('.ec-qcard__sequence')!
  expect(sequence.compareDocumentPosition(recap!) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy()
  expect(recap?.closest('[role="radio"], .ec-qcard__sequence')).toBeNull()
  expectNoSpecialistReport(scope)
  return recap!
}

function expectNoSpecialistReport(scope = card('MED ER')) {
  expect(scope.querySelector('.ec-conditional-summary, [aria-label="MED ER reported intent summary"], dl')).toBeNull()
  expect(scope.textContent).not.toMatch(/Review summary|Client-reported information|Setup verification is not completed|Payroll Code|Reported Purpose|Tax Treatment|Cash Compensation|Configuration Verification|Review Status|Recommended Action/)
  expect(scope.textContent).not.toContain(definition.recommendedAction)
  // Keep the old specialist report out of the customer card.
  const sections = scope.querySelector('.mc-card__response > .ec-qcard__sections')!
  expect([...sections.children].every(node =>
    node.matches('.ec-qcard__sequence, .ec-description, [role="status"]'))).toBe(true)
}

/** The same card-level slot used by current Mileage, never a selected option's content. */
function expectCardLevelSequence(scope: HTMLElement, count: number) {
  const opening = scope.querySelector('.mc-card__response > .ec-qcard__answer')!
  expect(opening.querySelectorAll('[role="radio"]')).toHaveLength(count)
  const sequence = scope.querySelector('.ec-qcard__sequence')!
  expect(sequence.parentElement?.matches('.mc-card__response > .ec-qcard__sections')).toBe(true)
  expect(opening.compareDocumentPosition(sequence) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy()
  expect(sequence.closest('.ec-qcard__option-panel, .ec-qcard__option-content, [role="radio"], form')).toBeNull()
  expect(scope.querySelector('form form')).toBeNull()
  expect(scope.querySelectorAll('[data-sequence-number="01"]')).toHaveLength(1)
  expect(scope.querySelectorAll('.ec-defer')).toHaveLength(1)
  return sequence
}

describe('medical employer card', () => {
  it('shows only MED ER with the requested wording and no premature mapping', () => {
    render()
    const cards = [...host.querySelectorAll('.ec-guide-item')]
    expect(cards.map(node => node.getAttribute('aria-label')?.split(',')[0])).toEqual(['MED ER'])
    for (const id of ['MED ER']) {
      expect(card(id).matches('.ec-qcard--misclassification.mc-card')).toBe(true)
      expect(card(id).querySelectorAll('.ec-defer')).toHaveLength(1)
      expect(card(id).querySelector('.mc-card__response .ec-defer')).not.toBeNull()
      expect(card(id).querySelector('.mc-card__header > .mc-card__question')?.textContent).toBe(findItem(id).question)
    }
    expect(card('MED ER').textContent).not.toContain('Earning → Employer portion of MED')
    expect(card('MED ER').querySelector('.mc-card__question')?.textContent).toBe(definition.question)
    expect(card('MED ER').textContent).toContain(definition.introduction)
    expect(card('MED ER').querySelectorAll('[data-sequence-number]')).toHaveLength(0)
    expect([...card('MED ER').querySelectorAll('.sc__title')].map(node => node.textContent)).toEqual(definition.purposes.map(p => p.label))
    expect(host.textContent).not.toMatch(/\bDEN\b|imputed|W-2|Show Employer Amount/)
    expect(host.querySelector('.ec-intro strong')?.textContent).toBe('Defer')
  })

  it('keeps additional compensation distinct and requires review instead of mapping it to a contribution', () => {
    render()
    chooseByKeyboard(card('MED ER'), definition.purposes[1].label)
    expect(session.answers['MED ER'].choice).toBe('additional-compensation')
    expect(card('MED ER').textContent).toContain(definition.purposes[1].followUp.question)
    expect(card('MED ER').textContent).not.toContain(MEDICAL_DISPLAY_QUESTION)
    expect(decisionFor(findItem('MED ER'), session.answers['MED ER'])).toBeUndefined()
  })

  it.each(definition.purposes)('shows only the numbered follow-up for $label below all opening choices', purpose => {
    render()
    chooseByKeyboard(card('MED ER'), purpose.label)
    expect(card('MED ER').querySelectorAll('[data-sequence-number]')).toHaveLength(1)
    expect(card('MED ER').textContent).toContain(purpose.followUp.question)
    for (const other of definition.purposes.filter(other => other.followUp.id !== purpose.followUp.id)) {
      expect(card('MED ER').textContent).not.toContain(other.followUp.question)
    }
    const sequence = expectCardLevelSequence(card('MED ER'), definition.purposes.length)
    expect(sequence.textContent).toContain(purpose.followUp.question)
    const groups = card('MED ER').querySelectorAll('[role="radiogroup"]')
    expect(groups).toHaveLength(2)
    expect(groups[0].getAttribute('aria-labelledby')).not.toBe(groups[1].getAttribute('aria-labelledby'))
    expect(groups[0].querySelector('input:checked')).not.toBeNull()
    expect(groups[1].querySelector('input:checked')).toBeNull()
    chooseByKeyboard(sequence, purpose.followUp.options[0].label)
    expectCardLevelSequence(card('MED ER'), definition.purposes.length)
    expect(sequence.querySelector('.ec-qcard__sequence-answer')?.textContent).toContain(purpose.followUp.options[0].label)
    expectRecap()
    act(() => sequence.querySelector<HTMLButtonElement>('.ec-qcard__sequence-answer')!.click())
    expect(sequence.querySelector('input:checked')).not.toBeNull()
    expect(groups[0].querySelector('input:checked')).not.toBeNull()
  })

  it.each(definition.purposes.flatMap(purpose =>
    purpose.followUp.options.map(option => ({ purpose, option })),
  ))('recaps $purpose.id / $option.id without changing completion or saved reports after restore', ({ purpose, option }) => {
    render()
    chooseByKeyboard(card('MED ER'), purpose.label)
    expect(isAnswered(findItem('MED ER'), session.answers['MED ER'])).toBe(false)
    expect(card('MED ER').querySelector('[aria-label="MED ER answer summary"]')).toBeNull()
    chooseByKeyboard(card('MED ER').querySelector<HTMLElement>('.ec-qcard__sequence')!, option.label)
    const saved = session.answers['MED ER']
    const decision = decisionFor(findItem('MED ER'), saved)
    expect(isAnswered(findItem('MED ER'), saved)).toBe(true)
    expect(decision).toMatchObject({ kind: 'describe', note: expect.stringContaining('Configuration Verification: Not completed') })
    const recap = expectRecap().textContent
    if (purpose.id === 'uncertain-purpose') expect(recap).toContain('purpose is still unclear')
    if (option.id === 'unsure') expect(recap).toMatch(/not sure|needs review/)
    expect(card('MED ER').querySelector('[role="status"]')).toBeNull()
    session = parseSession(JSON.stringify(session))!
    render()
    expect(session.answers['MED ER']).toEqual(saved)
    expect(decisionFor(findItem('MED ER'), session.answers['MED ER'])).toEqual(decision)
    expect(expectRecap().textContent).toBe(recap)
    expect(card('MED ER').querySelector('[role="status"]')).toBeNull()
    const sequence = expectCardLevelSequence(card('MED ER'), definition.purposes.length)
    expect(sequence.querySelector('.ec-qcard__sequence-answer')?.textContent).toContain(option.label)
    expect(card('MED ER').querySelectorAll('.sc__title')).toHaveLength(definition.purposes.length)
  })

  it('shows optional details only for the relevant answer and clears the old branch when purpose changes', () => {
    render()
    chooseByKeyboard(card('MED ER'), definition.purposes[3].label)
    expect(card('MED ER').querySelector('textarea')).toBeNull()
    chooseByKeyboard(card('MED ER').querySelector<HTMLElement>('.ec-qcard__sequence')!, 'We can share a brief description')
    const details = card('MED ER').querySelector('textarea')!
    expect(details.closest('.ec-qcard__sections')).not.toBeNull()
    expect(details.closest('.ec-qcard__option-panel, [role="radio"], form')).toBeNull()
    fillComment('Please review the benefit reporting.')
    const saved = session.answers['MED ER']
    session = parseSession(JSON.stringify(session))!
    render()
    expect(session.answers['MED ER']).toEqual(saved)
    expect(card('MED ER').querySelector('textarea')?.value).toBe('Please review the benefit reporting.')
    expect(decisionFor(findItem('MED ER'), session.answers['MED ER'])).toMatchObject({
      kind: 'describe', note: expect.stringContaining('Additional information: Please review the benefit reporting.'),
    })
    expect(expectRecap().textContent).toContain('purpose is still unclear')
    chooseByKeyboard(card('MED ER'), definition.purposes[1].label)
    expect(card('MED ER').querySelector('textarea')).toBeNull()
    expect(session.answers['MED ER'].conditionalReview?.responses).toEqual({})
    expect(session.answers['MED ER'].conditionalReview?.comments).toEqual({})
    expect(card('MED ER').querySelector('[aria-label="MED ER answer summary"]')).toBeNull()
    expect(card('MED ER').textContent).not.toContain('Which payroll tax or reporting categories does MED ER affect?')
    chooseByKeyboard(card('MED ER').querySelector<HTMLElement>('.ec-qcard__sequence')!, 'Something else')
    expect(card('MED ER').querySelector('textarea')).not.toBeNull()
  })

  it('uses one numbered follow-up, one Defer, and clears just this card', async () => {
    render()
    chooseByKeyboard(card('MED ER'), definition.purposes[0].label)
    const section = () => card('MED ER').querySelector<HTMLElement>('[data-sequence-number="01"]')!
    expect(section().textContent).toContain(definition.purposes[0].followUp.question)
    expect(card('MED ER').querySelectorAll('.ec-defer')).toHaveLength(1)
    chooseByKeyboard(section(), "We're not sure yet")
    expect(session.answers['MED ER'].conditionalReview?.responses['employer-tax-treatment-v2']).toBe('unsure')
    expect(decisionFor(findItem('MED ER'), session.answers['MED ER'])?.kind).toBe('describe')
    expect(conditionalReport(definition, session.answers['MED ER'].conditionalReview)?.category).toBe('Needs Review')
    session = parseSession(JSON.stringify(session))!
    render()
    expect(expectRecap().textContent).toContain('not sure how it affects taxable pay')
    const footer = () => card('MED ER').querySelector('.mc-card__response > .ec-qcard__footer-actions')!
    expect(footer().firstElementChild?.textContent).toBe('Clear all answers')
    expect(footer().lastElementChild?.matches('.ec-defer')).toBe(true)
    await act(async () => { button(card('MED ER'), 'Clear all answers').click(); await Promise.resolve() })
    expect(session.answers['MED ER'].conditionalReview).toBeUndefined()
    expect(session.answers['MED ER'].choice).toBeUndefined()
    expect(session.answers.MED).toBeUndefined()
    expect(section()).toBeNull()
    expect(card('MED ER').querySelector('[aria-label="MED ER answer summary"]')).toBeNull()
  })

  it('keeps keyboard edits and Defer working after reopening a completed answer', () => {
    render()
    chooseByKeyboard(card('MED ER'), definition.purposes[0].label)
    chooseByKeyboard(card('MED ER'), definition.purposes[0].followUp.options[0].label)
    expect(expectRecap().textContent).toContain("MED ER as your company's medical contribution")
    expect(expectRecap().textContent).toContain('You indicated that it does not affect taxable pay.')
    session = parseSession(JSON.stringify(session))!
    render()
    act(() => card('MED ER').querySelector<HTMLButtonElement>('.ec-qcard__sequence-answer')!.click())
    act(() => radio(card('MED ER'), definition.purposes[0].followUp.options[0].label)
      .dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true })))
    expect(session.answers['MED ER'].conditionalReview).toMatchObject({
      primary: 'only-records', responses: { 'employer-tax-treatment-v2': 'taxable' },
    })
    expect(conditionalReport(definition, session.answers['MED ER'].conditionalReview)?.category).toBe('Tax/Reporting Review Required')
    expect(expectRecap().textContent).toContain('You indicated that it is included in taxable pay.')
    expect(expectRecap().textContent).not.toContain('does not affect taxable pay')
    const saved = session.answers['MED ER'].conditionalReview
    act(() => card('MED ER').querySelector<HTMLInputElement>('.ec-defer input')!.click())
    expect(decisionFor(findItem('MED ER'), session.answers['MED ER'])?.kind).toBe('defer')
    expect(session.answers['MED ER'].conditionalReview).toEqual(saved)
    expect(card('MED ER').querySelector('[aria-label="MED ER answer summary"]')).toBeNull()
    session = parseSession(JSON.stringify(session))!
    render()
    expect(card('MED ER').querySelector('[aria-label="MED ER answer summary"]')).toBeNull()
    act(() => card('MED ER').querySelector<HTMLInputElement>('.ec-defer input')!.click())
    expect(session.answers['MED ER']).toEqual({})
    expect(card('MED ER').querySelector('.ec-qcard__sections')).toBeNull()
  })

  it('recaps conflicts cautiously and preserves actionable feedback, including restored comments', () => {
    render()
    chooseByKeyboard(card('MED ER'), definition.purposes[1].label)
    chooseByKeyboard(card('MED ER').querySelector<HTMLElement>('.ec-qcard__sequence')!, 'Something else')
    fillComment('No direct cash payment; employer tracking only')
    const saved = session.answers['MED ER']
    session = parseSession(JSON.stringify(session))!
    render()
    expect(session.answers['MED ER']).toEqual(saved)
    expect(card('MED ER').querySelector('[role="status"]')?.textContent).toBe('These answers conflict. Check the purpose and treatment answers above, or select Defer to ask the customer. The setup team needs to review the discrepancy.')
    expect(expectRecap().textContent).toContain('Your answers about MED ER conflict')
    expect(expectRecap().textContent).not.toContain('pays money directly')
    expect(decisionFor(findItem('MED ER'), saved)).toMatchObject({
      kind: 'describe', note: expect.stringContaining('Conflicting information needs review.'),
    })
    fillComment('Medical allowance for temporary staff')
    expect(card('MED ER').querySelector('[role="status"]')).toBeNull()
    expect(expectRecap().textContent).toContain('pays money directly to your people')
    expect(expectRecap().textContent).not.toContain('conflict')
    expect(conditionalReport(definition, session.answers['MED ER'].conditionalReview)?.configurationVerification).toBe('Not completed')
  })

  it.each([
    ...definition.purposes.map(purpose => ({ itemId: 'MED ER', purpose, openingCount: 4 })),
    ...GTL_QUESTIONS.purposes.filter(purpose => purpose.followUp).map(purpose => ({ itemId: GTL_ID, purpose, openingCount: 3 })),
  ])('lets a customer answer $itemId / $purpose.id below the opening choices without altering the saved answer', ({ itemId, purpose, openingCount }) => {
    session = reduceSession(routingOpen([itemId]), { type: 'choose', itemId, choice: ASK_CUSTOMER })
    const flow = itemId === 'MED ER' ? definition : GTL_QUESTIONS
    session = reduceSession(session, { type: 'selectDeferredQuestion', itemId, source: {
      question: flow.question, control: 'choices', choices: flow.purposes.map(option => option.label),
      options: flow.purposes.map(option => ({ id: option.id, label: option.label })),
    } })
    session = reduceSession(session, { type: 'submitRound' })
    session = reduceSession(session, { type: 'finishReevaluation' })
    const question = customerQuestionList(session).find(q => q.id === `classification:${itemId}${itemId === 'MED ER' ? ':v2' : ''}`)!
    const save = vi.fn()
    act(() => root.render(provider(<CustomerReplyDialog question={question} onClose={() => {}} />, save)))
    const dialog = document.querySelector<HTMLElement>('[role="dialog"]')!
    expect(button(dialog, 'Save answer').disabled).toBe(true)
    chooseByKeyboard(dialog, purpose.label)
    const sequence = expectCardLevelSequence(dialog.querySelector('article.ec-qcard')!, openingCount)
    expect(sequence.textContent).toContain(purpose.followUp!.question)
    chooseByKeyboard(sequence, purpose.followUp!.options[0].label)
    const nested = (purpose.followUp!.options[0] as import('./conditionalQuestions').ConditionalOption).followUp
    if (nested) {
      expect(button(dialog, 'Save answer').disabled).toBe(true)
      chooseByKeyboard(dialog.querySelector<HTMLElement>('[data-sequence-number="02"]')!, nested.options[0].label)
    }
    expect(button(dialog, 'Save answer').disabled).toBe(false)
    if (itemId === 'MED ER') expectRecap(dialog.querySelector<HTMLElement>('article.ec-qcard')!)
    else expect(dialog.querySelector('[aria-label="MED ER answer summary"]')).toBeNull()
    act(() => button(dialog, 'Save answer').click())
    expect(save).toHaveBeenCalledWith(expect.objectContaining({ type: 'saveCustomerReply',
      answer: expect.objectContaining({ choice: purpose.id,
        conditionalReview: expect.objectContaining({ responses: expect.objectContaining({ [purpose.followUp!.id]: purpose.followUp!.options[0].id }) }) }) }))
    expect(session.answers[itemId].choice).toBe(ASK_CUSTOMER)
  })

  it('keeps locked answers and their optional information read-only after the opening', () => {
    render()
    chooseByKeyboard(card('MED ER'), definition.purposes[1].label)
    chooseByKeyboard(card('MED ER').querySelector<HTMLElement>('.ec-qcard__sequence')!, 'Something else')
    const locked = { [definition.question]: definition.purposes[1].label,
      [definition.purposes[1].followUp.question]: 'Something else' }
    act(() => root.render(provider(<DiscussionLockedQuestions.Provider value={locked}>
      <StepQuestions />
    </DiscussionLockedQuestions.Provider>)))
    expect(card('MED ER').querySelector('.ec-qcard__sections .ec-qcard__sequence')).not.toBeNull()
    expect(card('MED ER').querySelector('button.ec-qcard__sequence-answer')).toBeNull()
    expect(card('MED ER').querySelector('textarea')?.readOnly).toBe(true)
    expect(button(card('MED ER'), 'Clear all answers')).toBeUndefined()
    expect(card('MED ER').querySelector<HTMLInputElement>('.ec-defer input')?.disabled).toBe(true)
    expectRecap()
  })
})
