import { describe, expect, it } from 'vitest'
import { renderToStaticMarkup } from 'react-dom/server'
import { MemoryRouter } from 'react-router-dom'
import { actionableOvertimeSession } from './overtimeActionable.testing'
import { paymentSession, checkedFacts } from './paymentFacts.testing'
import { currentPaymentFacts, paymentRequest } from './paymentEvidence'
import { parseSession, reduceSession } from './session'
import { overtimeReview } from './overtimeReview'
import { summaryCsv } from './summary'
import { EARNING_DEMO_SETTINGS } from './demoSettings'
import { READY } from './sampleRegister'
import { AwaitingOvertimeReview } from './OvertimeRecommendations'
import { SessionContext } from './sessionContext'
import { StepOvertimeSort } from './StepOvertime'

describe('direct overtime boundaries', () => {
  it.each(['original', 'discussion', 'team'] as const)('allows all direct choices with %s setup work open, preserving that work and snapshots', kind => {
    const initial = actionableOvertimeSession(kind)
    const original = JSON.stringify([initial.answers, initial.resolutions, initial.rounds, initial.sent])
    const settings = { ...EARNING_DEMO_SETTINGS }
    try {
      EARNING_DEMO_SETTINGS.ungateForwardButtons = false
      for (const choice of ['include', 'exclude', 'unsure', 'unanswered'] as const) {
        let session = reduceSession(initial, { type: 'setOvertimeReviewChoice', code: 'Special Pay', choice })
        expect(session.overtime.reviewChoices?.['Special Pay'].choice).toBe(choice)
        expect(JSON.stringify([session.answers, session.resolutions, session.rounds, session.sent])).toBe(original)
        session = reduceSession(session, { type: 'confirmOvertime' })
        expect(session.step).toBe('summary')
        expect(parseSession(JSON.stringify(session))?.step).toBe('summary')
        const review = overtimeReview(session)
        if (choice === 'include' || choice === 'exclude') {
          expect(review[choice].find(row => row.code === 'Special Pay')?.origin).toBe('customer')
          expect(review.setupReview.some(row => row.code === 'Special Pay')).toBe(true)
          expect(summaryCsv(session, String)).toContain('Customer-selected treatment')
        } else {
          expect(review.awaiting.some(row => row.code === 'Special Pay')).toBe(true)
        }
      }
    } finally { Object.assign(EARNING_DEMO_SETTINGS, settings) }
  })
  it('keeps unsupported or conflicting current facts from falling back to an unrelated setup rule', () => {
    let session = paymentSession()
    session.resolutions.SPPAY = { status: 'resolved', reference: READY.shift, round: 2 }
    expect(overtimeReview(session).include.some(row => row.code === 'Special Pay')).toBe(false)
    for (const facts of [{}, { bilingualDuties: 'conflict' as const }, { workedWages: 'yes' as const, paidAbsence: 'yes' as const }]) {
      session = checkedFacts(session, 'SPPAY', facts)
      const review = overtimeReview(session)
      expect([...review.include, ...review.exclude].some(row => row.code === 'Special Pay')).toBe(false)
    }
  })
  it('does not turn a generic confirmed benefit label into an exclusion or a completed customer answer', () => {
    const session = actionableOvertimeSession('original')
    session.answers.SPPAY = {}
    session.resolutions.SPPAY = { status: 'resolved', reference: READY.fringeNonCash, round: 2 }
    expect(currentPaymentFacts(session, 'waot:Special Pay')?.mapping).toBeDefined()
    expect(currentPaymentFacts(session, 'waot:Special Pay')?.recommendation).toBeUndefined()
    expect(overtimeReview(session).exclude.some(row => row.code === 'Special Pay')).toBe(false)
    expect(session.overtime.reviewChoices).toBeUndefined()
  })
  it('retains mixed-code gates even when an extraction suggests one component', () => {
    let session = paymentSession()
    session.optimization.answers['split-bonus'] = 'keep'
    const request = paymentRequest(session, 'waot:BONUS')!
    session.paymentReviews = { ...session.paymentReviews, 'waot:BONUS': { basis: request.basis,
      replies: [{ key: 'businessPurpose', state: 'text', text: 'We pay bonuses earned under goals set in advance.' }] } }
    session = checkedFacts(session, 'waot:BONUS', { nondiscretionaryBonus: 'yes' })
    const settings = { ...EARNING_DEMO_SETTINGS }
    try {
      EARNING_DEMO_SETTINGS.ungateForwardButtons = false
      expect(overtimeReview(session).mixed.map(row => row.code)).toContain('BONUS')
      expect(reduceSession(session, { type: 'setOvertimeReviewChoice', code: 'BONUS', choice: 'include' }).overtime.reviewChoices).toBeUndefined()
      expect(reduceSession(session, { type: 'confirmOvertime' }).step).toBe('overtimeSort')
    } finally { Object.assign(EARNING_DEMO_SETTINGS, settings) }
  })
  it('keeps Not sure and cleared choices open when later evidence supports a suggestion', () => {
    for (const choice of ['unsure', 'unanswered'] as const) {
      let session = reduceSession(paymentSession(), { type: 'setOvertimeReviewChoice', code: 'Special Pay', choice })
      session = checkedFacts(session, 'SPPAY', { bilingualDuties: 'yes' })
      const review = overtimeReview(session)
      expect(review.awaiting.some(row => row.code === 'Special Pay')).toBe(true)
      expect(review.include.some(row => row.code === 'Special Pay')).toBe(false)
      expect(parseSession(JSON.stringify(session))?.overtime.reviewChoices?.['Special Pay'].choice).toBe(choice)
    }
  })
  it('keeps applied history frozen and summary actions free of supplemental-only destinations', () => {
    const session = checkedFacts(paymentSession(), 'SPPAY')
    const applied = { ...session, appliedReview: { round: 1, cursor: 0 } }
    const request = paymentRequest(applied, 'SPPAY')!
    expect(reduceSession(applied, { type: 'setPaymentFacts', itemId: 'SPPAY', basis: request.checkBasis, result: { facts: [] } }).paymentReviews)
      .toEqual(session.paymentReviews)
    const html = renderToStaticMarkup(<MemoryRouter><SessionContext.Provider value={{ session, dispatch() {}, save: () => true, restart: () => true }}>
      <StepOvertimeSort /><AwaitingOvertimeReview />
    </SessionContext.Provider></MemoryRouter>)
    expect(html).not.toMatch(/Review payment facts|Review payment answers|Continue to recommendations|A few details about these payments/)
    expect(summaryCsv(session, String)).not.toContain('Does this extra pay compensate')
  })
})
