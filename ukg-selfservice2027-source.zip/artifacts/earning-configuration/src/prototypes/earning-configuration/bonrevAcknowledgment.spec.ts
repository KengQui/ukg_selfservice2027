import { describe, expect, it } from 'vitest'
import { createSession, parseSession, reduceSession, type EarningSession } from './session'
import { ASK_CUSTOMER, CLEAR_CHOICE, READY, findItem } from './sampleRegister'
import { finalConfiguration } from './configuration'
import { sessionCodeStatus } from './sessionCodeStatus'
import { readinessItemStatus } from './readinessSummary'
import { SAMPLE_REGISTER_FILES } from './sampleDocument'

const initial = (): EarningSession => ({
  ...createSession(1), step: 'questions', scenario: 'usability', registerSource: 'sample',
  files: SAMPLE_REGISTER_FILES.map(file => ({ ...file })),
  rounds: [{ number: 1, itemIds: ['BONREV', 'OT ENG', 'OT MFG', 'MILEAGE'], submitted: false }],
})
const choose = (session: EarningSession, choice: string) =>
  reduceSession(session, { type: 'choose', itemId: 'BONREV', choice }, 1000)
const setup = (session: EarningSession) => finalConfiguration(session).find(row => row.code === 'BONREV')

describe('BONREV acknowledgment applies immediately', () => {
  it('confirms the deduction without applying unrelated unfinished answers', () => {
    const session = choose(initial(), 'accept')
    expect(session.answers.BONREV?.choice).toBe('accept')
    expect(session.rounds[0].submitted).toBe(false)
    expect(session.answers['OT ENG']).toBeUndefined()
    expect(setup(session)).toMatchObject({ status: 'ready', reference: READY.bonusReversal })
    expect(readinessItemStatus(session, findItem('BONREV'))).toBe('Ready for setup')
    const row = sessionCodeStatus(session).rows.find(row => row.code === 'BONREV')!
    expect(row.status).toBe('ready')
    expect(row.reference).toBe(READY.bonusReversal.name)
    expect(row.details.join(' ')).not.toContain('not yet applied')
  })

  it('withdraws the immediate confirmation when acknowledgment is cleared or deferred', () => {
    const accepted = choose(initial(), 'accept')
    for (const choice of [CLEAR_CHOICE, ASK_CUSTOMER]) {
      const session = choose(accepted, choice)
      expect(setup(session)?.status).not.toBe('ready')
      expect(setup(session)?.reference).toBeUndefined()
    }
    expect(setup(initial())?.status).not.toBe('ready')
  })

  it('retains the confirmation after restoring saved answers', () => {
    const accepted = choose(initial(), 'accept')
    const restored = parseSession(JSON.stringify(accepted))
    expect(restored).not.toBeNull()
    expect(setup(restored!)).toMatchObject({ status: 'ready', reference: READY.bonusReversal })
    expect(sessionCodeStatus(restored!).rows.find(row => row.code === 'BONREV')?.status).toBe('ready')
  })
})
