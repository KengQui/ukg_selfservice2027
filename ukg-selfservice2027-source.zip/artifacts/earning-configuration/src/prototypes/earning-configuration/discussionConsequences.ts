import { findItem } from './sampleRegister'
import type { Resolution } from './session'

/** Receipt data only: never recompute historical effects from today's answers or rules. */
export function appliedConsequence(id: string, result: Resolution) {
  const code = findItem(id).code
  switch (result.status) {
    case 'recommended': return `Saved the recommendation for ${code}. No payroll setup changes have been made.`
    case 'removed': return `${code} was removed from this setup. Earlier payroll activity is unchanged.`
    case 'customer': return `${code} still has a deferred question. It is not resolved.`
    case 'review': return result.customName
      ? `Accepted ${result.customName.name} for the described payment purpose. No Ready reference, tax treatment or overtime rule was confirmed.`
      : `Kept the supplied details for ${code}. A setup specialist still needs to review its setup.`
    case 'resolved': return result.outputs
      ? `Split ${code} into ${result.outputs.map(output => `${output.code} — ${output.reference.name}`).join(' and ')} in this setup.`
      : result.combinedInto ? `Confirmed ${result.reference.name} and combined ${code} into ${result.combinedInto} in this setup.`
        : `Confirmed ${result.reference.name} for ${code} in this setup.`
  }
}
