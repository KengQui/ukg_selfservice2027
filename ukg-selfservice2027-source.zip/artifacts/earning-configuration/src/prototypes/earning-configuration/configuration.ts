/**
 * The confirmed configuration: every code's final classification once classification and
 * optimization decisions are applied. Pure, so the summary, the overtime sorting and the CSV agree.
 */
import { ASK_CUSTOMER, EARNING_CODES, EARNING_FINDINGS, EARNING_INITIAL_ITEMS, LEGACY_MATCHED_OVERTIME, LEGACY_SHIFT_CODE, READY, codesAddedBy, findCode, findItem, relatedNoteText, type FindingItem, type PayCode, type ReadyReference, type ReviewItemType } from './sampleRegister'
import { OPTIMIZATIONS, appliedOptimization, optimizationAnswered, optimizationDecisionLocked, optimizationNote, type OptimizationSuggestion } from './optimization'
import { SOMETHING_ELSE } from './somethingElse'
import { cellFactsText } from './cellFlow'
import { reimbursementAnswer } from './reimbursements'
import { MIXED_EARNINGS, mixedQuestion } from './overtime'
import { decisionFor, type EarningSession } from './session'
import { MILEAGE_ID, mileageAnswerText } from './mileage'
import { TIPS_ID, tipsAnswerText } from './tips'
import { hasTipsOwedReview, hasPurposeHistory, knownLeaveReference, sourceItemId } from './questionApplicability'
import { isTipsCode } from './tipsIdentity'
import { medicalDisplayText, medicalEmployerCode, acceptedMedicalProposal } from './medical'
import { GTL_ID, LEGACY_GTL_PRACTICE_ID, LEGACY_GTL_CALCULATION_ID, gtlDiscovery, historicalGtlNote } from './gtlQuestions'
import { hiddenDemoCodes } from './optionalDemoQuestions'
import { consolidateRegisters } from './registerEvidence'
import { activeGtlAnswer, identifiedGtl, sampleGtlEvidence, uploadedGtlId } from './gtlEvidence'
import { assessGtlEvidence } from './gtlPurposeEvidence'
import { isSampleRegisterFile } from './sampleDocument'
import { USABILITY_PAY_CODES, USABILITY_ITEMS } from './sampleRegister'

/**
 * ready: set up in Ready · customer: classification waiting on the customer · review: a proposed custom name the team
 * accepted, or a described answer such as CELL's Something else, with no Ready reference, so setup awaits review · notSetUp: left out by an optimization decision.
 */
export type RowStatus = 'ready' | 'customer' | 'review' | 'notSetUp' | 'combined' | 'pending'

export interface ConfigRow {
  code: string
  /** Pay register description, the team's description for codes without one, or the added code's name. */
  description: string
  /** The Ready code it is set up as; undefined while the classification is waiting on the customer. */
  reference?: ReadyReference
  status: RowStatus
  /** A proposed custom name (AI suggestion the team accepted); never a Ready reference or classification. */
  customName?: string
  /** Audit row only: no independent setup or overtime placement. */
  combinedInto?: string
  relatedNote?: string
  notes: string[]
  /** The optimization suggestion about this code that the team sent to the customer. */
  openSuggestion?: string
  /** The customer's report already matched this code to its Ready setup, before any team answer. */
  matchedInReport?: true
  /** Discovery inclusion is independent of setup readiness. */
  inclusion?: 'include' | 'exclude' | 'unresolved'
  discoveryStatus?: 'Complete' | 'Needs review'
  gtlDiscovery?: ReturnType<typeof gtlDiscovery>
  sourceId?: string
  companyKey?: string
}

const RESOLVED_NOTES: Record<ReviewItemType, string> = {
  misclassification: 'Reclassified by your team',
  clarification: 'Clarified by your team',
  unidentified: 'Identified by your team',
  finding: 'Added by your team',
}

/**
 * The Ready setup an overtime code kept from the earlier analysis: progress that applied its review before the code was
 * asked its rate (no round ever included it) keeps the general Overtime match instead of waiting on an answer.
 */
export function legacyOvertimeMatch(session: Pick<EarningSession, 'rounds'>, code: string): ReadyReference | undefined {
  const itemId = EARNING_INITIAL_ITEMS.find(item => item.code === code)?.id ?? code
  const reference = LEGACY_MATCHED_OVERTIME[itemId]
  if (!reference || !session.rounds.length || session.rounds.some(round => round.itemIds.includes(itemId))) return undefined
  return reference
}

/** Leave purposes added later do not reopen a previously applied review. */
export function legacyLeaveMatch(session: Partial<EarningSession> | undefined, code: string): ReadyReference | undefined {
  return knownLeaveReference(findCode(code), session)
}

/** Starting matches only, not answers later applied to review questions. */
export function startingMatchedCodes(session?: Partial<EarningSession>): PayCode[] {
  return sessionEarningCodes(session).flatMap(code => {
    const reference = code.status === 'matched' ? code.reference
      : legacyLeaveMatch(session, code.code) ?? (session?.rounds ? legacyOvertimeMatch({ rounds: session.rounds }, code.code) : undefined)
    return reference ? [{ ...code, reference }] : []
  })
}

/** Matched source rows have no per-code resolution. Keep their register revision, not an inferred answer history. */
export function sessionEarningCodes(session?: Partial<EarningSession>): PayCode[] {
  if (session?.scenario === 'usability') return USABILITY_PAY_CODES
  const codes = EARNING_CODES.filter(code => code.code !== 'TIPS OWED'
    || hasTipsOwedReview(session))
  return session?.sampleRegisterVersion === 1 && !EARNING_CODES.some(code => code.code === 'SHIFT2')
    ? [...codes, LEGACY_SHIFT_CODE] : codes
}

/**
 * Whether a combine suggestion can join its codes: only when every code has a confirmed Ready setup and they all share
 * it, so the combined code keeps that setup (for overtime, the confirmed rate). Codes with different setups, or still
 * waiting on an answer, stay separate.
 */
export type CombineCheck =
  | { ok: true; reference: ReadyReference }
  | { ok: false; reason: 'different' | 'waiting' }

/** A saved explicit rate is confirmation; it does not wait for unrelated questions. */
export function savedOvertimeReference(session: EarningSession, code: string): ReadyReference | undefined {
  const item = [...EARNING_INITIAL_ITEMS, ...USABILITY_ITEMS].find(item => item.code === code)
  if (!item || item.type !== 'clarification') return undefined
  const decision = decisionFor(item, session.answers[item.id])
  const resolution = session.resolutions[item.id]
  if (decision?.kind !== 'resolve' || resolution && resolution.status !== 'resolved') return undefined
  const reference = decision.reference
  const rates = [READY.overtimePremium, READY.overtimeFull, READY.overtimeDouble, READY.overtimeFlat]
  return reference && rates.some(rate => rate.id === reference.id) ? reference : undefined
}

/** Explicit acknowledgments and rate choices take effect independently of the review batch. */
export function savedSetupReference(session: EarningSession, code: string): ReadyReference | undefined {
  if (code === 'BONREV' && session.answers.BONREV?.choice === 'accept' && !session.answers.BONREV.rollUpType
    && (!session.resolutions.BONREV || session.resolutions.BONREV.status === 'resolved')) {
    return READY.bonusReversal
  }
  return savedOvertimeReference(session, code)
}

/** Explain the same applied source rows used by the combination guard, without inferring a rate. */
export function combinationSourceDetails(session: EarningSession, suggestion: OptimizationSuggestion) {
  return scenarioOptimization(session, suggestion).codes.map(code => {
    const row = registerRow(session, findCode(code)!)
    const item = [...EARNING_INITIAL_ITEMS, ...USABILITY_ITEMS].find(item => item.code === code)
    const answer = item && session.answers[item.id]
    const detail = row.status === 'ready' && row.reference
      ? `Confirmed setup: ${row.reference.name}.`
      : row.status === 'customer' ? 'Waiting for an answer to the clarification question.'
      : row.status === 'review' ? 'This code is waiting for setup review.'
      : row.status === 'combined' ? `Already combined into ${row.combinedInto}.`
      : row.status === 'notSetUp' ? 'This code is not included in the setup.'
      : answer?.choice ? 'An answer is saved, but its setup has not been confirmed.'
      : 'The overtime rate question has not been answered.'
    return { code, detail, notes: row.status === 'review' ? row.notes : [] }
  })
}

export function scenarioOptimization(session: EarningSession, suggestion: OptimizationSuggestion): OptimizationSuggestion {
  if (session.scenario !== 'usability' || suggestion.id !== 'combine-current-overtime') return suggestion
  const names = (text: string) => text.replaceAll('Overtime MFG', 'OT MFG').replaceAll('Overtime ENG', 'OT ENG')
  return { ...suggestion, codes: ['OT MFG', 'OT ENG'], question: names(suggestion.question),
    keep: { ...suggestion.keep, title: names(suggestion.keep.title) },
    customerQuestion: names(suggestion.customerQuestion),
    outcomes: { accept: names(suggestion.outcomes.accept), keep: names(suggestion.outcomes.keep), customer: names(suggestion.outcomes.customer) },
    replacements: suggestion.replacements?.map(replacement => ({ ...replacement, note: names(replacement.note) })) }
}

export function combineCheck(session: EarningSession, suggestion: OptimizationSuggestion): CombineCheck {
  suggestion = scenarioOptimization(session, suggestion)
  const rows = suggestion.codes.map(code => registerRow(session, findCode(code)!))
  // The bundled presentation always offers this decision. Real uploaded reviews
  // retain setup compatibility checks; a demo choice never rewrites source answers.
  const uploaded = session.registerSource === 'uploads' || (session.registerSource !== 'sample'
    && !session.files.some(file => isSampleRegisterFile(file.id))
    && session.files.some(file => !isSampleRegisterFile(file.id)))
  if (suggestion.id === 'combine-current-overtime' && !uploaded && session.scenario !== 'usability') {
    const shared = rows.every(row => row.status === 'ready' && row.reference?.id === rows[0].reference?.id)
    return { ok: true, reference: shared && rows[0].reference ? rows[0].reference : READY.overtime }
  }
  if (rows.some(row => row.status !== 'ready' || !row.reference)) return { ok: false, reason: 'waiting' }
  const [first] = rows
  if (rows.some(row => row.reference!.id !== first.reference!.id)) return { ok: false, reason: 'different' }
  return { ok: true, reference: first.reference! }
}

/** Current actionable questions only. Compatibility uses applied classification, never draft answers. */
export function applicableOptimizations(session: EarningSession, suggestions: readonly OptimizationSuggestion[] = OPTIMIZATIONS): OptimizationSuggestion[] {
  if (session.scenario === 'usability') {
    const codes = new Set(sessionEarningCodes(session).map(row => row.code))
    return suggestions.map(suggestion => scenarioOptimization(session, suggestion))
      .filter(suggestion => suggestion.codes.every(code => codes.has(code))
        && (suggestion.kind !== 'combine' || combineCheck(session, suggestion).ok))
  }
  return suggestions.filter(suggestion => suggestion.id !== 'inactive-COVIDSP' && (suggestion.kind !== 'combine' || combineCheck(session, suggestion).ok))
}

/** Keep completed decisions readable without presenting an ineligible combination as work still to do. */
export function optimizationDecisionSuggestions(session: EarningSession): OptimizationSuggestion[] {
  const active = new Set(applicableOptimizations(session).map(suggestion => suggestion.id))
  return OPTIMIZATIONS.map(suggestion => scenarioOptimization(session, suggestion)).filter(suggestion => active.has(suggestion.id)
    || (session.optimization.completed && optimizationDecisionLocked(session.optimization, suggestion.id)
      && optimizationAnswered(session.optimization, suggestion.id)))
}

/** Completion of an earlier set of questions cannot finish a newly eligible question. */
export function optimizationComplete(session: EarningSession): boolean {
  return session.optimization.completed && applicableOptimizations(session).every(suggestion =>
    optimizationDecisionLocked(session.optimization, suggestion.id))
}

/** Why a combine suggestion can't be accepted right now, in the team's words; undefined when it can. */
export function combineBlockedReason(session: EarningSession, suggestion: OptimizationSuggestion): string | undefined {
  if (suggestion.kind !== 'combine') return undefined
  const check = combineCheck(session, suggestion)
  if (check.ok) return undefined
  const codes = suggestion.codes.join(' and ')
  return check.reason === 'different'
    ? `${codes} have different setups, such as different overtime rates, so they can’t be combined into one code.`
    : `${codes} can’t be combined until every one of them has a confirmed setup, such as its overtime rate.`
}

function registerRow(session: EarningSession, payCode: PayCode): ConfigRow {
  const description = payCode.description || session.answers[payCode.code]?.description?.trim() || ''
  const savedReference = savedSetupReference(session, payCode.code)
  if (savedReference) return { code: payCode.code, description, reference: savedReference, status: 'ready', notes: [] }
  if (payCode.code === 'GTL' && session.rounds.some(round => round.itemIds.includes(GTL_ID))) {
    const answer = session.answers[GTL_ID]
    const savedResolution = session.resolutions[GTL_ID]
    const historical = session.rounds.some(round => round.submitted && round.itemIds.includes(GTL_ID))
      && !!historicalGtlNote(answer?.conditionalReview)
      && savedResolution?.status === 'review' && historicalGtlNote(answer?.conditionalReview) === savedResolution.note
    const discovery = gtlDiscovery(answer?.conditionalReview, answer?.choice === ASK_CUSTOMER, sampleGtlEvidence(session.files), historical)
    return { code: payCode.code, description, status: discovery.outcome === 'exclude' ? 'notSetUp' : 'review',
      inclusion: discovery.outcome, discoveryStatus: discovery.status, gtlDiscovery: discovery, notes: [discovery.summary] }
  }
  if (payCode.status === 'matched') return { code: payCode.code, description, reference: payCode.reference, status: 'ready', notes: [], matchedInReport: true }
  const legacy = legacyLeaveMatch(session, payCode.code) ?? legacyOvertimeMatch(session, payCode.code)
  if (legacy) return { code: payCode.code, description, reference: legacy, status: 'ready', notes: [] }
  const item = [...EARNING_INITIAL_ITEMS, ...USABILITY_ITEMS].find(candidate => candidate.code === payCode.code)
  const resolution = item && (session.resolutions[item.id]
    ?? (payCode.code === 'CELL' ? session.legacyCell?.resolution : undefined)
    // A completed earlier review keeps its actual setup, never an invented calculation-method answer.
    ?? (payCode.code === 'GTL' && !session.rounds.some(round => round.itemIds.includes(GTL_ID))
      && session.rounds.some(round => round.submitted && round.itemIds.some(id => [LEGACY_GTL_PRACTICE_ID, LEGACY_GTL_CALCULATION_ID].includes(id)))
      ? session.resolutions[LEGACY_GTL_PRACTICE_ID] ?? session.resolutions[LEGACY_GTL_CALCULATION_ID] : undefined))
  const tipsNote = item && isTipsCode(item.id) ? tipsAnswerText(session.answers[item.id]) : undefined
  const tipsNotes = tipsNote ? [tipsNote] : []
  if (resolution?.status === 'recommended') return {
    code: payCode.code, description, status: 'notSetUp',
    notes: ['Recommendation complete. No payroll setup changes have been made.'],
  }
  if (item && resolution?.status === 'resolved') {
    return { code: payCode.code, description, reference: resolution.reference,
      status: resolution.combinedInto ? 'combined' : 'ready',
      ...(resolution.combinedInto ? { combinedInto: resolution.combinedInto } : {}),
      ...(resolution.relatedNote ? { relatedNote: resolution.relatedNote } : {}),
      notes: [RESOLVED_NOTES[item.type],
        ...(resolution.combinedInto ? [`Combined into ${resolution.combinedInto} · Set up as ${resolution.reference.name}`] : []),
        ...(resolution.relatedNote ? [`Set up as ${resolution.reference.name} · ${relatedNoteText(resolution.reference.id, payCode.code, resolution.relatedNote)}`] : []),
        // MILEAGE names the pick and, when the company pays per mile, the rate and how it compares with the IRS rate.
        ...(item.id === MILEAGE_ID ? [mileageAnswerText(session.answers[item.id])].filter((note): note is string => !!note) : []),
        ...(payCode.code === 'CELL' && session.answers['CELL-purpose']?.cell ? [cellFactsText(session.answers['CELL-purpose'])] : []),
        ...tipsNotes] }
  }
  if (item && resolution?.status === 'review') {
    // A described answer (Something else, MED's No) names no Ready setup; the description goes to the team's review.
    if (resolution.note) return {
      code: payCode.code, description, status: 'review',
      notes: [describedNote(resolution), 'Setup awaiting your team’s review',
        // Older applied pool/multiple answers retain their original note without a newly invented unanswered step.
        ...(session.answers[item.id]?.somethingElse ? tipsNotes : [])],
    }
    return {
      code: payCode.code, description, status: 'review', customName: resolution.customName?.name,
      notes: ['Payment purpose and custom name confirmed; no Ready reference selected', 'Tax treatment and combine compatibility still need their own review; a custom name alone does not establish overtime treatment'],
    }
  }
  if (item && resolution?.status === 'removed') {
    return { code: payCode.code, description, status: 'notSetUp', notes: ['You chose to leave this code out of setup'] }
  }
  const payment = item ? reimbursementAnswer(item, session.answers[item.id]) : undefined
  const cellNotes = payment ? [cellFactsText(payment)] : payCode.code === 'CELL' && session.answers['CELL-purpose']?.cell
    ? [cellFactsText(session.answers['CELL-purpose']), 'CELL tax setup is not complete. Confirm remaining decisions before final setup.'] : []
  return resolution?.status === 'customer'
    ? { code: payCode.code, description, status: 'customer', notes: ['Classification waiting on the customer', ...tipsNotes, ...cellNotes] }
    : { code: payCode.code, description, status: 'pending', notes: ['Needs an answer or review action; no setup decision applied', ...tipsNotes, ...cellNotes] }
}

/** Confirmed classification outputs, before optimization, excluding added finding codes. */
export function classificationReadyCount(session: EarningSession): number {
  return sessionEarningCodes(session).reduce((count, payCode) => {
    if (payCode.status === 'matched' || legacyLeaveMatch(session, payCode.code) || legacyOvertimeMatch(session, payCode.code)) return count + 1
    const item = [...EARNING_INITIAL_ITEMS, ...USABILITY_ITEMS].find(candidate => candidate.code === payCode.code)
    const resolution = item && (session.resolutions[item.id]
      ?? (payCode.code === 'CELL' ? session.legacyCell?.resolution : undefined))
    const related = item && session.rounds.flatMap(round => round.itemIds).filter(id => id !== item.id && sourceItemId(id) === item.id)
    if (related?.some(id => !session.resolutions[id] || ['customer', 'review'].includes(session.resolutions[id].status))) return count
    return count + (resolution?.status === 'resolved' && !resolution.combinedInto ? 1 : 0)
  }, 0)
}

/**
 * The setup team's note for a described answer. Something else names the question it answered, then the description;
 * MED's No and CELL's purpose description keep their earlier wording.
 */
export function describedNote(resolution: { note?: string; question?: string }): string {
  return resolution.question ? `${resolution.question} Something else: ${resolution.note}` : `Described as: ${resolution.note}`
}

export function finalConfiguration(session: EarningSession): ConfigRow[] {
  if (session.registerSource === 'uploads') return consolidateRegisters(session.files).map(source => {
    const answer = activeGtlAnswer(session.answers[uploadedGtlId(source)], source)
    const discovery = identifiedGtl(source) ? gtlDiscovery(answer?.conditionalReview, answer?.choice === ASK_CUSTOMER, assessGtlEvidence(source)) : undefined
    return { sourceId: source.id, companyKey: source.companyKey, code: source.code, description: source.description,
      status: discovery?.outcome === 'exclude' ? 'notSetUp' : 'review',
      ...(discovery ? { inclusion: discovery.outcome, discoveryStatus: discovery.status, gtlDiscovery: discovery } : {}),
      notes: discovery ? [discovery.summary] : ['Needs review before setup can be confirmed.'] }
  })
  // Carry explicit combination/removal decisions without promoting other unfinished answers.
  // Combination compatibility is still checked below against the current confirmed setups.
  const unfinished = !optimizationComplete(session) && ['overtime', 'overtimeAssessment', 'overtimeSort', 'summary'].includes(session.step)
  const sorted = new Set(session.optimization.changedWhileSorting ?? [])
  const answers = (unfinished ? appliedOptimization(session.optimization) : session.optimization).answers
  const rows: ConfigRow[] = []
  const replaced = new Set<string>()
  for (const payCode of sessionEarningCodes(session)) {
    // Standard company medical cost belongs to the deduction below, not an independent output.
    if (payCode.code === 'MED ER' && session.answers['MED ER']?.choice === 'only-records'
      && session.resolutions['MED ER']?.status === 'resolved') continue
    // A historical applied review does not acquire the new source question.
    if (payCode.code === 'MED ER' && session.rounds.some(round => round.submitted)
      && !session.rounds.some(round => round.itemIds.includes('MED ER'))) continue
    // A completed historical review used an earlier sample. Its output must not
    // acquire an unanswered scenario that was never part of any of its rounds.
    if (payCode.code === findItem('SPPAY').code && session.rounds.length
      && !session.rounds.some(round => round.itemIds.includes('SPPAY'))) continue
    if (payCode.code === 'CELL') {
      const resolution = session.resolutions['CELL-purpose'] ?? session.legacyCell?.resolution
      if (resolution?.status === 'resolved' && resolution.outputs) {
        rows.push(...resolution.outputs.map(output => ({
          code: output.code, description: output.reference.name, reference: output.reference,
          status: 'ready' as const,
          notes: ['Split from source CELL', 'Payment purpose and tax treatment confirmed'],
        })))
        continue
      }
    }
    const suggestion = OPTIMIZATIONS.map(candidate => scenarioOptimization(session, candidate)).find(candidate => candidate.codes.includes(payCode.code))
    const eligible = !suggestion || suggestion.kind !== 'combine' || combineCheck(session, suggestion).ok
    const choice = suggestion && eligible ? answers[suggestion.id] : undefined
    // Preserve the earlier accepted decision in history, but never apply an unsupported combination.
    if (suggestion && !eligible && answers[suggestion.id] === 'accept' && session.optimization.completed) {
      const row = registerRow(session, payCode)
      rows.push({ ...row, notes: [...row.notes, combineBlockedReason(session, suggestion)!] })
      continue
    }
    const combine = suggestion?.kind === 'combine' && choice === 'accept' ? combineCheck(session, suggestion) : undefined
    if (combine && !combine.ok) {
      // An accepted combine whose codes now have different or unconfirmed setups keeps them apart.
      const row = registerRow(session, payCode)
      rows.push({ ...row, notes: [...row.notes, combineBlockedReason(session, suggestion!)!] })
      continue
    }
    if (suggestion?.replacements && choice === 'accept') {
      if (!replaced.has(suggestion.id)) {
        replaced.add(suggestion.id)
        rows.push(...suggestion.replacements.map(replacement => {
          // A combined code keeps the setup its codes share, such as their confirmed overtime rate.
          const reference = combine?.ok ? combine.reference : replacement.reference
          return {
            code: replacement.code, description: replacement.description, reference,
            status: 'ready' as const,
            notes: [replacement.note, ...(reference.id !== replacement.reference.id ? [`Set up as ${reference.name}`] : [])],
          }
        }))
      }
      continue
    }
    const row = registerRow(session, payCode)
    if (suggestion && choice === SOMETHING_ELSE) {
      // Something else: the suggestion isn't applied or kept. Once Done, the codes stay as they are and wait for review.
      const note = optimizationNote(session.optimization, suggestion.id)
      if (!note) { rows.push(row); continue }
      const mixedCode = Object.keys(MIXED_EARNINGS).find(code => MIXED_EARNINGS[code].suggestionId === suggestion.id)
      const question = mixedCode && session.optimization.changedWhileSorting?.includes(suggestion.id) ? mixedQuestion(mixedCode) : suggestion.question
      rows.push({ ...row, status: row.status === 'ready' ? 'review' : row.status,
        notes: [...row.notes, describedNote({ question, note }), 'Setup awaiting your team’s review'] })
      continue
    }
    if (suggestion?.kind === 'inactive') {
      if (suggestion.id === 'inactive-COVIDSP') {
        rows.push({ ...row, status: choice === 'accept' ? 'notSetUp' : 'review',
          notes: [...row.notes, choice === 'accept' ? suggestion.outcomes.accept
            : choice === 'keep' ? suggestion.outcomes.keep : suggestion.outcomes.customer] })
        continue
      }
      if (choice === 'accept') rows.push({ ...row, status: 'notSetUp', notes: [...row.notes, 'Left out: no activity in the last 12 months'] })
      else if (choice === ASK_CUSTOMER) rows.push({ ...row, openSuggestion: suggestion.id, notes: [...row.notes, 'No activity in the last 12 months; the customer will confirm whether it’s needed'] })
      else rows.push({ ...row, notes: [...row.notes, 'No activity in the last 12 months; kept'] })
      continue
    }
    if (suggestion && choice === ASK_CUSTOMER) rows.push({ ...row, openSuggestion: suggestion.id, notes: [...row.notes, suggestion.outcomes.customer] })
    else rows.push(row)
  }
  for (const finding of EARNING_FINDINGS) {
    const resolution = session.resolutions[finding.id]
    if (!resolution) continue
    const raisedBy = `Raised by your answer for ${finding.raisedBy}`
    rows.push(resolution.status === 'resolved'
      ? { code: finding.code, description: resolution.reference.name, reference: resolution.reference, status: 'ready', notes: [raisedBy] }
      // Something else on a finding: the code isn't added, and the description goes to the team's review.
      : resolution.status === 'review' && resolution.note
        ? { code: finding.code, description: finding.options[0].resolution.name, status: 'review',
          notes: [raisedBy, `Not added. ${describedNote(resolution)}`, 'Setup awaiting your team’s review'] }
        : { code: finding.code, description: finding.options[0].resolution.name, status: 'customer', notes: [raisedBy, 'Waiting on the customer'] })
  }
  const pendingCodes = new Set(unfinished ? applicableOptimizations(session).filter(suggestion =>
    !sorted.has(suggestion.id) && (!session.optimization.completed
      || !optimizationDecisionLocked(session.optimization, suggestion.id))).flatMap(suggestion => suggestion.codes) : [])
  return rows.map(row => pendingCodes.has(row.code) && row.status === 'ready'
    ? { ...row, status: 'pending' as const, notes: [...row.notes, 'Optimization is not complete. Return to optimization to finish these decisions.'] } : row)
}

/** Summary presentation only: hidden demo work remains in the underlying configuration and history. */
export function summaryConfiguration(session: EarningSession): ConfigRow[] {
  const hidden = hiddenDemoCodes(session)
  return finalConfiguration(session).filter(row => !hidden.has(row.code))
}

export function configurationCounts(rows: readonly ConfigRow[]) {
  return {
    ready: rows.filter(row => row.status === 'ready').length,
    customer: rows.filter(row => row.status === 'customer').length,
    review: rows.filter(row => row.status === 'review').length,
    notSetUp: rows.filter(row => row.status === 'notSetUp').length,
  }
}

export interface PlanSummary {
  code: string
  name: string
  whoPays: string
  kept: string[]
  added: string[]
  waiting: string[]
}

/** Plan decisions stay separate from earnings rows. A shared cost lists the employer code it sets up next to the plan code. */
export function planConfiguration(session: EarningSession): PlanSummary[] {
  // The MED question is retired, but MED ER's confirmed employer portion still belongs in the summary.
  return [findItem('MED')].map(item => {
    const answer = session.answers[item.id]
    const original = session.resolutions[item.id]
    const employer = session.answers['MED ER'] ?? {}
    const employerResolution = session.resolutions['MED ER']
    const attached = employer.choice === 'only-records' && employerResolution?.status === 'resolved'
      ? medicalEmployerCode(employer) : undefined
    const proposal = acceptedMedicalProposal(answer ?? {})
    const whoPays = attached ? employer.medicalTarget?.code === null ? 'Company only' : 'Company contribution confirmed'
      : original?.status === 'customer' ? 'Waiting on the customer'
      : original?.status === 'resolved' ? answer?.choice === 'employee' ? 'Employees; company setup not confirmed'
          : proposal?.employeeMedicalCode ? `People pay under ${proposal.employeeMedicalCode}` : 'No employee medical deduction'
      : 'Not answered'
    const kept = original?.status === 'resolved'
      ? [`${item.code} — ${original.reference.name}`]
      : attached === 'MED' ? [`MED — ${READY.medical.name}`] : []
    if (attached && attached !== 'MED') kept.push(`${attached} — Medical deduction`)
    const added = attached ? [`Employer portion of ${attached}`,
      `Show on pay statements: ${medicalDisplayText(employer)}`,
      `Show Employer Amount: ${medicalDisplayText(employer)}`] : []
    const waiting = [
      ...(!attached ? [`Company portion not confirmed · Show on pay statements: ${medicalDisplayText(employer)}`] : []),
    ]
    return { code: item.code, name: 'Medical',
      whoPays, kept, added, waiting }
  })
}
