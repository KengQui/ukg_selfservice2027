import { InlineDiscussionCard } from './inlineDiscussionPresentation'
import { ItemQuestion } from './StepQuestions'
import { findItem } from './sampleRegister'
import { discussionContext } from './discussionContext'
import { callEvidence } from './cheatSheetAnswers'
import { useEarningSession } from './sessionContext'
import { setupReviewQuestion } from './setupReview'
import type { EarningSession } from './session'
import { DiscussionLockedQuestions } from './QuestionCard'

/** Mount the owning process once, with settled facts read-only, inside the isolated transaction. */
export default function DiscussionProposalQuestion({ original, id, label, inline = false }: { original: EarningSession; id: string; label: string; inline?: boolean }) {
  const { session } = useEarningSession()
  const item = findItem(id)
  const answer = session.answers[id] ?? {}
  const setup = original.discussionPreview?.setupItems?.includes(id)
  const opening = setup ? setupReviewQuestion(original, id) : original.answers[id]?.explicitDeferral?.question
  const earlier = discussionContext(item, original.answers[id] ?? {}, original.resolutions[id], '').earlier
    .filter(entry => entry.question !== opening)
  // Captured discussion replies aren't editable here. Their new follow-ups and confirmations are.
  const captured = setup ? [] : callEvidence(item, answer).answers
    .filter(entry => entry.question === opening || entry.question === item.question && !!answer.descriptionSubmitted)
  const locked = Object.fromEntries([...earlier, ...captured].map(entry => [entry.question, entry.answer]))
  for (const entry of original.answers[id]?.cell?.entries ?? []) locked[entry.question] = entry.answer
  for (const entry of original.answers[id]?.checkAnswers ?? []) locked[entry.question] = entry.answer
  if (!setup) {
    for (const entry of answer.checkAnswers ?? []) if (entry.question === opening) locked[entry.question] = entry.answer
    for (const entry of answer.cell?.entries ?? []) if (entry.question === opening) locked[entry.question] = entry.answer
  }
  return <InlineDiscussionCard.Provider value={inline}><DiscussionLockedQuestions.Provider value={locked}>
    <ItemQuestion item={item} label={label} answer={answer} hideRelated />
  </DiscussionLockedQuestions.Provider></InlineDiscussionCard.Provider>
}
