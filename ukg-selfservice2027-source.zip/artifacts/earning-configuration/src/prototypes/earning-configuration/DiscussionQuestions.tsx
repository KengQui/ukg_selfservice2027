import { useId } from 'react'
import Radio from '@ready/dls/components/Radio/Radio'
import Checkbox from '@ready/dls/components/Checkbox/Checkbox'
import TextArea from '@ready/dls/components/TextArea/TextArea'
import { Button } from '@ready/dls/compatibility'
import { useEarningSession } from './sessionContext'
import type { DiscussionEdit } from './discussionAnswers'
import { DISCUSSION_OPTIONS, type DiscussionAnswer, type DiscussionKind, type DiscussionOption } from './discussionFormats'
import { DISCUSSION_INPUT_HELP, discussionInputIssue } from './discussionProgress'
import { QuestionSection } from './QuestionCard'

/** Shape returned by deferredReview.discussionEntries; options keep their original business IDs. */
export interface DiscussionEntryView {
  itemId: string
  question: string
  options: DiscussionOption[]
  target?: unknown
  control?: 'checkbox' | 'choices' | 'text'
  answer?: DiscussionAnswer
  key: string
  basis: string
}

function DiscussionQuestion({ entry, index, inline = false }: { entry: DiscussionEntryView; index: number; inline?: boolean }) {
  const { session, dispatch } = useEarningSession()
  const id = useId()
  const { itemId, question, options, basis, answer: saved } = entry
  const kind: DiscussionKind = options.length ? 'review-choices' : 'text'
  const choice = saved?.kind === kind ? saved.choice : undefined
  const selected = options.find(option => option.id === choice)
  const edit = (change: DiscussionEdit['change']) => dispatch({ type: 'setDiscussionAnswer', itemId, question, kind, basis, change })
  const testId = `${itemId}-${index}`
  const issue = discussionInputIssue(entry)
  const feedback = issue === 'details' || issue === 'length' ? DISCUSSION_INPUT_HELP[issue]
    : !issue ? 'Answer entered.' : ''
  const textFeedback = kind === 'text' || selected?.details
  const prepared = inline && session.discussionPreview?.inlineItems?.includes(itemId)
  const prepare = () => dispatch({ type: 'prepareInlineDiscussion', itemId })
  if (prepared) return <QuestionSection question={question} selected={choice ?? saved?.text}
    sequenceStep={{ number: index + 1, state: 'answered',
      summary: [selected?.label, selected?.details ? saved?.details?.[choice!] : '', saved?.text].filter(Boolean).join(' — '),
      onChange: () => {
        if (choice) edit({ choice })
        else edit({ text: saved?.text ?? '' })
      } }} />
  return (
    <div className={inline ? 'ec-qcard__section ec-qcard__sequence-step ec-qcard__sequence-step--current' : undefined}>
      {inline && <span className="ec-qcard__label">Question {String(index + 1).padStart(2, '0')}</span>}
      <p id={`${id}-question`} className={inline ? 'ec-qcard__title' : 'ec-cheat__text ec-discussion__question'}>{question}</p>
      <div className="ec-discussion__response" data-testid={`discussion-answer-${testId}`}
        data-discussion-incomplete={!!issue} role="group" aria-labelledby={`${id}-question`}
        aria-describedby={feedback && !textFeedback ? `${id}-feedback` : undefined}>
        {entry.control === 'checkbox' && options.length === 1 ? (
          <Checkbox id={`${id}-acknowledge`} label={options[0].label} checked={choice === options[0].id}
            onChange={checked => { edit(checked ? { choice: options[0].id } : { clear: true }); if (inline && checked) prepare() }} />
        ) : options.length > 0 && (
          <div className="ec-discussion__options" role="radiogroup" aria-labelledby={`${id}-question`} aria-describedby={feedback && !textFeedback ? `${id}-feedback` : undefined}>
            {options.map((option, optionIndex) => (
              <div key={option.id} data-testid={`choice-discussion-${testId}-${option.id}`}>
                <Radio id={`${id}-option-${optionIndex}`} name={id} value={option.id} label={option.label}
                  checked={choice === option.id} onChange={value => {
                    edit({ choice: value })
                    if (inline && !option.details) prepare()
                  }} />
              </div>
            ))}
          </div>
        )}
        {selected?.details && (
          <TextArea id={`${id}-details`} label="Add details" rows={2}
            value={saved?.details?.[choice!] ?? ''} onChange={detail => edit({ detail, choice: choice! })}
            helperText={feedback} />
        )}
        {kind === 'text' && (
          <TextArea id={`${id}-answer`} label="Answer" placeholder="Add an answer" rows={2} value={saved?.text ?? ''}
            onChange={text => edit({ text })} helperText={issue !== 'length' ? feedback : undefined}
            errorText={issue === 'length' ? feedback : undefined} />
        )}
        {inline && (kind === 'text' || selected?.details) && <Button variant="secondary" size="small"
          disabled={!!issue} data-testid={`button-done-discussion-${testId}`} onClick={prepare}>Done</Button>}
        {feedback && !textFeedback && <p id={`${id}-feedback`} className="ec-cheat__empty" data-testid={`feedback-discussion-${testId}`}>{feedback}</p>}
        {choice === 'unsure' && <p className="ec-cheat__empty" role="status">You’re not sure yet. This is kept with your response, but it doesn’t confirm a business fact.</p>}
        {!inline && (choice || saved?.text) && <Button variant="tertiary" size="small" data-testid={`button-clear-discussion-${testId}`}
          onClick={() => {
            edit({ clear: true })
            document.getElementById(`${id}-${kind === 'text' ? 'answer'
              : entry.control === 'checkbox' && options.length === 1 ? 'acknowledge' : 'option-0'}`)?.focus()
          }}>Clear answer</Button>}
      </div>
    </div>
  )
}

/** Earlier discussion responses for this code that no longer match a current deferred question. Read-only. */
export function EarlierDiscussionAnswers({ itemId, currentKeys }: { itemId: string; currentKeys: string[] }) {
  const { session } = useEarningSession()
  const keys = new Set(currentKeys)
  const earlier = Object.entries(session.discussionAnswers?.[itemId] ?? {})
    .filter(([key, answer]) => !keys.has(key) && (answer.choice || answer.text))
  if (!earlier.length) return null
  return (
    <details className="ec-cheat__why ec-discussion__history">
      <summary data-testid={`button-discussion-history-${itemId}`}>Earlier discussion responses ({earlier.length})</summary>
      {earlier.map(([key, answer]) => (
        <div key={key} className="ec-discussion__earlier">
          <p className="ec-cheat__text">{answer.question}</p>
          {answer.choice && <p className="ec-cheat__text">{(answer.options ?? DISCUSSION_OPTIONS[answer.kind]).find(option => option.id === answer.choice)?.label}</p>}
          {answer.choice && answer.details?.[answer.choice] && <p className="ec-cheat__text">{answer.details[answer.choice]}</p>}
          {answer.text && <p className="ec-cheat__text">{answer.text}</p>}
        </div>
      ))}
    </details>
  )
}

/** The exact deferred questions with their original answer controls. */
export default function DiscussionQuestions({ entries, inline = false }: { entries: DiscussionEntryView[]; inline?: boolean }) {
  return (
    <div className="ec-cheat__lines">
      {entries.map((entry, index) => <DiscussionQuestion key={entry.key} entry={entry} index={index} inline={inline} />)}
    </div>
  )
}
