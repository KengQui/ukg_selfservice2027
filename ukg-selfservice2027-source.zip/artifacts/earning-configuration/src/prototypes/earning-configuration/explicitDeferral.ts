import { createContext } from 'react'
import type { SessionAction, ItemAnswer } from './session'
import { customerDraftBasis } from './customerQuestionData'
import type { DiscussionOption } from './discussionFormats'
import { isMileage, isMileageReviewFallback } from './mileageQuestions'
import { MILEAGE_POLICY } from '@workspace/setup-shared/mileage-policy'

/** Captured from the owning control's action, never reconstructed from its label. */
export type DeferredTarget =
  | { kind: 'choice'; stage: 'main' | 'reference' | 'name' }
  | { kind: 'description'; append?: boolean }
  | { kind: 'followUp'; id: string }
  | { kind: 'conditional'; id: string }
  | { kind: 'retention' }
  | { kind: 'check'; question: string }
  | { kind: 'shared'; referenceId: string }
  | { kind: 'shiftReply'; question: string }
  | { kind: 'shiftDecision' }
  | { kind: 'cell'; id: string }
  | { kind: 'tips'; id: string }

export interface DeferredQuestion {
  question: string
  choices: string[]
  options?: DiscussionOption[]
  target?: DeferredTarget
  control?: 'checkbox' | 'choices' | 'text'
}
export interface ExplicitDeferral extends DeferredQuestion { basis: string }
export function validDeferredTarget(value: unknown): value is DeferredTarget {
  if (!value || typeof value !== 'object') return false
  const target = value as Record<string, unknown>
  const text = (key: string) => typeof target[key] === 'string' && !!target[key].trim() && target[key].length <= 2000
  switch (target.kind) {
    case 'choice': return ['main', 'reference', 'name'].includes(String(target.stage))
    case 'description': return target.append === undefined || typeof target.append === 'boolean'
    case 'retention': case 'shiftDecision': return true
    case 'followUp': case 'conditional': case 'cell': case 'tips': return text('id')
    case 'check': case 'shiftReply': return text('question')
    case 'shared': return text('referenceId')
    default: return false
  }
}
export const ExplicitDeferralContext = createContext<{
  itemId: string
  dispatch: (action: SessionAction) => void
} | null>(null)

/** Provenance does not change the answer or the identity of existing AI/sent drafts. */
export function deferralBasis(answer: ItemAnswer = {}) {
  const { explicitDeferral: _selection, ...facts } = answer
  return customerDraftBasis(facts)
}

export function selectedDeferral(answer: ItemAnswer = {}): DeferredQuestion | undefined {
  const selection = answer.explicitDeferral
  if (isMileage(answer) && (isMileageReviewFallback(answer.cell?.deferred)
    || selection?.target?.kind === 'cell' && selection.target.id === `${MILEAGE_POLICY}:review`)) return undefined
  return selection && typeof selection.question === 'string' && !!selection.question.trim()
    && Array.isArray(selection.choices) && selection.choices.every(choice => typeof choice === 'string')
    && (selection.target === undefined || validDeferredTarget(selection.target))
    && (selection.options === undefined || Array.isArray(selection.options) && selection.options.length <= 20
      && selection.options.every(option => typeof option?.id === 'string' && typeof option.label === 'string')
      && new Set(selection.options.map(option => option.id)).size === selection.options.length)
    && selection.basis === deferralBasis(answer) ? selection : undefined
}
