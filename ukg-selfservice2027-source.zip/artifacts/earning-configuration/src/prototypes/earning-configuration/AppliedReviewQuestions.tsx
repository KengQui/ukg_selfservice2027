import { useEffect, useRef } from 'react'
import { Button } from '@ready/dls/compatibility'
import { useEarningSession } from './sessionContext'
import { appliedReviewSession, reviewPages, reviewPosition } from './session'
import { findItem } from './sampleRegister'
import { reviewTopicForPage, sectionReviewPages } from './reviewTopics'
import ReviewStepper from './ReviewStepper'
import SavedAppliedQuestion from './SavedAppliedQuestion'
import AppliedAnswerHistory from './AppliedAnswerHistory'
import { hideSkippedDemoQuestion } from './optionalDemoQuestions'
import { ReviewCardPosition } from './ReviewCardCounter'

export default function AppliedReviewQuestions() {
  const { session, dispatch } = useEarningSession()
  const view = appliedReviewSession(session)
  const heading = useRef<HTMLHeadingElement>(null)
  const pages = view ? reviewPages(view) : []
  const displayedPages = pages.map(page => page.filter(id => !hideSkippedDemoQuestion(view!, id)))
  const visiblePages = displayedPages.flatMap((page, index) => page.length ? [index] : [])
  const saved = view ? reviewPosition(view).index : 0
  const index = visiblePages.includes(saved) ? saved : visiblePages.find(page => page > saved) ?? visiblePages.at(-1) ?? 0
  const position = visiblePages.indexOf(index)
  const total = visiblePages.length
  const sectionPages = sectionReviewPages(pages, visiblePages, index)
  useEffect(() => {
    heading.current?.scrollIntoView?.({ block: 'start' })
    heading.current?.focus()
  }, [index])
  if (!view) return null
  const ids = pages[index] ?? []
  const displayedIds = displayedPages[index] ?? []
  const round = view.rounds[0]
  const grouped = round.number === 1 || round.kind === 'added-questions'
  const topic = grouped ? reviewTopicForPage(ids) : undefined
  const go = (to: number) => dispatch({ type: 'moveAppliedReview', index: to })
  const close = () => dispatch({ type: 'closeAppliedReview' })
  const offset = sectionPages.filter(page => page < index).flatMap(page => displayedPages[page]).length
  const sectionTotal = sectionPages.flatMap(page => displayedPages[page]).length
  return <div className="ec-review-layout">
    <ReviewStepper session={view} onGoToPage={go} readOnly visiblePages={visiblePages} currentPage={index} />
    <div className="ec-page ec-page--wide ec-review-main">
      <h1 ref={heading} tabIndex={-1} className="text-display ec-h1 ec-review-category">
        {topic?.title ?? (round.kind === 'added-questions' ? 'Review added questions' : 'Review follow-up questions')}
      </h1>
      <p className="text-body ec-intro">These answers have already been applied. You can look back without changing your setup or progress.</p>
      <AppliedAnswerHistory />
      {displayedIds.map((id, itemIndex) => {
        return <section className="ec-guide-item" data-review-item={id} key={id}>
        <ReviewCardPosition.Provider value={{ current: sectionPages.indexOf(index) + 1, total: sectionPages.length }}>
        <SavedAppliedQuestion item={findItem(id)} session={view} label={`${offset + itemIndex + 1} of ${sectionTotal}`} />
        </ReviewCardPosition.Provider>
      </section>
      })}
      <div className="ec-submit-bar ec-guide-nav ec-guide-nav--in-flow">
        <div className="ec-guide-nav__back">
          {position > 0 && <Button variant="secondary" size="large" onClick={() => go(visiblePages[position - 1])}>Back</Button>}
        </div>
        <div className="ec-submit-bar__primary">
          {position < total - 1 && <Button variant="secondary" size="large" onClick={close}>Return to setup</Button>}
          <Button variant="primary" size="large" onClick={() => position < total - 1 ? go(visiblePages[position + 1]) : close()}>
            {position < total - 1 ? 'Next' : 'Return to setup'}
          </Button>
        </div>
      </div>
    </div>
  </div>
}
