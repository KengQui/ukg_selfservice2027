import { describe, expect, it, vi } from 'vitest'
import { addedCodeRows, addedCodeStatus, addedCodesDecided, reduceAddedCodes, validAddedCodes, type AddedCheckResult, type AddedCodesEvent, type AddedCodesState } from './addedCodes'
import { errorMessage, runAddedCheck } from './addedCodeCheck'
import { createSession, parseSession, reduceSession } from './session'
import { summaryCsv } from './summary'

const ref = { id: 'demo-employee-referral-bonus', name: 'Employee referral bonus', library: 'demo' as const }
it('does not expose unrecognized proxy or server error text', () => {
  expect(errorMessage({ status: 502, data: { error: 'Internal proxy details' } })).toBe('We can’t check this code right now. Try again.')
  expect(errorMessage({ status: 400, data: { code: 'unavailable', error: 'Internal details' } })).toBe('We can’t check this code right now. Try again.')
})
const match: AddedCheckResult = { outcome: 'match', summary: 'A one-time $500 referral payment.', facts: ['$500 per hire', 'Paid once after 90 days'], question: null, reason: 'All known.', reference: ref }
const question: AddedCheckResult = { outcome: 'question', summary: 'A $500 referral payment.', facts: ['$500 per hire'], question: 'Is it paid once or in installments?', reason: 'Timing unclear.', reference: null }
const noMatch: AddedCheckResult = { outcome: 'noMatch', summary: 'A safety committee stipend.', facts: ['Paid monthly'], question: null, reason: 'Nothing fits.', reference: null }

const r = (state: AddedCodesState | undefined, ...events: AddedCodesEvent[]) => events.reduce<AddedCodesState>((s, e) => reduceAddedCodes(s, e), state as AddedCodesState)
const describe1 = (text: string, state?: AddedCodesState) => r(state, { kind: 'start' }, { kind: 'change', field: 'description', value: text }, { kind: 'save' })
const token = (state: AddedCodesState, id = 'added-1') => { const c = state.entries.find(e => e.id === id)!.check!; return c.token }
const answer = (state: AddedCodesState, result: AddedCheckResult, id = 'added-1') => r(state, { kind: 'checkResult', id, token: token(state, id), result })

describe('additional code live check', () => {
  it('keeps a requested change in the reply sequence, persists drafts and rechecks the answer', () => {
    let state = r(answer(describe1('Referral pay'), match), { kind: 'confirm', id: 'added-1', at: 1 })
    state = r(state, { kind: 'requestChange', id: 'added-1' },
      { kind: 'replyChange', id: 'added-1', value: 'It is actually a sign-on bonus for the new hire.' },
      { kind: 'defer', id: 'added-1' })
    expect(state.entries[0].plan).toBeUndefined()
    const saved = parseSession(JSON.stringify({ ...createSession(1), addedCodes: state }))
    expect(saved?.addedCodes?.entries[0]).toMatchObject({
      deferred: true, replyDraft: 'It is actually a sign-on bonus for the new hire.',
    })
    state = r(saved!.addedCodes, { kind: 'resume', id: 'added-1' }, { kind: 'reply', id: 'added-1' })
    expect(state.entries[0].check?.status).toBe('checking')
    expect(state.entries[0].thread?.at(-1)).toEqual({
      question: 'What would you like to change about this earning code?',
      answer: 'It is actually a sign-on bonus for the new hire.',
    })
    expect(state.entries[0].history).toHaveLength(1)
    expect(state.entries[0].plan).toBeUndefined()
  })
  it('starts a check on save with only an intention, no code or name', () => {
    const state = describe1('We pay $500 when a referred person is hired.')
    expect(state.entries[0]).toMatchObject({ code: '', name: '', check: { status: 'checking' } })
    expect(addedCodeStatus(state.entries[0])).toBe('pending')
  })

  it('asks a follow-up, keeps the thread and rechecks after a reply', () => {
    let state = answer(describe1('Referral pay $500'), question)
    state = r(state, { kind: 'replyChange', id: 'added-1', value: 'Once, after 90 days.' })
    expect(validAddedCodes(state)!.entries[0].replyDraft).toBe('Once, after 90 days.')
    state = r(state, { kind: 'reply', id: 'added-1' })
    expect(state.entries[0].thread).toEqual([{ question: question.question, answer: 'Once, after 90 days.' }])
    expect(state.entries[0].check!.status).toBe('checking')
    state = answer(state, match)
    expect(state.entries[0].thread).toHaveLength(1)
    expect(addedCodeStatus(state.entries[0])).toBe('pending')
  })

  it('needs an explicit Yes before the setup plan changes; Review later stays deferred', () => {
    let state = answer(describe1('Referral pay'), match)
    expect(state.entries[0].plan).toBeUndefined()
    state = r(state, { kind: 'defer', id: 'added-1' })
    expect(addedCodeStatus(state.entries[0])).toBe('deferred')
    state = r(state, { kind: 'confirm', id: 'added-1', at: 5 })
    expect(state.entries[0].plan).toMatchObject({ referenceId: ref.id, referenceName: ref.name, description: 'Referral pay', at: 5 })
    expect(state.entries[0]).toMatchObject({ code: 'REFBON', name: 'Referral bonus' })
    expect(addedCodeStatus(state.entries[0])).toBe('plan')
    // A question or no match can never be confirmed.
    expect(r(answer(describe1('x'), noMatch), { kind: 'confirm', id: 'added-1', at: 1 }).entries[0].plan).toBeUndefined()
  })

  it('keeps no-match facts for setup review without inventing a reference', () => {
    const state = answer(describe1('Safety stipend'), noMatch)
    const row = addedCodeRows(state)[0]
    expect(row.status).toBe('No match found · Awaiting setup review')
    expect(row.facts).toEqual(['Paid monthly'])
    expect(row.plan).toBeUndefined()
  })

  it('shows a retry on error and never a result', () => {
    let state = r(describe1('Referral pay'), { kind: 'checkError', id: 'added-1', token: 'x', message: 'nope' })
    expect(state.entries[0].check!.status).toBe('checking')
    state = r(state, { kind: 'checkError', id: 'added-1', token: token(state), message: 'We can’t check this code right now. Try again.' })
    expect(state.entries[0].check).toMatchObject({ status: 'error' })
    state = r(state, { kind: 'check', id: 'added-1' })
    expect(state.entries[0].check!.status).toBe('checking')
  })

  it('drops stale responses after edits, removal and a reused id', () => {
    let state = describe1('Referral pay')
    const first = token(state)
    state = r(state, { kind: 'edit', id: 'added-1' }, { kind: 'change', field: 'description', value: 'Referral pay of $750' }, { kind: 'save' })
    expect(r(state, { kind: 'checkResult', id: 'added-1', token: first, result: match }).entries[0].check!.status).toBe('checking')
    const second = token(state)
    state = describe1('Something else', r(state, { kind: 'remove', id: 'added-1' }))
    expect(state.entries[0].id).toBe('added-1')
    expect(r(state, { kind: 'checkResult', id: 'added-1', token: second, result: match }).entries[0].check!.status).toBe('checking')
  })

  it('a revision invalidates the recommendation and keeps the earlier confirmation as history', () => {
    let state = r(answer(describe1('Referral pay'), match), { kind: 'confirm', id: 'added-1', at: 1 })
    state = r(state, { kind: 'edit', id: 'added-1' }, { kind: 'save' })
    expect(state.entries[0].plan).toBeDefined() // unchanged text keeps the decision
    state = r(state, { kind: 'edit', id: 'added-1' }, { kind: 'change', field: 'description', value: 'Referral pay, two installments' }, { kind: 'save' })
    expect(state.entries[0].plan).toBeUndefined()
    expect(state.entries[0].history).toHaveLength(1)
    expect(state.entries[0].check!.status).toBe('checking')
    expect(state.entries[0].thread).toBeUndefined()
  })

  it('persists results, replies and decisions; a reload restarts an interrupted check', () => {
    let state = r(answer(describe1('Referral pay'), match), { kind: 'confirm', id: 'added-1', at: 1 })
    state = describe1('Second code', state)
    const session = { ...createSession(1), addedCodes: state }
    const restored = parseSession(JSON.stringify(session))!.addedCodes!
    expect(restored.entries[0].plan).toEqual(state.entries[0].plan)
    expect(restored.entries[0].check).toEqual(state.entries[0].check)
    expect(restored.entries[1].check!.status).toBe('checking')
    expect(token(restored, 'added-2')).not.toBe(token(state, 'added-2'))
    // Older entries saved before checks still restore untouched and can be checked.
    const old = validAddedCodes({ entries: [{ id: 'added-1', code: 'BONYR', name: 'Yearly bonus', description: 'Paid each December' }] })!
    expect(old.entries[0]).toEqual({ id: 'added-1', code: 'BONYR', name: 'Yearly bonus', description: 'Paid each December' })
    expect(r(old, { kind: 'check', id: 'added-1' }).entries[0].check!.status).toBe('checking')
  })

  it('leaves the blank form optional and register evidence untouched', () => {
    const session = reduceSession(createSession(1), { type: 'addedCodes', event: { kind: 'start' } }, 2)
    expect(addedCodesDecided(session.addedCodes)).toBe(true)
    expect(session.addedCodes!.none).toBeUndefined()
    const next = reduceSession(session, { type: 'addedCodes', event: { kind: 'save' } }, 3)
    expect(next.files).toEqual(session.files)
    expect(next.answers).toEqual(session.answers)
  })

  it('separates the setup plan from pending items and history in the CSV', () => {
    let state = r(answer(describe1('Referral pay'), match), { kind: 'confirm', id: 'added-1', at: 1 })
    state = answer(describe1('Safety stipend', state), noMatch, 'added-2')
    state = describe1('Holiday gift', state)
    const csv = summaryCsv({ ...createSession(1), addedCodes: state }, () => 'now')
    const lines = csv.split('\r\n').filter(line => line.startsWith('"Added by your team"'))
    expect(lines[0]).toContain('In your setup plan')
    expect(lines[0]).toContain('Earning code: Employee referral bonus')
    expect(csv).not.toMatch(/reference library|demo library/i)
    expect(lines[0]).toContain('not to payroll')
    expect(lines[1]).toContain('No match found')
    expect(lines[2]).toContain('Awaiting setup review')
    expect(csv).not.toMatch(/payroll (was|has been) (changed|updated)/i)
  })
})

describe('runAddedCheck', () => {
  it('sends the intention and thread once and dispatches with the request token', async () => {
    const state = describe1('Referral pay')
    const events: AddedCodesEvent[] = []
    const request = vi.fn().mockResolvedValue(match)
    runAddedCheck(state.entries[0], e => events.push(e), request)
    runAddedCheck(state.entries[0], e => events.push(e), request)
    await vi.waitFor(() => expect(events).toHaveLength(1))
    expect(request).toHaveBeenCalledTimes(1)
    expect(request.mock.calls[0][0]).toEqual({ description: 'Referral pay', thread: [] })
    expect(events[0]).toMatchObject({ kind: 'checkResult', token: token(state) })
  })

  it('turns API failures into an error with the server message, not a result', async () => {
    const state = describe1('Referral pay')
    const events: AddedCodesEvent[] = []
    runAddedCheck(state.entries[0], e => events.push(e), vi.fn().mockRejectedValue({ status: 502, data: { code: 'unavailable', error: 'We can’t check this code right now. Try again.' } }))
    await vi.waitFor(() => expect(events).toHaveLength(1))
    expect(events[0]).toMatchObject({ kind: 'checkError', message: 'We can’t check this code right now. Try again.' })
  })
})
