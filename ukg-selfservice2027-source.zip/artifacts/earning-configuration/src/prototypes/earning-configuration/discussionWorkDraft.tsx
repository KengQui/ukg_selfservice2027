import { createContext, useContext, useState } from 'react'
import { ExplicitDeferralContext } from './explicitDeferral'

export const DiscussionWorkDraftContext = createContext<{
  scope?: string
  values: Record<string, string>
  change: (key: string, value: string) => void
} | null>(null)

/** Unfinished text is workspace data, not a submitted business answer. Other screens retain their existing behavior. */
export function useDiscussionWorkDraft(question: string, field: string, initial = ''): [string, (value: string) => void] {
  const drafts = useContext(DiscussionWorkDraftContext)
  const owner = useContext(ExplicitDeferralContext)
  const [local, setLocal] = useState(initial)
  const key = JSON.stringify([owner?.itemId ?? drafts?.scope, question, field])
  return [drafts?.values[key] ?? local, value => {
    setLocal(value)
    if (drafts && (owner || drafts.scope)) drafts.change(key, value)
  }]
}
