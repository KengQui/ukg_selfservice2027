import { GTL_QUESTIONS, GTL_PURPOSE_ID, gtlDefinition, gtlDiscovery } from './gtlQuestions'
import { assessGtlEvidence } from './gtlPurposeEvidence'
import { sampleRegistersFor, REGISTER_SECTIONS } from './sampleDocument'
import { consolidateRegisters, type RegisterQuestion } from './registerEvidence'
import type { EarningSession, ItemAnswer } from './session'

/** The demo uses the same evidence evaluator as uploads. Preserve its separate
 * period and annual observations without borrowing the sample Ready references. */
export function sampleGtlEvidence(files: EarningSession['files']) {
  const registers = sampleRegistersFor(files)
  const groups = consolidateRegisters(registers.map(register => ({
    ...register.file, status: 'ready' as const, evidence: { warnings: [], reports: [{
      company: null, companyId: null, periodStart: null, periodEnd: null,
      periodLabel: register.period, reportId: null, currency: 'USD',
      rows: register.rows.filter(row => row.code === 'GTL').flatMap(row => {
        const lines = register.csv.split('\r\n')
        const index = lines.findIndex(line => line.startsWith('"GTL",'))
        const base = { code: row.code, description: null, section: row.section,
          people: row.employees, locator: `Row ${index + 1}`, quote: lines[index] ?? REGISTER_SECTIONS[row.section] }
        return [
          { ...base, amount: row.periodAmount ?? row.amount, amountLabel: row.periodAmount === undefined ? 'Last 12 months' : register.period },
          ...(row.periodAmount === undefined ? [] : [{ ...base, amount: row.amount, amountLabel: 'Last 12 months' }]),
        ]
      }),
    }] },
  })))
  if (!groups.length) return undefined
  const source = { ...groups[0], sources: groups.flatMap(group => group.sources), warnings: [...new Set(groups.flatMap(group => group.warnings))] }
  return assessGtlEvidence(source)
}

export function identifiedGtl(group: RegisterQuestion) {
  return assessGtlEvidence(group).candidate
}
export const uploadedGtlId = (group: RegisterQuestion) => `${GTL_QUESTIONS.id}:${group.id}`
export const isUploadedGtlId = (id: string) => id.startsWith(`${GTL_QUESTIONS.id}:register:`)
export function uploadedGtlDefinition(id: string, source?: RegisterQuestion) {
  const evidence = source ? assessGtlEvidence(source) : undefined
  return isUploadedGtlId(id) ? { ...gtlDefinition(evidence), itemId: id, code: source?.code ?? GTL_QUESTIONS.code,
    // Uploaded codes keep their source identity in the card label, not the demo code GTL.
    question: evidence?.identityUncertain
      ? 'If this code includes group-term life insurance, will your company continue providing that benefit after moving to UKG Ready?'
      // copy-exception(review/record): Approved opening retained for identified uploaded benefits.
      : 'We identified group-term life insurance in your payroll records. Will your company continue providing this benefit after moving to UKG Ready?',
  } : undefined
}
/** Source changes invalidate purpose only; continuation choices and frozen history survive. */
export function activeGtlAnswer(answer: ItemAnswer = {}, source: RegisterQuestion): ItemAnswer {
  if (!answer.conditionalReview || !answer.gtlSource || assessGtlEvidence(answer.gtlSource).basis === assessGtlEvidence(source).basis) return answer
  const { [GTL_PURPOSE_ID]: _purpose, ...responses } = answer.conditionalReview.responses
  const { [GTL_PURPOSE_ID]: _details, ...comments } = answer.conditionalReview.comments
  return { ...answer, conditionalReview: { ...answer.conditionalReview, responses, comments }, explicitDeferral: undefined }
}
/** Evidence stays attached per source; amounts are never summed or used to infer withholding. */
export function uploadedGtlDiscoveries(session: EarningSession) {
  return consolidateRegisters(session.files).filter(identifiedGtl).map(source => {
    const id = uploadedGtlId(source)
    const answer = activeGtlAnswer(session.answers[id], source)
    return { id, source, ...gtlDiscovery(answer?.conditionalReview, answer?.choice === 'ask-customer', assessGtlEvidence(source)) }
  })
}

/** Persist invalidation at the source-change boundary so changing a file back cannot
 * reactivate a stale purpose. Preserve the old source and answers together as history. */
export function reconcileGtlEvidence(session: EarningSession): EarningSession {
  if (session.registerSource !== 'uploads') return session
  const sources = consolidateRegisters(session.files)
  let answers = session.answers
  for (const source of sources.filter(identifiedGtl)) {
    const id = uploadedGtlId(source)
    const previous = answers[id]
    if (!previous) continue
    const active = activeGtlAnswer(previous, source)
    if (active === previous) continue
    answers = { ...answers, [id]: { ...active, gtlSource: source,
      gtlHistory: [...previous.gtlHistory ?? [], { source: previous.gtlSource!, answers: previous.conditionalReview! }],
    } }
  }
  return answers === session.answers ? session : { ...session, answers }
}
