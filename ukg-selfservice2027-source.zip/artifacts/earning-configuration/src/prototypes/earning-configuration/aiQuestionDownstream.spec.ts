import { SCRIPTED_QUESTIONS, reduceChecked } from './scriptedChecks.testing'
import { describe, expect, it } from 'vitest'
import { findItem } from './sampleRegister'
import { namingRequest } from './customName'
import { SOMETHING_ELSE_REFERENCE } from './somethingElse'
import { createSession, decisionFor, type EarningSession, type SessionAction } from './session'

const run = (session: EarningSession, ...actions: SessionAction[]) =>
  actions.reduce((state, action) => reduceChecked(state, action, 1000), session)
const started = () => run(createSession(0), { type: 'startReview' })
const ADJ2 = findItem('ADJ2')

/** ADJ2 through the AI's own question, both follow-ups and Keep, up to the proposed match. */
const atMatch = () => run(started(),
  { type: 'describe', itemId: 'ADJ2', description: 'It depends on the month' },
  { type: 'submitDescription', itemId: 'ADJ2' },
  { type: 'answerCheckQuestion', itemId: 'ADJ2', answer: 'A correction to an earlier overpayment' },
  { type: 'answerFollowUp', itemId: 'ADJ2', questionId: 'basis', choice: 'hourly' },
  { type: 'answerFollowUp', itemId: 'ADJ2', questionId: 'frequency', choice: 'one-time' },
  { type: 'chooseRetention', itemId: 'ADJ2', choice: 'keep' },
)

describe('answers after an AI-written question', () => {
  it('clears a submitted Something else on the match when an earlier AI answer changes', () => {
    const rejected = run(atMatch(),
      { type: 'chooseSomethingElse', itemId: 'ADJ2', question: SOMETHING_ELSE_REFERENCE },
      { type: 'describeSomethingElse', itemId: 'ADJ2', description: 'Neither, it pays back a loan' },
      { type: 'submitSomethingElse', itemId: 'ADJ2' },
    )
    expect(rejected.answers.ADJ2.somethingElse).toMatchObject({ question: SOMETHING_ELSE_REFERENCE, submitted: true })
    const changed = run(rejected, { type: 'changeCheckAnswer', itemId: 'ADJ2', index: 0 })
    expect(changed.answers.ADJ2.somethingElse).toBeUndefined()
    // Answering again reaches the match again, which has to be answered again.
    const again = run(changed,
      { type: 'answerCheckQuestion', itemId: 'ADJ2', answer: 'A correction to an earlier overpayment' },
      { type: 'answerFollowUp', itemId: 'ADJ2', questionId: 'basis', choice: 'hourly' },
      { type: 'answerFollowUp', itemId: 'ADJ2', questionId: 'frequency', choice: 'one-time' },
      { type: 'chooseRetention', itemId: 'ADJ2', choice: 'keep' },
    )
    expect(again.answers.ADJ2.somethingElse).toBeUndefined()
    expect(decisionFor(ADJ2, again.answers.ADJ2)).toBeUndefined()
  })

  it('sends the AI-question answers with the custom-name request', () => {
    const session = run(started(),
      { type: 'describe', itemId: 'ADJ2', description: 'It depends on the month' },
      { type: 'submitDescription', itemId: 'ADJ2' },
      { type: 'answerCheckQuestion', itemId: 'ADJ2', answer: 'A bonus amount' },
    )
    expect(namingRequest(ADJ2, session.answers.ADJ2)?.answers)
      .toEqual([{ question: SCRIPTED_QUESTIONS.ADJ2.question, answer: 'A bonus amount' }])
  })
})
