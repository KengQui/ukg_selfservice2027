import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { SessionContext } from './sessionContext'
import StepReview from './StepReview'
import UploadedRegisterReview from './UploadedRegisterReview'
import { APPROVED_BOUNDARIES, boundariesReviewFixture } from './aiSummaryBoundaries.testing'
import { SAVED_COPY_KEY, WORKING_COPY_KEY } from './storage'

describe('AI summary boundaries help', () => {
  let root: Root | undefined
  let host: HTMLDivElement
  afterEach(() => {
    if (root) act(() => root!.unmount())
    root = undefined
    host?.remove()
    localStorage.clear()
    sessionStorage.clear()
    vi.unstubAllGlobals()
  })

  function mount(variant: 'sample' | 'uploaded', analysis = false) {
    vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT', true)
    const session = boundariesReviewFixture(variant)
    const before = JSON.stringify(session)
    sessionStorage.setItem(WORKING_COPY_KEY, before)
    localStorage.setItem(SAVED_COPY_KEY, before)
    const dispatch = vi.fn()
    const save = vi.fn(() => true)
    const restart = vi.fn(() => true)
    host = document.createElement('div')
    document.body.append(host)
    root = createRoot(host)
    act(() => root!.render(
      <SessionContext.Provider value={{ session, dispatch, save, restart }}>
        {variant === 'sample' ? <StepReview /> : <UploadedRegisterReview analysis={analysis} />}
      </SessionContext.Provider>,
    ))
    return () => {
      expect(JSON.stringify(session)).toBe(before)
      expect(sessionStorage.getItem(WORKING_COPY_KEY)).toBe(before)
      expect(localStorage.getItem(SAVED_COPY_KEY)).toBe(before)
      expect(dispatch).not.toHaveBeenCalled()
      expect(save).not.toHaveBeenCalled()
      expect(restart).not.toHaveBeenCalled()
    }
  }

  it.each(['sample', 'uploaded'] as const)('opens, traps focus, dismisses and reopens without changing the %s review', variant => {
    const unchanged = mount(variant)
    if (variant === 'sample') {
      expect(host.querySelector('[data-testid="row-cheat-SPPAY"]')).not.toBeNull()
      expect(host.querySelector('textarea')?.value).toBe('A stipend for using a second language.')
    }
    const trigger = host.querySelector<HTMLButtonElement>('button[aria-label="About the AI summary"]')!
    const heading = host.querySelector('h1')!
    expect(heading.textContent).toBe(variant === 'sample' ? 'Let’s fill in the gaps in your pay code setup' : 'What do we need to review?')
    expect(heading.contains(trigger)).toBe(false)
    expect(heading.nextElementSibling).toBe(trigger)
    expect(trigger.getAttribute('aria-haspopup')).toBe('dialog')
    expect(trigger.getAttribute('aria-expanded')).toBe('false')
    expect(document.querySelector('[role="dialog"]')).toBeNull()
    const contentBefore = host.innerHTML

    for (const dismissal of ['escape', 'close', 'backdrop']) {
      act(() => { trigger.focus(); trigger.click() })
      const dialog = document.querySelector<HTMLElement>('[role="dialog"]')!
      expect(dialog).not.toBeNull()
      expect(document.getElementById(dialog.getAttribute('aria-labelledby')!)?.textContent)
        .toBe('Boundaries for the AI summary')
      expect(dialog.getAttribute('aria-modal')).toBe('true')
      expect(trigger.getAttribute('aria-expanded')).toBe('true')
      expect([...dialog.querySelectorAll('li')].map(item => item.textContent)).toEqual(APPROVED_BOUNDARIES)
      const close = dialog.querySelector<HTMLButtonElement>('[aria-label="Close dialog"]')!
      expect(document.activeElement).toBe(close)
      expect(dialog.querySelectorAll('button')).toHaveLength(1) // No acceptance or setup action.
      const list = dialog.querySelector<HTMLUListElement>('ul')!
      act(() => close.dispatchEvent(new KeyboardEvent('keydown', { key: 'Tab', shiftKey: true, bubbles: true, cancelable: true })))
      expect(document.activeElement).toBe(list)
      act(() => list.dispatchEvent(new KeyboardEvent('keydown', { key: 'Tab', bubbles: true, cancelable: true })))
      expect(document.activeElement).toBe(close)
      unchanged()
      act(() => {
        if (dismissal === 'escape') close.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }))
        else if (dismissal === 'close') close.click()
        else (dialog.parentElement as HTMLElement).click()
      })
      expect(document.querySelector('[role="dialog"]')).toBeNull()
      expect(document.activeElement).toBe(trigger)
      expect(trigger.getAttribute('aria-expanded')).toBe('false')
      expect(host.innerHTML).toBe(contentBefore)
      unchanged()
    }
  })

  it('does not put summary help on the file analysis screen', () => {
    const unchanged = mount('uploaded', true)
    expect(host.querySelector('h1')?.textContent).toBe('What we read from your files')
    expect(host.querySelector('[aria-label="About the AI summary"]')).toBeNull()
    expect(document.querySelector('[role="dialog"]')).toBeNull()
    unchanged()
  })
})
