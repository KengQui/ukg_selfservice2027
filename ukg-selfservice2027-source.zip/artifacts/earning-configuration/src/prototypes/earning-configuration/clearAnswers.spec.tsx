import { act, type ReactNode } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { ItemQuestion } from './StepQuestions'
import QuestionCard from './QuestionCard'
import { ReviewConversation } from './AnswerReview'
import { SessionContext } from './sessionContext'
import { requestDescriptionCheck } from './descriptionCheck'
import { reduceChecked } from './scriptedChecks.testing'
import { CELL_ID } from './cell'
import { MILEAGE_ID, PER_MILE } from './mileage'
import { findItem, ASK_CUSTOMER } from './sampleRegister'
import { createSession, reduceSession, parseSession, OTHER_PURPOSE, type EarningSession, type SessionAction } from './session'

vi.mock('./descriptionCheck', async importOriginal => ({
  ...(await importOriginal<typeof import('./descriptionCheck')>()), requestDescriptionCheck: vi.fn(),
}))

let host: HTMLDivElement
let root: Root
let session: EarningSession
let content: () => ReactNode
const render = () => root.render(
  <SessionContext.Provider value={{ session, dispatch, save: () => true, restart: () => true }}>{content()}</SessionContext.Provider>,
)
const dispatch = (action: SessionAction) => {
  session = reduceSession(session, action, 1000)
  render()
}
const seed = (...actions: SessionAction[]) => {
  session = actions.reduce((state, action) => reduceChecked(state, action, 1000), session)
}
const mountItem = (id: string, onAnswer?: (action: SessionAction) => void) => {
  content = () => <ItemQuestion item={findItem(id)} label={id} answer={session.answers[id] ?? {}} onAnswer={onAnswer} />
  act(render)
}
const clear = () => host.querySelector<HTMLElement>('.ec-qcard__clear-answers')

beforeEach(() => {
  (globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
  host = document.createElement('div')
  document.body.append(host)
  root = createRoot(host)
  session = reduceSession(createSession(0), { type: 'startReview' }, 1)
  vi.mocked(requestDescriptionCheck).mockReset().mockReturnValue(new Promise(() => {}))
})
afterEach(() => {
  act(() => root.unmount())
  host.remove()
})

describe('Clear all answers', () => {
  it.each([
    ['ADJ2', [
      { type: 'describe', itemId: 'ADJ2', description: 'It depends on the month' },
      { type: 'submitDescription', itemId: 'ADJ2' },
      { type: 'answerCheckQuestion', itemId: 'ADJ2', answer: 'A correction to an earlier overpayment' },
    ]],
    ['MISC7', [
      { type: 'describe', itemId: 'MISC7', description: 'Night shift premium' },
      { type: 'submitDescription', itemId: 'MISC7' },
    ]],
    ['SPPAY', [
      { type: 'choose', itemId: 'SPPAY', choice: OTHER_PURPOSE },
      { type: 'describe', itemId: 'SPPAY', description: 'It depends on the shift' },
      { type: 'submitDescription', itemId: 'SPPAY' },
    ]],
    [CELL_ID, [
      { type: 'choose', itemId: CELL_ID, choice: 'both' },
      { type: 'answerFollowUp', itemId: CELL_ID, questionId: 'treatment', choice: 'qualifying' },
      { type: 'answerFollowUp', itemId: CELL_ID, questionId: 'split', choice: ASK_CUSTOMER },
    ]],
    ['MED ER', [{ type: 'choose', itemId: 'MED ER', choice: 'only-records' }]],
    [MILEAGE_ID, [
      { type: 'cell', itemId: MILEAGE_ID, event: { kind: 'answer', id: 'method', value: PER_MILE } },
      { type: 'cell', itemId: MILEAGE_ID, event: { kind: 'answer', id: 'rate-basis', value: 'company' } },
      { type: 'cell', itemId: MILEAGE_ID, event: { kind: 'answer', id: 'company-rate', value: '0.60' } },
    ]],
  ] satisfies [string, SessionAction[]][])('restarts %s in its original card and preserves other cards', async (id, actions) => {
    const neighbor = 'MED'
    seed({ type: 'choose', itemId: neighbor, choice: id === 'MED ER' ? 'employee' : ASK_CUSTOMER })
    const otherAnswer = session.answers[neighbor]
    mountItem(id)
    expect(clear()).toBeNull()
    seed(...actions)
    act(render)
    expect(host.querySelector('.ec-qcard__sequence')).not.toBeNull()
    const reset = clear()!
    expect(reset.textContent).toBe('Clear all answers')
    expect(reset.parentElement?.className).toBe('ec-qcard__footer-actions')
    expect(reset.parentElement?.firstElementChild).toBe(reset)
    expect(reset.parentElement?.querySelectorAll('.ec-defer')).toHaveLength(1)
    expect(host.querySelectorAll('.ec-defer')).toHaveLength(1)
    await act(async () => reset.click())
    expect(session.answers[id]).toEqual({})
    expect(session.answers[neighbor]).toBe(otherAnswer)
    expect(host.querySelector('.ec-qcard__sequence')).toBeNull()
    expect(host.querySelector('[aria-checked="true"]')).toBeNull()
    expect(host.querySelector('textarea')?.value ?? '').toBe('')
    expect(clear()).toBeNull()
    expect(document.activeElement?.textContent).toBe(id === MILEAGE_ID ? 'How does your company calculate mileage payments?' : findItem(id).question)
    // Persisting and restoring the working copy must not bring deleted answers back.
    expect(parseSession(JSON.stringify(session))?.answers[id]).toEqual({})
  })

  it('removes the entire answer record, not just its visible choices', () => {
    session.answers.ADJ2 = {
      description: 'An old description', descriptionSubmitted: true, retain: 'keep', choice: 'accept',
      followUps: { old: ASK_CUSTOMER }, checkAnswers: [], reviews: {},
      sharedSetup: { referenceId: 'shift-differential', choice: 'separate' },
      somethingElse: { question: 'old', description: 'An old note', submitted: true },
    }
    const next = reduceSession(session, { type: 'clearAnswers', itemId: 'ADJ2' }, 12)
    expect(next.answers.ADJ2).toEqual({})
    expect(next.updatedAt).toBe(12)
    expect(next.rounds).toBe(session.rounds)
    expect(next.resolutions).toBe(session.resolutions)
  })

  it('protects applied rounds, unknown items and saved customer replies', () => {
    seed({ type: 'choose', itemId: 'DEN', choice: 'both' })
    mountItem('DEN', vi.fn())
    expect(clear()).toBeNull()
    session = { ...session, rounds: session.rounds.map(round => ({ ...round, submitted: true })) }
    mountItem('DEN')
    expect(clear()).toBeNull()
    expect(reduceSession(session, { type: 'clearAnswers', itemId: 'DEN' })).toBe(session)
    expect(reduceSession(session, { type: 'clearAnswers', itemId: 'unknown' })).toBe(session)
  })

  it('cancels a pending check and allows the same original description to be checked again', async () => {
    const description = 'It depends on the month'
    seed({ type: 'describe', itemId: 'ADJ2', description }, { type: 'submitDescription', itemId: 'ADJ2' })
    mountItem('ADJ2')
    act(() => dispatch({ type: 'answerCheckQuestion', itemId: 'ADJ2', answer: 'A correction to an earlier overpayment' }))
    const [input, signal] = vi.mocked(requestDescriptionCheck).mock.calls.at(-1)!
    expect(input).toBeDefined()
    expect(signal?.aborted).toBe(false)
    await act(async () => clear()!.click())
    expect(signal?.aborted).toBe(true)
    expect(session.answers.ADJ2).toEqual({})
    const callsBeforeRestart = vi.mocked(requestDescriptionCheck).mock.calls.length
    act(() => dispatch({ type: 'describe', itemId: 'ADJ2', description }))
    act(() => dispatch({ type: 'submitDescription', itemId: 'ADJ2' }))
    expect(requestDescriptionCheck).toHaveBeenCalledTimes(callsBeforeRestart + 1)
    expect(vi.mocked(requestDescriptionCheck).mock.calls.at(-1)?.[1]?.aborted).toBe(false)
    expect(session.answers.ADJ2.checkAnswers).toBeUndefined()
  })

  it('offers the same reset for an AI review follow-up in the Misclassified card layout', () => {
    const onClearAnswers = vi.fn()
    content = () => <QuestionCard label="MED" question="Who pays for the plan?" answered defer variant="misclassification"
      onClearAnswers={onClearAnswers} selected="note" onSelect={() => {}}
      afterOptions={<ReviewConversation basis="saved" requestKey="plan" request={vi.fn()} onReview={vi.fn()}
        saved={{ basis: 'saved', result: {
          outcome: 'followUp', reason: 'We need more detail.', suggestion: 'Describe the payment.',
          question: 'When does the company pay?', conflictingFact: null,
        } }} />} />
    act(render)
    expect(clear()?.parentElement?.querySelector('.ec-defer')).not.toBeNull()
    act(() => clear()!.click())
    expect(onClearAnswers).toHaveBeenCalledOnce()
  })
})
