import { draftEarningCustomerQuestions, type EarningCustomerQuestionInput } from '@workspace/api-client-react'
import { usabilityFacts } from './usabilityFacts'
import { redactSensitive } from '@workspace/setup-shared/ask-bryte'
import { findCode, findItem } from './sampleRegister'
import { itemInSession } from './mileage'
import type { EarningSession } from './session'
import { callEvidence } from './cheatSheetAnswers'
import { standardCustomerQuestion, validCustomerDraft } from './customerQuestionData'
import { allowedDiscussionKinds } from './discussionAnswers'
import { reimbursementAnswer } from './reimbursements'
import { cellOutstanding } from './cellFlow'

export const DRAFT_ERROR = 'We couldn’t draft these questions this time. Try again, or use the standard question.'

export function customerDraftRequest(session: EarningSession, id: string): EarningCustomerQuestionInput {
  const item = itemInSession(findItem(id), session.answers)
  const code = findCode(item.code)
  const saved = session.customerQuestions.find(question => question.itemId === id)
  const evidence = callEvidence(item, session.answers[id])
  const payment = reimbursementAnswer(item, session.answers[id])
  if (payment) {
    const outstanding = cellOutstanding(payment)
    evidence.questions = outstanding ? [{ question: outstanding.question, choices: outstanding.options?.map(o => o.label) ?? [] }] : []
    evidence.answers = [
      { question: 'Previously supplied payment facts', answer: payment.reimbursement!.purpose },
      ...(payment.cell?.entries ?? []).map(e => ({ question: e.question, answer: e.answer })),
    ]
  }
  const clean = (text: string, max: number) => redactSensitive(text).slice(0, max)
  return {
    allowedAnswerKinds: payment ? ['text'] : allowedDiscussionKinds(session, id),
    code: item.code.toUpperCase(),
    ...(payment ? { reimbursement: true } : {}),
    facts: usabilityFacts(session, item.code) ?? { description: code?.description ? clean(code.description, 500) : null,
      section: code?.section ?? null, peopleCount: code?.employees ?? null, amount: code?.amount ?? null },
    standardQuestion: clean(saved ? standardCustomerQuestion(session, saved) : item.customerQuestion, 3000),
    cardQuestions: evidence.questions.slice(0, 20).map(entry => ({
      question: clean(entry.question, 1000), choices: entry.choices.map(choice => clean(choice, 1000)).slice(0, 12),
    })),
    earlierAnswers: evidence.answers.slice(-60).map(entry => ({
      question: clean(entry.question, 1000), answer: clean(entry.answer, 2000),
    })),
  }
}

export async function requestCustomerDraft(input: EarningCustomerQuestionInput, signal: AbortSignal) {
  try {
    const result = await draftEarningCustomerQuestions(input, { signal })
    return validCustomerDraft(result) ? { ok: true as const, result: {
      questions: result.questions.map(question => redactSensitive(question)), reason: redactSensitive(result.reason),
      ...(result.answerKinds ? { answerKinds: result.answerKinds } : {}),
    } } : { ok: false as const, message: DRAFT_ERROR }
  } catch (error) {
    if (signal.aborted) throw error
    const known = error && typeof error === 'object' && 'data' in error ? error.data as { code?: string; error?: unknown } : undefined
    const status = error && typeof error === 'object' && 'status' in error ? error.status : undefined
    const statuses: Record<string, number> = { invalid_request: 400, rate_limited: 429, unavailable: 502, invalid_response: 502, timed_out: 504 }
    return { ok: false as const, message: known?.code && statuses[known.code] === status && typeof known.error === 'string' && known.error.trim()
      ? known.error : DRAFT_ERROR }
  }
}
