import { act, useReducer } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import {
  EARNING_STEPS, normalizeEarningEnvelope, isSessionEnvelope, resumedEarningProgressStep, resumedEarningStep,
} from '@workspace/setup-shared/prototypes/_shared-earning-configuration/sessionFormat'
import { earningPages } from '../../askBrytePages'
import { bryteFacts } from './bryteFacts'
import { EARNING_DEMO_SETTINGS } from './demoSettings'
import { createOptimization, OPTIMIZATIONS } from './optimization'
import { createSession, currentRound, parseSession, reduceSession, type EarningSession, type SessionAction } from './session'
import { ASK_CUSTOMER } from './sampleRegister'
import { SessionContext } from './sessionContext'
import StepReview from './StepReview'
import AppliedReviewQuestions from './AppliedReviewQuestions'
import { StepOptimization, StepOptimizationReview } from './StepOptimization'
import { StepOvertime } from './StepOvertime'
import { browserStores, loadSession, saveSession, writeWorkingCopy, SAVED_COPY_KEY, WORKING_COPY_KEY } from './storage'
import { createOvertimeDemoSession } from './overtimeDemo'
import { customerQuestionList } from './summary'

vi.mock('@workspace/api-client-react', async original => ({
  ...await original<typeof import('@workspace/api-client-react')>(),
  draftEarningCustomerQuestions: vi.fn(() => new Promise(() => {})),
}))

const run = (session: EarningSession, ...actions: SessionAction[]) =>
  actions.reduce((state, action) => reduceSession(state, action, 1000), session)

function deferredReview() {
  const open = run(createSession(1), { type: 'startReview' })
  return run(open, ...currentRound(open)!.itemIds.map(itemId => ({ type: 'choose' as const, itemId, choice: ASK_CUSTOMER })),
    { type: 'submitRound' }, { type: 'finishReevaluation' })
}

function phase(state: 'editing' | 'submitted' | 'completed') {
  let session = run(deferredReview(), { type: 'complete' },
    ...OPTIMIZATIONS.map(({ id }) => ({ type: 'chooseOptimization' as const, suggestionId: id, choice: 'keep' as const })))
  if (state !== 'editing') session = run(session, { type: 'submitOptimization' })
  if (state === 'completed') session = run(session, { type: 'completeOptimization' })
  return session
}

beforeEach(() => {
  HTMLElement.prototype.scrollIntoView = vi.fn()
  sessionStorage.clear()
  localStorage.clear()
  EARNING_DEMO_SETTINGS.ungateForwardButtons = false
})
afterEach(() => { EARNING_DEMO_SETTINGS.ungateForwardButtons = false })

describe('direct classification completion', () => {
  it.each([false, true])('retains the classification gate with the demo setting %s', ungated => {
    EARNING_DEMO_SETTINGS.ungateForwardButtons = ungated
    const open = run(createSession(1), { type: 'startReview' })
    const review = deferredReview()
    const pending: EarningSession = { ...review, rounds: [
      { ...review.rounds[0], results: { ...review.rounds[0].results!, findings: ['MILEAGE TX'] } },
      { number: 2, submitted: false, itemIds: ['MILEAGE TX'] },
    ] }
    for (const blocked of [createSession(1), open, pending]) expect(run(blocked, { type: 'complete' })).toBe(blocked)
    expect(run(review, { type: 'complete' }).step).toBe('optimization')
  })

  it('keeps applied decisions, deferred questions, discussion notes and file evidence across completion', () => {
    const review = { ...deferredReview(), callAnswers: { MILEAGE: 'Confirm the policy on the call.' } }
    const next = run(review, { type: 'complete' })
    expect(next.step).toBe('optimization')
    expect(next).toEqual({ ...review, step: 'optimization' })
    expect(customerQuestionList(next)).toEqual(customerQuestionList(review))
    expect(next.customerQuestions.length).toBeGreaterThan(0)
    // The recorded demo also covers resolved and setup-review decisions, plus source files.
    const applied = { ...createOvertimeDemoSession(1), step: 'review' as const, optimization: createOptimization() }
    expect(applied.files.length).toBeGreaterThan(0)
    expect(run(applied, { type: 'complete' })).toEqual({ ...applied, step: 'optimization', updatedAt: 1000 })
  })

  it.each(['editing', 'submitted', 'completed'] as const)('keeps %s optimization on Back, refresh, save and reentry', state => {
    const session = phase(state)
    const back = run(session, { type: 'goTo', step: 'review' })
    expect(back.optimization).toBe(session.optimization)
    writeWorkingCopy(browserStores(), back)
    expect(loadSession(browserStores())).toEqual(back)
    expect(saveSession(browserStores(), back)).toBe(true)
    sessionStorage.clear()
    const restored = loadSession(browserStores())
    const next = run(restored, { type: 'complete' })
    expect(next).toEqual(session)
    expect(parseSession(JSON.stringify(next))).toEqual(next)
    if (state !== 'editing') expect(run(next, { type: 'chooseOptimization', suggestionId: 'split-bonus', choice: 'accept' })).toBe(next)
    if (state === 'completed') expect(run(next, { type: 'editOptimization' })).toBe(next)
  })
})

describe('retired completion destination', () => {
  it.each(['editing', 'submitted', 'completed'] as const)('normalizes legacy %s progress in either copy and remembered navigation', state => {
    const session = phase(state)
    for (const destination of ['completed', 'intro', 'categorySelection'] as const) {
      const old = { ...session, step: destination, lastEarningStep: 'completed', updatedAt: 123 }
      for (const [store, key] of [[sessionStorage, WORKING_COPY_KEY], [localStorage, SAVED_COPY_KEY]] as const) {
        sessionStorage.clear(); localStorage.clear()
        const raw = JSON.stringify(old)
        store.setItem(key, raw)
        const restored = loadSession(browserStores())
        const step = destination === 'completed' ? session.step : destination
        expect(restored).toEqual({ ...old, step, lastEarningStep: session.step })
        expect(resumedEarningStep(browserStores())).toBe(step)
        expect(resumedEarningProgressStep(browserStores())).toBe(session.step)
        expect(parseSession(JSON.stringify(restored))).toEqual(restored)
        expect(store.getItem(key)).toBe(raw) // Reading never rewrites either copy or its timestamp.
      }
    }
  })

  it('selects the newest valid copy, with the working copy winning a tie', () => {
    const editing = { ...phase('editing'), step: 'completed', updatedAt: 20 }
    const completed = { ...phase('completed'), step: 'completed', updatedAt: 21 }
    sessionStorage.setItem(WORKING_COPY_KEY, JSON.stringify(editing))
    localStorage.setItem(SAVED_COPY_KEY, JSON.stringify(completed))
    expect(loadSession(browserStores()).step).toBe('overtime')
    expect(resumedEarningStep(browserStores())).toBe('overtime')
    localStorage.setItem(SAVED_COPY_KEY, JSON.stringify({ ...completed, updatedAt: 20 }))
    expect(loadSession(browserStores()).step).toBe('optimization')
    expect(resumedEarningStep(browserStores())).toBe('optimization')
    sessionStorage.setItem(WORKING_COPY_KEY, JSON.stringify({ ...editing, rounds: [], updatedAt: 30 }))
    expect(loadSession(browserStores()).step).toBe('overtime')
  })

  it.each([1, 2, 3, 4])('keeps question migration ahead of version %i destination normalization', version => {
    const session = phase('completed')
    for (const step of ['completed', 'intro', 'categorySelection']) {
      // The category chooser did not exist in v1.
      if (version === 1 && step === 'categorySelection') continue
      const old = JSON.parse(JSON.stringify({ ...session, version, step, lastEarningStep: 'completed' }).replaceAll('CELL-purpose', 'CELL'))
      localStorage.setItem(SAVED_COPY_KEY, JSON.stringify(old))
      const restored = loadSession(browserStores())
      // Earlier mixed-scope migrations can move even a navigation page into renewed review.
      const prior = parseSession(JSON.stringify({ ...old, step: step === 'completed' ? 'review' : step, lastEarningStep: 'review' }))!
      expect(prior).not.toBeNull()
      expect(restored.step).toBe(prior.step)
      if (step !== 'completed') expect(restored.lastEarningStep).toBe('questions')
      expect(resumedEarningStep(browserStores())).toBe(step === 'completed' ? 'questions' : step)
      expect(resumedEarningProgressStep(browserStores())).toBe('questions')
      expect(restored.rounds.at(-1)?.submitted).toBe(false)
      expect(restored.customerQuestions).toEqual(old.customerQuestions)
    }
  })

  it('accepts the v1 identifier but rejects newer v1 phases and unreachable legacy completions', () => {
    const v1 = { ...createSession(1), version: 1, step: 'completed' }
    expect(isSessionEnvelope(v1)).toBe(true)
    if (isSessionEnvelope(v1)) expect(normalizeEarningEnvelope(v1).step).toBe('optimization')
    expect(parseSession(JSON.stringify(v1))?.step).toBe('results') // Older scope migration still takes precedence.
    expect(parseSession(JSON.stringify({ ...v1, step: 'optimization' }))).toBeNull()
    expect(parseSession(JSON.stringify({ ...createSession(1), step: 'completed' }))).toBeNull()
    expect(parseSession(JSON.stringify({ ...run(createSession(1), { type: 'startReview' }), step: 'completed' }))).toBeNull()
    expect(parseSession(JSON.stringify({ ...phase('editing'), step: 'completed', optimization: { answers: {}, submitted: true, completed: true } }))).toBeNull()
    expect(EARNING_STEPS).not.toContain('completed')
    expect(earningPages).not.toHaveProperty('completed')
  })
})

describe('transition screens and guidance', () => {
  let root: Root | undefined
  let host: HTMLDivElement
  let latest: EarningSession
  function mount(initial: EarningSession) {
    host = document.createElement('div')
    document.body.append(host)
    root = createRoot(host)
    function Flow() {
      const [session, dispatch] = useReducer(
        (state: EarningSession, action: SessionAction) => reduceSession(state, action),
        initial,
      )
      latest = session
      const content = session.appliedReview ? <AppliedReviewQuestions /> : session.step === 'review' ? <StepReview />
        : session.step === 'optimizationReview' ? <StepOptimizationReview />
        : session.step === 'overtime' ? <StepOvertime /> : <StepOptimization />
      return <SessionContext.Provider value={{ session, dispatch, save: () => true, restart: () => true }}>{content}</SessionContext.Provider>
    }
    act(() => root!.render(<Flow />))
  }
  const click = (label: string) => act(() => {
    const button = [...host.querySelectorAll('button')].find(el => el.textContent?.trim() === label)
    expect(button, label).toBeDefined()
    button!.click()
  })
  afterEach(() => { if (root) act(() => root!.unmount()); root = undefined; host?.remove() })

  it('opens Optimize codes from the summary and returns Back with the answers intact', () => {
    mount(deferredReview())
    const before = latest
    click('Complete classification')
    expect(host.querySelector('h1')?.textContent).toBe('Optimize codes')
    expect(host.textContent).not.toMatch(/Classification completed|Continue to optimization/)
    expect(latest.customerQuestions).toEqual(before.customerQuestions)
    click('Back')
    expect(host.querySelector('h1')?.textContent).toBe('Let’s fill in the gaps in your pay code setup')
    expect(latest.optimization).toBe(before.optimization)
  })

  it.each(['submitted', 'completed'] as const)('reenters the %s screen without unlocking it', state => {
    const session = phase(state)
    mount(state === 'completed' ? session : run(session, { type: 'goTo', step: 'review' }))
    if (state === 'completed') click('Back')
    expect(host.querySelector('h1')?.textContent).toBe('Let’s fill in the gaps in your pay code setup')
    click('Complete classification')
    expect(host.querySelector('h1')?.textContent).toBe('How does your team earn overtime')
    expect(latest.optimization).toBe(session.optimization)
  })

  it('opens overtime directly with Next and preserves answered screening on Back', () => {
    const session = phase('submitted')
    mount({ ...session, step: 'optimization', optimization: { ...session.optimization, submitted: false, completed: false } })
    expect(host.querySelector('h1')?.textContent).toBe('Optimize codes')
    const before = latest
    click('Next')
    expect(host.querySelector('h1')?.textContent).toBe('How does your team earn overtime')
    expect(host.textContent).not.toMatch(/Optimization completed|Continue to overtime|Change answers/)
    expect(latest.optimization).toEqual({ ...before.optimization, submitted: true, completed: true })
    const no = [...host.querySelectorAll<HTMLElement>('[role="radio"]')].find(option => option.textContent?.startsWith('No'))!
    act(() => no.click())
    const answered = latest
    click('Back')
    expect(host.querySelector('h1')?.textContent).toBe('Let’s fill in the gaps in your pay code setup')
    click('Complete classification')
    expect(host.querySelector('h1')?.textContent).toBe('How does your team earn overtime')
    expect(latest.overtime).toBe(answered.overtime)
    expect(latest.customerQuestions).toEqual(answered.customerQuestions)
    expect(latest.optimization).toBe(answered.optimization)
  })

  it('keeps the pending findings action instead of Complete classification', () => {
    const session = deferredReview()
    mount({ ...session, rounds: [
      { ...session.rounds[0], results: { ...session.rounds[0].results!, findings: ['MILEAGE TX'] } },
      { number: 2, itemIds: ['MILEAGE TX'], submitted: false },
    ] })
    expect(host.textContent).not.toContain('Complete classification')
    click('Review 1 new finding')
    expect(latest.step).toBe('questions')
  })

  it.each([undefined, 'findings', 'added-questions'] as const)('looks back at saved answers without starting %s', pendingKind => {
    const saved = { ...deferredReview(), callAnswers: { MILEAGE: 'Keep this discussion note.' } }
    const session: EarningSession = pendingKind ? { ...saved, rounds: [
      ...saved.rounds, { number: 2, itemIds: ['MILEAGE TX'], submitted: false,
        ...(pendingKind === 'added-questions' ? { kind: pendingKind } : {}) },
    ] } : saved
    mount(session)
    const actions = [...host.querySelectorAll('.ec-actions button')].map(button => button.textContent?.trim())
    expect(actions[0]).toBe('Back')
    const primary = actions[1]!
    click('Back')
    expect(latest.appliedReview?.round).toBe(1)
    expect(host.textContent).toContain('These answers have already been applied.')
    expect(host.textContent).toContain('Deferred')
    // Applied business answers stay read-only; missing discussion provenance may
    // offer Defer separately, without opening classification answer controls.
    expect(host.querySelectorAll('.ec-qcard textarea, .ec-qcard input, .ec-qcard [role="radio"], .ec-qcard [role="checkbox"]')).toHaveLength(0)
    for (const input of host.querySelectorAll('input')) expect(input.closest('.ec-discussion__response')).not.toBeNull()
    expect(host.textContent).not.toMatch(/Apply answers|Edit description|Clear all answers|Restart questions/)
    expect(document.activeElement).toBe(host.querySelector('h1'))
    const last = latest.appliedReview!.cursor
    click('Back')
    expect(latest.appliedReview!.cursor).toBe(last - 1)
    click('Next')
    expect(latest.appliedReview!.cursor).toBe(last)
    click('Return to results')
    expect(latest.appliedReview).toBeUndefined()
    expect(latest).toEqual({ ...session, updatedAt: latest.updatedAt })
    expect(host.querySelector('h1')?.textContent).toBe('Let’s fill in the gaps in your pay code setup')
    click(primary)
    expect(latest.step).toBe(pendingKind ? 'questions' : 'optimization')
  })

  it('shows typed answers and saved follow-ups without mounting answer controls', () => {
    const session = deferredReview()
    const initial: EarningSession = { ...session, answers: { ...session.answers, ADJ2: {
      choice: ASK_CUSTOMER, description: 'A correction to an earlier commission payment.', descriptionSubmitted: true,
      checkAnswers: [{ question: 'Which payment is being corrected?', format: { kind: 'text' },
        answer: 'The commission from last month.', afterFollowUps: 0 }],
      reviews: { description: { basis: 'saved-history', result: { outcome: 'confirm', reason: 'Saved explanation.', question: null, conflictingFact: null },
        thread: [{ question: 'When was it paid?', reply: 'Last month.' }] } },
    } } }
    mount(initial)
    click('Back')
    while (!host.querySelector('[data-review-item="ADJ2"]')) click('Back')
    expect(host.textContent).toContain(initial.answers.ADJ2.description)
    expect(host.textContent).toContain('Which payment is being corrected?')
    expect(host.textContent).toContain('The commission from last month.')
    expect(host.textContent).toContain('When was it paid?')
    expect(host.textContent).toContain('Last month.')
    expect(host.querySelectorAll('.ec-qcard textarea, .ec-qcard input, .ec-qcard [role="radio"], .ec-qcard [role="checkbox"]')).toHaveLength(0)
    for (const input of host.querySelectorAll('input')) expect(input.closest('.ec-discussion__response')).not.toBeNull()
    expect(host.querySelector('[aria-label^="Change answer"]')).toBeNull()
    click('Return to results')
    expect(latest.answers).toBe(initial.answers)
    expect(latest.rounds).toBe(initial.rounds)
    expect(latest.resolutions).toBe(initial.resolutions)
  })

  it('describes the direct transition and both real Back destinations', () => {
    const review = deferredReview()
    const registration = bryteFacts(review)
    expect(registration.key).toBe('review')
    expect(earningPages.review(registration.facts).onScreen.join(' ')).toContain('Complete classification opens Optimize codes directly')
    for (const session of [phase('editing'), phase('completed')]) {
      const { key, facts } = bryteFacts(session)
      const copy = JSON.stringify(earningPages[key](facts))
      expect(copy).toContain('Back returns to the review page')
      expect(copy).not.toMatch(/Classification completed|Continue to optimization/)
    }
  })
})
