import TextArea from '@ready/dls/components/TextArea/TextArea'
import { useEarningSession } from './sessionContext'

/** Call notes stay separate from the structured replies that change payroll setup. */
export default function CallAnswer({ itemId, optional = false }: { itemId: string; optional?: boolean }) {
  const { session, dispatch } = useEarningSession()
  return (
    <TextArea
      id={`call-answer-${encodeURIComponent(itemId)}`}
      className="ec-cheat__answer"
      label={optional ? 'Discussion notes (optional)' : 'Discussion notes'}
      placeholder="Add notes from the discussion"
      aria-describedby="review-notes-guidance"
      rows={3}
      value={session.callAnswers?.[itemId] ?? ''}
      onChange={text => dispatch({ type: 'setCallAnswer', itemId, text })}
    />
  )
}
