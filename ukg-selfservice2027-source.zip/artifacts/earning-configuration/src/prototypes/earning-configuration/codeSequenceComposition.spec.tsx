import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { MemoryRouter } from 'react-router-dom'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { reviewPaymentFacts } from '@workspace/api-client-react'
import { ItemQuestion } from './StepQuestions'
import { SessionContext } from './sessionContext'
import { ASK_CUSTOMER, findItem } from './sampleRegister'
import { namingBasis, parseSession, reduceSession, type EarningSession, type SessionAction } from './session'
import { MEDICAL_CONTRIBUTION_QUESTIONS } from './benefitQuestions'
import { GTL_ID, GTL_QUESTIONS } from './gtlQuestions'
import { paymentSession } from './paymentFacts.testing'
import { currentPaymentFacts } from './paymentEvidence'
import { routingOpen } from './reviewRouting.testing'

vi.mock('@workspace/api-client-react', async original => ({
  ...await original<typeof import('@workspace/api-client-react')>(), reviewPaymentFacts: vi.fn(),
}))

let host: HTMLDivElement, root: Root, session: EarningSession, id: string
const run = (action: SessionAction) => { session = reduceSession(session, action, session.updatedAt + 1) }
const render = (reply = false) => root.render(<MemoryRouter><SessionContext.Provider value={{
  session, dispatch: action => { run(action); render(reply) }, save: () => true, restart: () => true,
}}><ItemQuestion item={findItem(id)} label={id} answer={session.answers[id] ?? {}}
  {...(reply ? { onAnswer: (action: SessionAction) => { run(action); render(true) } } : {})} />
</SessionContext.Provider></MemoryRouter>)
const card = () => host.querySelector<HTMLElement>('article.ec-qcard, .card.ec-qcard')!
const numbers = () => [...card().querySelectorAll<HTMLElement>('[data-sequence-number]')].map(el => el.dataset.sequenceNumber)
const pick = (label: string, scope: ParentNode = card()) => {
  const option = [...scope.querySelectorAll<HTMLElement>('[role="radio"]')]
    .find(el => el.querySelector('.sc__title')?.textContent === label)!
  expect(option, label).toBeTruthy()
  option.focus()
  option.dispatchEvent(new KeyboardEvent('keydown', { key: ' ', bubbles: true }))
}
const button = (label: string) => [...card().querySelectorAll<HTMLButtonElement>('button')]
  .find(el => el.textContent?.trim() === label)!
const sequence = () => {
  expect(host.querySelectorAll('article.ec-qcard, .card.ec-qcard')).toHaveLength(1)
  expect(card().querySelectorAll('.ec-qcard__sequence')).toHaveLength(1)
  expect(card().querySelectorAll('.ec-qcard__sequence-heading')).toHaveLength(1)
  expect(card().querySelectorAll('.ec-defer')).toHaveLength(1)
  const group = card().querySelector<HTMLElement>('.ec-qcard__sequence')!
  expect([...card().querySelectorAll('[data-sequence-number]')].every(el => group.contains(el))).toBe(true)
  expect(group.closest('.ec-qcard__answer, .ec-qcard__option-content')).toBeNull()
  return group
}
const conditionalFixture = (itemId = 'MED ER') => {
  id = itemId
  session = routingOpen([id])
  const definition = id === 'MED ER' ? MEDICAL_CONTRIBUTION_QUESTIONS : GTL_QUESTIONS
  run({ type: 'choose', itemId: id, choice: definition.purposes[0].id })
  return definition.purposes[0].followUp!
}

beforeEach(() => {
  vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT', true)
  HTMLElement.prototype.scrollIntoView = vi.fn()
  host = document.createElement('div'); document.body.append(host); root = createRoot(host)
  vi.mocked(reviewPaymentFacts).mockReset().mockResolvedValue({ facts: [] })
})
afterEach(() => { act(() => root.unmount()); host.remove(); vi.unstubAllGlobals(); vi.clearAllMocks() })

describe('card-owned follow-up composition', () => {
  it('completes MED ER with its purpose follow-up only, including after reload', async () => {
    const first = conditionalFixture()
    await act(async () => render())
    await act(async () => pick(first.options[0].label))
    session = parseSession(JSON.stringify(session))!
    await act(async () => render())
    sequence()
    expect(numbers()).toEqual(['01'])
    expect(card().querySelector('.ec-payment-facts')).toBeNull()
    expect(card().textContent).not.toMatch(/Review summary|Preliminary classification|adopted|pay statement/i)
    expect(reviewPaymentFacts).not.toHaveBeenCalled()
    await act(async () => pick(MEDICAL_CONTRIBUTION_QUESTIONS.purposes[1].label))
    expect(card().textContent).not.toContain(first.question)
    expect(session.answers[id].conditionalReview?.responses).toEqual({})
    await act(async () => button('Clear all answers').click())
    expect(session.answers[id]).toEqual({})
  })

  it.each([GTL_ID])('%s asks purpose once and never adds a payment supplement', async itemId => {
    const question = conditionalFixture(itemId)
    await act(async () => render())
    sequence()
    expect(numbers()).toEqual(['01'])
    await act(async () => pick(question.options[0].label))
    sequence()
    expect(numbers()).toEqual(['01'])
    expect(card().querySelector('.ec-qcard__sequence-answer')?.textContent).toContain(question.options[0].label)
    expect(card().querySelector('.ec-payment-facts')).toBeNull()
    expect(reviewPaymentFacts).not.toHaveBeenCalled()
    session = parseSession(JSON.stringify(session))!
    await act(async () => render())
    expect(numbers()).toEqual(['01'])
    sequence()
  })

  it('keeps purpose answers editable and clears the existing sequence', async () => {
    const first = conditionalFixture(GTL_ID)
    await act(async () => render())
    await act(async () => pick(first.options[0].label))
    await act(async () => card().querySelector<HTMLButtonElement>('[aria-label="Change answer to question 1"]')!.click())
    await act(async () => pick(first.options[1].label))
    expect(numbers()).toEqual(['01'])
    expect(session.answers[id].conditionalReview?.responses[first.id]).toBe(first.options[1].id)
    await act(async () => button('Clear all answers').click())
    expect(numbers()).toEqual([])
    expect(card().querySelector('.ec-qcard__sequence')).toBeNull()
    expect(session.answers[id]).toEqual({})
    expect(document.activeElement).toBe(card().querySelector('h3'))
  })

  it('defers once at the card footer without losing earlier answers', async () => {
    const first = conditionalFixture()
    run({ type: 'conditionalReview', itemId: id, event: { type: 'answer', questionId: first.id, choice: first.options[0].id } })
    await act(async () => render())
    const earlier = structuredClone(session.answers[id].conditionalReview)
    await act(async () => card().querySelector<HTMLInputElement>('.ec-defer input')!.click())
    expect(session.answers[id].choice).toBe(ASK_CUSTOMER)
    expect(session.answers[id].conditionalReview).toEqual(earlier)
    expect(card().querySelectorAll('.ec-defer')).toHaveLength(1)
    expect(card().querySelector('.ec-defer')?.closest('.ec-qcard__sequence')).toBeNull()
    expect(button('Clear all answers').closest('.ec-qcard__sequence')).toBeNull()
    expect(numbers()).toEqual(['01'])
  })

  it('never resumes a retired GTL retry or saved supplemental question', async () => {
    const first = conditionalFixture(GTL_ID)
    run({ type: 'conditionalReview', itemId: id, event: { type: 'answer', questionId: first.id, choice: first.options[0].id } })
    vi.mocked(reviewPaymentFacts).mockRejectedValueOnce(new Error('offline'))
    session.paymentReviews = { [id]: { basis: 'retired', replies: [], deferred: true,
      draft: { key: 'lifePlan', text: 'Earlier funding draft' } } }
    await act(async () => render())
    expect(sequence().textContent).not.toContain('We couldn’t check these payment facts.')
    expect(numbers()).toEqual(['01'])
    expect(button('Try again')).toBeUndefined()
    expect(reviewPaymentFacts).not.toHaveBeenCalled()
    session = parseSession(JSON.stringify(session))!
    await act(async () => render())
    expect(session.paymentReviews?.[id]?.draft?.text).toBe('Earlier funding draft')
    expect(currentPaymentFacts(session, id)?.question).toBeUndefined()
    expect(card().textContent).not.toContain('Suggested:')
    expect(card().textContent).not.toContain('These facts don’t support one overtime recommendation.')
    sequence()
    expect(numbers()).toEqual(['01'])
  })

  it('composes Special Pay AI/reference steps before its payment questions', async () => {
    id = 'SPPAY'; session = paymentSession()
    const answer = { ...session.answers[id], checkAnswers: [{ question: 'When do you pay this stipend?', answer: 'Each month.',
      format: { kind: 'text' as const }, afterFollowUps: 0 }] }
    const basis = namingBasis(answer)
    session.answers[id] = { ...answer, check: { ...answer.check!, basis }, naming: { ...answer.naming!, basis } }
    await act(async () => render())
    sequence()
    const labels = numbers()
    expect(labels.length).toBeGreaterThan(1)
    expect(labels).toEqual(labels.map((_, i) => String(i + 1).padStart(2, '0')))
    expect(card().querySelector('.ec-payment-facts [data-sequence-number]')).not.toBeNull()
  })

  it('keeps editable customer answers independent from the owning review supplement', async () => {
    const first = conditionalFixture()
    await act(async () => render(true))
    await act(async () => pick(first.options[0].label))
    sequence()
    expect(numbers()).toEqual(['01'])
    expect(card().querySelector('.ec-payment-facts')).toBeNull()
    expect(reviewPaymentFacts).not.toHaveBeenCalled()
    await act(async () => card().querySelector<HTMLButtonElement>('[aria-label="Change answer to question 1"]')!.click())
    expect(card().querySelectorAll('[role="radio"]').length).toBeGreaterThan(4)
  })
})
