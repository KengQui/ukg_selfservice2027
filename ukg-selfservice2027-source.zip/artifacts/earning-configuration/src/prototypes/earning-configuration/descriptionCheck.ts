/**
 * AI check requests for described codes (ADJ2, MISC7 and SPPAY's Something else). The server's AI reads the team's
 * description and follow-up answers and picks a candidate Ready reference, one follow-up question, a request for a
 * clearer description, or no suitable reference. A failure never becomes a stand-in result.
 */
import { checkEarningDescription, type EarningCheckInput } from '@workspace/api-client-react'
import { redactSensitive } from '@workspace/setup-shared/ask-bryte'
import { codesUsingReference, findCode, type UnidentifiedItem } from './sampleRegister'
import { answerFormatFrom, askedFollowUps, checkCandidates, followUpQuestions, type DescriptionCheck, type ItemAnswer } from './session'

export type CheckErrorCode = 'invalid_request' | 'rate_limited' | 'unavailable' | 'timed_out' | 'invalid_response'
const CHECK_ERROR_CODES: readonly CheckErrorCode[] = ['invalid_request', 'rate_limited', 'unavailable', 'timed_out', 'invalid_response']

/** Shown when the server's message can't be trusted as written, or the request never reached it. */
export const CHECK_FALLBACK_ERROR = 'We can’t check your answer right now. Try again, or select Review later.'
const UNUSABLE_RESULT = 'We couldn’t check your answer this time. Try again, or select Review later.'

export type CheckResponse =
  | { ok: true; result: DescriptionCheck }
  | { ok: false; message: string }

const SOURCE_LABEL = 'Pay register data'

/** The facts the AI check reads: the source, the description, earlier answers, unasked questions and the candidates. */
export function checkRequest(item: UnidentifiedItem, answer: ItemAnswer): EarningCheckInput {
  return {
    code: item.code,
    source: { label: SOURCE_LABEL, description: findCode(item.code)?.description || null },
    // Sensitive identifiers are removed here as well as on the server, so they never leave the browser.
    description: redactSensitive(answer.description?.trim() ?? ''),
    answers: describedAnswers(item, answer),
    followUps: followUpQuestions(item)
      .filter(question => !answer.followUps?.[question.id])
      .map(question => ({ id: question.id, question: question.question, options: question.options.map(option => option.label) })),
    references: checkCandidates(item).map(reference => {
      const inUseBy = codesUsingReference(reference.id, item.code).map(({ code, description }) => ({
        code, description: description ? redactSensitive(description) : null,
      }))
      return { id: reference.id, name: reference.name, ...(inUseBy.length ? { inUseBy } : {}) }
    }),
  }
}

/**
 * Every answer given after the description, in the order it was asked: follow-ups and answers to the AI's own
 * questions. The check and the custom-name request both read it, so a name builds on the same clarifications.
 */
export function describedAnswers(item: UnidentifiedItem, answer: ItemAnswer): { question: string; answer: string }[] {
  const answered = askedFollowUps(item, answer).flatMap(question => {
    const label = question.options.find(option => option.id === answer.followUps?.[question.id])?.label
    return label ? [{ question: question.question, answer: label }] : []
  })
  // Answers to AI-written questions keep their place among the follow-up answers.
  const written = answer.checkAnswers ?? []
  const inOrder = [...answered.keys(), answered.length].flatMap(position => [
    ...written.filter(entry => Math.min(entry.afterFollowUps, answered.length) === position)
      .map(entry => ({ question: entry.question, answer: redactSensitive(entry.answer) })),
    ...(position < answered.length ? [answered[position]] : []),
  ])
  // SPPAY's Something else rules out both listed options, so the AI hears that answer first.
  return item.script.kind === 'uncertainMatch' && !item.purposeFirst ? [{ question: item.question, answer: item.script.other.label }, ...inOrder] : inOrder
}

function errorMessage(error: unknown): string {
  if (typeof error !== 'object' || error === null || !('data' in error)) return CHECK_FALLBACK_ERROR
  const data = (error as { data: unknown }).data
  if (typeof data !== 'object' || data === null) return CHECK_FALLBACK_ERROR
  const { code, error: message } = data as { code?: unknown; error?: unknown }
  // Only this endpoint's documented errors carry a message written for this screen.
  return typeof code === 'string' && CHECK_ERROR_CODES.includes(code as CheckErrorCode)
    && typeof message === 'string' && message.trim() ? message : CHECK_FALLBACK_ERROR
}

export async function requestDescriptionCheck(input: EarningCheckInput, signal: AbortSignal): Promise<CheckResponse> {
  try {
    const result = await checkEarningDescription(input, { signal })
    if (result.outcome === 'reference' && result.referenceId && result.reason) {
      return { ok: true, result: { kind: 'reference', referenceId: result.referenceId, reason: result.reason } }
    }
    if (result.outcome === 'followUp' && result.followUpId) return { ok: true, result: { kind: 'followUp', questionId: result.followUpId } }
    if (result.outcome === 'noMatch' && result.reason) return { ok: true, result: { kind: 'noMatch', reason: result.reason } }
    if (result.outcome === 'notNeeded' && result.reason) return { ok: true, result: { kind: 'notNeeded', reason: result.reason } }
    const format = answerFormatFrom(result.answerFormat)
    if (result.outcome === 'needsInformation' && result.question && format) {
      return { ok: true, result: { kind: 'needsInformation', question: result.question, format } }
    }
    return { ok: false, message: UNUSABLE_RESULT }
  } catch (error) {
    if (signal.aborted) throw error
    return { ok: false, message: errorMessage(error) }
  }
}
