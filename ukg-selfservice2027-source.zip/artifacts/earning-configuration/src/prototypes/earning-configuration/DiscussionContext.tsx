import type { DiscussionContext as Context } from './discussionContext'

/** Earlier original answers, read-only and collapsed. No session actions or loading effects. */
export default function DiscussionContext({ context, itemId }: { context: Context; itemId: string }) {
  if (!context.earlier.length && !context.reviews.length) return null
  return (
    <details className="ec-cheat__why ec-context__earlier" data-testid={`details-earlier-answers-${itemId}`}>
      <summary>Earlier answers ({context.earlier.length})</summary>
      {!!context.earlier.length && (
        <dl className="ec-context__answers">
          {context.earlier.map((entry, index) => (
            <div key={index}>
              <dt>{entry.question}</dt>
              <dd><span className="ec-context__provenance">{entry.historical ? 'Historical answer, not current confirmation' : entry.provenance === 'supplied' ? 'Supplied payment context' : 'Your answer'}</span>{entry.answer}</dd>
            </div>
          ))}
        </dl>
      )}
      {context.reviews.map((review, index) => (
        <div key={index} className="ec-cheat__text ec-context__review">
          <strong>Earlier AI review of a typed answer. Not a setup decision</strong>
          <p>{review.reason}</p>
        </div>
      ))}
    </details>
  )
}
