import { findItem } from './sampleRegister'
import { activeCheck, activeNaming, askedFollowUps, decisionFor, lookupResult, openCheckQuestion, pendingCheckBasis,
  retentionAsked, retentionOf, sharedSetupFor, shiftPremiumFor, shiftPremiumUsesFixedQuestion, somethingElseQuestion,
  type EarningSession, type ItemAnswer } from './session'
import { answerReviewBasis } from './answerReviewData'
import { reviewShown } from './answerReviewScope'
import { reimbursementAnswer } from './reimbursements'
import { cellNext } from './cellFlow'
import { tipsResult, tipsSetup } from './tipsFlow'
import { isTipsCode } from './tipsIdentity'

export type AssessmentState = 'checking' | 'problem' | 'missing' | 'confirmation' | 'ready' | 'specialist' | 'deferred' | 'setupReview'
export const ASSESSMENT_LABELS: Record<AssessmentState, string> = {
  checking: 'Checking answer', problem: 'Check needs a retry', missing: 'Needs a detail',
  confirmation: 'Needs confirmation', ready: 'Ready to apply', specialist: 'Needs setup review', deferred: 'New question deferred',
  setupReview: 'Ready for setup review',
}

/** Pending TIPS facts can be kept for review; supported proposals use the ordinary Apply boundary. */
export function checkedTipsForSetupReview(id: string, answer: ItemAnswer) {
  const result = isTipsCode(id) && answer.tipsReview && !answer.tipsReview.deferred && !answer.tipsReview.editing
    ? tipsResult(answer, id) : undefined
  return result?.outcome === 'pending'
}

/** Describes only the owning process's actual state; neither an AI result nor this label accepts a decision. */
export function assessDeferredItem(session: EarningSession, id: string, answer: ItemAnswer, ready: boolean, deferred: boolean) {
  const state = (status: AssessmentState, message: string) => ({ status, message })
  if (deferred) return state('deferred', 'The new question stays open for discussion. Applying keeps it deferred, not resolved.')
  const checkStates = Object.entries(session.discussionPreview?.checks ?? {}).filter(([key]) => key.startsWith(`${id}:`)).map(([, check]) => check)
  const problem = checkStates.find(check => check.status === 'problem')
  if (problem) return state('problem', problem.message ?? 'We couldn’t check this answer. Try again below; your answers are kept.')
  if (checkStates.length) return state('checking', 'We’re checking your answer. No setup decision has been applied.')
  if (isTipsCode(id) && answer.tipsReview) {
    const result = tipsResult(answer, id)
    if (!result) return state('checking', 'We’re checking which tip details are still needed.')
    if (result.outcome === 'question') return state('missing', result.question ?? 'Answer the remaining tip question below.')
    if (tipsSetup(answer, id) && ready) return state('ready',
      `The checked answers support this ${id} proposal. Applying uses it in this review; live payroll will not change.`)
    if (checkedTipsForSetupReview(id, answer)) return state('setupReview',
      `Keep the ${id} answers for setup review. No tip treatment, Ready reference or separate code will be applied.`)
  }
  const item = findItem(id)
  if (pendingCheckBasis(item, answer) !== undefined) return state('checking', 'We’re checking the payment purpose before proposing a setup decision.')
  const payment = reimbursementAnswer(item, answer) ?? (answer.cell && !answer.cellLegacy ? answer : undefined)
  if (payment && !payment.cell?.deferred) {
    const next = cellNext(payment)
    if (next.kind === 'check') return state('checking', 'We’re checking the supplied payment details.')
    if (next.kind === 'question') return state('missing', next.question.question)
    if (next.kind === 'pending') return state('specialist', next.reason)
  }
  const reviewQuestions = new Set([item.question, somethingElseQuestion(item, answer), sharedSetupFor(item, answer)?.question,
    ...Object.keys(answer.reviews ?? {})].filter((q): q is string => !!q))
  for (const question of reviewQuestions) {
    if (!reviewShown(item, answer, question)) continue
    const review = answer.reviews?.[question]
    if (!review || review.basis !== answerReviewBasis(answer)) return state('checking', 'We’re reviewing your answer before proposing a consequence.')
    if (review.result.question && !review.dismissed)
      return state('missing', review.result.question)
    if (review.result.outcome === 'conflict' || review.result.outcome === 'followUp')
      return state('specialist', review.result.reason)
    if (review.result.outcome === 'notNeeded' && answer.retain !== 'remove')
      return state('confirmation', 'Confirm whether to leave this code out of setup. The check has not removed it.')
  }
  const check = activeCheck(item, answer)
  if (check?.kind === 'needsInformation') return openCheckQuestion(item, answer)
    ? state('missing', check.question)
    : state('specialist', `The payment purpose is still unclear after the available follow-ups: ${check.question}`)
  if (check?.kind === 'notNeeded' && answer.retain !== 'remove')
    return state('confirmation', 'Confirm whether to leave this code out of setup. Earlier payroll activity will stay unchanged.')
  const premium = shiftPremiumFor(item, answer)
  if (premium && !shiftPremiumUsesFixedQuestion(item, answer) && !answer.sharedSetup?.choice) {
    if (!premium.result && !premium.state?.changed) return state('checking', 'We’re comparing the payment with the existing shift code.')
    if (premium.result?.outcome === 'question') return state('missing', premium.result.question ?? 'Answer the remaining shift question below.')
    if (premium.result?.outcome === 'defer') return state('specialist', premium.result.reason)
  }
  if (ready) return state('ready', '')
  if (retentionAsked(item, answer) && !retentionOf(answer)) return state('confirmation', 'Confirm whether to keep or remove this code.')
  if (lookupResult(item, answer).kind === 'noMatch') {
    const naming = activeNaming(item, answer)
    if (!naming) return state('checking', 'We’re checking for a name that describes this payment purpose.')
    if (naming.outcome === 'needsInformation') return openCheckQuestion(item, answer)
      ? state('missing', naming.question ?? 'What does this payment cover?')
      : state('specialist', `The payment purpose still needs review: ${naming.question}`)
    if (!answer.choice) return state('confirmation', 'Accept the proposed name or keep the existing name. Neither choice confirms tax treatment or a Ready reference.')
  }
  const followUp = askedFollowUps(item, answer).find(q => !answer.followUps?.[q.id])
  if (followUp) return state('missing', followUp.question)
  const shared = sharedSetupFor(item, answer)
  if (shared && !answer.sharedSetup?.choice) return state('confirmation', shared.question)
  if (decisionFor(item, answer)?.kind === 'describe') return state('specialist',
    'The supplied details do not establish a supported setup decision. A setup specialist still needs to review this code.')
  return state('confirmation', 'Confirm the proposed decision below. Your earlier answers are kept.')
}
