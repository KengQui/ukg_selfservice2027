import { useEarningSession } from './sessionContext'
import { DEMO_FILL_ENABLED, demoFill } from './demoAnswers'
import { reviewPages, reviewPosition } from './session'
import { DemoQuestionPresentation, useDemoQuestionPresentation } from './DemoQuestionPresentation'

/** Invisible presenter aid: no visible copy, focus stop or accessible control. */
export default function DemoFill() {
  return <DemoQuestionPresentation><FillButton /></DemoQuestionPresentation>
}

function FillButton() {
  const { session, dispatch } = useEarningSession()
  const { displayed, currentPage } = useDemoQuestionPresentation()
  if (!DEMO_FILL_ENABLED || session.step !== 'questions') return null
  const pageItemIds = (reviewPages(session)[currentPage] ?? []).filter(displayed)
  return <button
    type="button"
    data-demo-fill
    tabIndex={-1}
    aria-hidden="true"
    style={{
      position: 'fixed', top: 0, right: 0, width: 48, height: 48, padding: 0,
      opacity: 0, background: 'transparent', border: 0, outline: 'none',
      // Above page content, but below the shared Bryte panel (400) and dialogs.
      cursor: 'pointer', zIndex: 100,
    }}
    onClick={() => demoFill(session, pageItemIds).forEach(dispatch)}
  />
}