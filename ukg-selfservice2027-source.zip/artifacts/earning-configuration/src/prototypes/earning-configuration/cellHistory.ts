import { READY, findItem, type ClarificationItem } from './sampleRegister'

/** Retired wording is a historical record, not guidance for a new review. */
export function historicalCellItem(): ClarificationItem {
  return {
    ...findItem('CELL-purpose') as ClarificationItem,
    question: 'How does the company pay CELL?',
    overview: 'CELL may cover phone costs. A set allowance and a payback for business phone use need different setups.',
    context: 'The code and amounts don’t show whether CELL is a fixed phone payment, repayment of business phone costs, or both.\n\nA fixed payment is taxed as pay. Repayment of business costs may qualify for tax-free treatment, but paying back a bill does not establish that treatment.\n\nYour answer selects the allowance or payback path. Paybacks need a separate confirmation of tax treatment. If you do both, a later question asks permission to separate the allowance and payback into two codes.',
    options: [
      { id: 'allowance', label: 'We pay a set amount for phones, whatever people spend', example: 'Example: $40 every month, whether someone’s phone bill is $30 or $90.', resolution: READY.cellAllowance },
      { id: 'reimbursement', label: 'We pay people back for what they spend on business phone use', example: 'Example: Someone shows $35 of business calls on their bill, and we pay back $35.', resolution: READY.cellReimbursement },
      { id: 'both', label: 'We do both', example: 'Example: $20 every month, plus money back for business calls on that month’s bill.', resolution: READY.cellAllowance },
    ],
  }
}
