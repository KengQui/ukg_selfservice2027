import { describe, expect, it } from 'vitest'
import { MEDICAL_CONTRIBUTION_QUESTIONS as definition } from './benefitQuestions'
import { conditionalReport, conditionalReportText, nextConditionalAnswers, validConditionalAnswers, type ConditionalDefinition } from './conditionalQuestions'
import { nextConditionalAnswer } from './conditionalAnswer'
import { ASK_CUSTOMER, CLEAR_CHOICE, findItem } from './sampleRegister'
import { createSession, customerQuestionFor, decisionFor, isAnswered, parseSession, reduceSession, reviewPages, type EarningSession, type SessionAction } from './session'
import { finalConfiguration } from './configuration'
import { customerQuestionList } from './summary'
import { routingOpen } from './reviewRouting.testing'

const run = (session: EarningSession, ...actions: SessionAction[]) =>
  actions.reduce((state, action) => reduceSession(state, action, 100), session)
const start = () => routingOpen([definition.code])
const choose = (choice: string): SessionAction => ({ type: 'choose', itemId: definition.code, choice })
const follow = (primary: string, choice: string): SessionAction => ({
  type: 'conditionalReview', itemId: definition.code,
  event: { type: 'answer', questionId: definition.purposes.find(purpose => purpose.id === primary)!.followUp.id, choice },
})

describe('conditional benefit intent', () => {
  it('asks the opening purpose only when it has not been established', () => {
    for (const answer of [{}, { choice: ASK_CUSTOMER }]) {
      const text = customerQuestionFor(findItem(definition.code), answer)
      expect(text).toContain(definition.question)
      for (const purpose of definition.purposes) expect(text).toContain(purpose.label)
      expect(text).not.toContain('undefined')
    }
  })
  it.each(definition.purposes)('defers only the missing follow-up for $id and preserves the reported purpose', purpose => {
    let session = run(start(), choose(purpose.id), choose(ASK_CUSTOMER))
    const text = customerQuestionFor(findItem(definition.code), session.answers[definition.code])
    expect(text).toContain(`You told us: ${purpose.label}`)
    expect(text).toContain(purpose.followUp.question)
    expect(text).not.toContain(definition.question)
    expect(text).not.toContain('undefined')
    for (const option of purpose.followUp.options) expect(text).toContain(option.label)
    session = run(session, { type: 'selectDeferredQuestion', itemId: definition.code, source: {
      question: purpose.followUp.question, choices: purpose.followUp.options.map(option => option.label),
      options: purpose.followUp.options.map(option => ({ id: option.id, label: option.label })),
    } }, { type: 'submitRound' })
    const question = customerQuestionList(session).find(q => q.id === 'classification:MED ER:v2')
    expect(question?.question).toBe(text)
    expect(session.answers[definition.code].explicitDeferral?.target).toEqual({ kind: 'conditional', id: purpose.followUp.id })
    expect(parseSession(JSON.stringify(session))?.answers[definition.code].conditionalReview?.primary).toBe(purpose.id)
  })
  it.each(definition.purposes)('completes $label with one relevant follow-up and never confirms configuration', purpose => {
    let session = run(start(), choose(purpose.id))
    expect(isAnswered(findItem(definition.code), session.answers[definition.code])).toBe(false)
    session = run(session, follow(purpose.id, purpose.followUp.options[0].id))
    expect(isAnswered(findItem(definition.code), session.answers[definition.code])).toBe(true)
    expect(decisionFor(findItem(definition.code), session.answers[definition.code])?.kind).toBe('describe')
    expect(session.answers[definition.code].medicalTarget).toBeUndefined()
    const report = conditionalReport(definition, session.answers[definition.code].conditionalReview)!
    expect(report.configurationVerification).toBe('Not completed')
    expect(Object.keys(session.answers[definition.code].conditionalReview!.responses)).toEqual([purpose.followUp.id])
  })

  it.each(definition.purposes)('allows uncertainty for $label without forcing a classification', purpose => {
    const uncertain = purpose.followUp.options.find(option => option.uncertain) ?? purpose.followUp.options.at(-1)!
    const session = run(start(), choose(purpose.id), follow(purpose.id, uncertain.id))
    expect(isAnswered(findItem(definition.code), session.answers[definition.code])).toBe(true)
    expect(conditionalReport(definition, session.answers[definition.code].conditionalReview)?.category).toBe('Needs Review')
  })

  it('switches purposes by deleting every old response, comment, review and setup attachment', () => {
    let session = run(start(), choose('other-purpose'), follow('other-purpose', 'description'),
      { type: 'conditionalReview', itemId: definition.code,
        event: { type: 'comment', questionId: 'medical-purpose-information-v2', text: 'Another benefit' } })
    session = run(session, choose('additional-compensation'))
    expect(session.answers[definition.code].conditionalReview).toMatchObject({
      primary: 'additional-compensation', responses: {}, comments: {},
    })
    expect(isAnswered(findItem(definition.code), session.answers[definition.code])).toBe(false)
    const stale = run(session, follow('only-records', 'taxable'))
    expect(stale.answers[definition.code]).toEqual(session.answers[definition.code])
  })

  it('does not require optional comments and clears them when their choice is no longer selected', () => {
    let session = run(start(), choose('other-purpose'), follow('other-purpose', 'description'))
    expect(isAnswered(findItem(definition.code), session.answers[definition.code])).toBe(true)
    session = run(session, { type: 'conditionalReview', itemId: definition.code,
      event: { type: 'comment', questionId: 'medical-purpose-information-v2', text: 'Another benefit' } },
    follow('other-purpose', 'no-information'))
    expect(session.answers[definition.code].conditionalReview?.comments).toEqual({})
  })

  it('keeps Defer working and clearing it restarts the card', () => {
    let session = run(start(), choose('only-records'), follow('only-records', 'tracking-only'), choose(ASK_CUSTOMER))
    expect(decisionFor(findItem(definition.code), session.answers[definition.code])?.kind).toBe('defer')
    session = run(session, choose(CLEAR_CHOICE))
    expect(session.answers[definition.code].conditionalReview).toBeUndefined()
    expect(isAnswered(findItem(definition.code), session.answers[definition.code])).toBe(false)
  })

  it('restores completed answers and comments after navigation and reload', () => {
    const session = run(start(), choose('additional-compensation'), follow('additional-compensation', 'other'),
      { type: 'conditionalReview', itemId: definition.code,
        event: { type: 'comment', questionId: 'medical-payment-method-v2', text: 'Medical allowance for temporary staff' } })
    const restored = parseSession(JSON.stringify(session))!
    expect(restored).not.toBeNull()
    expect(restored.answers[definition.code].conditionalReview).toEqual(session.answers[definition.code].conditionalReview)
    expect(decisionFor(findItem(definition.code), restored.answers[definition.code])?.kind).toBe('describe')
    const navigated = run(restored, { type: 'moveReview', index: 0 })
    expect(navigated.answers[definition.code].conditionalReview).toEqual(session.answers[definition.code].conditionalReview)
  })

  it('flags explicit contradictory comments, but does not decide tax treatment from a payment label', () => {
    const session = run(start(), choose('additional-compensation'), follow('additional-compensation', 'other'),
      { type: 'conditionalReview', itemId: definition.code,
        event: { type: 'comment', questionId: 'medical-payment-method-v2', text: 'No direct cash payment; employer tracking only' } })
    const report = conditionalReport(definition, session.answers[definition.code].conditionalReview)!
    expect(report.conflict).toBe(true)
    expect(report.category).toBe('Needs Review')
    expect(report.taxTreatment).toContain('Unknown')
    expect(isAnswered(findItem(definition.code), session.answers[definition.code])).toBe(true)
  })

  it('flags contradictory stored branches without accepting them as a confirmed setup', () => {
    const answers = nextConditionalAnswers(definition, undefined, { type: 'primary', choice: 'only-records' })!
    answers.responses = { 'employer-tax-treatment-v2': 'tracking-only', 'medical-payment-method-v2': 'allowance' }
    expect(conditionalReport(definition, answers)?.category).toBe('Needs Review')
  })

  it.each(definition.purposes.flatMap(purpose =>
    purpose.followUp.options.map(option => ({ purpose, option })),
  ))('saves the full preliminary report for $purpose.id / $option.id without verifying setup', ({ purpose, option }) => {
    let session = start()
    for (const id of reviewPages(session).flat()) session = run(session, { type: 'choose', itemId: id, choice: ASK_CUSTOMER })
    session = run(session, choose(purpose.id), follow(purpose.id, option.id))
    const report = conditionalReport(definition, session.answers[definition.code].conditionalReview)!
    const note = conditionalReportText(definition, session.answers[definition.code].conditionalReview)!
    session = run(session, { type: 'submitRound' })
    expect(session.resolutions[definition.code]?.status).toBe('review')
    expect(session.resolutions[definition.code]).toMatchObject({ note })
    expect(note).toContain('Configuration Verification: Not completed')
    expect(note).toContain(`Reported Purpose: ${purpose.label}`)
    expect(note).toContain(`${purpose.followUp.question} ${option.label}`)
    expect(note).toContain(`Tax Treatment: ${report.taxTreatment}`)
    expect(note).toContain(`Cash Compensation: ${report.cashCompensation}`)
    expect(note).toContain(`Recommended Action: ${definition.recommendedAction}`)
    const row = finalConfiguration(session).find(row => row.code === definition.code)!
    expect(row.status).toBe('review')
    expect(row.reference).toBeUndefined()
    expect(row.notes.join('\n')).toContain(report.category)
    const restored = parseSession(JSON.stringify(session))!
    expect(restored).not.toBeNull()
    expect(restored.resolutions[definition.code]).toEqual(session.resolutions[definition.code])
    expect(customerQuestionList(session).some(question => question.codes.includes(definition.code))).toBe(false)
  })

  it('shares exactly the same transitions with customer replies', () => {
    const primary = nextConditionalAnswer(definition.code, {}, choose('uncertain-purpose'))
    const complete = nextConditionalAnswer(definition.code, primary, follow('uncertain-purpose', 'no-information'))
    expect(isAnswered(findItem(definition.code), complete)).toBe(true)
    expect(decisionFor(findItem(definition.code), complete)?.kind).toBe('describe')
  })

  it('saves and restores an uncertain customer reply with its reported intent, not a setup reference', () => {
    let deferred = start()
    for (const id of reviewPages(deferred).flat()) deferred = run(deferred,
      { type: 'choose', itemId: id, choice: ASK_CUSTOMER },
      { type: 'selectDeferredQuestion', itemId: id, source: { question: definition.question,
        choices: definition.purposes.map(option => option.label), options: definition.purposes.map(option => ({ id: option.id, label: option.label })) } })
    deferred = run(deferred, { type: 'submitRound' }, { type: 'finishReevaluation' })
    const sent = run({ ...deferred, step: 'summary' }, { type: 'sendQuestions', to: 'customer@example.com' })
    let reply = nextConditionalAnswer(definition.code, {}, choose('uncertain-purpose'))
    reply = nextConditionalAnswer(definition.code, reply, follow('uncertain-purpose', 'no-information'))
    const saved = run(sent, { type: 'saveCustomerReply', questionId: 'classification:MED ER:v2', answer: reply })
    expect(saved.customerReplies?.['classification:MED ER:v2']?.answer).toEqual(reply)
    expect(saved.resolutions[definition.code]).toMatchObject({ status: 'review', note: expect.stringContaining('Needs Review') })
    // This fixture skips later optimization/overtime to exercise only reply persistence.
    const restored = parseSession(JSON.stringify({ ...saved, step: 'review' }))
    expect(restored).not.toBeNull()
    expect(restored?.sent).toEqual(sent.sent)
    expect(restored?.answers[definition.code].conditionalReview).toEqual(reply.conditionalReview)
    expect(restored?.resolutions[definition.code]).toEqual(saved.resolutions[definition.code])
  })

  it('supports another code through data definitions, without MED ER-specific logic', () => {
    const another: ConditionalDefinition = { ...definition, id: 'other-benefit-intent', code: 'HEALTH ER', codeCategory: 'unknown' }
    let answers = nextConditionalAnswers(another, undefined, { type: 'primary', choice: 'additional-compensation' })!
    answers = nextConditionalAnswers(another, answers, { type: 'answer', questionId: 'medical-payment-method-v2', choice: 'reimbursement' })!
    expect(validConditionalAnswers(answers)).toBe(true)
    expect(conditionalReport(another, answers)?.code).toBe('HEALTH ER')
    expect(conditionalReport(another, answers)?.category).toBe('Potential Employee Compensation')
    expect(conditionalReport(definition, answers)).toBeUndefined()
  })

  it('rejects malformed saved responses without treating them as configuration evidence', () => {
    expect(validConditionalAnswers({ definitionId: definition.id, version: 1, primary: 'only-records',
      responses: [], comments: {} })).toBe(false)
    expect(validConditionalAnswers({ definitionId: definition.id, version: 1, primary: 'only-records',
      responses: {}, comments: { note: 'x'.repeat(501) } })).toBe(false)
  })
})
