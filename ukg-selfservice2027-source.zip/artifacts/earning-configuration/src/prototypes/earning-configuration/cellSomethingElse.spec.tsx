import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { reviewCellPayment } from '@workspace/api-client-react'
import AdaptiveCellQuestions from './AdaptiveCellQuestions'
import CustomerReplyDialog from './CustomerReplyDialog'
import { SessionContext } from './sessionContext'
import { reduceSession, type ItemAnswer, type SessionAction } from './session'
import { cellNext, reduceCell, type CellEvent } from './cellFlow'
import { cellChecked, cellPick, cellResult, cellSession, fixedBusiness, sentCell } from './cellFlow.testing'
import { customerQuestionList } from './summary'
import { reimbursementAnswer } from './reimbursements'
import { findItem } from './sampleRegister'

vi.mock('@workspace/api-client-react', async original => ({ ...await original<typeof import('@workspace/api-client-react')>(), reviewCellPayment: vi.fn() }))

describe('CELL rendered sequence and local replies', () => {
  let host: HTMLDivElement, root: Root, answer: ItemAnswer, events: CellEvent[]
  const render = () => root.render(<SessionContext.Provider value={{ session: cellSession(answer), dispatch: vi.fn(), save: vi.fn(), restart: vi.fn() }}>
    <AdaptiveCellQuestions answer={answer} label={answer.reimbursement?.code ?? 'CELL'} sourceItemId={answer.reimbursement?.code ?? 'CELL-purpose'}
      onEvent={onEvent} onClearAnswers={() => { answer = {}; render() }} />
  </SessionContext.Provider>)
  const onEvent = (event: CellEvent) => { events.push(event); answer = reduceCell(answer, event); render() }
  const click = async (text: string) => {
    const title = [...host.querySelectorAll('.sc__title')].find(node => node.textContent?.trim() === text)
    const element = title?.closest('.sc') ?? [...host.querySelectorAll('button,label')].find(node => node.textContent?.trim() === text
      || node.tagName === 'LABEL' && node.textContent?.includes(text))
    if (!element) throw new Error(`Missing control: ${text}\n${host.textContent}`)
    await act(async () => (element as HTMLElement).click())
  }
  const type = async (text: string) => {
    const textarea = host.querySelector('textarea')!
    await act(async () => {
      Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')!.set!.call(textarea, text)
      textarea.dispatchEvent(new Event('input', { bubbles: true }))
    })
  }
  beforeEach(() => {
    Object.assign(globalThis, { IS_REACT_ACT_ENVIRONMENT: true })
    host = document.createElement('div'); document.body.append(host); root = createRoot(host)
    answer = {}; events = []; vi.mocked(reviewCellPayment).mockReset()
  })
  afterEach(async () => { await act(async () => root.unmount()); host.remove() })

  it('shows no selected method, numbered allowance reason, then explicit tax intent', async () => {
    vi.mocked(reviewCellPayment).mockResolvedValue(cellResult())
    await act(async () => render())
    expect(host.querySelector('input[type="radio"]:checked')).toBeNull()
    expect(host.textContent).toContain('How does your company use CELL to pay employees for cellphone costs?')
    expect(host.querySelector('.ec-qcard__prompt')?.textContent).toBe('Your pay register shows CELL payments. Is this a set amount you pay each pay period?')
    expect(host.textContent).not.toContain('The supplied mapping context identifies CELL')
    expect(events).toEqual([])
    await click('Fixed amount')
    expect(host.textContent).toContain('Why does your company provide the cellphone allowance?')
    expect(reviewCellPayment).not.toHaveBeenCalled()
    await click('Employees need to use their personal phones for work.')
    expect(reviewCellPayment).toHaveBeenCalledOnce()
    expect(host.textContent).toContain('How should this cellphone payment be treated for payroll taxes in UKG Ready?')
    expect(host.querySelectorAll('input[type="checkbox"]')).toHaveLength(1)
    await click('Taxable')
    expect(cellNext(answer).kind).toBe('done')
    expect(host.textContent).not.toContain('split CELL')
    await click('Clear all answers')
    expect(host.querySelector('input[type="radio"]:checked')).toBeNull()
  })
  it('Something else Done starts a targeted live clarification, not a terminal handoff', async () => {
    vi.mocked(reviewCellPayment).mockResolvedValue(cellResult('clarify', 'payment', {
      question: 'How is the employee’s business use reflected in the amount?', answerFormat: { kind: 'text', options: null },
    }))
    await act(async () => render())
    await click('Something else')
    expect(reviewCellPayment).not.toHaveBeenCalled()
    await type('The amount varies with calls for work.')
    await click('Done')
    expect(reviewCellPayment).toHaveBeenCalledOnce()
    expect(host.textContent).toContain('How is the employee’s business use reflected in the amount?')
    expect(host.textContent).not.toContain('Awaiting setup review')
  })
  it('failure offers Try again or Defer, retains learned facts, and retries the same snapshot', async () => {
    vi.mocked(reviewCellPayment).mockRejectedValueOnce(new Error('offline')).mockResolvedValue(cellResult())
    answer = fixedBusiness()
    await act(async () => render())
    expect(host.textContent).toContain('We can’t check this payment right now.')
    expect(cellNext(answer).kind).toBe('check')
    await click('Try again')
    expect(reviewCellPayment).toHaveBeenCalledTimes(2)
    await click('Defer')
    expect(answer.cell?.entries).toHaveLength(2)
    expect(answer.cell?.deferred?.id).toBe('tax-allowance')
  })
  it('known actual monthly phone costs reach the fixed tax question and repeated invalid responses retain retry/Defer', async () => {
    answer = cellPick({}, 'method', 'other', 'We repay actual monthly service costs for personal cellphones needed for work.')
    vi.mocked(reviewCellPayment).mockRejectedValueOnce({ status: 502, data: { code: 'invalid_response', error: 'We couldn’t check this payment this time. Try again, or select Defer.' } })
      .mockResolvedValue(cellResult('tax', 'payment'))
    await act(async () => render())
    const entries = answer.cell?.entries
    expect(host.textContent).toContain('Try again, or select Defer.')
    expect(host.textContent).not.toContain('ready for setup')
    await click('Try again')
    expect(host.textContent).toContain('How should this cellphone payment be treated for payroll taxes in UKG Ready?')
    expect(answer.cell?.entries).toEqual(entries)
    await click('Not sure')
    expect(host.textContent).toContain('Tax treatment is pending confirmation')
    expect(cellNext(answer).kind).toBe('done')
  })
  it('rechecks a legacy stop locally in a customer reply, asks tax and preserves frozen sent words', async () => {
    const pending = cellChecked(cellPick({}, 'method', 'other', 'We repay actual monthly service costs for personal cellphones needed for work.'),
      cellResult('pending', 'payment', { discovery: undefined, reason: 'Tax intent is not confirmed.' }))
    let session = sentCell(reduceCell(pending, { kind: 'defer', checked: true }))
    const sent = session.sent
    const question = customerQuestionList(session).find(q => q.codes.includes('CELL'))!
    vi.mocked(reviewCellPayment).mockResolvedValue(cellResult('tax', 'payment'))
    await act(async () => root.render(<SessionContext.Provider value={{ session,
      dispatch: action => { session = reduceSession(session, action, 124) }, save: vi.fn(), restart: vi.fn() }}>
      <CustomerReplyDialog question={question} onClose={vi.fn()} />
    </SessionContext.Provider>))
    const dialog = document.querySelector('[role="dialog"]')!
    for (const paragraph of question.question.split('\n\n')) expect(dialog.textContent).toContain(paragraph)
    expect(dialog.textContent).toContain('How should this cellphone payment be treated for payroll taxes in UKG Ready?')
    expect(reviewCellPayment).toHaveBeenCalledOnce()
    const taxable = [...dialog.querySelectorAll('.sc__title')].find(node => node.textContent?.trim() === 'Taxable')!.closest('.sc') as HTMLElement
    await act(async () => taxable.click())
    const save = [...dialog.querySelectorAll('button')].find(button => button.textContent?.trim() === 'Save answer')!
    expect(save.disabled).toBe(false)
    await act(async () => save.click())
    expect(session.sent).toEqual(sent)
    expect(session.resolutions['CELL-purpose'].status).toBe('review')
    expect(session.customerReplies?.[question.id]).toBeDefined()
    expect(session.answers['CELL-purpose'].cell?.entries[0]).toEqual(pending.cell?.entries[0])
  })
  it('MILEAGE validates a company rate without AI, then uses the scoped check and explicit intent', async () => {
    answer = reimbursementAnswer(findItem('MILEAGE'), {})!
    vi.mocked(reviewCellPayment).mockResolvedValue(cellResult('tax', 'reimbursement'))
    await act(async () => render())
    await click('A set amount for each business mile driven.')
    expect(reviewCellPayment).not.toHaveBeenCalled()
    await click('A company-established rate.')
    await type('bad')
    await click('Done')
    expect(host.textContent).toContain('Enter an amount greater than $0')
    expect(reviewCellPayment).not.toHaveBeenCalled()
    await type('0.80')
    await click('Done')
    expect(reviewCellPayment).toHaveBeenCalledOnce()
    expect(vi.mocked(reviewCellPayment).mock.calls[0][0].category).toBe('MILEAGE')
    expect(vi.mocked(reviewCellPayment).mock.calls[0][0].evidence?.[0].date).toBe('2026-10-09')
    expect(host.textContent).toContain('2026')
    expect(host.textContent).not.toContain('Add MILEAGE TX')
    await click('Nontaxable')
    expect(host.textContent).toContain('Configuration review required')
    expect(host.querySelectorAll('.ec-qcard')).toHaveLength(1)
  })
  it('can switch an earlier method to Something else and edit its description without retaining stale facts', async () => {
    vi.mocked(reviewCellPayment).mockResolvedValue(cellResult('tax', 'payment'))
    await act(async () => render())
    await click('Fixed amount')
    await click('Something else')
    await type('We repay the cost of required business calls.')
    await click('Done')
    expect(answer.choice).toBe('other')
    expect(answer.cell?.checks).toHaveLength(1)
    await click('Edit description')
    expect(host.querySelector('textarea')?.value).toBe('We repay the cost of required business calls.')
    expect(answer.cell?.checks).toEqual([])
    expect(cellNext(answer)).toMatchObject({ kind: 'question', question: { id: 'method' } })
    await type('We reimburse the business portion of the employee’s phone plan.')
    await click('Done')
    expect(answer.cell?.entries[0].answer).toContain('business portion')
    expect(reviewCellPayment).toHaveBeenCalledTimes(2)
  })
  it('ignores a request after Clear all answers aborts it', async () => {
    let finish!: (result: ReturnType<typeof cellResult>) => void
    vi.mocked(reviewCellPayment).mockImplementation((_input, options) => new Promise(resolve => { finish = resolve }))
    answer = fixedBusiness()
    await act(async () => render())
    const options = vi.mocked(reviewCellPayment).mock.calls[0][1]!
    await click('Clear all answers')
    expect(options.signal?.aborted).toBe(true)
    await act(async () => finish(cellResult()))
    expect(answer.cell).toBeUndefined()
    expect(events.some(event => event.kind === 'checked')).toBe(false)
  })
  it.each([['Taxable', 'review'], ['Not sure', 'customer']])('customer replies keep earlier answers read-only and save %s against the same outstanding question', async (choice, status) => {
    const pending = cellPick(cellChecked(fixedBusiness()), 'tax-allowance', 'unsure')
    let session = sentCell(pending)
    const question = customerQuestionList(session).find(q => q.codes.includes('CELL'))!
    const close = vi.fn()
    const dispatch = (action: SessionAction) => { session = reduceSession(session, action, 123) }
    await act(async () => root.render(<SessionContext.Provider value={{ session, dispatch, save: vi.fn(), restart: vi.fn() }}>
      <CustomerReplyDialog question={question} onClose={close} />
    </SessionContext.Provider>))
    // Dialogs portal into document.body, outside the mount node.
    const dialog = document.querySelector('[role="dialog"]')!
    const method = [...dialog.querySelectorAll<HTMLInputElement>('input[type="radio"]')].find(input => input.checked && input.disabled)
    expect(method).toBeDefined()
    const taxable = [...dialog.querySelectorAll('.sc__title')].find(node => node.textContent?.trim() === choice)?.closest('.sc') as HTMLElement
    await act(async () => taxable.click())
    const save = [...dialog.querySelectorAll('button')].find(button => button.textContent?.trim() === 'Save answer')!
    expect(save.disabled).toBe(false)
    await act(async () => save.click())
    expect(session.resolutions['CELL-purpose'].status).toBe(status)
    expect(session.customerReplies?.[question.id]).toBeDefined()
    expect(close).toHaveBeenCalledOnce()
  })
  it('closing an unsaved dialog aborts requests without changing the session', async () => {
    const draft = reduceCell(fixedBusiness(), { kind: 'defer', checked: true })
    const session = sentCell(draft)
    const before = JSON.stringify(session)
    const question = customerQuestionList(session).find(q => q.codes.includes('CELL'))!
    const dispatch = vi.fn()
    vi.mocked(reviewCellPayment).mockImplementation(() => new Promise(() => undefined))
    await act(async () => root.render(<SessionContext.Provider value={{ session, dispatch, save: vi.fn(), restart: vi.fn() }}>
      <CustomerReplyDialog question={question} onClose={() => root.render(<></>)} />
    </SessionContext.Provider>))
    const leave = [...document.querySelectorAll('button')].find(button => button.textContent?.trim() === 'Leave it open')!
    await act(async () => leave.click())
    expect(dispatch).not.toHaveBeenCalled()
    expect(JSON.stringify(session)).toBe(before)
  })
})
