import { createContext, useContext, type ReactNode } from 'react'
import { SessionContext, useEarningSession } from './sessionContext'
import { discussionReviewBasis, type DiscussionApplication } from './deferredReview'

export const AppliedDiscussionPresentation = createContext(false)
export const useAppliedDiscussion = () => useContext(AppliedDiscussionPresentation)

/** Frozen facts feed the same card components. No reducer or live check may run in this scope. */
export function AppliedDiscussionScope({ card, children }: {
  card: NonNullable<DiscussionApplication['inlineCard']>; children: ReactNode
}) {
  const outer = useEarningSession()
  const session = { ...outer.session, ...card.session, discussionApplications: undefined, appliedReview: undefined }
  if (session.discussionPreview) session.discussionPreview = {
    ...session.discussionPreview, basis: discussionReviewBasis(session),
  }
  return <AppliedDiscussionPresentation.Provider value>
    <SessionContext.Provider value={{ ...outer, session, dispatch: () => {} }}>{children}</SessionContext.Provider>
  </AppliedDiscussionPresentation.Provider>
}
