import { cellFollowUpQuestions, cellQuestionStage, CELL_ID } from './cell'
import { cellNext } from './cellFlow'
import { reimbursementAnswer } from './reimbursements'
import { TIPS_ID, TIPS_METHOD, needsTipsMethod } from './tips'
import { MILEAGE_ID, PER_MILE } from './mileage'
import { MILEAGE_PURPOSE_ID } from '@workspace/setup-shared/mileage-policy'
import { GTL_ID } from './gtlQuestions'
import { ALL_ITEMS, ASK_CUSTOMER, EMPLOYER_CODE_QUESTION, SUGGESTED_CODE, type ReviewItem } from './sampleRegister'
import {
  ACCEPT_NAME, OTHER_PURPOSE, activeCheck, activeNaming, currentRound, isOtherPurpose,
  retentionAsked, retentionOf, sharedSetupFor, shiftPremiumFor,
  type EarningSession, type ItemAnswer, type SessionAction,
} from './session'

/** Presenter-only scripted examples. Turn this off to remove the invisible demo control. */
export const DEMO_FILL_ENABLED = true

/** The per-mile rate the demo types for MILEAGE. The presenter still selects Done. */
export const DEMO_MILEAGE_RATE = '0.50'

export const DEMO_DESCRIPTIONS: Readonly<Record<string, string>> = {
  // A purpose outside the candidate references demonstrates live checking and custom naming.
  // copy-exception(review): User-provided presenter description, kept verbatim under A.7.
  SPPAY: 'A monthly stipend for employees who use a second language with customers',
  // A work-travel reimbursement leaves shift pay for the presenter to confirm in overtime screening.
  // copy-exception(review): User-provided presenter description, kept verbatim under A.7.
  MISC7: 'A daily meal allowance at the federal per diem rate when employees travel overnight for work',
  // A correction demonstrates optional calculation/frequency questions and keeping an old code.
  ADJ2: 'A one-time correction when someone was underpaid in an earlier pay period',
}

interface ScriptedChoice { choice: string; followUps?: Readonly<Record<string, string>> }

/** Demo choices, not customer evidence or automatic production decisions. */
export const DEMO_CHOICES: Readonly<Record<string, ScriptedChoice>> = {
  'VAC-purpose': { choice: 'confirm-purpose' },
  'SICK-purpose': { choice: 'confirm-purpose' },
  'HOL-purpose': { choice: 'confirm-purpose' },
  'JURY-purpose': { choice: 'confirm-purpose' },
  // A bonus recovery is proposed as a deduction in this sample.
  BONREV: { choice: 'accept' },
  // Straight time is paid as regular pay; use only the extra overtime premium.
  OTPREM: { choice: 'premium' },
  // Manufacturing pays the whole overtime hour at time and a half in this demo.
  OTMFG: { choice: 'full' },
  // The sample's fixed monthly amount fits a phone allowance.
  'CELL-purpose': { choice: 'allowance', followUps: { treatment: 'taxable', split: 'confirm' } },
  // Legacy phone-allowance question uses the fixed-amount branch.
  CELL: { choice: 'taxable' },
  // Paying $0.50 for each mile (at or below the IRS rate) demonstrates the reimbursement branch; Done stays manual.
  MILEAGE: { choice: PER_MILE },
  // Use tips paid through payroll rather than reported cash tips.
  TIPS: { choice: 'paycheck-paid' },
  // Demonstrate the proposed earning for employer-provided group term life value.
  [GTL_ID]: { choice: 'yes' },
  // Legacy group term life review accepts its proposed earning classification.
  GTL: { choice: 'accept' },
  // No take-home-pay change fits a reported non-dependent health benefit.
  'IMP INC': { choice: 'health' },
  // One medical deduction with both portions; show the company amount on pay statements.
  'MED ER': { choice: 'only-records', followUps: { 'medical-display': 'yes' } },
  // Legacy HSA review demonstrates adding an employer contribution.
  HSA: { choice: 'employer-contributes' },
  // Legacy employer health cost is reporting-only in the sample.
  ERHLTH: { choice: 'reporting' },
  // Legacy employee retirement contribution stays an employee deduction.
  '401K EE': { choice: 'accept' },
  // Legacy company retirement match becomes an employer contribution.
  '401K ER': { choice: 'accept' },
  // Add the separately confirmed taxable mileage excess when raised.
  'MILEAGE TX': { choice: 'add' },
  // Keep reported cash tips separate from tips paid through payroll.
  'TIPS RPT': { choice: 'add' },
  // Add the missing company HSA contribution.
  'HSA ER': { choice: 'add' },
  // Preserve the older employer HSA finding's proposed contribution.
  'HSA ER-legacy': { choice: 'add' },
}

const ADJ2_FOLLOW_UPS: Readonly<Record<string, string>> = {
  basis: 'flat',
  frequency: 'one-time',
}

function fillUnidentified(item: Extract<ReviewItem, { type: 'unidentified' }>, answer: ItemAnswer): SessionAction[] {
  const description = DEMO_DESCRIPTIONS[item.id]
  if (!description || answer.choice === ASK_CUSTOMER || answer.retain === 'remove' || answer.retain === ASK_CUSTOMER) return []
  const check = activeCheck(item, answer)
  const naming = activeNaming(item, answer)
  const laterAnswers = !!answer.choice || !!answer.retain || !!answer.sharedSetup || !!answer.naming || !!answer.check
    || Object.values(answer.followUps ?? {}).some(Boolean)
  // An AI-written question (or a naming request for detail) is the presenter's to answer, not another scripted response.
  if (check?.kind === 'needsInformation' || naming?.outcome === 'needsInformation') return []
  if (item.id === 'SPPAY' && !item.purposeFirst && !isOtherPurpose(answer)) {
    if (laterAnswers || answer.descriptionSubmitted) return []
    return [
      { type: 'choose', itemId: item.id, choice: OTHER_PURPOSE },
      { type: 'describe', itemId: item.id, description },
    ]
  }
  if (!answer.description && !answer.descriptionSubmitted) return laterAnswers ? []
    : [{ type: 'describe', itemId: item.id, description }]
  // The presenter chooses Done; only a live, current result can reveal the next stage.
  if (!answer.descriptionSubmitted || !check) return []
  if (check.kind === 'followUp') {
    // Answering a follow-up clears dependent choices; never discard anything the presenter selected.
    if (answer.choice || answer.retain || answer.sharedSetup || answer.naming) return []
    if (answer.followUps?.[check.questionId] || item.id !== 'ADJ2' || item.script.kind !== 'described') return []
    const choice = ADJ2_FOLLOW_UPS[check.questionId]
    const question = item.script.questions.find(question => question.id === check.questionId)
    return choice && question?.options.some(option => option.id === choice)
      ? [{ type: 'answerFollowUp', itemId: item.id, questionId: check.questionId, choice }] : []
  }
  if (retentionAsked(item, answer)) {
    if (!retentionOf(answer)) return [{ type: 'chooseRetention', itemId: item.id, choice: 'keep' }]
    if (retentionOf(answer) !== 'keep') return []
  }
  if (!answer.choice && check.kind === 'reference') return [{ type: 'choose', itemId: item.id, choice: 'accept' }]
  if (!answer.choice && item.id === 'SPPAY' && naming?.outcome === 'suggestion') {
    return [{ type: 'choose', itemId: item.id, choice: ACCEPT_NAME }]
  }
  const shared = sharedSetupFor(item, answer)
  if (!shared || answer.sharedSetup?.choice) return []
  // AI-written questions and recommendations belong to the presenter, including in older shift-pay sessions.
  if (shiftPremiumFor(item, answer)) return []
  return [{ type: 'answerSharedSetup', itemId: item.id, referenceId: shared.reference.id, choice: 'separate' }]
}

/** Fill only missing answers in the currently displayed cards, without advancing or confirming descriptions. */
export function demoFill(session: EarningSession, pageItemIds: readonly string[]): SessionAction[] {
  if (!DEMO_FILL_ENABLED || session.step !== 'questions' || currentRound(session)?.submitted) return []
  const actions: SessionAction[] = []
  for (const itemId of new Set(pageItemIds)) {
    const item = ALL_ITEMS.find(item => item.id === itemId)
    if (!item || session.resolutions[itemId]) continue
    const answer = session.answers[itemId] ?? {}
    const payment = reimbursementAnswer(item, answer)
    if (payment) {
      if (payment.cell?.deferred) continue
      const next = cellNext(payment)
      if (next.kind === 'question' && next.question.options) {
        const scripted: Record<string, string> = { [MILEAGE_PURPOSE_ID]: 'A', method: 'per-mile', 'rate-basis': 'company' }
        const value = scripted[next.question.id]
        if (value && next.question.options.some(o => o.id === value)) actions.push({ type: 'cell', itemId, event: { kind: 'answer', id: next.question.id, value } })
      }
      // The presenter answers remaining business/tax questions; no qualification is invented.
      continue
    }
    if (item.type === 'unidentified') {
      actions.push(...fillUnidentified(item, answer))
      continue
    }
    const script = DEMO_CHOICES[itemId]
    if (!script || answer.choice === ASK_CUSTOMER || answer.somethingElse) continue
    if (itemId === GTL_ID) {
      if (!answer.choice) actions.push({ type: 'choose', itemId, choice: script.choice })
      continue
    }
    if (itemId === 'MED ER' && (!answer.choice || answer.choice === 'only-records')) {
      if (!answer.choice) actions.push({ type: 'choose', itemId, choice: 'only-records' })
      if (!answer.conditionalReview?.responses['employer-tax-treatment-v2']) actions.push({
        type: 'conditionalReview', itemId, event: { type: 'answer', questionId: 'employer-tax-treatment-v2', choice: 'tracking-only' },
      })
      continue
    }
    if (itemId === TIPS_ID && (!answer.choice || answer.choice === script.choice)) {
      if (!answer.choice) actions.push({ type: 'choose', itemId, choice: script.choice })
      if (!answer.followUps?.[TIPS_METHOD] && needsTipsMethod({ ...answer, choice: script.choice })) {
        actions.push({ type: 'answerFollowUp', itemId, questionId: TIPS_METHOD, choice: 'payroll' })
      }
    } else if (itemId === CELL_ID) {
      if (answer.cell?.deferred || answer.choice && !answer.cell && !answer.cellLegacy) continue
      if (!answer.cellLegacy) {
        const next = cellNext(answer)
        if (next.kind === 'question' && next.question.options) {
          const choices: Record<string, string> = { method: 'allowance', 'allowance-purpose': 'business', 'allowance-basis': 'estimate',
            'reimbursement-basis': 'expenses', 'tax-allowance': 'taxable', 'tax-reimbursement': 'taxable', 'tax-payment': 'taxable' }
          const value = choices[next.question.id]
          if (value) actions.push({ type: 'cell', itemId, event: { kind: 'answer', id: next.question.id, value } })
        }
        // Live checks remain live; the invisible fill never supplies an AI or tax result.
        continue
      }
      const stage = cellQuestionStage(answer)
      if (stage === 'purpose' && !answer.choice && !Object.values(answer.followUps ?? {}).some(Boolean)) {
        actions.push({ type: 'choose', itemId, choice: script.choice })
      }
      else if (stage && stage !== 'purpose' && !answer.followUps?.[stage]) {
        if (stage === 'treatment' && answer.followUps?.split) continue
        const choice = script.followUps?.[stage]
        const question = cellFollowUpQuestions(answer).find(question => question.id === stage)
        if (choice && question?.options.some(option => option.id === choice)) {
          actions.push({ type: 'answerFollowUp', itemId, questionId: stage, choice })
        }
      }
    } else if (!answer.choice) {
      const offered = item.type === 'misclassification' ? item.accept.id === script.choice : item.options.some(option => option.id === script.choice)
      if (offered) actions.push({ type: 'choose', itemId, choice: script.choice })
      if (offered && itemId === MILEAGE_ID && script.choice === PER_MILE) actions.push({ type: 'enterMileageRate', itemId, amount: DEMO_MILEAGE_RATE })
    } else if (itemId === MILEAGE_ID && answer.choice === PER_MILE && !answer.mileageRate?.amount) {
      actions.push({ type: 'enterMileageRate', itemId, amount: DEMO_MILEAGE_RATE })
    } else if (item.type === 'clarification' && item.employerCode && answer.choice === 'both' && !answer.followUps?.[EMPLOYER_CODE_QUESTION]) {
      // Only our suggestion is scripted; a typed code name stays the customer's own.
      if (script.followUps?.[EMPLOYER_CODE_QUESTION] === SUGGESTED_CODE) {
        actions.push({ type: 'answerFollowUp', itemId, questionId: EMPLOYER_CODE_QUESTION, choice: SUGGESTED_CODE })
      }
    }
  }
  return actions
}