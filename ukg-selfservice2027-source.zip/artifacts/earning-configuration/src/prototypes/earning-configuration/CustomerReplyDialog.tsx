import { useState } from 'react'
import { Dialog } from '@ready/dls/compatibility'
import QuestionCard from './QuestionCard'
import { ItemQuestion } from './StepQuestions'
import { useEarningSession } from './sessionContext'
import { chooseSomethingElse, clearSomethingElseAfter, isSomethingElseAction, nextSomethingElseAnswer, somethingElseQuestion, decisionFor, hasDescribeAnswer, nextDescribedAnswer, nextUncertainMatchAnswer, retentionOf, withNaming, withCheck, answerFollowUp, answerSharedSetup, nextSharedSetupDescription, answerEmployerCode, nextEmployerCodeName, replySomethingElseNote, somethingElseReply, withoutTeamOnly, type ItemAnswer, type SessionAction } from './session'
import { DESCRIBE_CHOICE, findItem } from './sampleRegister'
import { findOptimization } from './optimization'
import { findScreeningQuestion } from './overtime'
import type { SummaryQuestion } from './summary'
import { CELL_ID, isCellQuestion, cellDecision, cellStageFromId, cellQuestionStage, updateCellAnswer } from './cell'
import { CellReplyQuestion } from './CellQuestions'
import { answerReviewBasis, validAnswerReview } from './answerReviewData'
import { medicalProposalKey, medicalTarget } from './medical'
import { conditionalDefinitionFor } from './benefitQuestions'
import { nextConditionalAnswer } from './conditionalAnswer'
import { SOMETHING_ELSE, SOMETHING_ELSE_LABEL } from './somethingElse'
import { phaseNote, type DescribedChoice } from './phaseSomethingElse'
import { DescribeBoxView } from './DescribeAnswerBox'
import { nextMileageRate } from './mileage'
import { TIPS_ID, answerTipsMethod, needsTipsMethod } from './tips'
import CellReplyDialog from './CellReplyDialog'
import TipsReplyDialog from './TipsReplyDialog'

/** Keeps unfinished replies local: closing the dialog never changes the setup. */
export default function CustomerReplyDialog({ question, onClose }: { question: SummaryQuestion; onClose: () => void }) {
  if (question.id.startsWith('tips:')) return <TipsReplyDialog question={question} onClose={onClose} />
  if (question.id.startsWith('classification:CELL-v2-') || question.id.startsWith('reimbursement:')) return <CellReplyDialog question={question} onClose={onClose} />
  return <ExistingCustomerReplyDialog question={question} onClose={onClose} />
}

function ExistingCustomerReplyDialog({ question, onClose }: { question: SummaryQuestion; onClose: () => void }) {
  const { session, dispatch } = useEarningSession()
  const [kind, id] = question.id.split(':')
  const cell = kind === 'classification' && isCellQuestion(id)
  const item = kind === 'classification' && !cell ? findItem(id) : undefined
  const existing = question.reply?.answer
  const [answer, setAnswer] = useState<ItemAnswer>(
    typeof existing === 'object' ? existing
    // A possibly old code the team didn't keep starts over: the customer describes it, answers its follow-ups, then
    // says whether to keep it.
    : item?.type === 'unidentified' && item.retention && retentionOf(session.answers[id]) !== 'keep' ? {} : {
      ...withoutTeamOnly(session.answers[id] ?? {}),
      choice: item?.id === TIPS_ID && needsTipsMethod(session.answers[id]) ? session.answers[id]?.choice
        : item?.type === 'clarification' && item.employerCode && session.answers[id]?.choice === 'both' ? 'both' : undefined,
      followUps: Object.fromEntries(Object.entries(session.answers[id]?.followUps ?? {}).filter(([, value]) => value !== 'ask-customer')),
      // A reply records Keep explicitly, even when older saved progress only implied it.
      ...(item?.type === 'unidentified' && item.retention ? { retain: 'keep' as const } : {}),
    },
  )
  const phase = kind === 'optimization' || kind === 'overtime'
  const [choice, setChoice] = useState(typeof existing === 'string' ? existing
    : cell && typeof existing === 'object' ? existing.somethingElse ? SOMETHING_ELSE : existing.choice ?? ''
      : phase && replySomethingElseNote(existing) ? SOMETHING_ELSE : '')
  // Something else on an Optimization or Overtime question: the customer's description, kept here until it's saved.
  const [phaseReply, setPhaseReply] = useState<DescribedChoice>(() => {
    const note = phase ? replySomethingElseNote(existing) : undefined
    return note ? { description: note, submitted: true } : { description: '' }
  })
  const phaseOption = {
    id: SOMETHING_ELSE, title: SOMETHING_ELSE_LABEL,
    content: <DescribeBoxView description={phaseReply.description} submitted={!!phaseReply.submitted}
      onChange={description => setPhaseReply(previous => previous.submitted ? previous : { description: description.slice(0, 2000) })}
      onDone={() => setPhaseReply(previous => phaseNote({ ...previous, submitted: true }) ? { ...previous, submitted: true } : previous)}
      onEdit={() => setPhaseReply(previous => ({ description: previous.description }))} />,
  }
  const phaseNoteText = phaseNote(phaseReply)
  // Another pick clears the description, as on the step's own questions.
  const selectPhase = (next: string) => {
    if (next !== SOMETHING_ELSE) setPhaseReply({ description: '' })
    setChoice(next)
  }
  // A Something else left on a question that's no longer open isn't part of the reply.
  const { somethingElse: _stale, ...withoutSomethingElse } = answer
  const replyAnswer = item && answer.somethingElse && !somethingElseQuestion(item, answer) ? withoutSomethingElse : answer
  const suggestion = kind === 'optimization' ? findOptimization(id) : undefined
  const screening = kind === 'overtime' ? findScreeningQuestion(id) : undefined
  const cellAnswer = session.answers[CELL_ID] ?? {}
  const cellStage = cellStageFromId(id)
  // CELL's Something else: the customer's description, kept here until it's saved.
  const [cellReply, setCellReply] = useState<ItemAnswer>(cell && typeof existing === 'object' ? existing : {})
  // Something else on the tax or split question: the customer's description for that question, on the setup's answers.
  const cellOtherwise = cellStage !== 'purpose' && choice === SOMETHING_ELSE
  const cellOtherwiseAnswer: ItemAnswer = { choice: cellAnswer.choice,
    ...(cellStage === 'split' ? { followUps: { treatment: cellAnswer.followUps?.treatment ?? '' } } : {}), somethingElse: cellReply.somethingElse }
  const describeCell = (action: SessionAction) => setCellReply(previous => {
    if (cellStage !== 'purpose' && action.type === 'choose') return action.choice === SOMETHING_ELSE ? { somethingElse: { question: cellStage, description: '' } } : {}
    if (isSomethingElseAction(action)) {
      const upstream: ItemAnswer = { ...cellOtherwiseAnswer, somethingElse: previous.somethingElse }
      return { somethingElse: nextSomethingElseAnswer(findItem(CELL_ID), upstream, action).somethingElse }
    }
    return nextDescribedAnswer(findItem(CELL_ID), previous, action)
  })
  const ready = cell ? cellQuestionStage(cellAnswer) === cellStage && !!choice
    && (cellOtherwise ? cellDecision(cellOtherwiseAnswer)?.kind === 'describe' : !!updateCellAnswer(cellAnswer, cellStage, choice))
    && (choice !== DESCRIBE_CHOICE || cellDecision(cellReply)?.kind === 'describe')
    : item ? ['resolve', 'name', 'remove', 'describe'].includes(decisionFor(item, replyAnswer)?.kind ?? '')
      : choice === SOMETHING_ELSE ? phase && !!phaseNoteText : !!choice
  const update = (action: SessionAction) => setAnswer(previous => {
    // Something else works as in the setup: picking it clears that question's answers, and another pick clears it.
    if (item && action.type === 'chooseSomethingElse') return chooseSomethingElse(item, previous, action.question) ?? previous
    if (item && isSomethingElseAction(action)) return nextSomethingElseAnswer(item, previous, action)
    const next = nextReply(previous, action)
    const cleared = clearSomethingElseAfter(action, previous, next)
    return item?.id === 'MED ER' && !cleared.conditionalReview && cleared.choice === 'only-records'
      ? { ...cleared, medicalTarget: medicalTarget(session) } : cleared
  })
  const nextReply = (previous: ItemAnswer, action: SessionAction): ItemAnswer => {
    {
      if (item && conditionalDefinitionFor(item.id) && (action.type === 'choose' || action.type === 'conditionalReview')) {
        return nextConditionalAnswer(item.id, previous, action)
      }
      if (action.type === 'acceptMedicalSetup') return medicalProposalKey(previous) === action.proposal
        ? { ...previous, medicalAccepted: action.proposal } : previous
      if (item?.id === 'MED ER' && action.type === 'answerFollowUp') return {
        ...previous, medicalTarget: medicalTarget(session),
        followUps: { ...previous.followUps, [action.questionId]: action.choice },
      }
      if (action.type === 'answerReview') return action.review.basis === answerReviewBasis(previous) && validAnswerReview(action.review)
        ? { ...previous, reviews: { ...previous.reviews, [action.key]: action.review } } : previous
      if (action.type === 'omitCode') return { ...previous, retain: action.remove ? 'remove' : undefined }
      if (item && action.type === 'answerSharedSetup') return answerSharedSetup(item, previous, action.referenceId, action.choice)
      if (item && (action.type === 'describeSharedSetup' || action.type === 'submitSharedSetupDescription' || action.type === 'editSharedSetupDescription')) {
        return nextSharedSetupDescription(item, previous, action)
      }
      if (item && hasDescribeAnswer(item) && ['choose', 'describe', 'submitDescription', 'editDescription'].includes(action.type)) {
        return nextDescribedAnswer(item, previous, action)
      }
      if (item?.type === 'unidentified' && item.script.kind === 'uncertainMatch'
        && ['choose', 'describe', 'submitDescription', 'editDescription'].includes(action.type)) {
        return nextUncertainMatchAnswer(previous, action)
      }
      // As in the setup, a changed description or follow-up answer clears a later keep-or-remove choice.
      const { retain: _retain, ...earlier } = previous
      switch (action.type) {
        case 'choose': return { ...previous, retain: previous.retain === 'remove' ? undefined : previous.retain, choice: action.choice, sharedSetup: previous.choice === action.choice ? previous.sharedSetup : undefined, ...(item?.type === 'clarification' && item.employerCode ? { followUps: {}, employerCodeName: undefined } : {}), ...(previous.choice !== action.choice ? { mileageRate: undefined, ...(item?.id === TIPS_ID ? { followUps: undefined } : {}) } : {}) }
        case 'describe': return { ...earlier, description: action.description, naming: undefined, sharedSetup: undefined }
        case 'submitDescription': return previous.description?.trim() ? { ...earlier, descriptionSubmitted: true, choice: undefined, followUps: {}, naming: undefined, check: undefined, sharedSetup: undefined } : previous
        case 'chooseRetention': return action.choice === 'ask-customer' || action.choice === '' ? earlier
          : { ...previous, retain: action.choice, ...(action.choice === 'remove' ? { choice: undefined } : {}) }
        case 'editDescription': return { description: previous.description }
        case 'answerFollowUp': return item?.id === TIPS_ID ? answerTipsMethod(previous, action.questionId, action.choice)
          : item?.type === 'unidentified' ? answerFollowUp(item, previous, action.questionId, action.choice)
          // DEN's employer-code follow-up keeps the shared-cost answer; another code opens the name box.
          : item?.type === 'clarification' && item.employerCode ? previous.choice === 'both' ? answerEmployerCode(previous, action.choice) : previous
          : { ...earlier, choice: undefined, followUps: { ...previous.followUps, [action.questionId]: action.choice }, naming: undefined }
        case 'nameEmployerCode':
        case 'submitEmployerCodeName':
        case 'editEmployerCodeName': return item ? nextEmployerCodeName(item, previous, action) : previous
        // MILEAGE's per-mile rate uses the same field, checks and Done as the setup.
        case 'enterMileageRate':
        case 'submitMileageRate':
        case 'editMileageRate': return nextMileageRate(previous, action)
        case 'setNaming': return item ? withNaming(item, previous, action.basis, action.result, Date.now()) : previous
        case 'checkDescription': return item ? withCheck(item, previous, action.basis, action.result, Date.now()) : previous
        default: return previous
      }
    }
  }
  return (
    <Dialog open onClose={onClose} title={question.codes.length ? `Customer answer: ${question.codes.join(', ')}` : 'Customer answer'}
      secondaryAction={{ label: 'Leave it open', onClick: onClose }}
      primaryAction={{ label: 'Save answer', disabled: !ready, onClick: () => {
        if (!ready) return
        dispatch({ type: 'saveCustomerReply', questionId: question.id, answer: item ? replyAnswer
          : cell && cellOtherwise ? { somethingElse: cellReply.somethingElse }
          : cell && choice === DESCRIBE_CHOICE ? { choice, description: cellReply.description, descriptionSubmitted: true }
          : phase && choice === SOMETHING_ELSE && phaseNoteText ? somethingElseReply(phaseNoteText) : choice })
        onClose()
      } }}>
      <p className="text-body ec-intro">Use the customer’s reply to finish this part of the setup. Nothing changes until you save.</p>
      {kind === 'classification' && <section aria-label="Question for the customer">
        <h2 className="text-caption ec-eyebrow">What we asked the customer</h2>
        {question.question.split('\n\n').map((text, index) => <p className="text-body" key={index}>{text}</p>)}
      </section>}
      {cell && <CellReplyQuestion stage={cellStage} answer={cellAnswer} choice={choice} reply={cellReply} onDescribe={describeCell}
        onSelect={next => { setChoice(next); describeCell({ type: 'choose', itemId: CELL_ID, choice: next }) }} />}
      {item && <ItemQuestion item={item} label={item.code} answer={answer} onAnswer={update} />}
      {suggestion && <QuestionCard label={suggestion.codes.join(', ')} sourceItemId={suggestion.codes} question={suggestion.question} context={suggestion.context}
        answered={!!choice} selected={choice} onSelect={selectPhase}
        options={[
          { id: 'accept', title: suggestion.accept.title, subHeading: suggestion.accept.detail },
          { id: 'keep', title: suggestion.keep.title, subHeading: suggestion.keep.detail },
          phaseOption,
        ]} />}
      {screening && <QuestionCard label={question.codes.join(', ')} sourceItemId={question.codes} question={screening.question} context={screening.reason}
        answered={!!choice} selected={choice} onSelect={selectPhase}
        options={[{ id: 'yes', title: 'Yes' }, { id: 'no', title: 'No' }, phaseOption]} />}
      {!ready && <p className="text-body">Choose an answer before saving. If the customer isn’t sure yet, choose Leave it open to keep the question on the list.</p>}
    </Dialog>
  )
}
