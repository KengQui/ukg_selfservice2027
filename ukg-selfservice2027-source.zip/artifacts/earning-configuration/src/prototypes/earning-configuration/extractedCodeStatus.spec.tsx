import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import ReviewStatusPanel from './ReviewStatusPanel'
import { sessionCodeStatus } from './sessionCodeStatus'
import { createSession, parseSession, reduceSession, reviewPages, type EarningSession } from './session'
import { ASK_CUSTOMER, findItem, READY } from './sampleRegister'
import { LEGACY_PERIOD_REGISTERS, PREVIOUS_EARNINGS_REGISTERS, SAMPLE_REGISTER_FILES } from './sampleDocument'
import { EARNING_DEMO_SETTINGS } from './demoSettings'
import { consolidateRegisters } from './registerEvidence'
import { preparationSummary } from './readinessSummary'

// Explicit evidence and review state: independent of evolving demo answers and page gating.
const fixture = (): EarningSession => ({
  ...createSession(1), registerSource: 'sample', files: SAMPLE_REGISTER_FILES.map(file => ({ ...file })),
  step: 'questions', rounds: [{ number: 1, itemIds: ['SPPAY', 'MILEAGE', 'CELL-purpose', 'MISC7'], submitted: false }],
})
const codes = (session: EarningSession) => sessionCodeStatus(session).rows.map(row => row.code)
const uploaded = (): EarningSession => ({
  ...fixture(), registerSource: 'uploads', files: [
    ...SAMPLE_REGISTER_FILES,
    ...['one', 'two', 'three'].map((id, index) => ({
      id, name: `${id}.csv`, sizeBytes: 1, docType: 'Pay register', status: 'ready' as const,
      evidence: { warnings: [], reports: [{
        company: 'Example', companyId: index === 2 ? 'B' : 'A',
        periodStart: null, periodEnd: null, periodLabel: null, reportId: null, currency: null,
        rows: [
          { code: 'REG', description: 'Pay', section: 'earnings' as const, amount: 1, people: 1, amountLabel: 'Pay', locator: '1', quote: 'REG Pay' },
          { code: 'REG', description: 'Repayment', section: 'deductions' as const, amount: 1, people: 1, amountLabel: 'Pay', locator: '2', quote: 'REG Repayment' },
        ],
      }] },
    })),
  ],
})

describe('extracted code status inventory', () => {
  it('keeps matched sources but hides unresolved optional sources and catalog-only or retired plan rows', () => {
    const session = fixture()
    EARNING_DEMO_SETTINGS.hideOptionalQuestions = true
    try {
      const model = sessionCodeStatus(session)
      expect(codes(session)).toEqual(expect.arrayContaining(['REG', 'TIPS OWED']))
      expect(codes(session).filter(code => ['MISC7', 'CELL', 'IMP INC'].includes(code))).toEqual([])
      expect(codes(session)).not.toEqual(expect.arrayContaining(['SAL']))
      expect(model.rows.some(row => ['DEN', '401K EE', 'SHIFT2'].includes(row.code))).toBe(false)
      expect(model.rows.filter(row => row.unit === 'plan')).toHaveLength(0)
      expect(model.rows.find(row => row.code === 'REG')).toMatchObject({ status: 'ready', reference: READY.regular.name })
      expect(new Set(codes(session)).size).toBe(model.rows.length)
      expect(codes({ ...session, files: session.files.slice(0, 1) })).toEqual(codes(session))
    } finally {
      EARNING_DEMO_SETTINGS.hideOptionalQuestions = false
    }
  })

  it.each([{ registers: LEGACY_PERIOD_REGISTERS }, { registers: PREVIOUS_EARNINGS_REGISTERS }])('uses attached older document identities even with current answer history', ({ registers }) => {
    const session = fixture()
    session.files = registers.map(register => ({ ...register.file }))
    session.rounds[0].itemIds.push('TIPS OWED')
    session.answers['TIPS OWED'] = { choice: ASK_CUSTOMER }
    const before = JSON.stringify(session)
    expect(codes(session)).toContain('SAL')
    expect(sessionCodeStatus(session).rows.find(row => row.code === 'SAL')).toMatchObject({ status: 'ready', reference: READY.salary.name })
    expect(codes(session)).not.toContain('TIPS OWED')
    expect(sessionCodeStatus(session).questions.some(question => question.codes.includes('TIPS OWED'))).toBe(false)
    expect(codes(parseSession(before)!)).toEqual(codes(session))
    expect(JSON.stringify(session)).toBe(before)
  })

  it('changes membership on individual removals without changing answers or saved notes', () => {
    let session = fixture()
    session.files = [PREVIOUS_EARNINGS_REGISTERS[0].file, SAMPLE_REGISTER_FILES[1]]
    session.answers.MISC7 = { description: 'Keep this answer' }
    session.callAnswers = { SAL: 'Keep this note' }
    expect(codes(session)).toEqual(expect.arrayContaining(['SAL', 'TIPS OWED']))
    session = reduceSession(session, { type: 'removeRegister', id: PREVIOUS_EARNINGS_REGISTERS[0].file.id })
    expect(codes(session)).not.toContain('SAL')
    expect(codes(parseSession(JSON.stringify(session))!)).toEqual(codes(session))
    session = reduceSession(session, { type: 'removeRegister', id: SAMPLE_REGISTER_FILES[1].id })
    expect(codes(session)).toEqual([])
    expect(session.answers.MISC7.description).toBe('Keep this answer')
    expect(session.callAnswers?.SAL).toBe('Keep this note')
  })

  it('does not infer inventory from resolutions and keeps generated findings subordinate', () => {
    const session = fixture()
    session.rounds[0].itemIds.push('MILEAGE TX')
    session.resolutions['MILEAGE TX'] = { status: 'customer', round: 1 }
    session.customerQuestions.push({ itemId: 'MILEAGE TX', code: 'MILEAGE TX', type: 'finding', question: findItem('MILEAGE TX').customerQuestion, round: 1 })
    session.resolutions['CELL-purpose'] = { status: 'resolved', round: 1, reference: READY.cellAllowance,
      outputs: [{ code: 'CELL-ALLOW', reference: READY.cellAllowance }] }
    expect(sessionCodeStatus(session).rows.find(row => row.code === 'CELL')?.outputs[0].code).toBe('CELL-ALLOW')
    expect(codes(session)).not.toContain('CELL-ALLOW')
    expect(sessionCodeStatus(session).rows.find(row => row.code === 'MILEAGE')?.outputs[0].code).toBe('MILEAGE TX')
    expect(sessionCodeStatus(session).questions.some(question => question.codes.includes('MILEAGE TX'))).toBe(true)
    const empty = sessionCodeStatus({ ...session, files: [] })
    expect(empty.rows).toEqual([])
    expect(empty.questions).toEqual([])
  })

  it('keeps general overtime questions when no source code applies', () => {
    const session = fixture()
    session.files = []
    session.step = 'overtime'
    session.overtime.answers.multiRate = 'no'
    session.overtime.answers.shiftDiff = ASK_CUSTOMER
    expect(sessionCodeStatus(session).questions).toEqual(expect.arrayContaining([
      expect.objectContaining({ id: 'overtime:shiftDiff', codes: [] }),
    ]))
  })

  it('preserves uploaded company and meaning boundaries, notes and removal semantics', () => {
    const session = uploaded()
    const groups = consolidateRegisters(session.files)
    session.callAnswers = { [groups[0].id]: 'Customer note' }
    expect(sessionCodeStatus(session).rows).toHaveLength(4)
    expect(sessionCodeStatus(session).rows[0].status).toBe('notes-added')
    const remaining = reduceSession(session, { type: 'removeRegister', id: 'three' })
    expect(sessionCodeStatus(remaining).rows).toHaveLength(2)
    expect(sessionCodeStatus(remaining).rows.every(row => row.code === 'REG' && !row.target && !row.reference)).toBe(true)
    expect(sessionCodeStatus({ ...remaining, files: [] }).rows).toEqual([])
  })
})

let root: Root
let host: HTMLDivElement
beforeEach(() => {
  (globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
  host = document.createElement('div')
  document.body.append(host)
  root = createRoot(host)
})
afterEach(() => {
  act(() => root.unmount())
  host.remove()
})
const panel = () => document.querySelector('.ec-status-panel')!
const render = (session: EarningSession, navigate = vi.fn()) => {
  act(() => root.render(<ReviewStatusPanel open session={session} currentPage={0} onGoToPage={navigate} onClose={() => {}} />))
  return navigate
}

describe('extracted inventory in the panel', () => {
  it.each(['questions', 'review', 'optimization', 'overtimeAssessment', 'summary'] as const)('counts only visible source rows during %s', step => {
    const session = { ...fixture(), step }
    render(session)
    const rows = panel().querySelectorAll('.ec-status-row')
    expect(rows).toHaveLength(sessionCodeStatus(session).rows.length)
    const counts = preparationSummary(session)
    expect(panel().querySelector('.ec-status-panel__summary')?.textContent).toBe(
      `${counts.total} earning codes · ${counts.matched} Ready for setup · ${counts.needInput} ${counts.needInput === 1 ? 'needs' : 'need'} review`)
    expect(panel().querySelector('[aria-label="Benefit plans"]')).toBeNull()
    expect([...panel().querySelectorAll('.ec-status-row__code')].map(node => node.textContent)).not.toContain('SAL')
  })

  it('keeps navigation for a retained code and reconciles questions and empty state on rerender', () => {
    const session = fixture()
    session.answers.SPPAY = { choice: ASK_CUSTOMER }
    const page = reviewPages(session).findIndex(ids => ids.includes('SPPAY'))
    session.reviewCursor = page
    const navigate = render(session)
    expect(sessionCodeStatus(session).rows.find(row => row.code === findItem('SPPAY').code)?.target).toEqual({ page, itemId: 'SPPAY' })
    const source = [...panel().querySelectorAll('.ec-status-row')].find(row => row.querySelector('.ec-status-row__code')?.textContent === findItem('SPPAY').code)!
    const link = source.querySelector<HTMLButtonElement>('.ec-status-row__code button')!
    act(() => link.click())
    expect(navigate).toHaveBeenCalledWith(page, 'SPPAY')
    expect(panel().querySelector('.ec-status-deferred')?.textContent).toContain(findItem('SPPAY').customerQuestion)
    render({ ...session, files: [] })
    expect(panel().querySelectorAll('.ec-status-row')).toHaveLength(0)
    expect(panel().querySelectorAll('.ec-status-deferred__item')).toHaveLength(0)
    expect(panel().textContent).toContain('No codes could be read.')
    expect(session.answers.SPPAY.choice).toBe(ASK_CUSTOMER)
  })

  it('counts uploaded meanings instead of sample rows', () => {
    render(uploaded())
    expect(panel().querySelectorAll('.ec-status-row')).toHaveLength(4)
    expect(panel().querySelectorAll('.ec-status-group')).toHaveLength(2)
    expect(panel().querySelector('.ec-status-panel__summary')?.textContent).toBe('4 codes · 0 Ready for setup · 4 need review')
  })
})
