import type { DiscussionAnswer, DiscussionOption } from './discussionFormats'

export interface DiscussionInput {
  options: readonly DiscussionOption[]
  answer?: DiscussionAnswer
}

/** Capture only, not assessment or approval. Keep this identical to the preview-entry gate. */
export function discussionInputIssue({ answer, options }: DiscussionInput): 'answer' | 'choice' | 'details' | 'length' | undefined {
  if (!options.length) {
    if (answer?.kind !== 'text' || !answer.text?.trim()) return 'answer'
    return answer.text.length > 2000 ? 'length' : undefined
  }
  const selected = options.find(option => option.id === answer?.choice)
  if (answer?.kind !== 'review-choices' || !selected) return 'choice'
  return selected.details && !answer.details?.[selected.id]?.trim() ? 'details' : undefined
}

export const discussionInputComplete = (entry: DiscussionInput) => !discussionInputIssue(entry)

export function discussionProgress(entries: readonly DiscussionInput[]) {
  const entered = entries.filter(discussionInputComplete).length
  return { entered, total: entries.length, remaining: entries.length - entered,
    complete: entries.length > 0 && entered === entries.length }
}

export const DISCUSSION_INPUT_HELP = {
  answer: 'Enter an answer.',
  choice: 'Select an answer.',
  details: 'Add details for the answer you selected.',
  length: 'Shorten your answer to 2,000 characters or fewer.',
}
