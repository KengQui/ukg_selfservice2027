import { renderToStaticMarkup } from 'react-dom/server'
import { act } from 'react'
import { createRoot } from 'react-dom/client'
import { describe, expect, it } from 'vitest'
import AddedCodesSection from './AddedCodesSection'
import { SessionContext } from './sessionContext'
import { createSession } from './session'
import { reduceAddedCodes, type AddedCodesState } from './addedCodes'

function render(addedCodes?: AddedCodesState) {
  return new DOMParser().parseFromString(renderToStaticMarkup(
    <SessionContext.Provider value={{
      session: { ...createSession(0), addedCodes },
      dispatch: () => {}, save: () => true, restart: () => true,
    }}>
      <AddedCodesSection />
    </SessionContext.Provider>,
  ), 'text/html')
}

describe('Codes you added', () => {
  it('adds a matched referral to the setup plan without another action', async () => {
    Object.assign(globalThis, { IS_REACT_ACT_ENVIRONMENT: true })
    let state: AddedCodesState = { entries: [{
      id: 'referral', code: '', name: '', description: 'Referral pay',
      check: { status: 'result', token: 'test', result: {
        outcome: 'match', summary: 'Referral bonus', facts: ['Employee referral'], question: null, reason: '',
        reference: { id: 'demo-employee-referral-bonus', name: 'Employee referral bonus', library: 'demo' },
      } },
    }] }
    const host = document.createElement('div')
    const root = createRoot(host)
    const draw = () => root.render(<SessionContext.Provider value={{
      session: { ...createSession(0), addedCodes: state },
      dispatch: action => {
        if (action.type === 'addedCodes') { state = reduceAddedCodes(state, action.event); draw() }
      }, save: () => true, restart: () => true,
    }}><AddedCodesSection /></SessionContext.Provider>)
    try {
      await act(async () => draw())
      expect(state.entries[0]).toMatchObject({ code: 'REFBON', name: 'Referral bonus',
        plan: { referenceId: 'demo-employee-referral-bonus' } })
      expect(host.querySelector('[data-testid="text-added-referral-referral"]')?.textContent).toContain('REFBON — Referral bonus')
      expect(host.querySelector('[data-testid="button-confirm-added-referral"]')).toBeNull()
      const defer = host.querySelector<HTMLInputElement>('#checkbox-defer-added-referral')!
      expect(defer.closest('.ec-defer')).not.toBeNull()
      await act(async () => defer.click())
      expect(state.entries[0].deferred).toBe(true)
      expect(state.entries[0].plan).toBeUndefined()
      expect(host.textContent).toContain('It isn’t in your setup plan.')
      await act(async () => defer.click())
      expect(state.entries[0].deferred).toBeUndefined()
      expect(state.entries[0].plan).toBeDefined()
      await act(async () => host.querySelector<HTMLButtonElement>('[data-testid="button-change-added-referral"]')!.click())
      expect(host.textContent).toContain('What would you like to change about this earning code?')
      expect(host.querySelector('[data-sequence-number="01"]')).not.toBeNull()
      expect(host.querySelector('[data-testid="form-added-code"]')).toBeNull()
      expect(host.querySelector('[data-testid="input-added-reply-referral"]')).not.toBeNull()
      expect(state.entries[0].plan).toBeUndefined()
      expect(state.entries[0].description).toBe('Referral pay')
      expect(state.entries[0].code).toBe('')
    } finally { await act(async () => root.unmount()) }
  })
  it('shows the approved referral code and description without match actions or repeated evidence', () => {
    const doc = render({ entries: [{
      id: 'referral', code: '', name: '', description: 'Referral pay',
      check: { status: 'result', token: 'test', result: {
        outcome: 'match', summary: 'Repeated answer', facts: ['Repeated fact'], question: null, reason: '',
        reference: { id: 'demo-employee-referral-bonus', name: 'Employee referral bonus', library: 'demo' },
      } },
    }] })
    const result = doc.querySelector('[data-testid="text-added-referral-referral"]')!
    expect(result.textContent).toContain('REFBON — Referral bonus')
    expect(result.textContent).toContain('We’ll set up REFBON for bonuses paid to employees when someone they refer is hired.')
    expect(result.textContent).not.toMatch(/Proposed match|Repeated answer|Repeated fact|Can we add/)
    expect(result.querySelector('button, a, svg')).toBeNull()
  })
  it.each([undefined, { entries: [] }, { entries: [], none: true }] as const)(
    'keeps Add a code available without the removed extras (%j)', state => {
      const doc = render(state as AddedCodesState | undefined)
      expect(doc.querySelector('[data-testid="button-add-code"]')).not.toBeNull()
      expect(doc.querySelector('input[type="checkbox"]')).toBeNull()
      expect(doc.body.textContent).not.toContain('I don’t have any codes to add')
      expect(doc.body.textContent).not.toContain('We’ll review each code you add before it’s set up.')
      expect(doc.querySelector('.ec-added')?.lastElementChild?.className).toBe('ec-added__add')
    },
  )

  it('preserves the form, saved list, edit and remove controls', () => {
    let state = reduceAddedCodes(undefined, { kind: 'start' })
    expect(render(state).querySelector('[data-testid="form-added-code"]')).not.toBeNull()
    state = reduceAddedCodes(state, { kind: 'change', field: 'name', value: 'Bonus' })
    state = reduceAddedCodes(state, { kind: 'change', field: 'description', value: 'Annual payment' })
    state = reduceAddedCodes(state, { kind: 'save' })
    const doc = render(state)
    expect(doc.body.textContent).toContain('Awaiting setup review')
    const actions = doc.querySelector('.ec-added__actions')!
    expect(actions.textContent).toContain('Edit')
    expect(actions.textContent).toContain('Remove')
    state = reduceAddedCodes(state, { kind: 'edit', id: 'added-1' })
    expect(render(state).body.textContent).toContain('Save changes')
    state = reduceAddedCodes(state, { kind: 'remove', id: 'added-1' })
    expect(render(state).querySelector('[data-testid="button-add-code"]')).not.toBeNull()
  })
})
