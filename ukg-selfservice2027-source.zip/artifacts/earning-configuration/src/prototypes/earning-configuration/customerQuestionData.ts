import type { EarningCustomerQuestionDraft } from '@workspace/api-client-react'
import type { CustomerQuestion, EarningSession, ItemAnswer } from './session'
import { CELL_ID, cellCustomerQuestion, cellQuestionStage } from './cell'
import { validAnswerKinds } from './discussionFormats'
import { customerQuestionFor } from './session'
import { findItem, isReviewItem } from './sampleRegister'
import { reimbursementAnswer } from './reimbursements'

export interface SavedCustomerDraft extends EarningCustomerQuestionDraft { basis: string }

/** Canonical full answer snapshot; object insertion order cannot change a draft's identity. */
export function customerDraftBasis(answer: ItemAnswer = {}): string {
  const canonical = (value: unknown): unknown => Array.isArray(value) ? value.map(canonical)
    : value && typeof value === 'object' ? Object.fromEntries(Object.entries(value)
      .filter(([, entry]) => entry !== undefined).sort(([a], [b]) => a.localeCompare(b))
      .map(([key, entry]) => [key, canonical(entry)])) : value
  const { explicitDeferral: _selection, ...facts } = answer
  return JSON.stringify(canonical(facts))
}

export function validCustomerDraft(value: unknown): value is EarningCustomerQuestionDraft {
  if (!value || typeof value !== 'object') return false
  const draft = value as EarningCustomerQuestionDraft
  return Array.isArray(draft.questions) && draft.questions.length >= 1 && draft.questions.length <= 3
    && draft.questions.every(question => typeof question === 'string' && !!question.trim() && question.length <= 500 && question.trim().endsWith('?'))
    && new Set(draft.questions.map(question => question.trim().toLowerCase())).size === draft.questions.length
    && typeof draft.reason === 'string' && !!draft.reason.trim() && draft.reason.length <= 600
    && (draft.answerKinds === undefined || validAnswerKinds(draft.answerKinds, draft.questions.length))
}

export function currentCustomerDraft(session: EarningSession, question: CustomerQuestion | undefined): SavedCustomerDraft | undefined {
  const draft = question?.draft
  return draft && validCustomerDraft(draft) && draft.basis === customerDraftBasis(session.answers[question!.itemId]) ? draft : undefined
}

/** Older CELL saves kept the opening wording after a partial reply advanced the question stage. */
export function standardCustomerQuestion(session: EarningSession, question: CustomerQuestion): string {
  const payment = isReviewItem(question.itemId) ? reimbursementAnswer(findItem(question.itemId), session.answers[question.itemId]) : undefined
  if (payment) return customerQuestionFor(findItem(question.itemId), payment)
  // Refresh only the obsolete unsent standard template, never AI drafts or call/sent history.
  if (question.itemId === 'ADJ2'
    && question.question.startsWith('The pay register data lists ADJ2 with no payments in the last 12 months.')
    && session.resolutions.ADJ2?.status === 'customer'
    && !session.sent?.questionIds.includes('classification:ADJ2')
    && !session.customerReplies?.['classification:ADJ2']) {
    return customerQuestionFor(findItem('ADJ2'), session.answers.ADJ2)
  }
  const answer = session.answers[question.itemId]
  const stage = question.itemId === CELL_ID ? cellQuestionStage(answer) : undefined
  return stage && stage !== 'purpose' ? cellCustomerQuestion(stage, answer) : question.question
}

/** Current drafts override the standard question; historical sent snapshots are kept separately. */
export function customerQuestionText(session: EarningSession, question: CustomerQuestion): string {
  return currentCustomerDraft(session, question)?.questions.join('\n\n') ?? standardCustomerQuestion(session, question)
}
