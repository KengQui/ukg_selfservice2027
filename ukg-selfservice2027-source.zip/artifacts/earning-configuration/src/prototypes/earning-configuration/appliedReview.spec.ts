import { describe, expect, it } from 'vitest'
import {
  appliedReviewSession, createSession, currentRound, parseSession, reduceSession, reviewPages,
  type EarningSession, type SessionAction,
} from './session'
import { ASK_CUSTOMER, findItem } from './sampleRegister'
import { OPTIMIZATIONS } from './optimization'
import { browserStores, loadSession, saveSession, writeWorkingCopy } from './storage'

const run = (session: EarningSession, ...actions: SessionAction[]) =>
  actions.reduce((state, action) => reduceSession(state, action, 1000), session)
const review = () => {
  // A completed required answer, not the former demo bypass of unselected Defer.
  const open: EarningSession = { ...createSession(1), step: 'questions',
    reviewLayout: 'business-topics', reviewTopicOrder: 3,
    rounds: [{ number: 1, itemIds: ['BONREV'], submitted: false }] }
  return run(open, { type: 'choose', itemId: 'BONREV', choice: 'accept' },
    { type: 'submitRound' })
}

describe('applied review navigation', () => {
  it.each([undefined, 'findings', 'added-questions'] as const)('preserves the open round and all review data with %s pending', kind => {
    const saved = { ...review(), callAnswers: { MILEAGE: 'Keep the note.' } }
    const session: EarningSession = kind ? { ...saved, step: 'questions', reviewCursor: 0, rounds: [
      ...saved.rounds, { number: 2, itemIds: ['MILEAGE TX'], submitted: false,
        ...(kind === 'added-questions' ? { kind } : {}) },
    ] } : saved
    const back = run(session, { type: 'viewAppliedReview' })
    const view = appliedReviewSession(back)!
    expect(view.rounds).toEqual([session.rounds[0]])
    expect(back.appliedReview).toEqual({ round: 1, cursor: reviewPages(view).length - 1 })
    expect(back.reviewCursor).toBe(session.reviewCursor)
    expect(back.rounds).toBe(session.rounds)
    expect(back.answers).toBe(session.answers)
    expect(back.customerQuestions).toBe(session.customerQuestions)
    expect(parseSession(JSON.stringify(back))).toEqual(back)
    const previous = run(back, { type: 'moveAppliedReview', index: 0 })
    expect(previous.appliedReview?.cursor).toBe(0)
    expect(parseSession(JSON.stringify(previous))).toEqual(previous)
    for (const action of [
      { type: 'submitRound' }, { type: 'nextRound' }, { type: 'complete' },
      { type: 'choose', itemId: 'BONREV', choice: 'accept' },
      { type: 'clearAnswers', itemId: 'BONREV' },
      { type: 'moveReview', index: 0 },
    ] as SessionAction[]) expect(run(previous, action)).toBe(previous)
    expect(run(previous, { type: 'closeAppliedReview' })).toEqual({ ...session, updatedAt: 1000 })
  })

  it('returns to the latest applied finding round, not the initial round', () => {
    const initial = review()
    const item = findItem('MILEAGE TX')
    if (item.type !== 'finding') throw new Error('fixture')
    const later = run({ ...initial, step: 'questions', rounds: [
      ...initial.rounds, { number: 2, itemIds: ['MILEAGE TX'], submitted: false },
    ] }, { type: 'choose', itemId: item.id, choice: ASK_CUSTOMER },
      { type: 'selectDeferredQuestion', itemId: item.id, source: {
        question: item.question, choices: item.options.map(option => option.label),
        options: item.options.map(option => ({ id: option.id, label: option.label })),
      } }, { type: 'submitRound' })
    const back = run(later, { type: 'viewAppliedReview' })
    expect(back.appliedReview).toEqual({ round: 2, cursor: 0 })
    expect(reviewPages(appliedReviewSession(back)!)).toEqual([['MILEAGE TX']])
  })

  it('restores both working and explicitly saved views without altering downstream progress', () => {
    sessionStorage.clear(); localStorage.clear()
    const later = run(review(), { type: 'complete' },
      ...OPTIMIZATIONS.map(suggestion => ({ type: 'chooseOptimization' as const, suggestionId: suggestion.id, choice: 'keep' as const })),
      { type: 'submitOptimization' }, { type: 'completeOptimization' },
      { type: 'answerOvertime', questionId: 'multiple-rates', answer: 'no' })
    expect(later.step).toBe('overtime')
    const session = run(later, { type: 'goTo', step: 'review' }, { type: 'viewAppliedReview' }, { type: 'moveAppliedReview', index: 0 })
    writeWorkingCopy(browserStores(), session)
    expect(loadSession(browserStores())).toEqual(session)
    expect(saveSession(browserStores(), session)).toBe(true)
    sessionStorage.clear()
    const restored = loadSession(browserStores())
    expect(restored).toEqual(session)
    const closed = run(restored, { type: 'closeAppliedReview' })
    expect(closed.answers).toEqual(later.answers)
    expect(closed.resolutions).toEqual(later.resolutions)
    expect(closed.optimization).toEqual(later.optimization)
    expect(closed.overtime).toEqual(later.overtime)
    expect(closed.customerQuestions).toEqual(later.customerQuestions)
    expect(closed.files).toEqual(later.files)
    expect(run(closed, { type: 'complete' }).step).toBe(later.step)
    sessionStorage.clear(); localStorage.clear()
  })

  it('rejects invalid moves, ignores uploaded reviews, and drops a stale view on restore', () => {
    const session = review()
    const back = run(session, { type: 'viewAppliedReview' })
    for (const index of [-1, 999, 0.5]) expect(run(back, { type: 'moveAppliedReview', index })).toBe(back)
    const uploaded = { ...session, registerSource: 'uploads' as const }
    expect(run(uploaded, { type: 'viewAppliedReview' })).toBe(uploaded)
    expect(run(createSession(1), { type: 'viewAppliedReview' }).appliedReview).toBeUndefined()
    expect(parseSession(JSON.stringify({ ...back, appliedReview: { round: 999, cursor: 0 } }))?.appliedReview).toBeUndefined()
    expect(parseSession(JSON.stringify({ ...back, appliedReview: { round: 1, cursor: -1 } }))).toBeNull()
    expect(parseSession(JSON.stringify({ ...back, appliedReview: { round: 1, cursor: 999 } }))?.appliedReview?.cursor)
      .toBe(back.appliedReview!.cursor)
    expect(run(back, { type: 'goTo', step: 'intro' }).appliedReview).toBeUndefined()
  })
})
