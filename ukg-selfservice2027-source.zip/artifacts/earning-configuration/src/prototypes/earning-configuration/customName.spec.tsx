import { reduceChecked } from './scriptedChecks.testing'
import { act, StrictMode } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { suggestEarningName } from '@workspace/api-client-react'
import StepQuestions from './StepQuestions'
import CustomNameSection from './CustomNameSection'
import { SessionContext } from './sessionContext'
import { ASK_CUSTOMER, REVIEW_INITIAL_ITEMS, findItem } from './sampleRegister'
import {
  ACCEPT_NAME, KEEP_NAME, activeNaming, classificationStatus, createSession, decisionFor, lookupResult, namingBasis, parseSession, reduceSession,
  type EarningSession, type SessionAction,
} from './session'
import { configurationCounts, finalConfiguration } from './configuration'
import { SCREENING_QUESTIONS, sortEarnings } from './overtime'
import { OPTIMIZATIONS } from './optimization'
import { summaryCsv } from './summary'
import { namingRequest, NAMING_FALLBACK_ERROR } from './customName'

vi.mock('@workspace/api-client-react', () => ({ suggestEarningName: vi.fn(), checkEarningDescription: vi.fn() }))
const suggest = vi.mocked(suggestEarningName)

const run = (session: EarningSession, ...actions: SessionAction[]) =>
  actions.reduce((state, action) => reduceChecked(state, action, 1000), session)
const started = () => ({ ...run(createSession(0), { type: 'startReview' }), reviewCursor: 7 })
const ADJ2 = findItem('ADJ2')
const describeAdj2 = (description: string, frequency = 'recurring'): SessionAction[] => [
  { type: 'describe', itemId: 'ADJ2', description },
  { type: 'submitDescription', itemId: 'ADJ2' },
  { type: 'answerFollowUp', itemId: 'ADJ2', questionId: 'basis', choice: 'flat' },
  { type: 'answerFollowUp', itemId: 'ADJ2', questionId: 'frequency', choice: frequency },
  // ADJ2 isn't on the sample pay register, so the team keeps it before seeing a reference or a name.
  { type: 'chooseRetention', itemId: 'ADJ2', choice: 'keep' },
]
const SUGGESTION = { outcome: 'suggestion' as const, name: 'Lead differential', rationale: 'It pays team leads extra each period, and the name says so on pay statements.', question: null }
const withSuggestion = (session: EarningSession) =>
  run(session, { type: 'setNaming', itemId: 'ADJ2', basis: namingBasis(session.answers.ADJ2), result: { outcome: 'suggestion', name: SUGGESTION.name, rationale: SUGGESTION.rationale } })
/** Every other first-round item settled, so the round can be applied. */
const settleOthers = (): SessionAction[] => REVIEW_INITIAL_ITEMS.filter(item => item.id !== 'ADJ2')
  .map(item => ({ type: 'choose', itemId: item.id, choice: item.id === 'BONREV' ? 'accept' : ASK_CUSTOMER }))

let host: HTMLDivElement
let root: Root
let session: EarningSession
const dispatch = (action: SessionAction) => { session = run(session, action) }
const mount = () => act(() => root.render(
  <SessionContext.Provider value={{ session, dispatch, save: () => true, restart: () => true }}><StepQuestions /></SessionContext.Provider>))
const adj2 = () => host.querySelector<HTMLElement>('.ec-guide-item[aria-label^="ADJ2,"]')!
const buttonNamed = (label: string) => [...adj2().querySelectorAll<HTMLButtonElement>('button')].find(button => button.textContent?.trim() === label)
const flush = () => act(async () => { await Promise.resolve(); await Promise.resolve() })

beforeEach(() => {
  (globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
  suggest.mockReset()
  host = document.createElement('div')
  document.body.appendChild(host)
  root = createRoot(host)
})
afterEach(() => {
  act(() => root.unmount())
  host.remove()
})

describe('reference lookup first', () => {
  it('confirms a suitable reference without asking AI for a name', () => {
    session = run(started(), ...describeAdj2('Back pay for last month', 'one-time'),
      { type: 'describe', itemId: 'MISC7', description: 'Night shift premium' }, { type: 'submitDescription', itemId: 'MISC7' })
    mount()
    expect(host.textContent).toContain('Proposed setup for ADJ2: Retroactive pay')
    expect(host.textContent).toContain('Proposed setup for MISC7: Shift differential')
    expect(host.textContent).toContain('pay statements')
    expect(host.textContent).not.toContain('W-2')
    expect(suggest).not.toHaveBeenCalled()
    expect(lookupResult(ADJ2, session.answers.ADJ2).kind).toBe('reference')
    expect(namingRequest(ADJ2, session.answers.ADJ2)).toBeUndefined()
    // Checked isn't confirmed: only an explicit choice sets the code up.
    expect(decisionFor(ADJ2, session.answers.ADJ2)).toBeUndefined()
  })

  it('never treats insufficient evidence or a missing lookup as no match', () => {
    session = run(started(), { type: 'describe', itemId: 'ADJ2', description: 'Adjustment' }, { type: 'submitDescription', itemId: 'ADJ2' })
    expect(lookupResult(ADJ2, session.answers.ADJ2).kind).toBe('needsMoreInfo')
    expect(lookupResult(findItem('SPPAY'), {}).kind).toBe('unavailable')
    expect(lookupResult(findItem('MISC7'), { description: '  ', descriptionSubmitted: true }).kind).toBe('needsMoreInfo')
    mount()
    expect(suggest).not.toHaveBeenCalled()
    // A blank description can't be checked.
    session = run(started(), { type: 'describe', itemId: 'ADJ2', description: '   ' })
    expect(run(session, { type: 'submitDescription', itemId: 'ADJ2' }).answers.ADJ2.descriptionSubmitted).toBeUndefined()
    mount()
    expect(buttonNamed('Done')?.disabled).toBe(true)
  })
})

describe('AI naming after an explicit no match', () => {
  it('refreshes the existing long Special Pay proposal through live naming without changing its description', async () => {
    const item = findItem('SPPAY')
    if (item.type !== 'unidentified') throw new Error('Expected Special Pay')
    session = run(started(),
      { type: 'describe', itemId: item.id, description: 'A monthly stipend for using a second language with customers' },
      { type: 'submitDescription', itemId: item.id })
    const basis = namingBasis(session.answers[item.id])
    session = reduceSession(session, { type: 'checkDescription', itemId: item.id, basis,
      result: { kind: 'noMatch', reason: 'No supplied reference covers a language stipend.' } }, 1000)
    session = reduceSession(session, { type: 'setNaming', itemId: item.id, basis,
      result: { outcome: 'suggestion', name: 'Second language stipend', rationale: 'It names the language payment.' } }, 1000)
    const description = session.answers[item.id].description
    suggest.mockResolvedValue({ outcome: 'suggestion', name: 'Bilingual', rationale: 'The label identifies payment for using a second language.', question: null })
    const render = () => act(() => root.render(
      <SessionContext.Provider value={{ session, dispatch, save: () => true, restart: () => true }}>
        <CustomNameSection item={item} answer={session.answers[item.id]} dispatch={dispatch} />
      </SessionContext.Provider>))
    render()
    expect(host.textContent).not.toContain('Second language stipend')
    await flush()
    render()
    expect(suggest).toHaveBeenCalledTimes(1)
    expect(host.textContent).toContain('Use ‘Bilingual’')
    expect(host.textContent).toContain('Keep ‘Special Pay’')
    expect(session.answers[item.id].description).toBe(description)
    expect(session.answers[item.id].choice).toBeUndefined()
  })

  it('sends the source facts, redacted description and answers once, then shows the suggestion for explicit acceptance', async () => {
    suggest.mockResolvedValue(SUGGESTION)
    session = run(started(), ...describeAdj2('Lead pay for jane@example.com, SSN 123-45-6789'))
    mount()
    await flush()
    expect(suggest).toHaveBeenCalledTimes(1)
    const [input] = suggest.mock.calls[0]
    expect(input).toMatchObject({
      code: 'ADJ2',
      source: { label: 'Pay register data', description: null },
      answers: [
        { question: 'Is ADJ2 paid as a flat amount or at an hourly rate?', answer: expect.any(String) },
        { question: 'Is ADJ2 a one-time payment or recurring?', answer: expect.any(String) },
      ],
      lookup: { outcome: 'noSuitableReference' },
    })
    expect(input.description).not.toContain('jane@example.com')
    expect(input.description).not.toContain('123-45-6789')
    mount()
    expect(adj2().textContent).toContain('Use ‘Lead differential’ for ADJ2?')
    expect(adj2().textContent).toContain(SUGGESTION.rationale)
    expect(adj2().textContent).toContain('Suggested by AI')
    expect(adj2().textContent).toContain('Save this proposed name for setup review. Your live payroll stays unchanged.')
    expect(adj2().textContent).not.toContain(input.lookup.reason)
    expect(adj2().querySelector('.ec-naming > [role="status"]')?.textContent).toContain('Lead differential')
    // Nothing is preselected; the name is only a suggestion until chosen.
    expect(session.answers.ADJ2.choice).toBeUndefined()
    expect(decisionFor(ADJ2, session.answers.ADJ2)).toBeUndefined()
    expect(buttonNamed('Edit description')).toBeDefined()
    // Rerendering doesn't request again.
    mount()
    await flush()
    expect(suggest).toHaveBeenCalledTimes(1)
  })

  it('still gets a result when the card is mounted twice, as React does in development', async () => {
    suggest.mockImplementation((_input, options) => new Promise((resolve, reject) => {
      const signal = (options as { signal?: AbortSignal } | undefined)?.signal
      signal?.addEventListener('abort', () => reject(new DOMException('Aborted', 'AbortError')))
      setTimeout(() => resolve(SUGGESTION), 0)
    }))
    session = run(started(), ...describeAdj2('Extra pay for team leads each period'))
    act(() => root.render(
      <StrictMode>
        <SessionContext.Provider value={{ session, dispatch, save: () => true, restart: () => true }}><StepQuestions /></SessionContext.Provider>
      </StrictMode>))
    await act(async () => { await new Promise(resolve => setTimeout(resolve, 5)) })
    // The first request was cancelled by the simulated unmount; the remount sent one that finished.
    expect(suggest).toHaveBeenCalledTimes(2)
    expect(session.answers.ADJ2.naming).toMatchObject({ outcome: 'suggestion', name: 'Lead differential' })
  })

  it('asks for the missing information instead of inventing a name', async () => {
    suggest.mockResolvedValue({ outcome: 'needsInformation', name: null, rationale: null, question: 'Who receives this payment, and what is it for?' })
    session = run(started(), ...describeAdj2('Extra money'))
    mount()
    await flush()
    mount()
    expect(adj2().textContent).toContain('Who receives this payment, and what is it for?')
    expect(adj2().textContent).not.toContain('Use ‘')
    expect(activeNaming(ADJ2, session.answers.ADJ2)?.outcome).toBe('needsInformation')
    expect(run(session, { type: 'choose', itemId: 'ADJ2', choice: ACCEPT_NAME }).answers.ADJ2.choice).toBe(ACCEPT_NAME)
    expect(decisionFor(ADJ2, run(session, { type: 'choose', itemId: 'ADJ2', choice: ACCEPT_NAME }).answers.ADJ2)).toBeUndefined()
    act(() => buttonNamed('Edit description')!.click())
    expect(session.answers.ADJ2.descriptionSubmitted).toBeUndefined()
    expect(session.answers.ADJ2.naming).toBeUndefined()
    expect(session.answers.ADJ2.description).toBe('Extra money')
  })

  it.each([
    ['a documented error', { data: { code: 'rate_limited', error: 'Too many name suggestions right now. Wait a minute, then try again.' } }, 'Too many name suggestions right now.'],
    ['an undocumented error', { data: { code: 'other', error: 'Internal stack trace' } }, NAMING_FALLBACK_ERROR],
    ['a network failure', new TypeError('Failed to fetch'), NAMING_FALLBACK_ERROR],
  ])('keeps answers through %s, offers Try again and never substitutes a name', async (_label, error, message) => {
    suggest.mockRejectedValueOnce(error)
    session = run(started(), ...describeAdj2(`Lead pay ${_label}`))
    const before = session.answers.ADJ2
    mount()
    await flush()
    expect(adj2().textContent).toContain(message)
    expect(adj2().textContent).not.toContain('Internal stack trace')
    expect(session.answers.ADJ2).toEqual(before)
    expect(adj2().textContent).not.toContain('Use ‘')
    // No automatic retry, even after leaving and coming back.
    act(() => root.render(<></>))
    mount()
    await flush()
    expect(suggest).toHaveBeenCalledTimes(1)
    expect(adj2().textContent).toContain(message)
    suggest.mockResolvedValueOnce(SUGGESTION)
    act(() => buttonNamed('Try again')!.click())
    await flush()
    expect(suggest).toHaveBeenCalledTimes(2)
    mount()
    expect(adj2().textContent).toContain('Use ‘Lead differential’ for ADJ2?')
  })

  it('treats malformed output as a failure, not a name', async () => {
    suggest.mockResolvedValue({ outcome: 'suggestion', name: null, rationale: null, question: null })
    session = run(started(), ...describeAdj2('Malformed lead pay'))
    mount()
    await flush()
    mount()
    expect(adj2().textContent).toContain('We couldn’t come up with a clear name this time.')
    expect(session.answers.ADJ2.naming).toBeUndefined()
    expect(buttonNamed('Try again')).toBeDefined()
  })

  it('disregards a response for answers changed while it was in flight, and the replacement request still succeeds', async () => {
    const pending: { resolve: (value: unknown) => void; signal?: AbortSignal }[] = []
    suggest.mockImplementation((_input, options) => new Promise(resolve => {
      pending.push({ resolve, signal: (options as { signal?: AbortSignal } | undefined)?.signal })
    }))
    session = run(started(), ...describeAdj2('In-flight lead pay'))
    const staleBasis = namingBasis(session.answers.ADJ2)
    mount()
    expect(adj2().textContent).toContain('We’re suggesting a name')
    dispatch({ type: 'answerFollowUp', itemId: 'ADJ2', questionId: 'basis', choice: 'hourly' })
    // The changed answer clears the later follow-up and Keep, so the naming section waits until the AI check has the
    // follow-up answered again and the team keeps ADJ2.
    mount()
    expect(suggest).toHaveBeenCalledTimes(1)
    expect(pending[0].signal?.aborted).toBe(true)
    expect(session.answers.ADJ2.followUps).toEqual({ basis: 'hourly' })
    dispatch({ type: 'answerFollowUp', itemId: 'ADJ2', questionId: 'frequency', choice: 'recurring' })
    dispatch({ type: 'chooseRetention', itemId: 'ADJ2', choice: 'keep' })
    mount()
    expect(suggest).toHaveBeenCalledTimes(2)
    // Only the request for the earlier answers is cancelled; the replacement keeps running.
    expect(pending[0].signal?.aborted).toBe(true)
    expect(pending[1].signal?.aborted).toBe(false)
    expect(adj2().textContent).toContain('We’re suggesting a name')
    await act(async () => { pending[0].resolve({ ...SUGGESTION, name: 'Stale name' }) })
    await flush()
    expect(session.answers.ADJ2.naming).toBeUndefined()
    await act(async () => { pending[1].resolve(SUGGESTION) })
    await flush()
    expect(session.answers.ADJ2.naming).toMatchObject({ outcome: 'suggestion', name: SUGGESTION.name, basis: namingBasis(session.answers.ADJ2) })
    mount()
    expect(adj2().textContent).toContain('Use ‘Lead differential’ for ADJ2?')
    // The reducer also ignores a late result for an earlier basis.
    expect(run(session, { type: 'setNaming', itemId: 'ADJ2', basis: staleBasis, result: SUGGESTION as never }).answers.ADJ2).toEqual(session.answers.ADJ2)
  })

  it('invalidates a suggestion and its acceptance when an answer changes or the session resets', () => {
    session = withSuggestion(run(started(), ...describeAdj2('Lead pay')))
    session = run(session, { type: 'choose', itemId: 'ADJ2', choice: ACCEPT_NAME })
    expect(decisionFor(ADJ2, session.answers.ADJ2)).toEqual({ kind: 'name', name: 'Lead differential' })
    const edited = run(session, { type: 'answerFollowUp', itemId: 'ADJ2', questionId: 'basis', choice: 'hourly' })
    expect(edited.answers.ADJ2.naming).toBeUndefined()
    expect(edited.answers.ADJ2.retain).toBeUndefined()
    expect(decisionFor(ADJ2, edited.answers.ADJ2)).toBeUndefined()
    expect(run(session, { type: 'editDescription', itemId: 'ADJ2' }).answers.ADJ2).toEqual({ description: 'Lead pay' })
    expect(createSession(0).answers.ADJ2).toBeUndefined()
  })
})

describe('accepted custom names', () => {
  it('offers keeping the existing name and preserves that choice through Apply and saved restoration', () => {
    session = withSuggestion(run(started(), ...describeAdj2('Lead pay')))
    mount()
    expect(host.textContent).toContain('Keep ‘ADJ2’')
    const option = [...host.querySelectorAll<HTMLElement>('[role="radio"]')]
      .find(card => card.querySelector('.sc__title')?.textContent === 'Keep ‘ADJ2’')!
    act(() => option.click())
    expect(session.answers.ADJ2.choice).toBe(KEEP_NAME)
    expect(decisionFor(ADJ2, session.answers.ADJ2)).toEqual({ kind: 'name', name: 'ADJ2', provenance: 'existing' })
    session = run(session, ...settleOthers(), { type: 'submitRound' })
    expect(session.resolutions.ADJ2).toEqual({ status: 'review', round: 1, customName: { name: 'ADJ2', provenance: 'existing' } })
    expect(parseSession(JSON.stringify(session))).toEqual(session)
    expect(configurationCounts(finalConfiguration(session)).review).toBeGreaterThan(0)
  })

  const applied = () => run(withSuggestion(run(started(), ...describeAdj2('Lead pay'))),
    { type: 'choose', itemId: 'ADJ2', choice: ACCEPT_NAME }, ...settleOthers(), { type: 'submitRound' })

  it('leave setup awaiting review, apart from Ready references, counts, overtime and the customer list', () => {
    const session = applied()
    expect(session.resolutions.ADJ2).toEqual({ status: 'review', round: 1, customName: { name: 'Lead differential', provenance: 'ai' } })
    expect(session.rounds[0].results?.review).toEqual(['ADJ2'])
    expect(session.customerQuestions.some(question => question.code === 'ADJ2')).toBe(false)
    expect(classificationStatus(session)).toMatchObject({ review: 1 })
    const rows = finalConfiguration(session)
    const row = rows.find(candidate => candidate.code === 'ADJ2')!
    expect(row).toMatchObject({ status: 'review', customName: 'Lead differential', description: 'Lead pay' })
    expect(row.reference).toBeUndefined()
    const counts = configurationCounts(rows)
    expect(counts.review).toBe(1)
    expect(counts.ready).toBe(rows.filter(candidate => candidate.status === 'ready').length)
    const sort = sortEarnings(rows)
    expect([...sort.include, ...sort.exclude].some(earning => earning.code === 'ADJ2')).toBe(false)
    expect(sort.review.map(candidate => candidate.code)).toEqual(['ADJ2'])
    expect(sort.waiting.some(candidate => candidate.code === 'ADJ2')).toBe(false)
    const csv = summaryCsv(session, () => 'Today').split('\r\n')
    expect(csv[0]).toContain('"Ready code","Proposed custom name","Status"')
    const csvRow = csv.find(line => line.startsWith('"Code","ADJ2"'))!
    expect(csvRow).toContain('"Code","ADJ2","Lead pay","","","Lead differential","Awaiting setup review"')
    const width = csv[0].split('","').length
    expect(csv.filter(Boolean).every(line => line.split('","').length >= width - 1)).toBe(true)
  })

  it('survive save and reload, and malformed saved names are dropped without losing the session', () => {
    const session = applied()
    expect(parseSession(JSON.stringify(session))).toEqual(session)
    const draft = withSuggestion(run(started(), ...describeAdj2('Lead pay')))
    expect(parseSession(JSON.stringify(draft))?.answers.ADJ2.naming?.name).toBe('Lead differential')
    const malformed = { ...draft, answers: { ...draft.answers, ADJ2: { ...draft.answers.ADJ2, naming: { outcome: 'suggestion', provenance: 'ai' } } } }
    const loaded = parseSession(JSON.stringify(malformed))
    expect(loaded).not.toBeNull()
    expect(loaded!.answers.ADJ2.naming).toBeUndefined()
    expect(loaded!.answers.ADJ2.description).toBe('Lead pay')
  })

  it('can come from a customer reply without marking the code ready', () => {
    const applied = run(started(), ...describeAdj2('Lead pay'), { type: 'choose', itemId: 'ADJ2', choice: ASK_CUSTOMER },
      ...settleOthers(), { type: 'submitRound' })
    const deferred = run(applied,
      { type: 'finishReevaluation' }, { type: 'complete' }, { type: 'startOptimization' },
      ...OPTIMIZATIONS.map((suggestion): SessionAction => ({ type: 'chooseOptimization', suggestionId: suggestion.id, choice: 'keep' })),
      { type: 'submitOptimization' }, { type: 'completeOptimization' }, { type: 'startOvertime' },
      ...SCREENING_QUESTIONS.map((question): SessionAction => ({ type: 'answerOvertime', questionId: question.id, answer: 'no' })),
      { type: 'confirmOvertime' }, { type: 'sendQuestions', to: 'customer@example.com' })
    expect(deferred.sent?.questionIds).toContain('classification:ADJ2')
    expect(parseSession(JSON.stringify(deferred))).not.toBeNull()
    expect(deferred.resolutions.ADJ2?.status).toBe('customer')
    const answered = withSuggestion(run(started(), ...describeAdj2('Lead pay for team leads'))).answers.ADJ2
    const replied = run(deferred, { type: 'saveCustomerReply', questionId: 'classification:ADJ2', answer: { ...answered, choice: ACCEPT_NAME } })
    expect(replied.resolutions.ADJ2).toMatchObject({ status: 'review', customName: { name: 'Lead differential' } })
    expect(replied.customerReplies?.['classification:ADJ2'].text).toContain('Lead differential')
    expect(finalConfiguration(replied).find(row => row.code === 'ADJ2')?.status).toBe('review')
    expect(parseSession(JSON.stringify(replied))).toEqual(replied)
    // A name that no longer fits the reply's answers can't be saved.
    const stale = { ...answered, followUps: { ...answered.followUps, basis: 'hourly' }, choice: ACCEPT_NAME }
    expect(run(deferred, { type: 'saveCustomerReply', questionId: 'classification:ADJ2', answer: stale })).toBe(deferred)
  })
})
