import { SCRIPTED_QUESTIONS, reduceChecked } from './scriptedChecks.testing'
import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { reviewEarningAnswer } from '@workspace/api-client-react'
import StepQuestions from './StepQuestions'
import { SessionContext } from './sessionContext'
import { requestDescriptionCheck } from './descriptionCheck'
import { OTHER_PURPOSE, createSession, type EarningSession, type SessionAction } from './session'

vi.mock('@workspace/api-client-react', async importOriginal => ({
  ...await importOriginal<typeof import('@workspace/api-client-react')>(),
  reviewEarningAnswer: vi.fn(),
}))
vi.mock('./descriptionCheck', async importOriginal => ({
  ...(await importOriginal<typeof import('./descriptionCheck')>()), requestDescriptionCheck: vi.fn(),
}))

const run = (session: EarningSession, ...actions: SessionAction[]) =>
  actions.reduce((state, action) => reduceChecked(state, action, 1000), session)
const started = () => ({ ...run(createSession(0), { type: 'startReview' }), reviewCursor: 7 })

let host: HTMLDivElement
let root: Root
let session: EarningSession
const dispatch = (action: SessionAction) => { session = run(session, action) }
const mount = () => act(() => root.render(
  <SessionContext.Provider value={{ session, dispatch, save: () => true, restart: () => true }}><StepQuestions /></SessionContext.Provider>,
))
const card = (id: string) => host.querySelector<HTMLElement>(`.ec-guide-item[aria-label^="${id},"]`)!
const sections = (scope: HTMLElement) => [...scope.querySelectorAll<HTMLElement>('.ec-qcard__sections .ec-qcard__section')]
const radio = (scope: ParentNode, label: string) =>
  [...scope.querySelectorAll<HTMLElement>('[role="radio"]')].find(option => option.textContent?.trim().startsWith(label))!
const button = (scope: ParentNode, label: string) =>
  [...scope.querySelectorAll<HTMLButtonElement>('button')].find(element => element.textContent?.trim() === label)
const type = (box: HTMLTextAreaElement, value: string) => act(() => {
  Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')!.set!.call(box, value)
  box.dispatchEvent(new Event('input', { bubbles: true }))
})

/** Every question after the opening one is a numbered step, 01 onward, with no AI-marked code label. */
function expectOneSequence(scope: HTMLElement) {
  const steps = sections(scope)
  expect(steps.length).toBeGreaterThan(0)
  expect(steps.map(step => step.getAttribute('data-sequence-number')))
    .toEqual(steps.map((_, index) => String(index + 1).padStart(2, '0')))
  expect(steps.every(step => step.closest('.ec-qcard__sequence'))).toBe(true)
  expect(scope.querySelector('.ec-qcard__sections .ec-qcard__label--ai')).toBeNull()
  expect(scope.textContent).not.toContain('Choose the best fit')
  expect(scope.querySelector('.ec-qcard__sequence-hint')).toBeNull()
}

beforeEach(() => {
  (globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
  host = document.createElement('div')
  document.body.append(host)
  root = createRoot(host)
  vi.mocked(reviewEarningAnswer).mockReset()
  vi.mocked(requestDescriptionCheck).mockReset().mockReturnValue(new Promise(() => {}))
  session = started()
})
afterEach(() => {
  act(() => root.unmount())
  host.remove()
  vi.useRealTimers()
})

describe('follow-up sequence on described codes', () => {
  it('numbers the match step even when no follow-ups came first', () => {
    session = run(session, { type: 'describe', itemId: 'MISC7', description: 'Night shift premium' }, { type: 'submitDescription', itemId: 'MISC7' })
    mount()
    expectOneSequence(card('MISC7'))
    expect(sections(card('MISC7'))[0].querySelector('h3')?.textContent).toBe('Proposed setup for MISC7: Shift differential')
    expect(sections(card('MISC7'))[0].querySelector('.ec-qcard__label')?.textContent).toBe('QUESTION 01')
  })

  it('answers the AI’s choices question inside the sequence, then continues the numbering', () => {
    session = run(session, { type: 'describe', itemId: 'ADJ2', description: 'It depends on the month' }, { type: 'submitDescription', itemId: 'ADJ2' })
    mount()
    const adj2 = card('ADJ2')
    expectOneSequence(adj2)
    const [step] = sections(adj2)
    expect(step.querySelector('h3')?.textContent).toBe(SCRIPTED_QUESTIONS.ADJ2.question)
    expect(step.textContent).not.toContain('Choose the best fit')
    expect([...step.querySelectorAll('[role="radio"]')].map(option => option.textContent?.trim()))
      .toEqual(['A bonus amount', 'A correction to an earlier overpayment', 'Something else'])
    // Nothing points back to the card's description.
    expect(adj2.textContent).not.toContain('Select Edit description to add it')
    act(() => radio(step, 'A correction to an earlier overpayment').click())
    expect(session.answers.ADJ2.checkAnswers?.[0]).toMatchObject({ answer: 'A correction to an earlier overpayment' })
    mount()
    expectOneSequence(card('ADJ2'))
    const [answered, next] = sections(card('ADJ2'))
    expect(answered.querySelector('.ec-qcard__sequence-answer')?.textContent).toContain('A correction to an earlier overpayment')
    expect(next.textContent).not.toContain('Choose the best fit')
    // Change reopens the AI's question.
    act(() => answered.querySelector<HTMLButtonElement>('.ec-qcard__sequence-answer')!.click())
    expect(session.answers.ADJ2.checkAnswers ?? []).toHaveLength(0)
  })
})

describe('typed answers and the live review', () => {
  it('shows no sparkle, loader or review while SPPAY’s Something else is typed, and answers the AI’s text question on Done', async () => {
    vi.useFakeTimers()
    session = run(session, { type: 'choose', itemId: 'SPPAY', choice: OTHER_PURPOSE })
    session = { ...session, reviewCursor: 1 }
    mount()
    type(card('SPPAY').querySelector('textarea')!, 'It depends on the shift')
    mount()
    await act(async () => { await vi.advanceTimersByTimeAsync(1500) })
    expect(card('SPPAY').querySelector('.ec-answer-review, .ec-describe__searching')).toBeNull()
    expect(reviewEarningAnswer).not.toHaveBeenCalled()
    act(() => button(card('SPPAY'), 'Done')!.click())
    mount()
    expectOneSequence(card('SPPAY'))
    const [step] = sections(card('SPPAY'))
    expect(step.querySelector('h3')?.textContent).toBe(SCRIPTED_QUESTIONS.SPPAY.question)
    const box = step.querySelector('textarea')!
    type(box, 'Weekend on-call shifts')
    await act(async () => { await vi.advanceTimersByTimeAsync(1500) })
    expect(step.querySelector('.ec-answer-review, .ec-describe__searching')).toBeNull()
    act(() => button(step, 'Done')!.click())
    expect(session.answers.SPPAY.checkAnswers?.[0]).toMatchObject({ answer: 'Weekend on-call shifts' })
    mount()
    expectOneSequence(card('SPPAY'))
    expect(sections(card('SPPAY'))[0].querySelector('.ec-qcard__sequence-answer')?.textContent).toContain('Weekend on-call shifts')
  })
})
