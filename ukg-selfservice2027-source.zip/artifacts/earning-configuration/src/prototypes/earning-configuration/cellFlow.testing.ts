import type { CellReviewResult } from '@workspace/api-client-react'
import type { EarningSession, ItemAnswer } from './session'
import { createSession, reduceSession } from './session'
import { cellBasis, cellComponents, cellNext, paymentMethod, reduceCell } from './cellFlow'
import { CELL_ID } from './cell'

export const cellPick = (answer: ItemAnswer, id: string, value: string, text?: string) =>
  reduceCell(answer, { kind: 'answer', id, value, text })
export const cellResult = (next: CellReviewResult['next'] = 'tax', component: CellReviewResult['component'] = 'allowance',
  overrides: Partial<CellReviewResult> = {}): CellReviewResult =>
  ({ next, component, question: null, answerFormat: null,
    discovery: { status: next === 'tax' ? 'sufficient' : 'missing', missingFact: next === 'tax' ? null : 'The payment calculation needs review.', answerIds: ['method'] },
    reason: 'The payment facts are clear; intended tax treatment still needs confirmation.', confirmations: [], ...overrides })
export const cellChecked = (answer: ItemAnswer, result = cellResult()) =>
  reduceCell(answer, { kind: 'checked', basis: cellBasis(answer), result, at: 42 })
export const fixedBusiness = () => cellPick(cellPick({}, 'method', 'allowance'), 'allowance-purpose', 'business')
export const readyCell = (intent = 'taxable') => cellPick(cellChecked(fixedBusiness()), 'tax-allowance', intent)
export const cellSession = (answer: ItemAnswer = {}): EarningSession => ({
  ...createSession(1), step: 'questions', reviewLayout: 'business-topics', reviewCursor: 0,
  rounds: [{ number: 1, itemIds: [CELL_ID], submitted: false }], answers: { [CELL_ID]: answer },
})
export const sentCell = (answer: ItemAnswer): EarningSession => {
  const applied = reduceSession(cellSession(answer), { type: 'submitRound' }, 43)
  return reduceSession({ ...applied, step: 'summary' }, { type: 'sendQuestions', to: 'payroll@example.test' }, 44)
}
/** Explicit scripted fixture for tests of other phases. Never imported by production code. */
export const completeDemoCell = (answer: ItemAnswer): ItemAnswer => {
  let next = answer
  if (cellNext(next).kind === 'question' && !next.choice) next = cellPick(next, 'method', 'allowance')
  next = cellPick(next, 'allowance-purpose', 'business')
  next = cellChecked(next)
  return cellPick(next, 'tax-allowance', 'taxable')
}

/** Explicit fictional facts and taxable intent for later-phase tests, not production/demo answers.
 * The result is still configuration review, never a verified reimbursement setup.
 */
export const completeTestReimbursement = (answer: ItemAnswer): ItemAnswer => {
  if (cellNext(answer).kind === 'done' || cellNext(answer).kind === 'pending') return answer
  let next = answer
  if (!paymentMethod(next)) next = cellPick(next, 'method', next.reimbursement?.category === 'MILEAGE' ? 'allowance' : 'reimbursement')
  next = cellPick(next, 'allowance-purpose', 'business')
  next = cellPick(next, 'rate-basis', 'company')
  next = cellPick(next, 'company-rate', '0.50')
  for (const component of cellComponents(next)) {
    next = cellChecked(next, cellResult('tax', component))
    next = cellPick(next, `tax-${component}`, 'taxable')
  }
  return next
}
