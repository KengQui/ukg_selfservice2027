import { describe, expect, it } from 'vitest'
import { createSession, parseSession, reduceSession, type EarningSession, type SessionAction } from './session'
import { ASK_CUSTOMER, findItem } from './sampleRegister'
import { codeApplicationIssue, canEnterOptimization, discussionEntries, discussionsComplete, previewCanApply, previewItems, previewWorkIds } from './deferredReview'
import { discussionSummaryBasis, discussionSummaryInput } from './discussionSummary'
import { saveSession, loadSession, type SessionStores } from './storage'
import { TIPS_METHOD_OPTIONS, tipsMethodQuestion } from './tips'
import { ACCEPT_NAME, namingBasis, pendingCheckBasis, type ItemAnswer } from './session'
import { EARNING_DEMO_SETTINGS } from './demoSettings'
import { finalConfiguration } from './configuration'
import { sortEarnings } from './overtime'
import { CELL_OPENING, CELL_METHODS, emptyCell } from './cellFlow'
import { SOMETHING_ELSE_MAIN } from './somethingElse'
import { setupReviewItems } from './setupReview'
import { appliedReviewSession } from './session'

function run(session: EarningSession, ...actions: SessionAction[]) {
  return actions.reduce((value, action, index) => reduceSession(value, action, value.updatedAt + index + 1), session)
}
function deferred(id = 'BONREV') {
  const item = findItem(id)
  const options = item.type === 'misclassification' ? [item.accept] : item.type === 'unidentified' ? [] : item.options
  return run({ ...createSession(1), step: 'questions', rounds: [{ number: 1, itemIds: [id], submitted: false }] },
    { type: 'choose', itemId: id, choice: ASK_CUSTOMER },
    { type: 'selectDeferredQuestion', itemId: id, source: {
      question: item.question, choices: options.map(option => option.label), options: options.map(option => ({ id: option.id, label: option.label })),
    } }, { type: 'submitRound' })
}
function respond(session: EarningSession, choice: string) {
  const entry = discussionEntries(session)[0]
  return run(session, { type: 'setDiscussionAnswer', itemId: entry.itemId, question: entry.question,
    basis: entry.basis, kind: entry.options.length ? 'review-choices' : 'text', change: { choice } })
}
function store() {
  const entries = new Map<string, string>()
  return { getItem: (key: string) => entries.get(key) ?? null, setItem: (key: string, value: string) => { entries.set(key, value) },
    removeItem: (key: string) => { entries.delete(key) } }
}
function deferredTips() {
  const answer = { choice: 'pool' }
  return run({ ...createSession(1), step: 'questions', answers: { TIPS: answer },
    rounds: [{ number: 2, itemIds: ['TIPS'], submitted: false }] },
    { type: 'answerFollowUp', itemId: 'TIPS', questionId: 'tips-method', choice: ASK_CUSTOMER },
    { type: 'selectDeferredQuestion', itemId: 'TIPS', source: { question: tipsMethodQuestion(answer),
      choices: TIPS_METHOD_OPTIONS.map(option => option.label), options: TIPS_METHOD_OPTIONS.map(option => ({ id: option.id, label: option.label })) } },
    { type: 'submitRound' })
}
function describedTips() {
  return run({ ...createSession(1), step: 'questions', rounds: [{ number: 2, itemIds: ['TIPS'], submitted: false }] },
    { type: 'chooseSomethingElse', itemId: 'TIPS', question: SOMETHING_ELSE_MAIN },
    { type: 'describeSomethingElse', itemId: 'TIPS', description: 'Our pooled tips need a separate setup decision.' },
    { type: 'submitSomethingElse', itemId: 'TIPS' }, { type: 'submitRound' })
}
describe('explicit deferred review transaction', () => {
  it('gives a completed Something else a new owning proposal without editing its applied history', () => {
    const original = describedTips()
    expect(original.resolutions.TIPS).toMatchObject({ status: 'review', note: 'Our pooled tips need a separate setup decision.' })
    expect(discussionEntries(original)).toEqual([])
    expect(canEnterOptimization(original)).toBe(false)
    expect(setupReviewItems(original)).toEqual(['TIPS'])
    let work = run(original, { type: 'prepareSetupReview' })
    expect(work.step).toBe('discussionWork')
    expect(work.answers).toEqual(original.answers)
    expect(work.resolutions).toEqual(original.resolutions)
    expect(previewCanApply(work)).toBe(false)
    const item = findItem('TIPS')
    if (item.type !== 'clarification') throw new Error('fixture')
    work = run(work, { type: 'editDiscussionWork', action: { type: 'choose', itemId: item.id, choice: item.options[0].id } },
      { type: 'finishDiscussionWork' })
    expect(work.step).toBe('discussionReview')
    expect(previewCanApply(work)).toBe(true)
    expect(work.resolutions).toEqual(original.resolutions)
    const stores = { working: store(), saved: store() }
    expect(saveSession(stores, work)).toBe(true)
    const restored = loadSession({ working: store(), saved: stores.saved })
    expect(restored.step).toBe('discussionReview')
    expect(previewCanApply(restored)).toBe(true)
    const applied = run(restored, { type: 'applyDiscussionReview' })
    expect(applied.resolutions.TIPS.status).toBe('resolved')
    expect(canEnterOptimization(applied)).toBe(true)
    expect(applied.discussionApplications?.[0].originalAnswers.TIPS).toEqual(original.answers.TIPS)
    expect(applied.discussionApplications?.[0].source).toBe('setupReview')
    expect(applied.sent).toBeUndefined()
    expect(applied.customerReplies).toBeUndefined()
    const earlier = appliedReviewSession({ ...applied, appliedReview: { round: 2, cursor: 0 } })
    expect(earlier?.answers.TIPS).toEqual(original.answers.TIPS)
    expect(run(applied, { type: 'applyDiscussionReview' })).toEqual(applied)
  })

  it('restores unresolved setup work and accepts only a new explicit Defer, never a manufactured selection', () => {
    const original = parseSession(JSON.stringify(describedTips()))!
    let work = run(original, { type: 'prepareSetupReview' })
    expect(discussionEntries(work)).toEqual([])
    expect(work.answers.TIPS.explicitDeferral).toBeUndefined()
    const item = findItem('TIPS')
    if (item.type !== 'clarification') throw new Error('fixture')
    work = run(work, { type: 'editDiscussionWork', action: { type: 'choose', itemId: item.id, choice: ASK_CUSTOMER } })
    expect(previewCanApply(work)).toBe(false)
    work = run(work, { type: 'editDiscussionWork', action: { type: 'selectDeferredQuestion', itemId: item.id,
      source: { question: item.question, choices: item.options.map(option => option.label),
        options: item.options.map(option => ({ id: option.id, label: option.label })) } } },
      { type: 'finishDiscussionWork' })
    expect(previewCanApply(work)).toBe(true)
    const applied = run(work, { type: 'applyDiscussionReview' })
    expect(discussionEntries(applied).map(entry => entry.question)).toEqual([item.question])
    expect(canEnterOptimization(applied)).toBe(false)
    expect(applied.discussionApplications?.[0].originalAnswers.TIPS).toEqual(original.answers.TIPS)
  })
  it('captures real option identities; typing, preview and cancel do not apply; explicit apply is idempotent', () => {
    const initial = deferred()
    expect(discussionEntries(initial)[0].target).toEqual({ kind: 'choice', stage: 'main' })
    expect(discussionsComplete(initial)).toBe(false)
    const item = findItem('BONREV')
    if (item.type !== 'misclassification') throw new Error('fixture')
    const response = respond(initial, item.accept.id)
    expect(response.answers).toEqual(initial.answers)
    expect(response.resolutions).toEqual(initial.resolutions)
    expect(canEnterOptimization(response)).toBe(false)
    const preview = run(response, { type: 'prepareDiscussionReview' })
    expect(preview.step).toBe('discussionReview')
    expect(previewCanApply(preview), JSON.stringify(previewItems(preview))).toBe(true)
    expect(preview.answers).toEqual(initial.answers)
    expect(preview.resolutions).toEqual(initial.resolutions)
    expect(run(preview, { type: 'cancelDiscussionReview' }).resolutions).toEqual(initial.resolutions)
    const applied = run(preview, { type: 'applyDiscussionReview' })
    expect(applied.resolutions.BONREV.status).toBe('resolved')
    expect(applied.discussionApplications).toHaveLength(1)
    expect(applied.sent).toBeUndefined()
    expect(applied.customerReplies).toBeUndefined()
    expect(applied.discussionApplications![0].originalAnswers.BONREV).toEqual(initial.answers.BONREV)
    expect(canEnterOptimization(applied)).toBe(true)
    expect(run(applied, { type: 'applyDiscussionReview' })).toEqual(applied)
    const restored = parseSession(JSON.stringify(applied))
    expect(restored?.discussionApplications).toEqual(applied.discussionApplications)
    expect(restored?.resolutions.BONREV).toEqual(applied.resolutions.BONREV)
  })

  it('stale, display-derived and missing selections cannot satisfy the current question', () => {
    const initial = deferred()
    const entry = discussionEntries(initial)[0]
    expect(respond(initial, 'source-accept')).toEqual(initial)
    const wrong = run(initial, { type: 'setDiscussionAnswer', itemId: 'BONREV', question: entry.question,
      basis: 'old', kind: 'review-choices', change: { choice: entry.options[0].id } })
    expect(wrong).toEqual(initial)
    const preview = run(respond(initial, entry.options[0].id), { type: 'prepareDiscussionReview' })
    const edited = run(preview, { type: 'setDiscussionAnswer', itemId: 'BONREV', question: entry.question,
      basis: entry.basis, kind: 'review-choices', change: { clear: true } })
    expect(previewItems(edited)).toEqual([])
    expect(previewCanApply(edited)).toBe(false)
    expect(run(edited, { type: 'applyDiscussionReview' }).resolutions).toEqual(initial.resolutions)
  })

  it('keeps legacy question selections as history, never guesses a discussion target, and opens owning work', () => {
    const initial = deferred()
    delete initial.answers.BONREV.explicitDeferral!.target
    expect(discussionEntries(initial)).toEqual([])
    const work = parseSession(JSON.stringify(initial))!
    expect(work.step).toBe('discussionWork')
    expect(work.answers).toEqual(initial.answers)
    expect(previewCanApply(work)).toBe(false)
    expect(run(work, { type: 'applyDiscussionReview' }).resolutions).toEqual(initial.resolutions)
  })

  it('preserves partial capture and current previews in working and saved-only copies', () => {
    const initial = deferred()
    const complete = respond(initial, discussionEntries(initial)[0].options[0].id)
    const preview = run(complete, { type: 'prepareDiscussionReview' })
    const stores: SessionStores = { working: store(), saved: store() }
    expect(saveSession(stores, preview)).toBe(true)
    expect(loadSession({ working: store(), saved: stores.saved }).step).toBe('discussionReview')
    expect(previewCanApply(loadSession(stores))).toBe(true)
    const blocked = { ...store(), setItem() { throw new Error('blocked') } }
    expect(saveSession({ working: blocked, saved: stores.saved }, preview)).toBe(true)
    expect(saveSession({ working: store(), saved: blocked }, initial)).toBe(false)
    expect(loadSession(stores).discussionAnswers).toEqual(preview.discussionAnswers)
  })

  it('keeps later work reachable without confirming deferred answers', () => {
    const initial = deferred()
    const later: EarningSession = { ...initial, step: 'optimization', optimization: { ...initial.optimization, answers: { 'old': 'keep' } } }
    // Use a known empty downstream state so parsing is not testing unrelated option validation.
    later.optimization = initial.optimization
    const restored = parseSession(JSON.stringify(later))
    expect(restored?.step).toBe('optimization')
    expect(restored?.resolutions).toEqual(initial.resolutions)
    expect(run(initial, { type: 'goTo', step: 'optimization' }).resolutions).toEqual(initial.resolutions)
  })

  it('never generates context for a question with no earlier answers', () => {
    expect(discussionSummaryBasis(deferred(), 'BONREV')).toBeUndefined()
  })

  it('keeps summary cache independent of capture and rejects stale evidence results', () => {
    const original = deferredTips()
    const basis = discussionSummaryBasis(original, 'TIPS')!
    expect(basis).toContain('pool')
    const summarized = run(original, { type: 'setDiscussionSummary', itemId: 'TIPS', basis,
      summary: 'The company shares pooled tips; how employees receive their shares remains open.' })
    const captured = respond(summarized, 'both')
    expect(discussionSummaryBasis(captured, 'TIPS')).toBe(basis)
    expect(captured.discussionSummaries).toEqual(summarized.discussionSummaries)
    expect(captured.answers).toEqual(original.answers)
    const unrelated = { ...captured, answers: { ...captured.answers, BONREV: { choice: 'accept' } } }
    expect(discussionSummaryBasis(unrelated, 'TIPS')).toBe(basis)
    const changed = { ...captured, answers: { ...captured.answers, TIPS: { ...captured.answers.TIPS, choice: 'other' } } }
    expect(discussionSummaryBasis(changed, 'TIPS')).not.toBe(basis)
    expect(run(changed, { type: 'setDiscussionSummary', itemId: 'TIPS', basis, summary: 'An older result.' })).toEqual(changed)
    expect(parseSession(JSON.stringify(captured))?.discussionSummaries).toEqual(captured.discussionSummaries)
  })

  it('refreshes old summary wording without changing answers or an unapplied proposal', () => {
    const proposed = run(respond(deferredTips(), 'both'), { type: 'prepareDiscussionReview' })
    const oldBasis = JSON.stringify(discussionSummaryInput(proposed, 'TIPS'))
    const saved = { ...proposed, discussionSummaries: { TIPS: { basis: oldBasis,
      summary: 'Customer answer: Tips are pooled. How people receive them is still unconfirmed.' } } }
    const currentBasis = discussionSummaryBasis(saved, 'TIPS')!
    expect(currentBasis).not.toBe(oldBasis)
    expect(run(saved, { type: 'setDiscussionSummary', itemId: 'TIPS', basis: oldBasis, summary: 'An older response.' })).toEqual(saved)
    const refreshed = run(saved, { type: 'setDiscussionSummary', itemId: 'TIPS', basis: currentBasis,
      summary: 'Earlier answers indicate that tips are pooled. How people receive them is still unconfirmed.' })
    expect(refreshed.discussionSummaries?.TIPS.basis).toBe(currentBasis)
    expect(discussionSummaryBasis(refreshed, 'TIPS')).toBe(currentBasis)
    expect(refreshed.answers).toEqual(proposed.answers)
    expect(refreshed.discussionAnswers).toEqual(proposed.discussionAnswers)
    expect(refreshed.discussionPreview).toEqual(proposed.discussionPreview)
    expect(refreshed.resolutions).toEqual(proposed.resolutions)
  })

  it('does not count notes, blank text or uncertainty as a confirmed business answer', () => {
    let session = deferred('SPPAY')
    const entry = discussionEntries(session)[0]
    session = run(session, { type: 'setCallAnswer', itemId: 'SPPAY', text: 'Optional notes only.' },
      { type: 'setDiscussionAnswer', itemId: 'SPPAY', question: entry.question, basis: entry.basis, kind: 'text', change: { text: '   ' } })
    expect(discussionsComplete(session)).toBe(false)
    expect(run(session, { type: 'prepareDiscussionReview' }).discussionPreview).toBeUndefined()
    const unsure = run(respond(deferred('TIPS'), ASK_CUSTOMER), { type: 'prepareDiscussionReview' })
    expect(previewCanApply(unsure)).toBe(false)
    expect(canEnterOptimization(unsure)).toBe(false)
  })

  it('rejects changed evidence at Apply and keeps saved work drafts without applying', () => {
    let session = deferred('SPPAY')
    const entry = discussionEntries(session)[0]
    session = run(session, { type: 'setDiscussionAnswer', itemId: 'SPPAY', question: entry.question,
      basis: entry.basis, kind: 'text', change: { text: 'A bilingual service payment.' } },
      { type: 'prepareDiscussionReview' }, { type: 'reviewDiscussionWork' },
      { type: 'setDiscussionWorkDraft', key: 'SPPAY:followup', value: 'Partially typed clarification' })
    const restored = parseSession(JSON.stringify(session))!
    expect(restored.discussionPreview?.drafts?.['SPPAY:followup']).toBe('Partially typed clarification')
    expect(restored.answers).toEqual(session.answers)
    const ready = run(respond(deferred(), 'accept'), { type: 'prepareDiscussionReview' })
    const changed = { ...ready, sampleRegisterVersion: 1 as const }
    expect(run(changed, { type: 'applyDiscussionReview' }).resolutions).toEqual(ready.resolutions)
    expect(run(changed, { type: 'applyDiscussionReview' }).discussionApplications).toBeUndefined()
  })

  it('preserves earlier facts and allows a new owning question to be explicitly deferred', () => {
    let session = run(respond(deferredTips(), 'both'), { type: 'prepareDiscussionReview' }, { type: 'reviewDiscussionWork' })
    expect(previewWorkIds(session)).toContain('TIPS RPT')
    const originalPreview = session.discussionPreview
    session = run(session, { type: 'editDiscussionWork', action: { type: 'choose', itemId: 'TIPS', choice: 'paid' } })
    expect(session.discussionPreview).toEqual(originalPreview)
    const item = findItem('TIPS RPT')
    if (item.type !== 'finding') throw new Error('fixture')
    session = run(session,
      { type: 'editDiscussionWork', action: { type: 'choose', itemId: item.id, choice: ASK_CUSTOMER } },
      { type: 'editDiscussionWork', action: { type: 'selectDeferredQuestion', itemId: item.id, source: {
        question: item.question, choices: item.options.map(option => option.label),
        options: item.options.map(option => ({ id: option.id, label: option.label })),
      } } }, { type: 'finishDiscussionWork' })
    expect(previewCanApply(session)).toBe(true)
    const applied = run(session, { type: 'applyDiscussionReview' })
    expect(applied.answers.TIPS.choice).toBe('pool')
    expect(discussionEntries(applied).map(entry => entry.itemId)).toEqual(['TIPS RPT'])
    expect(applied.discussionApplications).toHaveLength(1)
    expect(canEnterOptimization(applied)).toBe(false)
    expect(run(applied, { type: 'applyDiscussionReview' })).toEqual(applied)
  })

  it('targets the tips follow-up, retains the parent, and requires the actual TIPS RPT owner', () => {
    const answer = { choice: 'pool' }
    const source = { question: tipsMethodQuestion(answer), choices: TIPS_METHOD_OPTIONS.map(option => option.label),
      options: TIPS_METHOD_OPTIONS.map(option => ({ id: option.id, label: option.label })) }
    let session = run({ ...createSession(1), step: 'questions', answers: { TIPS: answer },
      rounds: [{ number: 2, itemIds: ['TIPS'], submitted: false }] },
      { type: 'answerFollowUp', itemId: 'TIPS', questionId: 'tips-method', choice: ASK_CUSTOMER },
      { type: 'selectDeferredQuestion', itemId: 'TIPS', source }, { type: 'submitRound' })
    expect(discussionEntries(session)[0].target).toEqual({ kind: 'followUp', id: 'tips-method' })
    session = run(respond(session, 'both'), { type: 'prepareDiscussionReview' })
    expect(session.discussionPreview?.answers.TIPS.choice).toBe('pool')
    expect(session.answers.TIPS.followUps?.['tips-method']).toBe(ASK_CUSTOMER)
    expect(previewCanApply(session)).toBe(false)
    expect(session.discussionPreview?.round.itemIds).toContain('TIPS RPT')
    expect(codeApplicationIssue(session, 'TIPS')).toBeTruthy()
    session = run(session, { type: 'reviewDiscussionWork' },
      { type: 'editDiscussionWork', action: { type: 'choose', itemId: 'TIPS RPT', choice: 'add' } },
      { type: 'finishDiscussionWork' })
    expect(previewCanApply(session), JSON.stringify(previewItems(session))).toBe(true)
    // The original checked proposal is reused on return, including its inseparable finding.
    const appliedInline = run({ ...session, step: 'review' }, { type: 'applyDiscussionCode', itemId: 'TIPS' })
    expect(appliedInline.resolutions['TIPS RPT']?.status).toBe('resolved')
    expect(appliedInline.discussionApplications?.at(-1)?.outcomes).toHaveProperty('TIPS')
    expect(appliedInline.discussionApplications?.at(-1)?.outcomes).toHaveProperty('TIPS RPT')
    session = run(session, { type: 'applyDiscussionReview' })
    expect(session.resolutions['TIPS RPT']?.status).toBe('resolved')
    expect(session.answers.TIPS.choice).toBe('pool')
    expect(session.answers.TIPS.followUps?.['tips-method']).toBe('both')
  })

  it('routes descriptions through current live-check results and accepts a clear-purpose custom name honestly', () => {
    let session = deferred('SPPAY')
    const entry = discussionEntries(session)[0]
    session = run(session, { type: 'setDiscussionAnswer', itemId: 'SPPAY', question: entry.question, basis: entry.basis,
      kind: 'text', change: { text: 'A monthly payment for speaking a second language with customers.' } },
      { type: 'prepareDiscussionReview' }, { type: 'reviewDiscussionWork' })
    expect(previewCanApply(session)).toBe(false)
    let proposed = session.discussionPreview!.answers.SPPAY
    const basis = pendingCheckBasis(findItem('SPPAY'), proposed)!
    expect(basis).toBeDefined()
    session = run(session, { type: 'editDiscussionWork', action: { type: 'checkDescription', itemId: 'SPPAY', basis,
      result: { kind: 'noMatch', reason: 'No supplied Ready reference fits the described language payment.' } } })
    proposed = session.discussionPreview!.answers.SPPAY
    session = run(session, { type: 'editDiscussionWork', action: { type: 'setNaming', itemId: 'SPPAY', basis: namingBasis(proposed),
      result: { outcome: 'suggestion', name: 'Bilingual', rationale: 'Bilingual describes the language payment on a pay statement.' } } },
      { type: 'editDiscussionWork', action: { type: 'choose', itemId: 'SPPAY', choice: ACCEPT_NAME } },
      { type: 'finishDiscussionWork' })
    expect(previewCanApply(session), JSON.stringify(previewItems(session))).toBe(true)
    const applied = run(session, { type: 'applyDiscussionReview' })
    expect(canEnterOptimization(applied)).toBe(true)
    const row = finalConfiguration(applied).find(row => row.code === 'Special Pay')!
    expect(row.reference).toBeUndefined()
    expect(row.customName).toBe('Bilingual')
    expect(sortEarnings([row]).awaiting[0].reason).toContain('no overtime rule')
    expect(session.resolutions.SPPAY.status).toBe('customer')
  })

  it('keeps an adaptive method response separate from later tax intent and confirmed setup', () => {
    let session = run({ ...createSession(1), step: 'questions', rounds: [{ number: 2, itemIds: ['CELL-purpose'], submitted: false }],
      answers: { 'CELL-purpose': { cell: emptyCell() } } },
      { type: 'cell', itemId: 'CELL-purpose', event: { kind: 'defer', checked: true } },
      { type: 'selectDeferredQuestion', itemId: 'CELL-purpose', source: {
        question: CELL_OPENING, choices: CELL_METHODS.map(option => option.label),
        options: CELL_METHODS.map(option => ({ id: option.id, label: option.label, ...(option.id === 'other' ? { details: true } : {}) })),
      } }, { type: 'submitRound' })
    session = run(respond(session, 'allowance'), { type: 'prepareDiscussionReview' })
    expect(session.discussionPreview?.answers['CELL-purpose'].cell?.entries[0]?.value).toBe('allowance')
    expect(previewCanApply(session)).toBe(false)
    expect(session.answers['CELL-purpose'].cell?.entries).toHaveLength(0)
    expect(canEnterOptimization(session)).toBe(false)
  })

  it('allows demo navigation past a required page without applying its missing answers', () => {
    const previous = EARNING_DEMO_SETTINGS.ungateForwardButtons
    EARNING_DEMO_SETTINGS.ungateForwardButtons = true
    try {
      const session: EarningSession = { ...createSession(1), step: 'questions',
        rounds: [{ number: 2, itemIds: ['BONREV', 'SPPAY'], submitted: false }] }
      expect(run(session, { type: 'moveReview', index: 1 }).reviewCursor).toBe(1)
      expect(run(session, { type: 'submitRound' })).toEqual(session)
      const overtime = run(session, { type: 'goTo', step: 'overtime' })
      expect(overtime.step).toBe('overtime')
      expect(overtime.answers).toEqual(session.answers)
      expect(overtime.resolutions).toEqual(session.resolutions)
      expect(overtime.optimization.completed).toBe(false)
    } finally { EARNING_DEMO_SETTINGS.ungateForwardButtons = previous }
  })
})
