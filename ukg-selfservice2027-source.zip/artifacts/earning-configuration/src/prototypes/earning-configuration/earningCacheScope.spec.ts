import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { webcrypto } from 'node:crypto'
import { createSession } from './session'
import { earningCacheHeaders } from './earningCacheScope'
import { reviewEarningAnswer, setRequestHeadersGetter } from '@workspace/api-client-react'

beforeEach(() => { vi.stubGlobal('crypto', webcrypto); sessionStorage.clear() })
afterEach(() => { setRequestHeadersGetter(null); vi.unstubAllGlobals() })
const request = { method: 'POST', url: '/api/earnings/answer-reviews' }

describe('earning response cache namespace', () => {
  it('reuses a scope for unchanged company evidence, including after rereading storage', async () => {
    const session = { ...createSession(), registerSource: 'sample' as const, registerOwnerId: 'company-one' }
    const first = await earningCacheHeaders(session, request)
    expect(await earningCacheHeaders(session, request)).toEqual(first)
    expect(await earningCacheHeaders({ ...session, updatedAt: session.updatedAt + 1 }, request)).toEqual(first)
    expect(new Headers(first).get('X-Earning-Cache-Scope')).toMatch(/^[a-f0-9]{64}$/)
    expect(JSON.stringify(first)).not.toContain('company-one')
  })
  it('changes scope for a different company, source, document or browser tab', async () => {
    const session = { ...createSession(), registerSource: 'sample' as const, registerOwnerId: 'one' }
    const first = await earningCacheHeaders(session, request)
    expect(await earningCacheHeaders({ ...session, registerOwnerId: 'two' }, request)).not.toEqual(first)
    expect(await earningCacheHeaders({ ...session, registerSource: 'uploads' }, request)).not.toEqual(first)
    expect(await earningCacheHeaders({ ...session, files: [{ id: 'file', sha256: 'changed' } as typeof session.files[number]] }, request)).not.toEqual(first)
    sessionStorage.clear()
    expect(await earningCacheHeaders(session, request)).not.toEqual(first)
  })
  it('does not attach a scope to unrelated, external or non-POST calls', async () => {
    const session = createSession()
    for (const input of [{ method: 'GET', url: request.url }, { method: 'POST', url: '/api/auth/user' },
      { method: 'POST', url: 'https://example.com/api/earnings/answer-reviews' }]) {
      expect(await earningCacheHeaders(session, input)).toEqual({})
    }
  })
  it('attaches the scope through the actual generated API client without changing its payload', async () => {
    const session = { ...createSession(), registerOwnerId: 'company' }
    const fetch = vi.fn<typeof globalThis.fetch>(async () => new Response(JSON.stringify({ outcome: 'confirmed' }), {
      headers: { 'content-type': 'application/json' },
    }))
    vi.stubGlobal('fetch', fetch)
    setRequestHeadersGetter(input => earningCacheHeaders(session, input))
    const body = { code: 'CELL' } as Parameters<typeof reviewEarningAnswer>[0]
    await reviewEarningAnswer(body)
    const init = fetch.mock.calls[0][1] as RequestInit
    expect(new Headers(init.headers).get('X-Earning-Cache-Scope')).toMatch(/^[a-f0-9]{64}$/)
    expect(init.body).toBe(JSON.stringify(body))
  })
  it('still allows live requests if browser crypto is unavailable', async () => {
    vi.stubGlobal('crypto', {})
    expect(await earningCacheHeaders(createSession(), request)).toEqual({})
  })
})
