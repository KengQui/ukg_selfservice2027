import { act, useReducer } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { reviewTips, type TipsReviewResult } from '@workspace/api-client-react'
import { createSession, parseSession, reduceSession, type EarningSession, type SessionAction } from './session'
import { SessionContext } from './sessionContext'
import { TIPS_OPENING_OPTIONS, tipsBasis, tipsOpening } from './tipsFlow'
import type { TipsCode } from './tipsIdentity'
import { discussionEntries, canEnterOptimization, previewCanApply, previewItems, previewWorkIds } from './deferredReview'
import StepReview from './StepReview'
import StepDiscussionReview from './StepDiscussionReview'
import DiscussionAcknowledgment from './DiscussionAcknowledgment'
import { loadSession, saveSession, writeWorkingCopy } from './storage'
import { finalConfiguration } from './configuration'

vi.mock('@workspace/api-client-react', async original => ({
  ...await original<typeof import('@workspace/api-client-react')>(),
  reviewTips: vi.fn(),
  summarizeEarningDiscussion: vi.fn(() => new Promise(() => {})),
}))
const recommendation: TipsReviewResult = { outcome: 'recommendation', reason: 'Card tips still need to be paid in paychecks.',
  question: null, options: null, rollUp: 'Charge Tips', splitReview: false }
const pending: TipsReviewResult = { ...recommendation, outcome: 'pending', rollUp: null, splitReview: true,
  reason: 'The company uses both payment paths. The setup team needs to verify separate treatments.' }
const question: TipsReviewResult = { ...recommendation, outcome: 'question', rollUp: null,
  question: 'How does your company collect the tips?', options: ['Card payments', 'Cash collected by the company'] }
const run = (state: EarningSession, ...actions: SessionAction[]) => actions.reduce((s, action) => reduceSession(s, action, s.updatedAt + 1), state)
function deferredTips(code: TipsCode = 'TIPS') {
  const options = TIPS_OPENING_OPTIONS.map(o => ({ ...o, ...(o.id === 'other' ? { details: true } : {}) }))
  return run({ ...createSession(1), step: 'questions', rounds: [{ number: 1, itemIds: [code], submitted: false }] },
    { type: 'tips', itemId: code, event: { kind: 'defer', checked: true } },
    { type: 'selectDeferredQuestion', itemId: code, source: {
      question: tipsOpening(code), options, choices: options.map(o => o.label), control: 'choices',
    } }, { type: 'submitRound' })
}
function enteredTips(code: TipsCode = 'TIPS') {
  const original = deferredTips(code)
  const entry = discussionEntries(original)[0]
  return run(original, { type: 'setDiscussionAnswer', itemId: code, question: entry.question,
    basis: entry.basis, kind: 'review-choices', change: { choice: 'paycheck-paid' } }, { type: 'prepareDiscussionReview' })
}
function checkTips(state: EarningSession, result: TipsReviewResult, code: TipsCode = 'TIPS') {
  return run(state, { type: 'editDiscussionWork', identity: state.discussionPreview!.identity, action: {
    type: 'tips', itemId: code, event: { kind: 'checked', basis: tipsBasis(state.discussionPreview!.answers[code], code), result },
  } })
}
const store = () => {
  const data = new Map<string, string>()
  return { getItem: (key: string) => data.get(key) ?? null, setItem: (key: string, value: string) => { data.set(key, value) },
    removeItem: (key: string) => { data.delete(key) } }
}
let root: Root | undefined
let host: HTMLDivElement
let latest: EarningSession
const originalScroll = HTMLElement.prototype.scrollIntoView
function mount(state: EarningSession) {
  vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT', true)
  HTMLElement.prototype.scrollIntoView = vi.fn()
  host = document.createElement('div'); document.body.append(host); root = createRoot(host)
  function Harness() {
    const [session, dispatch] = useReducer((s: EarningSession, a: SessionAction) => run(s, a), state)
    latest = session
    return <SessionContext.Provider value={{ session, dispatch, save: () => true, restart: () => true }}>
      <DiscussionAcknowledgment />
      {session.step === 'discussionReview' ? <StepDiscussionReview /> : <StepReview />}
    </SessionContext.Provider>
  }
  act(() => root!.render(<Harness />))
}
const button = (id: string) => host.querySelector<HTMLButtonElement>(`[data-testid="${id}"]`)!
const click = (id: string) => act(() => button(id).click())
afterEach(() => { if (root) act(() => root!.unmount()); root = undefined; host?.remove()
  HTMLElement.prototype.scrollIntoView = originalScroll; vi.clearAllMocks(); vi.unstubAllGlobals() })

describe('deferred TIPS summary and explicit application', () => {
  it.each([
    ['TIPS', 'review'], ['TIPS OWED', 'review'],
    ['TIPS', 'discussionReview'], ['TIPS OWED', 'discussionReview'],
  ] as const)('keeps %s split actions non-mutating on %s', (code, step) => {
    const state = checkTips(enteredTips(code), pending, code)
    mount({ ...state, step })
    const actions = () => [...host.querySelectorAll<HTMLButtonElement>('.ec-tip-split button')]
      .filter(button => !button.closest('[hidden]'))
    expect(actions().map(button => button.textContent?.trim())).toEqual(['Set up new code', 'Do it later'])
    const before = JSON.stringify(latest)
    const url = window.location.href
    act(() => actions()[0].click())
    expect(host.textContent).toContain('New-code setup isn’t available here yet')
    act(() => actions()[1].click())
    expect(host.textContent).toContain('new code still needs setup')
    expect(JSON.stringify(latest)).toBe(before)
    expect(window.location.href).toBe(url)
    expect(latest.resolutions[code].status).toBe('customer')
    expect(previewItems(latest)[0].assessment.status).toBe('setupReview')
    expect(previewCanApply(latest)).toBe(true)
    expect(button('button-apply-answers').disabled).toBe(false)
    expect(parseSession(JSON.stringify(latest))?.discussionPreview).toEqual(latest.discussionPreview)
    expect(reviewTips).not.toHaveBeenCalled()
  })
  it.each([recommendation, pending])('retains a checked $outcome through preview, explicit Apply and restore', async result => {
    const supported = result.outcome === 'recommendation'
    let finish!: (result: TipsReviewResult) => void
    vi.mocked(reviewTips).mockImplementation(() => new Promise(resolve => { finish = resolve }))
    const original = deferredTips()
    mount(original)
    expect(discussionEntries(latest)[0].target).toEqual({ kind: 'tips', id: 'opening' })
    act(() => host.querySelector<HTMLLabelElement>('[data-testid="choice-discussion-TIPS-0-paycheck-paid"] label')!.click())
    expect(host.textContent).toContain('1 of 1 opening answer entered')
    expect(latest.step).toBe('review')
    expect(latest.resolutions.TIPS.status).toBe('customer')
    expect(reviewTips).toHaveBeenCalledTimes(1)
    expect(button('button-apply-answers').disabled).toBe(true)
    expect(previewItems(latest)[0].assessment.status).toBe('checking')
    await act(async () => { finish(result); await Promise.resolve() })
    expect(previewItems(latest)[0]).toMatchObject({ ready: true, assessment: { status: supported ? 'ready' : 'setupReview' } })
    expect(host.querySelector('[data-testid="row-cheat-TIPS"] .ec-setup-summary')).not.toBeNull()
    expect(host.textContent).not.toMatch(/Confirm setup|Change answers/)
    if (!supported) expect(host.textContent).toContain('No tip treatment, Ready reference or separate code will be applied.')
    expect(previewWorkIds(latest)).toEqual([])
    expect(button('button-apply-answers').disabled).toBe(false)
    expect(latest.resolutions.TIPS.status).toBe('customer')
    expect(latest.discussionApplications).toBeUndefined()
    const stores = { working: store(), saved: store() }
    writeWorkingCopy(stores, latest)
    expect(saveSession(stores, latest)).toBe(true)
    const restored = loadSession({ working: store(), saved: stores.saved })
    expect(restored.discussionAnswers).toEqual(latest.discussionAnswers)
    expect(restored.discussionPreview).toEqual(latest.discussionPreview)
    expect(previewCanApply(restored)).toBe(true)
    expect(restored.resolutions).toEqual(original.resolutions)
    expect(reviewTips).toHaveBeenCalledTimes(1)
    click('button-apply-answers')
    expect(latest.resolutions.TIPS).toMatchObject({ status: supported ? 'resolved' : 'review' })
    if (supported) expect(latest.resolutions.TIPS).toHaveProperty('reference.name', 'Charge Tips')
    else expect(latest.resolutions.TIPS).not.toHaveProperty('reference')
    expect(latest.resolutions['TIPS RPT']).toBeUndefined()
    expect(latest.rounds.flatMap(round => round.itemIds)).not.toContain('TIPS RPT')
    expect(discussionEntries(latest)).toEqual([])
    expect(canEnterOptimization(latest)).toBe(supported)
    expect(latest.discussionApplications).toHaveLength(1)
    expect(latest.discussionApplications![0].outcomes.TIPS).toEqual(latest.resolutions.TIPS)
    expect(latest.discussionApplications![0].originalAnswers.TIPS).toEqual(original.answers.TIPS)
    if (!supported) expect(host.querySelector('[data-testid="discussion-applied"]')?.textContent).toContain('A setup specialist still needs to review its setup.')
    const reopened = parseSession(JSON.stringify(latest))!
    expect(reopened.resolutions.TIPS).toEqual(latest.resolutions.TIPS)
    expect(reopened.answers.TIPS.tipsReview?.check?.result).toEqual(result)
    expect(reopened.discussionApplications).toEqual(latest.discussionApplications)
    expect(finalConfiguration(reopened).find(row => row.code === 'TIPS')?.reference?.name).toBe(supported ? 'Charge Tips' : undefined)
  })

  it('blocks missing/stale checks, questions and retryable problems rather than treating them as review-ready', () => {
    const state = enteredTips()
    expect(previewCanApply(state)).toBe(false)
    const needs = checkTips(state, question)
    expect(previewItems(needs)[0].assessment.status).toBe('missing')
    expect(previewCanApply(needs)).toBe(false)
    const checked = checkTips(state, recommendation)
    expect(previewCanApply(checked)).toBe(true)
    const problem = run(checked, { type: 'setDiscussionCheck', identity: checked.discussionPreview!.identity!,
      key: 'TIPS:questions', check: { status: 'problem', basis: tipsBasis(checked.discussionPreview!.answers.TIPS), message: 'Try again.' } })
    expect(previewCanApply(problem)).toBe(false)
    expect(run(problem, { type: 'applyDiscussionReview' }).resolutions.TIPS.status).toBe('customer')
    const stale = structuredClone(checked)
    stale.discussionPreview!.answers.TIPS.tipsReview!.check!.basis = 'stale'
    expect(previewCanApply(stale)).toBe(false)
    expect(run(stale, { type: 'applyDiscussionReview' }).discussionApplications).toBeUndefined()
  })

  it('completes a deferred follow-up without repeating the opening and applies only on Apply', () => {
    let state: EarningSession = { ...createSession(1), step: 'questions', rounds: [{ number: 1, itemIds: ['TIPS'], submitted: false }] }
    state = run(state, { type: 'tips', itemId: 'TIPS', event: { kind: 'answer', id: 'opening', value: 'paycheck-paid' } })
    state = run(state, { type: 'tips', itemId: 'TIPS', event: { kind: 'checked', basis: tipsBasis(state.answers.TIPS), result: question } },
      { type: 'tips', itemId: 'TIPS', event: { kind: 'defer', checked: true } },
      { type: 'selectDeferredQuestion', itemId: 'TIPS', source: { question: question.question!, choices: question.options!,
        options: question.options!.map((label, index) => ({ id: `option-${index}`, label })), control: 'choices' } },
      { type: 'submitRound' })
    const entry = discussionEntries(state)[0]
    const original = state.answers.TIPS.tipsReview!.entries[0]
    expect(entry.target).toEqual({ kind: 'tips', id: 'follow-up-1' })
    state = run(state, { type: 'setDiscussionAnswer', itemId: 'TIPS', question: entry.question, basis: entry.basis,
      kind: 'review-choices', change: { choice: 'option-0' } }, { type: 'prepareDiscussionReview' })
    state = checkTips(state, recommendation)
    expect(previewCanApply(state)).toBe(true)
    const applied = run(state, { type: 'applyDiscussionReview' })
    expect(applied.answers.TIPS.tipsReview?.entries).toHaveLength(2)
    expect(applied.answers.TIPS.tipsReview?.entries[0]).toEqual(original)
    expect(applied.answers.TIPS.tipsReview?.entries[1].answer).toBe('Card payments')
    expect(applied.resolutions.TIPS.status).toBe('resolved')
    expect(applied.resolutions.TIPS).toHaveProperty('reference.name', 'Charge Tips')
    expect(parseSession(JSON.stringify(applied))?.answers.TIPS).toEqual(applied.answers.TIPS)
  })
})
