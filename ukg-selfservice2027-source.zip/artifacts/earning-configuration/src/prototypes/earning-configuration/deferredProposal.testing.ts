import { createSession, reduceSession, type EarningSession } from './session'
import { ASK_CUSTOMER, findItem } from './sampleRegister'
import { discussionEntries } from './deferredReview'

/** Deterministic, fictional test input; never imported by the application. */
export function deferredProposalFixture(id = 'SPPAY', reply = 'Extra pay for temporary project leadership') {
  const item = findItem(id)
  let session: EarningSession = { ...createSession(1), step: 'questions', rounds: [{ number: 1, itemIds: [id], submitted: false }] }
  session = reduceSession(session, { type: 'choose', itemId: id, choice: ASK_CUSTOMER }, 2)
  session = reduceSession(session, { type: 'selectDeferredQuestion', itemId: id, source: {
    question: item.type === 'unidentified' ? item.purposeFirst?.question ?? item.question : item.question,
    choices: item.type === 'misclassification' ? [item.accept.label] : [],
    options: item.type === 'misclassification' ? [{ id: item.accept.id, label: item.accept.label }] : [],
  } }, 3)
  session = reduceSession(session, { type: 'submitRound' }, 4)
  const entry = discussionEntries(session)[0]
  if (!entry) throw new Error('Test fixture has no explicit deferred question')
  session = reduceSession(session, { type: 'setDiscussionAnswer', itemId: id, question: entry.question, basis: entry.basis,
    kind: entry.options.length ? 'review-choices' : 'text',
    change: entry.options.length ? { choice: entry.options[0].id } : { text: reply } }, 5)
  return reduceSession(session, { type: 'prepareDiscussionReview' }, 6)
}
