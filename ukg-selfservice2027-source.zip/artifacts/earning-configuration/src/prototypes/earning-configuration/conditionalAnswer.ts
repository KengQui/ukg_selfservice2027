import { ASK_CUSTOMER, CLEAR_CHOICE } from './sampleRegister'
import { conditionalDefinitionFor } from './benefitQuestions'
import { nextConditionalAnswers } from './conditionalQuestions'
import type { ItemAnswer, SessionAction } from './session'

/** Shared by the main review and the customer reply dialog. Switching purpose resets the entire branch. */
export function nextConditionalAnswer(itemId: string, previous: ItemAnswer, action: SessionAction): ItemAnswer {
  const definition = conditionalDefinitionFor(itemId, previous)
  if (!definition) return previous
  if (action.type === 'choose' && action.choice === CLEAR_CHOICE) return previous.choice === ASK_CUSTOMER
    ? previous.conditionalHistory?.length ? { conditionalHistory: previous.conditionalHistory }
      : previous.conditionalReview && previous.conditionalReview.version !== definition.version
        ? { conditionalHistory: [previous.conditionalReview] } : {} : previous
  if (action.type === 'choose' && action.choice === ASK_CUSTOMER) return { ...previous, choice: ASK_CUSTOMER }
  const event = action.type === 'choose' ? { type: 'primary' as const, choice: action.choice }
    : action.type === 'conditionalReview' ? action.event : undefined
  if (!event || (previous.choice === ASK_CUSTOMER && event.type !== 'primary')) return previous
  const next = nextConditionalAnswers(definition, previous.conditionalReview, event)
  if (!next || next === previous.conditionalReview) {
    return event.type === 'primary' && previous.choice === ASK_CUSTOMER && next
      ? { ...previous, choice: next.primary } : previous
  }
  // The newer branch contains reported intent only: discard former setup attachments and AI acceptance.
  const history = [...(previous.conditionalHistory ?? []),
    ...(previous.conditionalReview && previous.conditionalReview.version !== definition.version ? [previous.conditionalReview] : [])]
  return { choice: next.primary, conditionalReview: next, ...(previous.gtlSource ? { gtlSource: previous.gtlSource } : {}),
    ...(previous.gtlHistory ? { gtlHistory: previous.gtlHistory } : {}),
    ...(history.length ? { conditionalHistory: history } : {}) }
}
