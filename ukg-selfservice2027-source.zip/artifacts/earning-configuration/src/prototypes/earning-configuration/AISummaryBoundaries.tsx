import { useState } from 'react'
import { Button, Dialog } from '@ready/dls/compatibility'
import './aiSummaryBoundaries.css'

/** Informational only: opening help never reads or changes the review session. */
export default function AISummaryBoundaries() {
  const [open, setOpen] = useState(false)

  return (
    <>
      <Button type="button" variant="tertiary" size="large" borderShape="none"
        iconLeftName="info" iconSize={20} className="ec-summary-help"
        aria-label="About the AI summary" aria-haspopup="dialog" aria-expanded={open}
        onClick={() => setOpen(true)} />
      <Dialog open={open} onClose={() => setOpen(false)} size="normal" className="ec-summary-dialog"
        title="Boundaries for the AI summary">
        <ul className="ec-summary-boundaries" tabIndex={0}>
          <li>Summarize relevant answers, not the entire review. Include answers from a related code when they explain the current question.</li>
          <li>Distinguish facts from suggestions. An AI-proposed name or match is not an accepted decision until the user accepts it.</li>
          <li>Do not add questions. AI can explain the remaining gap, but the active question must still be the one explicitly deferred.</li>
          <li>Do not infer missing facts, especially tax treatment, from a code name or register.</li>
          <li>Keep discussion responses separate from applied decisions. Something recorded during the call must not be described as an approved setup change.</li>
          <li>Keep the original answers accessible. The summary helps people understand them; it does not replace them.</li>
          <li>If there are no earlier answers, do not manufacture context. Show the question and available source evidence.</li>
        </ul>
      </Dialog>
    </>
  )
}
