import type { ConditionalDefinition, ConditionalFollowUp } from './conditionalQuestions'
import { GTL_QUESTIONS } from './gtlQuestions'
import { uploadedGtlDefinition } from './gtlEvidence'
import { READY } from './sampleRegister'
import { medicalClassification } from './medicalClassification'

const additionalInformation = {
  id: 'medical-purpose-information-v2',
  question: 'Can you tell us a little more about what MED ER represents?',
  options: [
    { id: 'description', label: 'We can share a brief description', comment: 'optional' },
    { id: 'no-information', label: "We're not sure yet", uncertain: true },
  ],
} satisfies ConditionalFollowUp

export const MEDICAL_CONTRIBUTION_QUESTIONS = {
  id: 'medical-contribution-intent',
  version: 2,
  code: 'MED ER',
  codeCategory: 'earning',
  assessment: (purpose, option, conflict) => medicalClassification(purpose, option, conflict, Object.values(READY)),
  question: 'What does MED ER represent?',
  introduction: "Your pay register lists MED ER as an earning. It may track what your company pays toward your team's medical insurance. Its purpose helps us find the right setup.",
  recommendedAction: 'The setup team needs to check the purpose, tax treatment and available setup before accepting a match.',
  purposes: [
    {
      id: 'only-records', label: "We pay toward our team's medical insurance",
      detail: 'This tracks the company’s insurance contribution, without paying extra cash to our people.',
      category: 'Potential Employer Contribution', cashCompensation: 'No',
      conflictingComment: /\b(?:paid directly to employees|adds cash to (?:employee|the) pay)\b/i,
      followUp: {
        id: 'employer-tax-treatment-v2',
        question: "Does MED ER only track insurance costs, or is it also included in your team's taxable pay?",
        options: [
          { id: 'tracking-only', label: 'We only track the insurance contribution; it does not affect taxable pay', taxTreatment: 'Employer contribution tracking only' },
          { id: 'taxable', label: 'We include it in taxable pay, without paying extra cash', taxTreatment: 'Included in taxable pay, as reported' },
          { id: 'unsure', label: "We're not sure yet", uncertain: true },
        ],
      },
    },
    {
      id: 'additional-compensation', label: 'We pay money directly to our people',
      detail: 'This pays a medical allowance or repays medical expenses.',
      category: 'Potential Employee Compensation', cashCompensation: 'Yes',
      conflictingComment: /\b(?:no direct cash payment|not paid (?:directly )?to employees|employer tracking only)\b/i,
      followUp: {
        id: 'medical-payment-method-v2', question: 'How is this money provided to your people?',
        options: [
          { id: 'allowance', label: 'We pay a regular medical allowance with wages' },
          { id: 'reimbursement', label: 'We repay medical expenses our people have already paid' },
          { id: 'unsure', label: "We're not sure yet", uncertain: true, comment: 'optional' },
          { id: 'other', label: 'Something else', uncertain: true, comment: 'optional' },
        ],
      },
    },
    {
      id: 'uncertain-purpose', label: "We're not sure yet",
      category: 'Needs Review', uncertain: true, cashCompensation: 'Unknown',
      followUp: additionalInformation,
    },
    {
      id: 'other-purpose', label: 'Something else',
      category: 'Needs Review', uncertain: true, cashCompensation: 'Unknown',
      followUp: additionalInformation,
    },
  ],
} satisfies ConditionalDefinition

const DEFINITIONS: readonly ConditionalDefinition[] = [MEDICAL_CONTRIBUTION_QUESTIONS, GTL_QUESTIONS]
export const conditionalDefinitionFor = (itemId: string, answer?: import('./session').ItemAnswer) => DEFINITIONS.find(definition => (definition.itemId ?? definition.code) === itemId) ?? uploadedGtlDefinition(itemId, answer?.gtlSource)
