import { act, useReducer } from 'react'
import { readFileSync } from 'node:fs'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { draftEarningCustomerQuestions } from '@workspace/api-client-react'
import { createSession, reduceSession, parseSession, reviewPages, type EarningSession, type SessionAction } from './session'
import { ASK_CUSTOMER, READY, findItem } from './sampleRegister'
import { customerDraftBasis, currentCustomerDraft } from './customerQuestionData'
import { customerDraftRequest, requestCustomerDraft, DRAFT_ERROR } from './customerQuestionDraft'
import { cheatSheetGroups } from './cheatSheet'
import { callEvidence } from './cheatSheetAnswers'
import { customerQuestionList, summaryCsv } from './summary'
import { migrateReimbursements } from './reimbursements'
import { bryteFacts } from './bryteFacts'
import { SessionContext } from './sessionContext'
import StepReview from './StepReview'
import CustomerReplyDialog from './CustomerReplyDialog'
import { CELL_ID, cellCustomerQuestion, cellQuestionStage } from './cell'
import { loadSession, saveSession, writeWorkingCopy, type SessionStores } from './storage'
import { SAMPLE_REGISTER_FILE, SAMPLE_REGISTER_FILES, SAMPLE_PAY_REGISTERS } from './sampleDocument'

// The package test command runs here. CSS imports are stubbed and Vite rewrites asset URLs.
const cheatSheetStyles = readFileSync('src/prototypes/earning-configuration/cheatSheet.css', 'utf8')

vi.mock('@workspace/api-client-react', () => ({ draftEarningCustomerQuestions: vi.fn() }))
const result = { questions: ['How does your company calculate mileage payments?'], reason: 'The payment method identifies which business facts are still needed.' }
const run = (session: EarningSession, ...actions: SessionAction[]) => actions.reduce((state, action) => reduceSession(state, action, 7), session)
const deferred = () => {
  let state = reduceSession(createSession(1), { type: 'startReview' })
  for (const id of reviewPages(state).flat()) state = reduceSession(state, { type: 'choose', itemId: id, choice: ASK_CUSTOMER })
  return run(state, { type: 'submitRound' }, { type: 'finishReevaluation' })
}
const oneDeferred = (): EarningSession => {
  const state = deferred()
  return { ...state, rounds: [{ number: 1, itemIds: ['MILEAGE'], submitted: true, results: { resolved: [], deferred: ['MILEAGE'], findings: [] } }],
    resolutions: { MILEAGE: { status: 'customer', round: 1 } },
    customerQuestions: state.customerQuestions.filter(question => question.itemId === 'MILEAGE') }
}
const saveDraft = (state: EarningSession, id = 'MILEAGE') => reduceSession(state,
  { type: 'saveCustomerDraft', itemId: id, basis: customerDraftBasis(state.answers[id]), draft: result })

describe('customer call data', () => {
  it('keeps call responses separate from setup decisions and supports editing and clearing', () => {
    const state = oneDeferred()
    const noted = run(state, { type: 'setCallAnswer', itemId: 'MILEAGE', text: 'We reimburse 70 cents per mile.\nPaid each payday.' })
    expect(noted.callAnswers?.MILEAGE).toBe('We reimburse 70 cents per mile.\nPaid each payday.')
    expect(noted.answers).toEqual(state.answers)
    expect(noted.resolutions).toEqual(state.resolutions)
    expect(noted.customerQuestions).toEqual(state.customerQuestions)
    expect(noted.customerReplies).toEqual(state.customerReplies)
    const edited = run(noted, { type: 'setCallAnswer', itemId: 'MILEAGE', text: 'Paid monthly.' })
    expect(edited.callAnswers?.MILEAGE).toBe('Paid monthly.')
    const cleared = run(edited, { type: 'setCallAnswer', itemId: 'MILEAGE', text: '' })
    expect(cleared.callAnswers?.MILEAGE).toBeUndefined()
    expect(parseSession(JSON.stringify(cleared))?.callAnswers?.MILEAGE).toBeUndefined()
    expect(run(state, { type: 'setCallAnswer', itemId: 'missing-code', text: 'Not a reviewed code' })).toBe(state)
  })
  it('restores call responses from working and explicitly saved copies without losing older sessions', () => {
    const memoryStore = () => {
      const data = new Map<string, string>()
      return { getItem: (key: string) => data.get(key) ?? null, setItem: (key: string, value: string) => { data.set(key, value) }, removeItem: (key: string) => { data.delete(key) } }
    }
    const stores: SessionStores = { working: memoryStore(), saved: memoryStore() }
    const state = run(oneDeferred(), { type: 'setCallAnswer', itemId: 'MILEAGE', text: 'Paid monthly.' })
    writeWorkingCopy(stores, state)
    expect(loadSession(stores).callAnswers).toEqual(state.callAnswers)
    expect(saveSession(stores, state)).toBe(true)
    expect(loadSession({ ...stores, working: memoryStore() }).callAnswers).toEqual(state.callAnswers)
    expect(parseSession(JSON.stringify(oneDeferred()))).not.toBeNull()
    expect(parseSession(JSON.stringify(oneDeferred()))?.callAnswers).toBeUndefined()
    const malformed = parseSession(JSON.stringify({ ...state, callAnswers: { MILEAGE: 9, SPPAY: 'Customer confirmed weekend pay.' } }))
    expect(malformed?.callAnswers).toEqual({ SPPAY: 'Customer confirmed weekend pay.' })
    expect(malformed?.answers).toEqual(state.answers)
  })
  it('groups all submitted rounds by review section and includes split, combined, removed and setup review', () => {
    const state: EarningSession = { ...oneDeferred(),
      rounds: [
        { number: 1, submitted: true, itemIds: ['ADJ2', 'SPPAY', 'MILEAGE', 'OTPREM', 'CELL-purpose'], results: { resolved: ['OTPREM', 'CELL-purpose'], deferred: ['MILEAGE'], findings: ['TIPS RPT'], review: ['SPPAY'], removed: ['ADJ2'] } },
        { number: 2, submitted: true, itemIds: ['TIPS RPT'], results: { resolved: ['TIPS RPT'], deferred: [], findings: [] } },
      ],
      answers: { MILEAGE: { choice: ASK_CUSTOMER }, OTPREM: { choice: 'premium' }, SPPAY: { description: 'Extra weekend pay' },
        'CELL-purpose': { choice: 'both', followUps: { treatment: 'qualifying', split: 'accept' } }, ADJ2: { retain: 'remove' }, 'TIPS RPT': { choice: 'accept' } },
      resolutions: { MILEAGE: { status: 'customer', round: 1 }, OTPREM: { status: 'resolved', round: 1, reference: READY.overtimePremium, combinedInto: 'OTMFG' },
        SPPAY: { status: 'review', round: 1, note: 'Extra weekend pay' }, ADJ2: { status: 'removed', round: 1 },
        'CELL-purpose': { status: 'resolved', round: 1, reference: READY.cellAllowance, outputs: [{ code: 'CELL ALLOW', reference: READY.cellAllowance }, { code: 'CELL REIMB', reference: READY.cellReimbursement }] },
        'TIPS RPT': { status: 'resolved', round: 2, reference: READY.tipsReported } },
    }
    const groups = cheatSheetGroups(state)
    expect(groups.map(group => group.title)).toEqual(['To discuss', 'Review results', 'With the setup team'])
    expect(groups[1].rows.map(row => row.id)).toEqual(['OTPREM', 'TIPS RPT', 'CELL-purpose', 'ADJ2'])
    expect(groups[1].rows[0].setup).toContain('Combined into OTMFG')
    expect(groups[1].rows[2].setup).toContain('Split CELL into CELL ALLOW')
    expect(groups[1].rows[3].setup).toBe('Removed from the setup.')
    expect(groups[2].rows[0].answers.join(' ')).toContain('Extra weekend pay')
    expect(groups[0].rows[0].evidence.join(' ')).toMatch(/Earnings.*\$48,200\.00.*31 people/)
    expect(groups[0].rows[0].evidence).toEqual(['Earnings · $48,200.00 · 31 people'])
    expect(groups.flatMap(group => group.rows).flatMap(row => row.evidence).join(' ')).not.toMatch(/description:/i)
    expect(groups[0].rows[0].answers).toContain('Not answered yet')
    expect(groups.flatMap(group => group.rows).every(row =>
      (row.deferred ? row.questions.length > 0 : row.questions.length === 0) && row.reason && row.setup)).toBe(true)
    expect(groups.flatMap(group => group.rows).flatMap(row => row.evidence).join(' ')).not.toMatch(/taxable|pre-tax|non-taxable/i)
    expect(groups[1].rows[1].evidence[0]).toContain('Not shown as a separate code')
  })
  it('sends register evidence, choices and earlier follow-up answers without internal ids as answers', () => {
    const state = oneDeferred()
    state.answers.MILEAGE = { choice: 'per-mile', mileageRate: { amount: '0.9', submitted: true } }
    const request = customerDraftRequest(migrateReimbursements(state), 'MILEAGE')
    expect(request.facts).toEqual({ description: null, section: 'earnings', peopleCount: 31, amount: 48200 })
    expect(request.reimbursement).toBe(true)
    expect(request.earlierAnswers.some(answer => answer.answer.includes('0.9'))).toBe(true)
    const spec = findItem('ADJ2')
    if (spec.type !== 'unidentified' || spec.script.kind !== 'described') throw new Error('Missing test fixture')
    const first = spec.script.questions[0]
    const second = spec.script.questions[1]
    const evidence = callEvidence(spec, { description: 'Business payment', followUps: { [first.id]: first.options[0].id, [second.id]: ASK_CUSTOMER } })
    expect(evidence.answers).toContainEqual({ question: first.question, answer: [first.options[0].label, first.options[0].detail].filter(Boolean).join(' — ') })
    expect(evidence.questions.some(question => question.question === second.question)).toBe(true)
    expect(evidence.answers.some(answer => answer.answer === ASK_CUSTOMER)).toBe(false)
  })
  it('saves drafts once, restores them and reuses exact wording in summary, CSV and Ask Bryte', () => {
    const saved = saveDraft(deferred())
    const restored = parseSession(JSON.stringify(saved))!
    expect(restored).not.toBeNull()
    const question = customerQuestionList(restored).find(question => question.id.startsWith('reimbursement:MILEAGE:'))!
    expect(question.question).toBe(result.questions.join('\n\n'))
    expect(summaryCsv(restored, String)).toContain(result.questions.join('\n\n'))
    expect(bryteFacts(restored).facts.draftedCustomerQuestions).toContain(result.questions[0])
    expect(saveDraft(saved).customerQuestions).toEqual(saved.customerQuestions)
  })
  it('rejects late drafts and clears the old one when answers change, including a partial customer reply', () => {
    const saved = saveDraft(deferred())
    const basis = customerDraftBasis(saved.answers.MILEAGE)
    const reopened: EarningSession = { ...saved, step: 'questions', rounds: [...saved.rounds, { number: 2, itemIds: ['MILEAGE'], submitted: false }] }
    const edited = run(reopened, { type: 'choose', itemId: 'MILEAGE', choice: 'fixed' }, { type: 'choose', itemId: 'MILEAGE', choice: ASK_CUSTOMER })
    expect(edited.customerQuestions.find(q => q.itemId === 'MILEAGE')?.draft).toBeUndefined()
    // Different evidence, not a request from the old answer snapshot.
    const changed = { ...edited, answers: { ...edited.answers, MILEAGE: { choice: ASK_CUSTOMER, description: 'Updated evidence' } } }
    const late = reduceSession(changed, { type: 'saveCustomerDraft', itemId: 'MILEAGE', basis, draft: result })
    expect(late.customerQuestions.find(q => q.itemId === 'MILEAGE')?.draft).toBeUndefined()
    expect(currentCustomerDraft(changed, saved.customerQuestions.find(q => q.itemId === 'MILEAGE'))).toBeUndefined()
  })
  it('older saves keep their exact wording and do not become draft requests', () => {
    const old = deferred()
    old.customerQuestions = old.customerQuestions.map(({ draftBasis: _basis, ...question }) => ({ ...question, question: `Earlier wording for ${question.code}?` }))
    old.sent = { at: 1, to: 'payroll@example.test', questionIds: ['classification:MILEAGE'] }
    const restored = parseSession(JSON.stringify(old))!
    expect(restored).not.toBeNull()
    expect(customerQuestionList(restored).find(q => q.id === 'classification:MILEAGE')?.question).toBe('Earlier wording for MILEAGE?')
    expect(restored.customerQuestions.every(question => question.draftBasis === undefined)).toBe(true)
    expect(saveDraft(restored)).toBe(restored)
  })
  it.each(['treatment', 'split'] as const)('keeps older partial CELL %s replies as history while asking the new outstanding question', stage => {
    let state = deferred()
    const opening = state.customerQuestions.find(question => question.itemId === CELL_ID)!.question
    state = run(state, { type: 'complete' }, { type: 'startOptimization' },
      ...['combine-overtime', 'split-bonus', 'inactive-JURY'].map((suggestionId): SessionAction =>
        ({ type: 'chooseOptimization', suggestionId, choice: 'keep' })),
      { type: 'submitOptimization' }, { type: 'completeOptimization' }, { type: 'startOvertime' },
      ...['multiRate', 'shiftDiff', 'samePeriodBonus', 'multiPeriodBonus', 'fixedSalary'].map((questionId): SessionAction =>
        ({ type: 'answerOvertime', questionId, answer: 'no' })),
      { type: 'confirmOvertime' }, { type: 'sendQuestions', to: 'customer@example.com' })
    // Exact pre-adaptive saved fixture: these questions were sent under their old meanings.
    state = { ...state, answers: { ...state.answers, [CELL_ID]: { choice: 'both', followUps: stage === 'split' ? { treatment: 'qualifying' } : {} } },
      sent: { ...state.sent!, questionIds: ['classification:CELL-purpose', ...(stage === 'split' ? ['classification:CELL-treatment'] : [])],
        questions: [{ id: 'classification:CELL-purpose', topic: 'allowances', codes: ['CELL'], question: opening, status: 'open' }] },
      customerReplies: { 'classification:CELL-purpose': { answer: 'both', text: 'We do both', at: 1 },
        ...(stage === 'split' ? { 'classification:CELL-treatment': { answer: 'qualifying', text: 'No, it’s tax-free', at: 2 } } : {}) } }
    // Pre-update saves kept the purpose question on the code even after these partial replies.
    state.customerQuestions = state.customerQuestions.map(({ draftBasis: _basis, draft: _draft, ...question }) =>
      question.itemId === CELL_ID ? { ...question, question: opening } : question)
    const restored = parseSession(JSON.stringify(state))!
    expect(restored).not.toBeNull()
    expect(restored.step).toBe('summary')
    const id = `classification:CELL-${cellQuestionStage(restored.answers[CELL_ID])}`
    const expected = cellCustomerQuestion(cellQuestionStage(restored.answers[CELL_ID])!, restored.answers[CELL_ID])
    expect(expected).not.toBe(opening)
    expect(expected).toContain('Why does your company provide the cellphone allowance?')
    expect(restored.customerReplies).toEqual(state.customerReplies)
    expect(restored.sent).toEqual(state.sent)
    expect(restored.answers[CELL_ID].cell?.earlier).toEqual(state.answers[CELL_ID])
    expect(customerQuestionList(restored).find(question => question.id === id)).toMatchObject({ question: expected, status: 'open' })
    expect(cheatSheetGroups(restored).flatMap(group => group.rows).find(row => row.id === CELL_ID)?.questions).toEqual([expected])
    expect(customerDraftRequest(restored, CELL_ID).standardQuestion).toBe(expected)
    expect(summaryCsv(restored, String)).toContain(expected)
    const sent = run(restored, { type: 'sendQuestions', to: 'customer@example.com' })
    expect(sent.sent?.questions?.find(question => question.id === id)?.question).toBe(expected)
    expect(sent.sent?.questions?.find(question => question.id === 'classification:CELL-purpose')?.question).toBe(opening)
    // A current-stage AI draft wins, but one drafted for the earlier purpose cannot.
    const source = restored.customerQuestions.find(question => question.itemId === CELL_ID)!
    source.draft = { ...result, basis: customerDraftBasis({ choice: ASK_CUSTOMER }) }
    expect(customerQuestionList(restored).find(question => question.id === id)?.question).toBe(expected)
    source.draft.basis = customerDraftBasis(restored.answers[CELL_ID])
    expect(customerQuestionList(restored).find(question => question.id === id)?.question).toBe(result.questions.join('\n\n'))
  })
  it('redacts client inputs and only displays documented server errors', async () => {
    const state = oneDeferred()
    state.answers.MILEAGE.description = 'Contact owner@example.com'
    expect(JSON.stringify(customerDraftRequest(state, 'MILEAGE'))).not.toContain('owner@example.com')
    vi.mocked(draftEarningCustomerQuestions).mockRejectedValueOnce({ status: 502, data: { code: 'unavailable', error: 'Try again later.' } })
    expect(await requestCustomerDraft(customerDraftRequest(state, 'MILEAGE'), new AbortController().signal)).toEqual({ ok: false, message: 'Try again later.' })
    vi.mocked(draftEarningCustomerQuestions).mockRejectedValueOnce({ status: 400, data: { code: 'unexpected', error: 'Internal details' } })
    expect(await requestCustomerDraft(customerDraftRequest(state, 'MILEAGE'), new AbortController().signal)).toEqual({ ok: false, message: DRAFT_ERROR })
  })
})

let root: Root | undefined
let host: HTMLDivElement
let latest: EarningSession
function mount(state: EarningSession, child = <StepReview />) {
  host = document.createElement('div'); document.body.append(host); root = createRoot(host)
  function Harness() {
    const [session, dispatch] = useReducer((state: EarningSession, action: SessionAction) => reduceSession(state, action), state)
    latest = session
    return <SessionContext.Provider value={{ session, dispatch, save: () => true, restart: () => true }}>{child}</SessionContext.Provider>
  }
  act(() => root!.render(<Harness />))
}
afterEach(() => { if (root) act(() => root!.unmount()); root = undefined; host?.remove(); vi.clearAllMocks() })
const settle = async () => { await act(async () => { await Promise.resolve(); await Promise.resolve() }) }
const typeCallAnswer = (field: HTMLTextAreaElement, text: string) => act(() => {
  Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')!.set!.call(field, text)
  field.dispatchEvent(new Event('input', { bubbles: true }))
})

describe('payroll review summary page', () => {
  it('gives deferred and confirmed codes individual single-column cards without changing the setup group', () => {
    const state = deferred()
    state.customerQuestions = state.customerQuestions.map(({ draftBasis: _basis, ...question }) => question)
    state.resolutions.OTPREM = { status: 'resolved', round: 1, reference: READY.overtimePremium }
    state.resolutions.MILEAGE = { status: 'removed', round: 1 }
    state.resolutions.SPPAY = { status: 'review', round: 1, note: 'Customer will explain this payment.' }
    state.callAnswers = { OTPREM: 'Saved confirmation note.' }
    mount(state)
    const style = document.createElement('style')
    style.textContent = cheatSheetStyles
    host.append(style)
    const ask = host.querySelector('[data-testid="group-cheat-ask"]')!
    const rows = [...ask.querySelectorAll('.ec-cheat__row')]
    expect(rows.length).toBeGreaterThan(1)
    expect(ask.querySelector(':scope > .ec-cheat__list--cards')).not.toBeNull()
    expect(ask.querySelectorAll('.ec-cheat__card')).toHaveLength(rows.length)
    const confirm = host.querySelector('[data-testid="group-cheat-confirm"]')!
    const confirmedRows = [...confirm.querySelectorAll('.ec-cheat__row')]
    expect(confirmedRows).toHaveLength(2)
    expect(confirm.querySelector(':scope > .ec-cheat__list--cards')).not.toBeNull()
    expect(confirm.querySelectorAll('.ec-cheat__card')).toHaveLength(confirmedRows.length)
    for (const row of [...rows, ...confirmedRows]) {
      expect(row.firstElementChild?.classList.contains('ec-cheat__card')).toBe(true)
      const grid = row.querySelector('.ec-cheat__grid')!
      expect(getComputedStyle(grid).gridTemplateColumns).toBe('minmax(0, 1fr)')
      expect([...grid.querySelectorAll(':scope > .ec-cheat__cell > dt')].map(label => label.textContent)).toEqual([
        rows.includes(row) ? 'Details to confirm' : 'Result',
      ])
      expect(row.querySelectorAll('textarea[id^="call-answer-"]')).toHaveLength(1)
      expect(row.querySelector('.ec-register-details')).not.toBeNull()
      expect(row.querySelector<HTMLDetailsElement>('.ec-cheat__why')?.open).toBe(false)
      expect(row.querySelector<HTMLDetailsElement>('.ec-register-details')?.open).toBe(false)
      expect(row.querySelector('.ec-register-details__overview')?.closest('details')).not.toBeNull()
    }
    const setup = host.querySelector('[data-testid="group-cheat-setup"]')!
    expect(setup.querySelector('.ec-cheat__card')).toBeNull()
    expect(getComputedStyle(setup.querySelector('.ec-cheat__grid')!).gridTemplateColumns).toBe('repeat(2, minmax(0, 1fr))')
    const confirmedField = confirm.querySelector<HTMLTextAreaElement>('[data-testid="row-cheat-OTPREM"] textarea')!
    expect(confirmedField.value).toBe('Saved confirmation note.')
    typeCallAnswer(confirmedField, 'Updated confirmation note.')
    expect(latest.callAnswers?.OTPREM).toBe('Updated confirmation note.')
    typeCallAnswer(confirmedField, '')
    expect(latest.callAnswers?.OTPREM).toBeUndefined()
    const firstField = rows[0].querySelector<HTMLTextAreaElement>('textarea[id^="call-answer-"]')!
    const why = rows[0].querySelector<HTMLDetailsElement>('.ec-cheat__why')!
    expect(why.querySelector('summary')?.textContent).toBe('Why it matters')
    act(() => why.querySelector('summary')!.click())
    expect(why.open).toBe(true)
    typeCallAnswer(firstField, 'Confirmed on the call.')
    expect(why.open).toBe(true)
    act(() => why.querySelector('summary')!.click())
    expect(why.open).toBe(false)
    expect(firstField.value).toBe('Confirmed on the call.')
    expect(host.querySelectorAll('#review-notes-guidance')).toHaveLength(1)
    expect(host.textContent).toContain('Answers and notes don’t change the payroll setup.')
    expect(host.textContent).not.toMatch(/Nobody was sure yet|Ask these on the call|Settled by your team|Answered with Something else/)
    expect(latest.resolutions).toEqual(state.resolutions)
    expect(latest.customerQuestions).toEqual(state.customerQuestions)
    expect(draftEarningCustomerQuestions).not.toHaveBeenCalled()
  })
  it('shows both demo pay periods under one code and keeps one customer answer on reload', () => {
    const state = saveDraft(oneDeferred())
    state.files = SAMPLE_REGISTER_FILES
    state.callAnswers = { MILEAGE: 'Paid monthly.' }
    mount(parseSession(JSON.stringify(state))!)
    const rows = host.querySelectorAll('[data-testid="row-cheat-MILEAGE"]')
    expect(rows).toHaveLength(1)
    const details = rows[0].querySelector('.ec-register-details')!
    expect(details.querySelector('summary')?.textContent).toBe('View source')
    expect(details.querySelectorAll('.ec-register-details__source')).toHaveLength(2)
    for (const register of SAMPLE_PAY_REGISTERS) {
      expect(details.textContent).toContain(register.file.name)
      expect(details.textContent).toContain(register.period)
    }
    expect(details.textContent).toContain('$1,928.00')
    expect(details.textContent).toContain('$2,088.67')
    expect(details.textContent).not.toMatch(/12.month|The review uses them once/i)
    expect(details.querySelector('.ec-register-details__uploads')).toBeNull()
    expect(rows[0].querySelectorAll('textarea[id^="call-answer-"]')).toHaveLength(1)
    expect(rows[0].querySelector<HTMLTextAreaElement>('textarea[id^="call-answer-"]')?.value).toBe('Paid monthly.')
    expect(latest.resolutions).toEqual(state.resolutions)
  })
  it('expands register evidence separately from unread uploads without changing answers', () => {
    const state = saveDraft(oneDeferred())
    state.files = [
      SAMPLE_REGISTER_FILES[0],
      { id: 'january', name: 'January payroll.xlsx', sizeBytes: 1200, docType: 'Pay register' },
      { id: 'february', name: 'February payroll.pdf', sizeBytes: 1300, docType: 'Pay register' },
    ]
    mount(state)
    const details = host.querySelector<HTMLDetailsElement>('.ec-register-details')!
    expect(details.open).toBe(false)
    const summary = details.querySelector('summary')!
    expect(summary.textContent).toBe('View source')
    act(() => summary.click())
    expect(details.open).toBe(true)
    const source = details.querySelector('.ec-register-details__source')!
    expect(source.textContent).toContain(SAMPLE_REGISTER_FILES[0].name)
    expect(source.textContent).not.toMatch(/12.month/i)
    expect(source.textContent).toContain('$1,928.00')
    expect(source.textContent).not.toContain('January payroll.xlsx')
    expect(details.querySelectorAll('.ec-register-details__source')).toHaveLength(1)
    const uploads = details.querySelector('.ec-register-details__uploads')!
    expect(uploads.querySelectorAll('li')).toHaveLength(2)
    expect(uploads.textContent).toContain('January payroll.xlsx')
    expect(uploads.textContent).toContain('February payroll.pdf')
    expect(uploads.textContent).toContain('Code details haven’t been read')
    expect(uploads.textContent).not.toContain('$')
    typeCallAnswer(host.querySelector('textarea[id^="call-answer-"]')!, 'Paid monthly.')
    expect(details.open).toBe(true)
    act(() => summary.click())
    expect(details.open).toBe(false)
    expect(latest.callAnswers?.MILEAGE).toBe('Paid monthly.')
    expect(latest.answers).toEqual(state.answers)
    expect(latest.resolutions).toEqual(state.resolutions)
    expect(draftEarningCustomerQuestions).not.toHaveBeenCalled()
  })
  it('shows a related source for an added code without inventing its payments', () => {
    const state = saveDraft(oneDeferred())
    state.files = SAMPLE_REGISTER_FILES
    state.rounds[0].itemIds.push('TIPS RPT')
    state.resolutions['TIPS RPT'] = { status: 'resolved', round: 1, reference: READY.tipsReported }
    mount(state)
    const details = host.querySelector('[data-testid="row-cheat-TIPS RPT"] .ec-register-details')!
    expect(details.textContent).toContain('TIPS RPT isn’t a separate row. The figures below belong to TIPS.')
    expect(details.textContent).toContain('Related code')
    const sources = details.querySelectorAll('.ec-register-details__source')
    expect(sources).toHaveLength(2)
    sources.forEach((source, index) => {
      expect(source.textContent).toContain(SAMPLE_PAY_REGISTERS[index].file.name)
      expect(source.textContent).toContain(SAMPLE_PAY_REGISTERS[index].period)
      expect(source.textContent).toContain('Related code: TIPS')
      expect(source.textContent).toContain(`Earnings · ${['$3,856.00', '$4,177.33'][index]} this period`)
      expect(source.textContent).toContain('TIPS RPT isn’t a separate row. The figures below belong to TIPS.')
    })
    expect(details.textContent).not.toMatch(/description:/i)
    expect(details.querySelector('.ec-register-details__uploads')).toBeNull()
  })
  it('shows loading then saves success, and reuses the draft after remount without another request', async () => {
    let finish!: (value: typeof result) => void
    vi.mocked(draftEarningCustomerQuestions).mockImplementationOnce(() => new Promise(resolve => { finish = resolve }))
    mount(oneDeferred())
    const style = document.createElement('style')
    style.textContent = cheatSheetStyles
    host.append(style)
    const initialParagraphs = host.querySelectorAll('.ec-cheat__lines > p')
    expect(initialParagraphs).toHaveLength(1)
    expect(getComputedStyle(initialParagraphs[0]).fontSize).toBe('14px')
    expect(host.querySelector('h1')?.textContent).toBe('What do we need to review?')
    expect(host.querySelector('.ec-intro')?.textContent?.trim()).toBe('See what’s been confirmed and what still needs clarification to get your pay codes set up correctly.')
    expect(host.querySelector('.ec-page')?.textContent).not.toMatch(/Customer call cheat sheet|Suggested questions to ask/)
    expect(host.textContent).not.toContain('What we answered')
    expect(host.querySelectorAll('.ec-cheat__grid > .ec-cheat__cell')).toHaveLength(1)
    expect(host.querySelector('.ec-cheat__cell--ask dt')?.textContent).toBe('Details to confirm')
    expect(host.textContent).toContain('Preparing questions')
    expect(host.textContent).not.toContain('Standard question')
    expect(host.querySelector('.ec-stats')).toBeNull()
    const field = host.querySelector<HTMLTextAreaElement>('textarea[id^="call-answer-"]')!
    expect(host.querySelector(`label[for="${field.id}"]`)?.textContent).toBe('Discussion notes (optional)')
    typeCallAnswer(field, 'Paid monthly.')
    expect(latest.callAnswers?.MILEAGE).toBe('Paid monthly.')
    await act(async () => finish(result))
    expect(host.querySelector<HTMLTextAreaElement>('textarea[id^="call-answer-"]')?.value).toBe('Paid monthly.')
    expect(host.textContent).not.toContain('AI-drafted questions')
    expect(host.querySelector('.ec-cheat__source')).toBeNull()
    expect(host.textContent).toContain(result.questions[0])
    expect(host.textContent).toContain(result.reason)
    const paragraphs = [...host.querySelectorAll('.ec-cheat__lines > p')]
    expect(paragraphs.map(paragraph => paragraph.textContent)).toEqual(result.questions)
    expect(host.querySelector('.ec-cheat__questions ul, .ec-cheat__questions li')).toBeNull()
    for (const paragraph of paragraphs) expect(getComputedStyle(paragraph).fontSize).toBe('14px')
    expect(host.querySelector<HTMLDetailsElement>('.ec-cheat__why')?.open).toBe(false)
    expect(host.querySelector('.ec-cheat__why p')?.textContent).toBe(result.reason)
    const saved = latest
    act(() => root!.unmount()); host.remove(); root = undefined
    mount(parseSession(JSON.stringify(saved))!)
    expect(draftEarningCustomerQuestions).toHaveBeenCalledTimes(1)
    expect(host.textContent).toContain(result.questions[0])
    expect(host.querySelector<HTMLTextAreaElement>('textarea[id^="call-answer-"]')?.value).toBe('Paid monthly.')
  })
  it('shows the standard question on failure, retries and permits continuing', async () => {
    vi.mocked(draftEarningCustomerQuestions).mockRejectedValueOnce(new Error('offline')).mockResolvedValueOnce(result)
    mount(oneDeferred()); await settle()
    expect(host.textContent).toContain(DRAFT_ERROR)
    expect(host.textContent).not.toContain('Standard question')
    expect(host.textContent).toContain('The original question is shown below.')
    expect(host.querySelector<HTMLDetailsElement>('.ec-cheat__why')?.open).toBe(false)
    expect(host.textContent).toContain(latest.customerQuestions[0].question)
    const retry = [...host.querySelectorAll('button')].find(button => button.textContent === 'Retry')!
    await act(async () => retry.click())
    expect(host.textContent).not.toContain('AI-drafted questions')
    expect(host.textContent).toContain(result.questions[0])
    expect(draftEarningCustomerQuestions).toHaveBeenCalledTimes(2)
  })
  it('uses no AI for resolved/awaiting setup review or old deferrals; preserves next-round action', () => {
    const state = oneDeferred()
    state.customerQuestions = state.customerQuestions.map(({ draftBasis: _basis, ...question }) => question)
    state.rounds[0].results!.findings = ['MILEAGE TX']
    state.rounds.push({ number: 2, itemIds: ['MILEAGE TX'], submitted: false })
    state.resolutions.SPPAY = { status: 'review', round: 1, note: 'Special payment' }
    state.resolutions.OTPREM = { status: 'resolved', round: 1, reference: READY.overtimePremium }
    state.rounds[0].itemIds.push('SPPAY', 'OTPREM')
    mount(state)
    expect(host.textContent).toContain('New findings (1)')
    expect(host.textContent).toContain('Review results')
    expect(host.textContent).toContain('With the setup team')
    const questionHeadings = [...host.querySelectorAll('.ec-cheat__cell--ask dt')]
    expect(questionHeadings).toHaveLength(1)
    expect(questionHeadings.every(heading => heading.textContent === 'Details to confirm')).toBe(true)
    for (const [id, label] of [['MILEAGE', 'Details to confirm'], ['SPPAY', 'Status'], ['OTPREM', 'Result']]) {
      expect(host.querySelector(`[data-testid="row-cheat-${id}"] .ec-cheat__cell dt`)?.textContent).toBe(label)
    }
    expect(host.textContent).not.toContain('What we answered')
    expect(host.querySelectorAll('.ec-discussion__response')).toHaveLength(1)
    expect(host.querySelector('[data-testid="row-cheat-OTPREM"]')?.textContent).toContain(`Ready setup: ${READY.overtimePremium.name}`)
    expect(host.querySelector('[data-testid="row-cheat-SPPAY"]')?.textContent).toContain('Awaiting setup review; no Ready setup confirmed.')
    expect(host.textContent).not.toContain(findItem('MILEAGE TX').question)
    expect(host.textContent).toContain('Needs review before setup can be confirmed.')
    expect([...host.querySelectorAll<HTMLDetailsElement>('.ec-cheat__why')].every(details => !details.open)).toBe(true)
    expect(latest.answers).toEqual(state.answers)
    expect(host.querySelectorAll('textarea[id^="call-answer-"]')).toHaveLength(3)
    const fieldFor = (id: string) => host.querySelector<HTMLTextAreaElement>(`[data-testid="row-cheat-${id}"] textarea[id^="call-answer-"]`)!
    typeCallAnswer(fieldFor('SPPAY'), 'Extra pay on weekends.')
    typeCallAnswer(fieldFor('OTPREM'), 'Customer confirmed overtime.')
    expect(latest.callAnswers).toEqual({ SPPAY: 'Extra pay on weekends.', OTPREM: 'Customer confirmed overtime.' })
    expect(fieldFor('MILEAGE').value).toBe('')
    typeCallAnswer(fieldFor('SPPAY'), '')
    expect(latest.callAnswers).toEqual({ OTPREM: 'Customer confirmed overtime.' })
    expect(latest.resolutions).toEqual(state.resolutions)
    const next = [...host.querySelectorAll('button')].find(button => button.textContent === 'Review 1 new finding')!
    expect(next).toBeDefined(); act(() => next.click())
    expect(latest.step).toBe('questions')
    expect(draftEarningCustomerQuestions).not.toHaveBeenCalled()
  })
  it('opens optimization without findings and keeps saved questions for the reply dialog', () => {
    const state = saveDraft(oneDeferred())
    mount(state)
    const complete = [...host.querySelectorAll('button')].find(button => button.textContent === 'Complete classification')!
    expect(complete).toBeDefined()
    act(() => complete.click())
    expect(latest.step).toBe('optimization')
    expect(latest.customerQuestions).toEqual(state.customerQuestions)
    expect(customerQuestionList(latest).find(q => q.id.startsWith('reimbursement:MILEAGE:'))?.question).toContain(result.questions[0])
    act(() => root!.unmount()); host.remove(); root = undefined
    const question = customerQuestionList(state).find(q => q.id.startsWith('reimbursement:MILEAGE:'))!
    mount(state, <CustomerReplyDialog question={question} onClose={() => {}} />)
    expect(document.body.textContent).toContain('What we asked the customer')
    expect(document.body.textContent).toContain(result.questions[0])
  })
})
