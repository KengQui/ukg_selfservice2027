/**
 * What Ask Bryte reads about the phase in view, derived from the session so the phase screens stay as
 * they are. The page catalog (src/askBrytePages.ts) turns these facts into Bryte's page description.
 *
 * Facts carry code names, Ready references and classifications, counts of codes and questions, and
 * your team's decisions. They never carry employee names or counts, pay amounts, uploaded file names or
 * contents, pay register descriptions, descriptions your team typed, the customer's email address or
 * the customer's replies. The exception is an explicitly saved relationship note, redacted before
 * it enters Bryte's facts. Lists are one string with one entry per line.
 */
import type { AskBryteFacts } from '@workspace/setup-shared/ask-bryte'
import { appliedReviewSession, reviewUsesUploads } from './session'
import { redactSensitive } from '@workspace/setup-shared/ask-bryte'
import { applicableOptimizations, classificationReadyCount, configurationCounts, finalConfiguration, summaryConfiguration } from './configuration'
import { CELL_ID, cellFollowUpQuestions, cellQuestionStage } from './cell'
import { IRS_MILEAGE_RATE, MILEAGE_ID, MILEAGE_TX_ID, PER_MILE, PER_MILE_PLUS, formatMileageRate, itemInSession, mileageAnswerText } from './mileage'
import { OPTIMIZATION_GROUPS, appliedOptimization, findOptimization, optimizationAnswered, optimizationCounts, optimizationNote, optimizationOutcomeIn, optimizationProgress } from './optimization'
import { SOMETHING_ELSE } from './somethingElse'
import { legacyTipsOption, isReviewItem } from './sampleRegister'
import { TIPS_ID, TIPS_METHOD, needsTipsMethod, tipsAnswerText, tipsMethodQuestion } from './tips'
import { isTipsCode, TIPS_OWED_EXAMPLE } from './tipsIdentity'
import { usesTipsFlow, tipsOutstanding, tipsFacts, tipsSetup } from './tipsFlow'
import { reviewTopicForPage } from './reviewTopics'
import { medicalDisplayText, medicalEmployerCode } from './medical'
import { startingMatchedCodes } from './configuration'
import {
  ASK_CUSTOMER, DESCRIBE_CHOICE, EARNING_CODES, EMPLOYER_CODE_QUESTION, EXISTING_CODE, FLAG_SUMMARIES, SUGGESTED_CODE, PLAN_INITIAL_ITEMS, codesAddedBy, findItem, relatedNoteText,
  type Classification, type ReadyReference, type ReviewItem, type ReviewItemType,
} from './sampleRegister'
import {
  INITIAL_REVIEW_CATEGORIES, INITIAL_REVIEW_PAGES, analysisCounts, classificationStatus, currentRound, decisionFor, effectiveOvertime, followUpOutcome, reviewPages, reviewPosition, roundProgress,
  needsLegacyBonrevReview, unidentifiedStage, activeCheck, askedFollowUps, activeNaming, isOtherPurpose, lookupResult, sharedSetupFor, type Decision, type EarningSession, type ItemAnswer, type Step,
} from './session'
import { TOPICS, customerQuestionList } from './summary'
import { answerReviewBasis, reviewOpen } from './answerReviewData'
import { reviewShown } from './answerReviewScope'
import { readinessAction, readinessItemStatus, preparationSummary } from './readinessSummary'
import { hiddenDemoCodes } from './optionalDemoQuestions'
import { questionApplies, sourceGroups, sourceItemId } from './questionApplicability'
import { reviewCodeRows } from './reviewStatus'
import { hasViewCodes } from './sessionCodeStatus'
import { forwardButtonsUngated } from './demoSettings'
import { cheatSheetGroups } from './cheatSheet'
import { currentCustomerDraft } from './customerQuestionData'
import { CELL_OVERVIEW, cellFactsText, cellOutstanding } from './cellFlow'
import { reimbursementAnswer } from './reimbursements'
import { discussionEntries, previewItems } from './deferredReview'
import { discussionProgress } from './discussionProgress'
import { MIXED_EARNINGS, OVERTIME_METHOD_LABELS, SCREENING_QUESTIONS, describedScreeningQuestions, overtimeMethod, overtimePaymentCodes, recommendationDetail, screeningAnswered, screeningNote, supersededScreeningQuestions, visibleScreeningQuestions } from './overtime'
import { overtimeReview } from './overtimeReview'
import { overtimePageReview } from './overtimePageReview'

/** One key per phase, plus a separate key for the second and later rounds of questions (new findings). */
export type EarningBrytePage = Step | 'new-findings' | 'uploaded-registers' | 'applied-review' | 'confirmation-needed'

export interface EarningBryteRegistration {
  key: EarningBrytePage
  facts: AskBryteFacts
}

/** The question groups as they're headed on screen. */
const GROUP_TITLES: Record<ReviewItemType, string> = {
  misclassification: 'Potential misclassifications',
  clarification: 'Need clarification',
  unidentified: 'Couldn’t be identified',
  finding: 'New findings',
}

/** Singular labels, as the guided review's position line shows them ("3 of 5 · Needs clarification"). */
const POSITION_TITLES: Record<ReviewItemType, string> = {
  misclassification: 'Potential misclassification',
  clarification: 'Needs clarification',
  unidentified: 'Couldn’t be identified',
  finding: 'New finding',
}

const CLASSIFICATIONS: readonly Classification[] = ['Earning', 'Deduction', 'ER contribution', 'Reporting only']
const ANSWER_LABELS: Record<string, string> = { yes: 'Yes', no: 'No', [ASK_CUSTOMER]: 'Deferred', [SOMETHING_ELSE]: 'Something else' }

const lines = (entries: readonly string[]) => entries.join('\n')
const codes = (ids: readonly string[]) => ids.map(id => findItem(id).code).join(', ')
const referenceText = (reference: ReadyReference) => `${reference.name} (${reference.classification})`

/** Joins entries into lines that stay under the page description's line limit. */
function wrapped(entries: readonly string[], max = 180): string {
  const result: string[] = []
  for (const entry of entries) {
    const last = result.length - 1
    if (last >= 0 && result[last].length + entry.length + 2 <= max) result[last] = `${result[last]}, ${entry}`
    else result.push(entry)
  }
  return lines(result)
}

function decisionText(decision: Decision, code: string): string {
  return decision.kind === 'defer' ? 'Deferred (added to the questions for the customer)'
    : decision.kind === 'name' ? `proposed custom name ${decision.name} (not a Ready reference; setup awaits review)`
    : decision.kind === 'remove' ? 'removed from the setup by your choice'
    : decision.kind === 'describe' ? decision.question
      ? `Something else for ${decision.question} Described as ${redactSensitive(decision.note)} (no Ready setup, nothing more asked; setup awaits review)`
      : `described as ${redactSensitive(decision.note)} (no Ready setup; setup awaits review)`
    : decision.outputs ? `split into ${decision.outputs.map(output => `${output.code}: ${referenceText(output.reference)}`).join('; ')}`
      : `${decision.combinedInto ? `Combined into ${decision.combinedInto} · Set up as ` : 'set up as '}${referenceText(decision.reference)}${decision.relatedNote ? ` · ${relatedNoteText(decision.reference.id, code, redactSensitive(decision.relatedNote))}` : ''}`
}

/**
 * Structured choices only. The register gives CELL's amount, frequency and headcount, never how it was taxed,
 * so nothing here may suggest that tax details came from the document. Amounts and headcounts stay out of Bryte's facts.
 */
function cellFacts(session: EarningSession): AskBryteFacts {
  const answer = session.answers[CELL_ID] ?? {}
  if (!answer.cellLegacy) return {
    cellPurpose: answer.choice ?? 'Not answered',
    cellBasis: `${CELL_OVERVIEW} Payment method, receipts and historical treatment do not establish tax intent or qualification. No required split or verified catalog connection is supplied.`,
    cellTreatment: redactSensitive(cellFactsText(answer)),
    cellSetup: session.resolutions[CELL_ID]?.status === 'resolved'
      ? 'Explicit intended tax treatment saved for the proposed CELL setup; not a legal determination or a change to live payroll.'
      : 'CELL setup is not complete. Business facts, intended tax treatment or the supported setup still need confirmation.',
    cellOpenQuestion: cellQuestionStage(answer) ? cellOutstanding(answer)?.question ?? '' : '',
  }
  const resolution = session.resolutions[CELL_ID]
  const stage = cellQuestionStage(answer)
  // The team's pick, in the card's own “We…” words.
  const item = findItem(CELL_ID)
  const picked = item.type === 'clarification' ? item.options.find(option => option.id === answer.choice)?.label : undefined
  const purpose = picked ?? (answer.choice === DESCRIBE_CHOICE ? answer.descriptionSubmitted && answer.description?.trim()
    ? `Something else, described as ${redactSensitive(answer.description.trim())}` : 'Something else, description not finished'
    : answer.choice === ASK_CUSTOMER ? 'Deferred' : 'Not answered')
  const treatment = answer.choice === 'allowance' ? 'Taxed as pay (an allowance)'
    : answer.choice === DESCRIBE_CHOICE ? 'Not set: the setup team reviews the description first'
      : answer.followUps?.treatment === 'qualifying' ? 'Payback is tax-free; their adviser confirmed it meets the rules'
        : answer.followUps?.treatment === 'taxable' ? 'Payback is taxed as pay'
          : answer.somethingElse?.question === 'treatment' ? 'Something else: the setup team reviews the description first' : 'Not answered yet'
  return {
    cellPurpose: purpose,
    cellBasis: 'Historical CELL decision, kept as it was applied. Its earlier automatic allowance treatment is not a new explicit tax confirmation. The register does not show tax treatment. Do not apply historical assumptions to a new review.',
    cellTreatment: treatment,
    cellSetup: resolution?.status === 'resolved'
      ? resolution.outputs
        ? `Source CELL replaced by ${resolution.outputs.map(output => `${output.code}: ${output.reference.name}`).join('; ')}`
        : `CELL: ${referenceText(resolution.reference)}`
      : resolution?.status === 'review' ? 'Awaiting setup review; Something else sets up no Ready code for CELL until the setup team reviews the description'
      : resolution?.status === 'customer' ? 'Pending with the customer; no confirmed setup codes for CELL'
        : 'Answers not applied; no confirmed setup codes for CELL',
    cellOpenQuestion: stage === 'purpose' ? findItem(CELL_ID).question
      : cellFollowUpQuestions(answer).find(question => question.id === stage)?.question ?? '',
  }
}

/** MILEAGE's pick, its per-mile rate and how the rate compares with the IRS rate, once the card is on the review. */
function mileageFacts(session: EarningSession): AskBryteFacts {
  if (!session.rounds.some(round => round.itemIds.includes(MILEAGE_ID))) return {}
  const answer = session.answers[MILEAGE_ID] ?? {}
  const payment = reimbursementAnswer(findItem(MILEAGE_ID), answer)
  if (payment) return {
    mileageAnswer: redactSensitive(cellFactsText(payment)),
    mileageBasis: 'MILEAGE starts with its purpose: reimbursement, fixed allowance, extra mileage pay, multiple purposes, uncertainty or something else. Relevant AI follow-ups arrive one at a time after an answer is committed. Earlier facts are reused without assuming the new purpose or tax qualification.',
    mileageSetup: 'Captured requirements still need payroll setup validation. Tax policy, actual setup and payroll results remain unverified. Customer statements, a rate and a trip log do not establish tax-free eligibility. Keep technical mapping private; no payroll changes or separate codes have been applied.',
    mileageOpenQuestion: cellOutstanding(payment)?.question ?? '',
  }
  const resolution = session.resolutions[MILEAGE_ID]
  const pick = answer.choice === ASK_CUSTOMER ? 'Deferred'
    : answer.somethingElse ? answer.somethingElse.submitted ? 'Something else (setup awaits review)' : 'Something else, description not finished'
      : mileageAnswerText(answer) ?? 'Not answered'
  return {
    mileageAnswer: pick,
    mileageBasis: `Per mile up to the IRS rate (${formatMileageRate(IRS_MILEAGE_RATE.amount)} a mile for ${IRS_MILEAGE_RATE.year}): reimbursement. Above: also ${MILEAGE_TX_ID}. Fixed amount: car allowance. Actual business expense: expense reimbursement`,
    mileageSetup: resolution?.status === 'resolved' ? `MILEAGE: ${referenceText(resolution.reference)}${answer.choice === PER_MILE_PLUS || (answer.choice === PER_MILE && resolution && session.rounds.some(round => round.itemIds.includes(MILEAGE_TX_ID))) ? `; ${MILEAGE_TX_ID} raised for the taxable part` : ''}`
      : resolution?.status === 'customer' ? 'Pending with the customer'
        : resolution?.status === 'review' ? 'Awaiting setup review'
          : 'Answers not applied',
  }
}
/**
 * The question an open item is waiting on, in its approved wording as shown on screen. Never includes your team's
 * description; text the AI check or naming wrote is redacted.
 */
function openQuestion(item: ReviewItem, answer: ItemAnswer = {}): string {
  if (isTipsCode(item.id) && usesTipsFlow(answer)) return tipsOutstanding(answer, item.id)?.question ?? ''
  const shared = sharedSetupFor(item, answer)
  if (shared) return answer.sharedSetup?.referenceId === shared.reference.id && answer.sharedSetup.choice === 'other'
    ? `${shared.question} Something else selected. ${answer.sharedSetup.descriptionSubmitted ? 'Relationship description saved; the code keeps its own setup' : 'Describe how the codes are related, then select Done; no AI check is needed'}`
    : shared.question
  if (item.id === CELL_ID) {
    const stage = cellQuestionStage(answer)
    return cellFollowUpQuestions(answer).find(question => question.id === stage)?.question ?? item.question
  }
  if (item.type === 'clarification' && item.employerCode && answer.choice === 'both' && !answer.followUps?.[EMPLOYER_CODE_QUESTION]) {
    return item.employerCode.question
  }
  if (item.type === 'clarification' && item.employerCode && answer.choice === 'both'
    && answer.followUps?.[EMPLOYER_CODE_QUESTION] === EXISTING_CODE && !answer.employerCodeName?.submitted) {
    return `${item.employerCode.question} Another code selected. Type its name, then select Done; no AI check is needed`
  }
  if (item.type !== 'unidentified') return item.question
  if (item.purposeFirst) {
    item = { ...item, question: item.purposeFirst.question, context: item.purposeFirst.context }
  }
  if (item.script.kind === 'uncertainMatch' && !item.purposeFirst) {
    if (!isOtherPurpose(answer)) return item.question
    if (!answer.descriptionSubmitted) return `${item.question} Something else selected. Describe what ${item.code} pays for, then select Done to check it`
    const lookup = lookupResult(item, answer)
    if (lookup.kind === 'reference') return `Something else selected and its description checked. Use ‘${lookup.reference.name}’ for ${item.code}?`
    const check = activeCheck(item, answer)
    if (check?.kind === 'needsInformation') return `Something else selected. We have a question about it: ${redactSensitive(check.question)}`
    if (lookup.kind !== 'noMatch') return `${item.question} Something else selected; we're checking its description`
  } else {
    const stage = unidentifiedStage(item, answer)
    if (stage === 'describe') {
      return `${item.question} Describe the payment, then select Done to check it against Ready references`
    }
    if (stage === 'checking') return `${item.question} We're checking the description against Ready references`
    if (stage === 'needsInformation') {
      const check = activeCheck(item, answer)
      return `We have a question about ${item.code}: ${check?.kind === 'needsInformation' ? redactSensitive(check.question) : item.question}`
    }
    if (stage === 'followUp') {
      const asked = askedFollowUps(item, answer)
      return asked.find(question => !answer.followUps?.[question.id])?.question ?? asked[asked.length - 1]?.question ?? item.question
    }
  }
  const outcome = followUpOutcome(item, answer)
  if (outcome?.kind === 'suggest') return `Use ‘${outcome.reference.name}’ for ${item.code}?`
  const naming = activeNaming(item, answer)
  if (naming?.outcome === 'suggestion') {
    return `No Ready reference fits. AI suggested the custom name ‘${naming.name}’ (not a Ready reference; accepting it leaves setup awaiting review). Use it, edit the description or select Review later`
  }
  if (naming?.outcome === 'needsInformation') return `No Ready reference fits, and AI needs more information to suggest a name: ${redactSensitive(naming.question ?? '')}`
  return lookupResult(item, answer).kind === 'noMatch'
    ? `No Ready reference fits ${item.code}; we're suggesting a custom name, or the team can select Review later`
    : `Send ${item.code} to the customer?`
}

/** Why the analysis flagged a code, as the results page shows it. */
function flagReason(item: ReviewItem): string {
  return item.type === 'misclassification' ? `register: ${item.observed}, Ready: ${item.expected}` : FLAG_SUMMARIES[item.id] ?? ''
}

function uploadFacts(session: EarningSession): AskBryteFacts {
  return {
    files: session.files.length,
    documentTypes: [...new Set(session.files.map(file => file.docType).filter(Boolean))].join(', '),
  }
}

function resultsFacts(session: EarningSession): AskBryteFacts {
  const counts = preparationSummary(session)
  const hidden = hiddenDemoCodes(session)
  const flaggedCount = counts.misclassified + counts.clarify + counts.unidentified
  return {
    ...counts,
    flagged: flaggedCount,
    reviewAction: readinessAction(session),
    flaggedCodes: lines(INITIAL_REVIEW_CATEGORIES.map(category => ({ ...category,
      itemIds: category.itemIds.filter(id => questionApplies(findItem(id), session) && !hidden.has(findItem(id).code)) })).filter(category => category.itemIds.length).flatMap(({ title, itemIds }) =>
      wrapped(itemIds.map(id => {
        const item = findItem(id)
        return `${item.code} (${readinessItemStatus(session, item) ?? flagReason(item)})`
      }), 150).split('\n').map((part, index) => index === 0
        ? `${title} (${itemIds.length}): ${part}` : `More ${title.toLowerCase()}: ${part}`))),
    matchedCodes: wrapped(startingMatchedCodes(session)
      .filter(code => !hidden.has(code.code))
      .map(code => `${code.code} as ${code.reference!.name}`)),
  }
}

/** Tips and taxable benefits cards whose picks Bryte reads in the card's own words. */
const PRACTICE_ANSWER_ITEMS = ['TIPS', 'TIPS OWED', 'GTL-taxable-value', 'IMP INC', 'VAC-purpose', 'SICK-purpose', 'HOL-purpose', 'JURY-purpose']

function roundFacts(session: EarningSession): AskBryteFacts {
  const round = currentRound(session)
  if (!round) return {}
  const { answered, total } = roundProgress(session)
  const pages = reviewPages(session)
  const orderedIds = pages.flat()
  const sources = sourceGroups(orderedIds)
  const entries = orderedIds.map((id, index) => {
    // MILEAGE TX is worded for the MILEAGE answer that raised it, as the card shows it.
    const item = itemInSession(findItem(id), session.answers)
    const answer = session.answers[id] ?? {}
    return { item, answer, position: `${sources.findIndex(group => group.includes(id)) + 1} of ${sources.length}`, decision: decisionFor(item, answer) }
  })
  const pageIndex = reviewPosition(session).index
  const pageIds = pages[pageIndex] ?? []
  const category = reviewTopicForPage(pageIds)
  // Category-level help must not use the optional CELL card as this step's identity.
  const visible = entries.filter(entry => pageIds.includes(entry.item.id)
    && !(category?.id === 'expenses' && entry.item.id === CELL_ID))
  const inView = visible.find(entry => !entry.decision) ?? visible[0]
  const initial = round.number === 1 || round.kind === 'added-questions'
  const relevant = initial ? visible : entries
  const groups = initial
    ? [`${category?.title ?? ''} (${sourceGroups(pageIds).length} sources): ${visible.map(entry => entry.item.code).join(', ')}`]
    : (Object.keys(GROUP_TITLES) as ReviewItemType[]).flatMap(type => {
    const inGroup = relevant.filter(entry => entry.item.type === type)
    return inGroup.length ? [`${GROUP_TITLES[type]}: ${inGroup.map(entry => entry.item.code).join(', ')}`] : []
  })
  const raisedBy = (item: ReviewItem) => (item.type === 'finding' ? `, raised by the answer for ${item.raisedBy}` : '')
  return {
    round: round.number,
    answered,
    total,
    deferredCount: reviewCodeRows(session).filter(row => row.status === 'deferred').length,
    earningCodes: reviewCodeRows(session).filter(row => row.unit === 'earning').length,
    benefitPlans: reviewCodeRows(session).filter(row => row.unit === 'plan').length,
    progressUnit: 'Source codes and benefit plans, not individual questions. Related sections count once with their source.',
    proposalState: 'Unapplied answers are proposed decisions, not applied settings or payroll changes.',
    page: pageIndex + 1,
    pages: pages.length,
    ...(initial ? { category: category?.title ?? '', topicId: category?.id ?? '' } : {}),
    addedQuestions: round.kind === 'added-questions',
    groups: lines(groups),
    decisions: lines(relevant.flatMap(entry => (entry.decision ? [`${entry.item.code}: ${decisionText(entry.decision, entry.item.code)}`] : []))),
    openItems: relevant.filter(entry => !entry.decision).map(entry => entry.item.code).join(', '),
    current: inView
       ? `${inView.item.code} (${initial ? `${sourceGroups(pageIds).findIndex(group => group.some(id => sourceItemId(id) === sourceItemId(inView.item.id))) + 1} of ${sourceGroups(pageIds).length}` : inView.position} · ${initial ? (category?.title ?? '') : POSITION_TITLES[inView.item.type]}${raisedBy(inView.item)}): ${
         inView.decision ? `answered, ${decisionText(inView.decision, inView.item.code)}` : openQuestion(inView.item, inView.answer)}`
      : '',
    currentCode: inView?.item.code ?? '',
    codesInView: visible.map(entry => entry.item.code).join(', '),
    answerReviewsInView: lines(visible.flatMap(({ item, answer }) => {
      // Only reviews the card shows: typed answers. Older saves can hold reviews of fixed picks, which stay hidden.
      const outcomes = Object.entries(answer.reviews ?? {})
        .filter(([key, review]) => review.basis === answerReviewBasis(answer) && reviewShown(item, answer, key))
        .map(([, review]) => {
          const asked = review.thread?.length ?? 0
          const status = reviewOpen(review) ? `conversation open, waiting for a reply (${asked} follow-up questions answered)`
            : 'conversation resolved'
          // AI text can echo what the person typed, so it's redacted like every other fact.
          const suggestion = review.result.suggestion ? `; suggested next step: ${redactSensitive(review.result.suggestion)}` : ''
          return `${review.result.outcome}${review.dismissed ? ' (kept answer)' : ''}, ${status}${suggestion}`
        })
      const check = activeCheck(item, answer)
      if (check?.kind === 'notNeeded') outcomes.push('notNeeded')
      return outcomes.map(outcome => `${item.code}: ${outcome}`)
    })),
    questionsInView: lines(visible.map(entry => `${entry.item.code}: ${entry.decision ? 'answered' : openQuestion(entry.item, entry.answer)}`)),
    relatedQuestions: lines(visible.filter(entry => entry.item.type === 'finding')
      .map(entry => `${entry.item.code}: ${entry.item.question}`)),
    uncertainMatches: lines(visible.flatMap(({ item }) =>
      item.type === 'unidentified' && item.script.kind === 'uncertainMatch'
        ? [`${item.code}: each option sets it up as a Ready reference, ${item.script.options.map(option => option.resolution.name).join(' or ')}. Not confirmed until chosen; Review later leaves the mapping pending.`]
        : [])),
    // TIPS, GTL and IMP INC picks in the "We…" words the card shows; decisions name the Ready setup instead.
    practiceAnswers: lines(visible.flatMap(({ item, answer }) => {
      if (!PRACTICE_ANSWER_ITEMS.includes(item.id) || item.type !== 'clarification') return []
      const label = isTipsCode(item.id) ? redactSensitive(tipsAnswerText(answer) ?? '')
        : item.options.find(option => option.id === answer.choice)?.label ?? legacyTipsOption(item, answer.choice)?.label
      return label ? [`${item.code}: ${label}`] : []
    })),
    ...(visible.some(entry => entry.item.id === CELL_ID) ? cellFacts(session) : {}),
    tipCodeReviews: lines(visible.flatMap(({ item, answer }) => isTipsCode(item.id) ? [
      `${item.code}: ${redactSensitive(tipsFacts(answer, item.id))}`,
      `${item.code} open question: ${tipsOutstanding(answer, item.id)?.question ?? ''}`,
      ...(item.id === 'TIPS OWED' ? [`Authored example context, not register evidence or a confirmed answer: ${TIPS_OWED_EXAMPLE}`] : []),
    ] : [])),
    tipCodeBoundary: visible.some(({ item }) => item.id === 'TIPS OWED')
      ? 'TIPS and TIPS OWED have independent answers. Neither their names nor having two existing codes confirms a treatment or requires a third code.' : undefined,
    ...(visible.some(entry => [MILEAGE_ID, MILEAGE_TX_ID].includes(entry.item.id)) ? mileageFacts(session) : {}),
    ...(visible.some(entry => entry.item.id === TIPS_ID) ? {
      tipsPaymentQuestion: usesTipsFlow(session.answers.TIPS) ? tipsOutstanding(session.answers.TIPS ?? {})?.question
        : needsTipsMethod(session.answers.TIPS) ? tipsMethodQuestion(session.answers.TIPS) : undefined,
      ...(session.answers.TIPS?.tipsReview ? { tipsAIReview: redactSensitive(tipsFacts(session.answers.TIPS)),
        tipsVerification: session.resolutions.TIPS?.status === 'review'
          ? 'The earlier applied outcome remains setup review. A Summary does not upgrade historical work or change payroll.'
          : tipsSetup(session.answers.TIPS)
            ? 'Current checked answers support a proposed TIPS setup. Summary is read-only; no extra acknowledgment is needed. Existing page completion, Save answer and Apply answers remain explicit. Actual setup and reporting still need verification; payroll has not changed.'
            : 'Missing, stale, mixed, uncertain or unsupported outcomes remain pending. A Summary or completed questionnaire does not establish a supported setup; never infer a code split.' } : {}),
      tipsPaymentAnswer: redactSensitive(tipsAnswerText(session.answers.TIPS) ?? ''),
      tipsPaymentRule: usesTipsFlow(session.answers.TIPS)
        ? 'Ask only missing facts about payment timing, tip source, pooling and whether one code holds mixed treatments. Source alone never chooses a treatment. Current validated single-treatment outcomes show a read-only Summary without another acknowledgment. Individual answers can be edited; Clear all answers restarts an editable card. Do not create TIPS RPT automatically.'
        : needsTipsMethod(session.answers.TIPS)
        ? 'Payment method is missing: distinguish tips owed from tips received to avoid missed or double pay. Your answer selects paid or reported tips. Only both offers TIPS RPT.'
        : 'Explicit answers select paycheck tips, reported tips, or both. Only both offers TIPS RPT for separate confirmation. Not sure stays unresolved; no setup is guessed.',
    } : {}),
    ...(visible.some(entry => entry.item.id === 'MED' || entry.item.id === 'MED ER') ? {
      medicalSetup: session.resolutions.MED?.status === 'resolved' ? session.resolutions.MED.reference.name : 'MED is an existing matched medical deduction, not a question in this review',
      medicalCompanyPortion: session.answers['MED ER']?.choice === 'only-records'
        ? medicalEmployerCode(session.answers['MED ER']) ? `Employer portion of ${medicalEmployerCode(session.answers['MED ER'])}` : 'Waiting for a confirmed medical deduction'
        : 'Actual use not confirmed; typed exceptions go to setup review',
      medicalPayStatementDisplay: `Show on pay statements: ${medicalDisplayText(session.answers['MED ER'])}`,
    } : {}),
  }
}

/** The last applied round's results, as the recheck and review pages show them. */
function recheckFacts(session: EarningSession): AskBryteFacts {
  const round = session.rounds.filter(record => record.submitted).at(-1)
  const results = round?.results ?? { resolved: [], deferred: [], findings: [] }
  return {
    round: round?.number ?? 0,
    resolved: lines(results.resolved.filter(id => id !== 'DEN').map(id => {
      const resolution = session.resolutions[id]
      return resolution?.status === 'resolved'
        ? `${findItem(id).code}: ${resolution.outputs
          ? `split into ${resolution.outputs.map(output => `${output.code}: ${referenceText(output.reference)}`).join('; ')}`
           : `${resolution.combinedInto ? `Combined into ${resolution.combinedInto} · Set up as ` : 'set up as '}${referenceText(resolution.reference)}${resolution.relatedNote ? ` · ${relatedNoteText(resolution.reference.id, findItem(id).code, redactSensitive(resolution.relatedNote))}` : ''}`}` : findItem(id).code
    })),
    deferred: codes(results.deferred.filter(id => id !== 'DEN')),
    // Proposed custom names are not Ready references; setup still awaits review.
    proposedNamesAwaitingReview: lines((results.review ?? []).filter(id => id !== 'DEN').map(id => {
      const resolution = session.resolutions[id]
      return resolution?.status !== 'review' ? findItem(id).code
        : resolution.customName ? `${findItem(id).code}: purpose and name confirmed as ${resolution.customName.name}; Ready reference and tax treatment not confirmed`
          : `${findItem(id).code}: ${resolution.question ? `Something else for ${resolution.question} ` : ''}described as ${redactSensitive(resolution.note)} (setup awaits review)`
    })),
    removedFromSetup: codes(results.removed ?? []),
    findings: lines(results.findings.map(id => {
      const item = itemInSession(findItem(id), session.answers)
      return item.type === 'finding' ? `${item.code}, raised by the answer for ${item.raisedBy}: ${item.question}` : item.code
    })),
  }
}

function reviewFacts(session: EarningSession): AskBryteFacts {
  const next = currentRound(session)
  const progress = discussionProgress(discussionEntries(session))
  return {
    deferredInputTotal: progress.total,
    deferredInputEntered: progress.entered,
    deferredInputRemaining: progress.remaining,
    ...recheckFacts(session),
    cheatSheetGroups: lines(cheatSheetGroups(session).map(group => `${group.title}: ${group.rows.map(row => row.code).join(', ')}`)),
    readyToSetUp: classificationReadyCount(session),
    matched: analysisCounts(session).matched,
    customerQuestions: customerQuestionList(session).filter(question => question.status === 'open' && /^(classification|reimbursement):/.test(question.id)).length,
    stillToReview: classificationStatus(session).open,
    nextRoundFindings: next && !next.submitted ? next.itemIds.length : 0,
    ...cellFacts(session),
    ...mileageFacts(session),
    reimbursementDecisions: redactSensitive(Object.entries(session.answers).flatMap(([id, answer]) => {
      if (!isReviewItem(id)) return []
      const payment = reimbursementAnswer(findItem(id), answer)
      return payment ? [`${id}: ${cellFactsText(payment)}. Sample references are purpose proposals, not verified setup.`] : []
    }).join('\n')),
  }
}

function optimizationFacts(session: EarningSession): AskBryteFacts {
  const state = session.optimization
  const applicable = applicableOptimizations(session)
  const ordered = OPTIMIZATION_GROUPS.flatMap(group =>
    applicable.filter(suggestion => suggestion.kind === group.kind).map(suggestion => ({ suggestion, group: group.title })))
  const { answered, total } = optimizationProgress(state, applicable)
  const counts = optimizationCounts(state, applicable)
  const next = ordered.find(({ suggestion }) => !optimizationAnswered(state, suggestion.id))
  const setup = configurationCounts(finalConfiguration(session))
  return {
    answered,
    total,
    ...counts,
    codesToSetUp: setup.ready,
    leftOut: setup.notSetUp,
    customerQuestions: customerQuestionList(session).length,
    suggestions: lines(ordered.map(({ suggestion, group }) => `${group}: ${suggestion.question}`)),
    decisions: lines(ordered.flatMap(({ suggestion }) => {
      const outcome = optimizationOutcomeIn(state, suggestion)
      return outcome ? [outcome] : []
    })),
    next: next ? `${next.group}: ${next.suggestion.question}` : '',
    nextKind: next?.suggestion.kind ?? '',
    completed: state.completed,
    changedWhileSorting: (state.changedWhileSorting ?? []).map(id => findOptimization(id).codes.join(' and ')).join(', '),
  }
}

function overtimeFacts(session: EarningSession): AskBryteFacts {
  const overtime = effectiveOvertime(session)
  const visible = visibleScreeningQuestions(overtime)
  const method = overtimeMethod(overtime)
  const currentIndex = visible.findIndex(question => !screeningAnswered(overtime, question.id))
  const answers = visible.flatMap((question, index) => {
    const answer = overtime.answers[question.id]
    if (!answer && overtime.findings?.[question.id]) return [`Q${index + 1} ${question.question} Finding from current sources: ${overtime.findings[question.id]}. Not a customer-selected answer.`]
    if (!screeningAnswered(overtime, question.id)) return []
    const fromCustomer = session.overtime.answers[question.id] === ASK_CUSTOMER && answer !== ASK_CUSTOMER
    const note = screeningNote(overtime, question.id)
    return [`Q${index + 1} ${question.question} ${ANSWER_LABELS[answer]}${note ? `: ${note}` : ''}${fromCustomer ? ', the customer’s answer' : ''}`]
  })
  return {
    method: OVERTIME_METHOD_LABELS[method.kind],
    appliesBecause: method.kind === 'weighted' ? method.question.applies : '',
    asked: visible.length,
    total: SCREENING_QUESTIONS.length,
    answers: lines(answers),
    current: currentIndex >= 0 ? `Q${currentIndex + 1}: ${visible[currentIndex].question}` : '',
    noLongerNeeded: supersededScreeningQuestions(overtime).length,
    somethingElse: describedScreeningQuestions(overtime).length,
  }
}

function overtimeSortFacts(session: EarningSession, pageOnly = false): AskBryteFacts {
  const method = overtimeMethod(effectiveOvertime(session))
  const sort = pageOnly ? overtimePageReview(session) : overtimeReview(session)
  const listed = (earnings: typeof sort.include) => earnings.map(earning => earning.code).join(', ')
  const changed = session.optimization.changedWhileSorting ?? []
  // Pack shared reasons together so Bryte's bounded context retains every code, not just the first rows.
  const groups = new Map<string, string[]>()
  for (const earning of [...sort.include, ...sort.exclude]) {
    const reason = earning.reason.startsWith('Used to pay overtime')
      ? 'Pays overtime; base pay and premium amounts are not separated here' : earning.reason
    const key = earning.origin === 'customer'
      ? `Customer-selected treatment: ${earning.placement === 'include' ? 'Include' : 'Exclude'}; not setup or tax approval`
      : earning.recommendationBasis ? recommendationDetail(earning) : `${earning.placement === 'include' ? 'Include' : 'Exclude'}${earning.moved
      ? ` (changed by you; suggested ${earning.recommendedPlacement === 'include' ? 'Include' : 'Exclude'})`
      : earning.confirmed ? ' (you chose the suggested treatment)' : ''}: ${reason}`
    groups.set(key, [...(groups.get(key) ?? []), earning.code])
  }
  const briefReasons = {
    unanswered: 'Needs your decision; overtime treatment not selected',
    deferred: 'question deferred; no inclusion decision',
    proposedName: 'purpose and name confirmed; overtime treatment not confirmed',
    described: 'described answer awaiting setup review',
    unsupported: 'no supported inclusion rule',
    missingSetup: 'no confirmed setup available',
    mixed: 'mixed purposes; split, Review later or Something else needed',
  }
  return {
    appliesBecause: method.kind === 'weighted' ? method.question.applies : '',
    include: listed(sort.include),
    exclude: listed(sort.exclude),
    included: sort.include.length,
    excluded: sort.exclude.length,
    changedByYou: [...sort.include, ...sort.exclude].filter(earning => earning.moved)
      .map(earning => `${earning.code} to ${earning.placement === 'include' ? 'Include' : 'Exclude'}`).join(', '),
    recommendations: lines([...sort.include, ...sort.exclude].map(earning => redactSensitive(`${earning.code}: ${recommendationDetail(earning)}`))),
    recommendationGroups: lines([...groups].map(([reason, codes]) => `${codes.join(', ')} — ${reason}`)),
    unresolvedSuggestions: lines(sort.recommendations.filter(row => sort.awaiting.some(open => open.code === row.code))
      .map(row => `${row.code}: suggest ${row.placement}; decision open. ${row.reason}`)),
    corrections: lines([...sort.include, ...sort.exclude].filter(earning => earning.moved).map(earning =>
      `${earning.code}: ${earning.placement === 'include' ? 'Include' : 'Exclude'} (suggested ${earning.recommendedPlacement === 'include' ? 'Include' : 'Exclude'})`)),
    awaitingReview: lines(sort.awaiting.map(row => redactSensitive(`${row.code}: ${row.owner === 'customer' ? 'Needs your answer' : 'Needs setup team review'}; ${row.reason}`))),
    awaitingBrief: lines(sort.awaiting.map(row => `${row.code}: ${row.owner === 'customer' ? 'Needs your answer' : 'Needs setup team review'}; ${briefReasons[row.kind]}`)),
    needsAnswerCount: sort.customer.length,
    needsTeamCount: sort.team.length,
    needsAnswerCodes: sort.customer.map(row => row.code).join('\n'),
    needsTeamCodes: sort.team.map(row => row.code).join('\n'),
    placedSetupOpenCodes: sort.setupReview.map(row => row.code).join('\n'),
    selectedSetupCount: sort.setupReview.length,
    customerTreatments: lines([...sort.include, ...sort.exclude].filter(row => row.origin === 'customer')
      .map(row => row.recommendationBasis ? `${row.code}: ${recommendationDetail(row)}`
        : `${row.code}: ${row.placement === 'include' ? 'Include' : 'Exclude'} (your choice, not a product recommendation; setup still needs review)`)),
    awaitingCount: sort.awaiting.length,
    ...(!pageOnly ? { paymentCodes: lines(overtimePaymentCodes(sort.rows).map(row => `${row.code}: ${row.method}`))
      || 'No overtime payment codes have a confirmed setup yet.' } : {}),
    waiting: sort.waiting.map(row => row.code).join(', '),
    mixed: lines(sort.mixed.map(earning => `${earning.code} ${earning.reason}`)),
    mixedResolved: Object.entries(MIXED_EARNINGS)
      .filter(([code, mixed]) => changed.includes(mixed.suggestionId)
        && sort.rows.some(row => row.code === code || row.code.startsWith(`${code}-`)))
      .map(([code, mixed]) => {
        const answer = session.optimization.answers[mixed.suggestionId]
        const note = optimizationNote(session.optimization, mixed.suggestionId)
        return `${code}: ${answer === 'accept' ? 'split' : answer === SOMETHING_ELSE ? note ? `Something else, awaiting setup review: ${note}` : 'Something else, not described yet' : 'Deferred'}`
      })
      .join(', '),
  }
}

/**
 * The final summary's confirmed configuration: the Final classification table and Who pays into each plan.
 */
function configurationFacts(session: EarningSession): AskBryteFacts {
  const rows = summaryConfiguration(session)
  const ready = rows.filter(row => row.status === 'ready')
  return {
    needsReviewAction: rows.filter(row => row.status === 'pending').map(row => row.code).join(', '),
    waitingOnCustomer: rows.filter(row => row.status === 'customer' && !(row.code === 'BONREV' && needsLegacyBonrevReview(session))).map(row => row.code).join(', '),
    awaitingSetupReview: rows.filter(row => row.status === 'review')
      .map(row => row.customName ? `${row.code} (purpose and name confirmed: ${row.customName}; setup details still need review)` : `${row.code} (described)`).join(', '),
    byClassification: CLASSIFICATIONS
      .map(classification => `${classification} ${ready.filter(row => row.reference?.classification === classification).length}`)
      .join(', '),
    plans: PLAN_INITIAL_ITEMS.map(item => {
      const { id, code } = item
      const answer = session.answers[id]
      const resolution = session.resolutions[id]
      const added = codesAddedBy(item, answer).map(entry => entry.code)
      const employerPick = answer?.followUps?.[EMPLOYER_CODE_QUESTION]
      const employerCode = employerPick === ASK_CUSTOMER ? 'waiting on the customer' : employerPick === SUGGESTED_CODE ? 'our suggestion'
        : employerPick === EXISTING_CODE ? answer?.employerCodeName?.submitted ? 'the company’s own code' : 'code name not done' : 'not answered'
      return `${code}: ${resolution?.status === 'customer' ? 'waiting on the customer' : answer?.choice ?? 'not answered'}${item.employerCode && answer?.choice === 'both' ? `; company’s code: ${employerCode}` : ''}${added.length ? `; also sets up ${added.join(', ')} now` : ''}`
    }).join('\n'),
    medicalCompanyPortion: session.resolutions['MED ER']?.status === 'resolved' && session.answers['MED ER']?.choice === 'only-records'
      ? `Employer portion of ${medicalEmployerCode(session.answers['MED ER'])}` : 'Not confirmed',
    medicalPayStatementDisplay: `Show on pay statements: ${medicalDisplayText(session.answers['MED ER'])}`,
  }
}

function summaryFacts(session: EarningSession): AskBryteFacts {
  const tips = session.answers[TIPS_ID] ?? {}
  const tipsResolution = session.resolutions[TIPS_ID]
  const historicalTips = tipsResolution?.status === 'review' && !tips.followUps?.[TIPS_METHOD] && !tips.somethingElse
    ? tipsResolution.note : undefined
  const tipsSetup = tipsResolution?.status === 'resolved' ? `${tipsResolution.reference.name}${session.resolutions['TIPS RPT']?.status === 'resolved' ? ' plus TIPS RPT' : ''}`
    : tipsResolution?.status === 'review' ? 'Awaiting setup review; no Ready setup chosen'
      : tipsResolution?.status === 'customer' ? 'Waiting on the customer; no Ready setup chosen' : 'Answers not applied'
  const rows = summaryConfiguration(session)
  const counts = configurationCounts(rows)
  const optimization = optimizationCounts(appliedOptimization(session.optimization), applicableOptimizations(session))
  const method = overtimeMethod(effectiveOvertime(session))
  const questions = customerQuestionList(session)
  const open = questions.filter(question => question.status === 'open')
  return {
    ...cellFacts(session),
    ...mileageFacts(session),
    ...configurationFacts(session),
    tipsAnswer: redactSensitive(historicalTips ?? tipsAnswerText(tips, tipsResolution?.status === 'resolved') ?? (tips.choice === ASK_CUSTOMER ? 'Deferred' : 'Not answered')),
    tipsSetup,
    ...(rows.some(row => row.code === 'TIPS OWED') ? {
      tipsOwedAnswer: redactSensitive(tipsAnswerText(session.answers['TIPS OWED']) ?? 'Not answered'),
      tipsOwedSetup: session.resolutions['TIPS OWED']?.status === 'resolved'
        ? session.resolutions['TIPS OWED'].reference.name : session.resolutions['TIPS OWED']?.status ?? 'Answers not applied',
    } : {}),
    codesToSetUp: counts.ready,
    leftOut: rows.filter(row => row.status === 'notSetUp').map(row => row.code).join(', '),
    combinedCodes: lines(rows.filter(row => row.combinedInto).map(row => `${row.code}: Combined into ${row.combinedInto} · Set up as ${row.reference?.name}`)),
    relatedCodes: lines(rows.filter(row => row.relatedNote && row.reference).map(row =>
      `${row.code}: Set up as ${row.reference!.name} · ${relatedNoteText(row.reference!.id, row.code, redactSensitive(row.relatedNote!))}`)),
    legacyBonrevReview: needsLegacyBonrevReview(session),
    suggestionsAccepted: optimization.accepted,
    suggestionsKept: optimization.kept,
    suggestionsWithCustomer: optimization.customer,
    overtimeMethod: OVERTIME_METHOD_LABELS[method.kind],
    ...(method.kind === 'weighted' ? overtimeSortFacts(session) : {}),
    appliesBecause: method.kind === 'weighted' ? method.question.applies : '',
    openQuestions: open.length,
    answeredQuestions: questions.filter(question => question.status === 'answered').length,
    notNeededQuestions: questions.filter(question => question.status === 'notNeeded').length,
    openByTopic: lines(TOPICS.flatMap(topic => {
      const inTopic = open.filter(question => question.topic === topic.id)
      return inTopic.length ? [`${topic.title}: ${inTopic.flatMap(question => question.codes).join(', ')}`] : []
    })),
    sent: !!session.sent,
  }
}

/** The page key and facts Ask Bryte uses for the session's current phase. */
export function bryteFacts(session: EarningSession): EarningBryteRegistration {
  if (session.step === 'reviewOverview') return { key: 'reviewOverview', facts: {} }
  const savedReview = appliedReviewSession(session)
  if (savedReview && !reviewUsesUploads(session)) return {
    key: 'applied-review',
    facts: { round: savedReview.rounds[0].number, page: reviewPosition(savedReview).index + 1, pages: reviewPages(savedReview).length },
  }
  if (reviewUsesUploads(session) && !['intro', 'categorySelection', 'upload', 'overtime', 'overtimeAssessment', 'overtimeSort'].includes(session.step)) {
    return { key: 'uploaded-registers', facts: {
      viewCodes: hasViewCodes(session),
      files: session.files.length,
      read: session.files.filter(file => file.status === 'ready').length,
      failed: session.files.filter(file => file.status === 'failed').length,
    } }
  }
  const page = pageFacts(session)
  const drafts = session.customerQuestions.flatMap(question => {
    const draft = currentCustomerDraft(session, question)
    return draft ? [`${question.code}: ${redactSensitive(draft.questions.join(' '))}`] : []
  })
  return drafts.length ? { ...page, facts: { ...page.facts, draftedCustomerQuestions: lines(drafts) } } : page
}

function pageFacts(session: EarningSession): EarningBryteRegistration {
  switch (session.step) {
    case 'intro': return { key: 'intro', facts: {} }
    case 'reviewOverview': return { key: 'reviewOverview', facts: {} }
    case 'categorySelection': return { key: 'categorySelection', facts: {} }
    case 'upload': return { key: 'upload', facts: uploadFacts(session) }
    case 'analysis': return session.preparationComplete
      ? { key: 'results', facts: resultsFacts(session) }
      : { key: 'analysis', facts: { canStartEarly: forwardButtonsUngated() } }
    case 'results': return { key: 'results', facts: resultsFacts(session) }
    case 'questions': return { key: (currentRound(session)?.number ?? 1) > 1 && currentRound(session)?.kind !== 'added-questions' ? 'new-findings' : 'questions', facts: roundFacts(session) }
    case 'reevaluation':
    case 'review': return { key: discussionEntries(session).length ? 'review' : 'confirmation-needed', facts: reviewFacts(session) }
    case 'discussionReview':
    case 'discussionWork': return { key: session.step, facts: {
      setupChangesApplied: false,
      setupReview: !!session.discussionPreview?.setupItems,
      reviewedAnswers: previewItems(session).length,
      deferredInputTotal: discussionProgress(discussionEntries(session)).total,
      deferredInputRemaining: discussionProgress(discussionEntries(session)).remaining,
      purpose: 'The preview checks captured answers and shows their supported consequences. A pending check or retry is not a missing business answer. Only Apply answers commits confirmed proposals. Missing details, explicit confirmations and specialist review stay distinct. No specialist has been assigned or notified. Saving and navigation preserve work without applying.',
    } }
    case 'optimization': return { key: 'optimization', facts: optimizationFacts(session) }
    case 'optimizationReview':
    case 'overtime': return { key: 'overtime', facts: overtimeFacts(session) }
    case 'overtimeAssessment': return { key: 'overtimeAssessment', facts: overtimeFacts(session) }
    case 'overtimeSort': return { key: 'overtimeSort', facts: overtimeSortFacts(session, true) }
    case 'summary': return { key: 'summary', facts: summaryFacts(session) }
  }
}
