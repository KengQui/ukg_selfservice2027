import { reduceChecked } from './scriptedChecks.testing'
import { describe, expect, it } from 'vitest'
import { ASK_CUSTOMER, READY, REVIEW_INITIAL_ITEMS, findItem } from './sampleRegister'
import {
  createSession, customerQuestionFor, decisionFor, parseSession, reduceSession, retentionAsked, retentionOf, unidentifiedStage,
  type EarningSession, type ItemAnswer, type SessionAction,
} from './session'
import { finalConfiguration } from './configuration'
import { OPTIMIZATIONS } from './optimization'
import { SCREENING_QUESTIONS } from './overtime'
import { customerQuestionList, summaryCsv } from './summary'
import { standardCustomerQuestion } from './customerQuestionData'
import { cheatSheetGroups } from './cheatSheet'
import { SAMPLE_REGISTER_FILES } from './sampleDocument'

const run = (session: EarningSession, ...actions: SessionAction[]) =>
  actions.reduce((state, action) => reduceChecked(state, action, 1000), session)
const started = () => run(createSession(0), { type: 'startReview' })
const ADJ2 = findItem('ADJ2')
const COMBINED = 'Do you want to include ADJ2 in the setup? If you do, what does it pay for?'
const describeAdj2 = (frequency = 'one-time'): SessionAction[] => [
  { type: 'describe', itemId: 'ADJ2', description: 'Correction from last week' },
  { type: 'submitDescription', itemId: 'ADJ2' },
  { type: 'answerFollowUp', itemId: 'ADJ2', questionId: 'basis', choice: 'flat' },
  { type: 'answerFollowUp', itemId: 'ADJ2', questionId: 'frequency', choice: frequency },
]
const retain = (choice: 'keep' | 'remove' | typeof ASK_CUSTOMER | ''): SessionAction => ({ type: 'chooseRetention', itemId: 'ADJ2', choice })
/** Every other first-round item settled, so the round can be applied. */
const settleOthers = (): SessionAction[] => REVIEW_INITIAL_ITEMS.filter(item => item.id !== 'ADJ2')
  .map(item => ({ type: 'choose', itemId: item.id, choice: item.id === 'BONREV' ? 'accept' : ASK_CUSTOMER }))
const applied = (...adj2: SessionAction[]) => run(started(), ...adj2, ...settleOthers(), { type: 'submitRound' })
/** Applies the round and sends the questions for the customer. */
const sent = (...adj2: SessionAction[]) => run(applied(...adj2),
  { type: 'finishReevaluation' }, { type: 'complete' }, { type: 'startOptimization' },
  ...OPTIMIZATIONS.map((suggestion): SessionAction => ({ type: 'chooseOptimization', suggestionId: suggestion.id, choice: 'keep' })),
  { type: 'submitOptimization' }, { type: 'completeOptimization' }, { type: 'startOvertime' },
  ...SCREENING_QUESTIONS.map((question): SessionAction => ({ type: 'answerOvertime', questionId: question.id, answer: 'no' })),
  { type: 'confirmOvertime' }, { type: 'sendQuestions', to: 'customer@example.com' })
const reply = (session: EarningSession, answer: ItemAnswer) =>
  run(session, { type: 'saveCustomerReply', questionId: 'classification:ADJ2', answer })

describe('ADJ2: describe first, then keep or remove', () => {
  it('refreshes an unsent obsolete standard question without changing saved evidence', () => {
    const base = applied({ type: 'choose', itemId: 'ADJ2', choice: ASK_CUSTOMER })
    const oldText = 'The pay register data lists ADJ2 with no payments in the last 12 months. Do you still use ADJ2? If you do, what does it pay for?'
    const saved = { ...base, files: SAMPLE_REGISTER_FILES, customerQuestions: base.customerQuestions.map(question =>
      question.itemId === 'ADJ2' ? { ...question, question: oldText } : question) }
    const restored = parseSession(JSON.stringify(saved))!
    const question = restored.customerQuestions.find(question => question.itemId === 'ADJ2')!
    expect(question.question).toBe(oldText)
    expect(standardCustomerQuestion(restored, question)).toContain(COMBINED)
    expect(cheatSheetGroups(restored).flatMap(group => group.rows).find(row => row.id === 'ADJ2')?.questions[0]).toContain(COMBINED)
    expect(restored.answers).toEqual(saved.answers)
    expect(restored.resolutions).toEqual(saved.resolutions)
    const sentHistory = { ...restored, sent: { at: 1000, to: 'customer@example.com', questionIds: ['classification:ADJ2'] } }
    expect(standardCustomerQuestion(sentHistory, question)).toBe(oldText)
    const frozen = { ...sentHistory, sent: { ...sentHistory.sent,
      questions: customerQuestionList(sentHistory).filter(question => question.id === 'classification:ADJ2') } }
    const frozenRestored = parseSession(JSON.stringify(frozen))!
    expect(frozenRestored.sent).toEqual(frozen.sent)
    expect(frozenRestored.sent?.questions?.find(question => question.codes.includes('ADJ2'))?.question).toBe(oldText)
    const replied = { ...restored, customerReplies: {
      'classification:ADJ2': { answer: { retain: 'remove' as const }, text: 'Leave it out', at: 1000 },
    } }
    expect(standardCustomerQuestion(replied, question)).toBe(oldText)
    const completedReply = reply(sent({ type: 'choose', itemId: 'ADJ2', choice: ASK_CUSTOMER }), {
      ...run(started(), ...describeAdj2()).answers.ADJ2, retain: 'remove',
    })
    expect(parseSession(JSON.stringify(completedReply))?.customerReplies).toEqual(completedReply.customerReplies)
  })

  it.each([1, 2])('keeps deferred summary evidence scoped to %i selected register periods', count => {
    const base = applied({ type: 'choose', itemId: 'ADJ2', choice: ASK_CUSTOMER })
    const restored = parseSession(JSON.stringify({ ...base, files: SAMPLE_REGISTER_FILES.slice(0, count) }))!
    const row = cheatSheetGroups(restored).flatMap(group => group.rows).find(row => row.id === 'ADJ2')!
    expect(row.evidence.join(' ')).toContain('September 1–15, 2026 · Reported period amount: $0.00')
    expect(row.evidence.join(' ')).not.toMatch(/12.month/i)
    if (count === 2) expect(row.evidence.join(' ')).toContain('September 16–30, 2026 · Reported period amount: $0.00')
    else expect(row.evidence.join(' ')).not.toContain('September 16–30, 2026')
    expect(JSON.stringify(row)).not.toMatch(/no payments|old code|no activity|pay code list/i)
    expect(row.questions[0]).toContain(COMBINED)
    expect(summaryCsv(restored, () => 'Today')).toContain(COMBINED)
    expect(summaryCsv(restored, () => 'Today')).not.toContain('no payments in the last 12 months')
  })

  it('asks whether to keep ADJ2 only once its description and follow-ups are answered', () => {
    let session = started()
    const answer = () => session.answers.ADJ2 ?? {}
    expect(unidentifiedStage(ADJ2, answer())).toBe('describe')
    expect(retentionAsked(ADJ2, answer())).toBe(false)
    session = run(session, ...describeAdj2().slice(0, 3))
    expect(retentionAsked(ADJ2, answer())).toBe(false)
    session = run(session, describeAdj2()[3])
    expect(retentionAsked(ADJ2, answer())).toBe(true)
    expect(retentionOf(answer())).toBeUndefined()
    expect(decisionFor(ADJ2, answer())).toBeUndefined()
    // Keep continues to the suggested reference, which counts only once chosen.
    session = run(session, retain('keep'))
    expect(decisionFor(ADJ2, answer())).toBeUndefined()
    session = run(session, { type: 'choose', itemId: 'ADJ2', choice: 'accept' })
    expect(decisionFor(ADJ2, answer())).toMatchObject({ kind: 'resolve', reference: READY.retro })
    // Switching to Remove drops the accepted reference.
    session = run(session, retain('remove'))
    expect(answer().choice).toBeUndefined()
    expect(decisionFor(ADJ2, answer())).toEqual({ kind: 'remove' })
  })

  it('finishes a removed ADJ2 as Not set up, with no naming step and no customer question', () => {
    const session = applied(...describeAdj2('recurring'), retain('remove'))
    expect(session.resolutions.ADJ2).toMatchObject({ status: 'removed' })
    expect(session.answers.ADJ2.naming).toBeUndefined()
    expect(finalConfiguration(session).find(row => row.code === 'ADJ2')?.status).toBe('notSetUp')
    expect(summaryCsv(session, () => 'Today').split('\r\n').find(line => line.startsWith('"Code","ADJ2"'))).toContain('Not set up')
    expect(session.customerQuestions.some(question => question.code === 'ADJ2')).toBe(false)
  })

  it.each<[string, SessionAction[]]>([
    ['a changed description', [{ type: 'describe', itemId: 'ADJ2', description: 'Something else' }]],
    ['Edit description', [{ type: 'editDescription', itemId: 'ADJ2' }]],
    ['a changed follow-up', [{ type: 'answerFollowUp', itemId: 'ADJ2', questionId: 'basis', choice: 'hourly' }]],
  ])('clears the keep-or-remove choice and the accepted reference after %s', (_label, actions) => {
    for (const choice of ['keep', 'remove'] as const) {
      let session = run(started(), ...describeAdj2(), retain(choice))
      if (choice === 'keep') session = run(session, { type: 'choose', itemId: 'ADJ2', choice: 'accept' })
      session = run(session, ...actions)
      expect(session.answers.ADJ2.retain).toBeUndefined()
      expect(session.answers.ADJ2.choice).toBeUndefined()
      expect(decisionFor(ADJ2, session.answers.ADJ2)).toBeUndefined()
    }
  })

  it.each<[string, SessionAction[]]>([
    ['the description', [{ type: 'describe', itemId: 'ADJ2', description: 'Not sure' }, { type: 'choose', itemId: 'ADJ2', choice: ASK_CUSTOMER }]],
    ['a follow-up', [...describeAdj2().slice(0, 2), { type: 'answerFollowUp', itemId: 'ADJ2', questionId: 'basis', choice: ASK_CUSTOMER }]],
    ['the keep-or-remove question', [...describeAdj2(), retain(ASK_CUSTOMER)]],
  ])('sends the combined customer question when Defer is selected on %s before Keep', (_label, actions) => {
    const session = run(started(), ...actions)
    expect(decisionFor(ADJ2, session.answers.ADJ2)).toEqual({ kind: 'defer' })
    expect(customerQuestionFor(ADJ2, session.answers.ADJ2)).toContain(COMBINED)
    const round = run(session, ...settleOthers(), { type: 'submitRound' })
    expect(round.customerQuestions.find(question => question.code === 'ADJ2')?.question).toContain(COMBINED)
  })

  it('keeps the description and follow-ups when Defer is unchecked on the keep-or-remove question', () => {
    const session = run(started(), ...describeAdj2(), retain(ASK_CUSTOMER), retain(''))
    expect(session.answers.ADJ2).toEqual(run(started(), ...describeAdj2()).answers.ADJ2)
    expect(retentionAsked(ADJ2, session.answers.ADJ2)).toBe(true)
    expect(decisionFor(ADJ2, session.answers.ADJ2)).toBeUndefined()
  })

  it('takes a customer reply in the same order: the description and follow-ups, then keep or remove', () => {
    const deferred = sent({ type: 'choose', itemId: 'ADJ2', choice: ASK_CUSTOMER })
    expect(deferred.sent?.questionIds).toContain('classification:ADJ2')
    const described = run(started(), ...describeAdj2()).answers.ADJ2
    // Keep or remove alone, or before the follow-ups, isn't a complete reply.
    expect(reply(deferred, { retain: 'remove' })).toBe(deferred)
    expect(reply(deferred, { description: 'Old code', descriptionSubmitted: true, followUps: {}, retain: 'remove' })).toBe(deferred)
    expect(reply(deferred, { ...described, retain: 'keep' })).toBe(deferred)
    expect(reply(deferred, { ...described, choice: 'accept' })).toBe(deferred)
    const removed = reply(deferred, { ...described, retain: 'remove' })
    expect(removed.resolutions.ADJ2).toMatchObject({ status: 'removed' })
    expect(removed.answers.ADJ2).toEqual({ ...described, retain: 'remove' })
    expect(finalConfiguration(removed).find(row => row.code === 'ADJ2')?.status).toBe('notSetUp')
    const kept = reply(deferred, { ...described, retain: 'keep', choice: 'accept' })
    expect(kept.resolutions.ADJ2).toMatchObject({ status: 'resolved', reference: READY.retro })
    expect(kept.answers.ADJ2.retain).toBe('keep')
    // Both replies survive a reload unchanged.
    for (const session of [removed, kept]) expect(parseSession(JSON.stringify(session))).toEqual(JSON.parse(JSON.stringify(session)))
  })

  it('restores a customer Remove saved when the keep-or-remove question came first', () => {
    const deferred = sent({ type: 'choose', itemId: 'ADJ2', choice: ASK_CUSTOMER })
    const legacy: EarningSession = {
      ...deferred,
      answers: { ...deferred.answers, ADJ2: { retain: 'remove' } },
      resolutions: { ...deferred.resolutions, ADJ2: { status: 'removed', round: deferred.resolutions.ADJ2.round } },
      customerReplies: { 'classification:ADJ2': { answer: { retain: 'remove' }, text: 'Removed from the setup', at: 1000 } },
    }
    expect(parseSession(JSON.stringify(legacy))).toEqual(legacy)
    // A reply that doesn't match the saved answer is still rejected.
    const mismatched = { ...legacy, answers: { ...legacy.answers, ADJ2: { retain: 'keep' as const } } }
    expect(parseSession(JSON.stringify(mismatched))).toBeNull()
  })

  it('opens progress saved before this order unchanged: finished stays finished, Remove stays removed, partial work resumes', () => {
    const described = run(started(), ...describeAdj2()).answers.ADJ2
    const saved: Record<string, { answer: ItemAnswer; decision: unknown; asked: boolean; stage: string }> = {
      // A reference accepted before the keep-or-remove question existed.
      finished: { answer: { ...described, choice: 'accept' }, decision: { kind: 'resolve', reference: READY.retro, raises: [] }, asked: true, stage: 'suggestion' },
      // Saved when the keep-or-remove question came first.
      removed: { answer: { retain: 'remove' }, decision: { kind: 'remove' }, asked: false, stage: 'describe' },
      deferredFirst: { answer: { retain: ASK_CUSTOMER }, decision: { kind: 'defer' }, asked: false, stage: 'describe' },
      keptThenTyping: { answer: { retain: 'keep', description: 'Correction' }, decision: undefined, asked: false, stage: 'describe' },
      // Saved before the AI check: the answers stay, and the check runs again for them when the card opens.
      keptMidFollowUps: { answer: { retain: 'keep', description: 'Correction', descriptionSubmitted: true, followUps: { basis: 'flat' } }, decision: undefined, asked: false, stage: 'checking' },
      keptAfterFollowUps: { answer: { ...described, retain: 'keep' }, decision: undefined, asked: true, stage: 'suggestion' },
    }
    for (const [label, { answer, decision, asked, stage }] of Object.entries(saved)) {
      const session = { ...started(), answers: { ADJ2: answer } }
      const restored = parseSession(JSON.stringify(session))
      expect(restored, label).toEqual(session)
      expect(decisionFor(ADJ2, restored!.answers.ADJ2), label).toEqual(decision)
      expect(retentionAsked(ADJ2, restored!.answers.ADJ2), label).toBe(asked)
      expect(unidentifiedStage(ADJ2, restored!.answers.ADJ2), label).toBe(stage)
    }
    expect(retentionOf(saved.finished.answer)).toBe('keep')
    expect(retentionOf(saved.keptAfterFollowUps.answer)).toBe('keep')
  })
})
