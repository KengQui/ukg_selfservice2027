import { describe, expect, it } from 'vitest'
import { createSession, reduceSession, type EarningSession, type SessionAction } from './session'
import { ASK_CUSTOMER, CLEAR_CHOICE } from './sampleRegister'
import { CELL_ID } from './cell'

const run = (session: EarningSession, ...actions: SessionAction[]) =>
  actions.reduce((state, action) => reduceSession(state, action, 1000), session)
const started = () => run(createSession(0), { type: 'startReview' })

describe('unchecking Defer', () => {
  it('clears a review decision and keeps what the team typed', () => {
    const typed = run(started(), { type: 'describe', itemId: 'ADJ2', description: 'Correction' },
      { type: 'choose', itemId: 'ADJ2', choice: ASK_CUSTOMER })
    expect(run(typed, { type: 'choose', itemId: 'ADJ2', choice: CLEAR_CHOICE }).answers.ADJ2).toEqual({ description: 'Correction', choice: undefined })
    const otp = run(started(), { type: 'choose', itemId: 'OTPREM', choice: ASK_CUSTOMER }, { type: 'choose', itemId: 'OTPREM', choice: CLEAR_CHOICE })
    expect(otp.answers.OTPREM.choice).toBeUndefined()
  })

  it('leaves SPPAY and CELL unanswered, and ignores an unchecked box that was never checked', () => {
    const sppay = run(started(), { type: 'choose', itemId: 'SPPAY', choice: ASK_CUSTOMER }, { type: 'choose', itemId: 'SPPAY', choice: CLEAR_CHOICE })
    expect(sppay.answers.SPPAY).toEqual({})
    const shift = run(started(), { type: 'choose', itemId: 'SPPAY', choice: 'shift' })
    expect(run(shift, { type: 'choose', itemId: 'SPPAY', choice: CLEAR_CHOICE })).toBe(shift)
    const cell = run(started(), { type: 'choose', itemId: CELL_ID, choice: ASK_CUSTOMER }, { type: 'choose', itemId: CELL_ID, choice: CLEAR_CHOICE })
    expect(cell.answers[CELL_ID]).toEqual({})
  })

  it('clears a deferred follow-up and the CELL stage it defers', () => {
    const cell = run(started(), { type: 'choose', itemId: CELL_ID, choice: 'reimbursement' },
      { type: 'answerFollowUp', itemId: CELL_ID, questionId: 'treatment', choice: ASK_CUSTOMER })
    expect(run(cell, { type: 'answerFollowUp', itemId: CELL_ID, questionId: 'treatment', choice: CLEAR_CHOICE }).answers[CELL_ID])
      .toEqual({ choice: 'reimbursement', followUps: {} })
    const den = run(started(), { type: 'choose', itemId: 'MED ER', choice: 'only-records' },
      { type: 'answerFollowUp', itemId: 'MED ER', questionId: 'medical-display', choice: ASK_CUSTOMER })
    expect(run(den, { type: 'answerFollowUp', itemId: 'MED ER', questionId: 'medical-display', choice: CLEAR_CHOICE }).answers['MED ER'])
      .toMatchObject({ followUps: {} })
  })

  it('removes a deferred optimization or overtime answer', () => {
    const optimization = run(started(), { type: 'chooseOptimization', suggestionId: 'combine-overtime', choice: ASK_CUSTOMER })
    expect(optimization.optimization.answers['combine-overtime']).toBe(ASK_CUSTOMER)
    expect(run(optimization, { type: 'chooseOptimization', suggestionId: 'combine-overtime', choice: CLEAR_CHOICE }).optimization.answers)
      .not.toHaveProperty('combine-overtime')
    const overtime: EarningSession = { ...started(), step: 'overtime' }
    const answered = run(overtime, { type: 'answerOvertime', questionId: 'multiRate', answer: ASK_CUSTOMER })
    expect(answered.overtime.answers.multiRate).toBe(ASK_CUSTOMER)
    expect(run(answered, { type: 'answerOvertime', questionId: 'multiRate', answer: CLEAR_CHOICE }).overtime.answers).not.toHaveProperty('multiRate')
  })
})
