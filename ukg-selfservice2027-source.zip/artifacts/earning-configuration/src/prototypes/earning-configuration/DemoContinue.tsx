import { Button } from '@ready/dls/compatibility'
import { demoNavigationAllowed } from './session'
import { useEarningSession } from './sessionContext'

/** Separate from Apply: navigation never confirms answers or creates a proposal. */
export default function DemoContinue() {
  const { session, dispatch } = useEarningSession()
  if (!demoNavigationAllowed(session)) return null
  return <Button variant="secondary" size="large" data-testid="button-demo-optimization"
    onClick={() => dispatch({ type: 'continueDemoReview' })}>Continue to optimization</Button>
}
