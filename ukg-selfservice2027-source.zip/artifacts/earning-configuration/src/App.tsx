import { lazy, Suspense } from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import LoadingState from './components/LoadingState'

const SetupApp = lazy(() => import('./SetupApp'))
const QuestionPipelinePresentation = lazy(() => import('./presentation/question-pipeline'))

export default function App() {
  return (
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <Routes>
        {/* Read-only presentations never load the setup session or Bryte providers. */}
        <Route path="/presentation/question-pipeline" element={
          <Suspense fallback={<LoadingState label="Loading presentation…" />}>
            <QuestionPipelinePresentation />
          </Suspense>
        } />
        <Route path="*" element={
          <Suspense fallback={<LoadingState label="Loading payroll setup…" />}>
            <SetupApp />
          </Suspense>
        } />
      </Routes>
    </BrowserRouter>
  )
}
