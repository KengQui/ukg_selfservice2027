import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import App from './App'
import { createSession, reduceSession } from './prototypes/earning-configuration/session'
import * as storage from './prototypes/earning-configuration/storage'

// Delay imports, not components: every released module is the real implementation.
// Keep this file's lazy instances cold until the corresponding route/phase is used.
const imports = vi.hoisted(() => {
  function deferred() {
    let release!: () => void
    let loaded!: () => void
    const pending = new Promise<void>(resolve => { release = resolve })
    const ready = new Promise<void>(resolve => { loaded = resolve })
    return { pending, release, ready, loaded, requested: vi.fn() }
  }
  return {
    setup: deferred(), presentation: deferred(), results: deferred(), questions: deferred(),
    session: { mounts: 0, unmounts: 0 },
    bryte: { mounts: 0, unmounts: 0 },
  }
})

vi.mock('./SetupApp', async importOriginal => {
  imports.setup.requested()
  await imports.setup.pending
  const actual = await importOriginal<typeof import('./SetupApp')>()
  imports.setup.loaded()
  return actual
})
vi.mock('./presentation/question-pipeline', async importOriginal => {
  imports.presentation.requested()
  await imports.presentation.pending
  return importOriginal<typeof import('./presentation/question-pipeline')>()
})
vi.mock('./prototypes/earning-configuration/StepResults', async importOriginal => {
  imports.results.requested()
  await imports.results.pending
  return importOriginal<typeof import('./prototypes/earning-configuration/StepResults')>()
})
vi.mock('./prototypes/earning-configuration/StepQuestions', async importOriginal => {
  imports.questions.requested()
  await imports.questions.pending
  return importOriginal<typeof import('./prototypes/earning-configuration/StepQuestions')>()
})
vi.mock('./prototypes/earning-configuration/SessionProvider', async importOriginal => {
  const actual = await importOriginal<typeof import('./prototypes/earning-configuration/SessionProvider')>()
  const { useEffect } = await import('react')
  return {
    ...actual,
    EarningSessionProvider: (props: React.ComponentProps<typeof actual.EarningSessionProvider>) => {
      useEffect(() => {
        imports.session.mounts++
        return () => { imports.session.unmounts++ }
      }, [])
      return <actual.EarningSessionProvider {...props} />
    },
  }
})
vi.mock('@workspace/setup-shared/ask-bryte', async importOriginal => {
  const actual = await importOriginal<typeof import('@workspace/setup-shared/ask-bryte')>()
  const { useEffect } = await import('react')
  return {
    ...actual,
    AskBryteProvider: (props: React.ComponentProps<typeof actual.AskBryteProvider>) => {
      useEffect(() => {
        imports.bryte.mounts++
        return () => { imports.bryte.unmounts++ }
      }, [])
      return <actual.AskBryteProvider {...props} />
    },
  }
})

let base: string
let host: HTMLDivElement
let root: Root

beforeEach(() => {
  (globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
  vi.stubEnv('BASE_URL', '/earning-configuration/')
  base = import.meta.env.BASE_URL.replace(/\/$/, '')
  localStorage.clear()
  sessionStorage.clear()
  imports.session.mounts = imports.session.unmounts = 0
  imports.bryte.mounts = imports.bryte.unmounts = 0
  vi.spyOn(storage, 'loadSession')
  vi.spyOn(storage, 'writeWorkingCopy')
  vi.spyOn(storage, 'saveSession')
  vi.spyOn(storage, 'clearSessions')
  vi.spyOn(window, 'scrollTo').mockImplementation(() => {})
  vi.stubGlobal('fetch', vi.fn(() => { throw new Error('Loading must not call an API') }))
  vi.stubGlobal('matchMedia', vi.fn((query: string) => ({
    matches: false, media: query, onchange: null,
    addEventListener: vi.fn(), removeEventListener: vi.fn(),
    addListener: vi.fn(), removeListener: vi.fn(), dispatchEvent: vi.fn(),
  })))
  host = document.createElement('div')
  document.body.append(host)
  root = createRoot(host)
})

afterEach(async () => {
  await act(async () => { root.unmount() })
  host.remove()
  localStorage.clear()
  sessionStorage.clear()
  vi.restoreAllMocks()
  vi.unstubAllGlobals()
  vi.unstubAllEnvs()
})

function expectPending(label: string) {
  const status = host.querySelector('.ec-loading[role="status"]')
  expect(status?.textContent).toBe(label)
  expect(status?.getAttribute('aria-live')).toBe('polite')
  expect(status?.getAttribute('aria-atomic')).toBe('true')
}

function expectProviders() {
  expect(storage.loadSession).toHaveBeenCalledTimes(1)
  expect(imports.session).toEqual({ mounts: 1, unmounts: 0 })
  expect(imports.bryte).toEqual({ mounts: 1, unmounts: 0 })
}

async function settleImports(release?: () => void) {
  await act(async () => {
    release?.()
    await vi.dynamicImportSettled()
  })
}

describe('real deferred app imports', () => {
  it('keeps a cold direct presentation isolated while pending and after loading', async () => {
    const saved = '{"version":1,"answers":{"BONREV":{"choice":"ask-customer"}}}'
    const working = '{"version":2,"reviewCursor":4,"files":[{"id":"retained"}]}'
    localStorage.setItem(storage.SAVED_COPY_KEY, saved)
    sessionStorage.setItem(storage.WORKING_COPY_KEY, working)
    window.history.replaceState({}, '', `${base}/presentation/question-pipeline#examples`)
    await act(async () => { root.render(<App />) })
    expectPending('Loading presentation…')
    const expectIsolation = () => {
      expect(imports.setup.requested).not.toHaveBeenCalled()
      expect(imports.results.requested).not.toHaveBeenCalled()
      expect(imports.questions.requested).not.toHaveBeenCalled()
      expect(storage.loadSession).not.toHaveBeenCalled()
      expect(storage.writeWorkingCopy).not.toHaveBeenCalled()
      expect(storage.saveSession).not.toHaveBeenCalled()
      expect(storage.clearSessions).not.toHaveBeenCalled()
      expect(imports.session).toEqual({ mounts: 0, unmounts: 0 })
      expect(imports.bryte).toEqual({ mounts: 0, unmounts: 0 })
      expect(fetch).not.toHaveBeenCalled()
      expect(localStorage.getItem(storage.SAVED_COPY_KEY)).toBe(saved)
      expect(sessionStorage.getItem(storage.WORKING_COPY_KEY)).toBe(working)
      expect(host.querySelector('.cshell__header-area')).toBeNull()
      expect(host.querySelector('[data-ask-bryte-launcher]')).toBeNull()
    }
    expectIsolation()
    await settleImports(imports.presentation.release)
    expect(host.querySelector('[data-testid="text-section-position"]')?.textContent).toBe('Section 6 of 7')
    expect(host.querySelectorAll('main')).toHaveLength(1)
    expect(host.querySelector('.ec-loading')).toBeNull()
    expectIsolation()
  })

  it('keeps one session and Bryte provider through pending results and review, including a return', async () => {
    let session = reduceSession(createSession(100), { type: 'startReview' }, 200)
    session = reduceSession(session, { type: 'choose', itemId: 'MISC7', choice: 'ask-customer' }, 300)
    session = reduceSession(session, {
      type: 'setFiles',
      files: [{ id: 'retained-upload', name: 'register.csv', sizeBytes: 100, docType: 'pay-register' }],
    }, 400)
    sessionStorage.setItem(storage.WORKING_COPY_KEY, JSON.stringify({ ...session, step: 'results' }))
    window.history.replaceState({}, '', `${base}/`)
    await act(async () => { root.render(<App />) })
    expectPending('Loading payroll setup…')
    expect(storage.loadSession).not.toHaveBeenCalled()
    expect(imports.session.mounts).toBe(0)
    expect(imports.bryte.mounts).toBe(0)
    // Wait only for the shell import; the results import must remain pending.
    await act(async () => {
      imports.setup.release()
      await imports.setup.ready
    })
    expectPending('Loading setup step…')
    expectProviders()
    const header = host.querySelector('.cshell__header-area')
    expect(header).not.toBeNull()
    await settleImports(imports.results.release)
    expect(host.querySelector('.ec-loading')).toBeNull()
    expect(host.querySelector('[data-ask-bryte-launcher]')).not.toBeNull()
    const review = [...host.querySelectorAll<HTMLButtonElement>('button')]
      .find(action => action.textContent?.trim() === 'Continue review')
    expect(review).toBeDefined()
    await act(async () => { review!.click() })
    expectPending('Loading setup step…')
    expectProviders()
    expect(host.querySelector('.cshell__header-area')).toBe(header)
    const expectProgress = () => {
      const progress = JSON.parse(sessionStorage.getItem(storage.WORKING_COPY_KEY)!)
      expect(progress.answers).toEqual(session.answers)
      expect(progress.files).toEqual(session.files)
      expect(progress.rounds).toEqual(session.rounds)
    }
    expectProgress()
    await settleImports(imports.questions.release)
    expect(host.querySelector('h1.ec-h1')?.textContent).toBe('Changes we found')
    expect(host.textContent).toContain('Defer')
    expect(host.querySelector('[data-ask-bryte-launcher]')).not.toBeNull()
    expectProviders()
    expectProgress()
    const back = [...host.querySelectorAll('button')].find(button => button.textContent?.trim() === 'Back')
    expect(back).toBeDefined()
    await act(async () => { back!.click() })
    await settleImports()
    expect(host.querySelector('.ec-loading')).toBeNull()
    expect(host.querySelector('.cshell__header-area')).toBe(header)
    expect(host.querySelector('[data-ask-bryte-launcher]')).not.toBeNull()
    expect(JSON.parse(sessionStorage.getItem(storage.WORKING_COPY_KEY)!).step).toBe('results')
    expectProviders()
    expectProgress()
  })
})