export default function LoadingState({ label }: { label: string }) {
  return <p className="ec-loading" role="status" aria-live="polite" aria-atomic="true">{label}</p>
}