import { act, lazy, Suspense } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { ErrorBoundary } from './error-boundary'
import { isModuleLoadError, reloadPage } from './module-load-recovery'
import { SAVED_COPY_KEY, WORKING_COPY_KEY } from '../prototypes/earning-configuration/storage'

vi.mock('./module-load-recovery', async importOriginal => ({
  ...await importOriginal<typeof import('./module-load-recovery')>(),
  reloadPage: vi.fn(),
}))

let host: HTMLDivElement
let root: Root
beforeEach(() => {
  (globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
  vi.mocked(reloadPage).mockReset()
  vi.spyOn(console, 'error').mockImplementation(() => {})
  host = document.createElement('div')
  document.body.append(host)
  root = createRoot(host)
})
afterEach(() => {
  act(() => root.unmount())
  host.remove()
  localStorage.clear()
  sessionStorage.clear()
  vi.restoreAllMocks()
})

describe('failed page downloads', () => {
  it.each([
    'Failed to fetch dynamically imported module: https://example.test/earning-configuration/src/SetupApp.tsx',
    'error loading dynamically imported module: https://example.test/assets/StepQuestions.js',
    'Importing a module script failed.',
    'Loading chunk payroll-setup failed.',
    'Unable to preload CSS for /assets/StepQuestions.css',
  ])('recognizes the browser error: %s', message => {
    expect(isModuleLoadError(new TypeError(message))).toBe(true)
  })

  it('does not mistake an API or ordinary render error for a module failure', () => {
    expect(isModuleLoadError(new TypeError('Failed to fetch'))).toBe(false)
    expect(isModuleLoadError(new Error('Cannot read properties of undefined'))).toBe(false)
    const chunkError = new Error('A page file is no longer available')
    chunkError.name = 'ChunkLoadError'
    expect(isModuleLoadError(chunkError)).toBe(true)
  })

  it('reloads on an explicit retry of a rejected lazy import without clearing answers or changing the URL', async () => {
    const saved = JSON.stringify({ answers: { DEN: { choice: 'both' } } })
    const working = JSON.stringify({ step: 'questions', answers: { ADJ2: { description: 'An adjustment' } } })
    localStorage.setItem(SAVED_COPY_KEY, saved)
    sessionStorage.setItem(WORKING_COPY_KEY, working)
    window.history.replaceState({}, '', '/earning-configuration/?returnTo=setup#review')
    const url = window.location.href
    const load = vi.fn(async (): Promise<{ default: () => null }> => {
      throw new TypeError('Failed to fetch dynamically imported module: /earning-configuration/src/SetupApp.tsx')
    })
    const Screen = lazy(load)
    await act(async () => root.render(
      <ErrorBoundary><Suspense fallback="Loading"><Screen /></Suspense></ErrorBoundary>,
    ))
    expect(host.textContent).toContain('Something went wrong')
    expect(reloadPage).not.toHaveBeenCalled()
    act(() => host.querySelector<HTMLButtonElement>('button')!.click())
    expect(reloadPage).toHaveBeenCalledOnce()
    // A redraw cannot retry this lazy instance; the fresh document must do it.
    expect(load).toHaveBeenCalledOnce()
    expect(window.location.href).toBe(url)
    expect(localStorage.getItem(SAVED_COPY_KEY)).toBe(saved)
    expect(sessionStorage.getItem(WORKING_COPY_KEY)).toBe(working)
  })

  it('keeps ordinary render retries local', () => {
    let failing = true
    function Screen() {
      if (failing) throw new Error('An ordinary rendering error')
      return <p>Ready to continue</p>
    }
    act(() => root.render(<ErrorBoundary><Screen /></ErrorBoundary>))
    failing = false
    act(() => host.querySelector<HTMLButtonElement>('button')!.click())
    expect(host.textContent).toBe('Ready to continue')
    expect(reloadPage).not.toHaveBeenCalled()
  })

  it('allows navigation away from a failed screen without forcing a reload', () => {
    function BrokenScreen(): never { throw new TypeError('Importing a module script failed.') }
    act(() => root.render(<ErrorBoundary resetKey="old"><BrokenScreen /></ErrorBoundary>))
    act(() => root.render(<ErrorBoundary resetKey="new"><p>Another screen</p></ErrorBoundary>))
    expect(host.textContent).toBe('Another screen')
    expect(reloadPage).not.toHaveBeenCalled()
  })
})
