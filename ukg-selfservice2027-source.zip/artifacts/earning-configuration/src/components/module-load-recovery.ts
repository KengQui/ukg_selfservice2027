/**
 * A failed lazy import stays rejected in React and may be cached by the browser.
 * Reload the document on an explicit retry rather than reusing that module graph.
 * Keep ordinary render/API errors out of this path, and never reload automatically.
 */
export function isModuleLoadError(error: Error): boolean {
  return error.name === 'ChunkLoadError'
    || /failed to fetch dynamically imported module|error loading dynamically imported module|importing a module script failed|loading chunk [\w-]+ failed|unable to preload css/i.test(error.message)
}

/** Reloading the same URL retains both sessionStorage and localStorage. */
export function reloadPage(): void {
  window.location.reload()
}
