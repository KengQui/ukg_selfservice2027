import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import App from './App'
import { createSession, reduceSession, reviewPages, type EarningSession, type SessionAction } from './prototypes/earning-configuration/session'
import { customerQuestionList, groupQuestions, questionsEmailText, summaryCsv } from './prototypes/earning-configuration/summary'
import { bryteFacts } from './prototypes/earning-configuration/bryteFacts'
import { REVIEW_INITIAL_ITEMS, findItem } from './prototypes/earning-configuration/sampleRegister'
import * as storage from './prototypes/earning-configuration/storage'

// Keep the real Bryte provider, registration, launcher and panel. Observe its
// lifetime only: a replacement provider must not pass by rehydrating the session.
const lifetime = vi.hoisted(() => ({ mounts: 0, unmounts: 0 }))
vi.mock('@workspace/setup-shared/ask-bryte', async importOriginal => {
  const actual = await importOriginal<typeof import('@workspace/setup-shared/ask-bryte')>()
  const { useEffect } = await import('react')
  return {
    ...actual,
    AskBryteProvider: (props: React.ComponentProps<typeof actual.AskBryteProvider>) => {
      useEffect(() => {
        lifetime.mounts++
        return () => { lifetime.unmounts++ }
      }, [])
      return <actual.AskBryteProvider {...props} />
    },
  }
})

let host: HTMLDivElement
let root: Root

beforeEach(() => {
  (globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true
  vi.stubEnv('BASE_URL', '/earning-configuration/')
  localStorage.clear()
  sessionStorage.clear()
  lifetime.mounts = 0
  lifetime.unmounts = 0
  vi.spyOn(window, 'scrollTo').mockImplementation(() => {})
  vi.stubGlobal('matchMedia', vi.fn((query: string) => ({
    matches: false, media: query, onchange: null,
    addEventListener: vi.fn(), removeEventListener: vi.fn(),
    addListener: vi.fn(), removeListener: vi.fn(), dispatchEvent: vi.fn(),
  })))
  vi.spyOn(storage, 'loadSession')
  host = document.createElement('div')
  document.body.append(host)
  root = createRoot(host)
})

afterEach(() => {
  act(() => root.unmount())
  host.remove()
  localStorage.clear()
  sessionStorage.clear()
  vi.restoreAllMocks()
  vi.unstubAllGlobals()
  vi.unstubAllEnvs()
})

async function settle(action: () => void) {
  await act(async () => { action() })
  // Resolving the outer setup import can start a second, phase-level import.
  for (let boundary = 0; boundary < 2; boundary++) {
    await act(async () => { await vi.dynamicImportSettled() })
  }
}

async function mount(session: EarningSession, path: string, saved = false) {
  const base = import.meta.env.BASE_URL.replace(/\/$/, '')
  window.history.replaceState({}, '', `${base}${path}`)
  if (saved) localStorage.setItem(storage.SAVED_COPY_KEY, JSON.stringify(session))
  else sessionStorage.setItem(storage.WORKING_COPY_KEY, JSON.stringify(session))
  await settle(() => root.render(<App />))
}

function button(label: string) {
  const found = [...document.querySelectorAll('button')].find(el => el.textContent?.trim() === label)
  expect(found, `Missing button: ${label}`).toBeDefined()
  return found!
}

async function check(label: string) {
  const found = [...document.querySelectorAll<HTMLInputElement>('input[type="checkbox"]')].find(el => el.closest('label')?.textContent?.trim() === label)
  expect(found, `Missing checkbox: ${label}`).toBeDefined()
  await settle(() => found!.click())
}

async function click(label: string) {
  await settle(() => button(label).click())
}

function working(): EarningSession {
  return JSON.parse(sessionStorage.getItem(storage.WORKING_COPY_KEY)!)
}

function expectNormalShell() {
  expect(document.querySelector('nav[aria-label="Project navigation"] a')?.textContent).toContain('Back to Projects')
  expect(document.querySelector('.cshell__header-area')).not.toBeNull()
  expect(document.querySelector('.page-title__back button[aria-label="Go back"]')).not.toBeNull()
  expect(button('Save and finish later')).toBeDefined()
  expect(button('Restart demo')).toBeDefined()
  expect(document.querySelector('[data-ask-bryte-launcher]')).not.toBeNull()
}

function expectInitialReview(codes: string[], category: string, page: number, back: string, next: string, stepCount = 7) {
  expect(document.querySelector('h1.ec-h1')?.textContent).toBe(category)
  const steps = [...document.querySelectorAll('nav[aria-label="Review pages"] .ec-stepper__step')]
  expect(steps).toHaveLength(stepCount)
  expect(steps.findIndex(step => step.getAttribute('aria-current') === 'step')).toBe(page - 1)
  expect(document.querySelector('.ec-review-status__deferred')?.textContent).toMatch(/^\d+ deferred$/)
  expect(document.querySelector('.ec-submit-bar.ec-guide-nav.ec-guide-nav--in-flow')).not.toBeNull()
  for (const code of codes) expect(document.querySelector(`.ec-guide-item[aria-label^="${code},"]`)).not.toBeNull()
  for (const code of REVIEW_INITIAL_ITEMS.map(item => item.code).filter(code => !codes.includes(code))) {
    expect(document.querySelector(`.ec-guide-item[aria-label^="${code},"]`)).toBeNull()
  }
  expect(button(back).disabled).toBe(false)
  expect(button(next)).toBeDefined()
  expectNormalShell()
}

function expectSameProviders() {
  expect(storage.loadSession).toHaveBeenCalledTimes(1)
  expect(lifetime).toEqual({ mounts: 1, unmounts: 0 })
}

function answeredSession(): EarningSession {
  let session = reduceSession(createSession(100), { type: 'startReview' }, 200)
  session = reduceSession(session, { type: 'choose', itemId: 'MISC7', choice: 'ask-customer' }, 300)
  return reduceSession(session, {
    type: 'setFiles',
    files: [{ id: 'retained-upload', name: 'register.csv', sizeBytes: 100, docType: 'pay-register' }],
  }, 400)
}

function chooseRadio(code: string, label: string) {
  const group = document.querySelector(`.ec-guide-item[aria-label^="${code},"]`)
  const option = [...(group?.querySelectorAll<HTMLElement>('[role="radio"]') ?? [])]
    .find(radio => radio.textContent?.includes(label))
  expect(option, `${code}: ${label}`).toBeDefined()
  act(() => option!.click())
}

/** Clicks a code's one Defer, which covers every question in its card. */
function deferCode(code: string) {
  const group = document.querySelector(`.ec-guide-item[aria-label^="${code},"]`)
  const found = group?.querySelector<HTMLInputElement>('.ec-defer input[type="checkbox"]') ?? undefined
  expect(found, `${code}: Defer`).toBeDefined()
  act(() => found!.click())
  return found!
}

describe('full-app initial earnings review', () => {
  it.each(['shift', 'retro', 'ask-customer'])('saves SPPAY’s explicit %s answer and restores it without submitting the round', async choice => {
    await mount({ ...reduceSession(createSession(100), { type: 'startReview' }, 200), reviewCursor: 1 }, '/')
    const item = findItem('SPPAY')
    if (item.type !== 'unidentified' || item.script.kind !== 'uncertainMatch') throw Error('SPPAY must remain an uncertain match')
    const group = () => document.querySelector('.ec-guide-item[data-review-item="SPPAY"]')!
    expect(group().querySelector('.ec-qcard__prompt')?.textContent).toBe(item.script.prompt)
    expect(item.script.prompt).toContain('Special Pay has no description.')
    expect(group().textContent).not.toContain('Possible Ready match')
    expect(group().textContent).not.toContain('Why we’re asking')
    // Nothing is selected, so the Something else box stays hidden.
    expect(group().querySelector('input:not([type="radio"]):not([type="checkbox"])')).toBeNull()
    expect(group().querySelector('textarea')).toBeNull()
    expect(group().querySelectorAll('[role="radio"]')).toHaveLength(3)
    expect([...group().querySelectorAll('[role="radio"]')].every(radio => radio.getAttribute('aria-checked') === 'false')).toBe(true)
    expect(group().querySelector<HTMLInputElement>('.ec-defer input[type="checkbox"]')?.checked).toBe(false)
    const label = choice === 'ask-customer' ? 'Defer' : item.script.options.find(option => option.id === choice)!.label
    if (choice === 'ask-customer') deferCode('SPPAY')
    else chooseRadio('SPPAY', label)
    expect(working().answers.SPPAY).toEqual({ choice })
    expect(button('Next').disabled).toBe(true) // ADJ2 and MISC7 still need answers.
    await click('Save and finish later')
    const persisted = JSON.parse(localStorage.getItem(storage.SAVED_COPY_KEY)!) as EarningSession
    expect(persisted.answers.SPPAY).toEqual({ choice })
    expect(persisted.rounds[0].submitted).toBe(false)
    act(() => root.unmount())
    root = createRoot(host)
    sessionStorage.removeItem(storage.WORKING_COPY_KEY)
    await mount(persisted, '/', true)
    expectInitialReview(['OTPREM', 'OTMFG', 'OTSVC', 'SPPAY'], 'How employees are paid', 2, 'Back', 'Next')
    expect(working().answers.SPPAY).toEqual({ choice })
    const selected = [...group().querySelectorAll('[role="radio"]')].filter(radio => radio.getAttribute('aria-checked') === 'true')
    expect(selected).toHaveLength(choice === 'ask-customer' ? 0 : 1)
    if (choice !== 'ask-customer') expect(selected[0].textContent).toContain(label)
    expect(group().querySelector<HTMLInputElement>('.ec-defer input[type="checkbox"]')?.checked).toBe(choice === 'ask-customer')
    expect(group().querySelector('input:not([type="radio"]):not([type="checkbox"])')).toBeNull()
    expect(group().querySelector('textarea')).toBeNull()
  })

  it('enters the first review from fresh results without making any decisions', async () => {
    await mount({ ...createSession(100), step: 'results' }, '/')
    expectNormalShell()
    expect(host.textContent).toContain('20 earning codes')
    expect(host.textContent).toContain('12 need review')
    expect(host.textContent).toContain('2 benefit plans')
    await click('View all 20 codes')
    expect([...document.querySelectorAll('.ec-flag-group')].map(group => group.querySelector('h2, h3')?.textContent?.trim())).toEqual([
      'Changes we found (1)', 'How employees are paid (4)', 'Allowances & reimbursements (2)', 'Benefits & employer contributions (2)',
      'Tips (1)', 'Taxable benefits (2)', 'Other codes (2)',
    ])
    expect(document.querySelector('.ec-matched-count')?.textContent).toContain('8 matched codes')
    expect(document.querySelector('.ec-matched-count')?.textContent).not.toContain('MED')
    await click('Start review')
    expect(working().step).toBe('reviewOverview')
    expectNormalShell()
    expect(working().rounds).toEqual([])
    await click('Start review')
    expectInitialReview(['BONREV'], 'Changes we found', 1, 'Back', 'Next')
    expect(host.textContent).toContain('I understand')
    expect(host.textContent).not.toContain('Keep ADJ2 in the setup?')
    expect(host.textContent).not.toContain('What does MISC7 pay for?')
    expect(button('Next').disabled).toBe(true)
    expect(working().answers).toEqual({})
    expect(working().rounds[0].submitted).toBe(false)
    await click('Back')
    expectNormalShell()
    expect(working().step).toBe('results')
    expect(working().answers).toEqual({})
    expectSameProviders()
  })

  it.each(['/', '/prototypes/earning-configuration'])('retains the shell and providers while entering and leaving the review at %s', async path => {
    const initial = { ...answeredSession(), step: 'results' as const }
    await mount(initial, path)
    expectNormalShell()
    await click('Continue review')
    expectInitialReview(['BONREV'], 'Changes we found', 1, 'Back', 'Next')
    expect(button('Next').disabled).toBe(true)
    expect(host.textContent).toContain('Defer')
    expect(host.textContent).not.toContain('Ask the customer')
    const beforeNext = working()
    await click('Next')
    expect(working()).toEqual(beforeNext)
    await click('Back')
    expectNormalShell()
    expect(working()).toEqual({ ...beforeNext, step: 'results', updatedAt: expect.any(Number) })
    expectSameProviders()
    await click('Continue review')
    expectInitialReview(['BONREV'], 'Changes we found', 1, 'Back', 'Next')
    expect(working().answers).toEqual(initial.answers)
    expect(working().files).toEqual(initial.files)
    expectSameProviders()
  })

  it('advances from the unidentified category through BONREV to OTPREM and CELL without losing files or answers', async () => {
    let session = answeredSession()
    session = reduceSession(session, { type: 'choose', itemId: 'OTPREM', choice: 'premium' }, 500)
    session = reduceSession(session, { type: 'choose', itemId: 'ADJ2', choice: 'ask-customer' }, 600)
    session = reduceSession(session, { type: 'choose', itemId: 'SPPAY', choice: 'shift' }, 700)
    session = reduceSession(session, { type: 'answerSharedSetup', itemId: 'SPPAY', referenceId: 'RDY-E-020', choice: 'separate' }, 701)
    await mount({ ...session, step: 'results' }, '/')
    await click('Continue review')
    expectInitialReview(['BONREV'], 'Changes we found', 1, 'Back', 'Next')
    expect(button('Next').disabled).toBe(true)
    await check('I understand')
    await click('Next')
    expectInitialReview(['OTPREM', 'OTMFG', 'OTSVC', 'SPPAY'], 'How employees are paid', 2, 'Back', 'Next')
    expect(host.textContent).not.toContain('How does the company pay CELL?')
    expect(button('Next').disabled).toBe(true)
    expect(working().answers).toMatchObject({ ...JSON.parse(JSON.stringify(session.answers)), BONREV: { choice: 'accept' } })
    expect(working().files).toEqual(session.files)
    await click('Back')
    expectInitialReview(['BONREV'], 'Changes we found', 1, 'Back', 'Next')
    expectSameProviders()
  })

  it.each(['/', '/prototypes/earning-configuration'])('reenters a saved first-round BONREV page and returns through page zero at %s', async path => {
    const first = answeredSession()
    const saved = { ...first, reviewCursor: 0, answers: { ...first.answers, ADJ2: { choice: 'ask-customer' as const }, SPPAY: { choice: 'shift' } } }
    await mount(saved, path, true)
    expectInitialReview(['BONREV'], 'Changes we found', 1, 'Back', 'Next')
    expect(host.textContent).toContain('I understand')
    expect(button('Next').disabled).toBe(true)
    expect(working().answers).toEqual(saved.answers)
    expect(working().files).toEqual(saved.files)
    await click('Back')
    expect(working().reviewCursor).toBe(0)
    expectNormalShell()
    await click('Continue review')
    expectInitialReview(['BONREV'], 'Changes we found', 1, 'Back', 'Next')
    expect(working().reviewCursor).toBe(0)
    expect(working().answers).toEqual(saved.answers)
    expect(working().files).toEqual(saved.files)
    expect(JSON.parse(localStorage.getItem(storage.SAVED_COPY_KEY)!)).toEqual(saved)
    expectSameProviders()
  })

  it.each(['/', '/prototypes/earning-configuration'])('saves the category and answers, then resumes after a fresh mount at %s', async path => {
    const first = answeredSession()
    const saved = reduceSession(reduceSession(first, { type: 'choose', itemId: 'ADJ2', choice: 'ask-customer' }, 500),
      { type: 'choose', itemId: 'SPPAY', choice: 'shift' }, 600)
    await mount({ ...saved, reviewCursor: 0 }, path)
    expectInitialReview(['BONREV'], 'Changes we found', 1, 'Back', 'Next')
    await click('Save and finish later')
    const persisted = JSON.parse(localStorage.getItem(storage.SAVED_COPY_KEY)!)
    expect(persisted.reviewCursor).toBe(0)
    expect(persisted.answers).toEqual(saved.answers)
    expect(persisted.files).toEqual(saved.files)
    expectNormalShell()
    act(() => root.unmount())
    root = createRoot(host)
    sessionStorage.removeItem(storage.WORKING_COPY_KEY)
    await mount(persisted, path, true)
    expectInitialReview(['BONREV'], 'Changes we found', 1, 'Back', 'Next')
    expect(working().answers).toEqual(saved.answers)
    expect(working().files).toEqual(saved.files)
  })

  it('sends BONREV to the customer with Defer and keeps it changeable after returning', async () => {
    let session = reduceSession(answeredSession(), { type: 'choose', itemId: 'ADJ2', choice: 'ask-customer' }, 500)
    session = reduceSession(session, { type: 'choose', itemId: 'SPPAY', choice: 'shift' }, 550)
    session = reduceSession(session, { type: 'answerSharedSetup', itemId: 'SPPAY', referenceId: 'RDY-E-020', choice: 'separate' }, 551)
    session = reduceSession(session, { type: 'moveReview', index: 0 }, 600)
    await mount(session, '/')
    expect([...document.querySelectorAll('button')].some(el => el.textContent?.trim() === 'Ask the customer')).toBe(false)
    const deferBox = () => document.querySelector<HTMLInputElement>('#checkbox-defer-BONREV')!
    expect(deferBox().checked).toBe(false)
    act(() => deferBox().click())
    expect(working().answers.BONREV.choice).toBe('ask-customer')
    expect(deferBox().checked).toBe(true)
    expect(host.textContent).not.toContain('Deferred.')
    expect(button('Next').disabled).toBe(false)
    await click('Next')
    expectInitialReview(['OTPREM', 'OTMFG', 'OTSVC', 'SPPAY'], 'How employees are paid', 2, 'Back', 'Next')
    expect(host.textContent).not.toContain('Go to BONREV')
    expect(button('Next').disabled).toBe(true)
    await click('Back')
    expectInitialReview(['BONREV'], 'Changes we found', 1, 'Back', 'Next')
    expect(working().answers.BONREV.choice).toBe('ask-customer')
    expect(deferBox().checked).toBe(true)
    await check('I understand')
    expect(working().answers.BONREV.choice).toBe('accept')
    expect(deferBox().checked).toBe(false)
    expectSameProviders()
  })

  it.each(['/', '/prototypes/earning-configuration'])('migrates saved mixed-page progress without skipping unidentified codes at %s', async path => {
    const saved: EarningSession = {
      ...answeredSession(), reviewLayout: 'restored', reviewCursor: 2,
      answers: {
        MISC7: { choice: 'ask-customer' },
        OTPREM: { choice: 'full' },
        ADJ2: { description: 'Correction to earlier pay' },
      },
    }
    await mount(saved, path, true)
    expectInitialReview(['BONREV'], 'Changes we found', 1, 'Back', 'Next')
    expect(working().reviewLayout).toBe('business-topics')
    expect(working().files).toEqual(saved.files)
    expect(working().answers).toEqual(saved.answers)
    expect(host.textContent).not.toContain('60% AI match')
    expect(button('Next').disabled).toBe(true)
    expectSameProviders()
    const migrated = working()
    act(() => root.unmount())
    root = createRoot(host)
    await mount(migrated, path)
    expectInitialReview(['BONREV'], 'Changes we found', 1, 'Back', 'Next')
    expect(working()).toEqual(migrated)
  })

  it('keeps shell and Bryte on the reimbursement, tip and plan pages, with no preselected answers', async () => {
    let session = answeredSession()
    for (const id of ['ADJ2', 'SPPAY', 'OTPREM', 'OTMFG', 'OTSVC']) {
      session = reduceSession(session, { type: 'choose', itemId: id, choice: 'ask-customer' }, 500)
    }
    session = reduceSession(session, { type: 'choose', itemId: 'BONREV', choice: 'accept' }, 500)
    await mount(session, '/')
    for (let index = 0; index < 2; index++) await click('Next')
    for (const [page, codes, topic] of [
      [3, ['CELL', 'MILEAGE'], 'Allowances & reimbursements'],
      [4, ['MED', 'DEN'], 'Benefits & employer contributions'],
      [5, ['TIPS'], 'Tips'],
      [6, ['GTL', 'IMP INC'], 'Taxable benefits'],
    ] as const) {
      expectInitialReview([...codes], topic, page, 'Back', 'Next')
      expect([...document.querySelectorAll('.ec-guide-item [role="radio"]')].every(radio => radio.getAttribute('aria-checked') !== 'true')).toBe(true)
      expect([...document.querySelectorAll('.ec-guide-item')].every(group => group.textContent?.includes('Defer'))).toBe(true)
      expect(button('Next').disabled).toBe(true)
      for (const code of codes) deferCode(code)
      expect(button('Next').disabled).toBe(false)
      await click('Next')
    }
    expect(working().answers['GTL-review'].choice).toBe('ask-customer')
    expect(working().answers.DEN.choice).toBe('ask-customer')
    expect(working().files).toEqual(session.files)
    expectSameProviders()
  })

  it('restores the medical display question and clears its card without losing MED', async () => {
    const first = answeredSession()
    const session = { ...first, reviewCursor: reviewPages(first).findIndex(page => page.includes('MED')), reviewLayout: 'business-topics' as const }
    await mount(session, '/', true)
    expectInitialReview(['MED', 'MED ER'], 'Benefits & employer contributions', session.reviewCursor + 1, 'Back', 'Next', reviewPages(session).length)
    expect(host.textContent).not.toContain('DEN')
    chooseRadio('MED', 'Yes')
    chooseRadio('MED ER', 'We only track what the company pays toward medical. It doesn’t add to anyone’s pay or change how pay is taxed or reported.')
    expect(host.textContent).toContain("Should the employer contribution be displayed on the employee's pay statement?")
    const den = document.querySelector('.ec-guide-item[aria-label^="MED ER,"]')!
    expect(den.querySelectorAll('.ec-qcard')).toHaveLength(1)
    const followUp = den.querySelector('[data-sequence-number="02"]')!
    expect(followUp.querySelector('h3')?.textContent).toBe("Should the employer contribution be displayed on the employee's pay statement?")
    expect(den.querySelector('.ec-qcard')?.classList.contains('ec-qcard--open')).toBe(true)
    expect(button('Next').disabled).toBe(true)
    const beforeReload = working()
    expect(beforeReload.answers['MED ER']).toMatchObject({ choice: 'only-records' })
    act(() => root.unmount())
    root = createRoot(host)
    await mount(beforeReload, '/', false)
    expectInitialReview(['MED', 'MED ER'], 'Benefits & employer contributions', beforeReload.reviewCursor! + 1, 'Back', 'Next', reviewPages(beforeReload).length)
    expect(host.textContent).toContain("Should the employer contribution be displayed on the employee's pay statement?")
    chooseRadio('MED ER', 'Yes')
    expect(working().answers['MED ER'].followUps?.['medical-display']).toBe('yes')
    expect(document.querySelector('.ec-guide-item[aria-label^="MED ER,"] .ec-qcard')?.classList.contains('ec-qcard--answered')).toBe(true)
    // With both questions answered, the card's one Defer defers the last one and keeps the first answer.
    expect(document.querySelectorAll('.ec-guide-item[aria-label^="MED ER,"] .ec-defer')).toHaveLength(1)
    deferCode('MED ER')
    expect(working().answers['MED ER'].choice).toBe('only-records')
    expect(working().answers['MED ER'].followUps?.['medical-display']).toBe('ask-customer')
    // Clearing restarts this card and its working copy without remounting the app.
    act(() => document.querySelector<HTMLElement>('.ec-guide-item[aria-label^="MED ER,"] .ec-qcard__clear-answers')!.click())
    expect(working().answers['MED ER']).toEqual({})
    expect(host.textContent).not.toContain("Should the employer contribution be displayed on the employee's pay statement?")
    expect(lifetime).toEqual({ mounts: 2, unmounts: 1 })
  })

  it('saves the customer medical portion and display choice without raising a separate code', async () => {
    let session = reduceSession(createSession(100), { type: 'startReview' }, 200)
    const apply = (action: SessionAction) => { session = reduceSession(session, action, 300) }
    for (const item of REVIEW_INITIAL_ITEMS.filter(item => !['BONREV', 'MED', 'MED ER'].includes(item.id))) {
      apply({ type: 'choose', itemId: item.id, choice: 'ask-customer' })
    }
    apply({ type: 'choose', itemId: 'BONREV', choice: 'accept' })
    apply({ type: 'choose', itemId: 'MED', choice: 'employee' })
    apply({ type: 'choose', itemId: 'MED ER', choice: 'ask-customer' })
    for (const type of ['submitRound', 'finishReevaluation', 'complete', 'startOptimization'] as const) apply({ type })
    for (const suggestionId of ['combine-overtime', 'split-bonus', 'inactive-JURY']) {
      apply({ type: 'chooseOptimization', suggestionId, choice: 'keep' })
    }
    for (const type of ['submitOptimization', 'completeOptimization', 'startOvertime'] as const) apply({ type })
    for (const questionId of ['multiRate', 'shiftDiff', 'samePeriodBonus', 'multiPeriodBonus', 'fixedSalary']) {
      apply({ type: 'answerOvertime', questionId, answer: 'no' })
    }
    apply({ type: 'confirmOvertime' })
    expect(session.step).toBe('summary')
    apply({ type: 'sendQuestions', to: 'customer@example.com' })
    expect(session.sent?.questionIds).toContain('classification:MED ER')
    await mount(session, '/')
    const den = [...document.querySelectorAll('.ec-customer-question')]
      .find(row => row.querySelector('.ec-customer-question__codes')?.textContent === 'MED ER')!
    expect(den.textContent).toContain('What does MED ER do?')
    act(() => den.querySelector<HTMLButtonElement>('button')!.click())
    const dialog = document.querySelector<HTMLElement>('[role="dialog"]')!
    expect(dialog).not.toBeNull()
    expect(button('Save answer').disabled).toBe(true)
    const select = (label: string) => {
      const radio = [...dialog.querySelectorAll<HTMLElement>('[role="radio"]')].find(entry => entry.textContent?.includes(label))
      expect(radio, `Missing customer reply choice ${label}`).toBeDefined()
      act(() => radio!.click())
    }
    select('We only track what the company pays toward medical.')
    expect(dialog.textContent).toContain("Should the employer contribution be displayed on the employee's pay statement?")
    expect(button('Save answer').disabled).toBe(true)
    select('No')
    expect(button('Save answer').disabled).toBe(false)
    await click('Save answer')
    expect(working().resolutions['MED ER'].status).toBe('resolved')
    expect(working().rounds.flatMap(round => round.itemIds)).not.toContain('DEN ER')
    expect(host.textContent).not.toContain('DEN')
  })

  it('keeps the normal shell and questions for saved later-round Review new findings', async () => {
    const first = answeredSession()
    const later: EarningSession = {
      ...first,
      rounds: [
        { ...first.rounds[0], submitted: true },
        { number: 2, itemIds: ['CELL-purpose'], submitted: false },
      ],
      reviewCursor: 0,
    }
    await mount(later, '/', true)
    expectNormalShell()
    expect(document.querySelector('section[aria-label="Review earnings"]')).toBeNull()
    expect(host.textContent).toContain('Review follow-up questions')
    expect(host.textContent).toContain('CELL')
    expect(button('Apply answers').disabled).toBe(true)
    expect(working().rounds).toEqual(later.rounds)
    expectSameProviders()
  })

  it.each(['unsent', 'snapshot', 'id-only', 'id-only-with-reply'])('settles historical BONREV without losing history (%s)', async format => {
    let session = answeredSession()
    const apply = (action: SessionAction) => { session = reduceSession(session, action) }
    for (const [itemId, choice] of Object.entries({ BONREV: 'accept', ADJ2: 'ask-customer', MISC7: 'ask-customer', OTPREM: 'premium', 'CELL-purpose': 'allowance' })) apply({ type: 'choose', itemId, choice })
    for (const item of REVIEW_INITIAL_ITEMS.filter(item => !['BONREV', 'ADJ2', 'MISC7', 'OTPREM', 'CELL-purpose'].includes(item.id))) {
      apply({ type: 'choose', itemId: item.id, choice: 'ask-customer' })
    }
    for (const type of ['submitRound', 'finishReevaluation', 'complete', 'startOptimization'] as const) apply({ type })
    for (const suggestionId of ['combine-overtime', 'split-bonus', 'inactive-JURY']) apply({ type: 'chooseOptimization', suggestionId, choice: 'keep' })
    for (const type of ['submitOptimization', 'completeOptimization', 'startOvertime'] as const) apply({ type })
    for (const questionId of ['multiRate', 'shiftDiff', 'samePeriodBonus', 'multiPeriodBonus', 'fixedSalary'] as const) apply({ type: 'answerOvertime', questionId, answer: 'no' })
    apply({ type: 'confirmOvertime' })
    expect(session.step).toBe('summary')
    session.answers.BONREV = { choice: 'ask-customer' }
    session.resolutions.BONREV = { status: 'customer', round: 1 }
    session.customerQuestions.push({ itemId: 'BONREV', code: 'BONREV', type: 'misclassification', question: 'Earlier BONREV question', round: 1 })
    if (format !== 'unsent') session.sent = {
      at: 400, to: 'customer@example.com', questionIds: ['classification:BONREV'],
      ...(format === 'snapshot' ? {
        questions: [{ id: 'classification:BONREV', codes: ['BONREV'], topic: 'bonuses' as const, question: 'Earlier BONREV question', status: 'open' as const }],
      } : {}),
    }
    if (format === 'id-only-with-reply') session.customerReplies = {
      'classification:BONREV': { answer: 'accept', text: 'Earlier customer reply', at: 500 },
    }
    // Storage serializes the working copy; undefined optional fields are not persisted.
    const before = JSON.parse(JSON.stringify(session)) as EarningSession
    await mount(session, '/', true)
    const expectHistory = () => {
      if (format === 'unsent') return
      const history = customerQuestionList(working()).filter(question => question.id === 'classification:BONREV')
      expect(history).toHaveLength(1)
      expect(history[0].question).toBe('Earlier BONREV question')
      expect(history[0].status).toBe('notNeeded')
      expect(host.textContent).toContain('Earlier BONREV question')
      expect(host.textContent).toContain('No longer needed')
      const csv = summaryCsv(working(), String)
      expect(csv).toContain('"Question for the customer","BONREV","Bonuses","","","","No longer needed","","Earlier BONREV question')
      if (format === 'id-only-with-reply') {
        expect(history[0].reply).toEqual(before.customerReplies!['classification:BONREV'])
        expect(host.textContent).toContain('Earlier customer reply')
        expect(csv).toContain('Customer answer: Earlier customer reply')
      }
      expect(questionsEmailText(groupQuestions(customerQuestionList(working())))).not.toContain('BONREV')
    }
    expectHistory()
    expect(host.textContent).toContain('BONREV needs your team’s review')
    expect(bryteFacts(working()).facts.legacyBonrevReview).toBe(true)
    expect(bryteFacts(working()).facts.waitingOnCustomer).not.toContain('BONREV')
    expect(customerQuestionList(working()).filter(question => question.status === 'open').some(question => question.codes.includes('BONREV'))).toBe(false)
    expect(questionsEmailText(groupQuestions(customerQuestionList(working())))).not.toContain('BONREV')
    await settle(() => button('Review BONREV').click())
    expect(button('Apply answers').disabled).toBe(true)
    // The team's acknowledgment of an older question is not a second chance to ask the customer.
    expect([...document.querySelectorAll('button')].some(el => ['Defer', 'Ask the customer'].includes(el.textContent?.trim() ?? ''))).toBe(false)
    await click('Leave for later')
    expect(working().answers).toEqual(before.answers)
    await settle(() => button('Review BONREV').click())
    expect(button('Apply answers').disabled).toBe(true)
    await check('I understand')
    await click('Apply answers')
    expect(host.textContent).toContain('Your team acknowledged that BONREV will be set up as a Deduction.')
    expect(working().answers.BONREV.choice).toBe('accept')
    expect(working().resolutions.BONREV.status).toBe('resolved')
    expect(working().customerQuestions).toEqual(before.customerQuestions)
    expect(working().sent).toEqual(before.sent)
    expect(working().customerReplies).toEqual(before.customerReplies)
    expect(working().rounds).toEqual(before.rounds)
    expect(working().files).toEqual(before.files)
    expect(summaryCsv(working(), String)).toMatch(/"BONREV","Bonus Reversal","Deduction",[^\r\n]*"Ready to set up"/)
    const resolved = working()
    act(() => root.unmount())
    root = createRoot(host)
    await mount(resolved, '/')
    expect(working()).toEqual(resolved)
    expect(host.textContent).not.toContain('BONREV needs your team’s review')
    expectHistory()
  })
})