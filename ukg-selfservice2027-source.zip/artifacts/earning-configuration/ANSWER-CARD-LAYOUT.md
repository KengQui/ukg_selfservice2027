# Answer-card layout check

## Continuous code follow-up sequences

`QuestionCard` owns the numbered sequence. Renderers pass numbered question
steps through `followUpSequence` and their count through `followUpSequenceCount`;
they must not pass an enclosing `FollowUpSequence` there. Payment producers
return only missing questions and answer history. The card appends their
questions using the preceding count, and keeps code summaries outside and after the
sequence. The incoming clarification-page policy is preserved: background checks
stay mounted without adding payment introductions or overtime conclusions.
`beforeFollowUps` is historical context; `followUps` is terminal
feedback, not another question group. Opening-answer panels are unchanged.

The tips renderer retains its merged ordering policy: finish setup questions
first, integrate payment questions at the existing offset, then show its
terminal summary. This composition change does not add checks or alter
readiness, question wording, answers, or saved-history rules.

### Composition audit

| Surface | Active question producers and outcome |
| --- | --- |
| How employees are paid | Option/description checks, AI/reference/shared-setup steps, tips; one card-owned sequence. Tips' integrated payment order preserved. |
| Paid time off & leave | Option cards and conditional/description steps, when applicable; same shared card path. Different codes stay separate. |
| Allowances & reimbursements | Adaptive reimbursement/CELL/MILEAGE questions; one card-owned sequence; opening and historical information kept outside it. |
| Benefits & employer contributions | Registered `ConditionalQuestionCard` for MED ER, **not** the retired `MedicalEmployerSections` path. Conditional Question 01 and payment Question 02 now share one container and heading. |
| Taxable benefits | Registered GTL conditional flow plus payment questions, and option/description paths; same sequence composition. |
| Corrections & reversals | BONREV MisclassificationCard has no independent numbered follow-up producer or payment supplement; no redesign. |
| Other codes we couldn't identify | Description-check/AI/reference/custom-name/shared-setup steps; SPPAY's payment questions continue the same sequence. |
| Optimization and Overtime | Separate cards per suggestion/screening question. Answer-review conversations stay attached to their opening answer; no repeated sequence enclosure. Standalone overtime payment-detail return view remains independent. |
| Customer replies and saved history | Editable replies use the same conditional/adaptive/options renderers without the owning review's payment supplement. Applied answers keep read-only pills; inline discussion still supplies its own opening and numbering offset. |

Legacy medical attachment/display renderers were inspected but not restored or
changed. Related questions use steps-only rendering when composed with another
producer, with an explicit offset where an employer-code question precedes
them. Loading, retry and live answer-review messages remain attached to their
questions. Clear all answers and the one card-level Defer remain in the footer.

### Focused verification

```sh
BASE_URL="https://$REPLIT_DEV_DOMAIN" \
PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH="$(which chromium)" \
pnpm --filter @workspace/earning-configuration test:code-sequences
```

Optionally set `SEQUENCE_SCREENSHOTS` to a temporary output directory. This
check covers the actual initial MED ER and GTL routes, open and answered
Question 01/02 states, one heading/container, rail alignment, unbroken
numbering, keyboard edits/clear and reload at 1440, 390 and 320px. It uses
isolated browser storage and a deterministic payment-fact API response.

`codeSequenceComposition.spec.tsx` covers MED ER, GTL and SPPAY composition,
branch changes, payment answer pills, clearing/focus, deferral, retry, terminal
summary ordering, reload parsing and editable replies. The conditional-only
benefits suite isolates the payment supplement; the composition suite uses
the real payment renderer.

The focused benefit/conditional/payment/tips/current-optimization suites pass.
The existing `test:answer-card-layout` stops at its retired OTPREM card
locator; it no longer matches the current first review page. The older
guided-review, answer-review, clearing, related-question and legacy CELL
checks also have failures reproduced against the unchanged preceding
commit. Those unrelated fixtures are not repaired by this layout correction.

Run against the managed Earning Configuration development server:

```sh
BASE_URL="https://$REPLIT_DEV_DOMAIN" \
PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH="$(which chromium)" \
pnpm --filter @workspace/earning-configuration test:answer-card-layout
```

The check uses the existing Playwright dependency in Ready DLS Kit. It creates
isolated browser contexts and seeds sample sessions through the real reducer and
storage functions; it does not alter a user's saved progress or call AI.
Set `ANSWER_CARD_SCREENSHOTS` to an output directory to save viewport captures.

## Measured bounds

Measurements from October 7, 2026, with a 900px-high browser viewport.
Coordinates are CSS pixels. TIPS and neighboring OTPREM, OTMFG and OTSVC
Misclassified-style shells have identical bounds.

| Viewport | Shell left–right | Answer area left–right | TIPS answer width before → after | Example-bearing answer width |
| --- | --- | --- | --- | --- |
| 1440 | 464–1296 | 512–1248 | 450 → 736 | 736 |
| 390 | 24–366 | 40–350 | 310 → 310 | 310 |
| 320 | 24–296 | 40–280 | 240 → 240 | 240 |

Before the correction, Something else was also capped at 450px on desktop.
It now fills the answer area, including its inner selectable card. TIPS's outer
shell, heading inset, response padding/margins and sequence rail are unchanged.
Special Pay (SPPAY) also aligns with these outer edges: within the shared review
column, its question-first wrapper no longer centers a narrower 680px card.
Its internal presentation remains distinct, and standalone cards retain their
existing width limit. The check compares every card on the page, not only TIPS
and the overtime cards.

## Coverage

- Plain, description-bearing, example-bearing and expandable answers fill their
  own containers; nested radios fill the inside of expandable panels.
- TIPS pool and multiple-method paths, reported-tips confirmation, editing an
  earlier answer, Clear all answers, Defer, Space and arrow-key selection.
- Something else selected/unselected, long description, empty/filled Done state,
  refresh and saved reentry in a new tab.
- Follow-up box bounds and original rail indentation.
- Optimize codes and overtime, including expanded Something else panels.
- No horizontal page overflow or clipped text/radios/description controls at
  desktop, 390px and 320px widths.

## Outer-card alignment verification

A focused geometry check confirmed identical outer edges for all five cards,
including SPPAY and TIPS, at 1440px, 390px and 320px, with no horizontal overflow
or browser errors. The broader interaction run reached the new desktop alignment
assertions but stopped during a page reload while the review was still loading.
Its UI-state timeout now allows 30 seconds rather than five; the complete
interaction run has not been repeated after that test-only adjustment.

## Earlier answer-width verification

The browser check passed at all three widths, with no page errors or unintended
earnings API calls. The app typecheck and build pass.

The latest shared app intentionally omits demo register descriptions, following
the confirmed source-data requirement. Its updated questions and consumers are
preserved unchanged. This layout change does not modify source data or its
presentation. Optimization assertions allow the actual register-source disclosure
while still rejecting additional, unintended disclosures; the BONUS CSV assertion
now preserves the empty source description instead of inventing one.

Across ten related unit suites, 130 tests pass and three fail. The remaining
three failures were reproduced in an isolated export of the preceding committed
app, confirming they are outside this correction:

- `businessTopics.spec.tsx`: the sample topic walk supplies an uploaded-file
  fixture, so Ask Bryte returns uploaded-register facts instead of `category`.
- `sampleUpload.spec.tsx`: the upload-capacity test expects five files before the
  asynchronous upload finishes; the completed-summary test expects seven stepper
  items where six are rendered.

All TIPS, Something else, optimization/overtime interaction and Clear all answers
tests pass. The sample source/CSV/preview assertions pass. The alignment change
does not alter runtime decisions, prompts, navigation, stored answers or wording.
