/**
 * Company Setup — Manual entry
 *
 * /to-ready build of company-setup/design/company-setup-manual.html — the
 * "no document uploaded" state. See CompanySetupForm.tsx (in
 * ../_shared-company-setup/) for the component notes, drift flags, and
 * fidelity buckets; this file is a thin route wrapper.
 */
import SelfServiceShell from '../../templates/selfservice-shell/SelfServiceShell'
import CompanySetupForm from '../_shared-company-setup/CompanySetupForm'
import VersionSwitcher, { buildCompanySetupSwitcherLinks } from '../_shared/versionSwitcher'

export const meta = {
  id:          'company-setup-manual',
  title:       'Company Setup — Manual entry',
  route:       'company-setup-manual',
  section:     'prototype',
  area:        'Company Setup',
  description: 'Business details form with progressive-disclosure EIN question and suggest-and-pick NAICS code — no document uploaded.',
  status:      'wip',
} as const

export default function CompanySetupManual() {
  return (
    <SelfServiceShell title="Company Setup" breadcrumbs={['Global Setup', 'Company Setup']} hideNav hideTabs>
      <CompanySetupForm variant="manual" />
      <VersionSwitcher links={buildCompanySetupSwitcherLinks('manual')} />
    </SelfServiceShell>
  )
}
