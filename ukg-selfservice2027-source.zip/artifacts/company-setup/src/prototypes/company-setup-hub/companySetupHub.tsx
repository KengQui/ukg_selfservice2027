/**
 * Company Setup — Hub screen
 *
 * The very first screen in the Company Setup flow — sits before
 * ../company-setup-intro/. Follows the "What should we set up first?" screen
 * ("08 Where to start", Feature grid style) of the uploaded onboarding
 * prototype: a heading, a grid of numbered setup cards with an "Also called"
 * and time-estimate footer, a recommended-first tag, and a closing note on a
 * gray page. It takes the reference's layout and copy but the kit's own
 * components, type and colors (no Volte Rounded load, prototype colors or
 * hover lift).
 *
 * Fidelity buckets:
 *   PRODUCTION  — Card (clickable: whole-card target, hover, pressed and focus
 *                 states), Tag and Progress from @ready/dls; kit type classes
 *                 and tokens.
 *   STUBBED     — pay schedule and hours confirmation have no destination yet:
 *                 their cards look and focus like the others but do nothing,
 *                 with demo progress of 35% for pay schedule and Not started
 *                 for hours. The time estimates are rough
 *                 placeholders.
 *   SCAFFOLDING — the number tile (replaces the theme StyledIcon, same tint),
 *                 the responsive card grid, the Tag's position over the first
 *                 card's top edge, and the status's place beside the number
 *                 tile (see companySetupHub.css).
 *
 * Copy, estimates, the recommended flag and each card's destination all live
 * in SETUP_ITEMS below, so they can change without touching the layout. Each
 * card's status comes from the route (index.tsx), which reads what the card's
 * destination keeps; this component only shows it.
 */
import { Card, Icon, Progress } from '@ready/dls'
import type {
  SetupItemId, SetupItemStatus,
} from '@workspace/setup-shared/prototypes/_shared-company-setup/setupProgress'
import './companySetupHub.css'

// ── Props ─────────────────────────────────────────────────────────────────────

export interface CompanySetupHubProps {
  /** ENG: wire to routing — advance into the company-setup-intro flow. */
  onGoToCompanySetup?: () => void
  /** Opens the collaborator invitation draft. */
  onInviteHelp?: () => void
  /** ENG: wire to routing once a pay-schedule screen exists. */
  onSetPaySchedule?: () => void
  /** Opens the earning and deduction codes introduction. */
  onConfirmPay?: () => void
  /** ENG: wire to routing once an hours/attestation confirmation screen exists. */
  onConfirmHours?: () => void
  /** Opens the existing system theme setup wizard. */
  onSetUpTheme?: () => void
  /** Each card's status, read from what its destination keeps. A card without one shows Not started. */
  progress?: Partial<Record<SetupItemId, SetupItemStatus>>
}

// ── Card content ──────────────────────────────────────────────────────────────

interface SetupItem {
  /** Which status this card shows. */
  id: SetupItemId
  number: string
  name: string
  description: string
  /** The product's own term for this area, shown as "Also called …". Omit when there is none. */
  alsoCalled?: string
  /** Rough placeholder estimate. */
  estimate: string
  /** Carries the "Best first step" tag. */
  recommended?: boolean
  /** The prop that opens this item's destination. */
  action: Exclude<keyof CompanySetupHubProps, 'progress'>
}

/** Kit Tag guidance: 20 characters or fewer (the reference says "Best first step for you"). */
const RECOMMENDED_LABEL = 'Best first step'
const NOT_STARTED_LABEL = 'Not started'
const DONE_LABEL = 'Done'
const NOT_STARTED: SetupItemStatus = { started: false }

const SETUP_ITEMS: readonly SetupItem[] = [
  {
    id: 'company',
    number: '01',
    name: 'Set up your company',
    description: 'The name, address, and tax ID your payroll is filed under.',
    estimate: '~10 min',
    recommended: true,
    action: 'onGoToCompanySetup',
  },
  {
    id: 'branding',
    number: '02',
    name: 'Bring your brand to work',
    description: 'Your logo and colors, so every screen feels like your company.',
    alsoCalled: 'system theme',
    estimate: '~5 min',
    action: 'onSetUpTheme',
  },
  {
    id: 'invite',
    number: '03',
    name: 'Invite others to help',
    description: 'Bring in a co-worker, bookkeeper, or accountant to help finish setup.',
    estimate: '~2 min',
    action: 'onInviteHelp',
  },
  {
    id: 'paySchedule',
    number: '04',
    name: 'Set your pay schedule',
    description: 'How often you pay people and your next payday, so pay goes out on time.',
    alsoCalled: 'pay period profiles',
    estimate: '~5 min',
    // ENG: no destination screen built yet
    action: 'onSetPaySchedule',
  },
  {
    id: 'pay',
    number: '05',
    name: 'Confirm how your people get paid',
    description: 'Check the pay types and deductions we’ve set up, so paychecks come out right.',
    alsoCalled: 'earning and deduction codes',
    estimate: '~15 min',
    action: 'onConfirmPay',
  },
  {
    id: 'hours',
    number: '06',
    name: 'Confirm hours before payday',
    description: 'Check everyone’s hours are right before you run payroll.',
    alsoCalled: 'attestation',
    estimate: '~5 min',
    // ENG: no destination screen built yet
    action: 'onConfirmHours',
  },
]

// ── Status ────────────────────────────────────────────────────────────────────

/** The status in words, read as part of the card's name. */
function statusText(status: SetupItemStatus): string {
  return status.started ? status.percent === 100 ? DONE_LABEL : `${status.percent}% done` : NOT_STARTED_LABEL
}

/**
 * Not started, Done, or the kit's small bar with its percentage. Hidden from screen readers, which read statusText as part of
 * the card's name instead, so the bar is never announced as a separate, unlabeled "Progress".
 */
function SetupStatus({ status }: { status: SetupItemStatus }) {
  const done = status.started && status.percent === 100
  return (
    <div
      className="c-company-setup-hub__status"
      aria-hidden="true"
    >
      {done
        ? <span className="c-company-setup-hub__done"><Icon name="tick" size={12} />{DONE_LABEL}</span>
        : status.started
        ? <Progress value={status.percent} size="small" />
        : <span className="c-company-setup-hub__not-started">{NOT_STARTED_LABEL}</span>}
    </div>
  )
}

// ── Component ─────────────────────────────────────────────────────────────────

export default function CompanySetupHub(props: CompanySetupHubProps) {
  return (
    <div className="c-company-setup-hub">
      <div className="c-company-setup-hub__inner">
        <div className="c-company-setup-hub__intro">
          <h1 className="text-display c-company-setup-hub__title">What should we set up first?</h1>
          <p className="text-body c-company-setup-hub__muted c-company-setup-hub__subtitle">
            Pick one. It takes about ten minutes, and you can come back for the rest any time.
          </p>
        </div>

        {/* role="list" keeps list semantics in Safari, which drops them for unstyled lists. */}
        <ul className="c-company-setup-hub__grid" role="list">
          {SETUP_ITEMS.map((item) => {
            const status = props.progress?.[item.id] ?? NOT_STARTED
            return (
              <li key={item.number} className="c-company-setup-hub__item">
                <Card
                  className="c-company-setup-hub__card"
                  // Always clickable, so the cards without a destination keep the
                  // same look and keyboard focus and simply do nothing, as before.
                  onClick={() => props[item.action]?.()}
                  footer={
                    <div className="c-company-setup-hub__footer">
                      {item.alsoCalled && (
                        <span className="text-caption c-company-setup-hub__also">Also called {item.alsoCalled}</span>
                      )}
                      <span className="c-company-setup-hub__estimate">{item.estimate}</span>
                    </div>
                  }
                >
                  {item.recommended && (
                    <span className="c-company-setup-hub__tag">{RECOMMENDED_LABEL}</span>
                  )}
                  <div className="c-company-setup-hub__card-body">
                    <div className="c-company-setup-hub__top">
                      {/* The list already announces each card's position. */}
                      <span className="c-company-setup-hub__number" aria-hidden="true">{item.number}</span>
                      <SetupStatus status={status} />
                    </div>
                    <h2 className="text-heading-md c-company-setup-hub__name">{item.name}</h2>
                    <span className="c-company-setup-hub__status-text">{statusText(status)}</span>
                    <p className="text-body c-company-setup-hub__muted c-company-setup-hub__description">
                      {item.description}
                    </p>
                  </div>
                </Card>
              </li>
            )
          })}
        </ul>

        <p className="text-body c-company-setup-hub__muted c-company-setup-hub__note">
          You only set up one thing at a time. The rest stays here, waiting, whenever you want it.
        </p>
      </div>
    </div>
  )
}
