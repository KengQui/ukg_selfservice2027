import { describe, expect, test } from 'vitest'
import {
  COMPANY_ANSWER_COUNT, NOT_STARTED, SETUP_ITEM_IDS, readSetupProgress, shareStatus, type SetupStores,
} from '@workspace/setup-shared/prototypes/_shared-company-setup/setupProgress'
import {
  companySetupDraftKey, companySetupSavedKey, type CompanySetupState,
} from '@workspace/setup-shared/prototypes/_shared-company-setup/useCompanySetupState'
import { invitationDraftKey } from '@workspace/setup-shared/prototypes/_shared-company-setup/invitationDraft'
import { brandingStorageKeys, DEMO_SCENARIOS, type DemoScenario } from '@workspace/setup-shared/prototypes/branding-demo/demoScenarios'
import { singleStepShownKey } from '@workspace/setup-shared/prototypes/branding-demo/brandingProgress'
import {
  INVITE_TEAM_SAVED_COPY_KEY, INVITE_TEAM_WORKING_COPY_KEY,
} from '@workspace/setup-shared/prototypes/_shared-invite-team/inviteTeamProgress'
import {
  EARNING_SAVED_COPY_KEY, EARNING_STEPS, EARNING_WORKING_COPY_KEY, type EarningStep,
} from '@workspace/setup-shared/prototypes/_shared-earning-configuration/sessionFormat'

type MemoryStorage = Pick<Storage, 'getItem'> & { set: (key: string, value: string) => void }

function memory(): MemoryStorage {
  const values = new Map<string, string>()
  return { getItem: key => values.get(key) ?? null, set: (key, value) => { values.set(key, value) } }
}

function stores() {
  const session = memory()
  const local = memory()
  return { session, local, read: (scenario: DemoScenario | null = null) => readSetupProgress(scenario, { session, local }) }
}

const scenarios = Object.keys(DEMO_SCENARIOS) as DemoScenario[]
const started = (percent: number) => ({ started: true, percent })

const allAnswers: Partial<CompanySetupState> = {
  legalName: 'Bright Harbor Bakery LLC', address: '4820 Sycamore Ave', city: 'Madison', state: 'WI', zip: '53718',
  taxId: '39-1234567', naicsCode: '311811', payrollVendor: 'ADP',
}

function inviteTeamDraft(screen: string, overrides: Record<string, unknown> = {}) {
  const invitee = { id: 'p1', firstName: 'Maria', lastName: 'Lopez', email: 'maria@example.com', jobs: ['payroll'], match: { profileKey: 'payroll' } }
  return JSON.stringify({ version: 2, screen, invitees: [invitee], sent: [], failed: [], reviewOrigins: [], resentTo: null, ...overrides })
}

function earningSession(step: EarningStep | 'completed', updatedAt = 1) {
  return JSON.stringify({ version: 3, step, files: [], rounds: [], customerQuestions: [], answers: {}, resolutions: {}, updatedAt })
}

describe('shareStatus', () => {
  test('rounds to a whole percentage', () => {
    expect(shareStatus(0.4)).toEqual(started(40))
    expect(shareStatus(1 / 8)).toEqual(started(13))
    expect(shareStatus(3 / 8)).toEqual(started(38))
    expect(shareStatus(7 / 8)).toEqual(started(88))
    expect(shareStatus(1 / 13)).toEqual(started(8))
    expect(shareStatus(12 / 13)).toEqual(started(92))
    expect(shareStatus(0.5 / 3)).toEqual(started(17))
  })

  test('a started item never shows 0%, and an unfinished one never shows 100%', () => {
    expect(shareStatus(0.001)).toEqual(started(1))
    expect(shareStatus(0.999)).toEqual(started(99))
    expect(shareStatus(1)).toEqual(started(100))
    expect(shareStatus(1.2)).toEqual(started(100))
  })

  test('nothing done is not started', () => {
    for (const share of [0, -0.5, Number.NaN]) expect(shareStatus(share)).toEqual(NOT_STARTED)
  })
})

describe('readSetupProgress', () => {
  test('on a first visit only pay schedule and returning branding have progress', () => {
    for (const scenario of [null, ...scenarios]) {
      const progress = stores().read(scenario)
      expect(Object.keys(progress)).toEqual([...SETUP_ITEM_IDS])
      for (const id of SETUP_ITEM_IDS) {
        if (id === 'branding' && scenario?.startsWith('returning')) continue
        expect(progress[id], `${scenario} ${id}`).toEqual(id === 'paySchedule' ? started(35) : NOT_STARTED)
      }
    }
  })

  describe('Set up your company', () => {
    test('counts each of the eight answers once', () => {
      expect(COMPANY_ANSWER_COUNT).toBe(8)
      for (const [field, value] of Object.entries(allAnswers)) {
        const { local, read } = stores()
        local.set(companySetupSavedKey('manual'), JSON.stringify({ [field]: value }))
        expect(read().company, field).toEqual(started(13))
      }
      const { local, read } = stores()
      local.set(companySetupSavedKey('manual'), JSON.stringify(allAnswers))
      expect(read().company).toEqual(started(100))
      local.set(companySetupSavedKey('manual'), JSON.stringify({ ...allAnswers, payrollVendor: null }))
      expect(read().company).toEqual(started(88))
    })

    test('counts the EIN answer for a tax ID, applied or none, but not before it is answered', () => {
      const cases: [Partial<CompanySetupState>, boolean][] = [
        [{ taxId: '39-1234567' }, true],
        [{ einStatus: 'applied' }, true],
        [{ einStatus: 'none' }, true],
        [{ einStatus: 'has' }, false],
        [{ einStatus: 'has', taxId: '  ' }, false],
      ]
      for (const [answer, counts] of cases) {
        const { local, read } = stores()
        local.set(companySetupSavedKey('manual'), JSON.stringify({ legalName: 'Acme', ...answer }))
        expect(read().company, JSON.stringify(answer)).toEqual(started(counts ? 25 : 13))
      }
    })

    test('ignores the optional business description and blank answers', () => {
      const { local, read } = stores()
      local.set(companySetupSavedKey('manual'), JSON.stringify({ bizDescription: 'We bake bread', legalName: '   ', city: '' }))
      expect(read().company).toEqual(NOT_STARTED)
    })

    test('reads the record the steps would reopen: the more recently changed of manual entry and from-document', () => {
      const { session, local, read } = stores()
      local.set(companySetupSavedKey('manual'), JSON.stringify({ ...allAnswers, updatedAt: 10 }))
      session.set(companySetupDraftKey('from-doc'), JSON.stringify({ legalName: 'Doc Co', updatedAt: 20 }))
      expect(read().company).toEqual(started(13))
      session.set(companySetupDraftKey('manual'), JSON.stringify({ legalName: 'A', city: 'B', updatedAt: 30 }))
      expect(read().company).toEqual(started(25))
      // Manual entry wins a tie.
      session.set(companySetupDraftKey('from-doc'), JSON.stringify({ ...allAnswers, updatedAt: 30 }))
      expect(read().company).toEqual(started(25))
    })

    test('reads the same in every demo scenario', () => {
      const { local, read } = stores()
      local.set(companySetupSavedKey('from-doc'), JSON.stringify({ legalName: 'Doc Co', zip: '53718', taxId: '39-1234567' }))
      for (const scenario of [null, ...scenarios]) expect(read(scenario).company, String(scenario)).toEqual(started(38))
    })
  })

  describe('Bring your brand to work', () => {
    test('outside a demo: kept branding is half done and a confirmed save is done', () => {
      const { local, read } = stores()
      const keys = brandingStorageKeys(null)
      local.set(keys.single, JSON.stringify({ primaryColor: '#123456' }))
      expect(read().branding).toEqual(started(50))
      local.set(keys.singleConfirmed, '1')
      expect(read().branding).toEqual(started(100))
    })

    test('single-EIN demos ignore the prepared starting data until a wizard step has been shown', () => {
      for (const scenario of ['new-single'] as const) {
        const { local, read } = stores()
        local.set(brandingStorageKeys(scenario).single, JSON.stringify({ primaryColor: '#123456' }))
        expect(read(scenario).branding, scenario).toEqual(NOT_STARTED)
        local.set(singleStepShownKey(scenario), '1')
        expect(read(scenario).branding, scenario).toEqual(started(50))
        expect(read(null).branding).toEqual(NOT_STARTED)
      }
    })

    test('returning scenarios show their prepared progress before Branding has been opened in them', () => {
      const { read } = stores()
      expect(read('returning-single').branding).toEqual(started(100))
      expect(read('returning-multi').branding).toEqual(started(50))
    })

    test('multi-EIN demos count the three demo companies, in process as half', () => {
      const { local, read } = stores()
      local.set(brandingStorageKeys('new-multi').companies, JSON.stringify({
        version: 2, themes: { 'acme-holdings': {} }, savedIds: ['acme-holdings'], drafts: { 'acme-services': {} },
        editDrafts: { 'acme-holdings': {} },
      }))
      expect(read('new-multi').branding).toEqual(started(50))
      expect(read('returning-multi').branding).toEqual(started(50))
      local.set(brandingStorageKeys('returning-multi').companies, JSON.stringify({
        version: 2, themes: {}, savedIds: [], drafts: { 'acme-retail': {} },
      }))
      expect(read('returning-multi').branding).toEqual(started(17))
      local.set(brandingStorageKeys('new-multi').companies, '{broken')
      expect(read('new-multi').branding).toEqual(NOT_STARTED)
    })
  })

  describe('Invite others to help', () => {
    test('is done once an invitation is saved, in that scenario only', () => {
      for (const scenario of [null, ...scenarios]) {
        const { local, read } = stores()
        local.set(invitationDraftKey(scenario), JSON.stringify({ email: 'partner@example.org', savedAt: 1 }))
        for (const other of [null, ...scenarios]) {
          expect(read(other).invite, `${scenario} → ${other}`).toEqual(other === scenario ? started(100) : NOT_STARTED)
        }
      }
    })

    test('outside a demo, reads the draft of the company being set up', () => {
      const { session, local, read } = stores()
      session.set(companySetupDraftKey('manual'), JSON.stringify({ taxId: '39-1234567', updatedAt: 1 }))
      const setupStores: SetupStores = { session, local }
      local.set(invitationDraftKey(null, setupStores), JSON.stringify({ email: 'partner@example.org', savedAt: 1 }))
      expect(read().invite).toEqual(started(100))
      session.set(companySetupDraftKey('manual'), JSON.stringify({ taxId: '98-7654321', updatedAt: 2 }))
      expect(read().invite).toEqual(NOT_STARTED)
    })

    test('shows Invite team members work saved to finish later as in progress, and its results as done', () => {
      const expected: Record<string, ReturnType<typeof started> | typeof NOT_STARTED> = {
        intro: NOT_STARTED, addPeople: started(33), reviewAccess: started(67), invitesSent: started(100),
      }
      for (const [screen, status] of Object.entries(expected)) {
        const { local, read } = stores()
        local.set(INVITE_TEAM_SAVED_COPY_KEY, inviteTeamDraft(screen))
        for (const scenario of [null, ...scenarios]) expect(read(scenario).invite, `${screen} ${scenario}`).toEqual(status)
      }
    })

    test('reads the copy Invite team members would reopen in this tab', () => {
      const { session, local, read } = stores()
      local.set(INVITE_TEAM_SAVED_COPY_KEY, inviteTeamDraft('addPeople'))
      session.set(INVITE_TEAM_WORKING_COPY_KEY, inviteTeamDraft('invitesSent'))
      expect(read().invite).toEqual(started(100))
      // After Start over, the app keeps only a fresh intro and removes the kept copy.
      session.set(INVITE_TEAM_WORKING_COPY_KEY, inviteTeamDraft('intro'))
      expect(read().invite).toEqual(NOT_STARTED)
      // A review whose people have no suggested access yet reopens at Add people.
      session.set(INVITE_TEAM_WORKING_COPY_KEY, '')
      local.set(INVITE_TEAM_SAVED_COPY_KEY, inviteTeamDraft('reviewAccess', {
        invitees: [{ id: 'p1', firstName: 'Maria', lastName: 'Lopez', email: 'maria@example.com', jobs: ['payroll'], match: null }],
      }))
      expect(read().invite).toEqual(started(33))
    })

    test('an unreadable Invite team members draft is not started', () => {
      for (const raw of ['{broken', inviteTeamDraft('summary'), inviteTeamDraft('addPeople', { version: 9 }), inviteTeamDraft('addPeople', { invitees: [] })]) {
        const { local, read } = stores()
        local.set(INVITE_TEAM_SAVED_COPY_KEY, raw)
        expect(read().invite, raw).toEqual(NOT_STARTED)
      }
    })

    test('an invitation saved on the invite step counts as done even while Invite team members is in progress', () => {
      const { local, read } = stores()
      local.set(INVITE_TEAM_SAVED_COPY_KEY, inviteTeamDraft('addPeople'))
      local.set(invitationDraftKey('new-single'), JSON.stringify({ email: 'partner@example.org', savedAt: 1 }))
      expect(read('new-single').invite).toEqual(started(100))
      expect(read(null).invite).toEqual(started(33))
    })

    test('an unreadable draft is not an invitation', () => {
      for (const raw of ['{broken', JSON.stringify({ email: 'not an email', savedAt: 1 }), JSON.stringify({ email: 'a@b.co' })]) {
        const { local, read } = stores()
        local.set(invitationDraftKey(null), raw)
        expect(read().invite, raw).toEqual(NOT_STARTED)
      }
    })
  })

  describe('Confirm how your people get paid', () => {
    test('follows Earning Configuration\'s step order, from not started at the intro to done at the summary', () => {
      expect(EARNING_STEPS).toHaveLength(13)
      const expected: Partial<Record<EarningStep, number>> = {
        upload: 9, analysis: 18, review: 55, optimization: 64, overtime: 82, overtimeSort: 91, summary: 100,
      }
      for (const [step, percent] of Object.entries(expected)) {
        const { session, read } = stores()
        session.set(EARNING_WORKING_COPY_KEY, earningSession(step as EarningStep))
        expect(read().pay, step).toEqual(started(percent))
      }
      const { session, read } = stores()
      session.set(EARNING_WORKING_COPY_KEY, earningSession('intro'))
      expect(read().pay).toEqual(NOT_STARTED)
      session.set(EARNING_WORKING_COPY_KEY, earningSession('categorySelection'))
      expect(read().pay).toEqual(NOT_STARTED)
    })

    test('keeps earnings status when visiting payroll choices or a deduction/tax information page', () => {
      const { session, read } = stores()
      session.set(EARNING_WORKING_COPY_KEY, earningSession('results'))
      expect(read().pay).toEqual(started(27))
      for (const step of ['categorySelection', 'intro'] as const) {
        session.set(EARNING_WORKING_COPY_KEY, JSON.stringify({
          version: 3, step, lastEarningStep: 'results', selectedCategory: 'taxes',
          files: [], rounds: [], customerQuestions: [], answers: {}, resolutions: {}, updatedAt: 2,
        }))
        expect(read().pay).toEqual(started(27))
      }
      session.set(EARNING_WORKING_COPY_KEY, JSON.stringify({
        version: 3, step: 'categorySelection', lastEarningStep: 'no-such-step',
        files: [], rounds: [], customerQuestions: [], answers: {}, resolutions: {}, updatedAt: 3,
      }))
      expect(read().pay).toEqual(NOT_STARTED)
    })

    test('reads the copy Earning Configuration would resume', () => {
      const { session, local, read } = stores()
      session.set(EARNING_WORKING_COPY_KEY, earningSession('upload', 10))
      local.set(EARNING_SAVED_COPY_KEY, earningSession('completed', 20))
      expect(read().pay).toEqual(started(64))
      session.set(EARNING_WORKING_COPY_KEY, earningSession('upload', 20))
      expect(read().pay).toEqual(started(9))
      // After Restart demo, Earning Configuration keeps only a fresh intro.
      session.set(EARNING_WORKING_COPY_KEY, earningSession('intro', 30))
      local.set(EARNING_SAVED_COPY_KEY, '')
      expect(read().pay).toEqual(NOT_STARTED)
    })

    test('counts the retired optimization completion as overtime, including remembered earnings progress', () => {
      for (const step of ['optimizationCompleted', 'intro', 'categorySelection']) {
        const { session, local, read } = stores()
        const kept = JSON.stringify({
          ...JSON.parse(earningSession('overtime')), version: 5, step,
          lastEarningStep: 'optimizationCompleted', optimization: { answers: {}, submitted: true, completed: true },
        })
        local.set(EARNING_SAVED_COPY_KEY, kept)
        expect(read().pay).toEqual(started(82))
        session.set(EARNING_WORKING_COPY_KEY, kept)
        expect(read().pay).toEqual(started(82))
      }
    })

    test('ignores unreadable copies and reads the same in every demo scenario', () => {
      const { session, local, read } = stores()
      local.set(EARNING_SAVED_COPY_KEY, earningSession('results'))
      session.set(EARNING_WORKING_COPY_KEY, '{broken')
      for (const scenario of [null, ...scenarios]) expect(read(scenario).pay, String(scenario)).toEqual(started(27))
      local.set(EARNING_SAVED_COPY_KEY, JSON.stringify({ version: 1, step: 'summary', files: [], rounds: [], customerQuestions: [], answers: {}, resolutions: {}, updatedAt: 1 }))
      expect(read().pay).toEqual(NOT_STARTED)
    })

    test('counts old earning introductions as upload, including progress remembered on payroll choices', () => {
      const { session, local, read } = stores()
      local.set(EARNING_SAVED_COPY_KEY, earningSession('completed', 1))
      session.set(EARNING_WORKING_COPY_KEY, JSON.stringify({
        version: 3, step: 'earningIntro', files: [], rounds: [], customerQuestions: [],
        answers: {}, resolutions: {}, updatedAt: 2,
      }))
      expect(read().pay).toEqual(started(9))
      for (const step of ['intro', 'categorySelection']) {
        session.set(EARNING_WORKING_COPY_KEY, JSON.stringify({
          version: 3, step, lastEarningStep: 'earningIntro', files: [], rounds: [], customerQuestions: [],
          answers: {}, resolutions: {}, updatedAt: 3,
        }))
        expect(read().pay).toEqual(started(9))
      }
    })
  })

  test('pay schedule is always a 35% demo and hours is always not started', () => {
    const { session, local, read } = stores()
    local.set(companySetupSavedKey('manual'), JSON.stringify(allAnswers))
    session.set(EARNING_WORKING_COPY_KEY, earningSession('summary'))
    for (const scenario of [null, ...scenarios]) {
      expect(read(scenario).paySchedule).toEqual(started(35))
      expect(read(scenario).hours).toEqual(NOT_STARTED)
    }
  })

  test('a browser that refuses storage keeps the pay schedule demo instead of breaking the hub', () => {
    const refusing = { getItem: () => { throw new Error('Storage disabled') } }
    for (const scenario of [null, ...scenarios]) {
      const progress = readSetupProgress(scenario, { session: refusing, local: refusing })
      for (const id of SETUP_ITEM_IDS) {
        if (id === 'branding' && scenario?.startsWith('returning')) continue
        expect(progress[id], `${scenario} ${id}`).toEqual(id === 'paySchedule' ? started(35) : NOT_STARTED)
      }
    }
  })
})
