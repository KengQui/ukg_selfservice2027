import { afterEach, beforeEach, describe, expect, test, vi } from 'vitest'
import '@testing-library/jest-dom/vitest'
import { act, cleanup, render, screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes, useNavigate } from 'react-router-dom'
import { companySetupSavedKey } from '@workspace/setup-shared/prototypes/_shared-company-setup/useCompanySetupState'
import { invitationDraftKey } from '@workspace/setup-shared/prototypes/_shared-company-setup/invitationDraft'
import { brandingStorageKeys } from '@workspace/setup-shared/prototypes/branding-demo/demoScenarios'
import { EARNING_SAVED_COPY_KEY } from '@workspace/setup-shared/prototypes/_shared-earning-configuration/sessionFormat'
import CompanySetupHub from '../companySetupHub'
import CompanySetupHubPage from '../index'

vi.mock('../../../templates/selfservice-shell/SelfServiceShell', () => ({
  default: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
}))

beforeEach(() => { localStorage.clear(); sessionStorage.clear() })
afterEach(() => { cleanup(); vi.restoreAllMocks() })

const CARD_NAMES = [
  'Set up your company', 'Bring your brand to work', 'Invite others to help',
  'Set your pay schedule', 'Confirm how your people get paid', 'Confirm hours before payday',
]

/** What each card shows in its top-right corner, in card order. */
function shownStatuses() {
  return Array.from(document.querySelectorAll('.c-company-setup-hub__status'), status => status.textContent?.trim())
}

/** The clickable card whose heading is `name`. */
function card(name: string) {
  return screen.getByRole('heading', { name }).closest<HTMLElement>('[role="button"]')!
}

/** Stands in for a destination: it keeps an invitation, then leaves by a link or the browser's Back button. */
function InviteStub() {
  const navigate = useNavigate()
  const keep = () => localStorage.setItem(invitationDraftKey(null), JSON.stringify({ email: 'partner@example.org', savedAt: 1 }))
  return (
    <>
      <button type="button" onClick={() => { keep(); navigate('/prototypes/company-setup-hub') }}>Back link</button>
      <button type="button" onClick={() => { keep(); navigate(-1) }}>Browser back</button>
    </>
  )
}

function openHub(search = '') {
  return render(
    <MemoryRouter initialEntries={[`/prototypes/company-setup-hub${search}`]}>
      <Routes>
        <Route path="/prototypes/company-setup-hub" element={<CompanySetupHubPage />} />
        <Route path="/prototypes/company-setup-invite" element={<InviteStub />} />
      </Routes>
    </MemoryRouter>,
  )
}

describe('CompanySetupHub', () => {
  test('on a first visit only pay schedule shows a bar, with each status in its name', () => {
    openHub()
    expect(shownStatuses()).toEqual(['Not started', 'Not started', 'Not started', '35%', 'Not started', 'Not started'])
    for (const name of CARD_NAMES) {
      const paySchedule = name === 'Set your pay schedule'
      expect(card(name)).toHaveAccessibleName(expect.stringContaining(`${name} ${paySchedule ? '35% done' : 'Not started'}`))
      expect(within(card(name)).queryAllByRole('progressbar', { hidden: true })).toHaveLength(paySchedule ? 1 : 0)
    }
    expect(screen.getAllByText('Best first step')).toHaveLength(1)
    expect(within(card('Set up your company')).getByText('Best first step')).toBeInTheDocument()
  })

  test('shows a started item as a bar with its percentage, named as done so far', () => {
    render(<CompanySetupHub progress={{ company: { started: true, percent: 40 }, pay: { started: true, percent: 100 } }} />)
    const company = card('Set up your company')
    expect(company).toHaveAccessibleName(expect.stringContaining('Set up your company 40% done'))
    expect(within(company).getByText('40%')).toBeInTheDocument()
    expect(within(company).queryByText('Not started')).not.toBeInTheDocument()
    // The bar is not announced as a separate, unlabeled control; the card's name carries the status.
    expect(within(company).queryByRole('progressbar')).not.toBeInTheDocument()
    expect(within(company).getByRole('progressbar', { hidden: true })).toHaveAttribute('aria-valuenow', '40')
    const finished = card('Confirm how your people get paid')
    expect(finished).toHaveAccessibleName(expect.stringContaining('Confirm how your people get paid Done'))
    expect(within(finished).queryByRole('progressbar', { hidden: true })).not.toBeInTheDocument()
    expect(within(finished).queryByText('100%')).not.toBeInTheDocument()
    expect(finished.querySelector('.c-company-setup-hub__done')).toHaveTextContent('Done')
    expect(shownStatuses()).toEqual(['40%', 'Not started', 'Not started', 'Not started', 'Done', 'Not started'])
  })

  test('reads each card\'s progress from what its destination keeps', () => {
    localStorage.setItem(companySetupSavedKey('manual'), JSON.stringify({ legalName: 'Acme', city: 'Madison', state: 'WI' }))
    localStorage.setItem(brandingStorageKeys(null).single, JSON.stringify({ primaryColor: '#123456' }))
    localStorage.setItem(EARNING_SAVED_COPY_KEY, JSON.stringify({
      version: 3, step: 'completed', files: [], rounds: [], customerQuestions: [], answers: {}, resolutions: {}, updatedAt: 1,
    }))
    // Invite team members' Save and finish later, on Review access (screen 3 of 4).
    localStorage.setItem('invite-team-members:saved:v1', JSON.stringify({
      version: 2, screen: 'reviewAccess', sent: [], failed: [], reviewOrigins: [], resentTo: null,
      invitees: [{ id: 'p1', firstName: 'Maria', lastName: 'Lopez', email: 'maria@example.com', jobs: ['payroll'], match: { profileKey: 'payroll' } }],
    }))
    openHub()
    expect(card('Set up your company')).toHaveAccessibleName(expect.stringContaining('38% done'))
    expect(card('Bring your brand to work')).toHaveAccessibleName(expect.stringContaining('50% done'))
    // Classification ends at interval 8 of 14; category selection is navigation, not progress.
    // Keep this independent of the shared reader so a progress-calculation change cannot silently pass.
    expect(card('Confirm how your people get paid')).toHaveAccessibleName(expect.stringContaining('58% done'))
    expect(card('Invite others to help')).toHaveAccessibleName(expect.stringContaining('67% done'))
    expect(card('Set your pay schedule')).toHaveAccessibleName(expect.stringContaining('35% done'))
    for (const name of ['Confirm hours before payday']) {
      expect(card(name)).toHaveAccessibleName(expect.stringContaining('Not started'))
    }
  })

  test('shows a demo scenario\'s own branding and invitation', () => {
    localStorage.setItem(invitationDraftKey('returning-multi'), JSON.stringify({ email: 'partner@example.org', savedAt: 1 }))
    openHub('?demo=returning-multi')
    expect(card('Bring your brand to work')).toHaveAccessibleName(expect.stringContaining('50% done'))
    expect(card('Invite others to help')).toHaveAccessibleName(expect.stringContaining('Done'))
  })

  test('returning single branding is Done with no bar', () => {
    openHub('?demo=returning-single')
    const branding = card('Bring your brand to work')
    expect(branding).toHaveAccessibleName(expect.stringContaining('Bring your brand to work Done'))
    expect(within(branding).queryByRole('progressbar', { hidden: true })).not.toBeInTheDocument()
    expect(within(branding).queryByText('100%')).not.toBeInTheDocument()
  })

  test('pay schedule stays at 35% after clicking its no-op card and revisiting', async () => {
    const view = openHub()
    await userEvent.click(card('Set your pay schedule'))
    expect(card('Set your pay schedule')).toHaveAccessibleName(expect.stringContaining('35% done'))
    view.unmount()
    openHub()
    expect(card('Set your pay schedule')).toHaveAccessibleName(expect.stringContaining('35% done'))
  })

  describe('when the customer comes back to the hub', () => {
    test.each(['Back link', 'Browser back'])('shows current progress after the %s without a reload', async (way) => {
      openHub()
      expect(card('Invite others to help')).toHaveAccessibleName(expect.stringContaining('Not started'))
      await userEvent.click(card('Invite others to help'))
      await userEvent.click(screen.getByRole('button', { name: way }))
      expect(card('Invite others to help')).toHaveAccessibleName(expect.stringContaining('Done'))
    })

    test('shows current progress when the browser restores the page from its back/forward cache', () => {
      openHub()
      localStorage.setItem(invitationDraftKey(null), JSON.stringify({ email: 'partner@example.org', savedAt: 1 }))
      const restored = new Event('pageshow')
      Object.defineProperty(restored, 'persisted', { value: true })
      act(() => { window.dispatchEvent(restored) })
      expect(card('Invite others to help')).toHaveAccessibleName(expect.stringContaining('Done'))
    })
  })
})
