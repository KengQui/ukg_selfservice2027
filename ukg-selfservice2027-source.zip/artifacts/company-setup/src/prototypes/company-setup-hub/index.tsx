/**
 * Company Setup — Hub
 *
 * The first screen in the Company Setup flow — "What should we set up
 * first?", a grid of numbered setup cards on a gray page under the shell's
 * breadcrumb band. See companySetupHub.tsx for the card content, component
 * notes and fidelity buckets; this file is a thin route wrapper that also reads
 * each card's progress from what its destination keeps.
 */
import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from '@workspace/setup-shared/prototypes/_shared/navigation'
import { useLocation, useNavigate as useRouterNavigate } from 'react-router-dom'
import { demoScenario } from '@workspace/setup-shared/prototypes/branding-demo/demoScenarios'
import { readSetupProgress } from '@workspace/setup-shared/prototypes/_shared-company-setup/setupProgress'
import SelfServiceShell from '../../templates/selfservice-shell/SelfServiceShell'
import CompanySetupHub from './companySetupHub'
import VersionSwitcher, { buildCompanySetupSwitcherLinks } from '../_shared/versionSwitcher'

export const meta = {
  id:          'company-setup-hub',
  title:       'Company Setup — Hub',
  route:       'company-setup-hub',
  section:     'prototype',
  area:        'Company Setup',
  description: 'Where-to-start chooser: six numbered setup cards in a grid, with the best first step tagged. Precedes the intro screen.',
  status:      'wip',
} as const

export default function CompanySetupHubPage() {
  const navigate = useNavigate()
  const routerNavigate = useRouterNavigate()
  const { search, key } = useLocation()
  const scenario = demoScenario(new URLSearchParams(search).get('demo'))
  // A page the browser restores from its back/forward cache comes back without a new route, so re-read then too.
  const [restored, setRestored] = useState(0)
  useEffect(() => {
    const onPageShow = (event: PageTransitionEvent) => { if (event.persisted) setRestored(count => count + 1) }
    window.addEventListener('pageshow', onPageShow)
    return () => window.removeEventListener('pageshow', onPageShow)
  }, [])
  // Re-read every time the hub is shown: each arrival, including the browser's Back button, is a new location.
  // eslint-disable-next-line react-hooks/exhaustive-deps -- key and restored mark each showing; the read uses neither.
  const progress = useMemo(() => readSetupProgress(scenario), [scenario, key, restored])

  return (
    <SelfServiceShell title="Company Setup" breadcrumbs={['Global Setup', 'Company Setup']} hideTitle hideNav hideTabs>
      <CompanySetupHub
        onGoToCompanySetup={() => navigate('/prototypes/company-setup-intro')}
        onInviteHelp={() => routerNavigate(`/prototypes/company-setup-invite${scenario ? `?demo=${scenario}` : ''}`)}
        onConfirmPay={() => navigate('/prototypes/earning-configuration')}
        onSetUpTheme={() => navigate('/prototypes/system-theme-setup')}
        progress={progress}
      />
      <VersionSwitcher links={buildCompanySetupSwitcherLinks('hub')} />
    </SelfServiceShell>
  )
}
