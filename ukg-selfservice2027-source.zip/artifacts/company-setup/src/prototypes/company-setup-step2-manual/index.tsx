/**
 * Company Setup — Step 2 of 2, Manual entry
 *
 * Address, EIN/Tax ID, and NAICS code. See CompanySetupStep2Form.tsx (in
 * ../_shared-company-setup/) for component notes and fidelity buckets; this
 * file is a thin route wrapper.
 */
import SelfServiceShell from '../../templates/selfservice-shell/SelfServiceShell'
import SaveDraftAction from '../_shared-company-setup/SaveDraftAction'
import { CompanySetupDraftProvider } from '../_shared-company-setup/CompanySetupDraftContext'
import CompanySetupStep2Form from '../_shared-company-setup/CompanySetupStep2Form'
import VersionSwitcher, { buildCompanySetupSwitcherLinks } from '../_shared/versionSwitcher'

export const meta = {
  id:          'company-setup-step2-manual',
  title:       'Company Setup — Step 2 of 2 (Manual entry)',
  route:       'company-setup-step2-manual',
  section:     'prototype',
  area:        'Company Setup',
  description: 'EIN/Tax ID, NAICS code, and a current payroll provider question — step 2 of the manual-entry company setup flow.',
  status:      'wip',
} as const

export default function CompanySetupStep2Manual() {
  // The draft is shared by the step form and the header's Save and finish later.
  return (
    <CompanySetupDraftProvider variant="manual">
      <SelfServiceShell title="Company Setup" backTo="/prototypes/company-setup-intro" breadcrumbs={['Global Setup', 'Company Setup']} headerActions={<SaveDraftAction />} hideNav hideTabs>
        <CompanySetupStep2Form variant="manual" step1Route="/prototypes/company-setup-step1-manual" />
        <VersionSwitcher links={buildCompanySetupSwitcherLinks('step2-manual')} />
      </SelfServiceShell>
    </CompanySetupDraftProvider>
  )
}
