import { useLocation, useNavigate } from 'react-router-dom'
import { demoScenario } from '@workspace/setup-shared/prototypes/branding-demo/demoScenarios'
import SelfServiceShell from '../../templates/selfservice-shell/SelfServiceShell'
import CompanySetupInvite from './companySetupInvite'

export default function CompanySetupInvitePage() {
  const { search } = useLocation()
  const navigate = useNavigate()
  const scenario = demoScenario(new URLSearchParams(search).get('demo'))
  const hub = `/prototypes/company-setup-hub${scenario ? `?demo=${scenario}` : ''}`

  return (
    <SelfServiceShell title="Company Setup" backTo={hub} breadcrumbs={['Global Setup', 'Company Setup']} hideNav hideTabs>
      <CompanySetupInvite key={scenario ?? 'ordinary'} scenario={scenario} onReturn={() => navigate(hub)} />
    </SelfServiceShell>
  )
}