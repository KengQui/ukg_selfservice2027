import { afterEach, beforeEach, describe, expect, test, vi } from 'vitest'
import '@testing-library/jest-dom/vitest'
import { cleanup, render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes, useLocation } from 'react-router-dom'
import { companySetupSavedKey } from '@workspace/setup-shared/prototypes/_shared-company-setup/useCompanySetupState'
import { invitationScope } from '../companySetupInvite'
import CompanySetupInvitePage from '../index'

vi.mock('../../../templates/selfservice-shell/SelfServiceShell', () => ({
  default: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
}))

beforeEach(() => { localStorage.clear(); sessionStorage.clear() })
afterEach(() => { cleanup(); vi.restoreAllMocks() })

function Location() {
  const { pathname, search } = useLocation()
  return <span data-testid="location">{pathname}{search}</span>
}

function open(search = '') {
  return render(
    <MemoryRouter initialEntries={[`/prototypes/company-setup-invite${search}`]}>
      <Routes>
        <Route path="/prototypes/company-setup-invite" element={<CompanySetupInvitePage />} />
        <Route path="/prototypes/company-setup-hub" element={<Location />} />
      </Routes>
    </MemoryRouter>,
  )
}

describe('Company Setup invitation draft', () => {
  test('validates a required email and explicitly saves only a draft, including after reload', async () => {
    const user = userEvent.setup()
    const view = open()
    await user.click(screen.getByRole('button', { name: 'Save invitation draft' }))
    expect(screen.getByText('Add the email address of the person you want to invite.')).toBeInTheDocument()
    await user.type(screen.getByLabelText('Collaborator email address'), 'not-an-email')
    await user.click(screen.getByRole('button', { name: 'Save invitation draft' }))
    expect(screen.getByText('That doesn’t look like an email address yet — check for a missing @ or a typo.')).toBeInTheDocument()
    expect(localStorage.length).toBe(0)
    await user.clear(screen.getByLabelText('Collaborator email address'))
    await user.type(screen.getByLabelText('Collaborator email address'), 'partner@example.org ')
    await user.click(screen.getByRole('button', { name: 'Save invitation draft' }))
    expect(screen.getByText(/Invitation draft saved in this browser/)).toBeInTheDocument()
    expect(screen.getByText(/No email will be sent and no access will be granted/)).toBeInTheDocument()
    expect(JSON.parse(localStorage.getItem(invitationScope(null).key)!)).toMatchObject({ email: 'partner@example.org' })
    view.unmount()
    open()
    expect(screen.getByLabelText('Collaborator email address')).toHaveValue('partner@example.org')
  })

  test('demo scopes are isolated from ordinary setup and from one another; return strips wizard params', async () => {
    localStorage.setItem(companySetupSavedKey('manual'), JSON.stringify({ legalName: 'Actual Co', taxId: '10-1234567', updatedAt: 50 }))
    localStorage.setItem(companySetupSavedKey('from-doc'), JSON.stringify({ legalName: 'Newer Co', taxId: '20-1234567', updatedAt: 100 }))
    expect(invitationScope(null).company).toBe('Newer Co')
    localStorage.removeItem(companySetupSavedKey('from-doc'))
    expect(invitationScope(null).company).toBe('Actual Co')
    expect(invitationScope('new-single').key).not.toBe(invitationScope(null).key)
    expect(invitationScope('new-single').key).not.toBe(invitationScope('new-multi').key)
    const user = userEvent.setup()
    open('?demo=new-single&page=done&company=secret&returning=1')
    expect(screen.getByText(/Bright Harbor Bakery LLC/)).toBeInTheDocument()
    await user.type(screen.getByLabelText('Collaborator email address'), 'demo@example.org')
    await user.click(screen.getByRole('button', { name: 'Save invitation draft' }))
    expect(localStorage.getItem(invitationScope(null).key)).toBeNull()
    await user.click(screen.getByRole('button', { name: 'Return to Company Setup' }))
    expect(screen.getByTestId('location')).toHaveTextContent('/prototypes/company-setup-hub?demo=new-single')
  })

  test('invalid demo is treated as ordinary, without retaining branding params', async () => {
    open('?demo=bogus&page=login')
    await userEvent.setup().click(screen.getByRole('button', { name: 'Return to Company Setup' }))
    expect(screen.getByTestId('location')).toHaveTextContent('/prototypes/company-setup-hub')
  })

  test('storage failures do not claim the draft was saved', async () => {
    vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => { throw new Error('Quota exceeded') })
    open()
    await userEvent.setup().type(screen.getByLabelText('Collaborator email address'), 'helper@example.org')
    await userEvent.setup().click(screen.getByRole('button', { name: 'Save invitation draft' }))
    expect(screen.getByText(/could not be saved in this browser/)).toBeInTheDocument()
    expect(screen.queryByText(/Invitation draft saved in this browser/)).not.toBeInTheDocument()
  })

  test('the form can be saved from the keyboard', async () => {
    open()
    const user = userEvent.setup()
    const input = screen.getByLabelText('Collaborator email address')
    await user.type(input, 'helper@example.org{Enter}')
    expect(screen.getByText(/Invitation draft saved in this browser/)).toBeInTheDocument()
  })

  test('corrupt stored data is reported, not represented as a saved invitation', () => {
    localStorage.setItem(invitationScope(null).key, '{invalid')
    open()
    expect(screen.getByText(/saved invitation draft could not be read/)).toBeInTheDocument()
    expect(screen.queryByText(/Invitation draft saved in this browser/)).not.toBeInTheDocument()
  })
})