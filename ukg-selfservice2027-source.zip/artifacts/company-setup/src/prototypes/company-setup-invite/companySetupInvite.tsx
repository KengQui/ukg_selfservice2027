import { useState, type CSSProperties, type FormEvent } from 'react'
import { Button, InlineMessage, Input } from '@ready/dls'
import { useAskBrytePage } from '@workspace/setup-shared/ask-bryte'
import type { DemoScenario } from '@workspace/setup-shared/prototypes/branding-demo/demoScenarios'
import { readCurrentCompanySetup, sampleFromDocState } from '@workspace/setup-shared/prototypes/_shared-company-setup/useCompanySetupState'
import {
  invitationDraftKey, readInvitationDraft, validInvitationEmail, type InvitationDraft,
} from '@workspace/setup-shared/prototypes/_shared-company-setup/invitationDraft'

/** Do not use the last viewed branding demo as ordinary Company Setup identity. */
export function invitationScope(scenario: DemoScenario | null): { key: string; company: string } {
  const key = invitationDraftKey(scenario)
  if (scenario) return { key, company: sampleFromDocState.legalName || 'Your company' }
  return { key, company: readCurrentCompanySetup()?.legalName?.trim() || 'your company' }
}

const UNREADABLE_DRAFT = 'The saved invitation draft could not be read. Enter the email again to replace it.'

function readDraft(key: string): { draft: InvitationDraft | null; error: string } {
  try {
    const draft = readInvitationDraft(localStorage, key)
    return draft === 'unreadable' ? { draft: null, error: UNREADABLE_DRAFT } : { draft, error: '' }
  } catch {
    return { draft: null, error: UNREADABLE_DRAFT }
  }
}

const page: CSSProperties = { maxWidth: 640, width: '100%', margin: '0 auto', minWidth: 0 }
const actions: CSSProperties = { display: 'flex', flexWrap: 'wrap', gap: 'var(--space-300)', marginTop: 'var(--space-600)' }

export default function CompanySetupInvite({ scenario, onReturn }: { scenario: DemoScenario | null; onReturn: () => void }) {
  const { key, company } = invitationScope(scenario)
  const [initial] = useState(() => readDraft(key))
  const [email, setEmail] = useState(initial.draft?.email ?? '')
  const [error, setError] = useState(initial.error)
  const [emailError, setEmailError] = useState('')
  const [saved, setSaved] = useState(Boolean(initial.draft))
  useAskBrytePage('company-setup-invite', { emailEntered: Boolean(email.trim()), draftSaved: saved })

  const save = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const normalized = email.trim()
    if (!normalized) { setEmailError('Add the email address of the person you want to invite.'); setSaved(false); return }
    if (!validInvitationEmail(normalized)) { setEmailError('That doesn’t look like an email address yet — check for a missing @ or a typo.'); setSaved(false); return }
    setEmailError('')
    try {
      localStorage.setItem(key, JSON.stringify({ email: normalized, savedAt: Date.now() } satisfies InvitationDraft))
      setEmail(normalized)
      setError('')
      setSaved(true)
    } catch {
      setSaved(false)
      setError('The invitation draft could not be saved in this browser. Free up browser storage and try again.')
    }
  }

  return (
    <section style={page} aria-labelledby="invite-heading">
      <h1 id="invite-heading" className="text-display" style={{ margin: '0 0 var(--space-300)' }}>Invite others to help</h1>
      <p className="text-body" style={{ color: 'var(--color-text-subtle)', margin: '0 0 var(--space-600)' }}>
        Setup goes faster with the person who keeps your paperwork. Ask a co-worker, bookkeeper, or accountant to help set up {company}. This is for help with setup, not for adding people to your team.
      </p>
      <InlineMessage theme="info">Save an invitation draft here. No email will be sent and no access will be granted.</InlineMessage>
      <form onSubmit={save} noValidate style={{ marginTop: 'var(--space-600)' }}>
        <Input
          id="collaborator-email"
          type="email"
          autoComplete="email"
          inputMode="email"
          size="large"
          label="Collaborator email address"
          required
          value={email}
          onChange={value => { setEmail(value); setEmailError(''); setSaved(false) }}
          errorText={emailError || undefined}
          placeholder="name@example.com"
        />
        <div style={actions}>
          <Button type="submit">Save invitation draft</Button>
          <Button type="button" variant="tertiary" onClick={onReturn}>Return to Company Setup</Button>
        </div>
      </form>
      {error && <div style={{ marginTop: 'var(--space-400)' }}><InlineMessage theme="error">{error}</InlineMessage></div>}
      {saved && <div style={{ marginTop: 'var(--space-400)' }}><InlineMessage theme="success">Invitation draft saved in this browser. No invitation has been sent and no access has been granted.</InlineMessage></div>}
    </section>
  )
}
