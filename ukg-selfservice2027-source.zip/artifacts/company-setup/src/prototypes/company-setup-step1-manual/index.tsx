/**
 * Company Setup — Step 1 of 2, Manual entry
 *
 * Business name + address + description. See
 * CompanySetupStep1Form.tsx (in ../_shared-company-setup/) for component
 * notes and fidelity buckets; this file is a thin route wrapper.
 */
import SelfServiceShell from '../../templates/selfservice-shell/SelfServiceShell'
import SaveDraftAction from '../_shared-company-setup/SaveDraftAction'
import { CompanySetupDraftProvider } from '../_shared-company-setup/CompanySetupDraftContext'
import CompanySetupStep1Form from '../_shared-company-setup/CompanySetupStep1Form'
import VersionSwitcher, { buildCompanySetupSwitcherLinks } from '../_shared/versionSwitcher'

export const meta = {
  id:          'company-setup-step1-manual',
  title:       'Company Setup — Step 1 of 2 (Manual entry)',
  route:       'company-setup-step1-manual',
  section:     'prototype',
  area:        'Company Setup',
  description: 'Business name, address, and description — step 1 of the manual-entry company setup flow.',
  status:      'wip',
} as const

export default function CompanySetupStep1Manual() {
  // The draft is shared by the step form and the header's Save and finish later.
  return (
    <CompanySetupDraftProvider variant="manual">
      <SelfServiceShell title="Company Setup" backTo="/prototypes/company-setup-intro" breadcrumbs={['Global Setup', 'Company Setup']} headerActions={<SaveDraftAction />} hideNav hideTabs>
        <CompanySetupStep1Form
          variant="manual"
          step2Route="/prototypes/company-setup-step2-manual"
          backRoute="/prototypes/company-setup-upload"
        />
        <VersionSwitcher links={buildCompanySetupSwitcherLinks('step1-manual')} />
      </SelfServiceShell>
    </CompanySetupDraftProvider>
  )
}
