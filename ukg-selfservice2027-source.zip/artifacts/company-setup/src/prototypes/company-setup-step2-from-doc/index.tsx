/**
 * Company Setup — Step 2 of 2, From uploaded document
 *
 * Address (pre-filled), EIN/Tax ID (pre-filled), and NAICS code (suggested
 * immediately). See CompanySetupStep2Form.tsx (in ../_shared-company-setup/)
 * for component notes and fidelity buckets; this file is a thin route
 * wrapper.
 */
import SelfServiceShell from '../../templates/selfservice-shell/SelfServiceShell'
import SaveDraftAction from '../_shared-company-setup/SaveDraftAction'
import { CompanySetupDraftProvider } from '../_shared-company-setup/CompanySetupDraftContext'
import CompanySetupStep2Form from '../_shared-company-setup/CompanySetupStep2Form'
import VersionSwitcher, { buildCompanySetupSwitcherLinks } from '../_shared/versionSwitcher'

export const meta = {
  id:          'company-setup-step2-from-doc',
  title:       'Company Setup — Step 2 of 2 (From uploaded document)',
  route:       'company-setup-step2-from-doc',
  section:     'prototype',
  area:        'Company Setup',
  description: 'EIN filled in from an uploaded tax letter, immediate NAICS suggestions, and a current payroll provider question — step 2 of the from-document company setup flow.',
  status:      'wip',
} as const

export default function CompanySetupStep2FromDoc() {
  // The draft is shared by the step form and the header's Save and finish later.
  return (
    <CompanySetupDraftProvider variant="from-doc">
      <SelfServiceShell title="Company Setup" backTo="/prototypes/company-setup-intro" breadcrumbs={['Global Setup', 'Company Setup']} headerActions={<SaveDraftAction />} hideNav hideTabs>
        <CompanySetupStep2Form variant="from-doc" step1Route="/prototypes/company-setup-step1-from-doc" />
        <VersionSwitcher links={buildCompanySetupSwitcherLinks('step2-from-doc')} />
      </SelfServiceShell>
    </CompanySetupDraftProvider>
  )
}
