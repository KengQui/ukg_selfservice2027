import { afterEach, describe, expect, test, vi } from 'vitest'
import '@testing-library/jest-dom/vitest'
import { cleanup, render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import CompanySetupIntro from '../companySetupIntro'

afterEach(cleanup)

describe('CompanySetupIntro', () => {
    function setup(props: Partial<React.ComponentProps<typeof CompanySetupIntro>> = {}) {
        const onStartSetup = vi.fn()
        const onPickSomethingElse = vi.fn()
        render(
            <CompanySetupIntro
                onStartSetup={onStartSetup}
                onPickSomethingElse={onPickSomethingElse}
                {...props}
            />,
        )
        return { onStartSetup, onPickSomethingElse }
    }

    test('should show the headline and both action buttons', () => {
        setup()

        expect(screen.getByRole('heading', { name: /let's get your company set up/i })).toBeInTheDocument()
        expect(screen.getByRole('button', { name: /start setup/i })).toBeInTheDocument()
        expect(screen.getByRole('button', { name: /pick something else/i })).toBeInTheDocument()
    })

    test('should show the not-yet state for what will be filled in, not real values', () => {
        setup()

        expect(screen.getByText('Business name')).toBeInTheDocument()
        expect(screen.getByText('Address')).toBeInTheDocument()
        expect(screen.getByText('EIN/Tax ID')).toBeInTheDocument()
        expect(screen.queryByText(/bright harbor bakery/i)).not.toBeInTheDocument()
    })

    describe('when the start setup button is clicked', () => {
        test('should call onStartSetup', async () => {
            const { onStartSetup } = setup()

            await userEvent.click(screen.getByRole('button', { name: /start setup/i }))

            expect(onStartSetup).toHaveBeenCalledTimes(1)
        })
    })

    describe('when the pick something else button is clicked', () => {
        test('should call onPickSomethingElse', async () => {
            const { onPickSomethingElse } = setup()

            await userEvent.click(screen.getByRole('button', { name: /pick something else/i }))

            expect(onPickSomethingElse).toHaveBeenCalledTimes(1)
        })
    })
})
