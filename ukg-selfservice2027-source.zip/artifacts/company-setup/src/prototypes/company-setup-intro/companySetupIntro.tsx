/**
 * Company Setup — Intro screen (PRODUCTION-ish scaffold)
 *
 * /to-ready build of company-setup/design/company-setup-intro.html — the
 * screen that precedes the two-step Company Setup form (see
 * ../_shared-company-setup/CompanySetupForm.tsx for that part). Nothing has
 * been uploaded yet at this point, so the right-hand preview deliberately
 * shows a "not filled in yet" state, not real values.
 *
 * Fidelity buckets:
 *   PRODUCTION  — Button, InlineMessage, Icon are real `src/design-system/`
 *                 components (see COMPONENT NOTES below for the concessions
 *                 found — none silent, all in company-setup/ready/GAPS.md).
 *                 "Start setup" / "Pick something else" are real navigation
 *                 too — wired in index.tsx to the upload screen and the hub,
 *                 respectively. The right-hand preview card's field-row text
 *                 uses `rdy_sys_text_copy_sm_lowEmphasis_onLight`
 *                 (`--type-md-size`/20px literal line-height/400 weight/
 *                 `--color-text-subtle`) — see GAPS.md for why the line-height
 *                 is a literal, not a token.
 *   SCAFFOLDING — the right-hand preview card as a whole. It is illustrative
 *                 (there is no real "document preview" component in this
 *                 kit), built from plain markup + real tokens + the real
 *                 Icon/AILogo components for its small glyphs.
 *
 * COMPONENT NOTES (see company-setup/ready/GAPS.md for the plain-language
 * version of each):
 *   - The "Your suggested first step" tag was removed at the user's request
 *     (2026-09-16) — no longer part of this screen.
 *   - The small sparkle glyph (in the document graphic and reused for the
 *     Bryte notice) is the real `AILogo` (variant="secondary"), which is a
 *     purple/magenta gradient mark — not the mockup's flat green-on-yellow
 *     sparkle. This is the Bryte AI brand mark; using it here is accurate
 *     (the graphic represents Bryte reading a document), the colour is just
 *     not overridable.
 *   - The "Bryte:" tip box uses `InlineMessage` (theme="info"), the same
 *     resolution `CompanySetupForm.tsx` already made for its own "Bryte:"
 *     notices — reused for consistency. Its icon is fixed to InlineMessage's
 *     own "announcement" glyph, not a Bryte-branded one.
 */
import type { CSSProperties, ReactNode } from 'react'
import { Button, Icon } from '@ready/dls'
import { AILogo } from '@ready/dls/ai'

// ── Props ─────────────────────────────────────────────────────────────────────

export interface CompanySetupIntroProps {
  /** Advances to the upload screen. Wired in index.tsx. */
  onStartSetup?: () => void
  /** Routes to the setup hub, so the user can pick a different checklist item. Wired in index.tsx. */
  onPickSomethingElse?: () => void
}

// ── Layout building blocks (inline styles + tokens — matches the pattern
//    already established in ../_shared-company-setup/CompanySetupForm.tsx) ──

const heroGrid: CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 360px), 1fr))',
  gap: 'var(--space-800)',
  flex: 1,
  // Extend the surface itself through the shell padding, not its children,
  // including the Ask Bryte room at the bottom when the app turns it on.
  margin: 'calc(-1 * var(--space-600)) calc(-1 * var(--space-600)) calc(-1 * (var(--space-600) + var(--ask-bryte-room, 0px)))',
  background: 'var(--color-bg)',
}

const heroLeft: CSSProperties = {
  minWidth: 0,
  padding: 'var(--space-800) var(--space-600)',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'flex-start',
}

const heroLeftInner: CSSProperties = { maxWidth: 480 }

const headline: CSSProperties = {
  margin: '0 0 var(--space-300)',
}

const bodyText: CSSProperties = {
  color: 'var(--color-text-subtle)',
  maxWidth: '56ch',
  // Spacing rhythm: heading + body stay close; each later group owns its top gap.
  margin: 0,
}

const statRow: CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: 'var(--space-400) var(--space-800)',
  margin: 'var(--space-600) 0 0',
  padding: 'var(--space-400) 0',
  borderTop: '1px solid var(--color-border)',
  borderBottom: '1px solid var(--color-border)',
}

const statCaption: CSSProperties = {
  color: 'var(--color-text-subtle)',
  margin: 0,
}

const eyebrow: CSSProperties = {
  color: 'var(--color-text-subtle)',
  letterSpacing: '0.1em',
  textTransform: 'uppercase',
  fontWeight: 600,
  // Section label: 24px above, 8px to the first checklist row.
  margin: 'var(--space-600) 0 var(--space-200)',
}

const checklistRow: CSSProperties = {
  display: 'flex',
  gap: 'var(--space-300)',
  alignItems: 'flex-start',
  margin: 0,
}

const checkCircle: CSSProperties = {
  width: 22,
  height: 22,
  borderRadius: 'var(--radius-full)',
  background: 'var(--color-icon-bg-success)',
  color: 'var(--color-status-success-text)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  flex: 'none',
  marginTop: 1,
}

const checklistExample: CSSProperties = {
  color: 'var(--color-text-subtle)',
  fontSize: 'var(--type-sm-size)',
  lineHeight: 'var(--type-sm-line-height)',
  display: 'block',
  marginTop: 'var(--space-100)',
}

const actionsRow: CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  alignItems: 'center',
  gap: 'var(--space-400) var(--space-600)',
  marginTop: 'var(--space-800)',
}

// Right column — illustrative preview. SCAFFOLDING, see file header.
const heroRight: CSSProperties = {
  background: 'var(--color-surface-mid)',
  minWidth: 0,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  padding: 'var(--space-800)',
}

const previewCard: CSSProperties = {
  width: '100%',
  maxWidth: 420,
  background: 'var(--color-bg)',
  borderRadius: 'var(--radius-300)',
  // rdy_ref_elevation_10 — no CSS custom property exists for this token yet
  // (see ready-dls-kit CLAUDE.md §8); this is its documented literal value.
  boxShadow: '0px 24px 68px rgba(0,0,0,0.14), 0px 0px 54px rgba(0,0,0,0.08)',
  overflow: 'hidden',
}

const previewCardHeader: CSSProperties = {
  background: 'var(--color-theme-1000)',
  color: 'var(--color-theme-text-on-dark)',
  padding: 'var(--space-600) var(--space-600) var(--space-400)',
}

const previewCardEyebrow: CSSProperties = {
  fontSize: 'var(--type-sm-size)',
  letterSpacing: '0.14em',
  textTransform: 'uppercase',
  color: 'var(--color-theme-accent)',
  margin: '0 0 var(--space-200)',
}

const previewCardTitle: CSSProperties = {
  fontFamily: 'var(--font-family-heading)',
  fontWeight: 500,
  fontSize: 'var(--type-2xl-size)',
  margin: '0 0 var(--space-300)',
}

const docGraphic: CSSProperties = {
  display: 'flex',
  gap: 'var(--space-300)',
  alignItems: 'center',
  background: 'rgba(255,255,255,.07)',
  borderRadius: 'var(--radius-200)',
  padding: 'var(--space-300) var(--space-400)',
}

const docLines: CSSProperties = {
  flex: 1,
  display: 'flex',
  flexDirection: 'column',
  gap: 'var(--space-200)',
}

const docLineBar = (width: string, faint: boolean): CSSProperties => ({
  display: 'block',
  height: 6,
  borderRadius: 4,
  background: faint ? 'rgba(255,255,255,.18)' : 'rgba(255,255,255,.35)',
  width,
})

const sparkleCircle: CSSProperties = {
  width: 34,
  height: 34,
  borderRadius: 'var(--radius-full)',
  background: 'var(--color-bg)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  flex: 'none',
}

const previewCardBody: CSSProperties = {
  padding: 'var(--space-400) var(--space-600) var(--space-600)',
}

const previewCardLabel: CSSProperties = {
  fontSize: 'var(--type-sm-size)',
  letterSpacing: '0.08em',
  textTransform: 'uppercase',
  color: 'var(--color-text-subtle)',
  margin: '0 0 var(--space-300)',
}

const previewFieldList: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 'var(--space-200)',
}

// rdy_sys_text_copy_sm (fontSize 14 / lineHeight 20 / weight 400 — confirmed in
// foundations/typography.ts). `--type-md-size` is the token that equals 14px, but
// no `--type-*-line-height` token equals 20 (sm=16, md=18, lg=24 — a real gap in
// the scale, not a naming mismatch this time), so line-height is a literal 20px
// here, sourced directly from the foundation data per ready-dls-kit/CLAUDE.md §4's
// allowance for that when no CSS token lines up. Color is
// rdy_sys_color_text_lowEmphasis_onLight → `--color-text-subtle`, already a real,
// wired-up token (unlike `--color-text-mid`, which needed adding — see GAPS.md #30).
const previewFieldRow: CSSProperties = {
  margin: 0, // reset the <p>'s default browser margin — it was stacking on top of
             // previewFieldList's flex `gap`, making the rows read far apart even
             // after the gap itself was reduced (36px actual gap vs. the 8px intended)
  fontFamily: 'var(--font-family-sans)',
  fontSize: 'var(--type-md-size)',
  lineHeight: '20px',
  fontWeight: 400,
  color: 'var(--color-text-subtle)',
}

// ── Content ───────────────────────────────────────────────────────────────────

function Checklist({ children }: { children: ReactNode }) {
  return (
    <div style={checklistRow}>
      <span style={checkCircle} aria-hidden="true">
        <Icon name="statusSuccessSolid" size={14} />
      </span>
      <span>{children}</span>
    </div>
  )
}

export default function CompanySetupIntro({
  onStartSetup,
  onPickSomethingElse,
}: CompanySetupIntroProps) {
  return (
    <div className="company-setup-intro-grid" style={heroGrid}>
      <div style={heroLeft}>
        <div style={heroLeftInner}>
          <h1 className="text-display" style={headline}>
            Let&apos;s get your company set up
          </h1>

          <p className="text-body" style={bodyText}>
            A few quick steps and your company details are ready to go. Upload what
            you&apos;ve got and I&apos;ll fill in the details for you to check — or skip that
            and type everything in yourself, whichever suits you.
          </p>

          <div style={statRow}>
            <div>
              <p className="text-heading-md" style={{ margin: '0 0 var(--space-100)' }}>8 min</p>
              <p className="text-caption" style={statCaption}>Typical time</p>
            </div>
            <div>
              <p className="text-heading-md" style={{ margin: '0 0 var(--space-100)' }}>2 steps</p>
              <p className="text-caption" style={statCaption}>Short ones</p>
            </div>
            <div>
              <p className="text-heading-md" style={{ margin: '0 0 var(--space-100)' }}>Anytime</p>
              <p className="text-caption" style={statCaption}>Save and come back</p>
            </div>
          </div>

          <p className="text-caption" style={eyebrow}>What to have nearby</p>

          <Checklist>
            Your business tax ID (EIN)
            <span style={checklistExample}>
              For example, your IRS EIN confirmation letter (CP 575) or a previously filed
              Form 941.
            </span>
          </Checklist>

          <div style={actionsRow}>
            <Button onClick={onStartSetup}>Start setup</Button>
            <Button variant="tertiary" highEmphasis onClick={onPickSomethingElse}>
              Pick something else
            </Button>
          </div>
        </div>
      </div>

      <div style={heroRight}>
        <div style={previewCard}>
          <div style={previewCardHeader}>
            <p style={previewCardEyebrow}>Before step 1</p>
            <p style={previewCardTitle}>Hand me your paperwork</p>
            <div style={docGraphic}>
              <div style={docLines}>
                <span style={docLineBar('82%', false)} />
                <span style={docLineBar('58%', false)} />
                <span style={docLineBar('90%', true)} />
                <span style={docLineBar('68%', true)} />
              </div>
              <span style={sparkleCircle} aria-hidden="true">
                <AILogo variant="secondary" size={16} />
              </span>
            </div>
          </div>
          <div style={previewCardBody}>
            <p style={previewCardLabel}>What I&apos;ll fill in for you</p>
            <div style={previewFieldList}>
              <p style={previewFieldRow}>Business name</p>
              <p style={previewFieldRow}>Address</p>
              <p style={previewFieldRow}>EIN/Tax ID</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
