/**
 * Company Setup — Intro
 *
 * /to-ready build of company-setup/design/company-setup-intro.html. Thin
 * route wrapper — see companySetupIntro.tsx for the actual screen and its
 * component notes.
 */
import { useNavigate } from '@workspace/setup-shared/prototypes/_shared/navigation'
import SelfServiceShell from '../../templates/selfservice-shell/SelfServiceShell'
import CompanySetupIntro from './companySetupIntro'
import VersionSwitcher, { buildCompanySetupSwitcherLinks } from '../_shared/versionSwitcher'

export const meta = {
  id:          'company-setup-intro',
  title:       'Company Setup — Intro',
  route:       'company-setup-intro',
  section:     'prototype',
  area:        'Company Setup',
  description: 'Intro screen before the two-step Company Setup form — nothing uploaded yet.',
  status:      'wip',
} as const

export default function CompanySetupIntroPrototype() {
  const navigate = useNavigate()

  return (
    <SelfServiceShell
      title="Company Setup"
      breadcrumbs={['Global Setup', 'Company Setup']}
      showBack={false}
      hideNav
      hideTabs
    >
      <CompanySetupIntro
        onStartSetup={() => navigate('/prototypes/company-setup-upload')}
        onPickSomethingElse={() => navigate('/prototypes/company-setup-hub')}
      />

      <VersionSwitcher links={buildCompanySetupSwitcherLinks('intro')} />
    </SelfServiceShell>
  )
}
