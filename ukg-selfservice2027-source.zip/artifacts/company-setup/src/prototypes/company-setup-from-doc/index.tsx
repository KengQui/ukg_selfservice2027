/**
 * Company Setup — From uploaded document
 *
 * /to-ready build of company-setup/design/company-setup-from-doc.html — the
 * "document uploaded and scraped" state. See CompanySetupForm.tsx (in
 * ../_shared-company-setup/) for the component notes, drift flags, and
 * fidelity buckets; this file is a thin route wrapper.
 */
import SelfServiceShell from '../../templates/selfservice-shell/SelfServiceShell'
import CompanySetupForm from '../_shared-company-setup/CompanySetupForm'
import VersionSwitcher, { buildCompanySetupSwitcherLinks } from '../_shared/versionSwitcher'

export const meta = {
  id:          'company-setup-from-doc',
  title:       'Company Setup — From uploaded document',
  route:       'company-setup-from-doc',
  section:     'prototype',
  area:        'Company Setup',
  description: 'Business details filled in from an uploaded tax letter, with a flagged city and ZIP code mismatch and the EIN already confirmed.',
  status:      'wip',
} as const

export default function CompanySetupFromDoc() {
  return (
    <SelfServiceShell title="Company Setup" breadcrumbs={['Global Setup', 'Company Setup']} hideNav hideTabs>
      <CompanySetupForm variant="from-doc" />
      <VersionSwitcher links={buildCompanySetupSwitcherLinks('from-doc')} />
    </SelfServiceShell>
  )
}
