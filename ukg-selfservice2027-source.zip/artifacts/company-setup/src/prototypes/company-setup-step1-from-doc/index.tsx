/**
 * Company Setup — Step 1 of 2, From uploaded document
 */
import SelfServiceShell from '../../templates/selfservice-shell/SelfServiceShell'
import SaveDraftAction from '../_shared-company-setup/SaveDraftAction'
import { CompanySetupDraftProvider } from '../_shared-company-setup/CompanySetupDraftContext'
import CompanySetupStep1Form from '../_shared-company-setup/CompanySetupStep1Form'
import VersionSwitcher, { buildCompanySetupSwitcherLinks } from '../_shared/versionSwitcher'
import { sampleFromDocState } from '../_shared-company-setup/useCompanySetupState'

export const meta = {
  id:          'company-setup-step1-from-doc',
  title:       'Company Setup — Step 1 of 2 (From uploaded document)',
  route:       'company-setup-step1-from-doc',
  section:     'prototype',
  area:        'Company Setup',
  description: 'Business name and address filled in from an uploaded tax letter, with a flagged city and ZIP code mismatch, plus a business description — step 1 of the from-document company setup flow.',
  status:      'wip',
} as const

export default function CompanySetupStep1FromDoc() {
  // The draft is shared by the step form and the header's Save and finish later.
  return (
    <CompanySetupDraftProvider variant="from-doc">
      <SelfServiceShell title="Company Setup" backTo="/prototypes/company-setup-intro" breadcrumbs={['Global Setup', 'Company Setup']} headerActions={<SaveDraftAction />} hideNav hideTabs>
        <CompanySetupStep1Form
          variant="from-doc"
          step2Route="/prototypes/company-setup-step2-from-doc"
          backRoute="/prototypes/company-setup-upload"
          explicitSampleData={sampleFromDocState}
        />
        <VersionSwitcher links={buildCompanySetupSwitcherLinks('step1-from-doc')} />
      </SelfServiceShell>
    </CompanySetupDraftProvider>
  )
}