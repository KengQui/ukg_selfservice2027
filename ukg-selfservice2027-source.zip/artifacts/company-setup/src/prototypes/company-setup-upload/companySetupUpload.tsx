/**
 * Company Setup — Upload screen (PRODUCTION-ish scaffold)
 *
 * /to-ready build of company-setup/design/company-setup-upload.html — the
 * screen between the intro (../company-setup-intro/) and the business/tax
 * step (../_shared-company-setup/CompanySetupForm.tsx). Lets the user drop
 * in paperwork (business + bank details get pre-filled downstream) or skip
 * straight to typing everything in by hand.
 *
 * Fidelity buckets:
 *   PRODUCTION  — Tag, Button, Icon are all real
 *                 `src/design-system/` components (see COMPONENT NOTES).
 *                 "Continue" / "I'd rather type it in myself" are real
 *                 navigation too — wired in index.tsx to step 1's from-doc
 *                 and manual variants, respectively.
 *   STUBBED     — the "extraction" itself: `onDrop`/sample-document click
 *                 just skips straight to the found state with sample options.
 *   SCAFFOLDING — the drop zone. Reuses the exact real-component pattern
 *                 already used in ../upload-files/index.tsx (Icon "upload" +
 *                 a tertiary high-emphasis Button as "Browse files") rather
 *                 than inventing a new one.
 *
 * No illustrative graphic on this screen — removed at the user's explicit
 * request (it duplicated the intro screen's card with stale content; see
 * company-setup/ready/GAPS.md #28).
 *
 * COMPONENT NOTES (see company-setup/ready/GAPS.md for the plain-language
 * version of each):
 *   - "Documents read" uses `Tag` (type="misc" color="lemon"
 *     emphasis="high") — closest real match for the mockup's saturated
 *     yellow-green pill.
 */
import { useState, useEffect } from 'react'
import { useAskBrytePage } from '@workspace/setup-shared/ask-bryte'
import { useSearchParams } from 'react-router-dom'
import { Button, Tag, SelectableCard, SelectableCardGroup, InlineMessage } from '@ready/dls'
import { DropZone, SelectedFilesCard } from '../_shared/uploadFiles'

// ── Props ─────────────────────────────────────────────────────────────────────

export interface CompanySetupUploadProps {
  /** Advances to step 1 of the wizard, from-doc variant. Wired in index.tsx. */
  onContinue?: (data: any) => void
  /** Advances to step 1 of the wizard, manual variant. Wired in index.tsx. */
  onTypeItMyself?: () => void
}

type Stage = 'upload' | 'found'

const EIN_OPTIONS = [
  {
    id: '1',
    legalName: 'Bright Harbor Bakery LLC',
    taxId: '39-1234567',
    address: '4820 Sycamore Ave',
    city: 'Madison',
    state: 'WI',
    zip: '53718'
  },
  {
    id: '2',
    legalName: 'Bright Harbor Coffee LLC',
    taxId: '39-7654321',
    address: '101 Main St',
    city: 'Madison',
    state: 'WI',
    zip: '53703'
  },
  {
    id: '3',
    legalName: 'Bright Harbor Catering Inc',
    taxId: '39-9998888',
    address: '200 State St',
    city: 'Madison',
    state: 'WI',
    zip: '53703'
  }
]

// ── Layout building blocks — one plain, single-column layout shared by all
// stages (upload/found). No illustrative graphic — see file header and GAPS.md #28. ──

const narrowPage = { maxWidth: 640, margin: '0 auto', padding: 'var(--space-800) var(--space-600)' } as const

const headline = { margin: '0 0 var(--space-300)' } as const

const bodyText = {
  color: 'var(--color-text-subtle)',
  maxWidth: '56ch',
  margin: '0 0 var(--space-400)',
} as const

const actionsRow = {
  display: 'flex',
  alignItems: 'center',
  gap: 'var(--space-600)',
  marginTop: 'var(--space-400)',
  flexWrap: 'wrap',
} as const

// ── Drop zone (same real-component pattern as ../upload-files/index.tsx) ──

// ── Component ─────────────────────────────────────────────────────────────────

export default function CompanySetupUpload({ onContinue, onTypeItMyself }: CompanySetupUploadProps) {
  const [searchParams] = useSearchParams()
  const initialStage = (searchParams.get('stage') as Stage) || 'upload'
  const [stage, setStage] = useState<Stage>(initialStage)
  const [selectedEinId, setSelectedEinId] = useState<string | null>(null)
  const [selectedFiles, setSelectedFiles] = useState<File[]>([])
  const [fileError, setFileError] = useState('')
  useAskBrytePage(stage === 'found' ? 'company-setup-upload-results' : 'company-setup-upload', {
    filesChosen: selectedFiles.length,
    companiesFound: EIN_OPTIONS.length,
    companyChosen: Boolean(selectedEinId),
  })

  // Sync stage if query param changes via direct navigation
  useEffect(() => {
    const queryStage = searchParams.get('stage') as Stage
    if (queryStage) {
      setStage(queryStage)
    }
  }, [searchParams])

  function startExtraction() {
    setStage('found')
  }

  if (stage === 'found') {
    return (
      <div style={narrowPage}>
        <div style={{ marginBottom: 'var(--space-300)' }}>
          <Tag label="Documents read" type="misc" color="lemon" emphasis="high" />
        </div>
        <h1 className="text-display" style={{ fontSize: 'var(--type-3xl-size)', margin: '0 0 var(--space-100)' }}>
          I found more than one company.
        </h1>
        <p className="text-body" style={{ color: 'var(--color-text-subtle)', margin: '0 0 var(--space-600)' }}>
          Each one has its own tax ID, so let&apos;s set them up one at a time. Pick one to
          start with — you can come back for the others when it&apos;s done.
        </p>

        {/* One radio group: one Tab stop, arrow keys move and select */}
        <SelectableCardGroup aria-label="Companies" style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-300)', marginBottom: 'var(--space-400)' }}>
          {EIN_OPTIONS.map(opt => (
            <SelectableCard
              key={opt.id}
              type="single"
              selected={selectedEinId === opt.id}
              title={opt.legalName}
              subHeading={`EIN: ${opt.taxId} • ${opt.address}, ${opt.city}, ${opt.state} ${opt.zip}`}
              onChange={() => setSelectedEinId(opt.id)}
            />
          ))}
        </SelectableCardGroup>

        <div style={actionsRow}>
          <Button 
            disabled={!selectedEinId} 
            onClick={() => {
              const selected = EIN_OPTIONS.find(o => o.id === selectedEinId)
              if (onContinue && selected) onContinue(selected)
            }}
          >
            Continue
          </Button>
          <Button variant="secondary" onClick={() => { setStage('upload'); setSelectedEinId(null); }}>Back</Button>
        </div>
      </div>
    )
  }

  return (
    <div style={narrowPage}>
      <h1 className="text-display" style={headline}>Got any paperwork handy?</h1>
      <p className="text-body" style={bodyText}>
        Drop in whatever you have and I&apos;ll read it once — then your business name,
        address, and EIN come pre-filled. You&apos;ll be checking my work instead of typing
        it all in.
      </p>

      <DropZone
        disabled={false}
        onFiles={files => {
          if (!files.length) return
          if (selectedFiles.length + files.length > 5) {
            setFileError('That would be more than 5 files. I can read up to 5 at a time — remove some from your list or add fewer.')
            return
          }
          setSelectedFiles(previous => [...previous, ...files])
          setFileError('')
        }}
      />
      {fileError && <InlineMessage theme="error">{fileError}</InlineMessage>}
      {selectedFiles.length > 0 && (
        <div style={{ marginTop: 'var(--space-400)' }}>
          <SelectedFilesCard
            onUpload={startExtraction}
            files={selectedFiles.map((file, index) => ({
              id: String(index),
              name: file.name,
              sizeBytes: file.size,
              displayName: file.name,
              docType: '',
            }))}
            onRemove={id => {
              setSelectedFiles(previous => previous.filter((_, index) => String(index) !== id))
              setFileError('')
            }}
          />
        </div>
      )}

      <div style={actionsRow}>
        <Button disabled={!selectedFiles.length} onClick={startExtraction}>Upload my documents</Button>
        <Button variant="tertiary" highEmphasis onClick={onTypeItMyself}>
          I&apos;d rather type it in myself
        </Button>
      </div>
    </div>
  )
}
