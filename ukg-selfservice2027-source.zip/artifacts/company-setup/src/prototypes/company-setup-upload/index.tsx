/**
 * Company Setup — Upload
 *
 * /to-ready build of company-setup/design/company-setup-upload.html — the
 * "hand me your paperwork" screen between the intro and the business/tax
 * step. See companySetupUpload.tsx for the component notes, drift flags,
 * and fidelity buckets; this file is a thin route wrapper.
 */
import { useNavigate } from '@workspace/setup-shared/prototypes/_shared/navigation'
import SelfServiceShell from '../../templates/selfservice-shell/SelfServiceShell'
import CompanySetupUpload from './companySetupUpload'
import VersionSwitcher, { buildCompanySetupSwitcherLinks } from '../_shared/versionSwitcher'

export const meta = {
  id:          'company-setup-upload',
  title:       'Company Setup — Upload',
  route:       'company-setup-upload',
  section:     'prototype',
  area:        'Company Setup',
  description: 'Drop-in paperwork upload with a simulated extraction pass, or skip straight to manual entry.',
  status:      'wip',
} as const

export default function CompanySetupUploadPage() {
  const navigate = useNavigate()

  return (
    <SelfServiceShell title="Company Setup" breadcrumbs={['Global Setup', 'Company Setup']} hideNav hideTabs>
      <CompanySetupUpload
        onContinue={(data) => navigate('/prototypes/company-setup-step1-from-doc', { state: { extractedData: data } })}
        onTypeItMyself={() => navigate('/prototypes/company-setup-step1-manual')}
      />
      <VersionSwitcher links={buildCompanySetupSwitcherLinks('upload')} />
    </SelfServiceShell>
  )
}
