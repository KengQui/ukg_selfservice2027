/**
 * What Bryte knows about each Company Setup page: name, purpose, what's on
 * screen, current state, welcome and suggested questions. Screens register a
 * page key and a few non-sensitive facts; everything Bryte reads lives here,
 * so voice passes edit this file rather than the screens.
 *
 * Register: first-time business owner. Plain words, terms defined inline.
 * Never put a tax ID, bank detail, file contents, or a person's name or
 * contact details in these descriptions.
 */
import type { AskBryteCatalog, AskBryteFacts, AskBrytePageDescription } from '@workspace/setup-shared/ask-bryte'

const filled = (value: unknown, label: string) => `${label}: ${value ? 'filled in' : 'empty'}`

const TAX_ID_ANSWERS: Record<string, string> = {
  has: 'Yes, I have it',
  applied: 'I’ve applied',
  none: 'Not yet',
}

function taxIdState(facts: AskBryteFacts): string[] {
  const answer = typeof facts.taxIdAnswer === 'string' ? TAX_ID_ANSWERS[facts.taxIdAnswer] : undefined
  const lines = [answer ? `Answer to “Do you have your EIN/Tax ID number yet?”: ${answer}` : 'The EIN/Tax ID question has no answer yet']
  if (facts.taxIdAnswer === 'has') lines.push(filled(facts.taxIdEntered, 'EIN/Tax ID number'))
  if (facts.taxIdAnswer === 'applied') lines.push(filled(facts.referenceEntered, 'Application reference number (optional)'))
  if (facts.taxIdAnswer === 'none') lines.push('A note explains an EIN is needed before payroll can run, and that it’s free from the IRS')
  return lines
}

function naicsState(facts: AskBryteFacts): string {
  if (!facts.naicsCode) return 'No NAICS code chosen yet'
  return `NAICS code chosen: ${facts.naicsCode}${facts.naicsDescription ? ` (${facts.naicsDescription})` : ''}`
}

function addressState(facts: AskBryteFacts): string[] {
  return [
    filled(facts.legalNameEntered, 'Business name, exactly as the tax office has it'),
    filled(facts.addressComplete, 'Street address, city, state and ZIP code (all parts)'),
    ...(facts.businessState ? [`State: ${facts.businessState}`] : []),
    filled(facts.descriptionEntered, 'What does your business do?'),
  ]
}

const fromDocNote = (facts: AskBryteFacts) =>
  facts.fromDocument ? ['Details were read from the uploaded tax document and are marked “Filled from your doc” for checking'] : []

const step1 = (fromDocument: boolean) => (facts: AskBryteFacts): AskBrytePageDescription => ({
  name: 'Step 1: Your business',
  purpose: 'Step 1 of 2 in setting up the company. The person enters or checks the business’s legal name, address and a short description of what the business does.',
  onScreen: [
    'Field: Business name, exactly as the tax office has it',
    'Fields: Street address, City, State, ZIP code',
    'Field: What does your business do? (used to suggest an industry code on step 2)',
    ...(fromDocument ? ['Tags showing which fields were filled from the uploaded document'] : []),
    'Actions: Next (to step 2), Back, and Save and finish later in the header',
  ],
  state: [
    ...fromDocNote({ fromDocument }),
    ...addressState(facts),
    ...(facts.cityCheckShown ? ['A message says the city spelling doesn’t match the ZIP code and offers to use Madison instead'] : []),
  ],
  welcome: fromDocument
    ? 'You’re on step 1, checking the business details I read from your document. I can explain any field or what the tax office expects to see.'
    : 'You’re on step 1, where you add your business name and address. I can explain what each field needs and why it matters.',
  suggestions: fromDocument
    ? ['Why does my business name need to match exactly?', 'What if something I read looks wrong?', 'What should I write about my business?']
    : ['Why does my business name need to match exactly?', 'Which address should I use?', 'What should I write about my business?'],
})

const step2 = (fromDocument: boolean) => (facts: AskBryteFacts): AskBrytePageDescription => ({
  name: 'Step 2: Tax details',
  purpose: 'Step 2 of 2 in setting up the company. The person adds the federal tax ID (EIN, the number the IRS gives a business), picks an industry code (NAICS, a six-digit code that says what kind of business it is), and says whether they pay people somewhere else today.',
  onScreen: [
    'Question: Do you have your EIN/Tax ID number yet? Choices: Yes, I have it; I’ve applied; Not yet',
    'An I need help link that opens EIN help from Bryte',
    'Suggested NAICS codes based on the business description, a search for more codes, and a field to type a six-digit code',
    'Question: Are you paying people somewhere else today? Choices are payroll providers or Something else / none of these',
    'Actions: Ready to review, Back, and Save and finish later in the header',
  ],
  state: [
    ...fromDocNote({ fromDocument }),
    ...taxIdState(facts),
    naicsState(facts),
    facts.payrollProvider ? `Current payroll provider answer: ${facts.payrollProvider}` : 'The payroll provider question has no answer yet',
  ],
  welcome: 'You’re on step 2, the tax details. I can explain what an EIN is, help you think through an industry code, or say why we ask about your current payroll provider.',
  suggestions: ['What is an EIN and where do I find it?', 'How do I pick the right NAICS code?', 'What if I haven’t applied for an EIN yet?'],
})

const singleScreen = (fromDocument: boolean) => (facts: AskBryteFacts): AskBrytePageDescription => ({
  name: 'Set up your company',
  purpose: 'All company details on one screen: the business’s legal name and address, what it does, its federal tax ID (EIN, the number the IRS gives a business) and its industry code (NAICS, a six-digit code for the kind of business).',
  onScreen: [
    'Fields: Business name, Street address, City, State, ZIP code',
    'Question: Do you have your EIN/Tax ID number yet? Choices: Yes, I have it; I’ve applied; Not yet',
    'Field: What does your business do?, with suggested NAICS codes and a code search',
    'Actions: Ready to review, and Save and finish later',
  ],
  state: [...fromDocNote({ fromDocument }), ...addressState(facts), ...taxIdState(facts), naicsState(facts)],
  welcome: 'You’re setting up your company on one screen. I can explain any field, what an EIN is, or how to choose an industry code.',
  suggestions: ['What is an EIN?', 'How do I pick the right NAICS code?', 'Why does my business name need to match exactly?'],
})

export const companySetupPages = {
  'company-setup-hub': () => ({
    name: 'Company Setup',
    purpose: 'The starting point for setting up UKG Ready. It lists the setup tasks and recommends which one to do first.',
    onScreen: [
      'Heading: What should we set up first?',
      'Card: Set up your company. The name, address, and tax ID your payroll is filed under. Tagged Best first step.',
      'Card: Bring your brand to work. Your logo and colors, so every screen feels like your company. Also called system theme.',
      'Card: Invite others to help. Bring in a co-worker, bookkeeper, or accountant to help finish setup.',
      'Card: Set your pay schedule. How often you pay people and your next payday, so pay goes out on time. Also called pay period profiles.',
      'Card: Confirm how your people get paid. Check the pay types and deductions we’ve set up, so paychecks come out right. Also called earning and deduction codes.',
      'Card: Confirm hours before payday. Check everyone’s hours are right before you run payroll. Also called attestation.',
    ],
    state: [],
    welcome: 'You’re on Company Setup, where every setup task starts. I can help you decide what to do first or explain what any card covers.',
    suggestions: ['Where should I start?', 'What does “pay period profiles” mean?', 'Can someone else help me finish setup?'],
  }),
  'company-setup-intro': () => ({
    name: 'Let’s get your company set up',
    purpose: 'Explains company setup before it starts: two short steps, about 8 minutes, and the person can save and come back anytime.',
    onScreen: [
      'Facts: 8 min typical time; 2 steps, short ones; save and come back anytime',
      'What to have nearby: your business tax ID (EIN), for example the IRS EIN confirmation letter (CP 575) or a previously filed Form 941',
      'Preview: Hand me your paperwork. Bryte can read the business name, address and EIN from a document',
      'Actions: Start setup, and Pick something else',
    ],
    state: [],
    welcome: 'You’re about to set up your company. It takes two short steps, and I can read your details from a tax document if you have one.',
    suggestions: ['What is a CP 575 letter?', 'What if I can’t find my EIN?', 'Can I stop and finish later?'],
  }),
  'company-setup-upload': facts => ({
    name: 'Got any paperwork handy?',
    purpose: 'The person can upload tax documents so Bryte reads the business name, address and EIN from them, instead of typing them in.',
    onScreen: [
      'Intro: Bryte reads the documents once and fills in the business name, address and EIN for the person to check',
      'A drop zone for up to 5 files at a time',
      'A list of chosen files with a way to remove each one',
      'Actions: Upload my documents, and I’d rather type it in myself',
    ],
    state: [`Files chosen: ${Number(facts.filesChosen) || 0}`],
    welcome: 'You’re on the upload step. Add a tax document and I’ll read your business details from it, or type them in yourself.',
    suggestions: ['Which documents work best?', 'What will you read from my document?', 'What if I don’t have any paperwork?'],
  }),
  'company-setup-upload-results': facts => ({
    name: 'I found more than one company',
    purpose: 'The uploaded documents mention more than one company. Each has its own tax ID, so they’re set up one at a time. The person picks one to start with and comes back for the others when it’s done.',
    onScreen: [
      'Tag: Documents read',
      `Cards for each company found (${Number(facts.companiesFound) || 0}), each with its EIN and address`,
      'Actions: Continue, and Back to upload again',
    ],
    state: [facts.companyChosen ? 'A company is selected' : 'No company is selected yet'],
    welcome: 'Your documents mention more than one company. Each one has its own tax ID, so we set them up one at a time. Pick one to start with, and I can help with the others after.',
    suggestions: ['Which company should I set up first?', 'What happens to the other companies?', 'What if a company is missing?'],
  }),
  'company-setup-manual': singleScreen(false),
  'company-setup-from-doc': singleScreen(true),
  'company-setup-step1-manual': step1(false),
  'company-setup-step1-from-doc': step1(true),
  'company-setup-step2-manual': step2(false),
  'company-setup-step2-from-doc': step2(true),
  'company-setup-invite': facts => ({
    name: 'Invite others to help',
    purpose: 'The person can prepare an invitation for a co-worker, bookkeeper or accountant to help finish setup. It’s for help with setup, not for adding people to the team. Saving keeps it as a draft: no email goes out and nobody gets access yet.',
    onScreen: [
      'Field: Collaborator email address',
      'Actions: Save invitation draft, and Return to Company Setup',
    ],
    state: [
      filled(facts.emailEntered, 'Collaborator email address'),
      facts.draftSaved ? 'An invitation draft is saved' : 'No invitation draft is saved yet',
    ],
    welcome: 'You’re inviting someone to help with setup. I can explain who to invite and what happens with a saved draft.',
    suggestions: ['Who should I invite?', 'Does saving send the invitation?', 'Can I invite more than one person?'],
  }),
} satisfies AskBryteCatalog
