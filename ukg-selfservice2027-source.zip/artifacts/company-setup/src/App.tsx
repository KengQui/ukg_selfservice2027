import { useEffect } from 'react'
import { BrowserRouter, Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { askBryte } from '@workspace/api-client-react'
import { AskBrytePage, AskBryteProvider } from '@workspace/setup-shared/ask-bryte'
import { companySetupPages } from './askBrytePages'
import Hub from './prototypes/company-setup-hub'
import Intro from './prototypes/company-setup-intro'
import Upload from './prototypes/company-setup-upload'
import Manual from './prototypes/company-setup-manual'
import FromDoc from './prototypes/company-setup-from-doc'
import Step1Manual from './prototypes/company-setup-step1-manual'
import Step1FromDoc from './prototypes/company-setup-step1-from-doc'
import Step2Manual from './prototypes/company-setup-step2-manual'
import Step2FromDoc from './prototypes/company-setup-step2-from-doc'
import Invite from './prototypes/company-setup-invite'

const pages = {
  'company-setup-hub': Hub,
  'company-setup-intro': Intro,
  'company-setup-upload': Upload,
  'company-setup-manual': Manual,
  'company-setup-from-doc': FromDoc,
  'company-setup-step1-manual': Step1Manual,
  'company-setup-step1-from-doc': Step1FromDoc,
  'company-setup-step2-manual': Step2Manual,
  'company-setup-step2-from-doc': Step2FromDoc,
  'company-setup-invite': Invite,
}

function Home() {
  const { search, hash } = useLocation()
  return <Navigate replace to={`/prototypes/company-setup-hub${search}${hash}`} />
}

function Exit({ to }: { to: string }) {
  const { search, hash } = useLocation()
  useEffect(() => { window.location.replace(`${to}${search}${hash}`) }, [to, search, hash])
  return <p role="status">Opening project…</p>
}

function UnknownRoute() {
  const { pathname } = useLocation()
  // Header library/demo links belong to the kit, not this app's router.
  return <Exit to={pathname} />
}

function Shell() {
  const location = useLocation()
  useEffect(() => {
    const saved = localStorage.getItem('pg-theme')
    document.documentElement.dataset.theme = saved === 'dark' || saved === 'bryte-ai' ? saved : 'light'
  }, [])
  useEffect(() => { window.scrollTo(0, 0) }, [location.pathname])
  return (
    <div className="app-shell">
      <nav className="project-return-nav" aria-label="Project navigation">
        <a href="/prototypes" className="project-return-nav__link"><span aria-hidden="true">←</span> Back to Projects</a>
      </nav>
      <main className="app-shell__main">
        <Routes>
          <Route path="/" element={<Home />} />
          {Object.entries(pages).map(([route, Page]) => (
            <Route key={route} path={`/prototypes/${route}`} element={<><AskBrytePage page={route} /><Page /></>} />
          ))}
          <Route path="/prototypes/system-theme-setup" element={<Exit to="/branding/prototypes/system-theme-setup" />} />
          <Route path="/prototypes/earning-deduction-intro" element={<Exit to="/prototypes/earning-deduction-intro" />} />
          <Route path="/prototypes/earning-configuration" element={<Exit to="/earning-configuration/" />} />
          <Route path="/prototypes" element={<Exit to="/prototypes" />} />
          <Route path="*" element={<UnknownRoute />} />
        </Routes>
      </main>
    </div>
  )
}

export default function App() {
  return (
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <AskBryteProvider app="company-setup" pages={companySetupPages} ask={askBryte}>
        <Shell />
      </AskBryteProvider>
    </BrowserRouter>
  )
}