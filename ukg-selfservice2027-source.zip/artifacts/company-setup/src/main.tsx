import { createRoot } from 'react-dom/client';
import { StrictMode } from 'react';
import '@ready/dls/styles.css';
import '@ukgepic/ready-dls/tokens/themes.css';

import App from './App';
import { ErrorBoundary } from '@/components/error-boundary';

import './index.css';

createRoot(document.getElementById('root')!, {
  // Keeps caught errors off reportError(), which would raise the dev overlay.
  onCaughtError: (error, errorInfo) => {
    console.error(error, errorInfo.componentStack);
  },
}).render(
  <StrictMode><ErrorBoundary>
    <App />
  </ErrorBoundary></StrictMode>,
);
