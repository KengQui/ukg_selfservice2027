import path from 'path';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { defineConfig } from 'vite';
import { createHash } from 'node:crypto';
import { readFile, readdir } from 'node:fs/promises';

import runtimeErrorOverlay from '@replit/vite-plugin-runtime-error-modal';

const rawPort = process.env.PORT;

if (!rawPort) {
  throw new Error(
    'PORT environment variable is required but was not provided.',
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const basePath = process.env.BASE_PATH;

// Keep this ordered input contract aligned with create-claude-archive.mjs.
const companyInputs = [
  'artifacts/company-setup/src/main.tsx',
  'artifacts/company-setup/src/App.tsx',
  'artifacts/company-setup/src/index.css',
  'artifacts/company-setup/index.html',
  'artifacts/company-setup/vite.config.ts',
  'artifacts/company-setup/package.json',
];
const companyDirectories = [
  'lib/setup-shared/src/templates/selfservice-shell',
  'lib/setup-shared/src/prototypes/_shared',
  'lib/setup-shared/src/prototypes/_shared-company-setup',
  'artifacts/company-setup/src/prototypes',
];

async function companyFingerprint() {
  const hash = createHash('sha256');
  const root = path.resolve(import.meta.dirname, '../..');
  const files = [...companyInputs];
  async function walk(dir: string) {
    for (const entry of (await readdir(path.join(root, dir), { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name))) {
      const relative = path.posix.join(dir, entry.name);
      if (entry.isDirectory()) await walk(relative);
      else if (entry.isFile()) files.push(relative);
    }
  }
  for (const dir of companyDirectories) await walk(dir);
  for (const relative of files) hash.update(relative).update(await readFile(path.join(root, relative)));
  return hash.digest('hex');
}

if (!basePath) {
  throw new Error(
    'BASE_PATH environment variable is required but was not provided.',
  );
}

export default defineConfig({
  base: basePath,
  plugins: [
    {
      name: 'company-setup-source-revision',
      async generateBundle() {
        this.emitFile({
          type: 'asset',
          fileName: 'handoff-source-fingerprint.json',
          source: JSON.stringify({ sourceFingerprint: await companyFingerprint() }),
        });
      },
    },
    react(),
    tailwindcss(),
    runtimeErrorOverlay(),
    ...(process.env.NODE_ENV !== 'production' &&
    process.env.REPL_ID !== undefined
      ? [
          await import('@replit/vite-plugin-cartographer').then((m) =>
            m.cartographer({
              root: path.resolve(import.meta.dirname, '..'),
            }),
          ),
          await import('@replit/vite-plugin-dev-banner').then((m) =>
            m.devBanner(),
          ),
        ]
      : []),
  ],
  resolve: {
    alias: {
      '@': path.resolve(import.meta.dirname, 'src'),
      '@assets': path.resolve(
        import.meta.dirname,
        '..',
        '..',
        'attached_assets',
      ),
    },
    dedupe: ['react', 'react-dom'],
  },
  root: path.resolve(import.meta.dirname),
  build: {
    outDir: path.resolve(import.meta.dirname, 'dist/public'),
    emptyOutDir: true,
  },
  server: {
    port,
    strictPort: true,
    host: '0.0.0.0',
    allowedHosts: true,
    fs: {
      strict: true,
    },
  },
  preview: {
    port,
    host: '0.0.0.0',
    allowedHosts: true,
  },
});
