import { Router, type IRouter } from "express";
import type OpenAI from "openai";
import { ReviewCellPaymentBody, type EarningCheckError } from "@workspace/api-zod";
import { createOpenAIClient, errorSummary } from "../lib/earningAI";
import { CELL_INSTRUCTIONS, CELL_SCHEMA, cellMessage, validateCellReview } from "../lib/earningCellReview";
import { REIMBURSEMENT_INSTRUCTIONS, validReimbursementScope } from "../lib/earningReimbursementKnowledge";

const BODY = ReviewCellPaymentBody.extend({ answers: ReviewCellPaymentBody.shape.answers.element.strict().array() }).strict();
const ERRORS = {
  invalid_request: "We couldn’t check this answer. Check it, then try again.",
  rate_limited: "We’ve checked a lot of answers. Wait a minute, then try again.",
  unavailable: "We can’t check this payment right now. Try again, or select Review later.",
  timed_out: "Checking this payment took too long. Try again, or select Review later.",
  invalid_response: "We couldn’t check this payment this time. Try again, or select Review later.",
} as const satisfies Record<EarningCheckError["code"], string>;

export function createEarningCellReviewsRouter({ timeoutMs = 20_000, maxRequestsPerMinute = 30 } = {}): IRouter {
  const router = Router();
  const windows = new Map<string, { count: number; until: number }>();
  router.post("/earnings/cell-reviews", async (req, res): Promise<void> => {
    const fail = (status: number, code: EarningCheckError["code"]) => { res.status(status).json({ code, error: ERRORS[code] }); };
    const now = Date.now();
    for (const [key, window] of windows) if (window.until <= now) windows.delete(key);
    const key = req.ip || req.socket.remoteAddress || "unknown";
    const window = windows.get(key) ?? { count: 0, until: now + 60_000 };
    windows.set(key, window);
    if (++window.count > maxRequestsPerMinute) { fail(429, "rate_limited"); return; }
    const parsed = BODY.safeParse(req.body);
    if (!parsed.success || parsed.data.category === "MILEAGE" || !validReimbursementScope(parsed.data)) { fail(400, "invalid_request"); return; }
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const client = createOpenAIClient();
      const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
        { role: "system", content: !parsed.data.category || parsed.data.category === "CELL" ? CELL_INSTRUCTIONS : REIMBURSEMENT_INSTRUCTIONS }, { role: "user", content: cellMessage(parsed.data) },
      ];
      for (let attempt = 0; attempt < 2; attempt++) {
        const completion = await client.chat.completions.create({
          model: "gpt-5.4-mini", max_completion_tokens: 4096, reasoning_effort: "low",
          response_format: { type: "json_schema", json_schema: { name: "cell_review", strict: true, schema: CELL_SCHEMA } }, messages,
        }, { signal: controller.signal });
        const content = completion.choices[0]?.message?.content ?? "";
        let raw: unknown;
        try { raw = JSON.parse(content); } catch { raw = null; }
        const result = validateCellReview(raw, parsed.data);
        if (result.ok) { res.json(result.value); return; }
        messages.push({ role: "assistant", content: content || "{}" }, { role: "user", content: `Correct this response: ${result.correction} Return JSON only.` });
      }
      fail(502, "invalid_response");
    } catch (error) {
      req.log.error({ upstream: errorSummary(error) }, "CELL review unavailable");
      fail(controller.signal.aborted ? 504 : 502, controller.signal.aborted ? "timed_out" : "unavailable");
    } finally { clearTimeout(timeout); }
  });
  return router;
}
export default createEarningCellReviewsRouter();
