import assert from "node:assert/strict";
import { mkdtemp, rm, readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";
import express from "express";
import { build } from "esbuild";

const directory = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(directory, "../../../..");
const kb = JSON.parse(await readFile(path.join(root, "docs/earning-prompts/knowledge/mileage-v1.json"), "utf8"));
const policy = "mileage-purpose-1";
const input = (choice = "A") => ({
  policyVersion: policy, knowledgeVersion: "1.0", code: "MILEAGE", purposeChoice: choice,
  answers: [{ id: `${policy}:purpose`, question: kb.initial_question.question, answer: kb.initial_question.options[choice], component: "payment" }],
  historicalAnswers: [],
});
const component = (choice = "A") => ({
  id: { A: "reimbursement", B: "allowance", C: "compensation" }[choice] ?? "unknown",
  purpose: kb.initial_question.options[choice], treatment: "unknown", presentation: "unknown", specialReporting: "unknown",
  facts: [{ topic: "purpose", value: kb.initial_question.options[choice], answerId: `${policy}:purpose`, quote: kb.initial_question.options[choice] }],
});
const model = (choice = "A") => ({
  customerSummary: null,
  next: "clarify", question: "How is this payment calculated?", answerFormat: { kind: "choices", options: ["Business miles at a rate", "A fixed amount", "I'm not sure"] },
  reason: "The calculation helps the setup team understand this payment.", nextTopic: "calculation",
  nextComponent: component(choice).id, components: [component(choice)], outstandingQuestions: ["Confirm the calculation method."],
});
function fact(request, c, topic, quote, value = quote) {
  const id = `${policy}:${request.answers.length}:${c.id}:${topic}`;
  request.answers.push({ id, question: `What is the ${topic} practice?`, answer: quote, component: "payment" });
  c.facts.push({ topic, value, answerId: id, quote });
}
function captured(request, c) {
  return { next: "captured", question: null, answerFormat: null, reason: "Your mileage requirements are captured for setup review.",
    customerSummary: `Your payment is for ${c.id === "unknown" ? "an uncertain purpose" : c.id}. ${c.facts.filter(f => f.topic === "calculation").map(f => f.value).join(" ") || "The calculation is uncertain."}`,
    nextTopic: null, nextComponent: null, components: [c], outstandingQuestions: [] };
}
const options = { bundle: true, platform: "node", format: "esm", loader: { ".txt": "text" }, logLevel: "silent",
  banner: { js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" } };
test("MILEAGE source, evidence and assessment contract", async t => {
  const temp = await mkdtemp(path.join(directory, ".mileage-contract-"));
  try {
    await build({ ...options, entryPoints: [path.join(directory, "../lib/earningMileageReview.ts")], outfile: path.join(temp, "review.mjs") });
    await build({ ...options, entryPoints: [path.join(directory, "../lib/earningMileageKnowledge.ts")], outfile: path.join(temp, "knowledge.mjs") });
    await build({ ...options, entryPoints: [path.join(directory, "../lib/earningMileageEvidence.ts")], outfile: path.join(temp, "evidence.mjs") });
    const { validateMileageReview: validate, validMileageInput } = await import(path.join(temp, "review.mjs"));
    const { MILEAGE_INSTRUCTIONS, MILEAGE_KNOWLEDGE, MILEAGE_PRODUCT_REFERENCE } = await import(path.join(temp, "knowledge.mjs"));
    const { validateMileageEvidence } = await import(path.join(temp, "evidence.mjs"));
    const audit = (r, components = r.components, overrides = {}) => ({
      summaryGrounded: true,
      components, questionTopic: r.nextTopic, questionComponent: r.nextComponent,
      questionStatus: r.next === "clarify" ? "missing-material" : "none",
      impact: "The missing calculation distinguishes repayment from extra compensation.", ...overrides,
    });
    const ok = (r, i) => { const v = validate(r, i); assert.equal(v.ok, true, v.correction); return v.value; };
    await t.test("ambiguous separate taxable choice permits one clearer wage-handling question without approving supplemental tax", () => {
      const i = input(), c = component();
      fact(i, c, "calculation", "By documented business miles at a rate");
      fact(i, c, "treatment", "Included in taxable wages");
      i.answers.at(-1).question = "Is this MILEAGE payment included in taxable wages, or kept as a reimbursement?";
      fact(i, c, "wageHandling", "Separate taxable mileage payment");
      i.answers.at(-1).question = "Is this mileage pay treated as ordinary wages, or as a separate taxable mileage payment?";
      const r = { ...model(), components: [c], nextTopic: "wageHandling",
        question: "Is this ordinary taxable pay or supplemental taxable pay?",
        answerFormat: { kind: "choices", options: ["Ordinary taxable pay", "Supplemental taxable pay", "I'm not sure"] } };
      ok(r, i);
      assert.equal(validateMileageEvidence(audit(r), r, i).ok, true);
      c.treatment = "supplemental-taxable";
      assert.equal(validate(r, i).ok, false);
      c.treatment = "unknown";
      fact(i, c, "wageHandling", "I'm not sure");
      assert.equal(validate(r, i).ok, false, "Must not ask the same distinction again");
    });
    await t.test("fixed allowance recognizes contextual reimbursement intent without inventing expense purpose", () => {
      const i = input("B"), c = component("B");
      fact(i, c, "calculation", "They keep the full allowance");
      i.answers.at(-1).question = "Do employees keep the full allowance regardless of actual business miles, or is it matched up to documented miles?";
      fact(i, c, "treatment", "Kept as a reimbursement");
      i.answers.at(-1).question = "Should this allowance be included in taxable wages, or kept as a reimbursement?";
      c.treatment = "claimed-nontaxable";
      const response = { ...model("B"), components: [c], nextTopic: "purpose",
        question: "Does this allowance repay work travel expenses or provide extra pay?",
        answerFormat: { kind: "choices", options: ["Repays work travel expenses", "Provides extra pay", "I'm not sure"] },
        outstandingQuestions: ["Whether the allowance repays business expenses or provides extra pay."] };
      assert.equal(ok(response, i).next, "clarify");
      assert.equal(validateMileageEvidence(audit(response), response, i).ok, true);
      assert.equal(validate(captured(i, c), i).ok, false, "tax intent alone cannot establish expense purpose");
      const directive = { ...captured(i, c), customerSummary: "The customer said this payment should be kept as a reimbursement." };
      assert.match(validate(directive, i).correction, /including within attributed intent/);
      const unrelated = structuredClone(i);
      unrelated.answers.at(-1).question = "How do employees describe the payment?";
      assert.equal(validate(response, unrelated).ok, false, "a short answer needs its explicit tax-choice context");
      const crossed = structuredClone(i);
      crossed.answers.at(-1).id = crossed.answers.at(-1).id.replace(":allowance:", ":reimbursement:");
      const crossedResponse = structuredClone(response);
      crossedResponse.components[0].facts.at(-1).answerId = crossed.answers.at(-1).id;
      assert.equal(validate(crossedResponse, crossed).ok, false, "intent cannot cross component boundaries");
    });
    await t.test("terminal summaries distinguish per-mile and flat reimbursement without changing recommendations", () => {
      for (const [calculation, summary] of [
        ["We repay reported business miles at $0.70 per mile each month.", "You repay personal-vehicle work travel at $0.70 per reported business mile each month."],
        ["We repay a flat $200 each month.", "You repay personal-vehicle work travel with a flat $200 payment each month."],
      ]) {
        const i = input(), c = component();
        fact(i, c, "calculation", calculation);
        fact(i, c, "treatment", "We intend non-taxable reimbursement.");
        c.treatment = "claimed-nontaxable";
        const proposal = { ...captured(i, c), customerSummary: summary };
        const result = validateMileageEvidence(audit(proposal), proposal, i);
        assert.equal(result.ok, true, result.correction);
        assert.equal(result.value.mileage.customerSummary, summary);
        assert.equal(result.value.mileage.components.length, 1);
        assert.equal(result.value.mileage.recommendedRollUpType, "Reimbursement (Non-taxable Earning)");
        for (const customerSummary of [null, "", "Your information has been collected and saved.",
          "There’s nothing else for you to answer right now.", "Your payment is tax-free.",
          "Your setup is approved.", "You must report all trips.", "You repay $999 each month.",
          "Use the Reimbursement (Non-taxable Earning) Roll-Up."]) {
          assert.equal(validate({ ...proposal, customerSummary }, i).ok, false, String(customerSummary));
        }
        for (const customerSummary of [
          "You give a separate car allowance.", // invented purpose
          "You repay work travel.", // omitted known calculation
          "You repay $0.70 each month.", // wrong units, even when number is present
          "Your repayment qualifies for tax exclusion.",
        ]) {
          const bad = { ...proposal, customerSummary };
          assert.equal(validateMileageEvidence(audit(bad, [c], {
            summaryGrounded: false, impact: "The summary changes or omits active payment facts.",
          }), bad, i).ok, false);
        }
        const historyOnly = structuredClone(i);
        historyOnly.historicalAnswers.push({ id: "historical-rate", question: "Earlier rate?", answer: "$999", component: "payment" });
        assert.equal(validate({ ...proposal, customerSummary: "You repay $999 each month." }, historyOnly).ok, false);
      }
    });
    await t.test("mixed and uncertain summaries retain distinct facts and separate unknowns", () => {
      const i = input("D"), expense = component(), pay = component("C");
      expense.facts = []; pay.facts = [];
      fact(i, expense, "purpose", "We repay personal-vehicle business travel.");
      fact(i, expense, "calculation", "We repay $0.70 per reported business mile.");
      fact(i, expense, "treatment", "We intend non-taxable reimbursement.");
      expense.treatment = "claimed-nontaxable";
      fact(i, pay, "purpose", "We also provide extra mileage pay.");
      fact(i, pay, "calculation", "We pay a separate flat $200 monthly.");
      fact(i, pay, "treatment", "I'm not sure about its intended tax treatment.");
      const summary = "You repay personal-vehicle business travel at $0.70 per reported business mile. You also provide extra pay of $200 monthly.\n\nThe intended tax treatment of the extra pay is uncertain.";
      const proposal = { ...captured(i, expense), next: "pending", components: [expense, pay],
        outstandingQuestions: ["The intended treatment of extra pay is uncertain."], customerSummary: summary };
      const result = validateMileageEvidence(audit(proposal), proposal, i);
      assert.equal(result.ok, true, result.correction);
      assert.equal(result.value.mileage.customerSummary, summary);
      assert.equal(result.value.mileage.components[0].decisionRuleStatus, "recommendation_complete");
      assert.equal(result.value.mileage.components[1].recommendedRollUpType, null);
      assert.equal(validateMileageEvidence(audit(proposal, proposal.components, {
        summaryGrounded: false, impact: "The summary omitted the unknown treatment.",
      }), proposal, i).ok, false);
    });
    await t.test("documented-mile repayment rejects empty enum placeholders with actionable correction", () => {
      const request = input(), c = component();
      fact(request, c, "calculation", "Based on documented business miles at a rate");
      request.answers[1].question = "How is MILEAGE calculated for this repayment?";
      const response = { ...model(), components: [c], nextTopic: "treatment",
        question: "Should this repayment be included in taxable wages or kept as a reimbursement?",
        answerFormat: { kind: "choices", options: ["Included in taxable wages", "Kept as a reimbursement", "I'm not sure"] },
        reason: "The intended treatment helps identify the proposed setup.",
        outstandingQuestions: ["Confirm the intended treatment."] };
      const placeholders = ["allowance", "compensation", "informational", "noncash", "unknown"].map(id => ({
        id, purpose: "unknown", treatment: "unknown", presentation: "unknown", specialReporting: "unknown", facts: [],
      }));
      const bad = { ...response, components: [c, ...placeholders] };
      const rejected = validate(bad, request);
      assert.equal(rejected.ok, false);
      assert.match(rejected.correction, /Unsupported component ids: allowance, compensation, informational, noncash/);
      assert.match(rejected.correction, /Remove unused placeholder components entirely/);
      assert.equal(validateMileageEvidence(audit(bad), response, request).ok, false);
      assert.equal(ok(response, request).next, "clarify");
      assert.equal(validateMileageEvidence(audit(response), response, request).ok, true);
      assert.equal(bad.components.length, 6, "validation must not silently remove unsupported data");
    });
    await t.test("flat calculation preserves the selected reimbursement purpose and asks missing treatment", () => {
      const request = input();
      const c = component();
      fact(request, c, "calculation", "Based on a flat amount or allowance.");
      request.answers[1].question = "How is MILEAGE calculated for these reimbursements?";
      const response = { ...model(), components: [c], nextTopic: "treatment",
        question: "Should this payment be included in taxable wages or kept as a reimbursement?",
        answerFormat: { kind: "choices", options: ["Included in taxable wages", "Kept as a reimbursement", "I'm not sure"] },
        reason: "Your intended treatment helps identify the proposed setup.",
        outstandingQuestions: ["Confirm the intended treatment."] };
      assert.equal(ok(response, request).next, "clarify");
      assert.equal(validateMileageEvidence(audit(response), response, request).ok, true);
      const unsupported = { ...response, nextComponent: "allowance", components: [
        c, { ...component("B"), facts: [c.facts[1]] },
      ] };
      assert.equal(validate(unsupported, request).ok, false);
      assert.ok(MILEAGE_INSTRUCTIONS.includes("That calculation does not confirm a second allowance purpose"));
    });
    await t.test("sources survive unchanged; effective discovery excludes superseded source instructions", async () => {
      assert.equal(await readFile(path.join(root, "docs/earning-prompts/knowledge/mileage-v1.json"), "utf8"),
        await readFile(path.join(root, "attached_assets/UKG_Ready_MILEAGE_Knowledge_Base_1792424981223.json"), "utf8"));
      const prompt = await readFile(path.join(root, "docs/earning-prompts/sources/mileage-question-builder.txt"), "utf8");
      assert.equal(prompt, await readFile(path.join(root, "attached_assets/Pasted--UKG-Ready-MILEAGE-Earnings-Code-Self-Service-Question-_1792424442002.txt"), "utf8"));
      assert.ok(!MILEAGE_INSTRUCTIONS.includes(prompt));
      assert.ok(!MILEAGE_INSTRUCTIONS.includes(JSON.stringify(kb)));
      assert.ok(MILEAGE_INSTRUCTIONS.includes(MILEAGE_PRODUCT_REFERENCE));
      assert.match(MILEAGE_INSTRUCTIONS, /minimum facts for conditional Roll-Up selection/);
      assert.match(MILEAGE_INSTRUCTIONS, /COMPLETE active conversation/);
      assert.deepEqual(MILEAGE_KNOWLEDGE, kb);
      for (const r of [...kb.roll_up_types, ...kb.product_dependencies]) assert.ok(kb.source_documents.some(s => s.id === r.source));
    });
    await t.test("reported-miles reimbursement choice accepts explicit payroll intent without requiring choices in the question", () => {
      const i = input(), c = component();
      fact(i, c, "calculation", "Reported business miles at a rate");
      i.answers.at(-1).question = "How do you calculate this mileage repayment?";
      fact(i, c, "treatment", "Keep it as a reimbursement");
      i.answers.at(-1).question = "For this reported-miles payment, how do you intend to treat it in payroll?";
      c.treatment = "claimed-nontaxable";
      const proposal = { ...captured(i, c),
        customerSummary: "You repay personal-vehicle work travel using reported business miles at a rate." };
      const result = validateMileageEvidence(audit(proposal), proposal, i);
      assert.equal(result.ok, true, result.correction);
      assert.equal(result.value.mileage.recommendedRollUpType, "Reimbursement (Non-taxable Earning)");
      assert.equal(result.value.mileage.taxTreatmentVerificationStatus, "pending-independent-validation");
      for (const question of ["How do you describe this payment?", "How do you intend to calculate this in payroll?", "How do you intend to use MILEAGE?"]) {
        const unrelated = structuredClone(i);
        unrelated.answers.at(-1).question = question;
        assert.equal(validate(proposal, unrelated).ok, false, question);
      }
      const history = structuredClone(i);
      history.historicalAnswers.push(history.answers.pop());
      assert.equal(validate(proposal, history).ok, false);
      const crossed = structuredClone(i), crossedProposal = structuredClone(proposal);
      crossed.answers.at(-1).id = crossed.answers.at(-1).id.replace(":reimbursement:", ":allowance:");
      crossedProposal.components[0].facts.at(-1).answerId = crossed.answers.at(-1).id;
      assert.equal(validate(crossedProposal, crossed).ok, false);
    });
    await t.test("short reimbursement intent uses its tax question context without asserting tax eligibility", () => {
      const i = input(), c = component();
      fact(i, c, "calculation", "Business miles at a set rate");
      i.answers.at(-1).question = "How is the mileage payment calculated?";
      fact(i, c, "treatment", "Kept as a reimbursement");
      i.answers.at(-1).question = "Is this mileage payment meant to be included in taxable wages, or kept as a reimbursement?";
      c.treatment = "claimed-nontaxable";
      const proposal = captured(i, c);
      const result = ok(proposal, i);
      assert.equal(result.mileage.captured, true);
      assert.equal(result.mileage.recommendedRollUpType, "Reimbursement (Non-taxable Earning)");
      assert.equal(result.mileage.decisionStatus, "Recommendation Complete");
      assert.equal(result.mileage.taxTreatmentVerificationStatus, "pending-independent-validation");
      assert.equal(validateMileageEvidence(audit(proposal), proposal, i).ok, true);
      const wrongContext = structuredClone(i);
      wrongContext.answers.at(-1).question = "What kind of payment is this?";
      assert.equal(validate(proposal, wrongContext).ok, false);
      const uncertain = structuredClone(i);
      uncertain.answers.at(-1).answer = "I'm not sure";
      const uncertainProposal = structuredClone(proposal);
      uncertainProposal.components[0].facts.at(-1).quote = "I'm not sure";
      assert.equal(validate(uncertainProposal, uncertain).ok, false);
      const history = structuredClone(i);
      history.historicalAnswers.push(history.answers.pop());
      assert.equal(validate(proposal, history).ok, false);
      const otherComponent = structuredClone(i);
      otherComponent.answers.at(-1).id = `${policy}:2:allowance:treatment`;
      const crossScope = structuredClone(proposal);
      crossScope.components[0].facts.at(-1).answerId = otherComponent.answers.at(-1).id;
      assert.equal(validate(crossScope, otherComponent).ok, false);
    });
    for (const choice of ["A", "B", "C", "D", "E", "F"]) await t.test(`${choice}: purpose first, no default treatment`, () => {
      assert.equal(validMileageInput(input(choice)), true);
      const result = ok(model(choice), input(choice));
      assert.equal(result.mileage.recommendedRollUpType, null);
      assert.equal(result.mileage.decisionStatus, "Pending Verification");
      assert.equal(result.mileage.outputStatus, "Additional Clarification Needed");
      assert.deepEqual(result.mileage.knownGaps, kb.known_gaps);
      assert.equal(validate(captured(input(choice), component(choice)), input(choice)).ok, false);
    });
    await t.test("ordinary compensation is only a conditional Regular candidate; supplemental stays null", () => {
      const i = input("C"), c = component("C");
      fact(i, c, "calculation", "Miles driven multiplied by the agreed pay rate.");
      fact(i, c, "treatment", "We treat it as ordinary taxable compensation.");
      c.treatment = "ordinary-taxable";
      const result = ok(captured(i, c), i).mileage;
      assert.equal(result.recommendedRollUpType, "Regular");
      assert.equal(result.components[0].decisionRuleStatus, "recommendation_complete");
      assert.equal(result.outputStatus, "Recommendation complete");
      assert.equal(result.decisionStatus, "Recommendation Complete");
      for (const subject of ["net pay", "taxes", "pay statement", "W-2", "GL", "downstream reports"])
        assert.ok(result.implementationSafeguards.some(q => q.includes(subject)));
      c.facts.pop(); i.answers.pop();
      fact(i, c, "treatment", "We treat it as taxable supplemental compensation.");
      c.treatment = "supplemental-taxable";
      const supplemental = ok(captured(i, c), i).mileage;
      assert.equal(supplemental.recommendedRollUpType, null);
      assert.equal(supplemental.components[0].decisionRuleStatus, "pending_documentation_verification");
    });
    await t.test("wage-handling evidence alone does not silently satisfy missing treatment", () => {
      const i = input("C"), c = component("C");
      fact(i, c, "calculation", "We pay $1 per mile.");
      fact(i, c, "wageHandling", "We intend ordinary taxable wages.");
      c.treatment = "ordinary-taxable";
      const rejected = validate(captured(i, c), i);
      assert.equal(rejected.ok, false);
      assert.match(rejected.correction, /also retain the exact supported statement as a treatment-topic fact/);
      c.facts.push({ ...c.facts.at(-1), topic: "treatment" });
      assert.equal(validateMileageEvidence(audit(captured(i, c)), captured(i, c), i).ok, true);
    });
    await t.test("text requests and incomplete taxable intent keep distinct supported next questions", () => {
      const other = model("F");
      other.question = "Describe how you use MILEAGE and include a representative payment example.";
      other.answerFormat = { kind: "text", options: null };
      other.nextTopic = "example";
      assert.equal(ok(other, input("F")).next, "clarify");
      const i = input("C"), c = component("C");
      fact(i, c, "calculation", "We pay a dollar for each mile driven.");
      fact(i, c, "treatment", "We treat the full amount as taxable.");
      const r = { ...model("C"), components: [c], nextTopic: "wageHandling",
        question: "Is this treated as ordinary wages or supplemental pay?" };
      assert.equal(ok(r, i).mileage.recommendedRollUpType, null);
      assert.equal(validate({ ...r, nextTopic: "treatment" }, i).ok, false);
      fact(i, c, "wageHandling", "We treat it as ordinary taxable wages.");
      c.treatment = "ordinary-taxable";
      assert.equal(ok(captured(i, c), i).mileage.recommendedRollUpType, "Regular");
      const copy = { ...model(), question: "Do people submit mileage records?" };
      assert.match(validate(copy, input()).correction, /submit.*record|record.*submit/);
    });
    await t.test("three reimbursement facts retain the primary documented candidate without legal qualification or checklist answers", () => {
      const i = input(), c = component();
      fact(i, c, "calculation", "Documented business miles multiplied by our rate.");
      fact(i, c, "treatment", "We intend these payments to be non-taxable reimbursements.");
      c.treatment = "claimed-nontaxable";
      const result = ok(captured(i, c), i).mileage;
      assert.equal(i.answers.length, 3);
      assert.equal(result.captured, true);
      assert.equal(result.recommendedRollUpType, "Reimbursement (Non-taxable Earning)");
      assert.equal(result.components[0].presentation, "unknown");
      assert.equal(result.components[0].specialReporting, "unknown");
      assert.equal(result.decisionStatus, "Recommendation Complete");
      assert.equal(result.taxTreatmentVerificationStatus, "pending-independent-validation");
      assert.equal(result.documentationVerification, "supplied-citations-only");
      assert.equal(result.tenantVerification, "not-inspected");
      assert.equal(result.payrollValidation, "not-performed");
      for (const term of ["substantiation", "reconciliation", "excess advances", "legal qualification", "authorization"])
        assert.ok(result.implementationSafeguards.some(q => q.toLowerCase().includes(term)), term);
      assert.deepEqual(result.outstandingQuestions, []);
      assert.match(result.components[0].selectionRationale, /business miles.*non-taxable/i);
      assert.deepEqual(result.components[0].documentationEvidence, [{
        source: "S1", behavior: "Displayed as earning; not taxed; adds to employee net pay.",
      }]);
      for (const topic of ["mileageDetails", "qualification", "reconciliation", "excess", "retention", "presentation"]) {
        const unnecessary = { ...model(), components: [c], nextTopic: topic, question: "What else should we know?" };
        assert.equal(validate(unnecessary, i).ok, false, topic);
      }
      const uncertain = structuredClone(c);
      uncertain.treatment = "unknown";
      assert.equal(validate(captured(i, uncertain), i).ok, false);
      const missingCalculation = structuredClone(c);
      missingCalculation.facts = missingCalculation.facts.filter(f => f.topic !== "calculation");
      assert.equal(validate(captured(i, missingCalculation), i).ok, false);
    });
    await t.test("one answer supplies multiple independently grounded facts; dropped evidence cannot restore paraphrases", () => {
      const i = input(), c = component();
      const text = "We repay personal-vehicle business travel using documented business miles multiplied by a rate. We intend it as non-taxable.";
      fact(i, c, "calculation", text);
      c.facts.push({ ...c.facts.at(-1), topic: "treatment" });
      c.treatment = "claimed-nontaxable";
      const complete = captured(i, c);
      const result = validateMileageEvidence(audit(complete), complete, i);
      assert.equal(result.ok, true, result.correction);
      assert.equal(result.value.mileage.recommendedRollUpType, "Reimbursement (Non-taxable Earning)");
      const dropped = component();
      for (const [topic, question, semantic] of [
        ["calculation", "Do you multiply business miles by your rate?", "calculation"],
        ["example", "Are the payments intended to be outside taxable wages?", "treatment"],
        ["mileageDetails", "Are these work trips in personal cars?", "purpose"],
      ]) {
        const r = { ...model(), components: [dropped], nextTopic: topic, question };
        // The calculation identity is already blocked; relabeled topics previously slipped through.
        if (topic === "example") assert.equal(validate(r, i).ok, true, "The independent evidence check must catch relabeled treatment");
        const checked = validateMileageEvidence(audit(r, [c], {
          questionTopic: semantic, questionStatus: "already-answered",
        }), r, i);
        assert.equal(checked.ok, false, question);
      }
      const terminalOmission = captured(i, { ...c, facts: c.facts.filter(f => f.topic !== "treatment"), treatment: "unknown" });
      assert.equal(validateMileageEvidence(audit(terminalOmission, [c]), terminalOmission, i).ok, false);
    });
    await t.test("successive turns keep earlier facts, corrections supersede them, and unrelated evidence cannot supply facts", () => {
      const i = input(), c = component();
      fact(i, c, "calculation", "We multiply business miles by our rate.");
      const calculation = c.facts.at(-1);
      const follow = { ...model(), question: "How do you intend to treat these payments for taxes?",
        nextTopic: "treatment", components: [c] };
      assert.equal(validateMileageEvidence(audit(follow), follow, i).ok, true);
      fact(i, c, "treatment", "We intend this to be non-taxable."); c.treatment = "claimed-nontaxable";
      assert.equal(validateMileageEvidence(audit(captured(i, c)), captured(i, c), i).ok, true);
      const lost = { ...c, facts: c.facts.filter(f => f !== calculation) };
      assert.equal(validateMileageEvidence(audit(captured(i, lost), [c]), captured(i, lost), i).ok, false);
      const forged = structuredClone(c); forged.facts.at(-1).answerId = "another-company";
      assert.equal(validateMileageEvidence(audit(captured(i, c), [forged]), captured(i, c), i).ok, false);
      fact(i, c, "example", "Correction: this is ordinary taxable pay, not the earlier treatment.");
      c.facts.at(-1).topic = "treatment";
      const corrected = { ...c, treatment: "ordinary-taxable", facts: c.facts.filter(f => f.topic !== "treatment" || f === c.facts.at(-1)) };
      assert.equal(validateMileageEvidence(audit(captured(i, corrected)), captured(i, corrected), i).ok, true);
      assert.equal(validateMileageEvidence(audit(captured(i, c), [corrected]), captured(i, c), i).ok, false);
    });
    await t.test("contradiction gets one relevant clarification, uncertainty stays named pending, and components stay independent", () => {
      const i = input(), c = component();
      fact(i, c, "calculation", "We multiply business miles by our rate.");
      fact(i, c, "treatment", "We intend it as non-taxable.");
      fact(i, c, "example", "Our payroll owner says this is ordinary taxable pay.");
      c.facts.at(-1).topic = "treatment";
      const clarify = { ...model(), components: [c], nextTopic: "treatment",
        question: "Which tax treatment should apply to this repayment?" };
      assert.equal(validateMileageEvidence(audit(clarify), clarify, i).ok, true);
      fact(i, c, "treatment", "I'm not sure which treatment applies.", "Unknown");
      assert.equal(validateMileageEvidence(audit(clarify), clarify, i).ok, false);
      const pending = { ...captured(i, c), next: "pending", outstandingQuestions: ["Confirm intended tax treatment with your payroll owner."] };
      assert.equal(validateMileageEvidence(audit(pending), pending, i).ok, true);
      const mixed = input("D"), expense = component(), allowance = component("B");
      expense.facts = []; allowance.facts = [];
      fact(mixed, expense, "purpose", "We repay business vehicle costs.");
      fact(mixed, expense, "calculation", "We multiply business miles by a rate.");
      fact(mixed, allowance, "purpose", "We also give a fixed car allowance.");
      const r = { ...model(), components: [expense, allowance], nextComponent: "allowance" };
      assert.equal(validateMileageEvidence(audit(r), r, mixed).ok, true);
      const misplaced = structuredClone(allowance); misplaced.facts.push(expense.facts.at(-1));
      assert.equal(validateMileageEvidence(audit({ ...r, components: [expense, misplaced] }, [expense, allowance]),
        { ...r, components: [expense, misplaced] }, mixed).ok, false);
    });
    await t.test("semantic check rejects compliance disguised as examples, but permits a genuinely missing display requirement", () => {
      const i = input(), c = component();
      fact(i, c, "calculation", "Documented business miles multiplied by our rate.");
      fact(i, c, "treatment", "We intend it as non-taxable."); c.treatment = "claimed-nontaxable";
      const unnecessary = { ...model(), nextTopic: "example", question: "How are excess advances returned?" };
      assert.equal(validateMileageEvidence(audit(unnecessary, [c], {
        questionTopic: "excess", questionStatus: "internal-safeguard",
      }), unnecessary, i).ok, false);
      fact(i, c, "example", "We are not sure whether we need a negative deduction on the pay statement.");
      c.facts.at(-1).topic = "presentation";
      const display = { ...model(), components: [c], nextTopic: "presentation",
        question: "Does this need to appear as a negative deduction?" };
      assert.equal(validateMileageEvidence(audit(display), display, i).ok, true);
      fact(i, c, "presentation", "We need a negative deduction on the pay statement.");
      c.presentation = "negative-deduction";
      const resolved = { ...c, facts: c.facts.filter(f => f.topic !== "presentation" || f === c.facts.at(-1)) };
      assert.equal(validateMileageEvidence(audit(captured(i, resolved)), captured(i, resolved), i).ok, true);
      assert.equal(validateMileageEvidence(audit(display, [resolved], { questionStatus: "already-answered" }), display, i).ok, false);
    });
    await t.test("material display and W-2 requirements may change the conditional candidate without compliance prerequisites", () => {
      const i = input(), c = component();
      fact(i, c, "calculation", "Documented business miles multiplied by our rate.");
      fact(i, c, "treatment", "We intend it as a non-taxable reimbursement.");
      c.treatment = "claimed-nontaxable";
      fact(i, c, "example", "We need a different display but are not sure whether it must be a negative deduction.");
      c.facts.at(-1).topic = "presentation";
      const display = { ...model(), components: [c], nextTopic: "presentation",
        question: "Does this reimbursement need to appear as a negative deduction?" };
      assert.equal(ok(display, i).next, "clarify");
      fact(i, c, "presentation", "We need a negative deduction on the pay statement.");
      c.presentation = "negative-deduction";
      assert.equal(ok(captured(i, c), i).mileage.recommendedRollUpType, "Reimbursement (Display as Negative Deduction)");
      fact(i, c, "reporting", "We need special W-2 reporting.");
      c.specialReporting = "yes";
      assert.equal(ok(captured(i, c), i).mileage.recommendedRollUpType, "Custom Reimbursement");
    });
    await t.test("reimbursement retains conditional presentation candidates and all gaps", () => {
      const i = input(), c = component();
      for (const [topic, answer] of Object.entries({
        calculation: "Documented business miles multiplied by our rate.",
        mileageDetails: "Business miles, dates and purpose are checked.",
        reconciliation: "We reconcile advances to the business-mile details.",
        excess: "Excess advances must be returned.",
        treatment: "Our company treats it as non-taxable.",
        qualification: "Our payroll owner has confirmed the reported tax qualification.",
        presentation: "We want the payment shown as an earning.",
      })) fact(i, c, topic, answer);
      c.treatment = "claimed-nontaxable"; c.presentation = "earning";
      let result = ok(captured(i, c), i).mileage;
      assert.equal(result.recommendedRollUpType, "Reimbursement (Non-taxable Earning)");
      assert.equal(result.components[0].decisionRuleStatus, "recommendation_complete");
      assert.equal(result.taxTreatmentVerificationStatus, "pending-independent-validation");
      c.presentation = "negative-deduction"; c.facts.pop(); i.answers.pop();
      fact(i, c, "presentation", "We want a negative deduction on the pay statement.");
      result = ok(captured(i, c), i).mileage;
      assert.equal(result.recommendedRollUpType, "Reimbursement (Display as Negative Deduction)");
      fact(i, c, "reporting", "Our payroll team says special W-2 reporting is needed; details need review.");
      c.specialReporting = "yes";
      result = ok(captured(i, c), i).mileage;
      assert.equal(result.recommendedRollUpType, "Custom Reimbursement");
      assert.equal(result.components[0].decisionRuleStatus, "pending_documentation_and_test");
      assert.ok(result.knownGaps.includes(kb.known_gaps[0]));
    });
    await t.test("ordinary taxable allowance needs no compliance checklist; mixed keeps component-specific evidence", () => {
      const i = input("B"), c = component("B");
      fact(i, c, "calculation", "A fixed monthly allowance.");
      fact(i, c, "treatment", "We include this as ordinary taxable pay."); c.treatment = "ordinary-taxable";
      assert.equal(ok(captured(i, c), i).mileage.decisionStatus, "Recommendation Complete");
      fact(i, c, "retention", "People keep the full allowance.");
      fact(i, c, "reconciliation", "We do not reconcile it against miles.");
      fact(i, c, "excess", "Any excess is kept by the employee.");
      assert.equal(ok(captured(i, c), i).mileage.recommendedRollUpType, "Regular");
      const mixed = input("D"), expense = component("A"), pay = component("C");
      expense.facts = []; pay.facts = [];
      fact(mixed, expense, "purpose", "We reimburse actual business mileage.");
      fact(mixed, pay, "purpose", "We also pay extra mileage-based compensation.");
      fact(mixed, expense, "sharedCode", "Both currently use MILEAGE.");
      const m = { ...model("D"), components: [expense, pay], nextComponent: "reimbursement" };
      const result = ok(m, mixed).mileage;
      assert.equal(result.components.length, 2);
      assert.equal(result.recommendedRollUpType, null);
      assert.equal(result.separateEarningsCodesRequired, "Unknown");
      assert.ok(result.outstandingQuestions.some(q => q.includes("treatment")));
    });
    await t.test("Memo and noncash fringe need explicit purpose evidence; never ordinary cash", () => {
      const i = input("F"), c = component("F");
      c.id = "informational"; c.facts = [];
      fact(i, c, "purpose", "We only track mileage for information.");
      fact(i, c, "informational", "It is informational only with no pay or tax effect.");
      fact(i, c, "treatment", "No pay or tax effect."); c.treatment = "no-payroll-effect";
      fact(i, c, "example", "For example, 40 miles are tracked without paying anything.");
      assert.equal(ok(captured(i, c), i).mileage.recommendedRollUpType, "Memo");
      c.id = "noncash";
      assert.equal(validate(captured(i, c), i).ok, false);
      c.facts = [];
      fact(i, c, "purpose", "This is a noncash taxable vehicle benefit.");
      fact(i, c, "noncash", "A noncash benefit, not a cash mileage payment.");
      fact(i, c, "treatment", "Ordinary taxable noncash benefit."); c.treatment = "ordinary-taxable";
      fact(i, c, "example", "For example, personal use of a company vehicle.");
      assert.equal(ok(captured(i, c), i).mileage.recommendedRollUpType, "Custom Taxable Fringe");
    });
    await t.test("mixed purposes retain a completed reimbursement beside an unresolved supplemental selection", () => {
      const i = input("D"), expense = component(), pay = component("C");
      expense.facts = []; pay.facts = [];
      fact(i, expense, "purpose", "We repay employees for business mileage.");
      fact(i, expense, "calculation", "Documented business miles at our rate.");
      fact(i, expense, "treatment", "Intended as non-taxable reimbursement.");
      expense.treatment = "claimed-nontaxable";
      fact(i, pay, "purpose", "We also provide extra mileage pay.");
      fact(i, pay, "calculation", "A separate amount for each mile.");
      fact(i, pay, "treatment", "We intend this portion as taxable supplemental pay.");
      pay.treatment = "supplemental-taxable";
      const result = ok({ ...captured(i, expense), components: [expense, pay] }, i).mileage;
      assert.equal(result.decisionStatus, "Pending Verification");
      assert.equal(result.recommendedRollUpType, null);
      assert.equal(result.components[0].decisionRuleStatus, "recommendation_complete");
      assert.deepEqual(result.components[0].outstandingQuestions, []);
      assert.equal(result.components[1].recommendedRollUpType, null);
      assert.match(result.outstandingQuestions.join(" "), /supplemental/);
      assert.doesNotMatch(result.outstandingQuestions.join(" "), /tenant|payroll testing|independently reviewed/);
    });
    await t.test("indicated unresolved display blocks completion but absent display does not", () => {
      const i = input(), c = component();
      fact(i, c, "calculation", "Documented business miles at our rate.");
      fact(i, c, "treatment", "Intended as non-taxable reimbursement.");
      c.treatment = "claimed-nontaxable";
      fact(i, c, "example", "We are not sure whether we need a negative deduction.");
      c.facts.at(-1).topic = "presentation";
      assert.equal(validate(captured(i, c), i).ok, false);
      const result = ok({ ...captured(i, c), next: "pending",
        outstandingQuestions: ["Confirm whether the payment needs to appear as a negative deduction."] }, i).mileage;
      assert.equal(result.decisionStatus, "Pending Verification");
      assert.match(result.outstandingQuestions.join(" "), /presentation|negative deduction/);
    });
    await t.test("tax uncertainty volunteered under calculation does not falsely answer calculation", () => {
      const i = input(), c = component();
      fact(i, c, "calculation", "We are not sure whether this should be treated as taxable pay or a non-taxable reimbursement.");
      c.facts.at(-1).topic = "treatment";
      const r = { ...model(), components: [c], question: "How is MILEAGE calculated for those trips?" };
      assert.equal(validateMileageEvidence(audit(r), r, i).ok, true);
      const pending = { ...captured(i, c), next: "pending",
        outstandingQuestions: ["Confirm how this payment is calculated and its intended tax treatment."] };
      assert.equal(ok(pending, i).mileage.decisionStatus, "Pending Verification");
      fact(i, c, "calculation", "Documented business miles multiplied by our rate.");
      const repeated = { ...model(), components: [c], nextTopic: "treatment",
        question: "Should this be taxable pay or a non-taxable reimbursement?" };
      assert.match(validate(repeated, i).correction, /already expressed uncertainty/);
      assert.equal(ok(pending, i).mileage.decisionStatus, "Pending Verification");
    });
    await t.test("skip-known, relevant reporting, fabricated citations/verification and old-purpose isolation", () => {
      const i = input(), r = model();
      fact(i, r.components[0], "calculation", "Business miles at a rate.");
      assert.equal(validate(r, i).ok, false);
      assert.equal(validate({ ...model(), nextTopic: "presentation" }, input()).ok, false);
      assert.equal(validate({ ...model(), nextTopic: "reporting", question: "What W-2 reporting do you need?" }, input()).ok, false);
      for (const key of ["decisionStatus", "outputStatus", "sourceId", "recommendedRollUpType"])
        assert.equal(validate({ ...model(), [key]: "Verified" }, input()).ok, false);
      const invented = model(); invented.components[0].facts[0].answerId = "invented";
      assert.equal(validate(invented, input()).ok, false);
      const forged = model(); forged.components[0].treatment = "ordinary-taxable";
      assert.equal(validate(forged, input()).ok, false);
      assert.equal(validMileageInput({ ...input(), answers: [{ ...input().answers[0], id: "method" }] }), false);
    });
    await t.test("uncertainty and the question bound retain named unresolved work", () => {
      const i = input("E"), c = component("E");
      fact(i, c, "purpose", "I'm not sure how employees receive it.", "Unknown");
      const pending = { ...captured(i, c), next: "pending", outstandingQuestions: ["Ask your payroll owner how this payment is received."] };
      assert.equal(ok(pending, i).mileage.captured, false);
      const capped = input("A");
      for (let n = 1; n <= 18; n++) capped.answers.push({ id: `${policy}:${n}:payment:example`, question: `Earlier question ${n}?`, answer: "Unknown" });
      assert.equal(validate(model(), capped).ok, true);
      assert.equal(ok({ ...captured(capped, component()), next: "pending", outstandingQuestions: ["Confirm calculation with your payroll owner."] }, capped).mileage.decisionStatus, "Pending Verification");
    });
  } finally { await rm(temp, { recursive: true, force: true }); }
});

test("MILEAGE live route uses bounded correction, preserves recovery, and isolates cached versions", async t => {
  const temp = await mkdtemp(path.join(directory, ".mileage-route-"));
  const servers = [];
  const listen = app => new Promise(resolve => { const server = app.listen(0, "127.0.0.1", () => resolve(`http://127.0.0.1:${server.address().port}`)); servers.push(server); });
  let mode = "ok", calls = 0;
  const bodies = [];
  const semanticInput = input(), semanticComponent = component();
  fact(semanticInput, semanticComponent, "calculation", "We multiply documented business miles by our rate. We intend this as non-taxable.");
  semanticComponent.facts.push({ ...semanticComponent.facts.at(-1), topic: "treatment" });
  semanticComponent.treatment = "claimed-nontaxable";
  try {
    const fake = express(); fake.use(express.json());
    fake.post("/chat/completions", async (req, res) => {
      calls++; bodies.push(req.body);
      if (mode === "timeout") await new Promise(r => setTimeout(r, 200));
      if (mode === "provider-retry") return res.status(429).json({ error: { message: "Fixture limited" } });
      if (mode === "unavailable") return res.status(400).json({ error: { message: "Fixture unavailable" } });
      const isAudit = req.body.response_format.json_schema.name === "mileage_evidence";
      if (mode === "audit-timeout" && isAudit || mode === "repair-timeout" && req.body.messages.length > 2)
        await new Promise(r => setTimeout(r, 200));
      const raw = isAudit ? (() => {
        const proposal = JSON.parse(req.body.messages[1].content).proposedReview;
        if (mode === "audit-bad") return { invalid: true };
        if (mode.startsWith("semantic")) return {
          summaryGrounded: true,
          components: [semanticComponent], questionTopic: proposal.next === "clarify" ? "treatment" : null,
          questionComponent: proposal.next === "clarify" ? "reimbursement" : null,
          questionStatus: proposal.next === "clarify" ? "already-answered" : "none",
          impact: "Tax intent was already provided in the calculation answer.",
        };
        return { summaryGrounded: true, components: proposal.components, questionTopic: proposal.nextTopic, questionComponent: proposal.nextComponent,
          questionStatus: "missing-material", impact: "Calculation distinguishes repayment from extra compensation." };
      })() : mode.startsWith("semantic")
        ? mode === "semantic-correct" && req.body.messages.length > 2 ? captured(semanticInput, semanticComponent)
          : { ...model(), nextTopic: "example", question: "Are these payments intended to be outside taxable wages?" }
        : mode === "bad" || ["correct", "repair-timeout"].includes(mode) && req.body.messages.length === 2 ? { invalid: true } : model();
      res.json({ choices: [{ message: { content: JSON.stringify(raw) } }] });
    });
    const baseURL = await listen(fake);
    await build({ ...options, entryPoints: [path.join(directory, "earningMileageReviews.ts")], outfile: path.join(temp, "route.mjs"),
      plugins: [{ name: "fake-provider", setup(b) {
        b.onLoad({ filter: /earningAI\.ts$/ }, () => ({ loader: "ts", contents:
          `import OpenAI from "openai"; export const errorSummary=()=>({kind:"fixture"}); export const createOpenAIClient=()=>new OpenAI({apiKey:"fixture",baseURL:${JSON.stringify(baseURL)},maxRetries:1});` }));
      } }] });
    const { createEarningMileageReviewsRouter } = await import(path.join(temp, "route.mjs"));
    const app = express(); app.use(express.json()); app.use((req, _res, next) => { req.log = { error() {}, warn() {} }; next(); });
    app.use(createEarningMileageReviewsRouter({ timeoutMs: 150, proposalMs: 100, auditMs: 100, minimumStageMs: 1 }));
    const api = await listen(app);
    const post = async body => { const r = await fetch(`${api}/earnings/mileage-reviews`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }); return { status: r.status, body: await r.json() }; };
    assert.equal((await post(input())).status, 200);
    assert.ok(bodies[0].messages[0].content.includes(JSON.stringify(kb.roll_up_types)));
    assert.ok(!bodies[1].messages[0].content.includes("Generate one grounded"));
    assert.ok(bodies[1].messages[0].content.includes("Independently audit"));
    assert.equal((await post({ ...input(), policyVersion: "retired" })).status, 400);
    assert.equal((await post({ ...input(), code: "CELL" })).status, 400);
    mode = "correct"; let before = calls; assert.equal((await post(input())).status, 200); assert.equal(calls - before, 3);
    mode = "bad"; before = calls;
    const bad = await post(input()); assert.equal(bad.body.code, "invalid_response"); assert.equal(calls - before, 2); assert.equal(bad.body.mileage, undefined);
    mode = "semantic-repeat"; before = calls;
    const repeat = await post(semanticInput);
    assert.equal(repeat.status, 502); assert.equal(repeat.body.code, "invalid_response");
    assert.equal(calls - before, 4, "One proposal plus one grounded check per bounded attempt");
    assert.equal(repeat.body.mileage, undefined);
    assert.deepEqual(JSON.parse(bodies.at(-1).messages[1].content).conversation.answers, semanticInput.answers);
    mode = "semantic-correct"; before = calls;
    const corrected = await post(semanticInput);
    assert.equal(corrected.status, 200); assert.equal(calls - before, 4);
    assert.equal(corrected.body.mileage.captured, true);
    assert.equal(corrected.body.mileage.recommendedRollUpType, "Reimbursement (Non-taxable Earning)");
    mode = "audit-bad"; before = calls;
    assert.equal((await post(input())).body.code, "invalid_response"); assert.equal(calls - before, 4);
    mode = "timeout"; assert.equal((await post(input())).body.code, "timed_out");
    for (const timeoutMode of ["audit-timeout", "repair-timeout"]) {
      mode = timeoutMode; before = calls;
      const failed = await post(input());
      assert.equal(failed.body.code, "timed_out");
      assert.equal(failed.body.mileage, undefined);
      assert.equal(calls - before, 2, "No call after a timed-out stage");
    }
    mode = "provider-retry"; before = calls;
    assert.equal((await post(input())).body.code, "unavailable");
    assert.equal(calls - before, 1, "MILEAGE overrides the shared SDK retry policy");
    const tight = express(); tight.use(express.json());
    tight.use((req, _res, next) => { req.log = { error() {}, warn() {} }; next(); });
    tight.use(createEarningMileageReviewsRouter({ timeoutMs: 10, minimumStageMs: 9 }));
    const tightUrl = await listen(tight);
    before = calls;
    const noBudget = await fetch(`${tightUrl}/earnings/mileage-reviews`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(input()),
    });
    assert.equal(noBudget.status, 504);
    assert.equal(calls, before, "Do not propose without budget for independent review");
    mode = "timeout"; before = calls;
    const cancel = new AbortController();
    const abandoned = fetch(`${api}/earnings/mileage-reviews`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(input()), signal: cancel.signal,
    });
    while (calls === before) await new Promise(r => setTimeout(r, 1));
    cancel.abort();
    await assert.rejects(abandoned);
    await new Promise(r => setTimeout(r, 220));
    assert.equal(calls - before, 1, "Disconnect prevents an audit or repair");
    mode = "unavailable"; assert.equal((await post(input())).body.code, "unavailable");
  } finally {
    for (const s of servers) { s.closeAllConnections(); await new Promise(r => s.close(r)); }
    await rm(temp, { recursive: true, force: true });
  }
});
