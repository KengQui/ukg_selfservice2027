import { Router, type IRouter } from "express";
import type OpenAI from "openai";
import { ReviewShiftPremiumBody, type EarningCheckError } from "@workspace/api-zod";
import { createOpenAIClient, errorSummary } from "../lib/earningAI";
import { SHIFT_PREMIUM_INSTRUCTIONS, SHIFT_PREMIUM_SCHEMA, SHIFT_PREMIUM_TURN_LIMIT, buildShiftPremiumMessage, validateShiftPremium } from "../lib/earningShiftPremium";

// Orval's object schemas strip extra keys by default; enforce additionalProperties:false here.
const BODY = ReviewShiftPremiumBody.extend({
  source: ReviewShiftPremiumBody.shape.source.strict(),
  teamAnswer: ReviewShiftPremiumBody.shape.teamAnswer.strict(),
  reference: ReviewShiftPremiumBody.shape.reference.strict(),
  existingCodes: ReviewShiftPremiumBody.shape.existingCodes.element.strict().array().min(1).max(10),
  thread: ReviewShiftPremiumBody.shape.thread.element.strict().array().max(SHIFT_PREMIUM_TURN_LIMIT),
}).strict();
const ERRORS = {
  invalid_request: "We couldn’t check these codes. Check your answer, then try again.",
  rate_limited: "We’ve checked a lot of answers in the last minute. Wait a minute, then try again.",
  unavailable: "We can’t compare these codes right now. Try again, or select Review later.",
  timed_out: "Comparing these codes took too long. Try again, or select Review later.",
  invalid_response: "We couldn’t compare these codes this time. Try again, or select Review later.",
} as const satisfies Record<EarningCheckError["code"], string>;

/** Request text is never logged. An unavailable or unusable review never becomes a stand-in recommendation. */
export function createEarningShiftPremiumReviewsRouter({ timeoutMs = 20_000, maxRequestsPerMinute = 30 } = {}): IRouter {
  const router = Router();
  const windows = new Map<string, { count: number; until: number }>();
  router.post("/earnings/shift-premium-reviews", async (req, res): Promise<void> => {
    const fail = (status: number, code: EarningCheckError["code"]) => { res.status(status).json({ code, error: ERRORS[code] }); };
    const now = Date.now();
    for (const [key, window] of windows) if (window.until <= now) windows.delete(key);
    const key = req.ip || req.socket.remoteAddress || "unknown";
    const window = windows.get(key) ?? { count: 0, until: now + 60_000 };
    windows.set(key, window);
    if (++window.count > maxRequestsPerMinute) { fail(429, "rate_limited"); return; }
    const parsed = BODY.safeParse(req.body);
    if (!parsed.success) { fail(400, "invalid_request"); return; }
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const client = createOpenAIClient();
      const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
        { role: "system", content: SHIFT_PREMIUM_INSTRUCTIONS },
        { role: "user", content: buildShiftPremiumMessage(parsed.data) },
      ];
      for (let attempt = 0; attempt < 2; attempt++) {
        const completion = await client.chat.completions.create({
          model: "gpt-5.4-mini", max_completion_tokens: 4096, reasoning_effort: "low",
          response_format: { type: "json_schema", json_schema: { name: "shift_premium_review", strict: true, schema: SHIFT_PREMIUM_SCHEMA } },
          messages,
        }, { signal: controller.signal });
        const content = completion.choices[0]?.message?.content ?? "";
        let raw: unknown;
        try { raw = JSON.parse(content); } catch { raw = null; }
        const result = validateShiftPremium(raw, parsed.data);
        if (result.ok) { res.json(result.value); return; }
        req.log.warn("Shift premium review needed a correction");
        messages.push({ role: "assistant", content: content || "{}" }, {
          role: "user", content: `Your result didn't meet the rules. ${result.correction} Return corrected JSON only.`,
        });
      }
      fail(502, "invalid_response");
    } catch (error) {
      req.log.error({ upstream: errorSummary(error) }, "Shift premium review unavailable");
      fail(controller.signal.aborted ? 504 : 502, controller.signal.aborted ? "timed_out" : "unavailable");
    } finally {
      clearTimeout(timeout);
    }
  });
  return router;
}
export default createEarningShiftPremiumReviewsRouter();
