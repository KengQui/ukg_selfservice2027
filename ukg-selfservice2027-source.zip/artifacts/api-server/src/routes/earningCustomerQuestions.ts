import { Router, type IRouter } from "express";
import type OpenAI from "openai";
import { DraftEarningCustomerQuestionsBody, type EarningCheckError } from "@workspace/api-zod";
import { createOpenAIClient, errorSummary } from "../lib/earningAI";
import { CUSTOMER_QUESTION_INSTRUCTIONS, CUSTOMER_QUESTION_SCHEMA, customerQuestionMessage, validateCustomerQuestions } from "../lib/earningCustomerQuestions";

const BODY = DraftEarningCustomerQuestionsBody.extend({
  facts: DraftEarningCustomerQuestionsBody.shape.facts.strict(),
  cardQuestions: DraftEarningCustomerQuestionsBody.shape.cardQuestions.element.strict().array().min(1).max(20),
  earlierAnswers: DraftEarningCustomerQuestionsBody.shape.earlierAnswers.element.strict().array().max(60),
}).strict();
const ERRORS = {
  invalid_request: "We couldn’t draft these questions. Check the code’s answers, then try again.",
  rate_limited: "We’ve drafted a lot of questions in the last minute. Wait a minute, then try again.",
  unavailable: "We can’t draft these questions right now. Try again, or use the standard question.",
  timed_out: "Drafting these questions took too long. Try again, or use the standard question.",
  invalid_response: "We couldn’t draft these questions this time. Try again, or use the standard question.",
} as const satisfies Record<EarningCheckError["code"], string>;

export function createEarningCustomerQuestionsRouter({ timeoutMs = 20_000, maxRequestsPerMinute = 60 } = {}): IRouter {
  const router = Router();
  const windows = new Map<string, { count: number; until: number }>();
  router.post("/earnings/customer-questions", async (req, res): Promise<void> => {
    const fail = (status: number, code: EarningCheckError["code"]) => { res.status(status).json({ code, error: ERRORS[code] }); };
    const now = Date.now();
    for (const [key, window] of windows) if (window.until <= now) windows.delete(key);
    const key = req.ip || req.socket.remoteAddress || "unknown";
    const window = windows.get(key) ?? { count: 0, until: now + 60_000 };
    windows.set(key, window);
    if (++window.count > maxRequestsPerMinute) { fail(429, "rate_limited"); return; }
    const parsed = BODY.safeParse(req.body);
    if (!parsed.success) { fail(400, "invalid_request"); return; }
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const client = createOpenAIClient();
      const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
        { role: "system", content: CUSTOMER_QUESTION_INSTRUCTIONS },
        { role: "user", content: customerQuestionMessage(parsed.data) },
      ];
      for (let attempt = 0; attempt < 2; attempt++) {
        const completion = await client.chat.completions.create({
          model: "gpt-5.4-mini", max_completion_tokens: 4096, reasoning_effort: "low",
          response_format: { type: "json_schema", json_schema: { name: "earning_customer_questions", strict: true, schema: CUSTOMER_QUESTION_SCHEMA } },
          messages,
        }, { signal: controller.signal });
        const content = completion.choices[0]?.message?.content ?? "";
        let raw: unknown;
        try { raw = JSON.parse(content); } catch { raw = null; }
        const result = validateCustomerQuestions(raw, parsed.data);
        if (result.ok) { res.json(result.value); return; }
        messages.push({ role: "assistant", content: content || "{}" },
          { role: "user", content: `Your result didn't meet the rules. ${result.correction} Return corrected JSON only.` });
      }
      fail(502, "invalid_response");
    } catch (error) {
      req.log.error({ upstream: errorSummary(error) }, "Earning customer question drafting unavailable");
      fail(controller.signal.aborted ? 504 : 502, controller.signal.aborted ? "timed_out" : "unavailable");
    } finally {
      clearTimeout(timeout);
    }
  });
  return router;
}
export default createEarningCustomerQuestionsRouter();
