import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { mkdtemp, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { randomUUID } from "node:crypto";
import test from "node:test";
import express from "express";
import { build } from "esbuild";
import { ensureExportJobsTable } from "../lib/exportJobsMigration.ts";

const requireDb = createRequire(new URL("../../../../lib/db/package.json", import.meta.url));
const { Pool } = requireDb("pg");
const directory = path.dirname(fileURLToPath(import.meta.url));

test("startup migration is idempotent and overlapping HTTP export requests never join a job", async t => {
  if (!process.env.DATABASE_URL) {
    t.skip("Development DATABASE_URL is required for the real database integration test");
    return;
  }
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  // Bundle beside where the build writes dist/ so the route resolves the
  // workspace (three directories up) and can confirm the source projects exist.
  const temp = await mkdtemp(path.join(directory, "../../.exports-test-"));
  let server;
  let activeId;
  try {
    await ensureExportJobsTable(pool);
    await ensureExportJobsTable(pool);
    const { rows: indexes } = await pool.query(
      "SELECT indexname FROM pg_indexes WHERE schemaname = current_schema() AND tablename = 'export_jobs'",
    );
    assert.ok(indexes.some(row => row.indexname === "export_jobs_one_running"));
    activeId = randomUUID();
    await pool.query(
      "INSERT INTO export_jobs (id, slug, status, created_at, expires_at) VALUES ($1, $2, 'running', now(), now() + interval '10 minutes')",
      [activeId, "company-setup-intro"],
    );

    // Bundle the actual router so this tests Express responses + the real unique
    // index; a pre-existing running row keeps the capture worker from starting.
    const outfile = path.join(temp, "route.mjs");
    await build({
      entryPoints: [path.join(directory, "exports.ts")],
      outfile,
      platform: "node",
      format: "esm",
      bundle: true,
      external: ["@google-cloud/storage", "pino", "pino-pretty"],
      banner: { js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" },
      logLevel: "silent",
    });
    const { default: router } = await import(outfile);
    const app = express();
    app.use(express.json());
    app.use("/api", router);
    server = app.listen(0);
    await new Promise(resolve => server.once("listening", resolve));
    const url = `http://127.0.0.1:${server.address().port}/api/exports/`;
    // Valid source-export requests pass the payload checks and reach the running-job claim.
    const exportSource = slug => fetch(url + slug, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind: "source" }),
    });
    const responses = await Promise.all([
      exportSource("company-setup-intro"),
      exportSource("company-setup-intro"),
      exportSource("copy-branding"),
    ]);
    for (const response of responses) {
      assert.equal(response.status, 429);
      assert.equal(response.headers.get("retry-after"), "30");
      const body = await response.json();
      assert.match(body.error, /retry your export request/i);
      assert.equal(body.id, undefined);
    }
    const { rows } = await pool.query("SELECT id FROM export_jobs WHERE status = 'running'");
    assert.deepEqual(rows.map(row => row.id), [activeId]);
  } finally {
    if (server) await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
    if (activeId) await pool.query("DELETE FROM export_jobs WHERE id = $1", [activeId]);
    await pool.end();
    await rm(temp, { recursive: true, force: true });
  }
});