import { randomUUID, createHash } from 'node:crypto';
import { Router, type IRouter } from 'express';
import { and, eq, gt, lt, ne, or, sql } from 'drizzle-orm';
import { db, registerFiles } from '@workspace/db';
import {
  CreateRegisterUploadBody, CreateRegisterUploadResponse, GetRegisterUploadParams,
  GetRegisterUploadResponse, type RegisterFile,
} from '@workspace/api-zod';
import { ObjectStorageService } from '../lib/objectStorage';
import { extractRegister } from '../lib/registerExtraction';
import { MAX_REGISTER_BYTES, RegisterReadError } from '../lib/registerDocument';
import { errorSummary } from '../lib/earningAI';

const router: IRouter = Router();
const storage = new ObjectStorageService();
type StoredFile = typeof registerFiles.$inferSelect;
const publicFile = (file: StoredFile): RegisterFile => GetRegisterUploadResponse.parse({
  id: file.id, name: file.name, sizeBytes: file.sizeBytes, docType: file.docType, status: file.status,
  ...(file.error ? { error: file.error } : {}), ...(file.sha256 ? { sha256: file.sha256 } : {}),
  ...(file.evidence ? { evidence: file.evidence } : {}),
});
const expired = () => new Date(Date.now() - 10 * 60_000);
const idle = () => or(ne(registerFiles.status, 'reading'), lt(registerFiles.updatedAt, expired()));

// All uploaded registers are private, including their filenames and extracted data.
router.use('/earnings/registers', (req, res, next) => {
  res.setHeader('Cache-Control', 'private, no-store');
  if (!req.isAuthenticated()) { res.status(401).json({ code: 'REGISTER_AUTH', error: 'Log in to read your pay registers.' }); return; }
  if (!['GET', 'HEAD'].includes(req.method)) {
    // Browser writes require same-origin; Bearer clients remain possible.
    const origin = req.get('origin');
    const host = req.get('x-forwarded-host') ?? req.get('host');
    if (origin && new URL(origin).host !== host) { res.status(403).json({ code: 'REGISTER_ORIGIN', error: 'Open this page again and try the upload.' }); return; }
  }
  next();
});

router.post('/earnings/registers', async (req, res): Promise<void> => {
  const input = CreateRegisterUploadBody.safeParse(req.body);
  if (!input.success || !/\.(pdf|csv|xlsx)$/i.test(input.data.name) || /[/\\\x00-\x1f]/.test(input.data.name)) {
    res.status(400).json({ code: 'REGISTER_INPUT', error: 'Choose a PDF, CSV or XLSX file up to 10 MB with a short file name.' }); return;
  }
  const ownerId = req.user!.id;
  try {
    const result = await db.transaction(async tx => {
      // Per-owner quota serialized across server instances, not an in-memory limiter.
      await tx.execute(sql`select pg_advisory_xact_lock(hashtext(${`registers:${ownerId}`}))`);
      const recent = await tx.select({ count: sql<number>`count(*)::int` }).from(registerFiles)
        .where(and(eq(registerFiles.ownerId, ownerId), gt(registerFiles.createdAt, new Date(Date.now() - 24 * 60 * 60_000))));
      if (recent[0].count >= 50) return null;
      const uploadURL = await storage.getObjectEntityUploadURL();
      const [file] = await tx.insert(registerFiles).values({
        ...input.data, id: randomUUID(), ownerId, objectPath: storage.normalizeObjectEntityPath(uploadURL), status: 'uploaded',
      }).returning();
      return { file: publicFile(file), uploadURL };
    });
    if (!result) { res.status(429).json({ code: 'REGISTER_LIMIT', error: 'The daily upload limit has been reached. Try again tomorrow.' }); return; }
    res.status(201).json(CreateRegisterUploadResponse.parse(result));
  } catch (error) {
    req.log.warn(errorSummary(error), 'Could not reserve register upload');
    res.status(503).json({ code: 'REGISTER_STORAGE', error: 'Your file couldn’t be uploaded. Try again in a moment.' });
  }
});

router.get('/earnings/registers/:id', async (req, res): Promise<void> => {
  const params = GetRegisterUploadParams.safeParse(req.params);
  if (!params.success) { res.sendStatus(400); return; }
  const [file] = await db.select().from(registerFiles).where(and(eq(registerFiles.id, params.data.id), eq(registerFiles.ownerId, req.user!.id)));
  if (!file) { res.sendStatus(404); return; }
  if (file.status === 'reading' && file.updatedAt < expired()) {
    const [interrupted] = await db.update(registerFiles).set({
      status: 'failed', error: 'Reading was interrupted. Try reading this file again.', updatedAt: new Date(),
    }).where(and(eq(registerFiles.id, file.id), eq(registerFiles.updatedAt, file.updatedAt))).returning();
    res.json(publicFile(interrupted ?? file)); return;
  }
  res.json(publicFile(file));
});

router.post('/earnings/registers/:id/read', async (req, res): Promise<void> => {
  const params = GetRegisterUploadParams.safeParse(req.params);
  if (!params.success) { res.sendStatus(400); return; }
  const owned = and(eq(registerFiles.id, params.data.id), eq(registerFiles.ownerId, req.user!.id));
  const [existing] = await db.select().from(registerFiles).where(owned);
  if (!existing) { res.sendStatus(404); return; }
  // A successful extraction is immutable. Retrying a lost HTTP response cannot replace its evidence.
  if (existing.status === 'ready') { res.json(publicFile(existing)); return; }
  const started = new Date();
  const [file] = await db.update(registerFiles).set({ status: 'reading', error: null, updatedAt: started })
    .where(and(owned, idle(), ne(registerFiles.status, 'ready'))).returning();
  if (!file) { res.status(409).json({ code: 'REGISTER_READING', error: 'This file is still being read. Check its status in a moment.' }); return; }
  const attempt = and(owned, eq(registerFiles.status, 'reading'), eq(registerFiles.updatedAt, started));
  let update: Partial<StoredFile>;
  try {
    const object = await storage.getObjectEntityFile(file.objectPath);
    const [metadata] = await object.getMetadata();
    if (Number(metadata.size) !== file.sizeBytes || Number(metadata.size) > MAX_REGISTER_BYTES)
      throw new RegisterReadError('The uploaded file size doesn’t match. Remove it and upload the file again.');
    const chunks: Buffer[] = [];
    let length = 0;
    const stream = object.createReadStream();
    for await (const chunk of stream) {
      length += chunk.length;
      if (length > MAX_REGISTER_BYTES) { stream.destroy(); throw new RegisterReadError('Choose a file up to 10 MB.'); }
      chunks.push(Buffer.from(chunk));
    }
    const bytes = Buffer.concat(chunks);
    const sha256 = createHash('sha256').update(bytes).digest('hex');
    const evidence = await extractRegister(bytes, file.name);
    update = { status: 'ready', evidence, sha256, error: null, updatedAt: new Date() };
  } catch (error) {
    req.log.warn({ ...errorSummary(error), registerId: file.id }, 'Register reading could not complete');
    update = {
      status: 'failed', evidence: null, updatedAt: new Date(),
      error: error instanceof RegisterReadError ? error.message : 'This file couldn’t be read. Try again, or upload a clearer PDF, CSV or XLSX copy.',
    };
  }
  const [finished] = await db.update(registerFiles).set(update).where(attempt).returning();
  if (!finished) { res.status(409).json({ code: 'REGISTER_READING', error: 'The file status changed. Check it again.' }); return; }
  res.json(publicFile(finished));
});

router.delete('/earnings/registers/:id', async (req, res): Promise<void> => {
  const params = GetRegisterUploadParams.safeParse(req.params);
  if (!params.success) { res.sendStatus(400); return; }
  const owned = and(eq(registerFiles.id, params.data.id), eq(registerFiles.ownerId, req.user!.id));
  const [file] = await db.select().from(registerFiles).where(owned);
  if (!file) { res.sendStatus(404); return; }
  // Lock metadata until bytes have been removed, including under concurrent retries.
  await db.transaction(async tx => {
    const [locked] = await tx.select().from(registerFiles).where(owned).for('update');
    if (!locked) { res.sendStatus(404); return; }
    if (locked.status === 'reading' && locked.updatedAt >= expired()) { res.sendStatus(409); return; }
    try {
      const object = await storage.getObjectEntityFile(file.objectPath);
      await object.delete({ ignoreNotFound: true });
    } catch (error) {
      if (!(error instanceof Error && error.name === 'ObjectNotFoundError')) throw error;
    }
    await tx.delete(registerFiles).where(owned);
    res.sendStatus(204);
  });
});
export default router;
