import assert from 'node:assert/strict'
import { mkdtemp, rm } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import test from 'node:test'
import express from 'express'
import { build } from 'esbuild'
import { createEarningResponseCache } from '../lib/earningResponseCache.ts'

const directory = path.dirname(fileURLToPath(import.meta.url))
const input = { code: 'TIPS', question: 'How do people receive their share?',
  evidence: [{ kind: 'customerAnswer', source: 'Earlier answer', text: 'We pool tips.' },
    { kind: 'document', source: 'Register A, earnings', text: 'TIPS appears in earnings.' }] }
const result = { summary: 'Earlier answers indicate that tips are pooled. How people receive them is still unconfirmed.' }

test('discussion summary: independent bounded process, privacy, errors and retry', async t => {
  const temp = await mkdtemp(path.join(directory, '.discussion-summary-test-'))
  let server, mode = 'success'
  const requests = [], logs = []
  globalThis.__summaryClient = { chat: { completions: { create: async (request, { signal }) => {
    requests.push(request)
    if (mode === 'timeout') await new Promise((_, reject) => signal.addEventListener('abort', () => reject(new Error('timeout')), { once: true }))
    if (mode === 'unavailable') throw new Error('private upstream answer and owner@example.com')
    const output = mode === 'bad' ? { summary: 'You should approve taxable pay?' }
      : (mode === 'ai-always' || mode === 'ai' && request.messages.length === 2) ? { summary: 'AI suggested pooling tips. The payment method remains unconfirmed.' }
      : (mode === 'long-always' || mode === 'long' && request.messages.length === 2) ? { summary: `${'Context '.repeat(41)}remains unconfirmed.` }
      : (mode === 'role-label-always' || mode === 'role-label' && request.messages.length === 2) ? { summary: 'Customer answer: Tips are pooled. How people receive them is still unconfirmed.' }
      : mode === 'correct' && request.messages.length === 2 ? { summary: 'What should we do?' }
      : mode === 'privacy' ? { summary: 'The earlier contact was owner@example.com. Payment method remains unconfirmed.' } : result
    return { choices: [{ message: { content: JSON.stringify(output) } }] }
  } } } }
  try {
    const outfile = path.join(temp, 'router.mjs')
    await build({ entryPoints: [path.join(directory, 'earningDiscussionSummary.ts')], outfile, platform: 'node', format: 'esm', bundle: true,
      banner: { js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" }, logLevel: 'silent',
      plugins: [{ name: 'provider-fixture', setup(build) {
        build.onLoad({ filter: /\/earningAI\.ts$/ }, () => ({ loader: 'ts', contents:
          'export const createOpenAIClient = () => globalThis.__summaryClient; export const errorSummary = () => ({name:"Error"});' }))
      } }] })
    const { createEarningDiscussionSummaryRouter } = await import(outfile)
    const app = express()
    app.use(express.json()); app.use((req, _res, next) => { req.log = { error: (...args) => logs.push(args) }; next() })
    app.use(createEarningResponseCache())
    app.use(createEarningDiscussionSummaryRouter({ timeoutMs: 30, maxRequestsPerMinute: 50 }))
    server = app.listen(0, '127.0.0.1')
    await new Promise(resolve => server.once('listening', resolve))
    const post = (body, scope) => fetch(`http://127.0.0.1:${server.address().port}/earnings/discussion-summary`, {
      method: 'POST', headers: { 'content-type': 'application/json', ...(scope ? { 'X-Earning-Cache-Scope': scope } : {}) }, body: JSON.stringify(body),
    })
    await t.test('uses shared rules plus summary-only instructions, with no decision output', async () => {
      const response = await post(input)
      assert.equal(response.status, 200); assert.deepEqual(await response.json(), result)
      assert.match(requests.at(-1).messages[0].content, /untrusted data/)
      assert.match(requests.at(-1).messages[0].content, /unaccepted AI suggestion/)
      assert.match(requests.at(-1).messages[0].content, /No new questions/)
      assert.match(requests.at(-1).messages[0].content, /Use "Earlier answers"/)
      assert.match(requests.at(-1).messages[0].content, /not proof that the customer supplied them/)
      assert.match(requests.at(-1).messages[0].content, /one or two short sentences/)
      assert.match(requests.at(-1).messages[0].content, /never pad/)
      assert.match(requests.at(-1).messages[0].content, /Preserve every distinction/)
    })
    await t.test('corrects role-specific answer labels without assuming who supplied the answer', async () => {
      mode = 'role-label'
      const before = requests.length
      const response = await post(input)
      assert.equal(response.status, 200)
      assert.deepEqual(await response.json(), result)
      assert.equal(requests.length - before, 2)
      assert.match(requests.at(-1).messages.at(-1).content, /Use Earlier answers/)
      assert.doesNotMatch(requests.at(-1).messages.at(-1).content, /Tips are pooled/)
      mode = 'role-label-always'
      const failed = await post(input)
      assert.equal(failed.status, 502)
      assert.equal((await failed.json()).code, 'invalid_response')
      mode = 'success'
    })
    await t.test('corrects AI mentions and rejects repeated technology references', async () => {
      mode = 'ai'
      const before = requests.length
      const response = await post(input)
      assert.equal(response.status, 200)
      assert.deepEqual(await response.json(), result)
      assert.equal(requests.length - before, 2)
      assert.match(requests.at(-1).messages.at(-1).content, /Never mention AI/)
      mode = 'ai-always'
      const failed = await post(input)
      assert.equal(failed.status, 502)
      assert.equal((await failed.json()).code, 'invalid_response')
      mode = 'success'
    })
    await t.test('shortens overlong summaries through correction, never truncation', async () => {
      mode = 'long'
      const before = requests.length
      const response = await post(input)
      assert.equal(response.status, 200)
      assert.deepEqual(await response.json(), result)
      assert.equal(requests.length - before, 2)
      assert.match(requests.at(-1).messages.at(-1).content, /at most 40 words/)
      assert.match(requests.at(-1).messages.at(-1).content, /Do not remove qualifications/)
      mode = 'long-always'
      const failed = await post(input)
      assert.equal(failed.status, 502)
      assert.equal((await failed.json()).code, 'invalid_response')
      mode = 'success'
    })
    await t.test('rejects missing prior answers, oversized and unexpected fields before calling AI', async () => {
      const before = requests.length
      for (const body of [{ ...input, evidence: [input.evidence[1]] }, { ...input, question: 'x'.repeat(1001) },
        { ...input, apply: true }, { ...input, evidence: [{ ...input.evidence[0], unsafe: true }] }]) {
        const response = await post(body)
        assert.equal(response.status, 400); assert.equal((await response.json()).code, 'invalid_request')
      }
      assert.equal(requests.length, before)
    })
    await t.test('redacts input and output, and never passes upstream text into a correction', async () => {
      mode = 'privacy'
      const response = await post({ ...input, evidence: [{ ...input.evidence[0], text: 'owner@example.com said tips are pooled.' }] })
      assert.doesNotMatch(JSON.stringify(await response.json()), /owner@example/)
      assert.doesNotMatch(requests.at(-1).messages[1].content, /owner@example/)
      mode = 'correct'; assert.equal((await post(input)).status, 200)
      assert.equal(requests.at(-1).messages.length, 3)
      assert.doesNotMatch(requests.at(-1).messages.at(-1).content, /What should we do/)
    })
    await t.test('bounds correction and returns documented errors without private upstream text', async () => {
      mode = 'bad'
      const before = requests.length
      let response = await post(input)
      assert.equal(response.status, 502); assert.equal((await response.json()).code, 'invalid_response')
      assert.equal(requests.length - before, 2)
      mode = 'unavailable'; response = await post(input)
      assert.equal(response.status, 502); assert.equal((await response.json()).code, 'unavailable')
      assert.doesNotMatch(JSON.stringify(logs), /private upstream|owner@example/)
      mode = 'timeout'; response = await post(input)
      assert.equal(response.status, 504); assert.equal((await response.json()).code, 'timed_out')
    })
    await t.test('reuses a validated summary but regenerates when evidence or company scope changes', async () => {
      mode = 'success'
      const before = requests.length
      const first = await post(input, 'c'.repeat(64))
      assert.equal(first.status, 200)
      assert.equal(first.headers.get('x-earning-cache'), 'miss')
      const reused = await post(input, 'c'.repeat(64))
      assert.equal(reused.headers.get('x-earning-cache'), 'hit')
      assert.deepEqual(await reused.json(), result)
      assert.equal(requests.length - before, 1)
      await post({ ...input, evidence: [{ ...input.evidence[0], text: 'We pool only cash tips.' }] }, 'c'.repeat(64))
      await post(input, 'd'.repeat(64))
      assert.equal(requests.length - before, 3)
    })
    await t.test('rate limits the process', async () => {
      mode = 'success'
      let response
      for (let i = 0; i < 51; i++) response = await post(input)
      assert.equal(response.status, 429); assert.equal((await response.json()).code, 'rate_limited')
    })
  } finally {
    await new Promise(resolve => server ? server.close(resolve) : resolve())
    delete globalThis.__summaryClient
    await rm(temp, { recursive: true, force: true })
  }
})
