import { Router, type IRouter } from "express";
import OpenAI from "openai";
import { SuggestInviteRoleBody, SuggestInviteRoleResponse, type InviteRoleSuggestionError } from "@workspace/api-zod";
import {
  INVITE_ROLE_POLICY_VERSION, needsManualInviteReview,
} from "@workspace/setup-shared/invite-role-policy";
import {
  buildInviteRolePrompt, INVITE_ROLE_MODEL_SCHEMA, NO_MATCH_CLARIFICATION, redactInviteRoleDescription,
  UnusableInviteRoleResponse, validateInviteRoleModelResponse,
} from "../lib/inviteRoleSuggestion";

export interface InviteTeamRouterOptions {
  timeoutMs?: number;
  maxRequestsPerMinute?: number;
  maxRateLimitKeys?: number;
}

function createOpenAIClient(): OpenAI {
  const apiKey = process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
  const baseURL = process.env.AI_INTEGRATIONS_OPENAI_BASE_URL;
  if (!apiKey || !baseURL) throw new Error("OpenAI integration is not configured");
  // At most one transient retry. The shared abort deadline includes SDK backoff.
  return new OpenAI({ apiKey, baseURL, maxRetries: 1 });
}

/** Privacy-safe metadata only. Never log SDK errors, descriptions or model content. */
function upstreamStatus(error: unknown): number | undefined {
  if (typeof error !== "object" || error === null || !("status" in error)) return undefined;
  return typeof error.status === "number" ? error.status : undefined;
}

export function createInviteTeamRouter({
  timeoutMs = 30_000, maxRequestsPerMinute = 10, maxRateLimitKeys = 1000,
}: InviteTeamRouterOptions = {}): IRouter {
  const router: IRouter = Router();
  const windows = new Map<string, { count: number; resetAt: number }>();
  function takeCapacity(key: string): boolean {
    const now = Date.now();
    for (const [windowKey, window] of windows) if (window.resetAt <= now) windows.delete(windowKey);
    const window = windows.get(key);
    if (window) {
      if (window.count >= maxRequestsPerMinute) return false;
      window.count++;
      return true;
    }
    // Never evict a live window: that would reset its protection. New keys are
    // refused until capacity frees up, keeping both memory and traffic bounded.
    if (windows.size >= maxRateLimitKeys) return false;
    windows.set(key, { count: 1, resetAt: now + 60_000 });
    return true;
  }

  router.post("/invite-team/role-suggestions", async (req, res): Promise<void> => {
    const respondError = (status: number, code: InviteRoleSuggestionError["code"], error: string): void => {
      res.status(status).json({ code, error } satisfies InviteRoleSuggestionError);
    };
    const parsed = SuggestInviteRoleBody.strict().safeParse(req.body);
    if (!parsed.success || !parsed.data.description.trim()) {
      req.log.warn("Role suggestion input rejected");
      respondError(400, "INVITE_ROLE_INPUT", "Describe their setup work in 1 to 1,000 characters, without personal details, then try again.");
      return;
    }
    if (parsed.data.policyVersion !== INVITE_ROLE_POLICY_VERSION) {
      respondError(409, "INVITE_ROLE_POLICY", "The setup roles have changed. Reload this page, then review their work again.");
      return;
    }
    if (!takeCapacity(req.ip || req.socket.remoteAddress || "unknown")) {
      respondError(429, "INVITE_ROLE_RATE_LIMIT", "Role suggestions have reached their limit for the moment. Wait a minute, try again, or choose a role yourself.");
      return;
    }
    // The original exclusion must precede redaction and AI: never widen work
    // that the matcher deliberately leaves for manual review. Only clearly stated
    // time or schedule setup work goes on, and only for Time & Scheduling Admin.
    if (needsManualInviteReview(parsed.data.description)) {
      res.json(SuggestInviteRoleResponse.parse({
        policyVersion: INVITE_ROLE_POLICY_VERSION, profileKey: null,
        explanation: "This work includes duties outside the setup roles we can suggest.",
        clarification: NO_MATCH_CLARIFICATION,
      }));
      return;
    }
    const description = redactInviteRoleDescription(parsed.data.description);
    if (!description || !description.replace(/\[removed\]/g, "").trim()) {
      respondError(400, "INVITE_ROLE_INPUT", "Describe the setup duties without personal or account details, then try again.");
      return;
    }
    const controller = new AbortController();
    const onClose = (): void => { if (!res.writableEnded) controller.abort(); };
    res.once("close", onClose);
    let deadlineExpired = false;
    let timeout: ReturnType<typeof setTimeout> | undefined;
    const deadline = new Promise<never>((_resolve, reject) => {
      timeout = setTimeout(() => {
        deadlineExpired = true;
        controller.abort();
        reject(new Error("Role suggestion deadline expired"));
      }, timeoutMs);
    });
    try {
      const completion = await Promise.race([
        createOpenAIClient().chat.completions.create({
          model: "gpt-5.4-mini",
          max_completion_tokens: 8192,
          reasoning_effort: "low",
          response_format: {
            type: "json_schema",
            json_schema: { name: "invite_setup_role", strict: true, schema: INVITE_ROLE_MODEL_SCHEMA },
          },
          messages: [
            { role: "system", content: buildInviteRolePrompt() },
            { role: "user", content: JSON.stringify({ description }) },
          ],
        }, { signal: controller.signal }),
        deadline,
      ]);
      if (controller.signal.aborted || res.destroyed) return;
      const choice = completion.choices[0];
      if (choice?.finish_reason !== "stop" || choice.message.refusal) throw new UnusableInviteRoleResponse();
      const result = validateInviteRoleModelResponse(choice.message.content, description);
      res.json(SuggestInviteRoleResponse.strict().parse(result));
    } catch (error) {
      if (res.destroyed) return;
      if (deadlineExpired) {
        req.log.warn("Role suggestion timed out");
        respondError(504, "INVITE_ROLE_TIMEOUT", "The role suggestion took too long. Try again, or choose a role yourself.");
      } else if (error instanceof UnusableInviteRoleResponse) {
        req.log.warn("Role suggestion response rejected");
        respondError(502, "INVITE_ROLE_RESPONSE", "I couldn’t use that role suggestion. Try again, or choose a role yourself.");
      } else {
        req.log.error({ upstreamStatus: upstreamStatus(error) }, "Role suggestion service unavailable");
        respondError(503, "INVITE_ROLE_UNAVAILABLE", "I can’t suggest a role right now. Try again in a moment, or choose a role yourself.");
      }
    } finally {
      clearTimeout(timeout);
      res.removeListener("close", onClose);
    }
  });
  return router;
}

export default createInviteTeamRouter();