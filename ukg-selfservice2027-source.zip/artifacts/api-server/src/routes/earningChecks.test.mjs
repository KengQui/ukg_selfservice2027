import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";
import express from "express";
import { build } from "esbuild";
import { CheckEarningDescriptionBody } from "../../../../lib/api-zod/src/generated/api.ts";

const directory = path.dirname(fileURLToPath(import.meta.url));
async function bundle(entry, temp) {
  const outfile = path.join(temp, `${path.basename(entry, ".ts")}.mjs`);
  await build({
    entryPoints: [entry], outfile, platform: "node", format: "esm", bundle: true,
    banner: { js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" },
    logLevel: "silent",
  });
  return import(outfile);
}
const helperTemp = await mkdtemp(path.join(directory, ".earning-check-helpers-"));
const { buildCheckMessage, correctionRequest, validateCheck, EARNING_CHECK_INSTRUCTIONS } =
  await bundle(path.join(directory, "../lib/earningCheck.ts"), helperTemp)
    .finally(() => rm(helperTemp, { recursive: true, force: true }));

function validBody(overrides = {}) {
  return {
    code: "ADJ2",
    source: { label: "Pay register", description: "Adjustments" },
    description: "Monthly flat pay for the warehouse lead covering the night crew roster",
    answers: [{ question: "Is ADJ2 a correction to earlier pay?", answer: "No" }],
    followUps: [{
      id: "payment-purpose",
      question: "Does ADJ2 pay for leading a crew or for working a night shift?",
      options: ["Leading a crew", "Working a night shift", "Something else"],
    }],
    references: [{ id: "RDY-E-101", name: "Lead duty pay" }, { id: "RDY-E-102", name: "Shift differential" }],
    ...overrides,
  };
}
const REFERENCE = { outcome: "reference", referenceId: "RDY-E-101", followUpId: null, reason: "The team describes monthly pay for leading the night crew. That purpose fits lead duty pay.", question: null, answerFormat: null };
const FOLLOW_UP = { outcome: "followUp", referenceId: null, followUpId: "payment-purpose", reason: null, question: null, answerFormat: null };
const NO_MATCH = { outcome: "noMatch", referenceId: null, followUpId: null, reason: "This pays for a staff referral, not leading a crew or working a particular shift.", question: null, answerFormat: null };
const NOT_NEEDED = { outcome: "notNeeded", referenceId: null, followUpId: null, reason: "You no longer use this code, so we suggest leaving it out of setup.", question: null, answerFormat: null };
const NEEDS_INFO = { outcome: "needsInformation", referenceId: null, followUpId: null, reason: null, question: "What work or event does ADJ2 pay for?", answerFormat: { kind: "text", options: null } };
const NEEDS_CHOICE = { ...NEEDS_INFO, question: "Was ADJ2 meant to pay a bonus amount or to correct an earlier overpayment?",
  answerFormat: { kind: "choices", options: ["A bonus amount", "A correction to an earlier overpayment"] } };
const IN_USE = { ...REFERENCE, reason: "The payment purpose fits lead duty pay. LEAD1 already uses Lead duty pay." };
const inUseBody = () => validBody({
  references: [{ id: "RDY-E-101", name: "Lead duty pay", inUseBy: [{ code: "LEAD1", description: "owner@example.com" }] }],
});

test("generated description check inputs are bounded", () => {
  assert.equal(CheckEarningDescriptionBody.safeParse(validBody()).success, true);
  for (const code of ["Special Pay", "Overtime ENG", "Uploaded OT", "SPPAY"]) {
    assert.equal(CheckEarningDescriptionBody.safeParse(validBody({ code })).success, true, code);
  }
  assert.equal(CheckEarningDescriptionBody.safeParse(validBody({ source: { label: "Pay register", description: null }, followUps: [] })).success, true);
  for (const override of [
    { description: "" }, { description: "a".repeat(501) }, { code: "adj2;" },
    { code: "" }, { code: "a".repeat(17) }, { code: "<Special Pay>" },
    { answers: Array(13).fill(validBody().answers[0]) },
    { followUps: Array(7).fill(validBody().followUps[0]) },
    { references: [] }, { references: Array(81).fill(validBody().references[0]) },
    { followUps: [{ ...validBody().followUps[0], id: "UPPER" }] },
    { followUps: [{ ...validBody().followUps[0], options: ["Only one"] }] },
    { references: [{ id: "lower", name: "Lead pay" }] },
    { references: [{ ...validBody().references[0], inUseBy: Array(11).fill({ code: "LEAD1", description: null }) }] },
    { references: [{ ...validBody().references[0], inUseBy: [{ code: "a".repeat(21), description: null }] }] },
    { references: [{ ...validBody().references[0], inUseBy: [{ code: "LEAD1", description: "a".repeat(81) }] }] },
  ]) assert.equal(CheckEarningDescriptionBody.safeParse(validBody(override)).success, false, JSON.stringify(override));
});

test("helpers frame and redact facts and enforce every outcome's fields", () => {
  assert.match(EARNING_CHECK_INSTRUCTIONS, /Prefer asking over guessing/);
  assert.match(EARNING_CHECK_INSTRUCTIONS, /Never ask one whose answer is already clear/);
  for (const value of [REFERENCE, FOLLOW_UP, NO_MATCH, NEEDS_INFO, NEEDS_CHOICE]) {
    assert.deepEqual(validateCheck(value, validBody()), { ok: true, value });
  }
  const issue = (value, request = validBody()) => {
    const result = validateCheck(value, request);
    return result.ok ? "ok" : result.issue;
  };
  for (const value of [null, [], {}, { ...REFERENCE, extra: true }, { ...REFERENCE, question: "Why?" }, { ...FOLLOW_UP, reason: "Some reason" }, { ...NO_MATCH, referenceId: "RDY-E-101" }, { ...NEEDS_INFO, reason: "Some reason" }]) {
    assert.equal(issue(value), "shape");
  }
  assert.equal(issue({ ...REFERENCE, answerFormat: { kind: "text", options: null } }), "shape");
  const { answerFormat: _missing, ...noFormat } = NEEDS_INFO;
  assert.equal(issue(noFormat), "shape");
  // An AI-written question must say how it's answered: two to four distinct options (no Something else), or text.
  const formatIssue = answerFormat => {
    const result = validateCheck({ ...NEEDS_CHOICE, answerFormat }, validBody());
    return result.ok ? "ok" : `${result.issue}: ${result.correction ?? ""}`;
  };
  assert.match(formatIssue(null), /^answer_format: Return answerFormat/);
  assert.match(formatIssue({ kind: "choices", options: ["Only one"] }), /^answer_format: Give two to four/);
  assert.match(formatIssue({ kind: "choices", options: ["A", "B", "C", "D", "E"] }), /^answer_format: Give two to four/);
  assert.match(formatIssue({ kind: "choices", options: ["A bonus", " "] }), /^answer_format: Every option needs words/);
  assert.match(formatIssue({ kind: "choices", options: ["A bonus", "a  bonus"] }), /^answer_format: Make every option different/);
  assert.match(formatIssue({ kind: "choices", options: ["A bonus", "Something else"] }), /^answer_format: Remove the option "Something else"/);
  assert.match(formatIssue({ kind: "choices", options: null }), /^answer_format: A choices answerFormat/);
  assert.match(formatIssue({ kind: "text", options: ["A bonus", "A correction"] }), /^answer_format: A text answerFormat has options null/);
  assert.match(formatIssue({ kind: "list", options: null }), /^answer_format: answerFormat kind/);
  assert.equal(formatIssue({ kind: "choices", options: ["A bonus", "Taxable pay"] }), "forbidden_claim: ");
  assert.equal(issue({ ...NEEDS_CHOICE, answerFormat: { kind: "choices", options: ["A bonus", "An easy fix"] } }), "banned_word");
  assert.deepEqual(validateCheck({ ...NEEDS_CHOICE, answerFormat: { kind: "choices", options: [" A bonus amount ", "A correction"] } }, validBody()).value.answerFormat,
    { kind: "choices", options: ["A bonus amount", "A correction"] });
  assert.match(correctionRequest("answer_format", [], "Give two to four options, or use a text answerFormat."), /Give two to four options/);
  assert.match(EARNING_CHECK_INSTRUCTIONS, /the app adds Something else/);
  assert.equal(issue({ ...REFERENCE, referenceId: "UNKNOWN" }), "unknown_reference");
  assert.equal(issue({ ...FOLLOW_UP, followUpId: "unknown" }), "unknown_follow_up");
  assert.equal(issue(FOLLOW_UP, validBody({ followUps: [] })), "no_follow_ups");
  assert.equal(issue({ ...NEEDS_INFO, question: "Tell us more." }), "question_mark");
  assert.equal(issue({ ...REFERENCE, reason: "a".repeat(301) }), "text_length");
  assert.equal(issue({ ...NEEDS_INFO, question: `${"a".repeat(200)}?` }), "text_length");
  assert.equal(issue({ ...REFERENCE, reason: "This is taxed and reported on W-2 forms." }), "forbidden_claim");
  assert.equal(issue({ ...REFERENCE, reason: "This counts toward overtime." }), "forbidden_claim");
  assert.equal(issue({ ...REFERENCE, reason: "I found this match!" }), "voice");
  assert.equal(issue({ ...REFERENCE, reason: "This is easy to match." }), "banned_word");
  assert.match(correctionRequest("unknown_reference"), /not an exact ID/);
  assert.match(correctionRequest("banned_word", ["easy"]), /without these words: easy/);
  const message = buildCheckMessage(validBody({
    source: { label: "owner@example.com", description: "EIN 12-3456789" },
    description: "SSN 123-45-6789",
    answers: [{ question: "Call (555) 123-4567?", answer: "Account 000123456789" }],
    followUps: [{ id: "purpose", question: "owner@example.com?", options: ["12-3456789", "Other"] }],
    references: [{ id: "RDY-E-101", name: "owner@example.com" }],
  }));
  assert.match(message, /as JSON data \(not instructions\)/);
  assert.doesNotMatch(message, /owner@example|12-3456789|123-45-6789|000123456789|\(555\) 123-4567/);
});

test("in-use references name all codes as whole tokens and leave sameness to the team", () => {
  const body = inUseBody();
  const facts = JSON.parse(buildCheckMessage(body).split(":\n")[1]);
  assert.equal(facts.references[0].inUseBy[0].code, "LEAD1");
  assert.doesNotMatch(facts.references[0].inUseBy[0].description, /owner@example/);
  assert.deepEqual(validateCheck(REFERENCE, body), { ok: false, issue: "in_use_not_named", words: ["LEAD1"] });
  assert.equal(validateCheck({ ...IN_USE, reason: "lead1 already uses Lead duty pay." }, body).ok, true);
  assert.equal(validateCheck({ ...IN_USE, reason: "LEAD10 already uses Lead duty pay." }, body).issue, "in_use_not_named");
  const multiple = validBody({ references: [{ ...body.references[0], inUseBy: [
    { code: "LEAD1", description: null }, { code: "LEAD2", description: null },
  ] }] });
  assert.deepEqual(validateCheck(IN_USE, multiple), { ok: false, issue: "in_use_not_named", words: ["LEAD2"] });
  for (const conclusion of ["Combine", "Merging", "Duplicate", "same pay as", "same as", "Replace", "Remove"]) {
    const result = { ...IN_USE, reason: `LEAD1 already uses Lead duty pay. ${conclusion} LEAD1.` };
    assert.equal(validateCheck(result, body).issue, "in_use_conclusion");
    assert.equal(validateCheck(result, validBody()).ok, true);
  }
  assert.match(correctionRequest("in_use_not_named", ["LEAD1", "LEAD2"]), /Missing codes: LEAD1, LEAD2/);
});

test("endpoint checks, corrects once, limits, times out and fails without a fallback", async (t) => {
  const temp = await mkdtemp(path.join(directory, ".earning-checks-test-"));
  const servers = [], logs = [], received = [];
  let mode = "reference";
  let temporaryFailures = 0;
  const previousEnv = { key: process.env.AI_INTEGRATIONS_OPENAI_API_KEY, url: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL };
  const listen = async (app) => {
    const server = app.listen(0);
    servers.push(server);
    await new Promise((resolve) => server.once("listening", resolve));
    return `http://127.0.0.1:${server.address().port}`;
  };
  try {
    const fake = express();
    fake.use(express.json());
    fake.post("/chat/completions", async (req, res) => {
      received.push(req.body);
      if (mode === "slow") await new Promise((resolve) => setTimeout(resolve, 1_500));
      if (temporaryFailures > 0) {
        temporaryFailures -= 1;
        res.status(502).json({ error: { message: "Temporarily unavailable", type: "server_error" } });
        return;
      }
      if (mode === "reject") {
        res.status(400).json({ error: { message: "Provider refused", type: "invalid_request_error" } });
        return;
      }
      const correcting = /^Your result didn't meet the rules/.test(req.body.messages.at(-1)?.content ?? "");
      const value = mode === "inUseMissing" && !correcting || mode === "inUseAlwaysMissing" ? REFERENCE
        : mode === "inUseConclusion" && !correcting ? { ...IN_USE, reason: "LEAD1 already uses Lead duty pay. Combine these codes." }
        : mode.startsWith("inUse") ? IN_USE
        : mode === "followUp" ? FOLLOW_UP : mode === "noMatch" ? NO_MATCH : mode === "notNeeded" ? NOT_NEEDED
        : mode === "needsInformation" ? NEEDS_INFO
        : mode === "unknown" && !correcting || mode === "alwaysUnknown" ? { ...REFERENCE, referenceId: "UNKNOWN" }
        : REFERENCE;
      res.json({
        id: "chatcmpl-test", object: "chat.completion", created: 0, model: req.body.model,
        choices: [{ index: 0, finish_reason: "stop", message: { role: "assistant", content: mode === "malformed" ? "not json" : JSON.stringify(value) } }],
      });
    });
    process.env.AI_INTEGRATIONS_OPENAI_API_KEY = "test-key";
    process.env.AI_INTEGRATIONS_OPENAI_BASE_URL = await listen(fake);
    const { createEarningChecksRouter } = await bundle(path.join(directory, "earningChecks.ts"), temp);
    const makeApp = (options) => {
      const app = express();
      app.use(express.json());
      app.use((req, _res, next) => {
        const record = (level) => (...args) => logs.push({ level, args });
        req.log = { info: record("info"), warn: record("warn"), error: record("error") };
        next();
      });
      app.use("/api", createEarningChecksRouter(options));
      return app;
    };
    const post = (base, body) => fetch(`${base}/api/earnings/description-checks`, {
      method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body),
    });
    const base = await listen(makeApp({ timeoutMs: 300, maxRequestsPerMinute: 30 }));
    await t.test("Special Pay reaches the AI with its displayed name unchanged", async () => {
      mode = "noMatch";
      const response = await post(base, validBody({
        code: "Special Pay",
        description: "A monthly stipend for employees who use a second language with customers",
      }));
      assert.equal(response.status, 200);
      assert.deepEqual(await response.json(), NO_MATCH);
      const facts = JSON.parse(received.at(-1).messages[1].content.split(":\n")[1]);
      assert.equal(facts.code, "Special Pay");
    });
    for (const [outcome, expected, body] of [
      ["reference", REFERENCE, validBody()],
      ["followUp", FOLLOW_UP, validBody({ description: "Extra pay for the night crew" })],
      ["noMatch", NO_MATCH, validBody({ description: "A payment for referring a new staff member" })],
      ["notNeeded", NOT_NEEDED, validBody({ description: "this is an old code we no longer use" })],
      ["needsInformation", NEEDS_INFO, validBody({ description: "Something else", followUps: [] })],
    ]) {
      await t.test(`returns ${outcome}`, async () => {
        mode = outcome;
        const response = await post(base, body);
        assert.equal(response.status, 200);
        assert.deepEqual(await response.json(), expected);
        const sent = received.at(-1);
        assert.equal(sent.model, "gpt-5.4-mini");
        assert.equal(sent.reasoning_effort, "low");
        assert.equal(sent.response_format.json_schema.strict, true);
        assert.equal(sent.messages[0].role, "system");
        assert.match(sent.messages[1].content, /RDY-E-101/);
      });
    }
    await t.test("unknown reference ID gets one precise corrective retry", async () => {
      mode = "unknown";
      const before = received.length;
      const response = await post(base, validBody());
      assert.equal(response.status, 200);
      assert.deepEqual(await response.json(), REFERENCE);
      assert.equal(received.length, before + 2);
      assert.match(received.at(-1).messages.at(-1).content, /referenceId is not an exact ID/);
    });
    await t.test("inUseBy reaches facts; missing code gets a correction then succeeds", async () => {
      mode = "inUseMissing";
      const before = received.length;
      const response = await post(base, inUseBody());
      assert.equal(response.status, 200);
      assert.deepEqual(await response.json(), IN_USE);
      assert.equal(received.length, before + 2);
      assert.match(received.at(-1).messages[1].content, /"inUseBy"/);
      assert.match(received.at(-1).messages[1].content, /"LEAD1"/);
      assert.doesNotMatch(received.at(-1).messages[1].content, /owner@example/);
      assert.match(received.at(-1).messages.at(-1).content, /Missing codes: LEAD1/);
    });
    await t.test("still missing a code returns invalid_response", async () => {
      mode = "inUseAlwaysMissing";
      const response = await post(base, inUseBody());
      assert.equal(response.status, 502);
      assert.equal((await response.json()).code, "invalid_response");
    });
    await t.test("conclusion wording gets corrected without deciding sameness", async () => {
      mode = "inUseConclusion";
      const response = await post(base, inUseBody());
      assert.equal(response.status, 200);
      assert.deepEqual(await response.json(), IN_USE);
      assert.match(received.at(-1).messages.at(-1).content, /Remove claims of sameness/);
    });
    await t.test("invalid twice returns invalid_response 502, never a result", async () => {
      for (const badMode of ["alwaysUnknown", "malformed"]) {
        mode = badMode;
        const before = received.length;
        const response = await post(base, validBody());
        assert.equal(response.status, 502);
        assert.equal((await response.json()).code, "invalid_response");
        assert.equal(received.length, before + 2);
      }
    });
    await t.test("invalid request returns 400 without model call", async () => {
      const before = received.length;
      for (const override of [
        { description: "" }, { extra: "not allowed" },
        { source: { ...validBody().source, extra: "not allowed" } },
        { answers: [{ ...validBody().answers[0], extra: "not allowed" }] },
        { followUps: [{ ...validBody().followUps[0], extra: "not allowed" }] },
        { references: [{ ...validBody().references[0], extra: "not allowed" }] },
        { references: [{ ...validBody().references[0], inUseBy: [{ code: "LEAD1", description: null, extra: "not allowed" }] }] },
      ]) {
        const response = await post(base, validBody(override));
        assert.equal(response.status, 400);
        assert.equal((await response.json()).code, "invalid_request");
      }
      assert.equal(received.length, before);
    });
    await t.test("provider failure returns unavailable 502", async () => {
      mode = "reject";
      const before = received.length;
      const response = await post(base, validBody());
      assert.equal(response.status, 502);
      assert.equal((await response.json()).code, "unavailable");
      assert.equal(received.length, before + 1, "permanent errors are not retried");
    });
    await t.test("Special Pay recovers after two temporary provider failures with the same answer", async () => {
      mode = "noMatch";
      temporaryFailures = 2;
      const retryBase = await listen(makeApp({ timeoutMs: 5_000 }));
      const before = received.length;
      const body = validBody({
        code: "Special Pay",
        description: "A monthly stipend for employees who use a second language with customers",
      });
      const response = await post(retryBase, body);
      assert.equal(response.status, 200);
      assert.deepEqual(await response.json(), NO_MATCH);
      assert.equal(received.length, before + 3);
      for (const request of received.slice(before)) assert.deepEqual(request, received[before]);
      const facts = JSON.parse(received[before].messages[1].content.split(":\n")[1]);
      assert.equal(facts.teamDescription, body.description);
    });
    await t.test("persistent provider failures stop after three attempts without a fallback result", async () => {
      temporaryFailures = 4;
      const retryBase = await listen(makeApp({ timeoutMs: 5_000 }));
      const before = received.length;
      const response = await post(retryBase, validBody());
      assert.equal(response.status, 502);
      assert.equal((await response.json()).code, "unavailable");
      assert.equal(received.length, before + 3);
      temporaryFailures = 0;
    });
    await t.test("the overall deadline also stops temporary-failure retries", async () => {
      temporaryFailures = 4;
      const before = received.length;
      const response = await post(base, validBody());
      assert.equal(response.status, 504);
      assert.equal((await response.json()).code, "timed_out");
      assert.equal(received.length, before + 1);
      temporaryFailures = 0;
    });
    await t.test("deadline returns timed_out 504", async () => {
      mode = "slow";
      const response = await post(base, validBody());
      assert.equal(response.status, 504);
      assert.equal((await response.json()).code, "timed_out");
    });
    await t.test("rate limit returns 429", async () => {
      mode = "reference";
      const limited = await listen(makeApp({ maxRequestsPerMinute: 2 }));
      assert.equal((await post(limited, validBody())).status, 200);
      assert.equal((await post(limited, validBody({ description: "" }))).status, 400);
      const response = await post(limited, validBody());
      assert.equal(response.status, 429);
      assert.equal((await response.json()).code, "rate_limited");
    });
    await t.test("sensitive request text never reaches model or logs", async () => {
      mode = "reference";
      const response = await post(base, validBody({
        description: "Paid to owner@example.com, EIN 12-3456789, SSN 123-45-6789",
        answers: [{ question: "Which account?", answer: "Account 000123456789, call (555) 123-4567" }],
      }));
      assert.equal(response.status, 200);
      const wire = JSON.stringify(received.at(-1));
      for (const secret of ["owner@example.com", "12-3456789", "123-45-6789", "000123456789", "(555) 123-4567"]) {
        assert.equal(wire.includes(secret), false);
      }
      assert.ok(logs.length >= 3);
      assert.doesNotMatch(JSON.stringify(logs), /warehouse lead|night crew|earlier pay|Leading a crew|Shift differential|owner@example|12-3456789|UNKNOWN/);
    });
  } finally {
    for (const server of servers) {
      server.closeAllConnections?.();
      await new Promise((resolve) => server.close(resolve));
    }
    if (previousEnv.key === undefined) delete process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
    else process.env.AI_INTEGRATIONS_OPENAI_API_KEY = previousEnv.key;
    if (previousEnv.url === undefined) delete process.env.AI_INTEGRATIONS_OPENAI_BASE_URL;
    else process.env.AI_INTEGRATIONS_OPENAI_BASE_URL = previousEnv.url;
    await rm(temp, { recursive: true, force: true });
  }
});