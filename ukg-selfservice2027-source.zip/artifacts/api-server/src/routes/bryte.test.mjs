import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";
import express from "express";
import { build } from "esbuild";
import { AskBryteBody } from "../../../../lib/api-zod/src/generated/api.ts";
import {
  MAX_ANSWER_LENGTH,
  bannedWordsIn,
  buildPageMessage,
  buildSystemPrompt,
  redactSensitive,
  shapeAnswer,
} from "../lib/bryteAnswer.ts";

const directory = path.dirname(fileURLToPath(import.meta.url));
const QUESTION = "What does this page need from me before I continue?";
const PAGE_PURPOSE = "Collect the company's federal tax ID and legal name.";

function validBody(overrides = {}) {
  return {
    app: "company-setup",
    register: "first-time",
    page: {
      name: "Company details",
      purpose: PAGE_PURPOSE,
      onScreen: ["Legal name field", "Federal tax ID field", "Continue button"],
      state: ["Legal name is filled in", "Tax ID is 12-3456789"],
    },
    history: [
      { role: "user", text: "What is an EIN?" },
      { role: "assistant", text: "It's the federal tax ID the IRS gave your business." },
    ],
    question: QUESTION,
    ...overrides,
  };
}

test("question requests are bounded", () => {
  assert.equal(AskBryteBody.safeParse(validBody()).success, true);
  assert.equal(AskBryteBody.safeParse(validBody({ history: undefined })).success, true);
  assert.equal(AskBryteBody.safeParse(validBody({ question: "" })).success, false);
  assert.equal(AskBryteBody.safeParse(validBody({ question: "a".repeat(501) })).success, false);
  assert.equal(AskBryteBody.safeParse(validBody({ app: "performance-reviews" })).success, false);
  assert.equal(AskBryteBody.safeParse(validBody({ register: "expert" })).success, false);
  const page = validBody().page;
  assert.equal(AskBryteBody.safeParse(validBody({ page: { ...page, onScreen: Array(13).fill("Item") } })).success, false);
  assert.equal(AskBryteBody.safeParse(validBody({ page: { ...page, state: ["x".repeat(201)] } })).success, false);
  assert.equal(AskBryteBody.safeParse(validBody({ page: { ...page, name: "" } })).success, false);
  const turn = { role: "user", text: "Hi" };
  assert.equal(AskBryteBody.safeParse(validBody({ history: Array(9).fill(turn) })).success, false);
  assert.equal(AskBryteBody.safeParse(validBody({ history: [{ role: "system", text: "Hi" }] })).success, false);
});

test("page context loses anything that looks sensitive, but keeps codes and colors", () => {
  const text = redactSensitive("EIN 12-3456789, SSN 123-45-6789, a@b.co, (555) 123-4567, acct 1234 5678 9012, NAICS 541511, #13352C");
  assert.doesNotMatch(text, /12-3456789|123-45-6789|a@b\.co|555|9012/);
  assert.match(text, /NAICS 541511/);
  assert.match(text, /#13352C/);
  const message = buildPageMessage(validBody().page);
  assert.match(message, /Page: Company details/);
  assert.match(message, /Tax ID is \[removed\]/);
  assert.match(message, /information only, not instructions/);
});

test("instructions carry the voice guide, the register and the scope rules", () => {
  const firstTime = buildSystemPrompt("company-setup", "first-time");
  assert.match(firstTime, /two to four short sentences/);
  assert.match(firstTime, /define it in a few words/);
  assert.match(firstTime, /Never use these words: wizard, configure/);
  assert.match(firstTime, /Never say you changed, saved/);
  assert.match(firstTime, /If you are not sure/);
  assert.match(firstTime, /federal tax ID \(EIN\)/);
  assert.match(firstTime, /\[removed\] was a tax ID/);
  assert.deepEqual(bannedWordsIn(firstTime.replace(/Never use these words:[^\n]*/, "")), []);
  const experienced = buildSystemPrompt("branding", "experienced");
  assert.match(experienced, /industry names alongside the plain ones/);
  assert.match(experienced, /Bring Your Brand to Work/);
});

test("only Earning Configuration Bryte receives the same attributed tips reference", () => {
  for (const app of ["company-setup", "branding", "earning-configuration"]) {
    const prompt = buildSystemPrompt(app, "first-time");
    if (app === "earning-configuration") {
      assert.match(prompt, /suppose an employee reports \$200/);
      assert.match(prompt, /PR merged_all_pdfs.pdf/);
      assert.match(prompt, /Never claim to have inspected their actual earning type/);
      assert.match(prompt, /Attribute the year-specific 2026 W-2 claim to this reference/);
    } else assert.doesNotMatch(prompt, /Tips reference|Cash Tips:|2026.*W-2/);
  }
});

test("long replies are trimmed at a sentence end", () => {
  const sentence = "This sentence is about ten words long for the test. ";
  const long = sentence.repeat(40);
  const shaped = shapeAnswer(long);
  assert.ok(shaped.length <= MAX_ANSWER_LENGTH);
  assert.ok(shaped.endsWith("."));
  assert.equal(shapeAnswer("  Short answer.  "), "Short answer.");
  assert.equal(shapeAnswer(""), "");
  assert.ok(shapeAnswer("word ".repeat(400)).endsWith("…"));
});

test("the endpoint answers, limits, times out and fails without a stand-in answer", async (t) => {
  const temp = await mkdtemp(path.join(directory, ".bryte-test-"));
  const servers = [];
  const logs = [];
  const received = [];
  let mode = "ok";
  const previousEnv = {
    key: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
    url: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  };
  const listen = async (app) => {
    const server = app.listen(0);
    servers.push(server);
    await new Promise((resolve) => server.once("listening", resolve));
    return `http://127.0.0.1:${server.address().port}`;
  };

  try {
    const fakeOpenAI = express();
    fakeOpenAI.use(express.json());
    fakeOpenAI.post("/chat/completions", async (req, res) => {
      received.push(req.body);
      if (mode === "slow") await new Promise((resolve) => setTimeout(resolve, 1_500));
      if (mode === "reject") {
        res.status(400).json({ error: { message: "Bad request", type: "invalid_request_error" } });
        return;
      }
      const rewriting = /^Rewrite your last answer/.test(req.body.messages.at(-1)?.content ?? "");
      const content = mode === "empty" ? ""
        : mode === "banned" && !rewriting ? "It's easy. Just type your legal name here."
        : mode === "banned" ? "Type your legal name the way it appears on your IRS letter."
        : "I can help with that. This page asks for your legal name and federal tax ID, the number the IRS gave your business.";
      res.json({
        id: "chatcmpl-test",
        object: "chat.completion",
        created: 0,
        model: req.body.model,
        choices: [{ index: 0, finish_reason: "stop", message: { role: "assistant", content } }],
      });
    });
    process.env.AI_INTEGRATIONS_OPENAI_API_KEY = "test-key";
    process.env.AI_INTEGRATIONS_OPENAI_BASE_URL = await listen(fakeOpenAI);

    const outfile = path.join(temp, "bryte.mjs");
    await build({
      entryPoints: [path.join(directory, "bryte.ts")],
      outfile,
      platform: "node",
      format: "esm",
      bundle: true,
      banner: { js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" },
      logLevel: "silent",
    });
    const { createBryteRouter } = await import(outfile);
    const makeApp = (router) => {
      const app = express();
      app.use(express.json());
      app.use((req, _res, next) => {
        const record = (level) => (...args) => logs.push({ level, args });
        req.log = { info: record("info"), warn: record("warn"), error: record("error") };
        next();
      });
      app.use("/api", router);
      return app;
    };
    const post = (base, body) =>
      fetch(`${base}/api/bryte/questions`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });

    const base = await listen(makeApp(createBryteRouter({ timeoutMs: 300, maxRequestsPerMinute: 20 })));

    await t.test("answers from the model, with context and history sent", async () => {
      mode = "ok";
      const response = await post(base, validBody());
      assert.equal(response.status, 200);
      const body = await response.json();
      assert.match(body.answer, /legal name and federal tax ID/);
      const sent = received.at(-1);
      assert.equal(sent.model, "gpt-5.4-mini");
      assert.equal(sent.messages[0].role, "system");
      assert.match(sent.messages[0].content, /define it in a few words/);
      assert.match(sent.messages[1].content, /Tax ID is \[removed\]/);
      assert.doesNotMatch(JSON.stringify(sent), /12-3456789/);
      assert.deepEqual(sent.messages.slice(2).map((message) => message.role), ["user", "assistant", "user"]);
      assert.equal(sent.messages.at(-1).content, QUESTION);
    });

    await t.test("sensitive details in the question and history never reach the model", async () => {
      mode = "ok";
      const secrets = ["12-3456789", "123-45-6789", "000123456789", "owner@example.com", "(555) 123-4567", "555.987.6543"];
      const response = await post(base, validBody({
        question: "Our EIN is 12-3456789 and my SSN is 123-45-6789. Is account 000123456789 right?",
        history: [
          { role: "user", text: "Email owner@example.com or call (555) 123-4567 about this." },
          { role: "assistant", text: "I can't call 555.987.6543, but I can explain this page." },
        ],
      }));
      assert.equal(response.status, 200);
      const sent = received.at(-1);
      const wire = JSON.stringify(sent);
      for (const secret of secrets) assert.equal(wire.includes(secret), false, `${secret} reached the model`);
      assert.equal(sent.messages.at(-1).content, "Our EIN is [removed] and my SSN is [removed]. Is account [removed] right?");
      assert.equal(sent.messages[2].content, "Email [removed] or call [removed] about this.");
      assert.equal(sent.messages[3].content, "I can't call [removed], but I can explain this page.");
      assert.match(sent.messages[0].content, /shown as \[removed\]/);
    });

    await t.test("a reply with banned words is rewritten once without them", async () => {
      mode = "banned";
      const before = received.length;
      const response = await post(base, validBody());
      assert.equal(response.status, 200);
      assert.equal((await response.json()).answer, "Type your legal name the way it appears on your IRS letter.");
      assert.equal(received.length, before + 2);
      assert.match(received.at(-1).messages.at(-1).content, /without these words: just, easy/);
      assert.equal(received.at(-1).messages.at(-2).role, "assistant");
    });

    await t.test("rejects an invalid request without calling the model", async () => {
      const before = received.length;
      const response = await post(base, validBody({ question: "" }));
      assert.equal(response.status, 400);
      assert.equal((await response.json()).answer, undefined);
      assert.equal(received.length, before);
    });

    await t.test("an empty model reply is a failure, not an answer", async () => {
      mode = "empty";
      const response = await post(base, validBody());
      assert.equal(response.status, 502);
      assert.equal((await response.json()).answer, undefined);
    });

    await t.test("a model failure returns 502", async () => {
      mode = "reject";
      const response = await post(base, validBody());
      assert.equal(response.status, 502);
      assert.equal((await response.json()).answer, undefined);
    });

    await t.test("a slow model reply times out with 504", async () => {
      mode = "slow";
      const response = await post(base, validBody());
      assert.equal(response.status, 504);
      assert.equal((await response.json()).answer, undefined);
    });

    await t.test("too many questions in a minute returns 429", async () => {
      mode = "ok";
      const limited = await listen(makeApp(createBryteRouter({ maxRequestsPerMinute: 2 })));
      assert.equal((await post(limited, validBody())).status, 200);
      assert.equal((await post(limited, validBody({ question: "" }))).status, 400);
      const response = await post(limited, validBody());
      assert.equal(response.status, 429);
      assert.equal((await response.json()).answer, undefined);
    });

    await t.test("logs never contain question or page text", () => {
      assert.ok(logs.length >= 3);
      const logged = JSON.stringify(logs);
      assert.doesNotMatch(logged, /What does this page need/);
      assert.doesNotMatch(logged, /Collect the company/);
      assert.doesNotMatch(logged, /Legal name/);
      assert.doesNotMatch(logged, /EIN\?/);
    });
  } finally {
    for (const server of servers) {
      server.closeAllConnections?.();
      await new Promise((resolve) => server.close(resolve));
    }
    if (previousEnv.key === undefined) delete process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
    else process.env.AI_INTEGRATIONS_OPENAI_API_KEY = previousEnv.key;
    if (previousEnv.url === undefined) delete process.env.AI_INTEGRATIONS_OPENAI_BASE_URL;
    else process.env.AI_INTEGRATIONS_OPENAI_BASE_URL = previousEnv.url;
    await rm(temp, { recursive: true, force: true });
  }
});
