import { Router, type IRouter } from 'express'
import type OpenAI from 'openai'
import { ReviewPaymentFactsBody } from '@workspace/api-zod'
import { redactSensitive } from '../lib/bryteAnswer'
import { createOpenAIClient, errorSummary } from '../lib/earningAI'
import { paymentFactSchema, paymentFactInstructions, paymentFactResult, validPaymentFacts } from '../lib/earningPaymentFacts'
import { normalizePaymentFactQuotes } from '@workspace/setup-shared/prototypes/_shared-earning-configuration/paymentFacts'

export function createPaymentFactsRouter({ createClient = createOpenAIClient, timeoutMs = 25_000, maxRequestsPerMinute = 30 } = {}): IRouter {
  const router = Router()
  const windows = new Map<string, { count: number; until: number }>()
  router.post('/earnings/payment-facts', async (req, res): Promise<void> => {
    const fail = (status: number, code: string) => res.status(status).json({
      code, error: 'We couldn’t check these payment facts. Try again, or return to the overtime review. Your answers stay saved.',
    })
    const now = Date.now()
    for (const [key, window] of windows) if (window.until <= now) windows.delete(key)
    const key = req.ip || req.socket.remoteAddress || 'unknown'
    const window = windows.get(key) ?? { count: 0, until: now + 60_000 }
    windows.set(key, window)
    if (++window.count > maxRequestsPerMinute) { fail(429, 'rate_limited'); return }
    const parsed = ReviewPaymentFactsBody.strict().safeParse(req.body)
    if (!parsed.success || new Set(parsed.data.statements.map(entry => entry.id)).size !== parsed.data.statements.length) {
      fail(400, 'invalid_request'); return
    }
    const input = { ...parsed.data, statements: parsed.data.statements.map(entry => ({ ...entry, text: redactSensitive(entry.text),
      ...(entry.question ? { question: redactSensitive(entry.question) } : {}) })) }
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), timeoutMs)
    try {
      const client = createClient()
      const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
        { role: 'system', content: paymentFactInstructions(input) }, { role: 'user', content: JSON.stringify(input) },
      ]
      for (let attempt = 0; attempt < 2; attempt++) {
        const result = await client.chat.completions.create({
          model: 'gpt-5.4-mini', max_completion_tokens: 4096, reasoning_effort: 'low',
          response_format: { type: 'json_schema', json_schema: { name: 'payment_facts', strict: true, schema: paymentFactSchema(input) } },
          messages,
        }, { signal: controller.signal })
        const content = result.choices[0]?.message?.content ?? ''
        let raw: unknown
        try { raw = JSON.parse(content) } catch { raw = null }
        raw = normalizePaymentFactQuotes(paymentFactResult(raw, input), input)
        if (validPaymentFacts(raw, input)) { res.json(raw); return }
        req.log.warn({ category: 'invalid_response', attempt: attempt + 1 }, 'Payment facts response rejected')
        messages.push({ role: 'assistant', content: content || '{}' }, { role: 'user', content:
          'Correct the response structure and citations. Use only allowed fact keys, unique keys, supplied source IDs and exact nonempty excerpts of answer text, not question text. Complete every required questionCoverage key with null or a valid answer citation; source-description cannot establish question coverage. Do not infer facts to make a response complete. Return JSON only.' })
      }
      fail(502, 'invalid_response')
    } catch (error) {
      req.log.error({ upstream: errorSummary(error) }, 'Payment facts unavailable')
      fail(controller.signal.aborted ? 504 : 502, controller.signal.aborted ? 'timed_out' : 'unavailable')
    } finally { clearTimeout(timer) }
  })
  return router
}
export default createPaymentFactsRouter()
