import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { TIPS_KNOWLEDGE, TIPS_KNOWLEDGE_PROMPT } from "../lib/earningTipsKnowledge.ts";
import { buildSystemPrompt } from "../lib/bryteAnswer.ts";

test("the complete uploaded source is retained verbatim and both consumers share it", async () => {
  const original = await readFile(new URL("../../../../attached_assets/Pasted-In-UKG-Ready-we-need-the-customer-to-clarify-how-employ_1791504442166.txt", import.meta.url), "utf8");
  assert.equal(TIPS_KNOWLEDGE.text, original);
  assert.equal(TIPS_KNOWLEDGE.citedDocument, "PR merged_all_pdfs.pdf");
  assert.ok(TIPS_KNOWLEDGE_PROMPT.includes(original));
  assert.ok(buildSystemPrompt("earning-configuration", "experienced").includes(TIPS_KNOWLEDGE_PROMPT));
  for (const phrase of ["Cash Tips:", "Charge Tips:", "Indirect Tips:", "Configuration Verification Checklist",
    "Insufficient Information", "For 2026", "$200"]) assert.ok(original.includes(phrase));
});
