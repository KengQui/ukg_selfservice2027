import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";
import { build } from "esbuild";

const directory = path.dirname(fileURLToPath(import.meta.url));
const purposes = { MILEAGE: "Business mileage", AUTO: "Vehicle allowance", PERDIEM: "Daily meal allowance",
  INTERNET: "Internet expenses", UNIFORM: "Required uniforms", TOOLS: "Business tools" };
const request = (category, purpose = purposes[category]) => ({ category, purpose,
  evidence: [{ type: "customer-answer", verification: "customer-confirmed", date: "2026-10-09", scope: "Payment purpose only", quote: purpose }],
  method: "reimbursement", answers: [{ id: "method", question: "How is the amount calculated?", answer: "Approved business expenses", component: "reimbursement" }], questionsLeft: 6 });
const result = (overrides = {}) => ({ next: "tax", component: "reimbursement", question: null, answerFormat: null,
  discovery: { status: "sufficient", missingFact: null, answerIds: ["method"] },
  reason: "Business facts are known; intended tax treatment still needs confirmation.", confirmations: [], ...overrides });

test("reimbursement categories reuse scoped validation without tax shortcuts", async t => {
  const temp = await mkdtemp(path.join(directory, ".reimbursement-test-"));
  try {
    for (const name of ["earningCellReview", "earningReimbursementKnowledge", "earningCustomerQuestions"]) {
      await build({ entryPoints: [path.join(directory, `../lib/${name}.ts`)], outfile: path.join(temp, `${name}.mjs`),
        bundle: true, platform: "node", format: "esm", logLevel: "silent",
        banner: { js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" } });
    }
    const { validateCellReview, cellMessage } = await import(path.join(temp, "earningCellReview.mjs"));
    const { validReimbursementScope, REIMBURSEMENT_INSTRUCTIONS } = await import(path.join(temp, "earningReimbursementKnowledge.mjs"));
    const { validateCustomerQuestions } = await import(path.join(temp, "earningCustomerQuestions.mjs"));
    for (const category of Object.keys(purposes)) await t.test(`${category}: provenance, missing facts and pending outcomes`, () => {
      const input = request(category);
      assert.equal(validReimbursementScope(input), true);
      assert.equal(validReimbursementScope({ ...input, purpose: "A payment" }), false);
      assert.equal(validReimbursementScope({ ...input, evidence: [] }), false);
      assert.equal(validReimbursementScope({ ...input, evidence: [{ ...input.evidence[0], date: "unknown" }] }), false);
      assert.equal(validateCellReview(result(), input).ok, true);
      assert.equal(validateCellReview(result({ next: "pending" }), input).ok, false);
      assert.equal(validateCellReview(result({ next: "pending", discovery: { status: "unsupported", missingFact: "A third payment component needs review", answerIds: ["method"] } }), input).ok, true);
      assert.equal(validateCellReview(result({ next: "pending", discovery: { status: "missing", missingFact: "Intended tax treatment", answerIds: ["method"] } }), input).ok, false);
      assert.equal(validateCellReview(result(), { ...input, questionsLeft: 0 }).ok, true);
      assert.equal(validateCellReview(result({ next: "reimbursement-basis" }), input).ok, false);
      assert.ok(REIMBURSEMENT_INSTRUCTIONS.includes(`${category}:`));
      assert.match(cellMessage(input), /Payment purpose only/);
    });
    await t.test("repeated questions, capped clarification, bogus tax or setup claims are rejected", () => {
      const input = request("MILEAGE");
      const clarify = result({ next: "clarify", question: input.answers[0].question, answerFormat: { kind: "text", options: null } });
      assert.equal(validateCellReview(clarify, input).ok, false);
      assert.equal(validateCellReview({ ...clarify, question: "Are business miles documented?" }, { ...input, questionsLeft: 0 }).ok, false);
      assert.equal(validateCellReview(result({ confirmations: [{ component: "reimbursement", intent: "nontaxable", answerId: "method", quote: "Approved business expenses" }] }), input).ok, false);
      for (const reason of ["The whole payment is taxable.", "This payment is nontaxable.", "You must split the payment."]) {
        assert.equal(validateCellReview(result({ reason }), input).ok, false, reason);
      }
    });
    await t.test("applicable explicit intent can be reused with exact provenance, independent components stay separate", () => {
      const input = { ...request("PERDIEM"), method: "both", answers: [
        { id: "method", question: "How?", answer: "A fixed allowance plus additional travel expenses.", component: "payment" },
        { id: "intent", question: "What has been confirmed?", answer: "Our company has confirmed the expense reimbursement qualifies for tax-free treatment.", component: "reimbursement" },
      ] };
      const confirmation = { component: "reimbursement", intent: "nontaxable", answerId: "intent", quote: input.answers[1].answer };
      assert.equal(validateCellReview(result({ component: "allowance", confirmations: [confirmation] }), input).ok, true);
      assert.equal(validateCellReview(result({ confirmations: [{ ...confirmation, component: "allowance" }] }), input).ok, false);
    });
    await t.test("special and question-form tax treatment cannot become blanket confirmation", () => {
      for (const answer of ["We intend this payment to be taxable for federal tax only.", "Should we treat this payment as taxable?",
        "Our company confirmed nontaxable treatment except FICA."]) {
        const intent = answer.includes("nontaxable") ? "nontaxable" : "taxable";
        const input = { ...request("PERDIEM"), answers: [{ id: "special", question: "What applies?", answer, component: "reimbursement" }] };
        assert.equal(validateCellReview(result({ confirmations: [{ component: "reimbursement", intent, answerId: "special", quote: answer }] }), input).ok, false);
      }
    });
    await t.test("customer drafts cannot change the current reimbursement question or assume a tax-bearing match", () => {
      const input = { reimbursement: true, code: "MISC7", standardQuestion: "How are eligible travel days determined?", allowedAnswerKinds: ["text"] };
      const value = { questions: [input.standardQuestion], answerKinds: ["text"], reason: "Travel days are needed to understand how the allowance is calculated." };
      assert.equal(validateCustomerQuestions(value, input).ok, true);
      assert.equal(validateCustomerQuestions({ ...value, questions: ["What does MISC7 mean?"] }, input).ok, false);
    });
  } finally { await rm(temp, { recursive: true, force: true }); }
});
