import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";
import express from "express";
import { build } from "esbuild";
import { SuggestEarningNameBody } from "../../../../lib/api-zod/src/generated/api.ts";
import { BANNED_TERMS, bannedWordsIn } from "../lib/bryteAnswer.ts";

const directory = path.dirname(fileURLToPath(import.meta.url));

// The naming helpers import other modules without file extensions, so they are bundled rather than type-stripped.
async function bundle(entry, temp) {
  const outfile = path.join(temp, `${path.basename(entry, ".ts")}.mjs`);
  await build({
    entryPoints: [entry],
    outfile,
    platform: "node",
    format: "esm",
    bundle: true,
    banner: { js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" },
    logLevel: "silent",
  });
  return import(outfile);
}
const helperTemp = await mkdtemp(path.join(directory, ".earning-name-helpers-"));
const { EARNING_NAME_INSTRUCTIONS, buildNamingMessage, correctionRequest, validateNaming } = await bundle(path.join(directory, "../lib/earningName.ts"), helperTemp)
  .finally(() => rm(helperTemp, { recursive: true, force: true }));
const DESCRIPTION = "Monthly pay for the warehouse lead covering the night crew roster";

function validBody(overrides = {}) {
  return {
    code: "ADJ2",
    source: { label: "Sample pay register", description: "Adjustments" },
    description: DESCRIPTION,
    answers: [
      { question: "Is ADJ2 paid as a flat amount or at an hourly rate?", answer: "Flat amount" },
      { question: "Is ADJ2 a one-time payment or recurring?", answer: "Recurring" },
    ],
    lookup: { outcome: "noSuitableReference", reason: "No sample Ready reference fits a recurring flat amount." },
    ...overrides,
  };
}

const SUGGESTION = { outcome: "suggestion", name: "Lead pay", rationale: "The team describes recurring pay for leading the night crew. Lead pay tells employees what the amount is for on their pay statements.", question: null };
const NEEDS_INFO = { outcome: "needsInformation", name: null, rationale: null, question: "What work or event does ADJ2 pay for?" };

test("naming requests are bounded and need an explicit no-suitable-reference lookup", () => {
  assert.equal(SuggestEarningNameBody.safeParse(validBody()).success, true);
  for (const code of ["Special Pay", "Overtime ENG", "Uploaded OT", "SPPAY"]) {
    assert.equal(SuggestEarningNameBody.safeParse(validBody({ code })).success, true, code);
  }
  assert.equal(SuggestEarningNameBody.safeParse(validBody({ source: { label: "Sample pay register", description: null } })).success, true);
  assert.equal(SuggestEarningNameBody.safeParse(validBody({ description: "" })).success, false);
  assert.equal(SuggestEarningNameBody.safeParse(validBody({ description: "a".repeat(501) })).success, false);
  assert.equal(SuggestEarningNameBody.safeParse(validBody({ code: "adj2; drop" })).success, false);
  for (const code of ["", "a".repeat(17), "<Special Pay>"]) {
    assert.equal(SuggestEarningNameBody.safeParse(validBody({ code })).success, false, code);
  }
  // The same bound as the check request: follow-ups plus answers to the AI's own questions.
  assert.equal(SuggestEarningNameBody.safeParse(validBody({ answers: Array(12).fill(validBody().answers[0]) })).success, true);
  assert.equal(SuggestEarningNameBody.safeParse(validBody({ answers: Array(13).fill(validBody().answers[0]) })).success, false);
  for (const outcome of ["reference", "unavailable", "lookupFailed", "needsMoreInfo"]) {
    assert.equal(SuggestEarningNameBody.safeParse(validBody({ lookup: { outcome, reason: "x" } })).success, false, outcome);
  }
});

test("instructions keep naming bounded to purpose and away from payroll treatment", () => {
  assert.match(EARNING_NAME_INSTRUCTIONS, /found no suitable Ready reference/);
  assert.match(EARNING_NAME_INSTRUCTIONS, /untrusted data/);
  assert.match(EARNING_NAME_INSTRUCTIONS, /needsInformation/);
  assert.match(EARNING_NAME_INSTRUCTIONS, /pay statement/);
  assert.match(EARNING_NAME_INSTRUCTIONS, /written to the customer/);
  assert.match(EARNING_NAME_INSTRUCTIONS, /actual current label \(source.description when supplied, otherwise code\)/);
  assert.match(EARNING_NAME_INSTRUCTIONS, /employee reading their pay statement/);
  assert.match(EARNING_NAME_INSTRUCTIONS, /do not recap why no reference matched/);
  assert.match(EARNING_NAME_INSTRUCTIONS, /second language with customers/);
  assert.match(EARNING_NAME_INSTRUCTIONS, /Do not claim a rename is legally required/);
  assert.doesNotMatch(EARNING_NAME_INSTRUCTIONS, /written to the setup team|why the name is clear to employees/);
  assert.match(EARNING_NAME_INSTRUCTIONS, /Never state or imply a Ready ID/);
  assert.match(EARNING_NAME_INSTRUCTIONS, /never claim a verified classification/);
  assert.match(EARNING_NAME_INSTRUCTIONS, /Never assert legal or tax treatment, tax forms, W-2 boxes, reporting treatment, FLSA status, overtime/);
  assert.deepEqual(bannedWordsIn(EARNING_NAME_INSTRUCTIONS.replace(/don't use these words:[^\n]*/i, "")), []);
  // The banned-word sentence names every term the result check rejects, so the model is told about each one.
  assert.deepEqual(bannedWordsIn(EARNING_NAME_INSTRUCTIONS.match(/don't use these words:[^\n]*/i)[0]), [...BANNED_TERMS]);
  // Supplied source facts can be cited; only document evidence that wasn't supplied is off limits.
  assert.match(EARNING_NAME_INSTRUCTIONS, /document evidence that wasn't supplied/);
  const message = buildNamingMessage(validBody({ description: "Paid to jo@example.com, EIN 12-3456789" }));
  assert.match(message, /as JSON data/);
  assert.doesNotMatch(message, /jo@example\.com|12-3456789/);
});

test("model results are checked against the naming contract", () => {
  assert.deepEqual(validateNaming(SUGGESTION, "ADJ2"), { ok: true, value: SUGGESTION });
  assert.deepEqual(validateNaming(NEEDS_INFO, "ADJ2"), { ok: true, value: NEEDS_INFO });
  const issue = (value) => { const result = validateNaming(value, "ADJ2"); return result.ok ? "ok" : result.issue; };
  assert.equal(issue({ ...SUGGESTION, name: "Adjustments" }), "generic_name");
  assert.equal(issue({ ...SUGGESTION, name: "ADJ2 lead pay" }), "contains_code");
  assert.equal(issue({ ...SUGGESTION, name: "A really long custom name that keeps going" }), "name_length");
  // Compact register labels can be one word, but must stay within 12 characters.
  assert.equal(issue({ ...SUGGESTION, name: "Bilingual" }), "ok");
  assert.equal(issue({ ...SUGGESTION, name: "Language stipend" }), "name_length");
  assert.equal(issue({ ...SUGGESTION, name: "Second language stipend" }), "name_length");
  assert.equal(issue({ ...SUGGESTION, name: "Night crew lead duty pay" }), "name_length");
  assert.equal(issue({ ...SUGGESTION, name: "Crew lead earning" }), "name_terms");
  // Ordinary payroll-treatment claims are refused, not only form numbers.
  for (const rationale of [
    "It counts toward overtime for the crew leads.",
    "It's reported on tax forms at year end.",
    "Employees see it on their tax forms.",
    "This amount is taxed like regular wages.",
    "It's exempt from withholding.",
    "We classified it as an earning for leads.",
  ]) assert.equal(issue({ ...SUGGESTION, rationale }), "forbidden_claim", rationale);
  assert.equal(issue({ ...NEEDS_INFO, question: "Does ADJ2 count toward overtime?" }), "forbidden_claim");
  assert.equal(issue({ ...SUGGESTION, rationale: "This shows on the W-2 in box 14." }), "forbidden_claim");
  assert.equal(issue({ ...SUGGESTION, rationale: "It's taxable and counts toward the regular rate." }), "forbidden_claim");
  assert.equal(issue({ ...SUGGESTION, rationale: "Matches Ready reference RDY-E-204." }), "forbidden_claim");
  assert.equal(issue({ ...SUGGESTION, rationale: "It's easy for employees to read." }), "banned_word");
  // Names come back in sentence case, keeping acronyms.
  assert.equal(validateNaming({ ...SUGGESTION, name: "Lead Pay" }, "ADJ2").value.name, "Lead pay");
  assert.equal(validateNaming({ ...SUGGESTION, name: "PTO Payout" }, "ADJ2").value.name, "PTO payout");
  // The correction names the words to replace, so the one retry can fix them.
  const banned = validateNaming({ ...SUGGESTION, rationale: "It's easy for employees to read." }, "ADJ2");
  assert.deepEqual(banned.words, ["easy"]);
  assert.match(correctionRequest(banned.issue, banned.words), /without these words: easy/);
  assert.equal(issue({ ...SUGGESTION, question: "Anything else?" }), "shape");
  assert.equal(issue({ ...NEEDS_INFO, name: "Lead pay" }), "shape");
  assert.equal(issue({ outcome: "reference", name: "x" }), "shape");
  assert.equal(issue(null), "shape");
});

test("the endpoint suggests, asks, limits, times out and fails without a stand-in name", async (t) => {
  const temp = await mkdtemp(path.join(directory, ".earning-names-test-"));
  const servers = [];
  const logs = [];
  const received = [];
  let mode = "ok";
  const previousEnv = {
    key: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
    url: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  };
  const listen = async (app) => {
    const server = app.listen(0);
    servers.push(server);
    await new Promise((resolve) => server.once("listening", resolve));
    return `http://127.0.0.1:${server.address().port}`;
  };

  try {
    const fakeOpenAI = express();
    fakeOpenAI.use(express.json());
    fakeOpenAI.post("/chat/completions", async (req, res) => {
      received.push(req.body);
      if (mode === "slow") await new Promise((resolve) => setTimeout(resolve, 1_500));
      if (mode === "reject") {
        res.status(400).json({ error: { message: "Bad request", type: "invalid_request_error" } });
        return;
      }
      const correcting = /^Your result didn't meet the rules/.test(req.body.messages.at(-1)?.content ?? "");
      const content = mode === "info" ? JSON.stringify(NEEDS_INFO)
        : mode === "malformed" ? "not json"
        : mode === "w2" && !correcting ? JSON.stringify({ ...SUGGESTION, rationale: "Employees will see it on their W-2." })
        : mode === "alwaysGeneric" ? JSON.stringify({ ...SUGGESTION, name: "Miscellaneous" })
        : JSON.stringify(SUGGESTION);
      res.json({
        id: "chatcmpl-test",
        object: "chat.completion",
        created: 0,
        model: req.body.model,
        choices: [{ index: 0, finish_reason: "stop", message: { role: "assistant", content } }],
      });
    });
    process.env.AI_INTEGRATIONS_OPENAI_API_KEY = "test-key";
    process.env.AI_INTEGRATIONS_OPENAI_BASE_URL = await listen(fakeOpenAI);

    const { createEarningNamesRouter } = await bundle(path.join(directory, "earningNames.ts"), temp);
    const makeApp = (router) => {
      const app = express();
      app.use(express.json());
      app.use((req, _res, next) => {
        const record = (level) => (...args) => logs.push({ level, args });
        req.log = { info: record("info"), warn: record("warn"), error: record("error") };
        next();
      });
      app.use("/api", router);
      return app;
    };
    const post = (base, body) =>
      fetch(`${base}/api/earnings/custom-name-suggestions`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });

    const base = await listen(makeApp(createEarningNamesRouter({ timeoutMs: 300, maxRequestsPerMinute: 30 })));

    await t.test("Special Pay reaches AI naming without changing the displayed code", async () => {
      mode = "ok";
      const response = await post(base, validBody({ code: "Special Pay" }));
      assert.equal(response.status, 200);
      assert.deepEqual(await response.json(), SUGGESTION);
      assert.match(received.at(-1).messages[1].content, /Special Pay/);
    });

    await t.test("suggests a name with strict structured output and labeled facts", async () => {
      mode = "ok";
      const response = await post(base, validBody());
      assert.equal(response.status, 200);
      assert.deepEqual(await response.json(), SUGGESTION);
      const sent = received.at(-1);
      assert.equal(sent.model, "gpt-5.4-mini");
      assert.equal(sent.response_format.type, "json_schema");
      assert.equal(sent.response_format.json_schema.strict, true);
      assert.equal(sent.messages[0].role, "system");
      assert.match(sent.messages[1].content, /Recurring/);
      assert.match(sent.messages[1].content, /noSuitableReference/);
    });

    await t.test("returns a targeted question when the purpose is unclear", async () => {
      mode = "info";
      const response = await post(base, validBody({ description: "Extra" }));
      assert.equal(response.status, 200);
      assert.deepEqual(await response.json(), NEEDS_INFO);
    });

    await t.test("sensitive details never reach the model", async () => {
      mode = "ok";
      const secrets = ["12-3456789", "123-45-6789", "000123456789", "owner@example.com", "(555) 123-4567"];
      const response = await post(base, validBody({
        description: "Paid to owner@example.com, EIN 12-3456789, SSN 123-45-6789",
        answers: [{ question: "Which account?", answer: "Account 000123456789, call (555) 123-4567" }],
      }));
      assert.equal(response.status, 200);
      const wire = JSON.stringify(received.at(-1));
      for (const secret of secrets) assert.equal(wire.includes(secret), false, `${secret} reached the model`);
    });

    await t.test("a result with a W-2 claim is corrected once", async () => {
      mode = "w2";
      const before = received.length;
      const response = await post(base, validBody());
      assert.equal(response.status, 200);
      assert.deepEqual(await response.json(), SUGGESTION);
      assert.equal(received.length, before + 2);
      assert.match(received.at(-1).messages.at(-1).content, /Remove any mention of tax/);
    });

    await t.test("an unusable result twice is invalid_response, never a substituted name", async () => {
      for (const unusable of ["alwaysGeneric", "malformed"]) {
        mode = unusable;
        const response = await post(base, validBody());
        assert.equal(response.status, 502);
        const body = await response.json();
        assert.equal(body.code, "invalid_response");
        assert.equal(body.name, undefined);
      }
    });

    await t.test("rejects an invalid request without calling the model", async () => {
      const before = received.length;
      const response = await post(base, validBody({ lookup: { outcome: "unavailable", reason: "Lookup is down" } }));
      assert.equal(response.status, 400);
      assert.equal((await response.json()).code, "invalid_request");
      assert.equal(received.length, before);
    });

    await t.test("a provider failure returns unavailable", async () => {
      mode = "reject";
      const response = await post(base, validBody());
      assert.equal(response.status, 502);
      const body = await response.json();
      assert.equal(body.code, "unavailable");
      assert.equal(body.name, undefined);
    });

    await t.test("a slow model reply times out with 504", async () => {
      mode = "slow";
      const response = await post(base, validBody());
      assert.equal(response.status, 504);
      assert.equal((await response.json()).code, "timed_out");
    });

    await t.test("too many requests in a minute returns 429", async () => {
      mode = "ok";
      const limited = await listen(makeApp(createEarningNamesRouter({ maxRequestsPerMinute: 2 })));
      assert.equal((await post(limited, validBody())).status, 200);
      assert.equal((await post(limited, validBody({ description: "" }))).status, 400);
      const response = await post(limited, validBody());
      assert.equal(response.status, 429);
      assert.equal((await response.json()).code, "rate_limited");
    });

    await t.test("logs never contain descriptions, answers or names", () => {
      assert.ok(logs.length >= 3);
      const logged = JSON.stringify(logs);
      assert.doesNotMatch(logged, /warehouse lead/);
      assert.doesNotMatch(logged, /Flat amount|Recurring/);
      assert.doesNotMatch(logged, /owner@example|12-3456789/);
      assert.doesNotMatch(logged, /Lead duty pay|Miscellaneous/);
    });
  } finally {
    for (const server of servers) {
      server.closeAllConnections?.();
      await new Promise((resolve) => server.close(resolve));
    }
    if (previousEnv.key === undefined) delete process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
    else process.env.AI_INTEGRATIONS_OPENAI_API_KEY = previousEnv.key;
    if (previousEnv.url === undefined) delete process.env.AI_INTEGRATIONS_OPENAI_BASE_URL;
    else process.env.AI_INTEGRATIONS_OPENAI_BASE_URL = previousEnv.url;
    await rm(temp, { recursive: true, force: true });
  }
});
