import { Router, type IRouter } from "express";
import OpenAI from "openai";
import { createOpenAIClient, errorSummary } from "../lib/earningAI";
import { SuggestEarningNameBody, SuggestEarningNameResponse, type EarningNameError } from "@workspace/api-zod";
import {
  EARNING_NAME_INSTRUCTIONS,
  EARNING_NAME_SCHEMA,
  buildNamingMessage,
  correctionRequest,
  validateNaming,
} from "../lib/earningName";

export interface EarningNamesRouterOptions {
  timeoutMs?: number;
  maxRequestsPerMinute?: number;
}

class InvalidNamingResult extends Error {}

// Earning Configuration shows each `error` below as written, so each names the problem and what to do next. The `code`
// sets them apart from other error responses at the same statuses, which get the app's general message instead.
const ERRORS = {
  invalid_request: "We couldn’t suggest a name from this answer. Check the description, then try again.",
  rate_limited: "We’ve suggested a lot of names in the last minute. Wait a minute, then try again.",
  unavailable: "We can’t suggest a name right now. Try again, or select Review later.",
  timed_out: "Suggesting a name took too long. Try again, or select Review later.",
  invalid_response: "We couldn’t come up with a clear name this time. Try again, or select Review later.",
} as const satisfies Record<EarningNameError["code"], string>;

const fail = (code: EarningNameError["code"]): EarningNameError => ({ code, error: ERRORS[code] });

/**
 * Suggests one custom earning name after an explicit no-suitable-reference lookup result. Request text is never logged,
 * and sensitive identifiers are removed before the model sees anything. A failure always returns an error, never a
 * stand-in name.
 */
export function createEarningNamesRouter({ timeoutMs = 20_000, maxRequestsPerMinute = 10 }: EarningNamesRouterOptions = {}): IRouter {
  const router: IRouter = Router();
  const requestWindows = new Map<string, { count: number; resetAt: number }>();

  function hasRateLimitCapacity(key: string): boolean {
    const now = Date.now();
    if (requestWindows.size > 1_000) {
      for (const [windowKey, window] of requestWindows) {
        if (window.resetAt <= now) requestWindows.delete(windowKey);
      }
    }
    const current = requestWindows.get(key);
    if (!current || current.resetAt <= now) {
      requestWindows.set(key, { count: 1, resetAt: now + 60_000 });
      return true;
    }
    if (current.count >= maxRequestsPerMinute) return false;
    current.count += 1;
    return true;
  }

  router.post("/earnings/custom-name-suggestions", async (req, res): Promise<void> => {
    const key = req.ip || req.socket.remoteAddress || "unknown";
    if (!hasRateLimitCapacity(key)) {
      res.status(429).json(fail("rate_limited"));
      return;
    }

    const parsed = SuggestEarningNameBody.safeParse(req.body);
    if (!parsed.success) {
      // Paths and codes only: the request text itself is never logged.
      req.log.warn(
        { issues: parsed.error.issues.map((issue) => ({ path: issue.path.join("."), code: issue.code })) },
        "Invalid earning name request",
      );
      res.status(400).json(fail("invalid_request"));
      return;
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const client = createOpenAIClient();
      const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
        { role: "system", content: EARNING_NAME_INSTRUCTIONS },
        { role: "user", content: buildNamingMessage(parsed.data) },
      ];
      const ask = async (conversation: OpenAI.Chat.Completions.ChatCompletionMessageParam[]) => {
        const completion = await client.chat.completions.create(
          {
            model: "gpt-5.4-mini",
            max_completion_tokens: 4096,
            reasoning_effort: "low",
            response_format: {
              type: "json_schema",
              json_schema: { name: "custom_earning_name", strict: true, schema: EARNING_NAME_SCHEMA },
            },
            messages: conversation,
          },
          { signal: controller.signal },
        );
        const content = completion.choices[0]?.message?.content ?? "";
        let raw: unknown;
        try {
          raw = JSON.parse(content);
        } catch {
          raw = null;
        }
        return { content, result: validateNaming(raw, parsed.data.code) };
      };

      let attempt = await ask(messages);
      if (!attempt.result.ok) {
        // Ask once for a correction; a second miss is an unusable result, never a substituted name.
        req.log.warn({ issue: attempt.result.issue, words: attempt.result.words }, "Earning name result needed a correction");
        attempt = await ask([
          ...messages,
          { role: "assistant", content: attempt.content || "{}" },
          { role: "user", content: correctionRequest(attempt.result.issue, attempt.result.words) },
        ]);
      }
      if (!attempt.result.ok) {
        req.log.warn({ issue: attempt.result.issue, words: attempt.result.words }, "Earning name result was unusable");
        throw new InvalidNamingResult();
      }
      res.json(SuggestEarningNameResponse.parse(attempt.result.value));
    } catch (error) {
      if (controller.signal.aborted) {
        req.log.warn("Earning name suggestion timed out");
        res.status(504).json(fail("timed_out"));
        return;
      }
      if (error instanceof InvalidNamingResult) {
        res.status(502).json(fail("invalid_response"));
        return;
      }
      req.log.error({ upstream: errorSummary(error) }, "Earning name suggestion failed");
      res.status(502).json(fail("unavailable"));
    } finally {
      clearTimeout(timeout);
    }
  });

  return router;
}

export default createEarningNamesRouter();
