import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";
import express from "express";
import { build } from "esbuild";

const directory = path.dirname(fileURLToPath(import.meta.url));
const input = { method: "allowance", answers: [
  { id: "method", question: "How does your company pay employees for cellphone costs?", answer: "Fixed amount" },
  { id: "allowance-purpose", question: "Why does your company provide the cellphone allowance?", answer: "Employees need to use their personal phones for work." },
], questionsLeft: 5 };
const result = (next = "tax", component = "allowance", extra = {}) => ({
  next, component, question: null, answerFormat: null,
  discovery: { status: next === "tax" ? "sufficient" : "missing", missingFact: next === "tax" ? null : "How the amount relates to business costs", answerIds: ["method"] },
  reason: "The business facts are clear; intended tax treatment still needs confirmation.", confirmations: [], ...extra,
});
const clarify = result("clarify", "allowance", { question: "How does the allowance relate to employees’ phone costs?", answerFormat: { kind: "text", options: null } });
const reported = { category: "CELL", method: "reimbursement", answers: [
  { id: "method", question: "How does your company pay employees for cellphone costs?", answer: "Actual expense reimbursement", component: "payment" },
  { id: "clarify-1", question: "What cellphone costs are repaid?", answer: "We reimburse the actual cost of monthly service on employees' personal cellphones needed for work. We have not confirmed the intended tax treatment.", component: "reimbursement" },
], questionsLeft: 5 };
const businessKnown = { status: "sufficient", missingFact: null, answerIds: ["method", "clarify-1"] };
const erroneousStop = result("pending", "reimbursement", {
  discovery: businessKnown,
  reason: "Actual monthly personal-cellphone service for work is repaid, but the company or adviser has not confirmed tax treatment, so the payment needs setup review.",
});

test("CELL scoped validation: material facts, no shortcuts, component confirmations and limits", async t => {
  const temp = await mkdtemp(path.join(directory, ".cell-contract-test-"));
  try {
    const outfile = path.join(temp, "contract.mjs");
    await build({ entryPoints: [path.join(directory, "../lib/earningCellReview.ts")], outfile, bundle: true, platform: "node", format: "esm",
      banner: { js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" }, logLevel: "silent" });
    const { validateCellReview, cellMessage, CELL_INSTRUCTIONS } = await import(outfile);
    await t.test("shared prompt plus bounded CELL knowledge and source applicability", () => {
      assert.match(CELL_INSTRUCTIONS, /2011-72/);
      assert.match(CELL_INSTRUCTIONS, /personally owned/i);
      assert.match(CELL_INSTRUCTIONS, /mapping context/);
      assert.match(CELL_INSTRUCTIONS, /not.*split|no.*split|never.*split/i);
      for (const method of ["allowance", "reimbursement", "both", "other"]) {
        const component = method === "reimbursement" ? "reimbursement" : method === "other" ? "payment" : "allowance";
        assert.equal(validateCellReview(result("tax", component), { ...input, method }).ok, true);
      }
    });
    await t.test("only missing calculation questions, not repeated questions or purpose identification", () => {
      assert.equal(validateCellReview(result("allowance-basis"), input).ok, true);
      assert.equal(validateCellReview(result("allowance-basis"), { ...input, answers: [...input.answers, { id: "allowance-basis", question: "How?", answer: "Standard amount" }] }).ok, false);
      assert.equal(validateCellReview({ ...clarify, question: input.answers[1].question }, input).ok, false);
      for (const question of ["What does CELL mean?", "Can you provide receipts each month?", "Does this meet accountable plan requirements?"]) {
        assert.equal(validateCellReview({ ...clarify, question }, input).ok, false, question);
      }
      assert.equal(validateCellReview(clarify, input).ok, true);
    });
    await t.test("independent Both treatments; wrong components and unsubstantiated confirmations fail", () => {
      const both = { ...input, method: "both", answers: [...input.answers, {
        id: "tax-allowance", question: "How should the allowance be treated?", answer: "Include the allowance in taxable wages.",
      }] };
      assert.equal(validateCellReview(result("tax", "reimbursement"), both).ok, true);
      assert.equal(validateCellReview(result("tax", "allowance"), both).ok, false);
      assert.equal(validateCellReview(result("tax", "payment"), both).ok, false);
      assert.equal(validateCellReview(result("tax", "reimbursement", { confirmations: [{
        component: "allowance", intent: "taxable", answerId: "tax-allowance", quote: "Include the allowance in taxable wages.",
      }] }), both).ok, true);
      const invented = result("tax", "allowance", { confirmations: [{ component: "allowance", intent: "nontaxable", answerId: "method", quote: "Fixed amount" }] });
      assert.equal(validateCellReview(invented, input).ok, false);
    });
    await t.test("explicit company-confirmed nontaxable intent is reusable, not historical treatment or business use alone", () => {
      const answer = "Our company has confirmed the payment qualifies for tax-free treatment.";
      const quoted = result("tax", "payment", { discovery: { status: "sufficient", missingFact: null, answerIds: ["description"] },
        confirmations: [{ component: "payment", intent: "nontaxable", answerId: "description", quote: answer }] });
      const request = { ...input, method: "other", answers: [{ id: "description", question: "How does it work?", answer }] };
      assert.equal(validateCellReview(quoted, request).ok, true);
      assert.equal(validateCellReview(quoted, { ...request, answers: [{ ...request.answers[0], answer: "It was historically nontaxable." }] }).ok, false);
      assert.equal(validateCellReview({ ...quoted, confirmations: [{ ...quoted.confirmations[0], quote: "It covers business calls." }] }, { ...request, answers: [{ ...request.answers[0], answer: "It covers business calls." }] }).ok, false);
    });
    await t.test("a retired question budget cannot end discovery or prevent the next material question", () => {
      const full = { ...input, questionsLeft: 6, answers: [...input.answers, ...Array.from({ length: 5 }, (_, i) => ({ id: `clarify-${i}`, question: `Question ${i}?`, answer: "Confirm" }))] };
      const discovery = { status: "missing", missingFact: "How the allowance relates to business costs", answerIds: ["method"] };
      assert.equal(JSON.parse(cellMessage(full)).questionsLeft, undefined);
      assert.equal(validateCellReview({ ...clarify, discovery }, full).ok, true);
      assert.equal(validateCellReview(result("allowance-basis", "allowance", { discovery }), full).ok, true);
      assert.equal(validateCellReview(result("pending", "allowance", { discovery }), full).ok, false);
      assert.equal(validateCellReview(result("tax"), full).ok, true); // May ask explicit tax choice if facts really suffice; not approval.
      assert.equal(validateCellReview({ ...result(), confirmations: [{ component: "allowance", intent: "taxable", answerId: "clarify-1", quote: "Confirm" }] }, full).ok, false);
    });
    await t.test("confirmation cannot cross Both components or bypass a compensation conflict", () => {
      const answer = "Our company confirms the allowance qualifies for nontaxable treatment.";
      const both = { ...input, method: "both", answers: [...input.answers, { id: "clarify-1", question: "Allowance intent?", answer }] };
      const confirmation = { component: "reimbursement", intent: "nontaxable", answerId: "clarify-1", quote: answer };
      assert.equal(validateCellReview(result("tax", "reimbursement", { confirmations: [confirmation] }), both).ok, false);
      const all = "Our company confirms both cellphone payments qualify for nontaxable treatment.";
      assert.equal(validateCellReview(result("tax", "reimbursement", { confirmations: [
        { ...confirmation, quote: all },
      ], discovery: { status: "sufficient", missingFact: null, answerIds: ["clarify-1"] } }), { ...both, answers: [{ id: "clarify-1", question: "What has the company confirmed?", answer: all, component: "allowance" }] }).ok, true);
      const compensation = { ...input, method: "other", answers: [
        { id: "method", question: "How does it work?", answer: "A cellphone bonus as additional compensation." },
        { id: "tax-payment", question: "Intended treatment?", answer },
      ] };
      assert.equal(validateCellReview(result("tax", "payment", { confirmations: [{ ...confirmation, component: "payment", answerId: "tax-payment" }] }), compensation).ok, false);
      assert.equal(validateCellReview(result("clarify", "payment", { question: "What business purpose supports the requested nontaxable treatment?", answerFormat: { kind: "text", options: null } }), compensation).ok, true);
      assert.equal(validateCellReview({ ...clarify, question: "Is the allowance a fixed amount or actual expense reimbursement?" }, input).ok, false);
    });
    await t.test("redacts outbound facts", () => {
      assert.doesNotMatch(cellMessage({ ...input, answers: [{ id: "description", question: "Details?", answer: "Contact example.person@example.test, SSN 123-45-6789" }] }), /example.person@example.test|123-45-6789/);
    });
    await t.test("reported business-ready reimbursement must reach tax, including at the cap", () => {
      for (const questionsLeft of [5, 0]) {
        const request = { ...reported, questionsLeft };
        assert.equal(validateCellReview(erroneousStop, request).ok, false);
        assert.equal(validateCellReview({ ...erroneousStop, next: "tax" }, request).ok, true);
        for (const status of ["missing"]) {
          assert.equal(validateCellReview({ ...erroneousStop, discovery: { ...businessKnown, status, missingFact: "Company tax qualification is not confirmed" } }, request).ok, false);
        }
      }
      assert.equal(validateCellReview({ ...erroneousStop, discovery: undefined }, reported).ok, false);
      assert.equal(validateCellReview({ ...erroneousStop, next: "tax", reason: "This reimbursement is ready for setup." }, reported).ok, false);
    });
    await t.test("a material business gap asks one question, while conflict and exhausted discovery stay open", () => {
      const discovery = { status: "missing", missingFact: "How the business portion of service cost is determined", answerIds: ["method"] };
      const gap = result("clarify", "reimbursement", { discovery, question: "How is the business portion of the service cost determined?", answerFormat: { kind: "text", options: null } });
      assert.equal(validateCellReview(gap, reported).ok, true);
      assert.equal(validateCellReview({ ...gap, next: "pending", question: null, answerFormat: null }, reported).ok, false);
      assert.equal(validateCellReview({ ...gap, next: "pending", question: null, answerFormat: null }, { ...reported, questionsLeft: 0 }).ok, false);
      assert.equal(validateCellReview(gap, { ...reported, questionsLeft: 0 }).ok, true);
      const conflicting = { ...reported, answers: [
        { id: "method", question: "How does it work?", answer: "This payment is additional compensation.", component: "payment" },
        { id: "tax-reimbursement", question: "Intended tax treatment?", answer: "Our company confirms it qualifies for nontaxable treatment.", component: "reimbursement" },
      ] };
      const conflict = { ...erroneousStop, discovery: { ...discovery, status: "conflict", missingFact: "The compensation purpose conflicts with requested nontaxable treatment", answerIds: ["method", "tax-reimbursement"] } };
      assert.equal(validateCellReview(conflict, conflicting).ok, true);
      assert.equal(validateCellReview({ ...conflict, discovery: { ...conflict.discovery, answerIds: ["method"] } }, conflicting).ok, false);
      assert.equal(validateCellReview({ ...erroneousStop, discovery: { ...businessKnown, answerIds: ["invented"] } }, reported).ok, false);
    });
    await t.test("explicit prior intent is reused, whereas Not sure cannot be confirmation", () => {
      const answer = "We intend to include this reimbursement in taxable wages.";
      const request = { ...reported, answers: [...reported.answers, { id: "intent", question: "What treatment is intended?", answer, component: "reimbursement" }] };
      const confirmation = { component: "reimbursement", intent: "taxable", answerId: "intent", quote: answer };
      assert.equal(validateCellReview({ ...erroneousStop, next: "tax", confirmations: [confirmation] }, request).ok, true);
      // This fixture includes an earlier description saying intent is unknown; the current explicit answer supersedes it.
      const known = { ...request, answers: request.answers.filter(a => a.id !== "clarify-1") };
      const knownResult = { ...erroneousStop, next: "tax", discovery: { ...businessKnown, answerIds: ["method", "intent"] } };
      assert.equal(validateCellReview(knownResult, known).ok, false);
      assert.equal(validateCellReview({ ...knownResult, confirmations: [confirmation] }, known).ok, true);
      const unsure = { ...reported, answers: [...reported.answers, { id: "tax-reimbursement", question: "Tax treatment?", answer: "Not sure", component: "reimbursement" }] };
      assert.equal(validateCellReview(erroneousStop, unsure).ok, true);
      assert.equal(validateCellReview({ ...erroneousStop, next: "tax" }, unsure).ok, false);
      assert.equal(validateCellReview({ ...erroneousStop, confirmations: [{ ...confirmation, answerId: "tax-reimbursement", quote: "Not sure" }] }, unsure).ok, false);
      const both = { ...reported, method: "both", answers: [...reported.answers,
        { id: "tax-allowance", question: "Allowance tax intent?", answer: "Not sure", component: "allowance" }] };
      assert.equal(validateCellReview({ ...erroneousStop, component: "allowance" }, both).ok, false);
      assert.equal(validateCellReview({ ...erroneousStop, next: "tax" }, both).ok, true);
    });
  } finally { await rm(temp, { recursive: true, force: true }); }
});

test("CELL HTTP correction retry, errors and exact contract", async t => {
  const temp = await mkdtemp(path.join(directory, ".cell-route-test-"));
  const servers = [];
  let calls = 0, mode = "tax";
  const bodies = [];
  const listen = async app => {
    const server = app.listen(0, "127.0.0.1"); servers.push(server);
    await new Promise(resolve => server.once("listening", resolve));
    return `http://127.0.0.1:${server.address().port}`;
  };
  try {
    const fake = express(); fake.use(express.json());
    fake.post("/chat/completions", async (req, res) => {
      calls++; bodies.push(req.body);
      if (mode === "timeout") await new Promise(resolve => setTimeout(resolve, 250));
      if (mode === "unavailable") return res.status(400).json({ error: { message: "Fixture unavailable" } });
      const corrected = req.body.messages.length > 2;
      const output = mode === "bad" || mode === "correct" && !corrected ? { bad: true }
        : mode === "contradiction" || mode === "correct-stop" && !corrected ? erroneousStop
        : mode === "correct-stop" ? { ...erroneousStop, next: "tax" } : mode === "clarify" ? clarify : result();
      res.json({ id: "fixture", object: "chat.completion", choices: [{ index: 0, finish_reason: "stop", message: { role: "assistant", content: JSON.stringify(output) } }] });
    });
    const baseURL = await listen(fake);
    const outfile = path.join(temp, "route.mjs");
    await build({ entryPoints: [path.join(directory, "earningCellReviews.ts")], outfile, bundle: true, platform: "node", format: "esm",
      banner: { js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" }, logLevel: "silent",
      plugins: [{ name: "test-provider", setup(build) {
        build.onLoad({ filter: /earningAI\.ts$/ }, () => ({ contents: `import OpenAI from "openai"; export const errorSummary = () => ({ kind: "fixture" }); export const createOpenAIClient = () => new OpenAI({ apiKey: "fixture-only", baseURL: ${JSON.stringify(baseURL)}, maxRetries: 0 });`, loader: "ts" }));
      } }],
    });
    const { createEarningCellReviewsRouter } = await import(outfile);
    const app = express(); app.use(express.json());
    app.use((req, _res, next) => { req.log = { error() {}, warn() {} }; next(); });
    app.use(createEarningCellReviewsRouter({ timeoutMs: 100 }));
    const api = await listen(app);
    const post = async body => { const response = await fetch(`${api}/earnings/cell-reviews`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }); return { status: response.status, body: await response.json() }; };
    await t.test("valid strict request and shared prompt", async () => {
      const response = await post(input);
      assert.equal(response.status, 200); assert.equal(response.body.next, "tax");
      assert.match(bodies.at(-1).messages[0].content, /CELL/);
      assert.equal((await post({ ...input, surprise: true })).status, 400);
    });
    await t.test("one correction then no fabricated question when still invalid", async () => {
      mode = "correct"; let before = calls;
      assert.equal((await post(input)).status, 200); assert.equal(calls - before, 2);
      mode = "bad"; before = calls;
      const response = await post(input);
      assert.equal(response.status, 502); assert.equal(response.body.code, "invalid_response"); assert.equal(calls - before, 2);
      assert.equal(response.body.question, undefined);
    });
    await t.test("unavailability and timeout are explicit retry/defer failures", async () => {
      mode = "unavailable"; assert.equal((await post(input)).body.code, "unavailable");
      mode = "timeout"; assert.equal((await post(input)).body.code, "timed_out");
    });
    await t.test("contradictory pending is corrected once, or returns recovery controls, never a fabricated decision", async () => {
      mode = "correct-stop"; let before = calls;
      const corrected = await post(reported);
      assert.equal(corrected.status, 200); assert.equal(corrected.body.next, "tax"); assert.equal(calls - before, 2);
      assert.match(bodies.at(-1).messages.at(-1).content, /unknown intent does not block/);
      mode = "contradiction"; before = calls;
      const invalid = await post(reported);
      assert.equal(invalid.status, 502); assert.equal(invalid.body.code, "invalid_response"); assert.equal(calls - before, 2);
      assert.match(invalid.body.error, /Try again.*Defer/);
      assert.equal(invalid.body.next, undefined);
    });
  } finally {
    await Promise.all(servers.map(server => new Promise(resolve => server.close(resolve))));
    await rm(temp, { recursive: true, force: true });
  }
});
