import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";
import { build } from "esbuild";

const directory = path.dirname(fileURLToPath(import.meta.url));
const temp = await mkdtemp(path.join(directory, ".earning-prompts-test-"));
const outfile = path.join(temp, "prompts.mjs");
// The prompt modules import other modules without file extensions, so they are bundled rather than type-stripped.
await build({
  stdin: {
    contents: [
      'export { GENERAL_PROMPT_RULES } from "../lib/earningPromptGeneral";',
      'export { answerReviewInstructions, PLAN_CONTRIBUTION_RULES, UNABLE_TO_IDENTIFY_REVIEW_RULES } from "../lib/earningAnswerReview";',
      'export { EARNING_CHECK_INSTRUCTIONS, EARNING_CHECK_PROCESS_RULES } from "../lib/earningCheck";',
      'export { EARNING_NAME_INSTRUCTIONS, EARNING_NAME_PROCESS_RULES } from "../lib/earningName";',
      'export { SHIFT_PREMIUM_INSTRUCTIONS, SHIFT_PREMIUM_PROCESS_RULES } from "../lib/earningShiftPremium";',
      'export { SHIFT_PREMIUM_KNOWLEDGE, SHIFT_PREMIUM_DECISION_INSTRUCTION } from "../lib/earningShiftPremiumKnowledge";',
    ].join("\n"),
    resolveDir: directory, loader: "ts",
  },
  outfile, platform: "node", format: "esm", bundle: true,
  banner: { js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" },
  logLevel: "silent",
});
const prompts = await import(outfile).finally(() => rm(temp, { recursive: true, force: true }));
const {
  GENERAL_PROMPT_RULES, answerReviewInstructions, PLAN_CONTRIBUTION_RULES, UNABLE_TO_IDENTIFY_REVIEW_RULES,
  EARNING_CHECK_INSTRUCTIONS, EARNING_CHECK_PROCESS_RULES, EARNING_NAME_INSTRUCTIONS, EARNING_NAME_PROCESS_RULES,
  SHIFT_PREMIUM_INSTRUCTIONS, SHIFT_PREMIUM_PROCESS_RULES, SHIFT_PREMIUM_KNOWLEDGE, SHIFT_PREMIUM_DECISION_INSTRUCTION,
} = prompts;
const PROCESSES = ["planContributions", "unableToIdentify", "needMoreInformation", "misclassified", "optimizationOvertime"];
const lines = prompt => prompt.split("\n");
const every = {
  ...Object.fromEntries(PROCESSES.map(process => [`answer review (${process})`, answerReviewInstructions(process)])),
  "description check": EARNING_CHECK_INSTRUCTIONS,
  naming: EARNING_NAME_INSTRUCTIONS,
  "shift premium relationship": SHIFT_PREMIUM_INSTRUCTIONS,
};

test("question reasons specify the missing fact, business consequence and supported use without contract changes", () => {
  for (const [name, prompt] of Object.entries(every)) {
    assert.match(prompt, /specific fact or permission still missing, why it matters for this payment, and the supported decision/, name);
    assert.match(prompt, /existing fields, sentence and character limits/, name);
    assert.match(prompt, /Never rewrite stored questions or evidence/, name);
  }
  assert.match(EARNING_CHECK_INSTRUCTIONS, /reason stays null/);
  assert.match(EARNING_NAME_INSTRUCTIONS, /keeping rationale null/);
  assert.match(SHIFT_PREMIUM_INSTRUCTIONS, /missing comparison fact first/);
  assert.match(answerReviewInstructions("planContributions"), /reason's one short sentence/);
});

test("ADJ2 guidance cannot infer inactivity or removal from zero register amounts", () => {
  assert.match(EARNING_CHECK_INSTRUCTIONS, /For ADJ2, absent source description means its purpose is unknown/);
  assert.match(EARNING_CHECK_INSTRUCTIONS, /Reported zero amounts are not proof of no payments, inactivity or retirement/);
  assert.match(EARNING_CHECK_INSTRUCTIONS, /Inclusion remains the customer's explicit decision after clarification/);
  assert.match(EARNING_CHECK_INSTRUCTIONS, /does not imply a separate code-list source/);
  assert.match(answerReviewInstructions("unableToIdentify"), /For ADJ2, reported zero amounts do not prove no payments, inactivity or retirement/);
});

test("every prompt contains the shared general part exactly once", () => {
  assert.ok(GENERAL_PROMPT_RULES.length >= 6);
  for (const [name, prompt] of Object.entries(every)) {
    for (const rule of GENERAL_PROMPT_RULES) assert.equal(lines(prompt).filter(line => line === rule).length, 1, `${name}: ${rule}`);
  }
});

test("every earning prompt preserves names but uses first-person or neutral product narration", () => {
  for (const [name, prompt] of Object.entries(every)) {
    assert.match(prompt, /Describe product actions as we\/us, never Ready or UKG Ready acting in the third person/, name);
    assert.match(prompt, /Beside company-practice choices starting with We, use neutral narration/, name);
    assert.match(prompt, /Quoted customer answers keep the customer's voice/, name);
  }
});

test("every operation uses the same evidence-sensitive missing-fact and stopping rule", () => {
  for (const [name, prompt] of Object.entries(every)) {
    assert.match(prompt, /known facts and their supplied sources/, name);
    assert.match(prompt, /which supported next decision its answer could change/, name);
    assert.match(prompt, /Brevity alone never requires a follow-up/, name);
    assert.match(prompt, /Reuse the original answer, earlier answers and the whole thread together/, name);
    assert.match(prompt, /proposal or a sufficient setup-team handoff/, name);
    assert.match(prompt, /Understanding purpose does not establish tax treatment/, name);
    assert.doesNotMatch(prompt, /isn't resolved on the first review|always ask what costs/, name);
  }
  const med = answerReviewInstructions("planContributions");
  assert.match(med, /brief reimbursement purpose can suffice/);
  assert.match(med, /return confirm, question null and medicalSetup/);
  assert.match(med, /never accept your own proposal/);
});

test("general rules live only in the general part", () => {
  const processLines = [...PLAN_CONTRIBUTION_RULES, ...UNABLE_TO_IDENTIFY_REVIEW_RULES, ...EARNING_CHECK_PROCESS_RULES, ...EARNING_NAME_PROCESS_RULES, ...SHIFT_PREMIUM_PROCESS_RULES];
  for (const pattern of [/untrusted data/, /\[removed\]/, /Don't use these words/i, /W-2/, /exclamation points/]) {
    assert.deepEqual(processLines.filter(line => pattern.test(line)), [], String(pattern));
    for (const [name, prompt] of Object.entries(every)) assert.equal(lines(prompt).filter(line => pattern.test(line)).length, 1, `${name}: ${pattern}`);
  }
});

test("plan rules reach only Who pays into each plan", () => {
  const plan = answerReviewInstructions("planContributions");
  for (const rule of PLAN_CONTRIBUTION_RULES) assert.ok(lines(plan).includes(rule));
  for (const [name, prompt] of Object.entries(every).filter(([name]) => name !== "answer review (planContributions)")) {
    for (const rule of PLAN_CONTRIBUTION_RULES) assert.equal(lines(prompt).includes(rule), false, name);
    assert.doesNotMatch(prompt, /Show Employer Amount|Show YTD|MED No|set askBryte to true/, name);
  }
});

test("each answer-review process gets only its own part", () => {
  const uti = answerReviewInstructions("unableToIdentify");
  for (const rule of UNABLE_TO_IDENTIFY_REVIEW_RULES) {
    assert.ok(lines(uti).includes(rule));
    for (const process of ["planContributions", "needMoreInformation", "misclassified", "optimizationOvertime"]) assert.equal(lines(answerReviewInstructions(process)).includes(rule), false, process);
  }
  // Only clarification reviews carry the bounded leave-purpose instruction, never plan or unrelated process rules.
  assert.match(answerReviewInstructions("needMoreInformation"), /For VAC, SICK, HOL or JURY leave-purpose questions/);
  assert.match(answerReviewInstructions("needMoreInformation"), /Do not assign an alternative Ready reference or infer accruals/);
  for (const process of ["planContributions", "unableToIdentify", "misclassified", "optimizationOvertime"]) {
    assert.doesNotMatch(answerReviewInstructions(process), /For VAC, SICK, HOL or JURY leave-purpose questions/);
  }
  // Something else on the Optimization and Overtime questions has no process rules either.
  assert.notEqual(answerReviewInstructions("optimizationOvertime"), answerReviewInstructions("misclassified"));
  assert.match(answerReviewInstructions("misclassified"), /STOP automatic employer-portion mapping/);
  for (const process of ["unableToIdentify", "needMoreInformation", "misclassified", "optimizationOvertime"]) {
    assert.match(answerReviewInstructions(process), /askBryte is always false/);
  }
  assert.doesNotMatch(answerReviewInstructions("planContributions"), /askBryte is always false/);
});

test("the description check and naming prompts are the general part plus their Unable to identify part", () => {
  assert.deepEqual(lines(EARNING_CHECK_INSTRUCTIONS).slice(1), [...GENERAL_PROMPT_RULES, ...EARNING_CHECK_PROCESS_RULES]);
  assert.deepEqual(lines(EARNING_NAME_INSTRUCTIONS).slice(1), [...GENERAL_PROMPT_RULES, ...EARNING_NAME_PROCESS_RULES]);
});

test("the shift premium step carries the full knowledge block, then the decision instruction, then its contract", () => {
  assert.deepEqual(lines(SHIFT_PREMIUM_INSTRUCTIONS).slice(1, 1 + GENERAL_PROMPT_RULES.length), [...GENERAL_PROMPT_RULES]);
  const knowledgeAt = SHIFT_PREMIUM_INSTRUCTIONS.indexOf(SHIFT_PREMIUM_KNOWLEDGE);
  const decisionAt = SHIFT_PREMIUM_INSTRUCTIONS.indexOf(SHIFT_PREMIUM_DECISION_INSTRUCTION);
  assert.ok(knowledgeAt > 0 && decisionAt > knowledgeAt);
  // Nothing but the heading sits between the knowledge block and the decision instruction.
  assert.equal(SHIFT_PREMIUM_INSTRUCTIONS.slice(knowledgeAt + SHIFT_PREMIUM_KNOWLEDGE.length, decisionAt), "\nDecision instruction:\n");
  for (const heading of ["UKG Ready — Shift Premium / Shift Differential", "Core Concept", "Consolidation Principle", "When Source Codes May Be Combined",
    "When Codes Should Remain Separate", "Example", "LLM Decision Rule", "Important Guardrails"]) assert.ok(lines(SHIFT_PREMIUM_KNOWLEDGE).includes(heading), heading);
  for (const step of [1, 2, 3, 4, 5, 6, 7, 8]) assert.match(SHIFT_PREMIUM_KNOWLEDGE, new RegExp(`^${step}\\. `, "m"));
  assert.match(SHIFT_PREMIUM_KNOWLEDGE, /SHIFT2 = shift differential for employees working in Department A\nSPPAY = shift differential for employees working in Department B/);
  assert.match(SHIFT_PREMIUM_KNOWLEDGE, /SHIFT2 = \$1\.00\/hour premium under one set of rules\nSPPAY = \$2\.00\/hour premium under different rules/);
  assert.match(SHIFT_PREMIUM_KNOWLEDGE, /ask a targeted follow-up question or select Defer\.$/);
  assert.match(SHIFT_PREMIUM_DECISION_INSTRUCTION, /^When a source payroll code is identified as extra pay for working a shift.*ask a targeted follow-up question or Defer\.$/);
  assert.match(SHIFT_PREMIUM_INSTRUCTIONS, /say combine, never consolidate or consolidation; say pay code or code, never source payroll code/);
});

test("shift premium knowledge reaches only the shift premium step", () => {
  for (const [name, prompt] of Object.entries(every).filter(([name]) => name !== "shift premium relationship")) {
    assert.equal(prompt.includes(SHIFT_PREMIUM_DECISION_INSTRUCTION), false, name);
    assert.doesNotMatch(prompt, /Shift Premium|Consolidation Principle|LLM Decision Rule|cost center/i, name);
  }
});
