import assert from 'node:assert/strict'
import test from 'node:test'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { build } from 'esbuild'
import express from 'express'

test('scoped earning response cache: successful results only, input isolation and bounded lifetime', async t => {
  const temp = await mkdtemp(path.join(tmpdir(), 'earning-cache-'))
  const directory = path.dirname(fileURLToPath(import.meta.url))
  let server
  try {
    const outfile = path.join(temp, 'cache.mjs')
    await build({ entryPoints: [path.join(directory, '../lib/earningResponseCache.ts')],
      outfile, platform: 'node', format: 'esm', bundle: true, logLevel: 'silent' })
    const { createEarningResponseCache, EARNING_CACHE_PATHS } = await import(outfile)
    let clock = 1000, calls = 0, mode = 'success'
    const app = express()
    app.use(express.json())
    app.use((req, _res, next) => { req.user = req.get('X-Test-User') ? { id: req.get('X-Test-User') } : undefined; next() })
    app.use(createEarningResponseCache({ ttlMs: 100, maxEntries: 3, now: () => clock }))
    const generate = async (req, res) => {
      calls++
      await new Promise(resolve => setTimeout(resolve, 10))
      if (mode === 'fail') { res.status(502).json({ code: 'invalid_response', error: 'Unusable result' }); return }
      if (!req.body.answer) { res.status(400).json({ code: 'invalid_request' }); return }
      res.json({ summary: `Validated result ${calls}`, answer: req.body.answer })
    }
    for (const endpoint of EARNING_CACHE_PATHS) app.post(endpoint, generate)
    app.post('/other', generate)
    server = app.listen(0, '127.0.0.1')
    await new Promise(resolve => server.once('listening', resolve))
    const post = (body = { answer: 'same' }, { scope = 'a'.repeat(64), user = 'first', endpoint = '/earnings/answer-reviews' } = {}) =>
      fetch(`http://127.0.0.1:${server.address().port}${endpoint}`, { method: 'POST',
        headers: { 'content-type': 'application/json', ...(scope ? { 'X-Earning-Cache-Scope': scope } : {}), ...(user ? { 'X-Test-User': user } : {}) },
        body: JSON.stringify(body) })

    await t.test('every generated-review endpoint reuses its validated result', async () => {
      for (const endpoint of EARNING_CACHE_PATHS) {
        const before = calls
        const first = await post({ answer: 'same' }, { endpoint })
        const result = await first.json()
        assert.equal(first.headers.get('x-earning-cache'), 'miss')
        const second = await post({ answer: 'same' }, { endpoint })
        assert.deepEqual(await second.json(), result)
        assert.equal(second.headers.get('x-earning-cache'), 'hit')
        assert.equal(second.headers.get('cache-control'), 'no-store')
        assert.equal(calls - before, 1)
      }
    })
    await t.test('canonicalizes object keys while preserving array order and all context', async () => {
      const before = calls
      await post({ answer: 'canonical', facts: { b: 2, a: 1 }, thread: ['first', 'second'] })
      assert.equal((await post({ thread: ['first', 'second'], facts: { a: 1, b: 2 }, answer: 'canonical' })).headers.get('x-earning-cache'), 'hit')
      await post({ answer: 'canonical', facts: { a: 1, b: 2 }, thread: ['second', 'first'] })
      await post({ answer: 'canonical', facts: { a: 1, b: 3 }, thread: ['first', 'second'] })
      assert.equal(calls - before, 3)
    })
    await t.test('partitions company/tab scope, user, endpoint and exact answer', async () => {
      const before = calls
      await post({ answer: 'isolation' })
      await post({ answer: 'isolation' }, { scope: 'b'.repeat(64) })
      await post({ answer: 'isolation' }, { user: 'second' })
      await post({ answer: 'changed' })
      await post({ answer: 'isolation' }, { endpoint: '/earnings/cell-reviews' })
      assert.equal(calls - before, 5)
    })
    await t.test('never caches failures, invalid inputs or unscoped calls', async () => {
      mode = 'fail'
      const before = calls
      assert.equal((await post({ answer: 'retry' })).status, 502)
      assert.equal((await post({ answer: 'retry' })).status, 502)
      mode = 'success'
      assert.equal((await post({ answer: 'retry' })).status, 200)
      assert.equal((await post({ answer: 'retry' })).headers.get('x-earning-cache'), 'hit')
      assert.equal(calls - before, 3)
      const invalidBefore = calls
      assert.equal((await post({})).status, 400)
      assert.equal((await post({})).status, 400)
      await post({ answer: 'unscoped' }, { scope: null }); await post({ answer: 'unscoped' }, { scope: null })
      await post({ answer: 'invalid-scope' }, { scope: 'company-name' }); await post({ answer: 'invalid-scope' }, { scope: 'company-name' })
      await post({ answer: 'other' }, { endpoint: '/other' }); await post({ answer: 'other' }, { endpoint: '/other' })
      assert.equal(calls - invalidBefore, 8)
    })
    await t.test('shares an in-flight success without issuing duplicate generation', async () => {
      const before = calls
      const responses = await Promise.all([post({ answer: 'concurrent' }), post({ answer: 'concurrent' })])
      const results = await Promise.all(responses.map(response => response.json()))
      assert.deepEqual(results[0], results[1])
      assert.equal(calls - before, 1)
      assert.equal(responses.filter(response => response.headers.get('x-earning-cache') === 'coalesced').length, 1)
    })
    await t.test('expires results and evicts oldest entries', async () => {
      await post({ answer: 'expires' })
      clock += 101
      assert.equal((await post({ answer: 'expires' })).headers.get('x-earning-cache'), 'miss')
      await post({ answer: 'evict-1' }); await post({ answer: 'evict-2' }); await post({ answer: 'evict-3' })
      assert.equal((await post({ answer: 'expires' })).headers.get('x-earning-cache'), 'miss')
    })
  } finally {
    if (server) await new Promise(resolve => server.close(resolve))
    await rm(temp, { recursive: true, force: true })
  }
})
