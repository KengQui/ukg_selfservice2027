import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";
import express from "express";
import { build } from "esbuild";

const directory = path.dirname(fileURLToPath(import.meta.url));
const input = {
  code: "MILEAGE", facts: { description: "Mileage", section: "earnings", peopleCount: 31, amount: 48200 },
  standardQuestion: "How does your company pay for miles driven?",
  cardQuestions: [{ question: "How does the company pay MILEAGE?", choices: ["A certain amount for each mile", "A fixed amount"] }],
  earlierAnswers: [{ question: "What does this pay for?", answer: "Business travel" }],
};
const draft = { questions: ["How much do you pay for each mile driven?"], answerKinds: ["text"], reason: "The per-mile amount is still needed to identify any taxable excess. Your answer determines whether to propose a separate taxable-mileage code." };

test("deferred customer drafting endpoint: contract, correction, privacy and failures", async t => {
  const temp = await mkdtemp(path.join(directory, ".customer-draft-test-"));
  let server;
  let mode = "success";
  const requests = [];
  // Replace only the provider transport, leaving route, prompt, schemas and validation real.
  globalThis.__customerDraftClient = { chat: { completions: { create: async (request, { signal }) => {
    requests.push(request);
    if (mode === "timeout") await new Promise((_resolve, reject) => signal.addEventListener("abort", () => reject(new Error("timeout")), { once: true }));
    if (mode === "unavailable") throw new Error("provider unavailable");
    const corrected = request.messages.length > 2;
    const supplied = JSON.parse(request.messages[1].content);
    const response = mode === "format" ? { ...draft, questions: supplied.formatQuestions, answerKinds: ["phone-tax"] }
      : mode === "cell" && corrected ? { ...draft, questions: [supplied.standardQuestion.split("?")[0] + "?"], answerKinds: ["text"] }
      : mode === "wrong-kind" ? { ...draft, answerKinds: ["phone-tax"] }
      : mode === "short-formats" && !corrected ? { ...draft, answerKinds: [] }
      : mode === "bad" ? { questions: [], reason: " " }
      : mode === "duplicate" && !corrected ? { ...draft, questions: [draft.questions[0], draft.questions[0]] }
      : mode === "banned" && !corrected ? { ...draft, reason: "Simply configure this." }
      : mode === "privacy" ? { ...draft, questions: ["Does owner@example.com know the amount?"] }
      : draft;
    return { choices: [{ message: { content: JSON.stringify(response) } }] };
  } } } };
  try {
    const outfile = path.join(temp, "router.mjs");
    await build({ entryPoints: [path.join(directory, "earningCustomerQuestions.ts")], outfile, platform: "node", format: "esm", bundle: true,
      banner: { js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" }, logLevel: "silent",
      plugins: [{ name: "provider-fixture", setup(build) {
        build.onLoad({ filter: /\/earningAI\.ts$/ }, () => ({ loader: "ts", contents:
          "export const createOpenAIClient = () => globalThis.__customerDraftClient; export const errorSummary = () => ({});" }));
      } }],
    });
    const { createEarningCustomerQuestionsRouter } = await import(outfile);
    const app = express(); app.use(express.json());
    app.use((req, _res, next) => { req.log = { error() {} }; next(); });
    app.use(createEarningCustomerQuestionsRouter({ timeoutMs: 30, maxRequestsPerMinute: 50 }));
    server = app.listen(0, "127.0.0.1");
    await new Promise(resolve => server.once("listening", resolve));
    const post = body => fetch(`http://127.0.0.1:${server.address().port}/earnings/customer-questions`,
      { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
    await t.test("uses shared general rules and only the customer-question process", async () => {
      const result = await post(input);
      assert.equal(result.status, 200); assert.deepEqual(await result.json(), draft);
      const prompt = requests.at(-1).messages[0].content;
      assert.match(prompt, /untrusted data/); assert.match(prompt, /one to three/);
      assert.match(prompt, /does not show tax treatment/); assert.match(prompt, /not restart a partially answered card/);
      assert.doesNotMatch(prompt, /medicalSetup|askBryte true|noMatchQuestions/);
      const supplied = JSON.parse(requests.at(-1).messages[1].content);
      assert.deepEqual(supplied, input);
    });
    for (const scenario of ["duplicate", "banned", "short-formats"]) await t.test(`one correction for ${scenario}`, async () => {
      mode = scenario; const before = requests.length;
      const result = await post(input);
      assert.equal(result.status, 200); assert.deepEqual(await result.json(), draft);
      assert.equal(requests.length - before, 2);
    });
    await t.test("adds approved formats without changing saved wording", async () => {
      mode = "format";
      const questions = ["What tax treatment has your adviser confirmed for the phone payback?"];
      const result = await post({ ...input, code: "CELL", allowedAnswerKinds: ["phone-tax"], formatQuestions: questions });
      assert.equal(result.status, 200);
      assert.deepEqual(await result.json(), { ...draft, questions, answerKinds: ["phone-tax"] });
      const prompt = requests.at(-1).messages[0].content;
      assert.match(prompt, /copy its questions exactly/i);
      assert.match(prompt, /NOT phone-tax/);
    });
    await t.test("rejects formats outside the allowed stage and rewritten saved questions", async () => {
      mode = "wrong-kind";
      assert.equal((await post(input)).status, 502);
      mode = "success";
      assert.equal((await post({ ...input, formatQuestions: ["Is this paid each month?"] })).status, 502);
    });
    await t.test("strict validation rejects extra, empty and oversized inputs before provider calls", async () => {
      const before = requests.length;
      for (const body of [{ ...input, extra: true }, { ...input, standardQuestion: "" }, { ...input, cardQuestions: [] },
        { ...input, facts: { ...input.facts, tax: true } }, { ...input, cardQuestions: [{ ...input.cardQuestions[0], extra: true }] },
        { ...input, earlierAnswers: [{ question: "Q", answer: "A", extra: true }] },
        { ...input, earlierAnswers: Array.from({ length: 61 }, () => input.earlierAnswers[0]) }]) {
        const result = await post(body);
        assert.equal(result.status, 400); assert.equal((await result.json()).code, "invalid_request");
      }
      assert.equal(requests.length, before);
    });
    await t.test("redacts input and output without logging their text", async () => {
      mode = "privacy";
      const result = await post({ ...input, facts: { ...input.facts, description: "owner@example.com" },
        earlierAnswers: [{ question: "Contact?", answer: "owner@example.com" }] });
      assert.equal(result.status, 200);
      assert.doesNotMatch(JSON.stringify(await result.json()), /owner@example.com/);
      assert.doesNotMatch(JSON.stringify(requests.at(-1)), /owner@example.com/);
    });
    for (const [scenario, status, code] of [["bad", 502, "invalid_response"], ["unavailable", 502, "unavailable"], ["timeout", 504, "timed_out"]]) {
      await t.test(scenario, async () => {
        mode = scenario;
        const result = await post(input);
        assert.equal(result.status, status);
        const body = await result.json(); assert.equal(body.code, code); assert.match(body.error, /standard question/);
      });
    }
    await t.test("CELL keeps the outstanding tax question instead of repeating a payment method or merging components", async () => {
      mode = "cell";
      const before = requests.length;
      const standardQuestion = "How should this cellphone payment be treated for payroll taxes in UKG Ready?\n\nFor the reimbursement component.";
      const result = await post({ ...input, code: "CELL", standardQuestion, allowedAnswerKinds: [] });
      assert.equal(result.status, 200);
      assert.deepEqual((await result.json()).questions, [standardQuestion.split("?")[0] + "?"]);
      assert.equal(requests.length, before + 2);
    });
    await t.test("rate limiting is explicit", async () => {
      mode = "success";
      for (let i = 0; i < 50; i++) await post({});
      const result = await post(input);
      assert.equal(result.status, 429); assert.equal((await result.json()).code, "rate_limited");
    });
  } finally {
    if (server) { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
    delete globalThis.__customerDraftClient;
    await rm(temp, { recursive: true, force: true });
  }
});
