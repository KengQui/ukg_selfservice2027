import { Router, type IRouter } from "express";

const router: IRouter = Router();

// Persona records from the uploaded cycle-setup employee seed. This imported
// project is a demo: review cycles and other edits remain in browser memory.
// Do not share the original app's database or claim these are real employees.
const demoEmployees = [
  { id: "admin", name: "Priya Rao", role: "HR Business Partner", department: "HR", avatarUrl: "https://i.pravatar.cc/150?u=perf-admin", managerId: null },
  { id: "manager", name: "Dana Whitfield", role: "Café & Roastery Manager", department: "Operations", avatarUrl: "https://i.pravatar.cc/150?u=perf-manager", managerId: null },
  { id: "employee", name: "Jamie Torres", role: "Frontend Engineer", department: "Engineering", avatarUrl: "https://i.pravatar.cc/150?u=perf-employee", managerId: null },
  { id: "peer1", name: "Sam Chen", role: "Backend Engineer", department: "Engineering", avatarUrl: "https://i.pravatar.cc/150?u=perf-peer1", managerId: null },
  { id: "peer2", name: "Alex Rivera", role: "Product Designer", department: "Design", avatarUrl: "https://i.pravatar.cc/150?u=perf-peer2", managerId: null },
];

router.get("/performance-reviews/employees", (_req, res) => {
  res.json(demoEmployees);
});

export default router;