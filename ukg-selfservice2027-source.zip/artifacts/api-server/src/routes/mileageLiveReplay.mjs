/**
 * Opt-in synthetic-only replay. Never accepts customer input or prints prompts, answers,
 * provider errors, or credentials. Run MILEAGE_LIVE=1 node src/routes/mileageLiveReplay.mjs.
 * Redirect stdout to a report; run before and after changes with the same fixtures.
 */
import { build } from "esbuild";
import { mkdtemp, rm, readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import express from "express";
import { execFileSync } from "node:child_process";

if (process.env.MILEAGE_LIVE !== "1") {
  console.log(JSON.stringify({ live: "not-run", reason: "Opt in with MILEAGE_LIVE=1" }));
  process.exit(0);
}
const here = path.dirname(fileURLToPath(import.meta.url));
const kb = JSON.parse(await readFile(path.resolve(here, "../../../../docs/earning-prompts/knowledge/mileage-v1.json"), "utf8"));
const fixtures = [
  ["short-reimbursement", "A", ["We repay documented business miles at $0.70 per mile monthly.", "We intend non-taxable reimbursement."]],
  ["flat-reimbursement", "A", ["We repay a flat $200 each month.", "We intend non-taxable reimbursement."]],
  ["allowance", "B", ["We pay $200 monthly as ordinary taxable extra pay, not expense repayment."]],
  ["compensation", "C", ["We pay $1 per mile as ordinary taxable wages."]],
  ["mixed", "D", ["We repay business vehicle expenses at $0.70 per mile as intended non-taxable reimbursement and separately pay extra compensation of $200 monthly as ordinary taxable wages."]],
  ["uncertain", "E", ["I'm not sure how people receive this payment."]],
  ["other", "F", ["We track mileage for information only, with no pay or tax effect."]],
  ["context-choice", "A", ["Business miles at a set rate", "Kept as a reimbursement"]],
  ["long-edited", "A", ["We repay personal-vehicle business travel monthly at $0.70 per documented business mile. We intend non-taxable reimbursement. Correction: our rate is $0.65 per mile, not $0.70."]],
];
const temp = await mkdtemp(path.join(here, ".mileage-live-"));
const stages = [];
globalThis.mileageReplayStage = value => stages.push(value);
let server;
try {
  await build({ entryPoints: [path.join(here, "earningMileageReviews.ts")], outfile: path.join(temp, "route.mjs"),
    bundle: true, platform: "node", format: "esm", loader: { ".txt": "text" }, logLevel: "silent",
    banner: { js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" },
    plugins: [{ name: "timing-only", setup(b) {
      // Optional immutable Git reference allows repeating a before/after comparison
      // after editing the working tree. Never replaces files in the workspace.
      if (process.env.MILEAGE_BASELINE_REF) b.onLoad({ filter: /(?:earningMileageReviews|earningMileageKnowledge|earningMileageEvidence)\.ts$/ }, args => ({
        loader: "ts", contents: execFileSync("git", ["show",
          `${process.env.MILEAGE_BASELINE_REF}:${path.relative(path.resolve(here, "../../../.."), args.path)}`], { encoding: "utf8" }),
      }));
      b.onLoad({ filter: /earningAI\.ts$/ }, async args => {
        const source = await readFile(args.path, "utf8");
        return { loader: "ts", contents: source.replace("export function createOpenAIClient", "function originalClient") + `
export function createOpenAIClient() {
  const client = originalClient();
  const create = client.chat.completions.create.bind(client.chat.completions);
  client.chat.completions.create = async (body, options) => {
    const start = Date.now(); let accepted = false;
    try { const result = await create(body, options); accepted = true; return result; }
    finally { globalThis.mileageReplayStage({stage: body.response_format.json_schema.name === "mileage_evidence" ? "audit" : body.messages.length > 2 ? "correction" : "proposal", ms: Date.now()-start, transportSucceeded: accepted}); }
  };
  return client;
}` };
      });
    } }],
  });
  const { createEarningMileageReviewsRouter } = await import(path.join(temp, "route.mjs"));
  const app = express(); app.use(express.json());
  app.use((req, _res, next) => { req.log = { warn(v) { if (v.reason) stages.push({ rejection: v.reason, missingTopics: v.missingTopics }); }, error() {}, info() {} }; next(); });
  app.use(createEarningMileageReviewsRouter({ maxRequestsPerMinute: 100 }));
  server = app.listen(0, "127.0.0.1"); await new Promise(r => server.once("listening", r));
  for (const [name, choice, replies] of fixtures.filter(f => !process.env.MILEAGE_FIXTURE || f[0] === process.env.MILEAGE_FIXTURE)) {
    const input = { policyVersion: "mileage-purpose-1", knowledgeVersion: "1.0", code: "MILEAGE", purposeChoice: choice,
      answers: [{ id: "mileage-purpose-1:purpose", question: kb.initial_question.question, answer: kb.initial_question.options[choice], component: "payment" }], historicalAnswers: [] };
    if (process.env.MILEAGE_LONG === "1") {
      // Long active history plus an explicit edit, not a trusted previous assessment.
      const facts = [
        ["Which trips?", "Personal-vehicle business travel."],
        ["Which calculation?", "Documented business miles multiplied by $0.70."],
        ["How often?", "Monthly."],
        ["Which purpose?", "Repayment of business vehicle expenses only."],
        ["What intended tax treatment?", "We intend non-taxable reimbursement."],
        ["Any correction to the rate?", "Correction: we now use $0.65 per mile, not $0.70."],
        ["Any other payments?", "There is no separate car allowance or extra pay."],
        ["How is mileage provided?", "People provide business trip details each month."],
      ];
      facts.forEach(([question, answer], n) => input.answers.push({
        id: `mileage-purpose-1:${n + 1}:reimbursement:example`, question, answer, component: "payment",
      }));
    }
    for (let turn = 0; turn <= replies.length; turn++) {
      stages.length = 0; const start = Date.now();
      const res = await fetch(`http://127.0.0.1:${server.address().port}/earnings/mileage-reviews`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(input), signal: AbortSignal.timeout(70_000),
      });
      const result = await res.json();
      console.log(JSON.stringify({ fixture: name, turn, ms: Date.now() - start, status: res.status,
        accepted: res.ok, outcome: result.mileage?.captured ? "captured" : result.next ?? result.code, stages: [...stages] }));
      if (!res.ok || result.next !== "clarify" || turn === replies.length) break;
      input.answers.push({ id: `mileage-purpose-1:${turn + 1}:${result.mileage.nextComponent}:${result.mileage.nextTopic}`,
        question: result.question, answer: replies[turn], component: "payment" });
    }
  }
} catch {
  console.log(JSON.stringify({ live: "unavailable", reason: "Replay could not complete; no acceptance claim." }));
  process.exitCode = 1;
} finally {
  server?.closeAllConnections(); if (server) await new Promise(r => server.close(r));
  await rm(temp, { recursive: true, force: true });
}
