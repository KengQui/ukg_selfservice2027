import { Router, type IRouter } from "express";
import type OpenAI from "openai";
import { ReviewEarningAnswerBody, type EarningCheckError } from "@workspace/api-zod";
import { createOpenAIClient, errorSummary } from "../lib/earningAI";
import { ANSWER_REVIEW_SCHEMA, answerReviewInstructions, buildAnswerReviewMessage, validateAnswerReview } from "../lib/earningAnswerReview";

const BODY = ReviewEarningAnswerBody.extend({
  facts: ReviewEarningAnswerBody.shape.facts.strict(),
  earlierAnswers: ReviewEarningAnswerBody.shape.earlierAnswers.element.strict().array().max(20),
  thread: ReviewEarningAnswerBody.shape.thread.element.strict().array(),
}).strict();
const ERRORS = {
  invalid_request: "We couldn’t review this answer. Check it, then try again.",
  rate_limited: "We’ve reviewed a lot of answers in the last minute. Wait a minute, then try again.",
  unavailable: "We can’t review your answer right now. Try again, or keep going.",
  timed_out: "Reviewing your answer took too long. Try again, or keep going.",
  invalid_response: "We couldn’t review your answer this time. Try again, or keep going.",
} as const satisfies Record<EarningCheckError["code"], string>;

export function createEarningAnswerReviewsRouter({ timeoutMs = 20_000, maxRequestsPerMinute = 60 } = {}): IRouter {
  const router = Router();
  const windows = new Map<string, { count: number; until: number }>();
  router.post("/earnings/answer-reviews", async (req, res): Promise<void> => {
    const fail = (status: number, code: EarningCheckError["code"]) => { res.status(status).json({ code, error: ERRORS[code] }); };
    const now = Date.now();
    for (const [key, window] of windows) if (window.until <= now) windows.delete(key);
    const key = req.ip || req.socket.remoteAddress || "unknown";
    const window = windows.get(key) ?? { count: 0, until: now + 60_000 };
    windows.set(key, window);
    if (++window.count > maxRequestsPerMinute) { fail(429, "rate_limited"); return; }
    const parsed = BODY.safeParse(req.body);
    if (!parsed.success) { fail(400, "invalid_request"); return; }
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const client = createOpenAIClient();
      const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
        { role: "system", content: answerReviewInstructions(parsed.data.process, parsed.data.code) },
        { role: "user", content: buildAnswerReviewMessage(parsed.data) },
      ];
      for (let attempt = 0; attempt < 2; attempt++) {
        const completion = await client.chat.completions.create({
          model: "gpt-5.4-mini", max_completion_tokens: 4096, reasoning_effort: "low",
          response_format: { type: "json_schema", json_schema: { name: "earning_answer_review", strict: true, schema: ANSWER_REVIEW_SCHEMA } },
          messages,
        }, { signal: controller.signal });
        const content = completion.choices[0]?.message?.content ?? "";
        let raw: unknown;
        try { raw = JSON.parse(content); } catch { raw = null; }
        const result = validateAnswerReview(raw, parsed.data);
        if (result.ok) { res.json(result.value); return; }
        messages.push({ role: "assistant", content: content || "{}" }, {
          role: "user", content: `Your result didn't meet the rules. ${result.correction} Return corrected JSON only.`,
        });
      }
      fail(502, "invalid_response");
    } catch (error) {
      // Never log answers, replies, model output or register text.
      req.log.error({ upstream: errorSummary(error) }, "Earning answer review unavailable");
      fail(controller.signal.aborted ? 504 : 502, controller.signal.aborted ? "timed_out" : "unavailable");
    } finally {
      clearTimeout(timeout);
    }
  });
  return router;
}
export default createEarningAnswerReviewsRouter();