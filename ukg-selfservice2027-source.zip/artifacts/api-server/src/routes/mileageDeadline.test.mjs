import test from "node:test";
import assert from "node:assert/strict";
import { mileageStage } from "../lib/mileageDeadline.ts";

test("hung transports settle on stage expiry even when they ignore abort", async () => {
  const parent = new AbortController();
  let signal;
  await assert.rejects(mileageStage(parent.signal, 10, s => { signal = s; return new Promise(() => {}); }));
  assert.equal(signal.aborted, true);
});
test("disconnect aborts in-flight work and does not start work already cancelled", async () => {
  const parent = new AbortController();
  let signal;
  const work = mileageStage(parent.signal, 500, s => { signal = s; return new Promise(() => {}); });
  parent.abort();
  await assert.rejects(work);
  assert.equal(signal.aborted, true);
  let called = false;
  await assert.rejects(mileageStage(parent.signal, 500, () => { called = true; return Promise.resolve(1); }));
  assert.equal(called, false);
});
test("late transport success cannot replace expiry", async () => {
  let finish;
  const result = mileageStage(new AbortController().signal, 5, () => new Promise(resolve => { finish = resolve; }));
  await assert.rejects(result);
  finish("too late");
  await assert.rejects(result);
});
