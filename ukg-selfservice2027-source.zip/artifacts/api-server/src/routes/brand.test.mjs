import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";
import express from "express";
import { build } from "esbuild";
import {
  DetectBrandLogoBody,
  DetectBrandLogoResponse,
} from "../../../../lib/api-zod/src/generated/api.ts";
import { normalizeLogoDetection } from "../lib/brandLogoDetection.ts";

const directory = path.dirname(fileURLToPath(import.meta.url));
const tinyPng = `data:image/png;base64,${"A".repeat(40)}`;

test("logo input accepts one to five bounded PNG or JPEG images", () => {
  assert.equal(
    DetectBrandLogoBody.safeParse({ images: [{ dataUrl: tinyPng }] }).success,
    true,
  );
  assert.equal(DetectBrandLogoBody.safeParse({ images: [] }).success, false);
  assert.equal(
    DetectBrandLogoBody.safeParse({
      images: Array.from({ length: 6 }, () => ({ dataUrl: tinyPng })),
    }).success,
    false,
  );
  assert.equal(
    DetectBrandLogoBody.safeParse({
      images: [{ dataUrl: "data:image/svg+xml;base64,AAAA" }],
    }).success,
    false,
  );
});

test("low-confidence recommendations are normalized to no match", () => {
  assert.deepEqual(
    normalizeLogoDetection(
      { selectedIndex: 0, confidence: 0.79, reason: "Unclear mark" },
      1,
    ),
    { selectedIndex: null, confidence: 0.79, reason: "Unclear mark" },
  );
});

test("confident valid recommendations and explicit no-match outputs validate", () => {
  const match = normalizeLogoDetection(
    { selectedIndex: 1, confidence: 0.92, reason: "Standalone wordmark" },
    2,
  );
  assert.equal(DetectBrandLogoResponse.safeParse(match).success, true);
  assert.equal(match.selectedIndex, 1);

  const noMatch = normalizeLogoDetection(
    { selectedIndex: null, confidence: 0.2, reason: "Only screenshots" },
    2,
  );
  assert.equal(DetectBrandLogoResponse.safeParse(noMatch).success, true);
  assert.equal(noMatch.selectedIndex, null);
});

test("each failure the logo step explains carries its code and an explanation", async (t) => {
  const temp = await mkdtemp(path.join(directory, ".brand-test-"));
  const servers = [];
  const previousEnv = {
    key: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
    url: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  };
  const listen = async (app) => {
    const server = app.listen(0);
    servers.push(server);
    await new Promise((resolve) => server.once("listening", resolve));
    return `http://127.0.0.1:${server.address().port}`;
  };

  try {
    // The analysis service rejects every request, so a valid one fails the way an outage does.
    const fakeOpenAI = express();
    fakeOpenAI.post("/chat/completions", (_req, res) => {
      res.status(400).json({ error: { message: "Bad request", type: "invalid_request_error" } });
    });
    process.env.AI_INTEGRATIONS_OPENAI_API_KEY = "test-key";
    process.env.AI_INTEGRATIONS_OPENAI_BASE_URL = await listen(fakeOpenAI);

    const outfile = path.join(temp, "brand.mjs");
    await build({
      entryPoints: [path.join(directory, "brand.ts")],
      outfile,
      platform: "node",
      format: "esm",
      bundle: true,
      banner: { js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" },
      logLevel: "silent",
    });
    const { default: router } = await import(outfile);
    const app = express();
    app.use(express.json({ limit: "8mb" }));
    app.use((req, _res, next) => {
      req.log = { info() {}, warn() {}, error() {} };
      next();
    });
    app.use("/api", router);
    const base = await listen(app);
    const post = async (body) => {
      const response = await fetch(`${base}/api/brand/logo-detection`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });
      return { status: response.status, body: await response.json() };
    };
    const assertExplained = (result, status, code) => {
      assert.equal(result.status, status);
      assert.deepEqual(Object.keys(result.body).sort(), ["code", "error"]);
      assert.equal(result.body.code, code);
      assert.match(result.body.error, /^Logo analysis .+\.$/);
    };

    await t.test("images that need fixing", async () => {
      assertExplained(await post({ images: [] }), 400, "invalid_images");
    });

    await t.test("analysis that isn't available", async () => {
      assertExplained(await post({ images: [{ dataUrl: tinyPng }] }), 502, "unavailable");
    });

    await t.test("too many requests in a minute", async () => {
      let result;
      for (let attempt = 0; attempt < 12 && result?.status !== 429; attempt++) {
        result = await post({ images: [] });
      }
      assertExplained(result, 429, "rate_limited");
    });
  } finally {
    for (const server of servers) {
      server.closeAllConnections?.();
      await new Promise((resolve) => server.close(resolve));
    }
    if (previousEnv.key === undefined) delete process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
    else process.env.AI_INTEGRATIONS_OPENAI_API_KEY = previousEnv.key;
    if (previousEnv.url === undefined) delete process.env.AI_INTEGRATIONS_OPENAI_BASE_URL;
    else process.env.AI_INTEGRATIONS_OPENAI_BASE_URL = previousEnv.url;
    await rm(temp, { recursive: true, force: true });
  }
});
