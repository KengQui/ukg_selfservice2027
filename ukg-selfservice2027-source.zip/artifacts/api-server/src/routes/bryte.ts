import { Router, type IRouter } from "express";
import OpenAI from "openai";
import { AskBryteBody, AskBryteResponse } from "@workspace/api-zod";
import { bannedWordsIn, buildPageMessage, buildSystemPrompt, redactSensitive, rewriteRequest, shapeAnswer } from "../lib/bryteAnswer";

export interface BryteRouterOptions {
  timeoutMs?: number;
  maxRequestsPerMinute?: number;
}

function createOpenAIClient(): OpenAI {
  const apiKey = process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
  const baseURL = process.env.AI_INTEGRATIONS_OPENAI_BASE_URL;
  if (!apiKey || !baseURL) {
    throw new Error("OpenAI integration is not configured");
  }
  return new OpenAI({ apiKey, baseURL, maxRetries: 1 });
}

function errorSummary(error: unknown): { status?: number; name?: string } {
  if (typeof error !== "object" || error === null) return {};
  const { status, name } = error as { status?: unknown; name?: unknown };
  return {
    status: typeof status === "number" ? status : undefined,
    name: typeof name === "string" ? name : undefined,
  };
}

/**
 * Bryte's page-aware answers. Question and page text are never logged, and
 * tax IDs, account numbers, emails and phone numbers in the question, the
 * earlier turns and the page description are removed before the model sees
 * them. A failure always returns an error status, never a stand-in answer.
 */
export function createBryteRouter({ timeoutMs = 30_000, maxRequestsPerMinute = 10 }: BryteRouterOptions = {}): IRouter {
  const router: IRouter = Router();
  const requestWindows = new Map<string, { count: number; resetAt: number }>();

  function hasRateLimitCapacity(key: string): boolean {
    const now = Date.now();
    if (requestWindows.size > 1_000) {
      for (const [windowKey, window] of requestWindows) {
        if (window.resetAt <= now) requestWindows.delete(windowKey);
      }
    }
    const current = requestWindows.get(key);
    if (!current || current.resetAt <= now) {
      requestWindows.set(key, { count: 1, resetAt: now + 60_000 });
      return true;
    }
    if (current.count >= maxRequestsPerMinute) return false;
    current.count += 1;
    return true;
  }

  router.post("/bryte/questions", async (req, res): Promise<void> => {
    const key = req.ip || req.socket.remoteAddress || "unknown";
    if (!hasRateLimitCapacity(key)) {
      res.status(429).json({ error: "Too many questions in the last minute. Please wait a moment and retry." });
      return;
    }

    const parsed = AskBryteBody.safeParse(req.body);
    if (!parsed.success) {
      // Paths and codes only: the request text itself is never logged.
      req.log.warn(
        { issues: parsed.error.issues.map((issue) => ({ path: issue.path.join("."), code: issue.code })) },
        "Invalid Bryte question request",
      );
      res.status(400).json({ error: "Send one question of up to 500 characters with a bounded page description." });
      return;
    }

    const { app, register, page, history = [], question } = parsed.data;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const client = createOpenAIClient();
      // The browser redacts too, but anything that reaches the model is redacted here as well.
      const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
        { role: "system", content: buildSystemPrompt(app, register) },
        { role: "system", content: buildPageMessage(page) },
        ...history.map((turn) => ({ role: turn.role, content: redactSensitive(turn.text) })),
        { role: "user", content: redactSensitive(question) },
      ];
      const ask = async (conversation: OpenAI.Chat.Completions.ChatCompletionMessageParam[]) => {
        const completion = await client.chat.completions.create(
          { model: "gpt-5.4-mini", max_completion_tokens: 8192, reasoning_effort: "low", messages: conversation },
          { signal: controller.signal },
        );
        return shapeAnswer(completion.choices[0]?.message?.content);
      };

      let answer = await ask(messages);
      if (!answer) throw new Error("Bryte returned no answer");
      // The voice guide's banned words slip through now and then; ask once for a rewrite without them.
      const banned = bannedWordsIn(answer);
      if (banned.length) {
        const rewritten = await ask([...messages, { role: "assistant", content: answer }, { role: "user", content: rewriteRequest(banned) }]);
        if (rewritten && bannedWordsIn(rewritten).length < banned.length) answer = rewritten;
      }
      res.json(AskBryteResponse.parse({ answer }));
    } catch (error) {
      if (controller.signal.aborted) {
        req.log.warn("Bryte question timed out");
        res.status(504).json({ error: "Bryte took too long to answer. Please retry." });
        return;
      }
      req.log.error({ upstream: errorSummary(error) }, "Bryte question failed");
      res.status(502).json({ error: "Bryte can't answer right now. Please retry." });
    } finally {
      clearTimeout(timeout);
    }
  });

  return router;
}

export default createBryteRouter();
