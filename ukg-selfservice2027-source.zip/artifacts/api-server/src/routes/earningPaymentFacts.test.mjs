import assert from 'node:assert/strict'
import test from 'node:test'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import express from 'express'
import { build } from 'esbuild'

test('payment facts: constrained extraction, source validation and explicit failures', async t => {
  const temp = await mkdtemp(path.join(tmpdir(), 'payment-facts-'))
  const servers = []
  try {
    await build({ entryPoints: ['src/lib/earningPaymentFacts.ts', 'src/routes/earningPaymentFacts.ts'],
      outdir: temp, outExtension: { '.js': '.mjs' }, platform: 'node', format: 'esm', bundle: true,
      banner: { js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" }, logLevel: 'silent' })
    const { createPaymentFactsRouter } = await import(pathToFileURL(path.join(temp, 'routes/earningPaymentFacts.mjs')))
    const lib = await import(pathToFileURL(path.join(temp, 'lib/earningPaymentFacts.mjs')))
    const input = { subject: 'tips', statements: [{ id: 'a', text: 'Customers freely choose tips. We pass them through payroll.' }] }
    const fact = { key: 'voluntaryPassThrough', state: 'yes', sourceId: 'a', evidence: 'Customers freely choose tips.' }
    let output = { facts: [fact] }, upstreamError = false, calls = [], coverage = {}
    const queued = [], warnings = []
    const makeServer = async (maxRequestsPerMinute = 100) => {
      const app = express()
      app.use(express.json())
      app.use((req, _res, next) => { req.log = { error() {}, warn(data) { warnings.push(data) } }; next() })
      app.use(createPaymentFactsRouter({ maxRequestsPerMinute, createClient: () => ({ chat: { completions: {
        create: async (...args) => {
          calls.push(args)
          if (upstreamError) throw new Error('private upstream diagnostic')
          const keys = args[0].response_format.json_schema.schema.properties.questionCoverage?.required
          return { choices: [{ message: { content: JSON.stringify({
            ...(queued.shift() ?? output), ...(keys ? { questionCoverage: Object.fromEntries(keys.map(key => [key, coverage[key] ?? null])) } : {}),
          }) } }] }
        },
      } } }) }))
      const server = app.listen(0)
      servers.push(server)
      await new Promise(resolve => server.once('listening', resolve))
      return async body => fetch(`http://127.0.0.1:${server.address().port}/earnings/payment-facts`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
      })
    }
    const post = await makeServer()
    await t.test('repairs an unusable extraction once without losing answers or returning invented facts', async () => {
      queued.push({ facts: [{ ...fact, sourceId: 'not-in-this-request' }] }, { facts: [fact] })
      const before = calls.length
      const response = await post(input)
      assert.equal(response.status, 200)
      assert.deepEqual(await response.json(), { facts: [fact] })
      assert.equal(calls.length, before + 2)
      assert.deepEqual(warnings.at(-1), { category: 'invalid_response', attempt: 1 })
      assert.ok(!JSON.stringify(warnings).includes(input.statements[0].text))
      assert.match(calls.at(-1)[0].messages.at(-1).content, /exact nonempty excerpts/)
      calls = []
    })
    await t.test('checks every question against earlier answers separately from treatment facts', async () => {
      const purpose = { subject: 'earnings', statements: [{ id: 'earlier', text: 'A payment for an unusual assignment.',
        question: 'What does this payment cover?' }] }
      output = { facts: [] }
      coverage = { businessPurpose: { sourceId: 'earlier', evidence: purpose.statements[0].text } }
      const response = await post(purpose)
      assert.equal(response.status, 200)
      assert.deepEqual(await response.json(), { facts: [], addressedQuestions: [{ key: 'businessPurpose', ...coverage.businessPurpose }] })
      const schema = lib.paymentFactSchema(purpose)
      assert.deepEqual(schema.properties.questionCoverage.required, schema.properties.facts.items.properties.key.enum)
      assert.match(lib.paymentFactInstructions(purpose), /not a yes\/no fact/)
      coverage.businessPurpose.sourceId = 'other-code'
      assert.equal((await post(purpose)).status, 502)
      coverage.businessPurpose.sourceId = 'earlier'
      coverage.businessPurpose.evidence = purpose.statements[0].question
      assert.equal((await post(purpose)).status, 502)
      coverage = {}; output = { facts: [fact] }; calls = []
    })
    await t.test('screens only the five conditions and partial facts with cited company evidence', async () => {
      const screening = { subject: 'screening', statements: [{ id: 'practice', text: 'We pay extra for night shifts.' }] }
      output = { facts: [{ key: 'shiftDiff', state: 'yes', sourceId: 'practice', evidence: screening.statements[0].text }] }
      const response = await post(screening)
      assert.equal(response.status, 200)
      assert.deepEqual(await response.json(), output)
      const prompt = lib.paymentFactInstructions(screening)
      for (const rule of ['SAME person', 'ONE WORKWEEK', 'company-wide denial', 'absence from a sample register',
        'eligible for overtime', 'bonusAdvancePromise', 'samePersonDifferentRates', 'No legal determinations']) assert.ok(prompt.includes(rule), rule)
      assert.ok(!lib.paymentFactSchema(screening).properties.facts.items.properties.key.enum.includes('workedWages'))
      output = { facts: [{ key: 'workedWages', state: 'yes', sourceId: 'practice', evidence: screening.statements[0].text }] }
      assert.equal((await post(screening)).status, 502)
      output = { facts: [fact] }
      calls = []
    })
    await t.test('accepts supplied-reference earnings facts with citations and keeps settings out of extraction', async () => {
      const earnings = { subject: 'earnings', statements: [{ id: 'work', text: 'We pay only for hours actually worked.' }] }
      output = { facts: [{ key: 'workedWages', state: 'yes', sourceId: 'work', evidence: earnings.statements[0].text }] }
      const response = await post(earnings)
      assert.equal(response.status, 200)
      assert.deepEqual(await response.json(), output)
      const prompt = lib.paymentFactInstructions(earnings)
      assert.match(prompt, /NOT independently verified UKG documentation/)
      assert.match(prompt, /Never invent hours/)
      assert.match(prompt, /combinedOvertime/)
      calls = []
      output = { facts: [fact] }
    })
    await t.test('accepts only cited facts; never makes a legal placement or caches one company for another', async () => {
      const response = await post(input)
      assert.equal(response.status, 200)
      assert.deepEqual(await response.json(), output)
      assert.equal(calls[0][0].response_format.json_schema.strict, true)
      assert.deepEqual(calls[0][0].response_format.json_schema.schema.properties.facts.items.properties.key.enum,
        ['voluntaryPassThrough', 'serviceChargeWages'])
      assert.deepEqual(calls[0][0].response_format.json_schema.schema.properties.facts.items.properties.sourceId.enum, ['a'])
      assert.ok(calls[0][1].signal)
      assert.ok(!('placement' in output))
      assert.match(calls[0][0].messages[0].content, /untrusted data/)
      assert.match(calls[0][0].messages[0].content, /Never choose Include or Exclude/)
      assert.match(calls[0][0].messages[0].content, /A question alone is never evidence/)
      await post(input)
      assert.equal(calls.length, 2, 'no cross-request reuse without company scope')
    })
    await t.test('rejects unsupported facts, fabricated citations and unexpected response shape', async () => {
      for (const invalid of [
        { facts: [{ ...fact, key: 'medicalPlan' }] },
        { facts: [{ ...fact, sourceId: 'other-company' }] },
        { facts: [{ ...fact, evidence: 'This code pays mandatory service charges' }] },
        { facts: [fact, fact] }, { facts: [fact], placement: 'exclude' }, { facts: [null] },
      ]) {
        output = invalid
        const response = await post(input)
        assert.equal(response.status, 502)
        assert.equal((await response.json()).code, 'invalid_response')
      }
    })
    await t.test('accepts contextual Yes replies without quoting the question or borrowing a sibling', async () => {
      output = { facts: [{ key: 'bilingualDuties', state: 'yes', evidence: 'Yes', sourceId: 'short' }] }
      const contextual = { subject: 'special', statements: [{ id: 'short', text: 'Yes',
        question: 'Is this extra pay for bilingual duties at work?' }] }
      assert.equal((await post(contextual)).status, 200)
      output.facts[0].evidence = contextual.statements[0].question
      assert.equal((await post(contextual)).status, 502)
    })
    await t.test('never treats cash receipt or a No to optional-only as proof of a tip fact', () => {
      const instructions = lib.paymentFactInstructions({ subject: 'tips', statements: [
        { id: 'cash', text: 'Our team already received cash directly from customers.' },
      ] })
      assert.match(instructions, /Cash receipt, a card source.*does not establish voluntariness/)
      assert.match(instructions, /A No to optional-tips-only does not establish service-charge-only/)
      assert.match(instructions, /preserve the all-amounts meaning of each fact independently/)
    })
    await t.test('keeps all benefit conditions, noncash/cash and ambiguity in the owning process', () => {
      const instructions = lib.paymentFactInstructions({ subject: 'life', statements: [] })
      for (const term of ['cashWages', 'lifePlan', 'communicatedPlan', 'definedBenefits',
        'irrevocableFunding', 'noCashOption', 'noAssignment']) assert.ok(instructions.includes(term))
      assert.match(instructions, /taxable value of noncash insurance is NOT cashWages/)
      assert.match(instructions, /Limited incidental payouts/)
      assert.match(instructions, /usual fiduciary duties/)
      assert.match(instructions, /A statement containing only Bilingual proves nothing/)
    })
    await t.test('rejects malformed input and exposes no provider errors or manufactured facts on failure', async () => {
      for (const body of [
        { ...input, subject: 'label' }, { ...input, statements: [...input.statements, ...input.statements] },
        { ...input, statements: [{ id: 'x', text: 'x'.repeat(2001) }] }, { ...input, invented: true },
      ]) assert.equal((await post(body)).status, 400)
      upstreamError = true
      const response = await post(input)
      assert.equal(response.status, 502)
      const failure = await response.json()
      assert.equal(failure.code, 'unavailable')
      assert.ok(!JSON.stringify(failure).includes('private'))
      assert.ok(!('facts' in failure))
      upstreamError = false
      const limited = await makeServer(1)
      output = { facts: [] }
      assert.equal((await limited(input)).status, 200)
      assert.equal((await limited(input)).status, 429)
    })
  } finally {
    await Promise.all(servers.map(server => new Promise(resolve => server.close(resolve))))
    await rm(temp, { recursive: true, force: true })
  }
})
