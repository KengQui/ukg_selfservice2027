import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { pathToFileURL } from "node:url";
import test from "node:test";
import express from "express";
import { build } from "esbuild";

test("added code checks: match, follow-up, no match and explicit failures", async () => {
  const temp = await mkdtemp(path.join(tmpdir(), "added-code-test-"));
  const servers = [];
  try {
    await build({ entryPoints: ["src/lib/earningAddedCodeCheck.ts", "src/routes/earningAddedCodeChecks.ts"],
      outdir: temp, outExtension: { ".js": ".mjs" }, platform: "node", format: "esm", bundle: true,
      banner: { js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" }, logLevel: "silent" });
    const lib = await import(pathToFileURL(path.join(temp, "lib/earningAddedCodeCheck.mjs")));
    const { createEarningAddedCodeChecksRouter } = await import(pathToFileURL(path.join(temp, "routes/earningAddedCodeChecks.mjs")));
    assert.match(lib.ADDED_CODE_INSTRUCTIONS, /untrusted data/, "shares the general prompt");
    assert.match(lib.ADDED_CODE_INSTRUCTIONS, /demo, not a verified catalog/);
    assert.ok(lib.ADDED_CODE_DEMO_LIBRARY.some(ref => ref.id === "demo-employee-referral-bonus"));

    const serve = async (replies, options = {}) => {
      const calls = [];
      const client = { chat: { completions: { create: async (body) => {
        calls.push(body);
        const next = replies.shift();
        if (next instanceof Error) throw next;
        return { choices: [{ message: { content: JSON.stringify(next) } }] };
      } } } };
      const app = express(); app.use(express.json());
      app.use((req, _res, next) => { req.log = { error() {}, warn() {} }; next(); });
      app.use(createEarningAddedCodeChecksRouter({ createClient: () => client, maxRequestsPerMinute: 100, ...options }));
      const server = app.listen(0, "127.0.0.1"); servers.push(server);
      await new Promise(resolve => server.once("listening", resolve));
      const post = async body => {
        const response = await fetch(`http://127.0.0.1:${server.address().port}/earnings/added-code-checks`, {
          method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
        return { status: response.status, body: await response.json() };
      };
      return { post, calls };
    };
    const referral = { description: "We pay $500 to an employee when someone they referred is hired.", thread: [] };

    const question = { outcome: "question", referenceId: null, summary: "A $500 referral payment.", facts: ["$500 per hire"], question: "Is this a cash bonus or another form of compensation?", reason: "The form of payment is unclear." };
    for (const wording of ["Is the $500 paid once, or split into installments?", "Does this payment recur?", "Is there a 90 day waiting period?", "How is it scheduled?"]) {
      assert.equal(lib.validateAddedCodeCheck({ ...question, question: wording }, referral).issue, "referral_scope");
    }
    let s = await serve([question]);
    let r = await s.post(referral);
    assert.equal(r.status, 200); assert.equal(r.body.outcome, "question"); assert.equal(r.body.reference, null);

    const match = { outcome: "match", referenceId: "demo-employee-referral-bonus", summary: "A one-time $500 payment.", facts: ["$500", "Paid once after 90 days"], question: null, reason: "All criteria are known." };
    s = await serve([match]);
    r = await s.post({ ...referral, thread: [{ question: question.question, answer: "Once, after 90 days." }] });
    assert.deepEqual(r.body.reference, { id: "demo-employee-referral-bonus", name: "Employee referral bonus", library: "demo" });
    assert.ok(JSON.parse(s.calls[0].messages[1].content).thread.length === 1, "reply is sent with the thread");

    s = await serve([{ ...match, outcome: "noMatch" }, { ...match, outcome: "noMatch", referenceId: null }]);
    r = await s.post({ description: "Stipend for being on the safety committee.", thread: [] });
    assert.equal(r.body.outcome, "noMatch"); assert.equal(r.body.reference, null); assert.equal(s.calls.length, 2, "an invented match is corrected");

    s = await serve([{ ...match, referenceId: "made-up" }, { ...match, referenceId: "made-up" }]);
    r = await s.post(referral);
    assert.equal(r.status, 502); assert.equal(r.body.code, "invalid_response");

    s = await serve([Object.assign(new Error("down"), { status: 500 })]);
    r = await s.post(referral);
    assert.equal(r.status, 502); assert.equal(r.body.code, "unavailable"); assert.equal(r.body.outcome, undefined);

    r = await s.post({ ...referral, code: "BONUS" });
    assert.equal(r.status, 400);
    r = await s.post({ description: "x", thread: Array(5).fill({ question: "q", answer: "a" }) });
    assert.equal(r.status, 400);
  } finally {
    for (const server of servers) server.close();
    await rm(temp, { recursive: true, force: true });
  }
});
