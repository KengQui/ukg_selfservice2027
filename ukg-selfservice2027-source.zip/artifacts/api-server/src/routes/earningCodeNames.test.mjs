import assert from "node:assert/strict";
import test from "node:test";
import {
  CheckEarningDescriptionBody, SuggestEarningNameBody, ReviewEarningAnswerBody,
  ReviewShiftPremiumBody, DraftEarningCustomerQuestionsBody,
} from "../../../../lib/api-zod/src/generated/api.ts";

test("all earning AI request paths accept displayed code names with unchanged bounds", () => {
  const schemas = [
    [CheckEarningDescriptionBody.shape.code, 16],
    [SuggestEarningNameBody.shape.code, 16],
    [ReviewEarningAnswerBody.shape.code, 16],
    [ReviewShiftPremiumBody.shape.code, 16],
    [ReviewShiftPremiumBody.shape.existingCodes.element.shape.code, 16],
    [DraftEarningCustomerQuestionsBody.shape.code, 20],
  ];
  for (const [schema, maxLength] of schemas) {
    for (const code of ["Special Pay", "Overtime ENG", "Overtime MFG", "SPPAY"]) {
      assert.equal(schema.parse(code), code);
    }
    for (const code of ["", "a".repeat(maxLength + 1), "<Special Pay>", "Pay;drop"]) {
      assert.equal(schema.safeParse(code).success, false, code);
    }
  }
});
