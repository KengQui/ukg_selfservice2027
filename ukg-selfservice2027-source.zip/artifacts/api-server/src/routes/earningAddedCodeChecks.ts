import { Router, type IRouter } from "express";
import type OpenAI from "openai";
import { CheckAddedEarningCodeBody, CheckAddedEarningCodeResponse } from "@workspace/api-zod";
import { createOpenAIClient, errorSummary } from "../lib/earningAI";
import { ADDED_CODE_INSTRUCTIONS, ADDED_CODE_SCHEMA, addedCodeMessage, validateAddedCodeCheck } from "../lib/earningAddedCodeCheck";

const BODY = CheckAddedEarningCodeBody.extend({
  thread: CheckAddedEarningCodeBody.shape.thread.element.strict().array().max(4),
}).strict();
const ERRORS = {
  invalid_request: "We couldn’t check this description. Check it, then try again.",
  rate_limited: "We’ve checked a lot of codes in the last minute. Wait a minute, then try again.",
  unavailable: "We can’t check this code right now. Try again.",
  timed_out: "Checking this code took too long. Try again.",
  invalid_response: "We couldn’t check this code this time. Try again.",
} as const;

/** Request text is never logged. A failed check never becomes a fallback match or no-match. */
export function createEarningAddedCodeChecksRouter({ timeoutMs = 30_000, maxRequestsPerMinute = 20, createClient = createOpenAIClient } = {}): IRouter {
  const router = Router();
  const windows = new Map<string, { count: number; until: number }>();
  router.post("/earnings/added-code-checks", async (req, res): Promise<void> => {
    const fail = (status: number, code: keyof typeof ERRORS) => { res.status(status).json({ code, error: ERRORS[code] }); };
    const now = Date.now();
    for (const [key, value] of windows) if (value.until <= now) windows.delete(key);
    const key = req.ip || req.socket.remoteAddress || "unknown";
    const window = windows.get(key) ?? { count: 0, until: now + 60_000 };
    windows.set(key, window);
    if (++window.count > maxRequestsPerMinute) { fail(429, "rate_limited"); return; }
    const input = BODY.safeParse(req.body);
    if (!input.success || !input.data.description.trim()) { fail(400, "invalid_request"); return; }
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const client = createClient();
      const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
        { role: "system", content: ADDED_CODE_INSTRUCTIONS }, { role: "user", content: addedCodeMessage(input.data) },
      ];
      for (let attempt = 0; attempt < 2; attempt++) {
        const completion = await client.chat.completions.create({
          model: "gpt-5.4-mini", max_completion_tokens: 4096, reasoning_effort: "low",
          response_format: { type: "json_schema", json_schema: { name: "added_code_check", strict: true, schema: ADDED_CODE_SCHEMA } }, messages,
        }, { signal: controller.signal });
        const content = completion.choices[0]?.message?.content ?? "";
        let raw: unknown;
        try { raw = JSON.parse(content); } catch { raw = null; }
        const checked = validateAddedCodeCheck(raw, input.data);
        if (checked.ok) { res.json(CheckAddedEarningCodeResponse.parse(checked.value)); return; }
        req.log.warn({ issue: checked.issue, attempt: attempt + 1 }, "Added code check needed a correction");
        messages.push({ role: "assistant", content: content || "{}" }, { role: "user", content: checked.correction });
      }
      fail(502, "invalid_response");
    } catch (error) {
      if (controller.signal.aborted) { fail(504, "timed_out"); return; }
      req.log.error({ upstream: errorSummary(error) }, "Added code check unavailable");
      fail(502, "unavailable");
    } finally {
      clearTimeout(timeout);
    }
  });
  return router;
}

export default createEarningAddedCodeChecksRouter();
