import assert from 'node:assert/strict';
import test from 'node:test';
import { mkdtemp, rm } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';
import ExcelJS from 'exceljs';

const directory = path.dirname(fileURLToPath(import.meta.url));
const header = 'Company,Company ID,Period start,Period end,Code,Description,Section,Amount,People,Currency';
const csv = `${header}\nFictional Harbor Co,DEMO-HARBOR,2026-01-01,2026-01-15,REG,Regular pay,Earnings,1200,4,USD`;

test('register readers preserve real tabular evidence and reject unusable documents', async t => {
  const temp = await mkdtemp(path.join(directory, '.register-test-'));
  try {
    const outfile = path.join(temp, 'reader.mjs');
    await build({ entryPoints: [path.join(directory, '../lib/registerExtraction.ts')], outfile, bundle: true, platform: 'node', format: 'esm',
      external: ['exceljs', 'pdfjs-dist/*', '@napi-rs/canvas'], logLevel: 'silent',
      banner: { js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" },
    });
    const { extractRegister } = await import(outfile);
    const noAI = () => { throw new Error('Unexpected AI call for a structured file'); };
    await t.test('CSV includes source company, period, amount, people and exact code', async () => {
      const evidence = await extractRegister(Buffer.from(csv), 'fictional.csv', noAI);
      const report = evidence.reports[0];
      assert.equal(report.companyId, 'DEMO-HARBOR');
      assert.equal(report.periodStart, '2026-01-01');
      assert.equal(report.rows[0].amount, 1200);
      assert.equal(report.rows[0].people, 4);
      assert.equal(report.rows[0].locator, 'CSV, row 2');
      assert.match(report.rows[0].quote, /REG/);
    });
    await t.test('employee detail stays tied to its amount, period and source row', async () => {
      const evidence = await extractRegister(Buffer.from(`${header},Employee name,Employee ID\nFictional Harbor Co,DEMO-HARBOR,2026-01-01,2026-01-15,BON,Bonus,Earnings,250,,USD,Demo Person,EMP-001`), 'employee.csv', noAI);
      const report = evidence.reports[0];
      const row = report.rows[0];
      assert.equal(row.employeeName, 'Demo Person');
      assert.equal(row.employeeId, 'EMP-001');
      assert.equal(row.amount, 250);
      assert.equal(report.periodStart, '2026-01-01');
      assert.match(row.locator, /row 2/);
      assert.ok(!row.quote.includes('Demo Person'));
    });
    await t.test('XLSX handles every company/sheet separately, including zero amounts', async () => {
      const workbook = new ExcelJS.Workbook();
      workbook.addWorksheet('Harbor').addRows([header.split(','), csv.split('\n')[1].split(',')]);
      workbook.addWorksheet('Mountain').addRows([header.split(','), ['Fictional Mountain Co', 'OTHER', '2026-01-01', '2026-01-15', 'REG', 'Regular pay', 'Earnings', 0, 0, 'USD']]);
      const evidence = await extractRegister(Buffer.from(await workbook.xlsx.writeBuffer()), 'fictional.xlsx', noAI);
      assert.equal(evidence.reports.length, 2);
      assert.equal(evidence.reports[1].rows[0].amount, 0);
      assert.equal(evidence.reports[1].rows[0].people, 0);
      assert.match(evidence.reports[1].rows[0].locator, /Mountain/);
    });
    await t.test('payment and expense columns both survive; missing people stay unknown', async () => {
      const evidence = await extractRegister(Buffer.from('Company,Company ID,Code,Description,Payment amount,Expense amount\nFictional,DEMO,BON,Bonus,100,25'), 'both.csv', noAI);
      assert.deepEqual(evidence.reports[0].rows.map(row => row.amount), [100, 25]);
      assert.deepEqual(evidence.reports[0].rows.map(row => row.amountLabel), ['Payment amount', 'Expense amount']);
      assert.equal(evidence.reports[0].rows[0].people, null);
    });
    await t.test('common current amount headings preserve values in CSV and XLSX', async () => {
      for (const heading of ['Current Amount', 'Current Period Amount', 'Current Pay', 'Current Earnings', 'Pay Amount']) {
        const input = csv.replace(',Amount,', `,${heading},`);
        const csvEvidence = await extractRegister(Buffer.from(input), 'current.csv', noAI);
        assert.equal(csvEvidence.reports[0].rows[0].amount, 1200);
        assert.equal(csvEvidence.reports[0].rows[0].amountLabel, heading);
        const workbook = new ExcelJS.Workbook();
        workbook.addWorksheet('Current payroll').addRows(input.split('\n').map(line => line.split(',')));
        const xlsxEvidence = await extractRegister(Buffer.from(await workbook.xlsx.writeBuffer()), 'current.xlsx', noAI);
        assert.equal(xlsxEvidence.reports[0].rows[0].amount, 1200);
        assert.equal(xlsxEvidence.reports[0].rows[0].amountLabel, heading);
      }
    });
    await t.test('unrecognized populated columns fall back with all source text, never partial ready evidence', async () => {
      for (const heading of ['Current Payment Total', 'Amount Paid', 'YTD Amount', 'Units Paid']) {
        const input = `${csv.replace(',Amount,', ',Current Amount,').split('\n')[0]},${heading}\n${csv.split('\n')[1]},7200`;
        let calls = 0;
        await assert.rejects(extractRegister(Buffer.from(input), 'ambiguous.csv', async document => {
          calls++;
          assert.match(document.text, /Current Amount/);
          assert.ok(document.text.includes(heading));
          assert.match(document.text, /1200/);
          assert.match(document.text, /7200/);
          throw new Error('Grounded reader unavailable: explicit file failure');
        }), /Grounded reader unavailable/);
        assert.equal(calls, 1);
      }
      // A Code heading alone is not enough to call an unknown populated value "not shown".
      await assert.rejects(extractRegister(Buffer.from('Code,Description,Money paid\nREG,Regular pay,1200'), 'unknown.csv',
        async document => { assert.match(document.text, /1200/); throw new Error('Requires document interpretation'); }),
      /Requires document interpretation/);
    });
    await t.test('never silently returns sample or truncated evidence for failed input', async () => {
      await assert.rejects(extractRegister(Buffer.from('broken pdf'), 'broken.pdf', noAI));
      await assert.rejects(extractRegister(Buffer.from(csv.replace('1200', 'unknown dollars')), 'bad.csv', noAI));
      await assert.rejects(extractRegister(Buffer.alloc(10 * 1024 * 1024 + 1), 'big.csv', noAI));
      await assert.rejects(extractRegister(Buffer.from(header), 'empty.csv', noAI));
    });
  } finally { await rm(temp, { recursive: true, force: true }); }
});
