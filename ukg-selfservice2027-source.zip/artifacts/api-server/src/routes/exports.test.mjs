import assert from "node:assert/strict";
import test from "node:test";
import { getTableConfig } from "drizzle-orm/pg-core";
import { exportJobs } from "../../../../lib/db/src/schema/index.ts";
import { cleanupExpiredExports, exportObjectKey } from "../lib/exportStorage.ts";

test("export artifacts have a per-job private key and reject untrusted identifiers", () => {
  const first = "00000000-0000-4000-8000-000000000001";
  const second = "00000000-0000-4000-8000-000000000002";
  assert.equal(exportObjectKey(first), `exports/${first}.zip`);
  assert.notEqual(exportObjectKey(first), exportObjectKey(second));
  for (const id of ["../../other", "not-a-uuid", `${first}/other`]) {
    assert.throws(() => exportObjectKey(id), /Invalid export job ID/);
  }
});

test("the database enforces a single running job across instances", () => {
  const { indexes, columns } = getTableConfig(exportJobs);
  const running = indexes.find(index => index.config.name === "export_jobs_one_running");
  assert.equal(running?.config.unique, true);
  assert.ok(running?.config.where);
  assert.deepEqual(running?.config.columns.map(column => column.name), ["status"]);
  assert.ok(columns.some(column => column.name === "expires_at"));
  assert.ok(columns.some(column => column.name === "object_key"));
});

test("expiration removes bytes for ready, failed and interrupted jobs before metadata", async () => {
  const events = [];
  const jobs = ["ready", "failed", "running"].map((status, index) => ({
    status, id: `job-${index}`,
  }));
  await cleanupExpiredExports(
    jobs,
    async id => { events.push(`metadata:${id}`); },
    () => assert.fail("unexpected storage error"),
    async id => { events.push(`bytes:${id}`); },
  );
  assert.deepEqual(events, jobs.flatMap(({ id }) => [`bytes:${id}`, `metadata:${id}`]));
});

test("storage failure retains expired metadata for retry without blocking other jobs", async () => {
  const removed = [];
  const failed = [];
  await cleanupExpiredExports(
    [{ id: "orphan", status: "failed" }, { id: "ready", status: "ready" }],
    async id => { removed.push(id); },
    (id, error) => { failed.push([id, error.message]); },
    async id => { if (id === "orphan") throw new Error("storage unavailable"); },
  );
  assert.deepEqual(failed, [["orphan", "storage unavailable"]]);
  assert.deepEqual(removed, ["ready"]);
});