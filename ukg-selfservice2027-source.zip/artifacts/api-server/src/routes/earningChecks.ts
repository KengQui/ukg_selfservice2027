import { Router, type IRouter } from "express";
import type OpenAI from "openai";
import { CheckEarningDescriptionBody, CheckEarningDescriptionResponse, type EarningCheckError } from "@workspace/api-zod";
import { createOpenAIClient, errorSummary } from "../lib/earningAI";
import { EARNING_CHECK_INSTRUCTIONS, EARNING_CHECK_SCHEMA, buildCheckMessage, correctionRequest, validateCheck } from "../lib/earningCheck";

export interface EarningChecksRouterOptions {
  timeoutMs?: number;
  maxRequestsPerMinute?: number;
}

class InvalidCheckResult extends Error {}

const ERRORS = {
  invalid_request: "We couldn’t check this answer. Check the description, then try again.",
  rate_limited: "We’ve checked a lot of answers in the last minute. Wait a minute, then try again.",
  unavailable: "We can’t check your answer right now. Try again, or select Review later.",
  timed_out: "Checking your answer took too long. Try again, or select Review later.",
  invalid_response: "We couldn’t check your answer this time. Try again, or select Review later.",
} as const satisfies Record<EarningCheckError["code"], string>;
const fail = (code: EarningCheckError["code"]): EarningCheckError => ({ code, error: ERRORS[code] });

// Orval's object schemas strip extra keys by default. Enforce the contract's
// additionalProperties:false here without changing other generated endpoints.
const CHECK_BODY = CheckEarningDescriptionBody.extend({
  source: CheckEarningDescriptionBody.shape.source.strict(),
  answers: CheckEarningDescriptionBody.shape.answers.element.strict().array().max(6),
  followUps: CheckEarningDescriptionBody.shape.followUps.element.strict().array().max(6),
  references: CheckEarningDescriptionBody.shape.references.element.extend({
    inUseBy: CheckEarningDescriptionBody.shape.references.element.shape.inUseBy.unwrap().element.strict().array().max(10).optional(),
  }).strict().array().min(1).max(80),
}).strict();

/** Request text is never logged. An unavailable or unusable check never becomes a fallback decision. */
export function createEarningChecksRouter({ timeoutMs = 30_000, maxRequestsPerMinute = 20 }: EarningChecksRouterOptions = {}): IRouter {
  const router: IRouter = Router();
  const requestWindows = new Map<string, { count: number; resetAt: number }>();
  function hasRateLimitCapacity(key: string): boolean {
    const now = Date.now();
    if (requestWindows.size > 1_000) {
      for (const [windowKey, window] of requestWindows) {
        if (window.resetAt <= now) requestWindows.delete(windowKey);
      }
    }
    const current = requestWindows.get(key);
    if (!current || current.resetAt <= now) {
      requestWindows.set(key, { count: 1, resetAt: now + 60_000 });
      return true;
    }
    if (current.count >= maxRequestsPerMinute) return false;
    current.count += 1;
    return true;
  }

  router.post("/earnings/description-checks", async (req, res): Promise<void> => {
    if (!hasRateLimitCapacity(req.ip || req.socket.remoteAddress || "unknown")) {
      res.status(429).json(fail("rate_limited"));
      return;
    }
    const parsed = CHECK_BODY.safeParse(req.body);
    if (!parsed.success) {
      req.log.warn(
        { issues: parsed.error.issues.map((issue) => ({ path: issue.path.join("."), code: issue.code })) },
        "Invalid earning description check request",
      );
      res.status(400).json(fail("invalid_request"));
      return;
    }
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const client = createOpenAIClient();
      const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
        { role: "system", content: EARNING_CHECK_INSTRUCTIONS },
        { role: "user", content: buildCheckMessage(parsed.data) },
      ];
      const ask = async (conversation: OpenAI.Chat.Completions.ChatCompletionMessageParam[]) => {
        const completion = await client.chat.completions.create(
          {
            model: "gpt-5.4-mini",
            max_completion_tokens: 4096,
            reasoning_effort: "low",
            response_format: {
              type: "json_schema",
              json_schema: { name: "earning_description_check", strict: true, schema: EARNING_CHECK_SCHEMA },
            },
            messages: conversation,
          },
          // Allow one more transport retry than the shared client default. Keep
          // the same facts/model and the shared deadline for any output correction.
          // The SDK supplies backoff and does not retry permanent request errors.
          { signal: controller.signal, maxRetries: 2 },
        );
        const content = completion.choices[0]?.message?.content ?? "";
        let raw: unknown;
        try { raw = JSON.parse(content); } catch { raw = null; }
        return { content, result: validateCheck(raw, parsed.data) };
      };
      let attempt = await ask(messages);
      if (!attempt.result.ok) {
        req.log.warn({ issue: attempt.result.issue }, "Earning description check needed a correction");
        attempt = await ask([
          ...messages,
          { role: "assistant", content: attempt.content || "{}" },
          { role: "user", content: correctionRequest(attempt.result.issue, attempt.result.words, attempt.result.correction) },
        ]);
      }
      if (!attempt.result.ok) {
        req.log.warn({ issue: attempt.result.issue }, "Earning description check was unusable");
        throw new InvalidCheckResult();
      }
      res.json(CheckEarningDescriptionResponse.parse(attempt.result.value));
    } catch (error) {
      if (controller.signal.aborted) {
        req.log.warn("Earning description check timed out");
        res.status(504).json(fail("timed_out"));
        return;
      }
      if (error instanceof InvalidCheckResult) {
        res.status(502).json(fail("invalid_response"));
        return;
      }
      req.log.error({ upstream: errorSummary(error) }, "Earning description check unavailable");
      res.status(502).json(fail("unavailable"));
    } finally {
      clearTimeout(timeout);
    }
  });
  return router;
}

export default createEarningChecksRouter();