import { Router, type IRouter } from "express";
import type OpenAI from "openai";
import { ReviewTipsBody } from "@workspace/api-zod";
import { createOpenAIClient, errorSummary } from "../lib/earningAI";
import { tipsInstructions, TIPS_SCHEMA, tipsMessage, validateTipsReview } from "../lib/earningTipsReview";
import { checkTipsQuestionCoverage } from "../lib/tipsQuestionCoverage";

const BODY = ReviewTipsBody.extend({ answers: ReviewTipsBody.shape.answers.element.strict().array().min(1) }).strict();
const ERRORS = {
  invalid_request: "We couldn’t read these answers. Check them, then try again.",
  rate_limited: "We’ve checked a lot of answers. Wait a minute, then try again.",
  unavailable: "We can’t check these tips right now. Try again, or select Review later.",
  timed_out: "Checking these tips took too long. Try again, or select Review later.",
  invalid_response: "We couldn’t use the AI response for these tips. Try again, or select Review later.",
} as const;

export function createEarningTipsReviewsRouter({ timeoutMs = 25_000, maxRequestsPerMinute = 30, createClient = createOpenAIClient } = {}): IRouter {
  const router = Router();
  const windows = new Map<string, { count: number; until: number }>();
  router.post("/earnings/tips-reviews", async (req, res): Promise<void> => {
    const fail = (status: number, code: keyof typeof ERRORS) => { res.status(status).json({ code, error: ERRORS[code] }); };
    const now = Date.now();
    for (const [key, value] of windows) if (value.until <= now) windows.delete(key);
    const key = req.ip || req.socket.remoteAddress || "unknown";
    const window = windows.get(key) ?? { count: 0, until: now + 60_000 };
    windows.set(key, window);
    if (++window.count > maxRequestsPerMinute) { fail(429, "rate_limited"); return; }
    const input = BODY.safeParse(req.body);
    if (!input.success || new Set(input.data.answers.map(entry => entry.id)).size !== input.data.answers.length) { fail(400, "invalid_request"); return; }
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const client = createClient();
      const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
        { role: "system", content: tipsInstructions(input.data) }, { role: "user", content: tipsMessage(input.data) },
      ];
      for (let attempt = 0; attempt < 2; attempt++) {
        const completion = await client.chat.completions.create({
          model: "gpt-5.4-mini", max_completion_tokens: 4096, reasoning_effort: "low",
          response_format: { type: "json_schema", json_schema: { name: "tips_review", strict: true, schema: TIPS_SCHEMA } }, messages,
        }, { signal: controller.signal });
        const content = completion.choices[0]?.message?.content ?? "";
        let raw: unknown;
        try { raw = JSON.parse(content); } catch { raw = null; }
        let checked = validateTipsReview(raw, input.data);
        if (checked.ok && checked.value.outcome === "question") {
          const coverage = await checkTipsQuestionCoverage(client, input.data, checked.value, controller.signal);
          if (!coverage.valid) {
            req.log.warn({ issue: "invalid_question_coverage", attempt: attempt + 1 }, "Tips review response rejected");
            fail(502, "invalid_response"); return;
          }
          if (coverage.answered) checked = { ok: false, issue: "answered_fact",
            correction: "This question repeats information already supplied in the active answer history, even though its wording differs. Carry the earlier answers forward, including the opening payment choice. Ask only a genuinely missing fact, or return the supported outcome. Do not invent uncertainty or a contradiction to ask the same thing again." };
        }
        if (checked.ok) { res.json(checked.value); return; }
        // Log only an app-owned category, never customer answers or model content.
        req.log.warn({ issue: checked.issue, attempt: attempt + 1 }, "Tips review response rejected");
        messages.push({ role: "assistant", content: content || "{}" },
          { role: "user", content: `Correct the response: ${checked.correction} Return JSON only.` });
      }
      fail(502, "invalid_response");
    } catch (error) {
      req.log.error({ upstream: errorSummary(error) }, "Tips review unavailable");
      fail(controller.signal.aborted ? 504 : 502, controller.signal.aborted ? "timed_out" : "unavailable");
    } finally { clearTimeout(timeout); }
  });
  return router;
}
export default createEarningTipsReviewsRouter();
