import { Router, type IRouter } from "express";
import type OpenAI from "openai";
import { ReviewMileagePaymentBody } from "@workspace/api-zod";
import { createOpenAIClient, errorSummary } from "../lib/earningAI";
import { MILEAGE_INSTRUCTIONS } from "../lib/earningMileageKnowledge";
import { MILEAGE_SCHEMA, mileageMessage, validMileageInput, validateMileageReview } from "../lib/earningMileageReview";
import { MILEAGE_EVIDENCE_SCHEMA, MILEAGE_EVIDENCE_INSTRUCTIONS, validateMileageEvidence } from "../lib/earningMileageEvidence";
import { MILEAGE_SERVER_DEADLINE_MS } from "@workspace/setup-shared/mileage-policy";
import { mileageStage } from "../lib/mileageDeadline";

const BODY = ReviewMileagePaymentBody.extend({
  answers: ReviewMileagePaymentBody.shape.answers.element.strict().array().min(1),
  historicalAnswers: ReviewMileagePaymentBody.shape.historicalAnswers.element.strict().array(),
}).strict();
export function createEarningMileageReviewsRouter({
  timeoutMs = MILEAGE_SERVER_DEADLINE_MS, maxRequestsPerMinute = 30,
  proposalMs = 30_000, auditMs = 25_000, minimumStageMs = 9_000,
} = {}): IRouter {
  const router = Router();
  const windows = new Map<string, { count: number; until: number }>();
  router.post("/earnings/mileage-reviews", async (req, res): Promise<void> => {
    const fail = (status: number, code: string) => res.status(status).json({ code,
      error: code === "timed_out" ? "Checking this payment took too long. Your answers are kept. Try again, or select Review later."
        : "We couldn’t check this payment. Your answers are kept. Try again, or select Review later." });
    const now = Date.now();
    for (const [key, window] of windows) if (window.until <= now) windows.delete(key);
    const key = req.ip || req.socket.remoteAddress || "unknown";
    const window = windows.get(key) ?? { count: 0, until: now + 60_000 };
    windows.set(key, window);
    if (++window.count > maxRequestsPerMinute) { fail(429, "rate_limited"); return; }
    const parsed = BODY.safeParse(req.body);
    if (!parsed.success || !validMileageInput(parsed.data)) { fail(400, "invalid_request"); return; }
    // Validate against the same redacted evidence sent upstream.
    const input = JSON.parse(mileageMessage(parsed.data));
    const controller = new AbortController();
    const deadline = Date.now() + timeoutMs;
    let expired = false;
    let disconnected = false;
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    const closed = () => { if (!res.writableEnded) { disconnected = true; controller.abort(); } };
    res.once("close", closed);
    try {
      const client = createOpenAIClient();
      const run = async (stage: "proposal" | "audit" | "correction", body: OpenAI.Chat.Completions.ChatCompletionCreateParamsNonStreaming) => {
        const remaining = deadline - Date.now();
        // A proposal is useless without enough time left for its mandatory audit.
        const reserve = stage === "audit" ? 0 : minimumStageMs;
        if (controller.signal.aborted || remaining < minimumStageMs + reserve) {
          expired = true;
          throw new Error("Insufficient mileage stage budget");
        }
        const allowance = Math.min(stage === "audit" ? auditMs : proposalMs, remaining - reserve);
        const start = Date.now();
        try {
          return await mileageStage(controller.signal, allowance, signal =>
            client.chat.completions.create(body, { signal, timeout: allowance, maxRetries: 0 }));
        } catch (error) {
          if (controller.signal.aborted || Date.now() - start >= allowance
            || errorSummary(error).name === "MileageDeadlineError"
            || errorSummary(error).name === "APIConnectionTimeoutError") expired = true;
          throw error;
        } finally {
          req.log.info?.({ stage, durationMs: Date.now() - start }, "MILEAGE stage finished");
        }
      };
      const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
        { role: "system", content: MILEAGE_INSTRUCTIONS }, { role: "user", content: mileageMessage(parsed.data) },
      ];
      for (let attempt = 0; attempt < 2; attempt++) {
        const completion = await run(attempt === 0 ? "proposal" : "correction", {
          model: "gpt-5.4", max_completion_tokens: 6500, reasoning_effort: "medium",
          response_format: { type: "json_schema", json_schema: { name: "mileage_review", strict: true, schema: MILEAGE_SCHEMA } }, messages,
        });
        const content = completion.choices[0]?.message?.content ?? "";
        let raw: unknown;
        try { raw = JSON.parse(content); } catch { raw = null; }
        let result = validateMileageReview(raw, input);
        if (result.ok) {
          const evidence = await run("audit", {
            model: "gpt-5.4", max_completion_tokens: 6500, reasoning_effort: "medium",
            response_format: { type: "json_schema", json_schema: { name: "mileage_evidence", strict: true, schema: MILEAGE_EVIDENCE_SCHEMA } },
            messages: [
              { role: "system", content: MILEAGE_EVIDENCE_INSTRUCTIONS },
              { role: "user", content: JSON.stringify({ conversation: input, proposedReview: raw }) },
            ],
          });
          let audit: unknown;
          try { audit = JSON.parse(evidence.choices[0]?.message?.content ?? ""); } catch { audit = null; }
          result = validateMileageEvidence(audit, raw, input);
        }
        if (controller.signal.aborted || Date.now() >= deadline) { expired = true; throw new Error("Mileage deadline"); }
        if (result.ok) { if (!res.destroyed) res.json(result.value); return; }
        // Corrections can contain exact private evidence; never log them.
        const correction = result.correction;
        const reason = correction.includes("Treatment must be supported") ? "unsupported_treatment"
          : correction.includes("fact is already supplied") || correction.includes("already answered") || correction.includes("repeat") ? "duplicate_question"
          : correction.includes("summary") || correction.includes("Summary") ? "summary"
          : correction.includes("Retain every current grounded fact") ? "evidence_disagreement"
          : correction.includes("Capture is incomplete") ? "incomplete_capture"
          : correction.includes("Questions remain") ? "premature_pending"
          : correction.includes("schema") || correction.includes("Schema") ? "schema"
          : correction.includes("quoted") ? "attribution"
          : correction.includes("terminal") || correction.includes("null") ? "terminal_fields"
          : "other";
        const missingTopics = reason === "incomplete_capture"
          ? [...correction.matchAll(/\b(?:reimbursement|allowance|compensation|informational|noncash|unknown): (purpose|calculation|treatment|wageHandling|presentation|reporting|noncash|informational)\b/g)].map(m => m[1])
          : [];
        req.log.warn({ attempt, reason, missingTopics }, "MILEAGE response needs correction");
        messages.push({ role: "assistant", content: content || "{}" },
          { role: "user", content: `Correct this response: ${result.correction} Return JSON only.` });
      }
      if (!res.destroyed) fail(502, "invalid_response");
    } catch (error) {
      req.log.error({ upstream: errorSummary(error) }, "MILEAGE review unavailable");
      if (!disconnected && !res.destroyed) fail(expired || controller.signal.aborted ? 504 : 502, expired || controller.signal.aborted ? "timed_out" : "unavailable");
    } finally { clearTimeout(timeout); res.off("close", closed); }
  });
  return router;
}
export default createEarningMileageReviewsRouter();
