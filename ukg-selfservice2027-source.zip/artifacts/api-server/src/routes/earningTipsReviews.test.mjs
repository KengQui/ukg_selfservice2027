import assert from "node:assert/strict";
import { mkdtemp, rm, readFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { pathToFileURL } from "node:url";
import test from "node:test";
import express from "express";
import { build } from "esbuild";

test("TIPS uses the supplied prompt, validates questions and fails explicitly", async t => {
  const temp = await mkdtemp(path.join(tmpdir(), "tips-review-test-"));
  const servers = [];
  try {
    await build({ entryPoints: ["src/lib/earningTipsReview.ts", "src/routes/earningTipsReviews.ts"],
      outdir: temp, outExtension: { ".js": ".mjs" }, platform: "node", format: "esm", bundle: true,
      banner: { js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" }, logLevel: "silent" });
    const lib = await import(pathToFileURL(path.join(temp, "lib/earningTipsReview.mjs")));
    const { createEarningTipsReviewsRouter } = await import(pathToFileURL(path.join(temp, "routes/earningTipsReviews.mjs")));
    const original = await readFile("../../attached_assets/Pasted--AI-Prompt-TIPS-Earnings-Code-Roll-Up-Type-Identificati_1792423644047.txt", "utf8");
    const update = await readFile("../../attached_assets/Pasted--5-Internal-AI-Decision-Logic-After-collecting-the-cust_1792430091284.txt", "utf8");
    const source = original.slice(0, original.indexOf("## 5. Internal AI Decision Logic"))
      + update.trim() + "\n\n" + original.slice(original.indexOf("## 6. Output Requirements"));
    assert.ok(lib.TIPS_INSTRUCTIONS.includes(source), "only section 5 is replaced by the exact supplied update");
    assert.ok(!lib.TIPS_INSTRUCTIONS.includes("Do not create or require a second code without verification."));
    assert.match(lib.TIPS_INSTRUCTIONS, /explicitly recommend separate earnings codes as a proposal/);
    assert.match(lib.TIPS_INSTRUCTIONS, /outcome pending, splitReview true, rollUp null/);
    assert.match(lib.TIPS_INSTRUCTIONS, /If the facts or documentation do not support/);
    assert.match(lib.TIPS_INSTRUCTIONS, /untrusted data/);
    const input = { source: "Tip payments", answers: [{ id: "opening", question: "How does your company handle these tips?",
      answer: "We pay these tips to employees in their paychecks." }] };
    const question = { outcome: "question", question: "How are these tips collected before they are paid to employees?",
      options: ["Credit or debit card tips.", "Cash tips collected by the company.", "Both cash and card tips.", "I'm not sure."],
      reason: "The way these tips are collected helps us check how they should reach paychecks.", rollUp: null, splitReview: false };
    const pending = { outcome: "pending", question: null, options: null,
      reason: "The setup team needs to confirm how these tips are paid.", rollUp: null, splitReview: true };
    const mixedInput = { ...input, answers: [{ ...input.answers[0],
      answer: "Cash tips go directly to our team and are only reported through payroll. Shared pool tips are paid in paychecks. Both use TIPS." }] };
    const separateProposal = { ...pending,
      reason: "TIPS covers cash tips your team already received and shared tips paid in paychecks. We recommend separate earnings codes so one reports tips without paying them again and the other pays tips still owed. The setup team needs to check the current TIPS setup and related payroll settings before finalizing this proposal." };
    await t.test("accepts plain conditional questions and review-only outcomes", () => {
      assert.ok(lib.validateTipsReview(question, input).ok);
      assert.ok(lib.validateTipsReview(pending, input).ok);
      const complete = { ...input, answers: [...input.answers, { id: "follow-up-1", question: question.question, answer: "Credit or debit card tips." }] };
      assert.ok(lib.validateTipsReview({ ...pending, outcome: "recommendation", rollUp: "Charge Tips", splitReview: false }, complete).ok);
    });
    await t.test("rejects technical choices, repeated questions and unsupported recommendations, but allows longer conversations", () => {
      assert.equal(lib.validateTipsReview({ ...question, options: ["Charge Tips", "Cash Tips", "I'm not sure"] }, input).ok, false);
      assert.equal(lib.validateTipsReview({ ...question, question: input.answers[0].question }, input).ok, false);
      assert.equal(lib.validateTipsReview({ ...pending, outcome: "recommendation", rollUp: null, splitReview: false }, input).ok, false);
      assert.equal(lib.validateTipsReview({ ...pending, outcome: "recommendation", rollUp: "Cash Tips" }, input).ok, false);
      assert.equal(lib.validateTipsReview(question, { ...input, answers: Array.from({ length: 30 }, (_, i) => ({ id: `${i}`, question: `Question ${i}?`, answer: "Unknown" })) }).ok, true);
      assert.equal(lib.validateTipsReview({ ...question, options: ["Cash", "Card"] }, input).ok, false);
    });
    await t.test("keeps a specific split proposal pending and never assigns either candidate to TIPS", () => {
      assert.ok(lib.validateTipsReview(separateProposal, mixedInput).ok);
      for (const rollUp of ["Cash Tips", "Indirect Tips"]) {
        assert.equal(lib.validateTipsReview({ ...separateProposal, rollUp }, mixedInput).ok, false);
        assert.equal(lib.validateTipsReview({ ...separateProposal, outcome: "recommendation", rollUp }, mixedInput).ok, false);
      }
      assert.equal(lib.validateTipsReview({ ...separateProposal,
        reason: "We recommend Cash Tips and Indirect Tips." }, mixedInput).ok, false);
      assert.equal(lib.validateTipsReview({ ...separateProposal,
        reason: "We have applied separate earnings codes." }, mixedInput).ok, false);
    });
    await t.test("identifies wording and outcome failures without a misleading technical-language correction", () => {
      const wording = lib.validateTipsReview({ ...question, question: "Are both treatments recorded under TIPS?" }, input);
      assert.equal(wording.ok, false);
      assert.equal(wording.issue, "wording");
      assert.match(wording.correction, /record/);
      assert.match(wording.correction, /use TIPS/);
      const outcome = lib.validateTipsReview({ ...separateProposal, outcome: "recommendation" }, mixedInput);
      assert.equal(outcome.ok, false);
      assert.equal(outcome.issue, "outcome_boundary");
      assert.match(outcome.correction, /set outcome pending, rollUp null and splitReview true/);
      assert.match(outcome.correction, /Keep the specific recommendation/);
    });
    const requests = [];
    const warnings = [];
    const queued = [];
    const coverageQueue = [];
    const coverageRequests = [];
    let output = question;
    let unavailable = false;
    const client = { chat: { completions: { create: async request => {
      if (request.response_format.json_schema.name === "tips_question_coverage") {
        coverageRequests.push(request);
        return { choices: [{ message: { content: JSON.stringify(coverageQueue.shift() ?? { answered: false, citations: [] }) } }] };
      }
      requests.push(request);
      if (unavailable) throw new Error("Test-only upstream failure");
      return { choices: [{ message: { content: JSON.stringify(queued.shift() ?? output) } }] };
    } } } };
    const app = express();
    app.use(express.json());
    app.use((req, _res, next) => { req.log = { error() {}, warn(data) { warnings.push(data); } }; next(); });
    app.use(createEarningTipsReviewsRouter({ createClient: () => client, maxRequestsPerMinute: 100 }));
    const server = app.listen(0, "127.0.0.1"); servers.push(server);
    await new Promise(resolve => server.once("listening", resolve));
    const post = async body => {
      const response = await fetch(`http://127.0.0.1:${server.address().port}/earnings/tips-reviews`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
      });
      return { status: response.status, data: await response.json() };
    };
    await t.test("requires receipt evidence and repairs premature already-received recommendations for both codes", async () => {
      const cash = { outcome: "recommendation", question: null, options: null,
        reason: "Your team receives these tips directly as cash. The proposed setup reports them without paying them again.",
        rollUp: "Cash Tips", splitReview: false };
      const receiptQuestion = { ...question, question: "How does your team receive these tips?",
        options: ["Cash directly from customers.", "Card tips paid separately from payroll.", "Through a shared tip pool.", "A combination.", "I'm not sure."],
        reason: "This helps us identify the reporting approach without paying tips twice." };
      for (const code of ["TIPS", "TIPS OWED"]) {
        const received = { ...input, code, answers: [{ ...input.answers[0],
          answer: "Employees have already received their tips (such as cash), and we only need to report them through payroll." }] };
        assert.ok(!JSON.parse(lib.tipsMessage(received)).answers[0].answer.includes("cash"));
        for (const wrong of [cash, { ...cash, receiptEvidence: { method: "directCash", citations: [
          { answerId: "opening", excerpt: "cash" },
        ] } }]) {
          queued.push(wrong, receiptQuestion);
          const response = await post(received);
          assert.equal(response.status, 200);
          assert.deepEqual(response.data, receiptQuestion);
          assert.equal(warnings.at(-1).issue, "missing_receipt_evidence");
        }
        const confirmed = { ...received, answers: [...received.answers, {
          id: "receipt", question: receiptQuestion.question, answer: "Cash directly from customers.",
        }] };
        queued.push({ ...cash, receiptEvidence: { method: "directCash", citations: [
          { answerId: "receipt", excerpt: "Cash directly from customers." },
        ] } });
        const before = requests.length;
        assert.deepEqual((await post(confirmed)).data, cash);
        assert.equal(requests.length, before + 1, "known cash must not trigger another question");
        for (const [method, answer] of [["cardOutsidePayroll", "Card tips paid separately."], ["pooled", "Through a shared tip pool."]]) {
          const body = { ...received, answers: [...received.answers, { id: "receipt", question: receiptQuestion.question, answer }] };
          assert.equal(lib.validateTipsReview({ ...cash, receiptEvidence: {
            method, citations: [{ answerId: "receipt", excerpt: answer }],
          } }, body).ok, false);
          assert.equal(lib.validateTipsReview({ ...pending, receiptEvidence: {
            method, citations: [{ answerId: "receipt", excerpt: answer }],
          } }, body).ok, false, "one confirmed method does not justify a split");
        }
        const unsure = { ...received, answers: [...received.answers, {
          id: "receipt", question: receiptQuestion.question, answer: "I'm not sure.",
        }] };
        const unresolved = { ...pending, splitReview: false,
          reason: "Confirm whether your team receives these tips as cash, separate card payments or pooled tips." };
        assert.ok(lib.validateTipsReview({ ...unresolved, receiptEvidence: {
          method: "unknown", citations: [{ answerId: "receipt", excerpt: "I'm not sure." }],
        } }, unsure).ok);
        assert.equal(lib.validateTipsReview(unresolved, received).ok, false, "missing facts must not silently become pending");
      }
    });
    await t.test("rejects paraphrased paycheck timing and regenerates from the existing opening and card answer", async () => {
      const complete = { ...input, code: "TIPS OWED", answers: [...input.answers, {
        id: "follow-up-1", question: "How are the TIPS OWED tips collected before we pay them to employees?",
        answer: "Credit or debit card tips",
      }] };
      const repeated = { ...question,
        question: "Do employees already receive these tip amounts before payroll, or do we still pay them in the paycheck?",
        options: ["We still pay them in the paycheck.", "Employees already receive the tip money before payroll.", "Both happen.", "I'm not sure."],
        reason: "This tells us whether the tips still need to be paid." };
      const proposal = { ...pending, outcome: "recommendation", splitReview: false, rollUp: "Charge Tips",
        reason: "These card tips are paid in paychecks. The proposed setup keeps that payment separate from tips already received." };
      queued.push(repeated, proposal);
      coverageQueue.push({ answered: true, citations: [{ answerId: "opening", excerpt: input.answers[0].answer }] });
      const before = requests.length;
      const response = await post(complete);
      assert.equal(response.status, 200);
      assert.deepEqual(response.data, proposal);
      assert.equal(requests.length, before + 2);
      assert.equal(warnings.at(-1).issue, "answered_fact");
      assert.match(requests.at(-1).messages.at(-1).content, /Carry the earlier answers forward/);
      const audit = coverageRequests.at(-1);
      assert.deepEqual(JSON.parse(audit.messages[1].content).answers, complete.answers);
      assert.match(audit.messages[0].content, /opening answer is evidence/);
    });
    await t.test("does not expose a repeat after exhausted correction or accept fabricated coverage citations", async () => {
      const repeated = { ...question, question: "Are these tips still owed in the paycheck or already received?" };
      queued.push(repeated, repeated);
      const cite = { answered: true, citations: [{ answerId: "opening", excerpt: input.answers[0].answer }] };
      coverageQueue.push(cite, cite);
      assert.equal((await post(input)).data.code, "invalid_response");
      for (const coverage of [
        { answered: true, citations: [] },
        { answered: true, citations: [{ answerId: "another-code", excerpt: input.answers[0].answer }] },
        { answered: true, citations: [{ answerId: "opening", excerpt: "The employee receives cash at the end of the shift." }] },
        { answered: false, citations: [], unexpected: true },
      ]) {
        queued.push(question); coverageQueue.push(coverage);
        assert.equal((await post(input)).data.code, "invalid_response");
        assert.equal(warnings.at(-1).issue, "invalid_question_coverage");
      }
    });
    await t.test("returns the model question and sends all five selected branches as facts", async () => {
      for (const answer of ["We pay tips in paychecks.", "Tips already received.", "We do both.", "I'm not sure.", "We distribute tips weekly outside payroll."]) {
        const response = await post({ ...input, answers: [{ ...input.answers[0], answer }] });
        assert.equal(response.status, 200);
        assert.deepEqual(response.data, question);
        assert.ok(requests.at(-1).messages[0].content.includes(source));
        assert.equal(JSON.parse(requests.at(-1).messages[1].content).answers[0].answer, answer);
      }
    });
    await t.test("scopes the second code while preserving legacy TIPS and rejecting arbitrary codes", async () => {
      for (const code of ["TIPS", "TIPS OWED", undefined]) {
        const body = { ...input, ...(code ? { code } : {}), exampleContext: "Company-collected tips not received in cash." };
        assert.equal((await post(body)).status, 200);
        const messages = requests.at(-1).messages;
        assert.match(messages[0].content, new RegExp(`Active source code: ${code ?? "TIPS"}`));
        assert.ok(messages[0].content.includes(source), "supplied knowledge stays intact");
        assert.match(messages[0].content, /NOT an extracted register description or a customer-confirmed fact/);
        assert.match(messages[0].content, /never warrants a third code/);
        assert.equal(JSON.parse(messages[1].content).code, code ?? "TIPS");
        assert.equal(JSON.parse(messages[1].content).source, input.source);
      }
      const before = requests.length;
      for (const code of ["CUSTOM TIPS", "", null, 1]) assert.equal((await post({ ...input, code })).status, 400);
      assert.equal((await post({ ...input, exampleContext: "x".repeat(501) })).status, 400);
      assert.equal(requests.length, before);
      const redacted = lib.tipsMessage({ ...input, code: "TIPS OWED", exampleContext: "SSN 123-45-6789" });
      assert.ok(!redacted.includes("123-45-6789"));
    });
    await t.test("keeps invalid requests, malformed model output and outages explicit", async () => {
      const before = requests.length;
      assert.equal((await post({ ...input, answers: [] })).status, 400);
      assert.equal((await post({ ...input, unexpected: true })).status, 400);
      assert.equal(requests.length, before);
      output = { ...question, options: ["Cash Tips", "Charge Tips"] };
      assert.equal((await post(input)).data.code, "invalid_response");
      unavailable = true;
      assert.equal((await post(input)).data.code, "unavailable");
    });
    await t.test("returns the specific split recommendation without reducing it to a generic handoff", async () => {
      unavailable = false;
      output = separateProposal;
      const response = await post(mixedInput);
      assert.equal(response.status, 200);
      assert.deepEqual(response.data, separateProposal);
      assert.ok(requests.at(-1).messages[0].content.includes(update.trim()));
    });
    await t.test("repairs wording and split labels on retry, keeping the supported recommendation", async () => {
      const plainQuestion = { ...question, question: "Do both tip treatments use TIPS?" };
      for (const [bad, good, issue] of [
        [{ ...plainQuestion, question: "Are both treatments recorded under TIPS?" }, plainQuestion, "wording"],
        [{ ...separateProposal, outcome: "recommendation" }, separateProposal, "outcome_boundary"],
      ]) {
        queued.push(bad, good);
        const before = requests.length;
        const response = await post(mixedInput);
        assert.equal(response.status, 200);
        assert.deepEqual(response.data, good);
        assert.equal(requests.length, before + 2);
        assert.deepEqual(warnings.at(-1), { issue, attempt: 1 });
      }
      assert.ok(warnings.every(warning => Object.keys(warning).sort().join() === "attempt,issue"));
      assert.ok(!JSON.stringify(warnings).includes(mixedInput.answers[0].answer));
    });
  } finally {
    await Promise.all(servers.map(server => new Promise(resolve => server.close(resolve))));
    await rm(temp, { recursive: true, force: true });
  }
});
