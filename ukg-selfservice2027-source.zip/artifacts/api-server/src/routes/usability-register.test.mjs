import assert from 'node:assert/strict';
import test from 'node:test';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';

const directory = path.dirname(fileURLToPath(import.meta.url));
test('authored CSVs and combined workbook read without AI or duplicate payments', async () => {
  const temp = await mkdtemp(path.join(directory, '.register-test-'));
  try {
    const outfile = path.join(temp, 'reader.mjs');
    await build({ entryPoints: [path.join(directory, '../lib/registerExtraction.ts')], outfile, bundle: true, platform: 'node', format: 'esm',
      external: ['exceljs', 'pdfjs-dist/*', '@napi-rs/canvas'], logLevel: 'silent',
      banner: { js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" } });
    const { extractRegister } = await import(outfile);
    const read = async name => extractRegister(
      await readFile(path.resolve(directory, '../../../earning-configuration/public/usability', name)), name,
      () => { throw new Error('Authored package unexpectedly needed AI'); });
    const codes = await read('cedar-vale-earning-codes.csv');
    const payments = await read('cedar-vale-payment-detail.csv');
    const workbook = await read('cedar-vale-payroll-package.xlsx');
    assert.equal(codes.reports.length, 1);
    assert.equal(codes.reports[0].rows.length, 10);
    assert.ok(codes.reports[0].rows.every(row => row.amount === null && row.people === null && !row.employeeId));
    assert.equal(payments.reports.length, 2);
    assert.equal(workbook.reports.length, 3);
    assert.ok(workbook.reports[0].rows.every(row => row.locator.startsWith('Earning codes,')));
    assert.ok(workbook.reports[1].rows.every(row => row.locator.startsWith('Payment detail,')));
    const cents = reports => reports.flatMap(report => report.rows).reduce((sum, row) => sum + Math.round((row.amount ?? 0) * 100), 0);
    assert.equal(cents(workbook.reports), cents(payments.reports));
    for (const report of payments.reports) {
      assert.equal(new Set(report.rows.map(row => row.employeeId)).size, 80);
      assert.ok(report.periodStart && report.periodEnd);
      assert.ok(report.rows.every(row => !['COVIDSP', 'BONUS', 'Period total'].includes(row.code)));
    }
    assert.equal(payments.reports.flatMap(report => report.rows).filter(row => row.code === 'BONREV')[0].amount, -150);
  } finally { await rm(temp, { recursive: true, force: true }); }
});
