import { Router, type IRouter } from "express";
import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import { mkdtemp, rm, stat, readFile, writeFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { and, eq, gt, lt } from "drizzle-orm";
import { db, exportJobs } from "@workspace/db";
import { cleanupExpiredExports, deleteExport, streamExport, uploadExport } from "../lib/exportStorage";
import { logger } from "../lib/logger";

const router: IRouter = Router();
const runtime = path.dirname(fileURLToPath(import.meta.url));
const published = process.env.NODE_ENV === "production";
// The API is compiled into artifacts/api-server/dist. In dev, read the live
// editable workspace at click time; in production, use the deployed input tree.
const input = published ? runtime : path.resolve(runtime, "../../..");
const safeSlug = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const templates = ["blank", "ready-header", "crud-page", "employee-profile"];
type Snapshot = { kind: "source" | "template" | "reference"; project?: Record<string, unknown>; records?: unknown };
async function knownSource(slug: string): Promise<boolean> {
  if (slug === "performance-reviews") return existsSync(path.join(input, "artifacts/performance-reviews/src/App.tsx"));
  if (slug === "copy-branding") return existsSync(path.join(input, "artifacts/branding/src/App.tsx")) &&
    existsSync(path.join(input, "artifacts/branding/src/prototypes/system-theme-setup/index.tsx"));
  const base = path.join(input, slug.startsWith("company-setup-")
    ? "artifacts/company-setup/src/prototypes"
    : ["system-theme-setup", "copy-branding"].includes(slug)
      ? "artifacts/branding/src/prototypes" : "artifacts/ready-dls-kit/src/prototypes");
  const source = await readFile(path.join(base, slug, "index.tsx"), "utf8").catch(() => "");
  if (source && new RegExp(`["'\`]?\\b(?:route|id)["'\`]?:\\s*['"\`]${slug}['"\`]`).test(source)
      && /["'`]?section["'`]?:\s*['"`]prototype['"`]/.test(source)) return true;
  if (slug.startsWith("company-setup-")) return false;
  const registry = await readFile(path.join(base, "registry.ts"), "utf8").catch(() => "");
  return [...registry.matchAll(/\{\s*slug:\s*['"]([^'"]+)['"][\s\S]*?filePath:\s*['"]([^'"]+)['"][\s\S]*?\}/g)]
    .some(match => match[1] === slug);
}
const HEADER_LABELS: Record<string, string> = {
  headerTemplate: "header choice", globalHeader: "global header", pageHeader: "page header",
};
function validateSnapshot(slug: string, body: Snapshot): string | null {
  if (!body || !["source", "template", "reference"].includes(body.kind)) return "Choose a valid export kind.";
  if (body.kind === "source") {
    if (body.project != null) return "Source exports cannot include browser project metadata.";
    if (body.records != null && (!Array.isArray(body.records) || body.records.length > 5000 ||
      body.records.some(row => !row || typeof row !== "object" || typeof row.id !== "string" ||
        row.id.length > 128 || typeof row.name !== "string" || row.name.length > 80)))
      return "Some saved items can’t be exported. Keep each name to 80 characters and the list to 5,000 items, then try again.";
    return null;
  }
  const project = body.project;
  if (!project || typeof project !== "object" || Array.isArray(project) ||
      project.slug !== slug || typeof project.title !== "string" || !project.title.trim() ||
      project.title.length > 80 ||
      project.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") !== slug ||
      typeof project.createdAt !== "string" ||
      !/^\d{4}-\d{2}-\d{2}$/.test(project.createdAt) || !templates.includes(String(project.template)))
    return "This project’s saved name, date or page template doesn’t match what Projects expects. Refresh Projects, then try again.";
  for (const [name, choices] of Object.entries({
    headerTemplate: ["ready", "none"], globalHeader: ["light", "dark-teal", "dark-navy"],
    pageHeader: ["title", "back"],
  })) if (project[name] != null && !choices.includes(String(project[name])))
    return `This project’s saved ${HEADER_LABELS[name]} isn’t one of the supported options. Refresh Projects, then try again.`;
  if (body.kind === "template") {
    if (project.source != null) return "Linked projects require a reference-only export.";
    if (project.template === "crud-page" && (!Array.isArray(body.records) || body.records.length > 5000 ||
      body.records.some(row => !row || typeof row !== "object" || typeof row.id !== "string" ||
        row.id.length > 128 || typeof row.name !== "string" || row.name.length > 80))) return "Some saved items can’t be exported. Keep each name to 80 characters and the list to 5,000 items, then try again.";
    if (project.template !== "crud-page" && body.records != null) return "Only CRUD page projects can include saved items. Refresh Projects, then try again.";
  } else {
    const source = project.source as Record<string, unknown> | undefined;
    if (!source || !["figma", "replit-link", "replit-copy", "replit-new"].includes(String(source.kind)))
      return "This project’s link isn’t a Figma or Replit link that can be exported. Edit the link, then try again.";
    if (source.kind !== "replit-copy" && source.originalUrl != null) return "Only a copied Replit project keeps an original project link. Edit the link, then try again.";
    for (const value of [source.url, ...(source.kind === "replit-copy" ? [source.originalUrl] : [])]) {
      if (typeof value !== "string" || value.length > 2048 || /[\\\s]/.test(value) ||
        /%|\/\/|\/\.(?:\/|$)|\/\.\.(?:\/|$)/.test(value.match(/^https:\/\/[^/?#]+([^?#]*)/i)?.[1] ?? ""))
        return "The saved link isn’t a full https:// address for a Figma file or Replit project. Edit the link, then try again.";
      try {
        const url = new URL(value);
        const figma = source.kind === "figma";
        if (url.protocol !== "https:" || url.port || url.username || url.password ||
          !(figma ? ["figma.com", "www.figma.com"] : ["replit.com", "www.replit.com"]).includes(url.hostname) ||
          !(figma ? /^\/(?:design|file|proto|board)\/[a-zA-Z0-9_-]+(?:\/[a-zA-Z0-9_.-]+)*\/?$/
            : /^\/@[a-zA-Z0-9][a-zA-Z0-9_-]*\/[a-zA-Z0-9][a-zA-Z0-9_.-]*(?:\/[a-zA-Z0-9_.-]+)*\/?$/).test(url.pathname))
          return "The saved link isn’t a full https:// address for a Figma file or Replit project. Edit the link, then try again.";
      } catch { return "The saved link isn’t a full https:// address for a Figma file or Replit project. Edit the link, then try again."; }
    }
    if (body.records != null) return "Reference exports include only the saved link, not saved items. Refresh Projects, then try again.";
  }
  return null;
}
function sanitizeSnapshot(body: Snapshot): Snapshot {
  if (body.kind === "source") return { kind: "source", ...(body.records != null
    ? { records: (body.records as Record<string, unknown>[]).map(row => ({ id: row.id, name: row.name })) } : {}) };
  const p = body.project!;
  const project: Record<string, unknown> = {
    slug: p.slug, title: p.title, template: p.template, createdAt: p.createdAt,
  };
  for (const key of ["headerTemplate", "globalHeader", "pageHeader"])
    if (typeof p[key] === "string") project[key] = p[key];
  if (body.kind === "reference") {
    const source = p.source as Record<string, unknown>;
    project.source = { kind: source.kind, url: source.url,
      ...(source.kind === "replit-copy" ? { originalUrl: source.originalUrl } : {}) };
  }
  return { kind: body.kind, project,
    ...(body.kind === "template" && p.template === "crud-page"
      ? { records: (body.records as Record<string, unknown>[]).map(row => ({ id: row.id, name: row.name })) } : {}) };
}
const MAX_ZIP = 60 * 1024 * 1024;
function chromiumExecutable() {
  if (process.env.CHROMIUM_PATH) return process.env.CHROMIUM_PATH;
  // Nix's chromium wrapper carries its own native library search path; a
  // downloaded Playwright binary does not have those libraries in autoscale.
  for (const directory of (process.env.PATH || "").split(path.delimiter)) {
    const executable = path.join(directory, "chromium");
    if (existsSync(executable)) return executable;
  }
  if (!published && existsSync("/repl/tools/bin/chromium")) return "/repl/tools/bin/chromium";
  throw new Error("Chromium is unavailable. Add Nix chromium to the deployment runtime.");
}
const RUNNING_MS = 12 * 60_000; // Child is killed after nine minutes; allow time for upload.
const RETENTION_MS = 15 * 60_000;
const INTERRUPTED = "The export stopped before it finished. Start another export. Your project wasn’t changed.";

async function maintainJobs() {
  const now = new Date();
  // This also recovers jobs orphaned by process termination or instance loss.
  await db.update(exportJobs).set({
    status: "failed", error: INTERRUPTED, expiresAt: new Date(now.getTime() + RETENTION_MS),
  }).where(and(eq(exportJobs.status, "running"), lt(exportJobs.expiresAt, now)));
  const expired = await db.select({ id: exportJobs.id, status: exportJobs.status })
    .from(exportJobs).where(lt(exportJobs.expiresAt, now)).limit(20);
  await cleanupExpiredExports(expired,
    async id => { await db.delete(exportJobs).where(and(eq(exportJobs.id, id), lt(exportJobs.expiresAt, now))); },
    (id, error) => logger.error({ err: error, id }, "Could not remove expired export bytes"),
  );
}

// Cleanup is bounded, and runs even when no one polls an abandoned job.
const maintenance = setInterval(() => {
  void maintainJobs().catch(error => logger.error({ err: error }, "Export cleanup failed"));
}, 60_000);
maintenance.unref();

async function generate(slug: string, id: string, payload: Snapshot): Promise<void> {
  const directory = await mkdtemp(path.join(os.tmpdir(), "ready-handoff-"));
  const archive = path.join(directory, "handoff.zip");
  try {
    const payloadPath = path.join(directory, "project.json");
    await writeFile(payloadPath, JSON.stringify(payload), { mode: 0o600 });
    await new Promise<void>((resolve, reject) => {
      const env = {
        ...process.env,
        HANDOFF_INPUT_ROOT: input,
        // Trusted server-owned origin only. Never construct a browser URL from
        // Host, Referer or request parameters (SSRF).
        HANDOFF_ORIGIN: process.env.HANDOFF_ORIGIN || "http://localhost:80",
        HANDOFF_PLAYWRIGHT_PACKAGE: path.join(runtime, "node_modules/@playwright/test/package.json"),
        PLAYWRIGHT_BROWSERS_PATH: path.join(runtime, "browsers"),
        CHROMIUM_PATH: payload.kind === "reference" ? "" : chromiumExecutable(),
        HANDOFF_KIND: payload.kind,
        HANDOFF_PAYLOAD_PATH: payloadPath,
      };
      // In development the kit's installed Playwright is used, not the staged copy.
      if (!published) env.HANDOFF_PLAYWRIGHT_PACKAGE = path.resolve(input, "artifacts/ready-dls-kit/package.json");
      const child = spawn(process.execPath, [
        path.join(runtime, "scripts/create-claude-archive.mjs"),
        "--slug", slug, "--out", archive,
      ], { cwd: runtime, stdio: ["ignore", "ignore", "pipe"], shell: false, env });
      let errors = "";
      child.stderr.on("data", chunk => { errors = (errors + String(chunk)).slice(-6000); });
      const timer = setTimeout(() => child.kill("SIGKILL"), 9 * 60_000);
      child.on("error", error => { clearTimeout(timer); reject(error); });
      child.on("close", code => {
        clearTimeout(timer);
        code === 0 ? resolve() : reject(new Error(
          `We couldn’t capture fresh screens for ${slug} (exit ${code}): ${errors.trim() || "screen capture timed out or Chromium is unavailable. No older screenshots were used."}`,
        ));
      });
    });
    if ((await stat(archive)).size > MAX_ZIP) throw new Error("Export exceeds the 60 MB safety limit.");
    await uploadExport(id, archive);
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
}

router.post("/exports/:slug", async (req, res) => {
  const slug = req.params.slug;
  const payload = req.body as Snapshot;
  if (typeof slug !== "string" || !safeSlug.test(slug) || !payload ||
      (payload.kind === "source" ? !await knownSource(slug) : !["template", "reference"].includes(payload.kind))) {
    res.status(400).json({ error: "We couldn’t find this project to export. Refresh Projects, then try again." });
    return;
  }
  const validation = validateSnapshot(slug, payload);
  if (validation) { res.status(400).json({ error: validation }); return; }
  try {
    await maintainJobs();
    const id = randomUUID();
    const now = new Date();
    const [claimed] = await db.insert(exportJobs).values({
      id, slug, status: "running", createdAt: now,
      expiresAt: new Date(now.getTime() + RUNNING_MS),
    }).onConflictDoNothing().returning({ id: exportJobs.id });
    if (!claimed) {
      res.status(429).setHeader("Retry-After", "30").setHeader("Cache-Control", "no-store")
        .json({ error: "A handoff is already being generated. Wait for it to finish, then retry your export request." });
      return;
    }
    // Only the instance which atomically inserted the row runs the capture.
    void generate(slug, id, sanitizeSnapshot(payload)).then(async () => {
      const [updated] = await db.update(exportJobs).set({
        status: "ready", expiresAt: new Date(Date.now() + RETENTION_MS),
        objectKey: `exports/${id}.zip`,
      }).where(and(eq(exportJobs.id, id), eq(exportJobs.status, "running"),
        gt(exportJobs.expiresAt, new Date()),
      )).returning({ id: exportJobs.id });
      if (!updated) await deleteExport(id);
    }).catch(async error => {
      const message = error instanceof Error ? error.message : "The export stopped unexpectedly. Start another export.";
      try {
        await db.update(exportJobs).set({
          status: "failed", error: message.slice(0, 6000), expiresAt: new Date(Date.now() + RETENTION_MS),
        }).where(and(eq(exportJobs.id, id), eq(exportJobs.status, "running")));
        await deleteExport(id);
      } catch (cleanupError) {
        logger.error({ err: cleanupError, id }, "Could not record export failure or clean up bytes");
      }
    });
    res.status(202).setHeader("Cache-Control", "no-store").json({ id, status: "running" });
  } catch (error) {
    req.log.error({ err: error }, "Could not start export");
    res.status(503).json({ error: "Exports aren’t available right now. Try again in a moment. Your project wasn’t changed." });
  }
});

router.get("/exports/jobs/:id", async (req, res) => {
  try {
    await maintainJobs();
    const [job] = await db.select().from(exportJobs).where(eq(exportJobs.id, req.params.id)).limit(1);
    if (!job || job.expiresAt < new Date()) {
      res.status(404).json({ error: "This export has expired or can’t be found. Start another export." });
      return;
    }
    res.setHeader("Cache-Control", "no-store");
    res.json({ status: job.status, error: job.error ?? undefined });
  } catch (error) {
    req.log.error({ err: error }, "Could not read export status");
    res.status(503).json({ error: "We couldn’t check on this export. Start another export in a moment." });
  }
});

router.get("/exports/jobs/:id/download", async (req, res) => {
  try {
    const [job] = await db.select().from(exportJobs).where(eq(exportJobs.id, req.params.id)).limit(1);
    if (!job || job.status !== "ready" || !job.objectKey || job.expiresAt < new Date()) {
      res.status(404).json({ error: "This export isn’t ready yet, or it has expired. Start another export." });
      return;
    }
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename="ready-${job.slug}.zip"`);
    res.setHeader("Cache-Control", "no-store");
    await streamExport(job.id, res);
  } catch (error) {
    req.log.error({ err: error }, "Could not download export");
    if (res.headersSent) res.destroy(error instanceof Error ? error : undefined);
    else {
      res.removeHeader("Content-Disposition");
      res.removeHeader("Content-Length");
      res.status(503).json({ error: "The finished export couldn’t be downloaded. Start another export. Your project wasn’t changed." });
    }
  }
});

export default router;