import { Router, type IRouter } from 'express'
import type OpenAI from 'openai'
import { SummarizeEarningDiscussionBody, type EarningCheckError } from '@workspace/api-zod'
import { createOpenAIClient, errorSummary } from '../lib/earningAI'
import { DISCUSSION_SUMMARY_INSTRUCTIONS, DISCUSSION_SUMMARY_SCHEMA, discussionSummaryMessage, validateDiscussionSummary } from '../lib/earningDiscussionSummary'

const BODY = SummarizeEarningDiscussionBody.extend({
  evidence: SummarizeEarningDiscussionBody.shape.evidence.element.strict().array().min(1).max(60),
}).strict()
const ERRORS = {
  invalid_request: 'We couldn’t summarize this context. Your answers are unchanged.',
  rate_limited: 'We’ve summarized a lot of context in the last minute. Try again in a minute.',
  unavailable: 'We can’t summarize this context right now. Try again, or continue with the original answers.',
  timed_out: 'This summary took too long. Try again, or continue with the original answers.',
  invalid_response: 'We couldn’t summarize this context this time. Try again, or continue with the original answers.',
} as const satisfies Record<EarningCheckError['code'], string>

export function createEarningDiscussionSummaryRouter({ timeoutMs = 20_000, maxRequestsPerMinute = 60 } = {}): IRouter {
  const router = Router()
  const windows = new Map<string, { count: number; until: number }>()
  router.post('/earnings/discussion-summary', async (req, res): Promise<void> => {
    const fail = (status: number, code: EarningCheckError['code']) => { res.status(status).json({ code, error: ERRORS[code] }) }
    const now = Date.now()
    for (const [key, window] of windows) if (window.until <= now) windows.delete(key)
    const key = req.ip || req.socket.remoteAddress || 'unknown'
    const window = windows.get(key) ?? { count: 0, until: now + 60_000 }
    windows.set(key, window)
    if (++window.count > maxRequestsPerMinute) { fail(429, 'rate_limited'); return }
    const parsed = BODY.safeParse(req.body)
    if (!parsed.success || !parsed.data.code.trim() || !parsed.data.question.trim()
      || !parsed.data.evidence.every(entry => entry.source.trim() && entry.text.trim())
      || !parsed.data.evidence.some(entry => entry.kind === 'customerAnswer')) { fail(400, 'invalid_request'); return }
    const controller = new AbortController()
    const timeout = setTimeout(() => controller.abort(), timeoutMs)
    try {
      const client = createOpenAIClient()
      const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
        { role: 'system', content: DISCUSSION_SUMMARY_INSTRUCTIONS },
        { role: 'user', content: discussionSummaryMessage(parsed.data) },
      ]
      for (let attempt = 0; attempt < 2; attempt++) {
        const completion = await client.chat.completions.create({
          model: 'gpt-5.4-mini', max_completion_tokens: 2048, reasoning_effort: 'low',
          response_format: { type: 'json_schema', json_schema: { name: 'earning_discussion_summary', strict: true, schema: DISCUSSION_SUMMARY_SCHEMA } },
          messages,
        }, { signal: controller.signal })
        let raw: unknown
        try { raw = JSON.parse(completion.choices[0]?.message?.content ?? '') } catch { raw = null }
        const result = validateDiscussionSummary(raw)
        if (result.ok) { res.json(result.value); return }
        // The correction doesn't echo potentially sensitive or injected upstream output.
        messages.push({ role: 'user', content: result.correction })
      }
      fail(502, 'invalid_response')
    } catch (error) {
      req.log.error({ upstream: errorSummary(error) }, 'Earning discussion summary unavailable')
      fail(controller.signal.aborted ? 504 : 502, controller.signal.aborted ? 'timed_out' : 'unavailable')
    } finally { clearTimeout(timeout) }
  })
  return router
}
export default createEarningDiscussionSummaryRouter()
