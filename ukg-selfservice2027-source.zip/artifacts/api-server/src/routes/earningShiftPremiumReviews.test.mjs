import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";
import express from "express";
import { build } from "esbuild";

const directory = path.dirname(fileURLToPath(import.meta.url));
const body = {
  code: "MISC7", source: { label: "MISC7", description: null },
  teamAnswer: { question: "What does MISC7 pay for?", answer: "An extra $2 an hour for people who work the night shift" },
  reference: { id: "RDY-E-020", name: "Shift differential" },
  existingCodes: [{ code: "SHIFT2", description: "Shift differential" }],
  thread: [],
};
const ask = { outcome: "question", question: "How much does SHIFT2 pay for each hour, and for which shifts?", combineInto: null,
  reason: "SHIFT2 already uses Shift differential, so we need to know how MISC7 compares.", customerQuestion: null,
  answerFormat: { kind: "text", options: null } };
const combine = { outcome: "combine", question: null, combineInto: "SHIFT2",
  reason: "MISC7 and SHIFT2 pay the same $2 an hour for nights. Ready can tell the departments apart in one setup.", customerQuestion: null, answerFormat: null };
const separate = { outcome: "separate", question: null, combineInto: null,
  reason: "MISC7 pays $2 an hour for nights and SHIFT2 pays $1 an hour for evenings under different rules.", customerQuestion: null, answerFormat: null };
const defer = { outcome: "defer", question: null, combineInto: null, reason: "We can’t tell yet whether MISC7 and SHIFT2 pay the same amount.",
  customerQuestion: "Your pay register has SHIFT2 (Shift differential) and MISC7. Does MISC7 pay the same extra amount for the same shifts as SHIFT2?", answerFormat: null };
const turn = index => ({ question: `Question ${index}?`, reply: `Reply ${index}` });
const facts = request => JSON.parse(request.messages[1].content.replace(/^[^\n]*\n/, ""));

test("shift premium review contract, corrections, privacy and failures", async t => {
  const temp = await mkdtemp(path.join(directory, ".shift-premium-test-"));
  const servers = [];
  const original = { key: process.env.AI_INTEGRATIONS_OPENAI_API_KEY, url: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL };
  let mode = "question";
  const requests = [];
  const listen = async app => {
    const server = app.listen(0, "127.0.0.1"); servers.push(server);
    await new Promise(resolve => server.once("listening", resolve));
    return `http://127.0.0.1:${server.address().port}`;
  };
  // Wrong on the first attempt; the retry returns the fixed result.
  const firstAttempt = {
    twoSentences: { ...ask, question: "We need the rate. What does SHIFT2 pay?" },
    noMark: { ...ask, question: "Tell us what SHIFT2 pays" },
    jargon: { ...combine, reason: "MISC7 and SHIFT2 are candidates for consolidation." },
    banned: { ...combine, reason: "MISC7 and SHIFT2 can simply share one setup." },
    tax: { ...separate, reason: "MISC7 is taxed differently from SHIFT2." },
    unnamed: { ...separate, reason: "These codes pay different rates." },
    unknownCode: { ...combine, combineInto: "OTMFG" },
    deferNoQuestion: { ...defer, customerQuestion: null },
    pastCap: ask,
    repeat: { ...ask, question: "Question 1?" },
  };
  const fixed = { twoSentences: ask, noMark: ask, jargon: combine, banned: combine, tax: separate, unnamed: separate, unknownCode: combine,
    deferNoQuestion: defer, pastCap: defer, repeat: ask };
  try {
    const fake = express(); fake.use(express.json());
    fake.post("/chat/completions", async (req, res) => {
      requests.push(req.body);
      if (mode === "timeout") await new Promise(resolve => setTimeout(resolve, 500));
      if (mode === "unavailable") { res.status(400).json({ error: { message: "test refusal" } }); return; }
      const corrected = req.body.messages.length > 2;
      const result = mode === "bad" ? { ...ask, outcome: "merge" }
        : firstAttempt[mode] ? (corrected ? fixed[mode] : firstAttempt[mode])
        : { question: ask, combine, separate, defer }[mode];
      res.json({ id: "test", object: "chat.completion", created: 0, model: req.body.model,
        choices: [{ index: 0, finish_reason: "stop", message: { role: "assistant", content: JSON.stringify(result) } }] });
    });
    process.env.AI_INTEGRATIONS_OPENAI_API_KEY = "test-only";
    process.env.AI_INTEGRATIONS_OPENAI_BASE_URL = await listen(fake);
    const outfile = path.join(temp, "route.mjs");
    await build({ entryPoints: [path.join(directory, "earningShiftPremiumReviews.ts")], outfile, platform: "node", format: "esm", bundle: true,
      banner: { js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" }, logLevel: "silent" });
    const { createEarningShiftPremiumReviewsRouter } = await import(outfile);
    const app = express(); app.use(express.json());
    app.use((req, _res, next) => { req.log = { error() {}, warn() {} }; next(); });
    app.use(createEarningShiftPremiumReviewsRouter({ timeoutMs: 150, maxRequestsPerMinute: 100 }));
    const base = await listen(app);
    const post = input => fetch(`${base}/earnings/shift-premium-reviews`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(input) });

    for (const [outcome, expected] of [["question", ask], ["combine", combine], ["separate", separate], ["defer", defer]]) await t.test(outcome, async () => {
      mode = outcome;
      const response = await post(body);
      assert.equal(response.status, 200);
      assert.deepEqual(await response.json(), expected);
      assert.equal(requests.at(-1).model, "gpt-5.4-mini");
      assert.equal(requests.at(-1).response_format.json_schema.strict, true);
      assert.match(requests.at(-1).messages[0].content, /UKG Ready — Shift Premium \/ Shift Differential/);
    });
    await t.test("the thread reaches the model redacted, with the questions left", async () => {
      mode = "question";
      const thread = [{ question: "What does SHIFT2 pay?", reply: "Ask owner@example.com, it's $1 an hour" }];
      assert.equal((await post({ ...body, thread })).status, 200);
      const sent = facts(requests.at(-1));
      assert.equal(sent.questionsLeft, 3);
      assert.equal(sent.thread.length, 1);
      assert.doesNotMatch(JSON.stringify(requests.at(-1)), /owner@example.com/);
    });
    for (const [value, input, pattern] of [
      ["twoSentences", body, /one sentence ending in \?/], ["noMark", body, /one sentence ending in \?/],
      ["jargon", body, /plain words instead of "consolidation"/], ["banned", body, /simply/], ["tax", body, /tax and legal/],
      ["unnamed", body, /Name MISC7/], ["unknownCode", body, /exactly one of: SHIFT2/], ["deferNoQuestion", body, /customerQuestion/],
      ["pastCap", { ...body, thread: [1, 2, 3, 4].map(turn) }, /No questions are left/],
      ["repeat", { ...body, thread: [turn(1)] }, /already asked/],
    ]) await t.test(`corrects ${value}`, async () => {
      mode = value;
      const response = await post(input);
      assert.equal(response.status, 200);
      assert.deepEqual(await response.json(), fixed[value]);
      assert.match(requests.at(-1).messages.at(-1).content, pattern);
    });
    await t.test("strict body: unknown fields, too many turns and missing codes are rejected", async () => {
      assert.equal((await post({ ...body, extra: true })).status, 400);
      assert.equal((await post({ ...body, source: { ...body.source, extra: 1 } })).status, 400);
      assert.equal((await post({ ...body, thread: [1, 2, 3, 4, 5].map(turn) })).status, 400);
      assert.equal((await post({ ...body, existingCodes: [] })).status, 400);
    });
    await t.test("an unusable result is never a stand-in recommendation", async () => {
      mode = "bad";
      const response = await post(body);
      assert.equal(response.status, 502);
      assert.deepEqual(await response.json(), { code: "invalid_response", error: "We couldn’t compare these codes this time. Try again, or select Defer." });
    });
    await t.test("unavailable and timed out", async () => {
      mode = "unavailable";
      assert.equal((await post(body)).status, 502);
      mode = "timeout";
      const response = await post(body);
      assert.equal(response.status, 504);
      assert.equal((await response.json()).code, "timed_out");
    });
  } finally {
    for (const server of servers) server.close();
    process.env.AI_INTEGRATIONS_OPENAI_API_KEY = original.key;
    process.env.AI_INTEGRATIONS_OPENAI_BASE_URL = original.url;
    await rm(temp, { recursive: true, force: true });
  }
});
