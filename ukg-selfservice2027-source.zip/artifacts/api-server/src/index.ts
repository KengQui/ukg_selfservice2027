import app from "./app";
import { logger } from "./lib/logger";
import { pool } from "@workspace/db";
import { ensureExportJobsTable } from "./lib/exportJobsMigration";
import { ensureRegisterTables } from "./lib/registerMigration";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

try {
  await ensureExportJobsTable(pool);
  await ensureRegisterTables(pool);
} catch (err) {
  logger.fatal({ err }, "Could not initialize service tables; refusing to listen");
  await pool.end();
  process.exit(1);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
});
