import type { pool } from "@workspace/db";

// Additive, transactional bootstrap for deployments whose DB predates export_jobs.
// The transaction-scoped advisory lock serializes startup across API instances.
export async function ensureExportJobsTable(database: typeof pool): Promise<void> {
  const client = await database.connect();
  try {
    await client.query("BEGIN");
    await client.query("SELECT pg_advisory_xact_lock(812719, 24091)");
    await client.query(`
      CREATE TABLE IF NOT EXISTS export_jobs (
        id text PRIMARY KEY,
        slug text NOT NULL,
        status text NOT NULL,
        error text,
        object_key text,
        created_at timestamptz NOT NULL,
        expires_at timestamptz NOT NULL
      )
    `);
    await client.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS export_jobs_one_running
      ON export_jobs (status) WHERE status = 'running'
    `);
    await client.query("COMMIT");
  } catch (error) {
    try {
      await client.query("ROLLBACK");
    } catch {
      // Preserve the original migration error; the client is discarded below.
    }
    throw error;
  } finally {
    client.release();
  }
}