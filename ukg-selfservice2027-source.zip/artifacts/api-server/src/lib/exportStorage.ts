import { Storage } from "@google-cloud/storage";
import { createReadStream } from "node:fs";
import { pipeline } from "node:stream/promises";
import type { Response } from "express";

// App Storage uses the Replit sidecar for credentials in both dev and publish.
const endpoint = "http://127.0.0.1:1106";
const storage = new Storage({
  credentials: {
    audience: "replit",
    subject_token_type: "access_token",
    token_url: `${endpoint}/token`,
    type: "external_account",
    credential_source: {
      url: `${endpoint}/credential`,
      format: { type: "json", subject_token_field_name: "access_token" },
    },
    universe_domain: "googleapis.com",
  },
  projectId: "",
});

function bucket() {
  const id = process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID;
  if (!id) throw new Error("App Storage is not configured: DEFAULT_OBJECT_STORAGE_BUCKET_ID is missing.");
  return storage.bucket(id);
}

// IDs are server generated; do not permit arbitrary DB contents to address other objects.
export function exportObjectKey(id: string) {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(id)) {
    throw new Error("Invalid export job ID.");
  }
  return `exports/${id}.zip`;
}

export async function uploadExport(id: string, filename: string) {
  const file = bucket().file(exportObjectKey(id));
  await pipeline(createReadStream(filename), file.createWriteStream({
    resumable: false,
    metadata: { contentType: "application/zip", cacheControl: "no-store" },
  }), { signal: AbortSignal.timeout(2 * 60_000) });
}

export async function deleteExport(id: string) {
  await bucket().file(exportObjectKey(id)).delete({ ignoreNotFound: true });
}

// The object key is deterministic, including before a job is marked ready.
// A crash after upload but before the DB update can leave bytes owned by a
// failed/interrupted row, so cleanup must not depend on status or objectKey.
export async function cleanupExpiredExports(
  jobs: Array<{ id: string; status: string }>,
  removeMetadata: (id: string) => Promise<void>,
  onError: (id: string, error: unknown) => void,
  removeObject: (id: string) => Promise<void> = deleteExport,
) {
  for (const job of jobs) {
    try {
      await removeObject(job.id);
    } catch (error) {
      onError(job.id, error);
      continue; // Retain metadata so a subsequent pass retries object deletion.
    }
    await removeMetadata(job.id);
  }
}

export async function streamExport(id: string, res: Response) {
  const file = bucket().file(exportObjectKey(id));
  // Check before committing response headers so missing artifacts produce an
  // explicit HTTP failure rather than a corrupt ZIP download.
  const [metadata] = await file.getMetadata();
  if (Number(metadata.size) > 60 * 1024 * 1024) throw new Error("Stored export exceeds the 60 MB safety limit.");
  res.setHeader("Content-Length", String(metadata.size));
  await pipeline(file.createReadStream(), res);
}