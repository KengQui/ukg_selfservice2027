/**
 * Custom earning-name suggestions for codes whose reference lookup explicitly
 * found no suitable reference. The instructions follow
 * docs/earning-prompts/unable-to-identify.md ("No-match naming") and the shared
 * general part in docs/earning-prompts/general.md; keep them aligned.
 */
import { bannedWordsIn, redactSensitive } from "./bryteAnswer";
import { composePrompt } from "./earningPromptGeneral";

export interface EarningNameRequest {
  code: string;
  source: { label: string; description: string | null };
  description: string;
  answers: { question: string; answer: string }[];
  lookup: { outcome: "noSuitableReference"; reason: string };
}

export type EarningNameSuggestion =
  | { outcome: "suggestion"; name: string; rationale: string; question: null }
  | { outcome: "needsInformation"; name: null; rationale: null; question: string };

export const EARNING_NAME_SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: ["outcome", "name", "rationale", "question"],
  properties: {
    outcome: { type: "string", enum: ["suggestion", "needsInformation"] },
    name: { anyOf: [{ type: "string" }, { type: "null" }] },
    rationale: { anyOf: [{ type: "string" }, { type: "null" }] },
    question: { anyOf: [{ type: "string" }, { type: "null" }] },
  },
} as const;

/**
 * No-match naming (Unable to identify): the shared general part plus this process's part.
 * See docs/earning-prompts/unable-to-identify.md ("No-match naming").
 */
export const EARNING_NAME_PROCESS_RULES = [
  "The reference lookup already found no suitable Ready reference for this code. Do not look for, name or invent a Ready reference.",
  "The user message comes from a pay register and from the customer describing their payment.",
  "First decide whether the facts make the payment's purpose clear enough to name. A purpose is clear when you can say what the payment is for, such as the work, event or circumstance it pays for.",
  "If the purpose is clear, return outcome \"suggestion\" with one name and a rationale, and set question to null.",
  "If the purpose is not clear, or the facts conflict, return outcome \"needsInformation\" with one short, specific question about the missing purpose, and set name and rationale to null. Never guess a name from vague words such as adjustment, miscellaneous, other or special.",
  "Name style: 1 or 2 words, at most 12 characters including spaces, sentence case, plain words suitable for a compact payroll register label. Prefer one clear word; leave payment details in the description. For a payment for using a second language, Bilingual is a compact label; do not use Second language stipend or Language stipend. Name the payment's purpose. Do not include the pay code, internal matching terms, abbreviations employees wouldn't know, or the words code, earning or payroll.",
  "Rationale: one or two sentences, at most 300 characters, written to the customer. Compare the actual current label (source.description when supplied, otherwise code) with the proposed purpose-specific name. Name the reader explicitly as an employee reading their pay statement. Explain what the current label does not tell that employee and how the suggested name identifies the known payment purpose. Use only supplied facts; do not recap why no reference matched, repeat the description alone, or merely claim the name is clear.",
  "For example, when the current label is Special Pay and the supplied purpose is extra pay for using a second language with customers: ‘Special Pay’ doesn’t tell an employee reading their pay statement what this payment is for. The suggested name identifies the extra pay for using a second language with customers. This is an illustration, not a purpose to assume for other payments.",
  "Question: one sentence, at most 200 characters, asking the customer for the specific missing fact. Write it as a direct question.",
  "For needsInformation, include the specific missing purpose and why it is needed to name the payment in that one question, keeping rationale null. Do not claim a rename is legally required, that employees tested the name, or that accepting it changes live payroll. Naming only proposes a name for setup review; do not promise to send it.",
  "Never state or imply a Ready ID. Never promise how the name appears on any tax form.",
];

export const EARNING_NAME_INSTRUCTIONS = composePrompt(
  "You suggest one custom earning name for a payroll earning code during UKG Ready earning setup.",
  EARNING_NAME_PROCESS_RULES,
);

/** Source facts and the team's answers, labeled as data and redacted. */
export function buildNamingMessage(request: EarningNameRequest): string {
  const facts = {
    code: request.code,
    source: {
      label: redactSensitive(request.source.label),
      description: request.source.description === null ? null : redactSensitive(request.source.description),
    },
    teamDescription: redactSensitive(request.description),
    followUpAnswers: request.answers.map((entry) => ({
      question: redactSensitive(entry.question),
      answer: redactSensitive(entry.answer),
    })),
    referenceLookup: { outcome: request.lookup.outcome, reason: redactSensitive(request.lookup.reason) },
  };
  return `Facts for one earning code, as JSON data:\n${JSON.stringify(facts, null, 2)}`;
}

const GENERIC_NAMES = new Set(["adjustment", "adjustments", "miscellaneous", "misc", "other", "other pay", "special pay", "extra pay", "earning", "earnings", "pay", "payment"]);
/** Payroll treatment, forms and references the AI never asserts: names describe purpose only. */
const FORBIDDEN_CLAIMS = /\b(w-?2s?|w2s?|1099s?|box \d+|tax(es|ed|able|ing)?|non-?taxable|tax[- ]exempt|pre-?tax|withholding|withheld|fica|irs|flsa|overtime|regular rate|exempt|reported|reporting|reports? (?:on|to)|tax forms?|rdy-[a-z]-\d+|ready id|ready reference|verified|classification|classified|garnish\w*)\b/i;
/** Words the naming contract keeps out of an employee-facing name. */
const NAME_TERMS = /\b(code|codes|earning|earnings|payroll)\b/i;

export type NamingIssue = "shape" | "name_length" | "generic_name" | "contains_code" | "forbidden_claim" | "banned_word" | "text_length" | "name_terms";

/** Names are sentence case; title-cased words after the first are lowered, acronyms such as PTO stay. */
function sentenceCase(name: string | null): string | null {
  if (!name) return name;
  return name.split(" ").map((word, index) => {
    if (/^[A-Z0-9]{2,}$/.test(word)) return word;
    if (index === 0) return word.charAt(0).toUpperCase() + word.slice(1);
    return /^[A-Z][a-z’'-]+$/.test(word) ? word.toLowerCase() : word;
  }).join(" ");
}

/** Checks the model's result against the contract; returns the first issue or the cleaned result. */
export type NamingCheck = { ok: true; value: EarningNameSuggestion } | { ok: false; issue: NamingIssue; words?: string[] };

export function validateNaming(raw: unknown, code: string): NamingCheck {
  if (typeof raw !== "object" || raw === null) return { ok: false, issue: "shape" };
  const { outcome, name, rationale, question } = raw as Record<string, unknown>;
  const clean = (value: unknown) => (typeof value === "string" ? value.replace(/\s+/g, " ").trim() : null);
  if (outcome === "suggestion") {
    const cleanName = sentenceCase(clean(name)?.replace(/^["'‘“]+|["'’”.]+$/g, "") ?? null);
    const cleanRationale = clean(rationale);
    if (!cleanName || !cleanRationale || question !== null) return { ok: false, issue: "shape" };
    if (GENERIC_NAMES.has(cleanName.toLowerCase())) return { ok: false, issue: "generic_name" };
    const wordCount = cleanName.split(" ").length;
    if (cleanRationale.length > 300) return { ok: false, issue: "text_length" };
    if (cleanName.toUpperCase().split(/[^A-Z0-9]+/).includes(code.toUpperCase().replace(/[^A-Z0-9]/g, ""))) {
      return { ok: false, issue: "contains_code" };
    }
    if (FORBIDDEN_CLAIMS.test(cleanName) || FORBIDDEN_CLAIMS.test(cleanRationale)) return { ok: false, issue: "forbidden_claim" };
    if (NAME_TERMS.test(cleanName)) return { ok: false, issue: "name_terms" };
    if (cleanName.length > 12 || wordCount < 1 || wordCount > 2) return { ok: false, issue: "name_length" };
    const words = bannedWordsIn(`${cleanName} ${cleanRationale}`);
    if (words.length) return { ok: false, issue: "banned_word", words };
    return { ok: true, value: { outcome, name: cleanName, rationale: cleanRationale, question: null } };
  }
  if (outcome === "needsInformation") {
    const cleanQuestion = clean(question);
    if (!cleanQuestion || name !== null || rationale !== null) return { ok: false, issue: "shape" };
    if (cleanQuestion.length > 200) return { ok: false, issue: "text_length" };
    if (FORBIDDEN_CLAIMS.test(cleanQuestion)) return { ok: false, issue: "forbidden_claim" };
    const words = bannedWordsIn(cleanQuestion);
    if (words.length) return { ok: false, issue: "banned_word", words };
    return { ok: true, value: { outcome, name: null, rationale: null, question: cleanQuestion } };
  }
  return { ok: false, issue: "shape" };
}

const CORRECTIONS: Record<NamingIssue, string> = {
  shape: "Return exactly one outcome: a suggestion with name and rationale and a null question, or needsInformation with a question and null name and rationale.",
  name_length: "The register label must be 1 or 2 words and at most 12 characters including spaces. Prefer one clear word and keep details in the description.",
  text_length: "Keep the rationale within 300 characters and the question within 200 characters.",
  generic_name: "The name is too general. Name the payment's purpose, or ask for the missing information instead.",
  contains_code: "Don't include the pay code in the name.",
  name_terms: "Don't use the words code, earning or payroll in the name. Name the payment's purpose.",
  forbidden_claim: "Remove any mention of tax, tax forms, reporting, overtime, exemptions, classification, verification or Ready references. Compare the current label with the proposed purpose-specific name for an employee reading their pay statement.",
  banned_word: "Rewrite without the voice guide's banned words.",
};

export function correctionRequest(issue: NamingIssue, words: readonly string[] = []): string {
  const detail = issue === "banned_word" && words.length
    ? `Rewrite without these words: ${words.join(", ")}. Say "clear" or "plain" instead of easy, and keep the meaning.`
    : CORRECTIONS[issue];
  return `Your result didn't meet the rules. ${detail} Return the corrected JSON only.`;
}
