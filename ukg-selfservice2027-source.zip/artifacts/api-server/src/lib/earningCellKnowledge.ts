/** Maintained with docs/earning-prompts/knowledge/cellphone.md; reviewed October 9, 2026. */
export const CELL_KNOWLEDGE = `
CELL's cellphone allowance/reimbursement purpose is established by supplied mapping context, NOT by a verified database or printed register description.
IRS Notice 2011-72 (https://www.irs.gov/pub/irs-drop/n-11-72.pdf) concerns employer-provided phones primarily for substantial noncompensatory business reasons, not cash reimbursements.
IRS examiner memo SBSE-04-0911-083, September 14, 2011 (https://www.irs.gov/pub/foia/ig/sbse/sbse-04-0911-083.pdf), concerns personally owned phones. It is audit guidance, not a technical position, and its interim expiration is September 19, 2012. It considers business need, reasonable coverage, amounts reasonably calculated not to exceed actual expenses, and no substitution for wages. A flat monthly plan can fit that approach.
The archived IRS announcement IR-2011-93 corroborates the distinction and recordkeeping relief. None of these sources certifies a customer's eligibility or state/local treatment.
Fixed does not imply taxable. Reimbursement, business use or receipts do not imply nontaxable. Never demand receipts, monthly substantiation, an accountable-plan judgment, or a legal eligibility decision from the customer.
No verified UKG Ready catalog or split requirement is supplied. Never propose reference names, separate codes or automatic setup. Capture independent intended tax treatment, not a legal determination.
`;
