import type { pool } from '@workspace/db';

/** Additive bootstrap, matching the existing export service's deployment convention. */
export async function ensureRegisterTables(database: typeof pool) {
  const client = await database.connect();
  try {
    await client.query('BEGIN');
    await client.query('SELECT pg_advisory_xact_lock(812719, 24092)');
    await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id varchar PRIMARY KEY DEFAULT gen_random_uuid(), email varchar UNIQUE,
        first_name varchar, last_name varchar, profile_image_url varchar,
        created_at timestamp NOT NULL DEFAULT now(), updated_at timestamp NOT NULL DEFAULT now()
      );
      CREATE TABLE IF NOT EXISTS sessions (sid varchar PRIMARY KEY, sess jsonb NOT NULL, expire timestamp NOT NULL);
      CREATE INDEX IF NOT EXISTS "IDX_session_expire" ON sessions(expire);
      CREATE TABLE IF NOT EXISTS earning_register_files (
        id text PRIMARY KEY, owner_id text NOT NULL, name text NOT NULL, size_bytes integer NOT NULL,
        doc_type text NOT NULL, object_path text NOT NULL, status text NOT NULL,
        error text, sha256 text, evidence jsonb,
        created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS earning_register_owner ON earning_register_files(owner_id);
    `);
    await client.query('COMMIT');
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally { client.release(); }
}
