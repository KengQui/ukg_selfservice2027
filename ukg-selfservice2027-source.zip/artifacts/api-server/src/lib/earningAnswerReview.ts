import { ReviewEarningAnswerResponse, type EarningAnswerReviewInput } from "@workspace/api-zod";
import { bannedWordsIn, redactSensitive } from "./bryteAnswer";
import { composePrompt } from "./earningPromptGeneral";
import { TIPS_KNOWLEDGE_PROMPT } from "./earningTipsKnowledge";

export const ANSWER_REVIEW_SCHEMA = {
  type: "object", additionalProperties: false,
  required: ["outcome", "reason", "suggestion", "question", "conflictingFact", "askBryte", "medicalSetup"],
  properties: {
    medicalSetup: { anyOf: [{ type: "null" }, {
      type: "object", additionalProperties: false, required: ["name", "classification", "employeeMedicalCode"],
      properties: {
        name: { type: "string", minLength: 1, maxLength: 100 },
        classification: { type: "string", enum: ["Earning", "Deduction"] },
        employeeMedicalCode: { type: ["string", "null"], minLength: 1, maxLength: 20 },
      },
    }] },
    outcome: { type: "string", enum: ["confirm", "conflict", "followUp", "notNeeded"] },
    reason: { type: "string", minLength: 1, maxLength: 300 },
    suggestion: { type: "string", minLength: 1, maxLength: 300 },
    question: { anyOf: [{ type: "string", minLength: 1, maxLength: 200 }, { type: "null" }] },
    conflictingFact: { type: ["string", "null"], enum: ["description", "section", "peopleCount", "amount", "observedReference", null] },
    askBryte: { type: "boolean" },
  },
};

const ANSWER_REVIEW_ROLE = "You review one typed answer to a fixed, approved UKG Ready pay-code setup question: a description the person wrote, such as Something else, and their replies to your follow-up questions. Fixed option picks are never sent; their outcome is set by the app. Never rewrite the fixed question or options.";

/** The answer-review contract every process shares: inputs, outcomes and evidence requirements. */
const ANSWER_REVIEW_CONTRACT = [
  "Compare the typed answer, with the option it was typed under and any earlier picks on the card as context, with the supplied register facts and earlier answers. A register is historical evidence, not a guarantee of current use.",
  "The review is a short conversation. thread lists the questions you already asked and the person's replies, oldest first, with your reason and suggestion on each turn when known; it is empty on the first review. Review the newest reply together with the original answer and the whole thread. Never ask a question the thread already answers, and never ask the same question twice.",
  "Return notNeeded when the person explicitly says the code is old and no longer used or should not be set up. Historical amounts do not contradict this. Suggest leaving it out, never remove it yourself.",
  "Return confirm when the answer is resolved: it fits, or it supplies the missing fact, or what happens next is clear. Missing register details alone are not a conflict.",
  "Return conflict only for a direct disagreement with a supplied register fact. Set conflictingFact to its field name and name that fact and its value in the reason. A conflict may ask one question to settle the disagreement.",
  "Do not infer conflicts from code abbreviations.",
  "Return followUp only when a specific missing fact can change the supported proposal or make the setup-team handoff actionable. In the reason's one short sentence, name that still-missing fact, why it matters for this payment, then the proposal or handoff detail the answer will inform. Ask exactly one targeted question ending in ?. If the person says only what the code is not and no supplied evidence explains its purpose, ask what it pays for without guessing a purpose. It is not a replacement opening question.",
  "A short label can resolve the answer when the question, supplied evidence and earlier answers explain what it covers. Do not require who gets it, amounts or repeated confirmation unless that missing fact can change the next supported action. A sufficient setup-team handoff resolves the answer even though the code is not ready for setup.",
  "Every result has a reason and a suggestion. The reason is one short sentence on what the answer tells us; don't only repeat the answer back. The suggestion is one or two short sentences with a concrete next step. A resolved suggestion says what happens next: we'll set it up this way, it's waiting for the setup team's review, or leave the code out. Never put a question in the suggestion.",
  "There is no follow-up question-count limit. Continue only while a specific material fact is missing; resolve the answer when the evidence supports the next action. Never confirm or hand off an answer merely because of the number of questions already asked.",
  "medicalSetup is null unless the process explicitly requests it. It is a proposal, not a verified reference or an accepted setup.",
  "question is required for followUp, optional for conflict and null for confirm and notNeeded. conflictingFact is null except for conflict. A suggestion proposes a setup, it doesn't choose one.",
  "The reader is the customer who gave the answer: address them as you (\"You said…\"), never as the team.",
  "When the option is Something else, the typed answer replaces the listed answers to that question: none of them is true. Review it as an answer to that question, with the earlier picks on the card as context. Whatever it says, the code waits for the setup team's review with nothing more asked on the card, so a resolved suggestion names that review and never says we'll set it up, add it, keep it or remove it.",
];

/** The process each typed answer comes from; the app sends it with every review. */
export type AnswerReviewProcess = EarningAnswerReviewInput["process"];

/**
 * Medical plan review: employee and employer portions belong on one deduction at setup.
 * A later separate code is only a fallback when the portion wasn't set up initially.
 */
export const PLAN_CONTRIBUTION_RULES = [
  "Plan questions ask what MED holds. Standard medical setup has employee and employer portions on ONE deduction, never a separate earning or company code for visibility. Show Employer Amount optionally displays the company part; Show YTD is also optional but is not asked here. Never explain the later-code fallback up front or use EE/ER abbreviations. You may ask about the company's part to understand MED, and may mention its optional display on pay statements.",
  "The typed answer is the description under MED No. Review it with the person's earlier answers. Use only followUp or confirm: neither an automatic removal nor Keep my answer settles this question.",
  "MED No means MED is not what people pay, not that the company contribution is unwanted. Ask one missing business fact at a time until you understand what MED holds and whether another code holds what people pay for medical. Examples: medical-cost payback, company cost, employee deductions under another code, or no employee medical deduction. Reuse the whole thread. A brief reimbursement purpose can suffice; never ask a checklist merely because it is short.",
  "Resolved MED No MUST return confirm, question null and medicalSetup: { name: a concrete plain Ready setup name, classification: Earning or Deduction, employeeMedicalCode: the code identified by the person, or null only when no employee medical deduction exists }. Suggest that setup for the person to confirm using Use this setup. NEVER send MED to the setup team's review and never accept your own proposal. Do not invent tax treatment or an employee deduction code. Resolve missing employee-code identity before proposing. MED ER then attaches to the identified deduction; if none exists the app asks for company-only setup confirmation.",
  "If the person writes that their company may start paying later, say we’ll still set up a company portion now, so it’s ready once their company starts paying. Don’t explain why. This does not answer a missing MED purpose or authorize accepting the setup.",
  "If the person insists the company portion should not be set up, accept without persuasion. Once MED's purpose and employee deduction identity are understood, return confirm with medicalSetup and askBryte true; briefly say a new code is needed if their company starts paying later. Never mention Bryte; the app adds the link. A No about MED's purpose alone is not an insisted decline.",
  "In every other case set askBryte to false and don’t bring up a company contribution starting later.",
];

export const MISCLASSIFIED_REVIEW_RULES = [
  "For MED ER typed answers use followUp or confirm, never notNeeded or conflict. Explain any disagreement through the follow-up conversation without bypassing setup review.",
  "MED ER appears in earnings, but source category and code name do not establish purpose. Its fixed opening asks company medical contribution, direct money, other or unsure. For company contributions ask only insurance-cost tracking versus inclusion in taxable pay, with unsure allowed. Unknown tax treatment retains provisional employer-contribution purpose. For direct money distinguish allowance from reimbursement; reimbursement is not automatically taxable wages and taxable noncash benefits are not ordinary cash pay. Other or unknown purpose may finish requiring review with an optional brief description. Never ask W-2 boxes, tax codes, formal plan adoption, configuration fields or continuation as standard classification questions. Never repeat reliably established facts. Use only available references whose definitions support the purpose; Employer portion of MED is a candidate, never an automatic attachment. Conceptual roll-up names are not verified catalog entries. Keep user-reported tax treatment separate from validated evidence; only validated purpose and required mapping evidence could support Confirmed. Contradictions or unsupported destinations require review. Preserve the short recap and structured saved outcome, not a long specialist report. Overtime safeguards remain separate.",
  "Something else also ends in setup-team review. Never accept a proposal, attach a portion, infer tax treatment or claim a verified catalog match. A resolved MED ER suggestion must name the setup team's review. medicalSetup is always null; askBryte is always false. These are Misclassified rules, not plan-contribution rules.",
];
/** Unable to identify: descriptions of what a code pays for, and How is this pay different? See docs/earning-prompts/unable-to-identify.md. */
export const UNABLE_TO_IDENTIFY_REVIEW_RULES = [
  "For ADJ2, reported zero amounts do not prove no payments, inactivity or retirement, and no separate code-list source is supplied. Its unknown purpose needs clarification; inclusion is a separate explicit choice. Never recommend removal from amounts or missing rows.",
  "These typed answers describe a code we couldn't identify: what it pays for (a description, or Special Pay's Something else), or, under How is this pay different?, how its pay differs from codes already set up with the same Ready reference.",
  "A Something else under a follow-up, under Keep or remove, or under a suggested Ready reference or custom name says how the code works when none of those answers is true. Use the code's earlier description and answers as context.",
];

const PROCESS_RULES: Record<AnswerReviewProcess, readonly string[]> = {
  planContributions: PLAN_CONTRIBUTION_RULES,
  unableToIdentify: UNABLE_TO_IDENTIFY_REVIEW_RULES,
  // Leave-purpose clarification is bounded; other clarification answers retain the general review behavior.
  needMoreInformation: [
    "For VAC, SICK, HOL or JURY leave-purpose questions, clarify only what the existing code pays for. The listed purpose is vacation, illness, company holidays without working, or time away for jury duty. Something else stays awaiting the setup team's review, even when its description is clear. Do not assign an alternative Ready reference or infer accruals, eligibility, statutory leave, payout calculations, tax or overtime policy. JURY's later keep-or-remove question is separate.",
  ],
  misclassified: MISCLASSIFIED_REVIEW_RULES,
  // Something else on the Optimization and Overtime questions: the general part and the shared contract only.
  optimizationOvertime: [],
};

/** askBryte is a Who pays into each plan signal only; every other process always sets it to false. */
const ASK_BRYTE_OFF = "askBryte is always false for this answer.";

/** The answer review prompt: the shared general part, the answer-review contract, then this process's part only. */
export function answerReviewInstructions(process: AnswerReviewProcess, code?: string): string {
  return composePrompt(ANSWER_REVIEW_ROLE, [
    ...ANSWER_REVIEW_CONTRACT,
    ...PROCESS_RULES[process],
    ...(process === "needMoreInformation" && (code === "TIPS" || code === "TIPS OWED")
      ? [TIPS_KNOWLEDGE_PROMPT, `Assess only ${code}. TIPS in the supplied knowledge denotes the active code, not another code's answers. Authored example context is not extracted register evidence or a confirmed answer. Two existing source codes never establish mixed treatments within one code or a need for a third code.`] : []),
    ...(process === "planContributions" ? [] : [ASK_BRYTE_OFF]),
  ]);
}

/** Redact every text field again on the server, including the answer's approved wording and every turn of the thread. */
export function buildAnswerReviewMessage(input: EarningAnswerReviewInput): string {
  return JSON.stringify(input, (_key, value: unknown) => typeof value === "string" ? redactSensitive(value) : value);
}

const normalized = (text: string) => text.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();

export function validateAnswerReview(raw: unknown, input: EarningAnswerReviewInput) {
  const parsed = ReviewEarningAnswerResponse.strict().safeParse(raw);
  if (!parsed.success) return { ok: false as const, correction: "Use exactly the required fields and their allowed types and lengths." };
  const value = parsed.data;
  value.reason = value.reason.trim();
  value.suggestion = value.suggestion.trim();
  value.question = value.question?.trim() ?? null;
  if (!value.reason || !value.suggestion || value.question === "") {
    return { ok: false as const, correction: "Give a short meaningful reason, a concrete suggestion and, only when the answer isn't resolved, one question." };
  }
  if (value.outcome === "followUp" && value.question === null) return { ok: false as const, correction: "A followUp must ask one question." };
  if ((value.outcome === "confirm" || value.outcome === "notNeeded") && value.question !== null) {
    return { ok: false as const, correction: "confirm and notNeeded resolve the answer, so set question to null. Use followUp to keep asking." };
  }
  if ((value.outcome === "conflict") !== (value.conflictingFact !== null)) {
    return { ok: false as const, correction: "Only conflict has a conflictingFact. Set it to null otherwise." };
  }
  if (typeof value.askBryte !== "boolean") return { ok: false as const, correction: "Include askBryte as true or false." };
  if (value.askBryte && input.process !== "planContributions") {
    return { ok: false as const, correction: "Set askBryte to false. It applies only to questions about who pays into a benefit plan." };
  }
  if (value.askBryte && value.outcome !== "confirm") {
    return { ok: false as const, correction: "askBryte can be true only with outcome confirm, when the person insists the employer contribution shouldn't be set up. Otherwise set it to false." };
  }
  const text = `${value.reason} ${value.suggestion} ${value.question ?? ""}`;
  if (/\bbryte\b/i.test(text)) {
    return { ok: false as const, correction: "Don't mention Bryte in the reason, suggestion or question. Set askBryte instead when it applies; the app shows its own link." };
  }
  if (value.question && !value.question.endsWith("?")) return { ok: false as const, correction: "End the one follow-up question with ?." };
  if (value.suggestion.includes("?")) return { ok: false as const, correction: "The suggestion states a next step; put any question in question." };
  const medical = input.code === "MED" && input.process === "planContributions";
  const medicalEmployer = input.code === "MED ER" && input.process === "misclassified";
  if ((medical || medicalEmployer) && !["confirm", "followUp"].includes(value.outcome)) {
    return { ok: false as const, correction: "Medical typed answers need followUp for a missing fact or confirm for a resolved proposal. Never remove the code or bypass review through conflict." };
  }
  if (medical && value.outcome === "confirm" && (!value.medicalSetup || /setup team|awaiting setup review/i.test(value.suggestion))) {
    return { ok: false as const, correction: "Resolved MED No needs medicalSetup and a concrete proposal for Use this setup, never a setup-team handoff." };
  }
  if (value.medicalSetup && (!medical || value.outcome !== "confirm")) {
    return { ok: false as const, correction: "medicalSetup belongs only to a resolved MED planContributions confirm. Set it to null otherwise." };
  }
  if (input.code === "MED ER" && input.process === "misclassified" && value.outcome === "confirm" && !/setup team/i.test(value.suggestion)) {
    return { ok: false as const, correction: "MED ER's typed answer waits for the setup team's review. Name that review and the proposed setup, without accepting it." };
  }
  if (value.question && input.thread.some(turn => normalized(turn.question) === normalized(value.question!))) {
    return { ok: false as const, correction: "That question was already asked and answered in the thread. Ask a different question, or resolve the answer." };
  }
  if (value.conflictingFact && input.facts[value.conflictingFact] === null) return { ok: false as const, correction: "A missing fact cannot disagree. Use confirm or followUp instead." };
  if (value.conflictingFact) {
    const names = { description: /description/i, section: /section|earnings|deductions/i, peopleCount: /people|team|person|count/i,
      amount: /amount|total|payment|\$/i, observedReference: /reference|match/i };
    const supplied = String(input.facts[value.conflictingFact]).toLowerCase();
    if (!names[value.conflictingFact].test(value.reason) && !value.reason.toLowerCase().includes(supplied)) {
      return { ok: false as const, correction: `Name the supplied ${value.conflictingFact} fact that disagrees in the reason.` };
    }
  }
  const words = bannedWordsIn(text);
  if (words.length) return { ok: false as const, correction: `Rewrite without these words: ${words.join(", ")}.` };
  if (/[!]|[*#`]|\p{Extended_Pictographic}|\b(I|I'm|I'll|I've)\b/u.test(text)) return { ok: false as const, correction: "Use plain text and we, not I. No markdown, emoji or exclamation points." };
  return { ok: true as const, value };
}
