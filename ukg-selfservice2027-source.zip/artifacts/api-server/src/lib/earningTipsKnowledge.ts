import reference from "../../../../docs/earning-prompts/knowledge/tips-payroll.json" with { type: "json" };

/** One maintained source, bundled into the server; no runtime workspace filesystem dependency. */
export const TIPS_KNOWLEDGE = reference;
export const TIPS_PAYMENT_EXPLANATION = "Tips paid through payroll need to be included in people’s paychecks. Tips people already received need to be reported without paying them again. Your answer helps us check that each amount is handled correctly.";

export const TIPS_KNOWLEDGE_PROMPT = [
  "Tips reference (background knowledge, not customer evidence):",
  `Uploaded source: ${reference.uploadedSource}. Cited document: ${reference.citedDocument}. ${reference.verification}`,
  reference.text,
  "How to apply this reference:",
  "The generic TIPS example and $200 example are not findings about this customer. Never claim to have inspected their actual earning type, tax settings, W-2 mappings or pay statement. Distribution answers establish business practice, not the actual earning setup or a verified catalog match.",
  "Explain the Cash Tips, Charge Tips and Indirect Tips handling only as described in the supplied reference, not as independently verified tax advice. Attribute the year-specific 2026 W-2 claim to this reference; do not invent boxes, mappings, thresholds or tax advice. The source's 'we have verified' is the source author's statement, not ours.",
  "Distinguish amounts still owed through payroll from tips people already received. A pool/split or mixed method alone does not establish who distributes money or whether it is paid in paychecks. The current TIPS question-generation prompt also asks the relevant collection/source question when that fact is missing. Neither the source nor net-pay path alone establishes a verified Roll-Up Type.",
  "Use supplied customer facts, earlier answers and the whole conversation before asking one targeted missing payment fact. Never re-ask a known fact or run the checklist as customer questions. A payroll choice can need clarification about whether any amount was already received, but sufficient evidence that all these tips remain payable in paychecks needs no follow-up.",
  TIPS_PAYMENT_EXPLANATION,
  "Keep existing Something else handling. There is no follow-up question-count limit. Ask only material missing facts, and summarize actual uncertainty for the setup team's review rather than inventing a setup or ending discovery because of the number of answers. Generated explanations follow the voice rules, not the source's original wording.",
].join("\n");
