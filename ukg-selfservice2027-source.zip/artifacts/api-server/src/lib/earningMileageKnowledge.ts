import reference from "../../../../docs/earning-prompts/knowledge/mileage-v1.json" with { type: "json" };
import suppliedPrompt from "../../../../docs/earning-prompts/sources/mileage-question-builder.txt";
import { MILEAGE_CHOICES, MILEAGE_OPENING, MILEAGE_PREFIX } from "@workspace/setup-shared/mileage-policy";
import { composePrompt } from "./earningPromptGeneral";
import { MILEAGE_DISCOVERY_POLICY } from "./earningMileagePolicy";

/** Supplied, attributed product descriptions; the cited PDF has NOT been independently inspected. */
export const MILEAGE_KNOWLEDGE = reference;
const sources = new Set(reference.source_documents.map(s => s.id));
if ([...reference.roll_up_types, ...reference.product_dependencies].some(r => !sources.has(r.source))
  || reference.decision_rules.some(r => r.candidate && !reference.roll_up_types.some(t => t.name === r.candidate))
  || reference.initial_question.prefix !== MILEAGE_PREFIX || reference.initial_question.question !== MILEAGE_OPENING
  || MILEAGE_CHOICES.some(o => reference.initial_question.options[o.id] !== o.label)
  || ![MILEAGE_PREFIX, MILEAGE_OPENING, ...MILEAGE_CHOICES.map(o => o.label)].every(t => suppliedPrompt.includes(t))) {
  throw new Error("MILEAGE references disagree or contain an unknown source/candidate");
}

/** Only product descriptions enter runtime; superseded source discovery prerequisites do not. */
export const MILEAGE_PRODUCT_REFERENCE = JSON.stringify({
  roll_up_types: reference.roll_up_types, source_documents: reference.source_documents,
  known_gaps: reference.known_gaps,
});
export const MILEAGE_INSTRUCTIONS = composePrompt("Generate one grounded US MILEAGE review using the response schema.", [
  MILEAGE_DISCOVERY_POLICY,
  `Attributed product reference: ${MILEAGE_PRODUCT_REFERENCE}`,
  "Use clarify for a missing answerable selection fact, captured when selection facts suffice, pending for named customer uncertainty. No question-count limit and no stopping merely for absent tenant verification. Only clarify has question, answerFormat, nextTopic and nextComponent; otherwise all four are null. outstandingQuestions contains only remaining business distinctions, never routine implementation checks.",
  "Ask one short question for one topic/component. Explain the missing fact and business consequence in reason, without internal candidate names. answerFormat is choices with 2–4 distinct options each <=80 characters (include I'm not sure when useful; the app adds Something else), or text with options null.",
  "customerSummary is null for clarify. For captured/pending write two to four short sentences, normally about 55 words, describing all confirmed purposes and calculations from ACTIVE answers. Preserve supplied amounts, rates, units, frequency and reporting accurately. Distinguish mixed payments. Material unknowns appear in a separate final paragraph as uncertainty. Never import historical-only details or question examples. Tax statements describe intent only.",
  // copy-exception(banned,review): Developer-only instructions identify prohibited wording (guide A.6).
  "No must, should or need to in customerSummary even when attributing intent: say 'You intend to treat this payment as a reimbursement'. No approval, tax eligibility, saving/collection/completion filler, payroll changes, internal candidates/rationale, or new questions in summaries. Questions, choices, reason and outstandingQuestions use plain language: provide business trip details, not submit records. No technical mapping, source IDs, markdown or verification claims in customer-facing fields. Output schema fields only.",
]);
