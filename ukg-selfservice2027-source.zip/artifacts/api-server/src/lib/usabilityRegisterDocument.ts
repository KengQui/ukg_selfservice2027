import type { RegisterEvidence, RegisterReport } from '@workspace/api-zod';
import type { DocumentContent } from './registerDocument';

/**
 * The authored usability layout has separate code, payment, and reconciliation sections.
 * Preserve descriptions as evidence without treating list entries or summary totals as payments.
 * Recognition is structural, never based on the file name or a classification answer.
 */
export function readUsabilityTables(document: DocumentContent): RegisterEvidence | null {
  if (!document.tables?.length) return null;
  const reports: RegisterReport[] = [];
  for (const table of document.tables) {
    // XLSX pads short rows to the sheet's width; CSV does not.
    const rows = table.rows.map(row => {
      const cells = [...row];
      while (cells.length && cells.at(-1) === '') cells.pop();
      return cells;
    });
    const isList = rows[0]?.[0] === 'Earning code list';
    const isPayments = rows[0]?.[0] === 'Earnings/payment detail';
    if (!isList && !isPayments) return null;
    if (!rows[0][1] || !rows[0][2] || rows[1]?.[0] !== 'Company size' || rows[1][1] !== '80') return null;
    const report = (periodStart: string | null, periodEnd: string | null, periodLabel: string | null, suffix: string): RegisterReport => ({
      company: rows[0][1], companyId: rows[0][2], periodStart, periodEnd, periodLabel,
      reportId: `${table.name}:${suffix}`, currency: 'USD', rows: [],
    });
    const equal = (actual: string[] | undefined, expected: string[]) => JSON.stringify(actual) === JSON.stringify(expected);
    if (isList) {
      if (!equal(rows[3], ['Code', 'Description', 'Source section']) || rows.length !== 14) return null;
      const list = report(null, null, 'Current and historical code list', 'codes');
      for (let i = 4; i < rows.length; i++) {
        const [code, description, section] = rows[i];
        if (!code || !description || section !== 'Earnings') return null;
        list.rows.push({ code, description, section: 'earnings', amount: null, amountLabel: null, people: null,
          employeeName: null, employeeId: null, locator: `${table.name}, row ${i + 1}`, quote: rows[i].join(' | ') });
      }
      reports.push(list);
      continue;
    }
    if (!equal(rows[4], ['Pay period', 'Period start', 'Period end', 'Pay date'])
      || rows[7]?.[0] !== 'Employee payment detail'
      || !equal(rows[8], ['Pay period', 'Employee ID', 'Department', 'Code', 'Description', 'Source section', 'Hours', 'Hourly rate (USD)', 'Business miles', 'Company mileage rate (USD)', 'Amount (USD)'])) return null;
    const periods = new Map<string, RegisterReport>();
    for (const [id, start, end] of rows.slice(5, 7)) {
      if (!id || !/^\d{4}-\d{2}-\d{2}$/.test(start) || !/^\d{4}-\d{2}-\d{2}$/.test(end) || start > end || periods.has(id)) return null;
      periods.set(id, report(start, end, id, id));
    }
    const summaryIndex = rows.findIndex(row => row[0] === 'Period summary — distinct people by code; do not add counts across codes');
    if (summaryIndex < 10) return null;
    const number = (value: string) => /^-?\d+(\.\d+)?$/.test(value) && Number.isFinite(Number(value)) ? Number(value) : NaN;
    for (let i = 9; i < summaryIndex; i++) {
      const [period, employeeId, department, code, description, section, hours, rate, miles, mileageRate, amountText] = rows[i];
      const target = periods.get(period);
      const amount = number(amountText);
      if (!target || !employeeId || !department || !code || !description || section !== 'Earnings' || !Number.isFinite(amount)) return null;
      if (hours && Math.round(number(hours) * number(rate) * 100) !== Math.round(amount * 100)) return null;
      if (miles && Math.round(number(miles) * number(mileageRate) * 100) !== Math.round(amount * 100)) return null;
      target.rows.push({ code, description, section: 'earnings', amount, amountLabel: 'Period payment (USD)', people: null,
        employeeId, employeeName: null, locator: `${table.name}, row ${i + 1}`,
        quote: [code, description, department, 'Earnings', hours && `${hours} hours at USD ${rate}`, miles && `${miles} business miles at USD ${mileageRate}`, `Amount: ${amountText}`].filter(Boolean).join(' | ') });
    }
    if (!equal(rows[summaryIndex + 1], ['Pay period', 'Code', 'Distinct people', 'Amount (USD)'])) return null;
    const summaries = rows.slice(summaryIndex + 2);
    for (const [period, target] of periods) {
      if (new Set(target.rows.map(row => row.employeeId)).size !== 80) return null;
      const codes = [...new Set(target.rows.map(row => row.code)), 'Period total'];
      for (const code of codes) {
        const payments = target.rows.filter(row => code === 'Period total' || row.code === code);
        const printed = summaries.filter(row => row[0] === period && row[1] === code);
        if (printed.length !== 1 || number(printed[0][2]) !== new Set(payments.map(row => row.employeeId)).size
          || Math.round(number(printed[0][3]) * 100) !== payments.reduce((sum, row) => sum + Math.round(row.amount! * 100), 0)) return null;
      }
      if (summaries.filter(row => row[0] === period).length !== codes.length) return null;
    }
    if (summaries.some(row => !periods.has(row[0]))) return null;
    reports.push(...periods.values());
  }
  return { reports, warnings: ['Earnings/payment detail only; these files do not include complete tax or net payroll calculations.'] };
}
