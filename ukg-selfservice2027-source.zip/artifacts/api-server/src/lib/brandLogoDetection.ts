export type ModelLogoDetection = {
  selectedIndex: number | null;
  confidence: number;
  reason: string;
};

const CONFIDENCE_THRESHOLD = 0.8;

export function normalizeLogoDetection(
  value: ModelLogoDetection,
  imageCount: number,
): ModelLogoDetection {
  const confidence = Math.max(0, Math.min(1, value.confidence));
  const validIndex =
    Number.isInteger(value.selectedIndex) &&
    value.selectedIndex !== null &&
    value.selectedIndex >= 0 &&
    value.selectedIndex < imageCount;

  if (!validIndex || confidence < CONFIDENCE_THRESHOLD) {
    return {
      selectedIndex: null,
      confidence,
      reason: value.reason,
    };
  }

  return { ...value, confidence };
}