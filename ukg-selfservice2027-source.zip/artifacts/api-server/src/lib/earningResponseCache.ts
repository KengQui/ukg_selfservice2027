import { createHash } from "node:crypto";
import type { RequestHandler } from "express";
import { MILEAGE_REVIEW_REVISION } from "@workspace/setup-shared/mileage-policy";

/** Only generated review responses, never payroll mutations, auth or document extraction. */
export const EARNING_CACHE_PATHS = new Set([
  "/earnings/description-checks", "/earnings/custom-name-suggestions",
  "/earnings/answer-reviews", "/earnings/shift-premium-reviews",
  "/earnings/customer-questions", "/earnings/discussion-summary", "/earnings/cell-reviews", "/earnings/tips-reviews", "/earnings/mileage-reviews",
]);

const canonical = (value: unknown): unknown => {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === "object") return Object.fromEntries(
    Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([key, entry]) => [key, canonical(entry)]),
  );
  return value;
};

/**
 * Process-local by design: a deploy/restart clears all results, including results generated under
 * older prompts/validators. Keys contain hashes, not raw answers or company/document identifiers.
 * Scope is an opaque per-tab/company value, additionally partitioned by authenticated user.
 */
export function createEarningResponseCache({
  ttlMs = 30 * 60_000, maxEntries = 200, maxBytes = 4 * 1024 * 1024,
  version = "earning-responses-v1", now = Date.now,
} = {}): RequestHandler {
  const cache = new Map<string, { json: string; until: number; bytes: number }>();
  const pending = new Map<string, Promise<string | undefined>>();
  let bytes = 0;
  const remove = (key: string) => {
    const old = cache.get(key);
    if (old) bytes -= old.bytes;
    cache.delete(key);
  };
  return async (req, res, next): Promise<void> => {
    if (req.method !== "POST" || !EARNING_CACHE_PATHS.has(req.path)) { next(); return; }
    // Never let an intermediary HTTP cache retain these private responses.
    res.setHeader("Cache-Control", "no-store");
    const scope = req.get("X-Earning-Cache-Scope");
    if (!scope || !/^[a-f0-9]{64}$/.test(scope)) { next(); return; }
    const input = JSON.stringify(canonical(req.body));
    if (!input || input.length > 64_000) { next(); return; }
    const key = createHash("sha256").update(JSON.stringify([
      version, req.path === "/earnings/mileage-reviews" ? MILEAGE_REVIEW_REVISION : null,
      req.user?.id ?? "anonymous", scope, req.path, input,
    ])).digest("hex");
    for (const [oldKey, entry] of cache) if (entry.until <= now()) remove(oldKey);
    const hit = cache.get(key);
    if (hit) {
      cache.delete(key); cache.set(key, hit);
      res.setHeader("X-Earning-Cache", "hit");
      res.json(JSON.parse(hit.json)); return;
    }
    const active = pending.get(key);
    if (active) {
      const json = await active;
      if (res.destroyed) return;
      if (json) {
        res.setHeader("X-Earning-Cache", "coalesced");
        res.json(JSON.parse(json)); return;
      }
      // A failed/aborted request does not become another caller's cached failure.
    }
    if (pending.size >= maxEntries) { next(); return; }
    let resolve!: (json: string | undefined) => void;
    const promise = new Promise<string | undefined>(done => { resolve = done; });
    pending.set(key, promise);
    let finished = false;
    const finish = (json?: string) => {
      if (finished) return;
      finished = true;
      if (pending.get(key) === promise) pending.delete(key);
      resolve(json);
    };
    res.once("close", () => finish());
    const sendJson = res.json.bind(res);
    res.setHeader("X-Earning-Cache", "miss");
    res.json = (body: unknown) => {
      let json: string | undefined;
      if (!finished && !res.destroyed && res.statusCode === 200 && body !== null && typeof body === "object" && !("error" in body)) {
        const serialized = JSON.stringify(body);
        const size = Buffer.byteLength(serialized);
        if (size <= 64_000 && size <= maxBytes) {
          json = serialized;
          remove(key);
          cache.set(key, { json, bytes: size, until: now() + ttlMs }); bytes += size;
          while (cache.size > maxEntries || bytes > maxBytes) remove(cache.keys().next().value!);
        }
      }
      finish(json);
      return sendJson(body);
    };
    next();
  };
}
