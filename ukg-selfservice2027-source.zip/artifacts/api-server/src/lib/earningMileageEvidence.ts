import type { MileageReviewInput } from "@workspace/api-zod";
import { MILEAGE_SCHEMA, validateMileageReview } from "./earningMileageReview";
import { MILEAGE_DISCOVERY_POLICY } from "./earningMileagePolicy";
import { MILEAGE_PRODUCT_REFERENCE } from "./earningMileageKnowledge";
import { composePrompt } from "./earningPromptGeneral";

/**
 * Independent semantic reading of the active conversation, not a ledger supplied by a client
 * or inherited from a previous model response. The route runs this before accepting a proposal.
 */
export const MILEAGE_EVIDENCE_SCHEMA = {
  type: "object", additionalProperties: false,
  required: ["components", "questionTopic", "questionComponent", "questionStatus", "impact", "summaryGrounded"],
  properties: {
    components: MILEAGE_SCHEMA.properties.components,
    summaryGrounded: { type: "boolean" },
    questionTopic: MILEAGE_SCHEMA.properties.nextTopic,
    questionComponent: MILEAGE_SCHEMA.properties.nextComponent,
    questionStatus: { type: "string", enum: ["missing-material", "already-answered", "internal-safeguard", "none"] },
    impact: { type: "string", minLength: 1, maxLength: 500 },
  },
};

export const MILEAGE_EVIDENCE_INSTRUCTIONS = composePrompt("Independently audit a US MILEAGE proposal. Return only the evidence schema, not a generated review.", [
  MILEAGE_DISCOVERY_POLICY,
  `Attributed product reference: ${MILEAGE_PRODUCT_REFERENCE}`,
  "Independently audit customerSummary against the COMPLETE ACTIVE answers, not the proposal's fact list. summaryGrounded is true only if clarify has null summary, or the terminal summary accurately states every confirmed purpose and calculation and retains distinct mixed components. Check amounts, rates, units, frequency and mileage reporting in context, including all supplied material details; number presence alone is not enough. Reject invented details, historical-only facts, superseded facts, purpose inferred from flat calculation, omitted known purpose/calculation, generic collection filler, tax eligibility/approval, payroll changes or saving claims. Tax statements must be attributed intent. Material unknown business facts must appear separately as uncertainty, never new questions or compliance requirements. Reject internal candidate names/rationale. If false, explain the specific correction in impact; never rewrite the summary or manufacture completion.",
  "Independently extract components and every supported fact from EVERY active answer before inspecting the proposal. Do not inherit its omissions, classifications or quotes. Apply the shared discovery policy to your own extraction; scope all facts independently, including multi-fact answers, short contextual choices and corrections. Compare the proposal with that evidence, not with earlier model memory.",
  "Then identify what the proposed question ACTUALLY asks, irrespective of nextTopic/nextComponent labels. Map paraphrases to their real topic and component. 'Are these work trips in personal cars?' is purpose; 'Do you multiply business miles by a rate?' is calculation; 'Should it be outside taxable wages?' is treatment, even if labeled qualification, example or mileageDetails.",
  "questionStatus is already-answered if the answer is in any active answer, including volunteered multi-fact text, or the same uncertainty has already been answered. A genuinely new contradiction can receive one targeted clarification; after an uncertain clarification retain named pending work. Distinct components are not duplicates.",
  "missing-material requires a genuinely unresolved distinction whose answer could change the conditional candidate. impact must identify that missing fact and explain the different candidate outcomes INTERNALLY. Do not authorize extra questions merely because they are relevant to payroll or useful before implementation.",
  "Classify routine compliance or implementation questions as internal-safeguard using the shared minimum-discovery policy. Independent review is mandatory even for a plausible proposal: do not approve unsupported intent or manufacture successful completion.",
  "For no question use questionTopic/questionComponent null and questionStatus none. Return the evidence schema only. Do not rewrite the question or manufacture successful completion.",
]);

export function validateMileageEvidence(raw: unknown, proposal: unknown, input: MileageReviewInput) {
  const fail = (correction: string) => ({ ok: false as const, correction });
  if (!raw || typeof raw !== "object") return fail("Return a grounded conversation evidence check.");
  const audit = raw as Record<string, unknown>;
  if (Object.keys(audit).sort().join() !== Object.keys(MILEAGE_EVIDENCE_SCHEMA.properties).sort().join()
    || typeof audit.impact !== "string" || !audit.impact.trim() || audit.impact.length > 500
    || !["missing-material", "already-answered", "internal-safeguard", "none"].includes(String(audit.questionStatus)))
    return fail("Use the evidence-check schema exactly.");
  const r = proposal as Record<string, unknown>;
  if (audit.summaryGrounded !== true)
    return fail(`Customer summary is not grounded in the active answers. ${audit.impact} Return a corrected summary with the complete review.`);
  if (r.next === "clarify" && audit.questionStatus !== "missing-material")
    return fail(`Do not repeat this question or extend internal safeguards. ${audit.impact} Use next pending with the named uncertainty when the customer already said they are unsure, or ask a different genuinely missing fact. Never manufacture captured completion.`);
  // Reuse all attribution, scope, treatment, minimum-discovery and duplication checks on the
  // independently extracted evidence AND the actual semantic target of the question.
  const grounded = validateMileageReview({ ...r, components: audit.components,
    nextTopic: audit.questionTopic, nextComponent: audit.questionComponent }, input);
  if (!grounded.ok) return fail(`Full conversation evidence: ${grounded.correction} Evidence: ${JSON.stringify(audit.components)}`);
  if (r.next === "clarify" && (audit.questionStatus !== "missing-material"
    || audit.questionTopic !== r.nextTopic || audit.questionComponent !== r.nextComponent))
    return fail(`The question repeats known facts, extends internal safeguards, or is relabeled. ${audit.impact} Ask only a genuinely missing recommendation-changing distinction, or capture/retain named pending work.`);
  if (r.next !== "clarify" && audit.questionStatus !== "none") return fail("Only a clarification has a question target.");
  const original = validateMileageReview(proposal, input);
  if (!original.ok) return original;
  const actual = original.value.mileage!.components;
  const evidence = grounded.value.mileage!.components;
  const sameEvidence = (a: { topic: string; answerId: string; quote: string }, b: typeof a) =>
    a.topic === b.topic && a.answerId === b.answerId && (a.quote.includes(b.quote) || b.quote.includes(a.quote));
  if (actual.length !== evidence.length || evidence.some(c => {
    const supplied = actual.find(s => s.id === c.id);
    return !supplied || ["treatment", "presentation", "specialReporting"].some(k =>
      supplied[k as keyof typeof supplied] !== c[k as keyof typeof c])
      || c.facts.some(f => !supplied.facts.some(s => sameEvidence(s, f)))
      || supplied.facts.some(f => !c.facts.some(s => sameEvidence(s, f)));
  })) return fail(`Retain every current grounded fact, with independent component scope; remove superseded facts. Evidence: ${JSON.stringify(audit.components)}`);
  return original;
}
