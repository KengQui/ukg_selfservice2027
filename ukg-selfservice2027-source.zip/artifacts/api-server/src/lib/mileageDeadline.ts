/** Race explicitly: an SDK/transport that ignores abort must not hold the route open. */
export async function mileageStage<T>(
  parent: AbortSignal, allowanceMs: number, work: (signal: AbortSignal) => PromiseLike<T>,
): Promise<T> {
  const controller = new AbortController();
  let rejectAbort: (reason: Error) => void = () => {};
  const stopped = new Promise<never>((_, reject) => { rejectAbort = reject; });
  const abort = () => {
    controller.abort();
    const error = new Error("Mileage deadline or cancellation");
    error.name = "MileageDeadlineError";
    rejectAbort(error);
  };
  const timer = setTimeout(abort, allowanceMs);
  parent.addEventListener("abort", abort, { once: true });
  try {
    if (parent.aborted || allowanceMs <= 0) { abort(); return await stopped; }
    return await Promise.race([work(controller.signal), stopped]);
  } finally {
    clearTimeout(timer);
    parent.removeEventListener("abort", abort);
  }
}
