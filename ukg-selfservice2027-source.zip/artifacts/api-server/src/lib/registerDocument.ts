import { parse } from 'csv-parse/sync';
import ExcelJS from 'exceljs';
import yauzl from 'yauzl';
import { createCanvas } from '@napi-rs/canvas';
import { GetRegisterUploadResponse, type RegisterEvidence, type RegisterReport } from '@workspace/api-zod';
import { readUsabilityTables } from './usabilityRegisterDocument';

export const MAX_REGISTER_BYTES = 10 * 1024 * 1024;
const MAX_TEXT = 100_000;
const MAX_ROWS = 2500;
export class RegisterReadError extends Error {}
export interface DocumentContent { text: string; images: string[]; tables?: Table[] }
interface Table { name: string; rows: string[][] }
const text = (v: unknown) => v == null ? '' : String(v).trim();
const normalized = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');

/** Bound declared and actual expanded ZIP sizes before ExcelJS reads an XLSX. */
async function checkWorkbookSize(bytes: Buffer) {
  await new Promise<void>((resolve, reject) => {
    yauzl.fromBuffer(bytes, { lazyEntries: true }, (error, zip) => {
      if (error || !zip) { reject(new RegisterReadError('This Excel file couldn’t be opened. Save a new XLSX copy and try again.')); return; }
      let total = 0;
      let expanded = 0;
      let entries = 0;
      zip.on('error', reject);
      zip.on('end', resolve);
      zip.on('entry', entry => {
        total += entry.uncompressedSize;
        entries++;
        if (total > 30 * 1024 * 1024 || entries > 2000) {
          zip.close();
          reject(new RegisterReadError('This workbook is too large to read safely. Export a smaller register and try again.'));
        } else if (entry.fileName.endsWith('/')) zip.readEntry();
        else zip.openReadStream(entry, (streamError, stream) => {
          if (streamError || !stream) { zip.close(); reject(streamError); return; }
          stream.on('error', failure => { zip.close(); reject(failure); });
          stream.on('data', chunk => {
            expanded += chunk.length;
            if (expanded > 30 * 1024 * 1024) {
              stream.destroy(); zip.close();
              reject(new RegisterReadError('This workbook expands beyond the reading limit. Export a smaller register and try again.'));
            }
          });
          stream.on('end', () => zip.readEntry());
        });
      });
      zip.readEntry();
    });
  });
}

export async function readDocument(bytes: Buffer, name: string): Promise<DocumentContent> {
  const extension = name.split('.').at(-1)?.toLowerCase();
  if (!bytes.length || bytes.length > MAX_REGISTER_BYTES) throw new RegisterReadError('Choose a file between 1 byte and 10 MB.');
  if (extension === 'csv' || extension === 'xlsx') {
    const tables: Table[] = [];
    if (extension === 'csv') {
      const content = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
      if (content.includes('\0')) throw new RegisterReadError('Save this file as a UTF-8 CSV and try again.');
      const rows = parse(content, { bom: true, skip_empty_lines: true, relax_column_count: true, max_record_size: 20000 }) as string[][];
      tables.push({ name: 'CSV', rows });
    } else {
      await checkWorkbookSize(bytes);
      const workbook = new ExcelJS.Workbook();
      await workbook.xlsx.load(bytes as unknown as Parameters<typeof workbook.xlsx.load>[0]);
      for (const sheet of workbook.worksheets) {
        if (sheet.rowCount > MAX_ROWS || sheet.columnCount > 100) throw new RegisterReadError('This sheet has too many rows or columns. Export a smaller register and try again.');
        const rows: string[][] = [];
        sheet.eachRow({ includeEmpty: true }, row => {
          const cells: string[] = [];
          for (let col = 1; col <= sheet.columnCount; col++) {
            const cell = row.getCell(col);
            const value = cell.value;
            if (value instanceof Date) cells.push(value.toISOString().slice(0, 10));
            else if (value && typeof value === 'object' && 'formula' in value) {
              if (value.result === undefined) throw new RegisterReadError('A formula has no saved value. Recalculate and save the workbook, then try again.');
              cells.push(text(value.result));
            } else cells.push(cell.text);
          }
          rows.push(cells);
        });
        if (rows.some(row => row.some(Boolean))) tables.push({ name: sheet.name, rows });
      }
    }
    if (!tables.length || tables.reduce((n, table) => n + table.rows.length, 0) > MAX_ROWS)
      throw new RegisterReadError('Choose a register with 1 to 2,500 rows.');
    const content = tables.map(table => table.rows.map((row, index) => `${table.name} row ${index + 1}: ${row.join(' | ')}`).join('\n')).join('\n\n');
    if (content.length > MAX_TEXT) throw new RegisterReadError('This register has too much text to read at once. Export a smaller report and try again.');
    return { text: content, images: [], tables };
  }
  if (extension !== 'pdf' || !bytes.subarray(0, 5).equals(Buffer.from('%PDF-')))
    throw new RegisterReadError('This file doesn’t match its format. Save a PDF, CSV or XLSX copy and try again.');
  const { getDocument } = await import('pdfjs-dist/legacy/build/pdf.mjs');
  const pdf = await getDocument({ data: new Uint8Array(bytes), useSystemFonts: true }).promise;
  try {
    if (pdf.numPages > 20) throw new RegisterReadError('Choose a PDF with no more than 20 pages. Split longer reports before uploading.');
    const pages: string[] = [];
    const images: string[] = [];
    for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber++) {
      const page = await pdf.getPage(pageNumber);
      const content = await page.getTextContent();
      const lines = content.items.map(item => 'str' in item ? item.str + (item.hasEOL ? '\n' : ' ') : '').join('');
      pages.push(`Page ${pageNumber}:\n${lines}`);
      // Scanned or almost-empty pages need actual vision, not a fabricated text result.
      if (lines.trim().length < 80) {
        const natural = page.getViewport({ scale: 1 });
        const viewport = page.getViewport({ scale: Math.min(2, 1600 / Math.max(natural.width, natural.height)) });
        const canvas = createCanvas(Math.ceil(viewport.width), Math.ceil(viewport.height));
        await page.render({ canvas: canvas as never, canvasContext: canvas.getContext('2d') as never, viewport }).promise;
        images.push(`data:image/png;base64,${canvas.toBuffer('image/png').toString('base64')}`);
        pages.push(`Page ${pageNumber} is also supplied as image ${images.length}.`);
      }
      page.cleanup();
    }
    const content = pages.join('\n\n');
    if (content.length > MAX_TEXT) throw new RegisterReadError('This PDF has too much text to read at once. Split it into smaller reports and try again.');
    return { text: content, images };
  } finally { await pdf.destroy(); }
}

const aliases = {
  code: ['code', 'paycode', 'earningcode', 'deductioncode'],
  description: ['description', 'codedescription', 'earningdescription'],
  company: ['company', 'companyname', 'employer'],
  companyId: ['companyid', 'employerid', 'ein'],
  periodStart: ['periodstart', 'payperiodstart', 'startdate'],
  periodEnd: ['periodend', 'payperiodend', 'enddate'],
  periodLabel: ['period', 'periodcovered', 'payperiod'],
  reportId: ['reportid', 'payrollid', 'runid'],
  section: ['section', 'type', 'category'],
  amount: ['amount', 'totalamount', 'paymentamount', 'expenseamount', 'currentamount', 'currentperiodamount',
    'currentpay', 'currentearnings', 'payamount', 'earningamount', 'deductionamount'],
  people: ['people', 'employees', 'headcount'],
  employeeName: ['employeename', 'workername'],
  employeeId: ['employeeid', 'employeenumber', 'workerid', 'empid'],
  currency: ['currency'],
} as const;

function numberOrNull(value: string | null, integer = false) {
  if (!value || /^(n\/a|not shown|-)$/i.test(value)) return null;
  const raw = value.replace(/[$,\s]/g, '').replace(/^\((.*)\)$/, '-$1');
  if (!/^-?\d+(\.\d+)?$/.test(raw) || !Number.isFinite(Number(raw)) || (integer && (!Number.isInteger(Number(raw)) || Number(raw) < 0)))
    throw new RegisterReadError('A numeric value couldn’t be read. Use numbers in the Amount and People columns, then try again.');
  return Number(raw);
}

/** Exact header-based extraction: preserves each source row; never sums detail rows and totals. */
export function readStructuredTables(document: DocumentContent): RegisterEvidence | null {
  const usability = readUsabilityTables(document);
  if (usability) return validateEvidence(usability);
  if (!document.tables) return null;
  const reports = new Map<string, RegisterReport>();
  for (const table of document.tables) {
    const headerIndex = table.rows.findIndex(row => aliases.code.some(alias => row.map(normalized).includes(alias)));
    if (headerIndex < 0) return null; // Unfamiliar layout goes to the grounded document reader.
    // A report title/preamble can carry its company or period. Don't discard it.
    if (table.rows.slice(0, headerIndex).some(row => row.some(cell => cell.trim()))) return null;
    const header = table.rows[headerIndex].map(normalized);
    const knownHeaders = new Set<string>(Object.values(aliases).flat());
    // Extra populated columns may contain amounts, YTD, units, or company/period context.
    // A partial header match must not silently discard them and claim a complete read.
    const width = Math.max(header.length, ...table.rows.map(row => row.length));
    for (let column = 0; column < width; column++) {
      if (!knownHeaders.has(header[column]) && table.rows.slice(headerIndex + 1).some(row => text(row[column]))) return null;
    }
    const amountColumns = header.flatMap((name, index) => (aliases.amount as readonly string[]).includes(name) ? [index] : []);
    const columns = Object.fromEntries(Object.entries(aliases).map(([key, names]) => [key, header.findIndex(h => (names as readonly string[]).includes(h))]));
    for (let index = headerIndex + 1; index < table.rows.length; index++) {
      const cells = table.rows[index];
      if (cells.every(cell => !cell.trim())) continue;
      const get = (key: keyof typeof aliases) => text(cells[columns[key]]) || null;
      const code = get('code');
      if (!code) return null; // Group headings need document-level interpretation, not a guessed carry-forward.
      if (normalized(code) === 'total' || normalized(code) === 'grandtotal') continue;
      if (aliases.code.includes(normalized(code) as 'code')) continue;
      const metadata = { company: get('company'), companyId: get('companyId'), periodStart: get('periodStart'), periodEnd: get('periodEnd'), periodLabel: get('periodLabel'), reportId: get('reportId'), currency: get('currency') };
      for (const date of [metadata.periodStart, metadata.periodEnd]) if (date && (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(Date.parse(date))))
        throw new RegisterReadError('Use YYYY-MM-DD dates in Period start and Period end, then try again.');
      if (metadata.periodStart && metadata.periodEnd && metadata.periodStart > metadata.periodEnd)
        throw new RegisterReadError('The period ends before it starts. Check the dates and upload a corrected copy.');
      const key = JSON.stringify([table.name, metadata]);
      const report = reports.get(key) ?? { ...metadata, rows: [] };
      const sectionText = normalized(get('section') ?? '');
      const section = /^(earnings?|payments?)$/.test(sectionText) ? 'earnings' : /^deductions?$/.test(sectionText) ? 'deductions' : /^(employer|employercontributions?|expenses?)$/.test(sectionText) ? 'employer' : 'unknown';
      for (const amountColumn of amountColumns.length ? amountColumns : [-1]) {
        const amountText = amountColumn >= 0 ? text(cells[amountColumn]) || null : null;
        const amountLabel = amountColumn >= 0 ? table.rows[headerIndex][amountColumn] : null;
        report.rows.push({ code, description: get('description'), section, amount: numberOrNull(amountText), amountLabel,
          people: numberOrNull(get('people'), true), locator: `${table.name}, row ${index + 1}`,
          employeeName: get('employeeName'), employeeId: get('employeeId'),
          // Keep employee identity in dedicated fields, not the evidence excerpt.
          quote: [code, get('description'), get('section'), amountLabel && `${amountLabel}: ${amountText ?? 'Not shown'}`, get('people')].filter(v => v !== null).join(' | ') });
      }
      reports.set(key, report);
    }
  }
  return validateEvidence({ reports: [...reports.values()], warnings: [] });
}

export function validateEvidence(value: unknown): RegisterEvidence {
  const parsed = GetRegisterUploadResponse.shape.evidence.unwrap().safeParse(value);
  if (!parsed.success) throw new RegisterReadError('The register details weren’t clear enough to read. Try a clearer PDF or a CSV or XLSX export.');
  return parsed.data;
}
