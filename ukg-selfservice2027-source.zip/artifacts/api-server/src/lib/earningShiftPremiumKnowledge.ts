/**
 * The user's UKG Ready Shift Premium knowledge, copied verbatim for the shift premium relationship step's AI
 * instructions only. Demo-only: it never goes into the prompt docs or the design-handoff export.
 */
export const SHIFT_PREMIUM_KNOWLEDGE = `UKG Ready — Shift Premium / Shift Differential

A shift premium (also called a shift differential) is additional compensation associated with working a qualifying shift or meeting defined shift-related conditions.

Core Concept

Do not assume that every source payroll code representing shift-related premium pay requires a separate UKG Ready shift premium code.

Multiple legacy/source payroll codes may represent the same underlying shift-premium concept. UKG Ready can use configuration and calculation rules to determine when a shift premium applies.

For migration and code-mapping decisions, separate these two concepts:

1. What is being paid?
   The shift premium or shift differential.
2. What determines when it applies?
   The qualifying conditions, which may include shift assignment, cost center, work assignment, or other documented Pay Calculation criteria.

Cost centers may therefore be used as criteria within shift-premium calculation logic when the premium depends on where the employee worked. The cost center is not itself the shift premium; it is a possible condition used to determine whether the premium applies.

Consolidation Principle

Prefer a single shift-premium structure when multiple source codes represent the same underlying premium and their differences can be handled through UKG Ready configuration.

This is conceptually similar to overtime: different employees, departments, or cost centers may generate overtime, but that does not necessarily require a unique overtime earning code for every department or work location.

Do not create separate shift-premium codes solely because the source system has separate payroll codes.

When Source Codes May Be Combined

Two source codes may be candidates for consolidation when they represent the same shift-premium concept and their differences can be represented through Ready configuration.

Before recommending consolidation, determine whether differences involve:

- qualifying shift
- premium rate
- calculation method
- eligibility rules
- cost center or work assignment
- effective dates
- payroll/reporting requirements
- other documented calculation conditions

If the codes have the same intended premium treatment and differ only because of department, location, cost center, or another condition that Ready can evaluate through configuration, prefer one shift-premium structure rather than duplicating the earning unnecessarily.

When Codes Should Remain Separate

Do not automatically consolidate source codes when they have materially different business purposes or calculation requirements.

Keep the distinction when separate treatment is required and cannot appropriately be represented through the documented Ready configuration.

Examples may include different premium rates, different calculation methods, different eligibility requirements, or materially different payroll/reporting treatment.

Example

Source system:

SHIFT2 = shift differential for employees working in Department A
Special Pay = shift differential for employees working in Department B

If both represent the same premium rate and rules, and Department A versus Department B can be identified using cost-center/rule criteria, they may be candidates for one Ready shift-premium structure.

Conceptually:

Department A qualifying hours ──┐
├──> Shift Premium
Department B qualifying hours ──┘

Do not create separate Ready shift-premium codes merely because the legacy system uses SHIFT2 and Special Pay.

However, if:

SHIFT2 = $1.00/hour premium under one set of rules
Special Pay = $2.00/hour premium under different rules

do not assume they should be combined. Determine whether Ready configuration can appropriately represent those differences before deciding.

LLM Decision Rule

When analyzing a source payroll code described as extra pay for working a shift:

1. Classify it as a candidate for Shift Premium / Shift Differential.
2. Identify any existing source codes already mapped to Shift Premium.
3. Ask whether the new code represents the same underlying premium.
4. Compare the premium rate, calculation method, eligibility/qualification rules, cost-center/work-assignment conditions, effective dates, and required payroll/reporting treatment.
5. Determine whether differences can be represented through documented UKG Ready configuration.
6. Recommend consolidation only when the underlying business purpose is equivalent and Ready configuration can preserve the required distinctions.
7. Otherwise, keep separate treatment.
8. If there is insufficient information to establish equivalence, select Defer rather than assuming the codes should be combined.

Important Guardrails

Do not infer that two codes are equivalent from their names alone.

Do not infer that two codes must remain separate merely because the source system has separate codes.

Do not assume that a cost center is an earning code. Cost centers may be used as conditions for determining which worked time qualifies for a premium.

Do not assume that all shift premiums have identical rates or rules.

Do not recommend consolidation if doing so would lose a required difference in calculation, eligibility, rate, accounting, or reporting.

When information is insufficient to determine whether two source codes can safely share one Ready configuration, ask a targeted follow-up question or select Defer.`;

/**
 * The decision instruction (the operational rule), verbatim. It comes immediately after the knowledge block and says
 * how to apply it when writing follow-up questions.
 */
export const SHIFT_PREMIUM_DECISION_INSTRUCTION = "When a source payroll code is identified as extra pay for working a shift, classify it as a candidate for Shift Premium / Shift Differential. If another source code is already mapped to Shift Premium, do not automatically create a separate Ready code or automatically combine the codes. Determine whether they represent the same underlying premium and whether differences such as shift, cost center, department, location, work assignment, rate, or eligibility can be represented through UKG Ready configuration. Prefer consolidation when the business purpose is equivalent and Ready configuration can preserve the required differences. Keep separate treatment when materially different rules or requirements require it. If there is not enough information to determine this, ask a targeted follow-up question or Defer.";
