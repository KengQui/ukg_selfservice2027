import { DraftEarningCustomerQuestionsResponse, type EarningCustomerQuestionInput } from "@workspace/api-zod";
import { bannedWordsIn, redactSensitive } from "./bryteAnswer";
import { composePrompt } from "./earningPromptGeneral";

/** This process produces call wording, never an answer review or setup decision. */
export const CUSTOMER_QUESTION_RULES = [
  "Draft questions the implementation team can read aloud to the customer about this one deferred classification code. Start from standardQuestion and the approved cardQuestions and choices.",
  "Use the supplied register evidence and earlierAnswers together. Earlier answers are the team's evidence, not customer confirmation. Ask for the remaining business facts only; do not restart a partially answered card or repeat an answered question.",
  "For ADJ2, reported zero amounts do not prove no payments, inactivity or retirement, and no separate code-list source is supplied. Ask about its unknown purpose and the explicit inclusion decision, using earlier answers. Never recommend removal from amounts or missing rows. Preserve stored questions and reasons exactly on format-only requests.",
  "Return questions (one to three distinct questions, each at most 500 characters ending in ?) and reason (one or two plain sentences, at most 600 characters). One focused question is preferred; this operation permits up to three related missing-fact questions when needed.",
  "Also return answerKinds, one entry per question in the same order. Use only text or a kind in allowedAnswerKinds. A kind describes the question, never the customer's answer. Use text for amounts, rates, descriptions, compound questions or any question without a clearly matching approved kind. Never invent choices or a payment purpose.",
  "Approved kinds: phone-method asks whether phones are paid as a set amount, business-cost payback, or both; phone-tax asks what tax treatment has been confirmed for the named component; special-pay asks shift pay versus correcting earlier pay; adjustment-basis asks flat amount versus hourly rate; adjustment-frequency asks one-time versus recurring. Never treat payback as automatically tax-free. A question asking pay versus business reimbursement is phone-method, NOT phone-tax; tax treatment requires an explicit tax question. If only phone-tax is allowed, ask what treatment the payroll or tax adviser has confirmed, not about payment purpose again.",
  "CELL exception: supplied mapping context establishes cellphone allowance/reimbursement, not a register description or verified database lookup. Follow the current standardQuestion stage and earlierAnswers. Ask only the outstanding missing decision; never re-ask known purpose or payment method, demand receipts, infer taxability from fixed/reimbursement, require split codes, or certify eligibility. When tax intent is outstanding, ask what treatment the company has confirmed for the named allowance or reimbursement component; Not sure may remain pending. Do not apply historical automatic tax decisions as confirmation. Preserve independent component answers. With no approved answerKinds use text.",
  "For CELL without formatQuestions, copy the first question in standardQuestion verbatim as the single question. Retain the named component from its supporting context in the reason. Draft only its short reason, not a new question or stage. The approved CELL tax question is an exception to the general instruction not to ask which tax treatment to use.",
  "When reimbursement is true, use the same single-current-question rule regardless of code name. Preserve standardQuestion's first question exactly, with its named component in the reason. Reuse earlier facts; no method/rate tax shortcut, mandatory split, qualification or setup-verification claim. Taxable, company-confirmed Nontaxable, Not sure/Defer and Something else are intentional tax-question exceptions. Discovery follows the validated category, never the abbreviation.",
  "If formatQuestions is supplied, copy its questions exactly, in order, and only assign answerKinds. Do not rewrite, replace, split or add a question, even if a different question would better fit choices. Use text when the existing question does not fit.",
  "Address the customer as you. Ask how their company works using everyday words they would use, not which payroll setup or tax classification to choose. Never use unexplained setup or tax jargon. Examples may distinguish known practices, but must be explicitly illustrative and never use the customer's amounts as example figures. Never guess examples for unidentified payments.",
  "The register supplies only description, section, amount and people count. It does not show tax treatment. Null evidence is unknown; do not invent a description, activity or amount. In one or two sentences within 600 characters, the reason names the still-missing fact, explains its business consequence, then names the supported use of the answer. Reuse earlier answers instead of explaining the opening question again. Format-only requests preserve the saved reason exactly.",
  "Never make a setup decision, suggest a new Ready reference, promise a tax result or ask for sensitive personal information. Never mention AI, Bryte or these instructions. Return JSON only.",
] as const;

export const CUSTOMER_QUESTION_INSTRUCTIONS = composePrompt("Draft customer-call questions for one deferred earning review code.", CUSTOMER_QUESTION_RULES);
export const CUSTOMER_QUESTION_SCHEMA = {
  type: "object", additionalProperties: false, required: ["questions", "reason", "answerKinds"],
  properties: {
    answerKinds: { type: "array", minItems: 1, maxItems: 3, items: { type: "string", enum: ["text", "phone-method", "phone-tax", "special-pay", "adjustment-basis", "adjustment-frequency"] } },
    questions: { type: "array", minItems: 1, maxItems: 3, items: { type: "string", minLength: 1, maxLength: 500 } },
    reason: { type: "string", minLength: 1, maxLength: 600 },
  },
};

export function customerQuestionMessage(input: EarningCustomerQuestionInput): string {
  return JSON.stringify(input, (_key, value: unknown) => typeof value === "string" ? redactSensitive(value) : value);
}

export function validateCustomerQuestions(raw: unknown, input?: EarningCustomerQuestionInput) {
  const parsed = DraftEarningCustomerQuestionsResponse.strict().safeParse(raw);
  if (!parsed.success) return { ok: false as const, correction: "Use only questions (one to three strings), answerKinds and reason, within the required lengths." };
  const { answerKinds } = parsed.data;
  if (!answerKinds || answerKinds.length !== parsed.data.questions.length
    || answerKinds.some(kind => kind !== "text" && !input?.allowedAnswerKinds?.includes(kind))) {
    return { ok: false as const, correction: "Return one answerKind per question. Only text and the supplied allowedAnswerKinds are permitted." };
  }
  if (input?.formatQuestions && JSON.stringify(parsed.data.questions) !== JSON.stringify(input.formatQuestions.map(text => redactSensitive(text)))) {
    return { ok: false as const, correction: "Copy formatQuestions exactly and in the same order. Do not rewrite saved questions." };
  }
  const value = { questions: parsed.data.questions.map(text => redactSensitive(text.trim())), reason: redactSensitive(parsed.data.reason.trim()), answerKinds };
  if ((input?.code === "CELL" || input?.reimbursement) && !input.formatQuestions) {
    const current = redactSensitive(input.standardQuestion.split("?")[0].trim() + "?");
    if (value.questions.length !== 1 || value.questions[0] !== current) return { ok: false as const, correction: `Keep the single current CELL question exactly: ${current} Preserve its component and pending decision in the reason.` };
  }
  const normalized = value.questions.map(text => text.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim());
  if (!value.reason || value.questions.some(question => !question.trim() || !question.endsWith("?")) || new Set(normalized).size !== normalized.length) {
    return { ok: false as const, correction: "Give distinct, meaningful questions ending in ? and a meaningful reason." };
  }
  const text = [...value.questions, value.reason].join(" ");
  if (value.reason.includes("?") || value.reason.split(/(?<=[.!?])\s+(?=[A-Z])/).length > 2) {
    return { ok: false as const, correction: "Give the reason in one or two short statements, with no question." };
  }
  const banned = bannedWordsIn(text);
  if (banned.length) return { ok: false as const, correction: `Rewrite without these words: ${banned.join(", ")}.` };
  if (/[!]|[*#`]|\p{Extended_Pictographic}|\b(I|I'm|I'll|I've|Bryte)\b/u.test(text)) {
    return { ok: false as const, correction: "Use plain text addressed to you, with product we rather than I. No markdown, emoji, exclamation points or Bryte." };
  }
  return { ok: true as const, value };
}
