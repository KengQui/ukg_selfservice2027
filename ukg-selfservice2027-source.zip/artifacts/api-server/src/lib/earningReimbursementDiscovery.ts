/** Routing evidence is separate from user-facing explanation and from setup readiness. */
export const REIMBURSEMENT_DISCOVERY_RULE = [
  "Always return discovery: status sufficient, missing, conflict or unsupported; missingFact null for sufficient, otherwise ONE specific business fact, conflict or unsupported arrangement; answerIds cite exact supplied answers supporting that assessment.",
  "Discovery describes business understanding, NOT tax intent or verified Ready configuration. Unknown company/adviser tax intent or qualification is never a missing business fact and never prevents asking the fixed tax question. Do not ask the customer to confirm eligibility before offering that question.",
  "When business facts suffice, use sufficient and next tax. Missing tax intent is the reason to ask tax, not to stop. Discovery has no question-count limit.",
  "Conflict needs at least two distinct answerIds identifying the incompatible supplied facts or intent. Unsupported needs a specifically identified unsupported arrangement from the supplied evidence, not merely unknown tax intent.",
  "With a material business fact missing and questions remaining, ask one relevant clarification (or an applicable fixed calculation question). Pending is reserved for exhausted unresolved business discovery, explicit uncertainty that cannot be clarified, a conflict or an unsupported arrangement. Sufficient may be pending only for an already answered unresolved tax decision, not an unasked tax question.",
].join("\n");

export const DISCOVERY_SCHEMA = {
  type: "object", additionalProperties: false,
  required: ["status", "missingFact", "answerIds"],
  properties: {
    status: { type: "string", enum: ["sufficient", "missing", "conflict", "unsupported"] },
    missingFact: { type: ["string", "null"], minLength: 1, maxLength: 300 },
    answerIds: { type: "array", minItems: 1, maxItems: 24, items: { type: "string", maxLength: 100 } },
  },
};
