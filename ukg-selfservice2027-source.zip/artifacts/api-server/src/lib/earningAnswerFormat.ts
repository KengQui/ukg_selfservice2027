import type { EarningAnswerFormat } from "@workspace/api-zod";

/**
 * How an AI-written question is answered (the description check's needsInformation question and the shift premium
 * follow-ups): two to four short listed choices, to which the app adds Something else, or a text box.
 */
export const ANSWER_FORMAT_SCHEMA = {
  anyOf: [
    {
      type: "object",
      additionalProperties: false,
      required: ["kind", "options"],
      properties: {
        kind: { type: "string", enum: ["choices", "text"] },
        options: { anyOf: [{ type: "array", items: { type: "string", maxLength: 80 } }, { type: "null" }] },
      },
    },
    { type: "null" },
  ],
} as const;

/** The prompt rule for choosing the format, shared by both processes that write questions. */
export const ANSWER_FORMAT_RULE =
  'With every question, return answerFormat: {"kind": "choices", "options": [...]} with two to four short, distinct options in the customer\'s plain words when the answer is one of a known set (for example "A bonus amount" and "A correction to an earlier overpayment"), or {"kind": "text", "options": null} when the answer is open-ended. Never add a Something else, other, not sure or none option; the app adds Something else. Options must not overlap and must each answer the question on their own. Set answerFormat to null when there is no question.';

export const ANSWER_FORMAT_OPTION_MAX = 80;

const normalized = (text: string) => text.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
const CATCH_ALL = /^(something else|other|others|none|none of (these|the above)|not sure|unsure|i don ?t know|don ?t know)$/;

export type AnswerFormatCheck = { ok: true; value: EarningAnswerFormat } | { ok: false; correction: string };

/** Checks a question's answer format; options come back trimmed. Text and claims inside options are checked by the caller. */
export function validateAnswerFormat(raw: unknown): AnswerFormatCheck {
  if (typeof raw !== "object" || raw === null || Array.isArray(raw)) {
    return { ok: false, correction: 'Return answerFormat with the question: {"kind": "choices", "options": [...]} or {"kind": "text", "options": null}.' };
  }
  const { kind, options, ...rest } = raw as Record<string, unknown>;
  if (Object.keys(rest).length) return { ok: false, correction: "answerFormat has only kind and options." };
  if (kind === "text") {
    return options === null ? { ok: true, value: { kind: "text", options: null } }
      : { ok: false, correction: 'A text answerFormat has options null: {"kind": "text", "options": null}.' };
  }
  if (kind !== "choices") return { ok: false, correction: 'answerFormat kind must be "choices" or "text".' };
  if (!Array.isArray(options) || !options.every(option => typeof option === "string")) {
    return { ok: false, correction: "A choices answerFormat lists its options as text." };
  }
  const clean = (options as string[]).map(option => option.replace(/\s+/g, " ").trim());
  if (clean.length < 2 || clean.length > 4) return { ok: false, correction: "Give two to four options, or use a text answerFormat." };
  if (clean.some(option => !option)) return { ok: false, correction: "Every option needs words; remove empty options." };
  if (clean.some(option => option.length > ANSWER_FORMAT_OPTION_MAX)) {
    return { ok: false, correction: `Keep each option within ${ANSWER_FORMAT_OPTION_MAX} characters.` };
  }
  const catchAll = clean.find(option => CATCH_ALL.test(normalized(option)));
  if (catchAll) return { ok: false, correction: `Remove the option "${catchAll}". The app adds Something else.` };
  if (new Set(clean.map(normalized)).size !== clean.length) return { ok: false, correction: "Make every option different; remove repeated options." };
  return { ok: true, value: { kind: "choices", options: clean } };
}
