import { ReviewCellPaymentResponse, type MileageReviewInput, type MileageAssessment, type MileageComponent, type CellReviewResult } from "@workspace/api-zod";
import { MILEAGE_POLICY, MILEAGE_KNOWLEDGE_VERSION, MILEAGE_PURPOSE_ID, MILEAGE_OPENING, MILEAGE_CHOICES, MILEAGE_CAPTURED } from "@workspace/setup-shared/mileage-policy";
import { MILEAGE_KNOWLEDGE as kb } from "./earningMileageKnowledge";
import { bannedWordsIn, redactSensitive } from "./bryteAnswer";

const topics = ["purpose", "calculation", "mileageDetails", "retention", "reconciliation", "excess", "treatment", "wageHandling", "qualification", "presentation", "reporting", "noncash", "informational", "sharedCode", "example"];
const ids = ["reimbursement", "allowance", "compensation", "informational", "noncash", "unknown"];
const text = { type: "string", minLength: 1, maxLength: 500 };
export const MILEAGE_SCHEMA = {
  type: "object", additionalProperties: false,
  required: ["next", "question", "answerFormat", "reason", "nextTopic", "nextComponent", "components", "outstandingQuestions", "customerSummary"],
  properties: {
    next: { type: "string", enum: ["clarify", "captured", "pending"] },
    customerSummary: { type: ["string", "null"], minLength: 1, maxLength: 1200 },
    question: { type: ["string", "null"], maxLength: 200 },
    answerFormat: { anyOf: [{ type: "null" }, { type: "object", additionalProperties: false, required: ["kind", "options"], properties: {
      kind: { type: "string", enum: ["text", "choices"] },
      options: { anyOf: [{ type: "null" }, { type: "array", minItems: 2, maxItems: 4, items: { type: "string", maxLength: 80 } }] },
    } }] },
    reason: text, nextTopic: { type: ["string", "null"], enum: [...topics, null] },
    nextComponent: { type: ["string", "null"], enum: [...ids, null] },
    outstandingQuestions: { type: "array", maxItems: 20, items: text },
    components: { type: "array", description: "Only actual customer-supported payment purposes, not all enum alternatives. Omit unused types and empty placeholders. One purpose means one component.", minItems: 1, maxItems: 6, items: {
      type: "object", additionalProperties: false,
      required: ["id", "purpose", "treatment", "presentation", "specialReporting", "facts"],
      properties: {
        id: { type: "string", enum: ids }, purpose: text,
        treatment: { type: "string", enum: ["ordinary-taxable", "supplemental-taxable", "claimed-nontaxable", "mixed", "unknown", "no-payroll-effect"] },
        presentation: { type: "string", enum: ["earning", "negative-deduction", "unknown"] },
        specialReporting: { type: "string", enum: ["yes", "no", "unknown"] },
        facts: { type: "array", maxItems: 20, items: { type: "object", additionalProperties: false,
          required: ["topic", "value", "answerId", "quote"], properties: {
            topic: { type: "string", enum: topics }, value: text, answerId: { type: "string", maxLength: 100 }, quote: { ...text, maxLength: 1000 },
          } } },
      },
    } },
  },
};
type Observation = Pick<MileageComponent, "id" | "purpose" | "treatment" | "presentation" | "specialReporting" | "facts">;
type ModelResult = {
  customerSummary: string | null;
  next: "clarify" | "captured" | "pending"; question: string | null;
  answerFormat: CellReviewResult["answerFormat"]; reason: string; nextTopic: string | null;
  nextComponent: string | null; components: Observation[]; outstandingQuestions: string[];
};
const assessmentSchema = ReviewCellPaymentResponse.shape.mileage.unwrap();
const observationSchema = assessmentSchema.shape.components.element.omit({
  recommendedRollUpType: true, decisionRuleStatus: true, outstandingQuestions: true,
  selectionRationale: true, recommendationExplanation: true, documentationEvidence: true,
}).strict();
const norm = (value: string) => value.toLowerCase().replace(/[^a-z0-9]/g, "");
const uncertain = (value: string) => /\b(unknown|unsure|uncertain|undecided|not sure|don.t know|not confirmed|unconfirmed|not yet|haven.t decided|haven.t confirmed|can.t confirm|cannot confirm|still deciding|need to (?:check|confirm))\b/i.test(value);
const has = (c: Observation, topic: string) => c.facts.some(f => f.topic === topic && !uncertain(f.value) && !uncertain(f.quote));
const current = (c: Observation, topic: string, input: MileageReviewInput) => c.facts.some(f =>
  f.topic === topic && input.answers.some(a => a.id === f.answerId));
const needsExpensePurpose = (c: Observation) => c.treatment === "claimed-nontaxable"
  && (c.id === "compensation" || c.id === "allowance" && !c.facts.some(f => f.topic === "purpose"
    && /\b(business expenses?|expense repayment|reimburse\w*|repay\w*)\b/i.test(f.quote)));
/** Conflicting current intent, not an explicit correction (the evidence pass removes superseded facts). */
function treatmentConflict(c: Observation) {
  const quotes = c.facts.filter(f => f.topic === "treatment" || f.topic === "wageHandling").map(f => f.quote);
  return quotes.some(q => /\b(non.?taxable|not taxable|tax.free|exclud\w*)\b/i.test(q))
    && quotes.some(q => /\b(taxable|taxed|taxable wages)\b/i.test(q.replace(/\b(non.?taxable|not taxable|tax.free)\b/gi, "")));
}
/** A short selection asserts intent only in an explicit payroll/tax treatment question. */
function contextualReimbursementIntent(c: Observation, input: MileageReviewInput): boolean {
  return ["reimbursement", "allowance", "compensation"].includes(c.id) && c.facts.some(f =>
    ["treatment", "wageHandling"].includes(f.topic) && input.answers.some(a =>
      a.id === f.answerId && (a.component === c.id
        || a.id.endsWith(`:${c.id}:treatment`) || a.id.endsWith(`:${c.id}:wageHandling`))
      && /^(?:kept|keep|treated|treat)(?: it| this payment)? as (?:a )?reimbursement[.!]?$/i.test(a.answer.trim())
      && ((/\btaxable wages\b/i.test(a.question) && /\bor\b/i.test(a.question)
        && /\breimbursement\b/i.test(a.question))
        || (/\bhow\b/i.test(a.question) && /\b(?:intend|intended)\b/i.test(a.question)
          && /\b(?:treat|treatment)\b/i.test(a.question) && /\b(?:payroll|tax|taxes)\b/i.test(a.question)))));
}
export function validMileageInput(input: MileageReviewInput) {
  const first = input.answers[0];
  return first.id === MILEAGE_PURPOSE_ID && first.question === MILEAGE_OPENING
    && first.answer === MILEAGE_CHOICES.find(o => o.id === input.purposeChoice)?.label
    && new Set([...input.answers, ...input.historicalAnswers].map(a => a.id)).size === input.answers.length + input.historicalAnswers.length
    && input.answers.slice(1).every(a => a.id.startsWith(`${MILEAGE_POLICY}:`));
}
export const mileageMessage = (input: MileageReviewInput) => JSON.stringify(input,
  (_key, value: unknown) => typeof value === "string" ? redactSensitive(value) : value);

/** Selection uses supplied product behavior, not approval of tax policy or tenant setup. */
function candidate(c: Observation): Pick<MileageComponent, "recommendedRollUpType" | "decisionRuleStatus"> {
  let rule = kb.decision_rules[6];
  if (c.id === "unknown") return { recommendedRollUpType: null, decisionRuleStatus: "clarification_required" };
  if (c.treatment === "mixed") rule = kb.decision_rules[5];
  else if (c.treatment === "supplemental-taxable") rule = kb.decision_rules[4];
  else if (c.id === "informational" && c.treatment === "no-payroll-effect" && has(c, "informational"))
    return { recommendedRollUpType: "Memo", decisionRuleStatus: "pending_documentation_verification" };
  else if (c.id === "noncash" && has(c, "noncash") && c.treatment === "ordinary-taxable")
    return { recommendedRollUpType: "Custom Taxable Fringe", decisionRuleStatus: "pending_documentation_and_test" };
  else if (c.id !== "noncash" && c.id !== "informational" && c.treatment === "ordinary-taxable") rule = kb.decision_rules[3];
  else if (["reimbursement", "allowance"].includes(c.id) && c.specialReporting === "yes" && has(c, "reporting")) rule = kb.decision_rules[2];
  else if (c.id === "reimbursement" && c.treatment === "claimed-nontaxable"
    && has(c, "purpose") && has(c, "calculation") && has(c, "treatment"))
    // Primary documented candidate only: unknown presentation is not an assumed configuration.
    // Qualification, substantiation and excess handling remain independent implementation safeguards.
    rule = c.presentation === "negative-deduction" ? kb.decision_rules[1] : kb.decision_rules[0];
  else if (c.id === "allowance" && c.treatment === "claimed-nontaxable"
    && !needsExpensePurpose(c) && has(c, "calculation") && has(c, "treatment"))
    rule = c.presentation === "negative-deduction" ? kb.decision_rules[1] : kb.decision_rules[0];
  return { recommendedRollUpType: rule.candidate as MileageComponent["recommendedRollUpType"],
    decisionRuleStatus: rule.status as MileageComponent["decisionRuleStatus"] };
}
function missing(c: Observation): string[] {
  const required = c.id === "reimbursement" ? ["calculation", "treatment"]
    : c.id === "allowance" ? ["calculation", "treatment"]
      : c.id === "compensation" ? ["calculation", "treatment"]
        : c.id === "informational" ? ["informational"] : c.id === "noncash" ? ["noncash", "treatment"] : ["purpose"];
  if (c.treatment === "claimed-nontaxable" && c.id === "compensation") required.push("purpose");
  if (c.treatment === "unknown" && has(c, "treatment")) required.push("wageHandling");
  if (c.presentation === "unknown" && c.facts.some(f => f.topic === "presentation")) required.push("presentation");
  if (c.specialReporting === "yes") required.push("reporting");
  return [...new Set(required)].filter(t => !has(c, t)).map(t => `${c.id}: ${t}`)
    .concat(needsExpensePurpose(c) ? ["Clarify whether this payment repays business expenses rather than providing extra pay."] : []);
}
export function validateMileageReview(raw: unknown, input: MileageReviewInput) {
  const fail = (correction: string) => ({ ok: false as const, correction });
  if (!raw || typeof raw !== "object") return fail("Return the required object.");
  const r = raw as ModelResult;
  if (r.next === "clarify" ? r.customerSummary !== null
    : typeof r.customerSummary !== "string" || !r.customerSummary.trim() || r.customerSummary.length > 1200)
    return fail("Use customerSummary null for clarify; for terminal outcomes summarize the actual active payment purpose and calculation, with material unknowns in a separate paragraph.");
  if (typeof r.customerSummary === "string") {
    if (/\b(saved|collected|complete[ds]?|nothing else|approved|verified|eligible|qualifies|tax.free|setup changed|payroll changed|must|should|need to)\b|\?/i.test(r.customerSummary))
      return fail("Rewrite customerSummary only to describe learned payment facts and material unknowns. Do not use must, should, or need to, including within attributed intent such as 'the customer said it should'. For explicitly supplied intent say 'You intend to treat this payment as a reimbursement', not 'should be kept as a reimbursement'. No saving/completion, eligibility, approval, requirements or new questions. Recheck the other fields and return the full JSON.");
    const activeNumbers = new Set(input.answers.flatMap(a => a.answer.match(/\d+(?:[.,]\d+)*/g) ?? []));
    if ((r.customerSummary.match(/\d+(?:[.,]\d+)*/g) ?? []).some(n => !activeNumbers.has(n)))
      return fail("Summary amounts, rates and frequencies must come from active answers, not history, questions or assumptions.");
  }
  if (Object.keys(r).sort().join() !== Object.keys(MILEAGE_SCHEMA.properties).sort().join()
    || !["clarify", "captured", "pending"].includes(r.next) || typeof r.reason !== "string" || !r.reason.trim() || r.reason.length > 500
    || !Array.isArray(r.components) || !r.components.length || r.components.length > 6
    || !r.components.every(c => observationSchema.safeParse(c).success)
    || new Set(r.components.map(c => c.id)).size !== r.components.length
    || !Array.isArray(r.outstandingQuestions) || r.outstandingQuestions.length > 20
    || !r.outstandingQuestions.every(q => typeof q === "string" && q.trim() && q.length <= 500)) return fail("Use the schema exactly; no candidates or verification claims.");
  const answers = [...input.answers, ...input.historicalAnswers];
  const unsupported = r.components.filter(c => c.id !== "unknown" && !current(c, "purpose", input));
  if (unsupported.length) return fail(
    `Unsupported component ids: ${unsupported.map(c => c.id).join(", ")}. Each purpose needs current quoted evidence. Component ids are alternatives, not a checklist. Remove unused placeholder components entirely, including a placeholder unknown component; preserve all genuinely supported purposes and their facts. Do not invent evidence to fill unused types. Unknown treatment inside a supported component is valid. Return the complete corrected JSON.`);
  for (const c of r.components) {
    for (const f of c.facts) {
      const a = answers.find(a => a.id === f.answerId);
      if (!a || !a.answer.includes(f.quote) || !f.quote.trim()) return fail("Every fact must cite an exact supplied answerId and quote.");
      if (["purpose", "treatment", "wageHandling", "qualification", "presentation", "reporting"].includes(f.topic) && !input.answers.includes(a))
        return fail("History cannot answer the replacement purpose or current tax/reporting decisions.");
    }
    if (c.id !== "unknown" && ["D", "E", "F"].includes(input.purposeChoice)
      && !c.facts.some(f => f.topic === "purpose" && f.answerId !== MILEAGE_PURPOSE_ID))
      return fail("Multiple, unsure and other choices do not establish a specific purpose. Ask which uses apply or how payment is received.");
    if (c.treatment !== "unknown" && !current(c, "treatment", input) && !current(c, "wageHandling", input)) return fail("Treatment needs independent current quoted intent, not purpose or calculation.");
    if (c.presentation !== "unknown" && !current(c, "presentation", input)) return fail("Presentation needs a quoted customer answer.");
    if (c.specialReporting !== "unknown" && !current(c, "reporting", input)) return fail("Reporting needs a quoted answer.");
    if (c.facts.some(f => ["treatment", "wageHandling", "qualification", "presentation", "reporting"].includes(f.topic) && f.answerId === MILEAGE_PURPOSE_ID))
      return fail("The opening establishes purpose only, never treatment, qualification or presentation.");
    const treatment = c.facts.filter(f => ["treatment", "wageHandling"].includes(f.topic)).map(f => f.quote).join(" ");
    if (c.treatment !== "unknown" && (uncertain(treatment)
      || c.treatment === "ordinary-taxable" && (!/\b(ordinary|regular|normal)\b/i.test(treatment) || !/\b(taxable|taxed|wages)\b/i.test(treatment) || /\b(supplemental|non.?taxable|tax.free|part|mixed)\b/i.test(treatment))
      || c.treatment === "supplemental-taxable" && !/\bsupplemental\b/i.test(treatment)
      || c.treatment === "claimed-nontaxable" && !/\b(non.?taxable|tax.free|not taxable|exclu\w+)\b/i.test(treatment)
        && !contextualReimbursementIntent(c, input)
      || c.treatment === "mixed" && !/\b(part|mixed|portion|some)\b/i.test(treatment)
      || c.treatment === "no-payroll-effect" && !/\b(no|not|without|only)\b/i.test(treatment)))
      return fail("Treatment must be supported by the exact quoted statement, not inferred from ordinary cash or purpose. 'Separate taxable mileage payment' does not explicitly establish supplemental intent. Keep treatment unknown for that choice; ask a clearer wageHandling question for the SAME component with explicit ordinary taxable wages versus supplemental taxable pay and an unsure option. Do not repeat ordinary-versus-separate wording.");
    if (c.id === "noncash" && !c.facts.some(f => f.topic === "noncash" && /\b(noncash|non-cash|not cash)\b/i.test(f.quote)))
      return fail("A noncash candidate needs an explicit noncash fact.");
    if (c.id === "informational" && !c.facts.some(f => f.topic === "informational" && /\b(no pay|not paid|without pay|informational|information only)\b/i.test(f.quote)))
      return fail("Memo requires explicit informational use without payment.");
    if (c.id === "informational" && !has(c, "informational") || c.id === "noncash" && !has(c, "noncash"))
      return fail("Informational/noncash use requires explicit evidence, never ordinary taxable cash.");
  }
  const expected = { A: "reimbursement", B: "allowance", C: "compensation" }[input.purposeChoice as "A"];
  if (expected && !r.components.some(c => c.id === expected) && input.answers.length === 1)
    return fail("Keep the selected purpose, not an inferred calculation method.");
  const gaps = r.components.flatMap(missing);
  if (input.purposeChoice === "D") {
    if (r.components.filter(c => c.id !== "unknown").length < 2) gaps.push("Identify each distinct purpose");
  }
  if (r.next === "captured" && (gaps.length || r.components.some(c => c.treatment === "unknown" || c.id === "unknown")))
    return fail(`Capture is incomplete. Clarify or retain uncertainty: ${gaps.join("; ")}. If explicit tax intent is cited only under wageHandling, also retain the exact supported statement as a treatment-topic fact. Never invent missing intent.`);
  if (r.next === "pending" && !r.outstandingQuestions.length) return fail("Name outstanding business questions; the limit never resolves them.");
  if (r.next === "pending" && input.answers.length === 1)
    return fail("The opening alone is not a completed review. Ask the relevant first follow-up for this branch.");
  if (r.next === "pending" && !input.answers.slice(1).some(a => uncertain(a.answer))
    && !r.components.some(treatmentConflict))
    return fail("Questions remain and no customer uncertainty has been expressed. Ask the missing relevant fact rather than ending discovery.");
  if (r.next === "clarify") {
    if (typeof r.question !== "string" || r.question.length > 200
      || !r.question.trim() || (r.question.match(/\?/g) ?? []).length > 1 || !topics.includes(r.nextTopic ?? "") || !ids.includes(r.nextComponent ?? ""))
      return fail("Ask one bounded question with a valid topic/component.");
    const c = r.components.find(c => c.id === r.nextComponent);
    if (!c) return fail("Scope the question to a component in this review, not another payment.");
    const answeredTopic = (answerId: string) => c.facts.some(f => f.topic === r.nextTopic && f.answerId === answerId);
    if (answers.some(a => norm(a.question) === norm(r.question!)))
      return fail("Do not repeat answered questions.");
    if (["mileageDetails", "retention", "reconciliation", "excess", "qualification", "sharedCode"].includes(r.nextTopic!))
      return fail("Ask only a missing distinction that changes Roll-Up selection: purpose, calculation, intended treatment, indicated presentation or reporting. Keep compliance and implementation checks separate.");
    if (!gaps.length && r.components.every(part => part.treatment !== "unknown" && part.id !== "unknown")
      && !["presentation", "reporting", "purpose"].includes(r.nextTopic!))
      return fail("Selection facts are already supplied. Capture the recommendation or its genuine documentation gap; do not manufacture another follow-up.");
    const conflictAt = c && treatmentConflict(c) ? Math.max(...c.facts
      .filter(f => ["treatment", "wageHandling"].includes(f.topic))
      .map(f => input.answers.findIndex(a => a.id === f.answerId))) : -1;
    const priorTopicAt = input.answers.reduce((last, a, index) =>
      a.id.endsWith(`:${r.nextComponent}:${r.nextTopic}`) ? index : last, -1);
    // Only a newly volunteered conflicting intent permits one clarification of that distinction.
    const newConflict = r.nextTopic === "treatment" && conflictAt > priorTopicAt
      && c?.treatment === "unknown";
    if (r.nextTopic === "treatment" && c.facts.some(f => f.topic === r.nextTopic && (uncertain(f.quote) || uncertain(f.value))))
      return fail("The customer already expressed uncertainty about this topic, even if volunteered under another question. Do not ask it again. Return next pending, question null, answerFormat null, nextTopic null, nextComponent null, with the named missing distinction in reason and outstandingQuestions; or ask a different genuinely missing fact. Unknown intent cannot be captured as complete.");
    const priorTopicAnswers = input.answers.filter(a => a.id.endsWith(`:${r.nextComponent}:${r.nextTopic}`));
    // An answer volunteered under calculation can address tax intent only. Its question label
    // is not evidence that calculation was answered. Permit one targeted return to the missing fact.
    // "Separate taxable payment" describes presentation, not supplemental tax intent.
    // Permit one clearer wage-handling question, rather than inferring treatment or
    // rejecting every way out of an ambiguous model-authored choice.
    const ambiguousWageChoice = r.nextTopic === "wageHandling" && c.treatment === "unknown"
      && priorTopicAnswers.length === 1
      && /^separate taxable mileage payment[.!]?$/i.test(priorTopicAnswers[0].answer.trim())
      && /\bordinary wages\b/i.test(priorTopicAnswers[0].question);
    if (ambiguousWageChoice && !/\bsupplemental\b/i.test(`${r.question} ${r.answerFormat?.kind === "choices" ? r.answerFormat.options?.join(" ") : ""}`))
      return fail("The earlier separate-payment choice did not establish supplemental tax intent. Ask one clearer wageHandling question for this same component, explicitly using ordinary taxable wages versus supplemental taxable pay and an unsure choice. Do not repeat separate taxable mileage payment as an option. Keep treatment unknown until that distinction is answered.");
    const priorAddressedTopic = !ambiguousWageChoice && priorTopicAt >= 0 && (answeredTopic(input.answers[priorTopicAt].id)
      || /^(?:i(?:'m| am)|we(?:'re| are))? ?(?:not sure|unsure|unknown|don.t know)[.!]?$/i.test(input.answers[priorTopicAt].answer.trim())
      || priorTopicAnswers.length > 1);
    if (priorAddressedTopic && !newConflict)
      return fail("This component already answered that topic, including any uncertainty. Ask another material fact or retain the gap.");
    if (c && has(c, r.nextTopic!) && !ambiguousWageChoice && !newConflict && !(r.nextTopic === "purpose" && needsExpensePurpose(c)))
      return fail("That fact is already supplied. Ask only a material missing fact.");
    if (c?.id === "reimbursement" && c.treatment === "claimed-nontaxable" && has(c, "calculation")
      && ["mileageDetails", "qualification", "reconciliation", "excess"].includes(r.nextTopic!))
      return fail("Purpose, calculation and intended treatment establish the primary conditional candidate. Capture requirements; retain substantiation, qualification and excess handling as internal safeguards, not customer prerequisites. Only clarify if intended treatment is genuinely uncertain.");
    if (c?.id === "reimbursement" && c.treatment === "claimed-nontaxable" && !missing(c).length
      && !["presentation", "reporting"].includes(r.nextTopic!)
      && !(input.purposeChoice === "D" && r.nextTopic === "sharedCode")
      && !(input.purposeChoice === "F" && r.nextTopic === "example"))
      return fail("The reimbursement purpose, calculation and intended treatment are already sufficient. Capture rather than extending discovery without a material Roll-Up Type uncertainty.");
    if (r.nextTopic === "presentation" && (!c || c.treatment !== "claimed-nontaxable"
      || c.presentation !== "unknown" || !c.facts.some(f => f.topic === "presentation")))
      return fail("Ask presentation only when supplied facts indicate an unresolved pay-statement requirement that could change the candidate; do not add a routine presentation checklist.");
    if ((r.nextTopic === "reporting" || /\bW-?2\b/i.test(r.question)) && c?.specialReporting !== "yes")
      return fail("Ask W-2 details only when special reporting has been indicated.");
    const f = r.answerFormat;
    if (!f || !["text", "choices"].includes(f.kind) || f.kind === "text" && f.options !== null
      || f.kind === "choices" && (!Array.isArray(f.options) || f.options.length < 2 || f.options.length > 4
        || f.options.some(o => typeof o !== "string" || !o.trim() || o.length > 80)
        || new Set(f.options.map(norm)).size !== f.options.length)) return fail("Use text/null or two to four distinct short choices.");
  } else if (r.question !== null || r.answerFormat !== null || r.nextTopic !== null || r.nextComponent !== null)
    return fail("Only clarify carries a question, format, topic and component.");
  const customerText = [r.customerSummary, r.question, r.reason, ...(r.answerFormat?.options ?? []), ...r.outstandingQuestions].join(" ");
  const forbidden = bannedWordsIn(customerText);
  if (forbidden.length) return fail(`Rewrite question, choices, reason and outstandingQuestions without these terms: ${forbidden.join(", ")}. Say provide business trip details rather than submit records. Keep quotes unchanged in component facts only. Return the full JSON.`);
  if (/\b(roll.?up|custom reimbursement|custom taxable fringe|tax engine|EIN|gross.to.net|verified candidate|configuration applied|must split|must create|is tax.free|qualifies for|accountable.plan)\b|[!*#`]|\p{Extended_Pictographic}/iu.test(customerText)
    ) return fail("Remove technical candidate names, accountable-plan jargon, source identifiers and verification claims from question, choices, reason and outstandingQuestions. Ask about company practice in plain language; retain technical details only in component facts. No markdown.");
  const safeguards = [
    "Verify applicable authoritative product documentation; supplied S1–S3 citations have not been independently reviewed.",
    "Confirm business purpose and legally supportable company tax policy with the payroll/tax owner.",
    "Verify business-mile substantiation, documentation and reconciliation requirements before implementation; customer-reported non-taxability is intent, not proof of legal qualification.",
    "Verify whether advances are used and how excess advances are returned or otherwise treated before implementation.",
    "Confirm earning versus negative-deduction display and any special W-2 reporting in actual setup; an unspecified display or reporting requirement is not a customer-confirmed default.",
    "Inspect actual MILEAGE setup, EIN/country availability, reporting and amount/hours/units capture settings.",
    ...["net pay", "taxes", "pay statement", "W-2", "GL", "downstream reports"].map(s => `Validate ${s} in controlled payroll testing.`),
    "Obtain authorization before any setup change. No setup change has been applied.",
  ];
  const components: MileageComponent[] = r.components.map(c => {
    const selection = candidate(c);
    const product = kb.roll_up_types.find(t => t.name === selection.recommendedRollUpType);
    const questions = missing(c);
    if (c.treatment === "mixed") questions.push("Identify the intended treatment of each payment portion.");
    if (c.treatment === "supplemental-taxable") questions.push("The supplied guidance does not identify a type for supplemental taxable mileage pay.");
    if (selection.recommendedRollUpType === "Custom Reimbursement")
      questions.push("The supplied guidance does not establish tax behavior for the requested W-2 reporting.");
    if (c.id === "compensation" && c.treatment === "claimed-nontaxable")
      questions.push("Clarify whether this payment repays business expenses rather than providing extra pay.");
    if (treatmentConflict(c)) questions.push("Confirm which intended tax treatment applies.");
    const complete = !!product && !questions.length && c.treatment !== "unknown";
    return { ...c, ...selection,
      decisionRuleStatus: complete ? "recommendation_complete" : selection.decisionRuleStatus,
      recommendationExplanation: product ? c.treatment === "claimed-nontaxable"
        ? `Your answers describe business-expense repayment intended as non-taxable. The supplied guidance describes this type as ${c.presentation === "negative-deduction" ? "a negative deduction that adds to net pay without tax" : c.specialReporting === "yes" ? "supporting special W-2 reporting, but does not establish its tax behavior" : "an earning that adds to net pay without tax"}.`
        : c.id === "informational" ? "Your answers describe information only, with no payment. The supplied guidance says this type has no effect on gross-to-net pay or employer taxes."
          : c.id === "noncash" ? "Your answers describe a noncash taxable benefit. The supplied guidance describes this type as reporting noncash taxable fringe benefits."
            : "Your answers describe ordinary taxable pay. The supplied guidance describes this type as earnings paid and taxed at the regular rate."
        : "The supplied answers and guidance do not yet support a recommendation.",
      selectionRationale: product
        ? `${c.purpose} Calculation: ${c.facts.filter(f => f.topic === "calculation").map(f => f.value).join("; ") || "Not applicable"}. Intended treatment: ${c.treatment}. ${c.presentation === "negative-deduction" ? "Negative-deduction presentation requested. " : ""}${product.name} matches the supplied behavior: ${product.documented_behavior}${questions.length ? ` Selection remains unresolved: ${questions.join(" ")}` : ""}`
        : `No supported selection yet. ${questions.join(" ") || "Clarify the payment purpose and intended treatment."}`,
      documentationEvidence: product ? [{ source: product.source as "S1", behavior: product.documented_behavior }] : [],
      outstandingQuestions: questions };
  });
  const complete = r.next === "captured" && !gaps.length && components.every(c => c.decisionRuleStatus === "recommendation_complete");
  const summarize = (types: string[]) => components.map(c => `${c.id}: ${c.facts.filter(f => types.includes(f.topic)).map(f => f.value).join("; ") || "Unknown"}`).join("\n");
  const assessment: MileageAssessment = {
    customerSummary: r.customerSummary,
    policyVersion: MILEAGE_POLICY, knowledgeVersion: MILEAGE_KNOWLEDGE_VERSION, earningsCode: "MILEAGE",
    businessPurpose: summarize(["purpose"]), paymentCalculationMethod: summarize(["calculation"]),
    substantiationStatus: summarize(["mileageDetails", "reconciliation", "excess"]),
    intendedTaxTreatment: summarize(["treatment", "wageHandling"]), taxTreatmentVerificationStatus: "pending-independent-validation",
    specialReportingRequirements: summarize(["reporting"]),
    recommendedRollUpType: components.length === 1 ? components[0].recommendedRollUpType : null,
    supportingUKGDocumentation: kb.source_documents.map(s => ({ ...s, id: s.id as "S1" | "S2" | "S3", verification: "supplied-citation-not-independently-verified" })),
    configurationDependencies: kb.product_dependencies.map(d => `${d.fact} [${d.source}]`),
    separateEarningsCodesRequired: "Unknown", decisionStatus: complete ? "Recommendation Complete" : "Pending Verification",
    outputStatus: complete ? "Recommendation complete" : r.next === "captured" ? "Pending Documentation Verification" : "Additional Clarification Needed",
    documentationVerification: "supplied-citations-only", tenantVerification: "not-inspected", payrollValidation: "not-performed",
    components, outstandingQuestions: complete ? [] : [...new Set([...r.outstandingQuestions, ...gaps, ...components.flatMap(c => c.outstandingQuestions)])],
    implementationSafeguards: safeguards,
    knownGaps: [...kb.known_gaps], captured: r.next === "captured", nextTopic: r.nextTopic, nextComponent: r.nextComponent,
  };
  const value: CellReviewResult = { next: r.next === "clarify" ? "clarify" : "pending", component: "payment",
    question: r.question, answerFormat: r.answerFormat, reason: complete ? MILEAGE_CAPTURED : r.next === "captured"
      ? components.flatMap(c => c.outstandingQuestions).join(" ") : r.reason,
    confirmations: [], mileage: assessment };
  const parsed = ReviewCellPaymentResponse.strict().safeParse(value);
  if (!parsed.success) return fail("Assessment does not satisfy the versioned contract.");
  return { ok: true as const, value: JSON.parse(JSON.stringify(parsed.data, (_key, v: unknown) => typeof v === "string" ? redactSensitive(v) : v)) as CellReviewResult };
}
