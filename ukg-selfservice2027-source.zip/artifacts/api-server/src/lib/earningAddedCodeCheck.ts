import { composePrompt } from "./earningPromptGeneral";

/**
 * Server-owned DEMO reference library for additional earning codes. Illustrative only: it holds no verified UKG
 * mapping, earning type, tax or setup setting. See docs/earning-prompts/added-codes.md.
 */
export const ADDED_CODE_DEMO_LIBRARY = [
  {
    id: "demo-employee-referral-bonus",
    name: "Employee referral bonus",
    criteria: [
      "The company pays an employee for referring someone who is hired (a successful referral).",
      "The payment is a cash bonus. Amount, timing, frequency, installments and retention requirements are not prerequisites for identifying this payment purpose.",
    ],
  },
  {
    id: "demo-sign-on-bonus",
    name: "Sign-on bonus",
    criteria: [
      "The company pays a newly hired employee for joining.",
      "The amount and when it is paid are known.",
      "Whether it is repaid if the employee leaves early is known, or the description says there is no repayment.",
    ],
  },
  {
    id: "demo-annual-performance-bonus",
    name: "Annual performance bonus",
    criteria: [
      "The company pays employees once a year based on individual or company performance.",
      "Who is eligible and when it is paid are known.",
    ],
  },
] as const;

export type AddedCodeReferenceId = (typeof ADDED_CODE_DEMO_LIBRARY)[number]["id"];
export const MAX_THREAD = 4;

export const ADDED_CODE_PROCESS_RULES = [
  "Process: additional earning codes. The team describes how they intend to use an earning code that isn't in their payroll register. Compare the description and any follow-up replies with the demo reference library in the user message.",
  "The library is a small illustrative demo, not a verified catalog. Never claim an earning type, tax, reporting or setup setting, and never invent a reference that isn't listed.",
  "Return outcome match only when one listed reference clearly fits and every one of its criteria is established by the supplied facts. Set referenceId to that id.",
  "Referral Bonus — Roll Up Type Identification. Objective: identify the appropriate documented UKG Ready Earning Code Roll Up Type using all supplied description and replies, minimizing follow-up questions. A cash bonus paid to an employee for referring a candidate who is hired sufficiently establishes purpose.",
  "For referral payments, never ask about payment frequency or recurrence, one-time versus installments, waiting periods or retention requirements (30/60/90 days), processing dates, scheduling, initiation or automation solely to identify the Roll Up Type. Do not introduce payroll automation or hiring workflows. These details are not selection criteria, even if mentioned in historical questions.",
  "If only 'referral payment' or 'referral incentive' is given and compensation is unclear, ask: 'Is this a cash bonus paid to an employee for successfully referring a candidate who is hired, or is it another type of referral-related compensation?' Skip this question when existing information already answers it.",
  "Evaluate Bonus (Supplemental Tax Rate) as a candidate subject to explicit intended payroll tax treatment and verified UKG Ready documentation. Never assume supplemental treatment from the word bonus. Ask only a missing fact essential to distinguish documented types; zero questions when sufficient. Briefly explain a supported classification. Never invent Roll Up Types or unsupported product behavior.",
  "Documentation boundary: the supplied demo library establishes illustrative payment-purpose matches only, not verified Roll Up Types. A match here is NOT a finalized Roll Up Type. Do not claim Bonus (Supplemental Tax Rate) is confirmed or mapped from this demo entry, and do not ask the customer operational questions to compensate for missing product documentation. Final Roll Up identification requires verified documentation; preserve that distinction in the reason when returning a referral purpose match.",
  "Return outcome question when one reference plausibly fits but a criterion is missing or ambiguous. Ask one focused question about the single most important missing fact, and never repeat a question already answered in the thread.",
  "Return outcome noMatch when no listed reference fits the described purpose. Never stretch a reference to fit. Set referenceId null; the facts are kept for setup review.",
  "summary restates the payment in one or two sentences using only supplied facts. facts lists the established facts as short plain statements. reason says briefly why this outcome follows.",
  "question is null unless outcome is question.",
  "Customer-facing summary, facts and question must never mention checking against a reference library, demo library, catalog, reference IDs or internal matching. Describe the payment and any missing facts directly. For noMatch, explain that the setup team needs to review the code without revealing the internal comparison.",
];

export const ADDED_CODE_INSTRUCTIONS = composePrompt(
  "You compare a described additional earning code with a small demo reference library and propose a match, ask one follow-up question or report no match.",
  ADDED_CODE_PROCESS_RULES,
);

export const ADDED_CODE_SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: ["outcome", "referenceId", "summary", "facts", "question", "reason"],
  properties: {
    outcome: { type: "string", enum: ["match", "question", "noMatch"] },
    referenceId: { anyOf: [{ type: "string", enum: ADDED_CODE_DEMO_LIBRARY.map((ref) => ref.id) }, { type: "null" }] },
    summary: { type: "string" },
    facts: { type: "array", items: { type: "string" } },
    question: { anyOf: [{ type: "string" }, { type: "null" }] },
    reason: { type: "string" },
  },
} as const;

export interface AddedCodeInput { description: string; thread: { question: string; answer: string }[] }

export function addedCodeMessage(input: AddedCodeInput): string {
  return JSON.stringify({
    demoReferenceLibrary: ADDED_CODE_DEMO_LIBRARY,
    description: input.description,
    thread: input.thread,
    followUpsRemaining: MAX_THREAD - input.thread.length,
  });
}

export interface AddedCodeResult {
  outcome: "match" | "question" | "noMatch";
  summary: string; facts: string[]; question: string | null; reason: string;
  reference: { id: string; name: string; library: "demo" } | null;
}

export type Validated = { ok: true; value: AddedCodeResult } | { ok: false; issue: string; correction: string };

const text = (value: unknown, max: number): value is string => typeof value === "string" && !!value.trim() && value.length <= max;

export function validateAddedCodeCheck(raw: unknown, input: AddedCodeInput): Validated {
  const bad = (issue: string, correction: string): Validated => ({ ok: false, issue, correction });
  if (!raw || typeof raw !== "object") return bad("not_json", "Return JSON that matches the schema.");
  const r = raw as Record<string, unknown>;
  if (!["match", "question", "noMatch"].includes(r.outcome as string)) return bad("outcome", "Use outcome match, question or noMatch.");
  if (!text(r.summary, 400) || !text(r.reason, 300)) return bad("text", "Give a summary within 400 characters and a reason within 300.");
  if (!Array.isArray(r.facts) || r.facts.length > 6 || !r.facts.every((fact) => text(fact, 200))) return bad("facts", "List up to 6 short facts.");
  const outcome = r.outcome as AddedCodeResult["outcome"];
  const reference = ADDED_CODE_DEMO_LIBRARY.find((ref) => ref.id === r.referenceId);
  if (outcome === "match" && !reference) return bad("reference", "A match needs a referenceId from the demo library.");
  if (outcome === "noMatch" && r.referenceId !== null) return bad("reference", "noMatch needs referenceId null.");
  if (outcome === "question") {
    if (!text(r.question, 300)) return bad("question", "Ask one question within 300 characters.");
    const referral = /\b(referr\w*|referral)\b/i.test([input.description, ...input.thread.map(turn => turn.answer)].join(" "));
    if (referral && /\b(installments?|recur\w*|frequency|how often|one[- ]time|paid once|multiple payments|waiting period|retention|30|60|90|schedul\w*|automat\w*|initiat\w*|when.*(?:paid|processed)|(?:paid|processed).*when)\b/i.test(r.question))
      return bad("referral_scope", "Do not ask about referral timing, frequency, installments, retention, scheduling or automation. Reuse established purpose. Ask only a missing distinction between documented Roll Up Types; otherwise return a purpose-only match without claiming verified Roll Up identification.");
    if (input.thread.length >= MAX_THREAD) return bad("thread_full", "The conversation limit is reached. Never invent a match or report noMatch solely because of this limit. A match still requires every criterion; noMatch still requires a genuinely unsupported purpose.");
    const asked = input.thread.map((turn) => turn.question.trim().toLowerCase());
    if (asked.includes((r.question as string).trim().toLowerCase())) return bad("repeat", "That question was already answered. Ask a different missing fact or decide.");
  } else if (r.question !== null) return bad("question", "question must be null unless outcome is question.");
  return { ok: true, value: {
    outcome, summary: (r.summary as string).trim(), facts: (r.facts as string[]).map((fact) => fact.trim()),
    question: outcome === "question" ? (r.question as string).trim() : null, reason: (r.reason as string).trim(),
    reference: outcome === "match" && reference ? { id: reference.id, name: reference.name, library: "demo" } : null,
  } };
}
