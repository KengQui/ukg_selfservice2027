import OpenAI from "openai";

export function createOpenAIClient(): OpenAI {
  const apiKey = process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
  const baseURL = process.env.AI_INTEGRATIONS_OPENAI_BASE_URL;
  if (!apiKey || !baseURL) throw new Error("OpenAI integration is not configured");
  return new OpenAI({ apiKey, baseURL, maxRetries: 1 });
}

export function errorSummary(error: unknown): { status?: number; name?: string } {
  if (typeof error !== "object" || error === null) return {};
  const { status, name } = error as { status?: unknown; name?: unknown };
  return {
    status: typeof status === "number" ? status : undefined,
    name: typeof name === "string" ? name : undefined,
  };
}