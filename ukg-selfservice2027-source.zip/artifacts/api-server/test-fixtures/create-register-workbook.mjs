import ExcelJS from 'exceljs';
import { writeFile, copyFile } from 'node:fs/promises';
const folder = new URL('./registers/', import.meta.url);
const workbook = new ExcelJS.Workbook();
const header = ['Company', 'Company ID', 'Period start', 'Period end', 'Code', 'Description', 'Section', 'Amount', 'People', 'Currency'];
workbook.addWorksheet('Conflicting meaning').addRows([header,
  ['Fictional Harbor Co', 'DEMO-HARBOR', '2026-01-10', '2026-01-20', 'REG', 'Repayment recovery', 'Deductions', 300, 1, 'USD'],
]);
workbook.addWorksheet('Other company').addRows([header,
  ['Fictional Mountain Co', 'DEMO-MOUNTAIN', '2026-02-01', '2026-02-15', 'REG', 'Regular pay', 'Earnings', 900, 2, 'USD'],
]);
await workbook.xlsx.writeFile(new URL('fictional-conflict.xlsx', folder).pathname);
await copyFile(new URL('fictional-january.csv', folder), new URL('fictional-january-copy.csv', folder));
await writeFile(new URL('fictional-broken.pdf', folder), 'This fictional file is deliberately not a readable PDF.');
