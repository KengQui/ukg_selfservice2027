"""Generate small fictional digital and scanned registers for ingestion verification."""
from pathlib import Path
import fitz

destination = Path(__file__).parent / "registers"
destination.mkdir(exist_ok=True)
pdf = fitz.open()
page = pdf.new_page(width=700, height=450)
page.insert_text((35, 40), "Fictional Harbor Co - Payroll register", fontsize=18)
lines = [
    "Company ID: DEMO-HARBOR",
    "Period: March 1, 2026 to March 15, 2026",
    "Report ID: FICTIONAL-MAR-A    Currency: USD",
    "Earnings summary (current period)",
    "Code     Description           Payment amount      People",
    "REG      Regular pay           1,450.00            4",
    "MEAL     Meal allowance        75.00               2",
    "Employer expenses (current period)",
    "Code     Description           Expense amount      People",
    "HLTH     Health contribution   125.00              4",
    "Fictional test data only.",
]
for index, line in enumerate(lines):
    page.insert_text((35, 78 + 25 * index), line, fontname="cour", fontsize=12)
pdf.save(destination / "fictional-digital.pdf")
pix = page.get_pixmap(matrix=fitz.Matrix(1.5, 1.5))
pix.save(destination / "fictional-preview.png")
scan = fitz.open()
scanned_page = scan.new_page(width=700, height=450)
scanned_page.insert_image(scanned_page.rect, stream=pix.tobytes("png"))
scan.save(destination / "fictional-scanned.pdf")
scan.close()
pdf.close()
