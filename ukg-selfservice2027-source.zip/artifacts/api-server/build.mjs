import { createRequire } from "node:module";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { build as esbuild } from "esbuild";
import esbuildPluginPino from "esbuild-plugin-pino";
import { rm, cp, mkdir, readFile, readdir, access, constants } from "node:fs/promises";
import { spawnSync } from "node:child_process";

// Plugins (e.g. 'esbuild-plugin-pino') may use `require` to resolve dependencies
globalThis.require = createRequire(import.meta.url);

const artifactDir = path.dirname(fileURLToPath(import.meta.url));

async function chromiumExecutable() {
  if (process.env.CHROMIUM_PATH) return process.env.CHROMIUM_PATH;
  // Nix's Chromium wrapper is on PATH in the deployment runtime. Its
  // location is not necessarily /repl/tools/bin/chromium.
  for (const directory of (process.env.PATH || "").split(path.delimiter)) {
    const browser = path.join(directory, "chromium");
    try {
      await access(browser, constants.X_OK);
      return browser;
    } catch { /* Try the next PATH entry. */ }
  }
  throw new Error("Production capture requires executable Nix Chromium on PATH or CHROMIUM_PATH.");
}

async function buildAll() {
  const distDir = path.resolve(artifactDir, "dist");
  await rm(distDir, { recursive: true, force: true });

  await esbuild({
    entryPoints: [path.resolve(artifactDir, "src/index.ts")],
    platform: "node",
    bundle: true,
    loader: { ".txt": "text" },
    format: "esm",
    outdir: distDir,
    outExtension: { ".js": ".mjs" },
    logLevel: "info",
    // Some packages may not be bundleable, so we externalize them, we can add more here as needed.
    // Some of the packages below may not be imported or installed, but we're adding them in case they are in the future.
    // Examples of unbundleable packages:
    // - uses native modules and loads them dynamically (e.g. sharp)
    // - use path traversal to read files (e.g. @google-cloud/secret-manager loads sibling .proto files)
    external: [
      "pdfjs-dist/*",
      "@napi-rs/canvas",
      "exceljs",
      "*.node",
      "sharp",
      "better-sqlite3",
      "sqlite3",
      "canvas",
      "bcrypt",
      "argon2",
      "fsevents",
      "re2",
      "farmhash",
      "xxhash-addon",
      "bufferutil",
      "utf-8-validate",
      "ssh2",
      "cpu-features",
      "dtrace-provider",
      "isolated-vm",
      "lightningcss",
      "pg-native",
      "oracledb",
      "mongodb-client-encryption",
      "nodemailer",
      "handlebars",
      "knex",
      "typeorm",
      "protobufjs",
      "onnxruntime-node",
      "@tensorflow/*",
      "@prisma/client",
      "@mikro-orm/*",
      "@grpc/*",
      "@swc/*",
      "@aws-sdk/*",
      "@azure/*",
      "@opentelemetry/*",
      "@google-cloud/*",
      "@google/*",
      "googleapis",
      "firebase-admin",
      "@parcel/watcher",
      "@sentry/profiling-node",
      "@tree-sitter/*",
      "aws-sdk",
      "classic-level",
      "dd-trace",
      "ffi-napi",
      "grpc",
      "hiredis",
      "kerberos",
      "leveldown",
      "miniflare",
      "mysql2",
      "newrelic",
      "odbc",
      "piscina",
      "realm",
      "ref-napi",
      "rocksdb",
      "sass-embedded",
      "sequelize",
      "serialport",
      "snappy",
      "tinypool",
      "usb",
      "workerd",
      "wrangler",
      "zeromq",
      "zeromq-prebuilt",
      "playwright",
      "puppeteer",
      "puppeteer-core",
      "electron",
    ],
    sourcemap: "linked",
    plugins: [
      // pino relies on workers to handle logging, instead of externalizing it we use a plugin to handle it
      esbuildPluginPino({ transports: ["pino-pretty"] })
    ],
    // Make sure packages that are cjs only (e.g. express) but are bundled continue to work in our esm output file
    banner: {
      js: `import { createRequire as __bannerCrReq } from 'node:module';
import __bannerPath from 'node:path';
import __bannerUrl from 'node:url';

globalThis.require = __bannerCrReq(import.meta.url);
globalThis.__filename = __bannerUrl.fileURLToPath(import.meta.url);
globalThis.__dirname = __bannerPath.dirname(globalThis.__filename);
    `,
    },
  });
  // Stage immutable exporter INPUTS alongside the API runtime, never ZIPs.
  // Autoscale deployments need not retain the editable workspace or dev dependencies.
  const workspace = path.resolve(artifactDir, "../..");
  const source = path.join(workspace, "artifacts/ready-dls-kit/src");
  await cp(source, path.join(distDir, "artifacts/ready-dls-kit/src"), { recursive: true });
  for (const relative of ["artifacts/company-setup/src", "lib/setup-shared/src"]) {
    await cp(path.join(workspace, relative), path.join(distDir, relative), { recursive: true });
  }
  for (const name of ["index.html", "vite.config.ts", "package.json"]) {
    const relative = `artifacts/company-setup/${name}`;
    await cp(path.join(workspace, relative), path.join(distDir, relative));
  }
  for (const name of ["index.html", "vite.config.ts", "package.json", "branding-fingerprint.mjs"]) {
    const relative = `artifacts/branding/${name}`;
    await cp(path.join(workspace, relative), path.join(distDir, relative));
  }
  await cp(path.join(workspace, "lib/setup-shared/package.json"),
    path.join(distDir, "lib/setup-shared/package.json"));
  await cp(path.join(workspace, "artifacts/branding/src"),
    path.join(distDir, "artifacts/branding/src"), { recursive: true });
  await cp(path.join(workspace, "artifacts/performance-reviews/src"),
    path.join(distDir, "artifacts/performance-reviews/src"), { recursive: true });
  await mkdir(path.join(distDir, "lib/rdy-core/src"), { recursive: true });
  await cp(path.join(workspace, "lib/rdy-core/src/index.ts"), path.join(distDir, "lib/rdy-core/src/index.ts"));
  const assets = new Set();
  async function referencedAssets(dir) {
    for (const entry of await readdir(dir, { withFileTypes: true })) {
      const filename = path.join(dir, entry.name);
      if (entry.isDirectory()) await referencedAssets(filename);
      else if (/\.(?:tsx?|jsx?|css)$/.test(entry.name)) {
        const body = await readFile(filename, "utf8");
        for (const match of body.matchAll(/@assets\/([a-zA-Z0-9_./-]+)/g)) assets.add(match[1]);
      }
    }
  }
  await referencedAssets(source);
  await referencedAssets(path.join(workspace, "artifacts/branding/src"));
  await referencedAssets(path.join(workspace, "artifacts/company-setup/src"));
  await referencedAssets(path.join(workspace, "lib/setup-shared/src"));
  // Capture's local upload exercise and the archive's screenshot revision
  // input use this document by filename rather than through an @assets import.
  assets.add("Pasted--Employee-Earning-Code-Description-Hours-Rate--17897477_1789747780020.txt");
  for (const asset of assets) {
    const original = path.resolve(workspace, "attached_assets", asset);
    if (!original.startsWith(path.join(workspace, "attached_assets") + path.sep)) throw new Error("Unsafe asset input");
    const target = path.join(distDir, "attached_assets", asset);
    await mkdir(path.dirname(target), { recursive: true });
    await cp(original, target);
  }
  await mkdir(path.join(distDir, "scripts"), { recursive: true });
  // Capture runs as an unbundled child; stage its export-only screen contract too.
  for (const name of ["capture-design-handoff", "branding-capture-contract"]) {
    await cp(path.join(workspace, `scripts/${name}.mjs`),
      path.join(distDir, `scripts/${name}.mjs`));
  }
  for (const name of ["export-project", "create-claude-archive"]) {
    await esbuild({
      entryPoints: [path.join(workspace, `scripts/${name}.mjs`)],
      outfile: path.join(distDir, `scripts/${name}.mjs`),
      platform: "node",
      format: "esm",
      bundle: true,
      // The exporter uses import.meta.url to resolve its staged input root.
      banner: { js: "import { createRequire as __createRequire } from 'node:module'; import { fileURLToPath as __fileURLToPath } from 'node:url'; import __path from 'node:path'; const require = __createRequire(import.meta.url); const __filename = __fileURLToPath(import.meta.url); const __dirname = __path.dirname(__filename);" },
      logLevel: "warning",
    });
  }
  // Copy the exact installed Playwright runtime rather than assuming
  // devDependencies survive into autoscale production. Browser availability
  // depends on the system Chromium path being present on the runtime host;
  // the build probe below cannot guarantee that separately.
  const kitRequire = createRequire(path.join(workspace, "artifacts/ready-dls-kit/package.json"));
  const testPackage = kitRequire.resolve("@playwright/test/package.json");
  const testRequire = createRequire(testPackage);
  for (const [name, packagePath] of [
    ["@playwright/test", testPackage],
    ["playwright", testRequire.resolve("playwright/package.json")],
    ["playwright-core", testRequire.resolve("playwright-core/package.json")],
  ]) {
    await cp(path.dirname(packagePath), path.join(distDir, "node_modules", name), { recursive: true });
  }
  if (process.env.NODE_ENV === "production") {
    // Playwright's downloaded Linux Chromium is not usable on this Nix host
    // (libglib-2.0.so.0 and other native dependencies are missing). Do not
    // ship a binary that installs successfully but fails on the first export.
    // Replit's system Chromium wrapper brings its own Nix library closure.
    const browser = await chromiumExecutable();
    try {
      await access(browser, constants.X_OK);
    } catch {
      throw new Error(`Production capture requires an executable system Chromium at ${browser}; set CHROMIUM_PATH to a runnable browser on both build and runtime hosts.`);
    }
    const probe = spawnSync(browser, ["--headless", "--no-sandbox", "--disable-gpu", "--dump-dom", "about:blank"], {
      encoding: "utf8", timeout: 20_000, maxBuffer: 1024 * 1024,
    });
    if (probe.error || probe.status !== 0 || !probe.stdout.includes("<html")) {
      throw new Error(`Production Chromium at ${browser} failed its headless smoke test: ${probe.error?.message || probe.stderr || probe.stdout || `exit ${probe.status}`}`);
    }
  }
}

buildAll().catch((err) => {
  console.error(err);
  process.exit(1);
});
