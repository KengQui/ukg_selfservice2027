import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import '@ready/dls/styles.css'
import '@ukgepic/ready-dls/tokens/themes.css'
import '@workspace/setup-shared/base.css'
import './index.css'
import App from './App'

createRoot(document.getElementById('root')!).render(
  <StrictMode><App /></StrictMode>,
)