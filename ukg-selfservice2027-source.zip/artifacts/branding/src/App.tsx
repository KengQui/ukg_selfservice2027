import { useEffect } from 'react'
import type { ReactNode } from 'react'
import { BrowserRouter, Navigate, Route, Routes, useLocation, useSearchParams } from 'react-router-dom'
import { askBryte } from '@workspace/api-client-react'
import { AskBryteProvider } from '@workspace/setup-shared/ask-bryte'
import { isArchivedScenario, normalizeDemoParams } from '@workspace/setup-shared/prototypes/branding-demo/demoScenarios'
import { brandingPages } from './askBrytePages'
import SystemThemeSetupPage from './prototypes/system-theme-setup'
import { invitationSearch } from './prototypes/system-theme-setup/completionNavigation'

const PROJECTS = '/prototypes'

function Exit({ to, invitation = false }: { to: string; invitation?: boolean }) {
  const { search, hash } = useLocation()
  useEffect(() => {
    window.location.replace(invitation ? `${to}${invitationSearch(search)}` : `${to}${search}${hash}`)
  }, [to, search, hash, invitation])
  return <p role="status">{invitation ? 'Opening Invite others to help…' : 'Opening Projects…'}</p>
}

function CopyShortcut() {
  const { search, hash } = useLocation()
  const params = new URLSearchParams(search)
  if (!params.has('companies')) params.set('companies', 'acme-holdings')
  if (!params.has('page')) params.set('page', 'copy-branding')
  // Returning demos otherwise normalize their URL with useSearchParams on mount,
  // which discards the incoming hash. Apply the same required flag up front.
  if (params.get('demo')?.startsWith('returning-') && !params.has('returning')) params.set('returning', '1')
  return <Navigate replace to={`/prototypes/system-theme-setup?${params}${hash}`} />
}

function Home() {
  const { search, hash } = useLocation()
  return <Navigate replace to={`/prototypes/system-theme-setup${search}${hash}`} />
}

function BrandingPage() {
  const { search, pathname, hash } = useLocation()
  const normalized = normalizeDemoParams(new URLSearchParams(search))
  if (normalized) return <Navigate replace to={`${pathname}?${normalized}${hash}`} />
  return (
    <div className="branding-page">
      <a className="branding-back" href="/prototypes" aria-label="Back to Projects">← Back to Projects</a>
      <SystemThemeSetupPage />
    </div>
  )
}

/**
 * Branding is a customer-facing setup. The archived implementation team demos, where the team works on a customer's
 * behalf, use the Experienced register (voice and tone guide A.1).
 */
function BrandingAskBryte({ children }: { children: ReactNode }) {
  const [params] = useSearchParams()
  const register = isArchivedScenario(params.get('demo')) ? 'experienced' : 'first-time'
  return <AskBryteProvider app="branding" pages={brandingPages} ask={askBryte} register={register}>{children}</AskBryteProvider>
}

export default function App() {
  return (
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <BrandingAskBryte>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/system-theme-setup" element={<BrandingPage />} />
          <Route path="/prototypes/system-theme-setup" element={<BrandingPage />} />
          <Route path="/copy-branding" element={<CopyShortcut />} />
          <Route path="/prototypes/copy-branding" element={<CopyShortcut />} />
          <Route path="/prototypes/company-setup-hub" element={<Home />} />
          <Route path="/prototypes/company-setup-invite" element={<Exit to="/company-setup/prototypes/company-setup-invite" invitation />} />
          <Route path="/prototypes" element={<Exit to={PROJECTS} />} />
          <Route path="*" element={<Navigate replace to="/prototypes/system-theme-setup" />} />
        </Routes>
      </BrandingAskBryte>
    </BrowserRouter>
  )
}