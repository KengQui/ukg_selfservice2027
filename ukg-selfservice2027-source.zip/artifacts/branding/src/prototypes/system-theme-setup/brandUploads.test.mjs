import test from 'node:test'
import assert from 'node:assert/strict'
import {
  BRAND_ASSET_ACCEPT, BRAND_IMAGE_ACCEPT, brandImageMime, emptyBrandUploads,
  isBrandAsset, isBrandImage, isSelectedBrandLogo, restoreBrandUploads, storableBrandUploads,
} from './brandUploads.ts'

const logo = { id: 'logo', name: 'acme.png', size: 2048, url: 'data:image/png;base64,kept', originalUrl: 'data:image/png;base64,original', visionDataUrl: 'data:image/png;base64,vision' }
const photo = { id: 'photo', name: 'team.jpg', size: 900000, url: 'data:image/jpeg;base64,smaller', originalUrl: 'data:image/jpeg;base64,large', visionDataUrl: 'data:image/jpeg;base64,vision' }
const guide = { id: 'guide', name: 'brand-guide.pdf', size: 4096, url: null }
const matched = {
  files: [logo, photo, guide], status: 'matched', selectedLogoId: 'logo',
  message: 'Bryte identified acme.png as the standalone logo and prepared colors from it.',
}

test('picker and drag-and-drop accept every supported image extension, including JPEG and WebP', () => {
  const cases = [['png', 'image/png'], ['jpg', 'image/jpeg'], ['jpeg', 'image/jpeg'], ['svg', 'image/svg+xml'], ['webp', 'image/webp']]
  for (const [extension, mime] of cases) {
    for (const name of [`logo.${extension}`, `logo.${extension.toUpperCase()}`]) {
      const file = { name, type: '' }
      assert.equal(isBrandImage(file), true, name)
      assert.equal(isBrandAsset(file), true, name)
      assert.equal(brandImageMime(name), mime)
    }
    assert.equal(BRAND_IMAGE_ACCEPT.split(',').includes(`.${extension}`), true)
    assert.equal(BRAND_ASSET_ACCEPT.split(',').includes(`.${extension}`), true)
  }
})

test('PDF is a document only on the upload step, never an image even with a misleading MIME type', () => {
  for (const name of ['brand-guide.pdf', 'brand-guide.PDF']) {
    const file = { name, type: 'image/png' }
    assert.equal(isBrandAsset(file), true)
    assert.equal(isBrandImage(file), false)
    assert.equal(brandImageMime(name), undefined)
  }
  assert.equal(BRAND_ASSET_ACCEPT.split(',').includes('.pdf'), true)
  assert.equal(BRAND_IMAGE_ACCEPT.split(',').includes('.pdf'), false)
  for (const name of ['logo.gif', 'logo.bmp', 'logo.tiff', 'guide.docx', 'logo', 'guide.pdf.exe']) {
    assert.equal(isBrandAsset({ name, type: 'image/png' }), false, name)
    assert.equal(isBrandImage({ name, type: 'image/png' }), false, name)
  }
})

test('stored uploads keep the kept image, outcome, and logo pick, but never the session-only copies', () => {
  const stored = storableBrandUploads(matched)
  assert.deepEqual(stored, {
    files: [
      { id: 'logo', name: 'acme.png', size: 2048, url: 'data:image/png;base64,kept' },
      { id: 'photo', name: 'team.jpg', size: 900000, url: 'data:image/jpeg;base64,smaller' },
      { id: 'guide', name: 'brand-guide.pdf', size: 4096, url: null },
    ],
    status: 'matched', selectedLogoId: 'logo', message: matched.message,
  })
  assert.equal(JSON.stringify(stored).includes('original'), false)
  assert.equal(JSON.stringify(stored).includes('vision'), false)
  for (const status of ['no-match', 'documents-only', 'failed']) {
    assert.equal(storableBrandUploads({ ...matched, status }).status, status)
  }
})

test('nothing is kept before the first upload or while an analysis is still running', () => {
  assert.equal(storableBrandUploads(emptyBrandUploads()), null)
  assert.equal(storableBrandUploads({ ...matched, files: [] }), null)
  assert.equal(storableBrandUploads({ ...matched, status: 'processing' }), null)
  assert.equal(storableBrandUploads({ ...matched, status: 'idle' }), null)
})

test('optional categories round-trip independently without retaining session image copies', () => {
  const categorized = { ...matched, files: [{ ...logo, docType: 'Logo' }, photo, { ...guide, docType: 'Brand style' }] }
  const restored = restoreBrandUploads(JSON.parse(JSON.stringify(storableBrandUploads(categorized))))
  assert.deepEqual(restored.files.map(file => file.docType), ['Logo', undefined, 'Brand style'])
  assert.equal(restored.selectedLogoId, 'logo')
  assert.equal(restored.files[0].url, logo.url)
  assert.equal('originalUrl' in restored.files[0], false)
  assert.equal('visionDataUrl' in restored.files[0], false)
})

test('legacy, blank, malformed, and unknown categories keep the asset without classifying it', () => {
  for (const docType of [undefined, '', null, 42, {}, 'Other', 'Future category']) {
    const restored = restoreBrandUploads({ ...matched, files: [{ ...logo, docType }] })
    assert.equal(restored.files.length, 1)
    assert.equal('docType' in restored.files[0], false)
    assert.equal(restored.selectedLogoId, 'logo')
  }
})

test('resuming restores the same files and outcome, with Next enabled by a settled status', () => {
  const restored = restoreBrandUploads(JSON.parse(JSON.stringify(storableBrandUploads(matched))))
  assert.deepEqual(restored, {
    files: [
      { id: 'logo', name: 'acme.png', size: 2048, url: 'data:image/png;base64,kept' },
      { id: 'photo', name: 'team.jpg', size: 900000, url: 'data:image/jpeg;base64,smaller' },
      { id: 'guide', name: 'brand-guide.pdf', size: 4096, url: null },
    ],
    status: 'matched', selectedLogoId: 'logo', message: matched.message,
  })
  assert.notEqual(restored.status, 'idle')
  assert.notEqual(restored.status, 'processing')
})

test('unreadable records restore as no uploads instead of breaking the step', () => {
  for (const stored of [undefined, null, 'x', [], {}, { files: 'x', status: 'matched' }, { files: [], status: 'matched' },
    { files: [logo], status: 'processing' }, { files: [logo], status: 'idle' }, { files: [logo], status: 'later' }]) {
    assert.deepEqual(restoreBrandUploads(stored), emptyBrandUploads())
  }
  const partlyBroken = restoreBrandUploads({
    files: [{ id: 'logo', name: 'acme.png', size: 2048, url: 'data:image/png;base64,kept' }, { id: 1 }, null, { id: 'x', name: 'y', size: '3', url: null }],
    status: 'no-match', selectedLogoId: 'gone', message: 42,
  })
  assert.deepEqual(partlyBroken, {
    files: [{ id: 'logo', name: 'acme.png', size: 2048, url: 'data:image/png;base64,kept' }],
    status: 'no-match', selectedLogoId: null, message: '',
  })
})

test('hydrated uploads are always distinct objects so the draft handshake can settle', () => {
  assert.notEqual(emptyBrandUploads(), emptyBrandUploads())
  assert.notEqual(restoreBrandUploads(undefined), restoreBrandUploads(undefined))
  const stored = storableBrandUploads(matched)
  assert.notEqual(restoreBrandUploads(stored), restoreBrandUploads(stored))
})

test('the logo checkbox follows the theme, so a logo replaced elsewhere no longer reads as picked here', () => {
  const picked = { logoFileName: 'acme.png', logoSize: 2048 }
  assert.equal(isSelectedBrandLogo(matched, logo, picked), true)
  assert.equal(isSelectedBrandLogo(matched, photo, picked), false)
  assert.equal(isSelectedBrandLogo({ selectedLogoId: null }, logo, picked), false)
  assert.equal(isSelectedBrandLogo(matched, logo, { logoFileName: 'default-brand-logo.svg', logoSize: 0 }), false)
  assert.equal(isSelectedBrandLogo(matched, logo, { logoFileName: null, logoSize: 0 }), false)
  assert.equal(isSelectedBrandLogo(matched, logo, { logoFileName: 'acme.png', logoSize: 4096 }), false)
})
