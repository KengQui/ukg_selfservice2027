import { demoScenario } from '@workspace/setup-shared/prototypes/branding-demo/demoScenarios'
import type { ThemeSetupState } from './SystemThemeSetup'

export const GLOBAL_SETUP_NOTICE_EVENT = 'branding-global-setup-notice'

/** Global Setup is outside this prototype; never invent a destination or publish a draft. */
export function showGlobalSetupPlaceholder(saved = false): void {
  if (!saved) return
  window.dispatchEvent(new CustomEvent(GLOBAL_SETUP_NOTICE_EVENT, {
    detail: 'Your progress is saved.',
  }))
}

/** Company Setup owns its own steps; only the validated scenario crosses this handoff. */
export function invitationSearch(search: string): string {
  const scenario = demoScenario(new URLSearchParams(search).get('demo'))
  return scenario ? `?${new URLSearchParams({ demo: scenario })}` : ''
}

export function allBrandingComplete(companies: { id: string }[], statuses: Record<string, string>): boolean {
  return companies.length > 0 && companies.every(company => statuses[company.id] === 'done')
}

/** Compare normalized state independent of property insertion order, including the Custom snapshot. */
function brandingSnapshot(value: unknown): string {
  return JSON.stringify(value, (_key, entry) =>
    entry && typeof entry === 'object' && !Array.isArray(entry)
      ? Object.fromEntries(Object.entries(entry).sort(([a], [b]) => a.localeCompare(b)))
      : entry)
}

/**
 * Back keeps edits separately before navigation can unmount/hydrate the editor.
 * No-op visits create no edit; reverting to live branding removes an earlier draft.
 * Persistence failures propagate so the caller can keep the editor and its current choices open.
 */
export function retainOwnBrandingEdit(
  draft: ThemeSetupState,
  saved: ThemeSetupState,
  hasExistingEdit: boolean,
  persist: (draft: ThemeSetupState | null) => void,
): boolean {
  const changed = brandingSnapshot(draft) !== brandingSnapshot(saved)
  if (changed) persist(draft)
  else if (hasExistingEdit) persist(null)
  return changed
}