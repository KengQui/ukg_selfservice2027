import test from 'node:test'
import assert from 'node:assert/strict'
import { invitationSearch, allBrandingComplete, showGlobalSetupPlaceholder, GLOBAL_SETUP_NOTICE_EVENT, retainOwnBrandingEdit } from './completionNavigation.ts'
import { persistBranding, persistBrandingDraft, persistBrandingEditDraft, persistSingleEditDraft, companySetupStatus, readBrandingStore } from './brandingStorage.ts'

test('invitation handoff keeps only a validated demo, never wizard parameters or hashes', () => {
  assert.equal(invitationSearch('?demo=new-multi&page=login&companies=acme-services&fresh=1&returning=1&standalone=1'), '?demo=new-multi')
  assert.equal(invitationSearch('?demo=unknown&page=multi-ein'), '')
  assert.equal(invitationSearch('?page=completion'), '')
  assert.equal(invitationSearch('?demo=returning-single'), '?demo=returning-single')
})

test('completion requires every company confirmed, including after reload and last-company apply', () => {
  const companies = [{ id: 'one' }, { id: 'two' }, { id: 'three' }]
  let raw = null
  const storage = { getItem: () => raw, setItem: (_key, value) => { raw = value } }
  const complete = () => {
    const store = readBrandingStore(raw)
    return allBrandingComplete(companies, Object.fromEntries(companies.map(c => [c.id, companySetupStatus(store, c.id)])))
  }
  assert.equal(complete(), false)
  persistBranding(storage, { one: { primaryColor: '#123456' } })
  persistBrandingDraft(storage, 'two', { primaryColor: '#123456' })
  assert.equal(complete(), false)
  persistBranding(storage, { two: { primaryColor: '#123456' } })
  assert.equal(complete(), false)
  const before = raw
  assert.throws(() => persistBranding({ ...storage, setItem: () => { throw Error('Full') } }, { three: { primaryColor: '#123456' } }))
  assert.equal(raw, before)
  assert.equal(complete(), false)
  persistBranding(storage, { three: { primaryColor: '#123456' } })
  assert.equal(complete(), true)
  assert.equal(allBrandingComplete([], {}), false)
})

test('Global Setup placeholders stay put and only saved progress emits feedback', () => {
  const original = Object.getOwnPropertyDescriptor(globalThis, 'window')
  const notices = []
  Object.defineProperty(globalThis, 'window', { configurable: true, value: {
    dispatchEvent(event) {
      assert.equal(event.type, GLOBAL_SETUP_NOTICE_EVENT)
      notices.push(event.detail)
      return true
    },
    get location() { throw new Error('Global Setup must not navigate') },
    get localStorage() { throw new Error('An exit notice must not change saved branding') },
  } })
  try {
    showGlobalSetupPlaceholder()
    assert.equal(notices.length, 0)
    showGlobalSetupPlaceholder(true)
    assert.deepEqual(notices, ['Your progress is saved.'])
  } finally {
    if (original) Object.defineProperty(globalThis, 'window', original)
    else delete globalThis.window
  }
})

test('Back retains company edits for list/summary reentry without publishing or revising', () => {
  const values = new Map()
  const storage = {
    getItem: key => values.get(key) ?? null,
    setItem: (key, value) => values.set(key, value),
    removeItem: key => values.delete(key),
  }
  const key = 'company-branding'
  const saved = { primaryColor: '#123456', accentColor: '#abcdef', loginTagline: 'Company' }
  const draft = { ...saved, primaryColor: '#654321' }
  persistBranding(storage, { company: saved }, key, { actor: 'Admin', savedAt: '2026-09-01T00:00:00.000Z' })
  const before = readBrandingStore(storage.getItem(key))
  const persist = next => persistBrandingEditDraft(storage, 'company', next, key)
  assert.equal(retainOwnBrandingEdit({ ...saved }, saved, false, persist), false)
  assert.deepEqual(readBrandingStore(storage.getItem(key)).editDrafts, {})
  assert.equal(retainOwnBrandingEdit(draft, saved, false, persist), true)
  const after = readBrandingStore(storage.getItem(key))
  assert.deepEqual(after.editDrafts.company, draft)
  for (const field of ['themes', 'savedIds', 'revisions', 'completions', 'drafts']) {
    assert.deepEqual(after[field], before[field])
  }
  assert.equal(retainOwnBrandingEdit(saved, saved, true, persist), false)
  assert.deepEqual(readBrandingStore(storage.getItem(key)).editDrafts, {})
})

test('Back retains single-company summary/completion edits, but unchanged visits do not create edits', () => {
  const saved = { primaryColor: '#123456', customPalette: { primaryColor: '#123456', accentColor: '#abcdef' } }
  const key = 'single'
  const values = new Map([[key, JSON.stringify(saved)], [`${key}:completion`, 'history'], ['confirmed', '1']])
  const storage = {
    getItem: key => values.get(key) ?? null,
    setItem: (key, value) => values.set(key, value),
    removeItem: key => values.delete(key),
  }
  const persist = next => persistSingleEditDraft(storage, key, next)
  const reordered = { customPalette: { accentColor: '#abcdef', primaryColor: '#123456' }, primaryColor: '#123456' }
  assert.equal(retainOwnBrandingEdit(reordered, saved, false, () => assert.fail('Unchanged edits must not write')), false)
  const draft = { ...saved, primaryColor: '#654321' }
  assert.equal(retainOwnBrandingEdit(draft, saved, false, persist), true)
  assert.deepEqual(JSON.parse(storage.getItem(`${key}:edit`)), draft)
  assert.equal(storage.getItem(key), JSON.stringify(saved))
  assert.equal(storage.getItem(`${key}:completion`), 'history')
  assert.equal(storage.getItem('confirmed'), '1')
  assert.equal(retainOwnBrandingEdit(saved, saved, true, persist), false)
  assert.equal(storage.getItem(`${key}:edit`), null)
})

test('Back persistence refusal propagates before navigation and keeps current choices', () => {
  const saved = { primaryColor: '#123456' }
  const draft = { primaryColor: '#654321' }
  let navigated = false
  assert.throws(() => {
    retainOwnBrandingEdit(draft, saved, false, () => { throw new Error('Storage full') })
    navigated = true
  }, /Storage full/)
  assert.equal(navigated, false)
  assert.equal(draft.primaryColor, '#654321')
  assert.equal(saved.primaryColor, '#123456')
})