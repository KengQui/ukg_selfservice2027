import { useCallback, useEffect, useId, useMemo, useRef, useState } from 'react'
import type { SetStateAction } from 'react'
import { Button, InlineMessage } from '@ready/dls/compatibility'
import type { ThemeSetupState } from './SystemThemeSetup'
import BrandingCopyReview from './BrandingCopyReview'
import CopyBrandingIllustration from './CopyBrandingIllustration'
import CopySourceDialog from './CopySourceDialog'
import CompanySetupStatusTag, { CompanyRevisionText } from './CompanySetupStatusTag'
import './multiEinSelection.css'
import { copySources, prepareReviewedBranding } from './copyBrandingState'
import type { CompanySummary, ThemeMap, ReviewedBranding } from './copyBrandingState'
import type { BrandingCompletion, BrandingRevision, CompanySetupStatus } from './brandingStorage'
import { clearPendingCopyEdit, readPendingCopyEdit, writePendingCopyEdit } from './copyEditSession'
import type { CopyEditorState } from './copyEditSession'
import CompletionActions from './CompletionActions'
import { allBrandingComplete } from './completionNavigation'
import { useAskBrytePage } from '@workspace/setup-shared/ask-bryte'

/** Once branding is saved, both list routes show What's next, with unfinished companies first. */
export default function CopyBranding({ companies, sourceId, lastAppliedSourceId = '', themes, fallbackData, error, unconfirmedIds = [], statuses, editDrafts, pendingCopyKey, listPage, heading = "What's next?", intro, updatedCompanyId, revisions, completions, onBeginEdit, onDiscardEdit, onSaveLaterChange, onSaveLaterEdit, onApply, onCreateNew, onContinueSetup, onEditCompleted, onDone, onSaveSource }: {
  /** The company catalog the prototype was opened with: every card, source, and destination comes from it. */
  companies: CompanySummary[]
  /** Preferred company for the preview; only confirmed themes qualify as copy sources. */
  sourceId: string
  lastAppliedSourceId?: string
  themes: ThemeMap
  fallbackData: ThemeSetupState
  error: string
  unconfirmedIds?: string[]
  statuses: Record<string, CompanySetupStatus>
  editDrafts: ThemeMap
  updatedCompanyId?: string
  revisions: Record<string, BrandingRevision>
  completions: Record<string, BrandingCompletion>
  onBeginEdit: () => void
  onDiscardEdit: (id: string) => boolean
  onSaveLaterChange?: (saveLater: (() => void) | null) => void
  onSaveLaterEdit: (id: string, draft: ThemeSetupState) => void
  pendingCopyKey: string
  listPage: 'multi-ein' | 'copy-branding'
  /** The page title; Select a company shows the same list under its own. */
  heading?: string
  /** The intro shown while companies remain; once all are complete the shared all-done line takes over. */
  intro?: string
  /** Saves the copy; true once it is stored, so the list comes back (a copy onto a completed company changes no card). */
  onApply: (sourceId: string, ids: string[], reviewed: ReviewedBranding) => boolean
  onCreateNew: (id: string) => void
  /** Reopens an in-process company's own draft instead of starting a fresh look. */
  onContinueSetup: (id: string) => void
  /** Takes over a completed company's Edit (a returning customer opens its saved look first); without it the edit runs inline here. */
  onEditCompleted?: (id: string) => void
  onDone: () => void
  onSaveSource: (id: string, draft: ThemeSetupState) => boolean
}) {
  const allComplete = allBrandingComplete(companies, statuses)
  useAskBrytePage(listPage === 'copy-branding' ? 'copy-branding' : 'company-list', {
    companies: companies.length,
    savedCompanies: companies.filter(company => themes[company.id]).length,
    editsInProcess: Object.keys(editDrafts).length,
    allComplete,
  })
  const sources = useMemo(
    () => copySources(themes, companies, '', fallbackData),
    [themes, companies, sourceId, fallbackData],
  )
  const [restoredEdit] = useState(() => {
    const pending = readPendingCopyEdit(pendingCopyKey)
    return pending?.page === listPage && pending.listSourceId === sourceId
      && companies.some(company => company.id === pending.targetId)
      && sources.some(source => source.company.id === pending.sourceId) ? pending : null
  })
  // Copying targets exactly one company: the card whose Copy action was chosen.
  const [targetId, setTargetId] = useState<string | null>(restoredEdit?.targetId ?? null)
  const groupLabelId = useId()
  const selected = targetId ? [targetId] : []
  const [reviewingCompanyId, setReviewingCompanyId] = useState<string | null>(null)
  const [reviewed, setReviewed] = useState<(ThemeSetupState & ReviewedBranding) | null>(null)
  const [copyEdit, setCopyEdit] = useState<CopyEditorState | null>(() =>
    restoredEdit ? { step: restoredEdit.step, draft: restoredEdit.draft } : null)
  const copyEditRef = useRef(copyEdit)
  const [copyEditWarning, setCopyEditWarning] = useState('')
  // Keep the validated recovery record on a surviving step too. This writes only
  // per-tab pending work, never saved branding or a company's completion history.
  useEffect(() => {
    if (restoredEdit && !writePendingCopyEdit(pendingCopyKey, restoredEdit)) {
      setCopyEditWarning('We can’t keep these copy edits if you reload or leave the page. Apply branding before you go so they aren’t lost.')
    }
  }, [restoredEdit, pendingCopyKey])
  // Copy branding on a card opens a dialog asking which company to copy from; this is the card's company while it is open.
  const [choosingForId, setChoosingForId] = useState<string | null>(null)
  const closeSourceDialog = useCallback(() => setChoosingForId(null), [])
  // The dialog preselects the company last copied from; before any pick, the page's own company.
  const [pickedSourceId, setPickedSourceId] = useState(restoredEdit?.sourceId ?? (sourceId || lastAppliedSourceId))
  const chosenSource = sources.find(source => source.company.id === pickedSourceId)
    ?? sources.find(source => source.company.id === sourceId)
    ?? sources[0]
  const source = chosenSource?.company ?? companies.find(company => company.id === sourceId) ?? companies[0]
  const chosenSourceId = source.id
  const data: ThemeSetupState = chosenSource?.theme ?? fallbackData
  const target = companies.find(company => company.id === targetId)
  const unfinished = companies.filter(company => statuses[company.id] !== 'done')
  const completed = companies.filter(company => statuses[company.id] === 'done')
  const choosingFor = companies.find(company => company.id === choosingForId) ?? null
  // A company can be copied to from any other source; a completed company is never offered as its own source.
  const sourcesFor = (targetCompanyId: string) => sources.filter(item => item.company.id !== targetCompanyId)
  const clearCopyEdit = () => {
    copyEditRef.current = null
    setCopyEdit(null)
    setCopyEditWarning(clearPendingCopyEdit(pendingCopyKey) ? ''
      : 'We couldn’t clear your unfinished copy edits, so they may reopen if you reload the page. You can close them again then.')
  }
  const changeCopyEdit = (change: SetStateAction<CopyEditorState | null>) => {
    const next = typeof change === 'function' ? change(copyEditRef.current) : change
    if (!next) { clearCopyEdit(); return }
    copyEditRef.current = next
    setCopyEdit(next)
    const saved = targetId && writePendingCopyEdit(pendingCopyKey, {
      version: 1, page: listPage, listSourceId: sourceId, sourceId: chosenSourceId, targetId, ...next,
    })
    setCopyEditWarning(saved ? ''
      : 'We can’t keep these copy edits if you reload or leave the page. Apply branding before you go so they aren’t lost.')
  }
  const startReview = (companyId: string, fromId: string) => {
    const from = sources.find(item => item.company.id === fromId)
    const recipient = companies.find(company => company.id === companyId)
    if (!from || !recipient || fromId === companyId) return
    onBeginEdit()
    clearCopyEdit()
    setPickedSourceId(fromId)
    setChoosingForId(null)
    setTargetId(companyId)
    setReviewed(prepareReviewedBranding(from.theme, from.company.name, recipient.name))
  }
  // The same dialog serves the list's Copy branding actions and the review's Change action, so it stays
  // mounted (closed) behind both and hands focus back to whichever action opened it.
  const sourceDialog = <CopySourceDialog target={choosingFor} sources={choosingFor ? sourcesFor(choosingFor.id) : sources}
    replacesSaved={Boolean(choosingFor && themes[choosingFor.id])} initialSourceId={chosenSourceId}
    replacesEdit={Boolean(choosingFor && editDrafts[choosingFor.id])}
    onClose={closeSourceDialog}
    onConfirm={fromId => choosingFor && startReview(choosingFor.id, fromId)} />
  if (reviewingCompanyId && themes[reviewingCompanyId]) {
    return <BrandingCopyReview companies={companies} savedView startInEdit data={themes[reviewingCompanyId]} sourceId={reviewingCompanyId} selectedIds={[]} error={error}
      unfinishedEdit={editDrafts[reviewingCompanyId]} onDiscardEdit={() => onDiscardEdit(reviewingCompanyId)}
      onSaveLaterChange={onSaveLaterChange} onSaveLaterEdit={draft => onSaveLaterEdit(reviewingCompanyId, draft)}
      onBack={() => setReviewingCompanyId(null)} onApply={() => {}}
      onFinishEdit={draft => {
        if (onSaveSource(reviewingCompanyId, draft)) {
          setReviewed(null)
          setReviewingCompanyId(null)
        }
      }} />
  }
  if (targetId && target) {
    const reviewData = reviewed ?? prepareReviewedBranding(data, source.name, target.name)
    // Change reopens the dialog for the same company; confirming there swaps the reviewed branding to the new source.
    return <>
      <BrandingCopyReview companies={companies} data={reviewData} sourceId={chosenSourceId} selectedIds={selected} error={error}
        copyEdit={copyEdit} onCopyEditChange={changeCopyEdit} copyEditWarning={copyEditWarning}
        onChangeSource={sourcesFor(targetId).length > 1 ? () => setChoosingForId(targetId) : undefined}
        onFinishEdit={draft => {
          if (onApply(chosenSourceId, selected, draft)) {
            clearCopyEdit()
            setTargetId(null)
            setReviewed(null)
          }
        }}
        onBack={() => {
          clearCopyEdit()
          setTargetId(null)
          setReviewed(null)
        }}
        onApply={() => {
          if (onApply(chosenSourceId, selected, reviewData)) {
            clearCopyEdit()
            setTargetId(null)
            setReviewed(null)
          }
        }} />
      {sourceDialog}
    </>
  }
  return (
    <main className="ts-hero-grid ts-intro-grid ts-company-split ts-copy-intro">
      <div className="ts-hero-left">
        <div className="ts-hero-left-inner">
          <h1 className="text-display ts-headline">{heading}</h1>
           <p className="text-body ts-body-text">{allComplete
             ? 'All companies have saved branding. Edit a completed company, invite others to help, or return to Global Setup.'
            : intro ?? 'Copy saved branding to another company to save time, or set up its own branding. You can review each one before it’s saved.'}</p>
          {unconfirmedIds.length > 0 && <p className="text-caption">Earlier branding is still available, but its saved status cannot be confirmed. Review and save each company’s branding, or apply a copy, to confirm it.</p>}
          {/* Companies that still need branding come first: they are the ones to act on. Completed follows. */}
          {unfinished.length > 0 && <div className="ts-company-group" role="group" aria-labelledby={`${groupLabelId}-up-next`}>
          <h2 className="text-caption ts-eyebrow" id={`${groupLabelId}-up-next`}>Up next</h2>
          {unfinished.map(company => {
            const status = statuses[company.id] === 'in-process' ? 'in-process' : 'not-started'
            return <section key={company.id} className="ts-company-card ts-company-card--pending"
              aria-label={`Company without saved branding: ${company.name}`} data-testid={`card-pending-${company.id}`}>
              <div className="ts-company-card__details">
                <span className="ts-company-card__title">
                  <strong>{company.name}</strong>
                  <CompanySetupStatusTag status={status} companyId={company.id} />
                </span>
                <span className="text-caption">EIN: {company.ein}</span>
              </div>
              <div className="ts-company-card__actions">
                {sourcesFor(company.id).length > 0 && <Button size="small" iconLeftName="copy" aria-label={`Copy branding to ${company.name}`}
                  data-testid={`button-copy-${company.id}`}
                  onClick={() => setChoosingForId(company.id)} />}
                {/* Icon-only like Copy and Edit; the pencil stays reserved for completed companies. */}
                {status === 'in-process'
                  ? <Button variant="secondary" size="small" iconLeftName="arrowRight" title="Continue"
                    aria-label={`Continue setup for ${company.name}`}
                    onClick={() => onContinueSetup(company.id)} data-testid={`button-continue-setup-${company.id}`} />
                  : <Button variant="secondary" size="small" iconLeftName="plus" title="Set up"
                    aria-label={`Set up branding for ${company.name}`}
                    onClick={() => onCreateNew(company.id)} data-testid={`button-create-new-look-${company.id}`} />}
              </div>
            </section>
          })}
          </div>}
          {completed.length > 0 && <div className="ts-company-group" role="group" aria-labelledby={`${groupLabelId}-completed`}>
          <h2 className="text-caption ts-eyebrow" id={`${groupLabelId}-completed`}>Completed</h2>
          {/* A completed company carries the same actions: another company's branding can be copied over its own. */}
          {completed.map(company => <section key={company.id} className="ts-company-card" aria-label={`Completed company: ${company.name}`}>
            <div className="ts-company-card__details">
              <span className="ts-company-card__title">
                <strong>{company.name}</strong>
                   <CompanySetupStatusTag status="done" companyId={company.id} updated={updatedCompanyId === company.id} editInProcess={Boolean(editDrafts[company.id])} />
              </span>
              <span className="text-caption">EIN: {company.ein}</span>
                <CompanyRevisionText completion={completions[company.id]} revision={revisions[company.id]} updated={updatedCompanyId === company.id && !editDrafts[company.id]} />
            </div>
            <div className="ts-company-card__actions">
              {sourcesFor(company.id).length > 0 && <Button size="small" iconLeftName="copy" aria-label={`Copy branding to ${company.name}`}
                data-testid={`button-copy-${company.id}`}
                onClick={() => setChoosingForId(company.id)} />}
              <Button variant="secondary" size="small" iconLeftName="edit" aria-label={`Edit branding for ${company.name}`}
                data-testid={`button-edit-${company.id}`}
                 onClick={() => { onBeginEdit(); if (onEditCompleted) onEditCompleted(company.id); else setReviewingCompanyId(company.id) }} />
            </div>
          </section>)}
          </div>}
          {error && <InlineMessage theme="error">{error}</InlineMessage>}
          {copyEditWarning && <InlineMessage theme="warning">{copyEditWarning}</InlineMessage>}
          <div className="ts-actions-row">
             {allComplete ? <CompletionActions /> : <Button variant="secondary" onClick={onDone} data-testid="button-done-for-today">Return to Global Setup</Button>}
          </div>
          {sourceDialog}
        </div>
      </div>

      <div className="ts-hero-right">
        <div className="ts-copy-intro-stack">
          <figure className="ts-copy-figure" data-testid="card-copy-source">
            <CopyBrandingIllustration data={data} preview={!themes[chosenSourceId]} />
            <figcaption><strong>{source.name}</strong></figcaption>
          </figure>
          {companies.filter(company => company.id !== source.id).map(company => (
                <figure key={company.id} className="ts-copy-figure" data-testid={`card-copy-pending-${company.id}`}>
                  <CopyBrandingIllustration data={themes[company.id] ?? data} pending={!themes[company.id]} />
                  <figcaption><strong>{company.name}</strong></figcaption>
                </figure>
          ))}
        </div>
      </div>
    </main>
  )
}
