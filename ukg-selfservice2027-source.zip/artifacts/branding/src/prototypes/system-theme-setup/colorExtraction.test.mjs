import test from 'node:test'
import assert from 'node:assert/strict'
import { extractDominantColors, logoColorUpdates } from './colorExtraction.ts'
import { customSnapshot, selectPalette, updateThemeSetup } from './palettes.ts'
import { restoreThemeSetup } from './savedState.ts'

const custom = {
  primaryColor: '#123456', accentColor: '#ABCDEF', lightView: true,
  contrastSourceColor: '#567890', colorsExtractedFromLogo: true, selectedPalette: 'Custom',
}

test('a logo without usable colors retains live colors and Custom comparison choices but clears old provenance', () => {
  for (const state of [custom, updateThemeSetup(custom, selectPalette(custom, 'Navy'))]) {
    const next = updateThemeSetup(state, logoColorUpdates(state, null))
    assert.equal(next.primaryColor, state.primaryColor)
    assert.equal(next.accentColor, state.accentColor)
    assert.equal(next.selectedPalette, state.selectedPalette)
    assert.equal(next.lightView, state.lightView)
    assert.equal(next.contrastSourceColor, state.contrastSourceColor)
    assert.equal(next.colorsExtractedFromLogo, false)
    const retainedCustom = updateThemeSetup(next, selectPalette(next, 'Custom'))
    assert.deepEqual(customSnapshot(retainedCustom), { ...customSnapshot(custom), colorsExtractedFromLogo: false })
    const restored = restoreThemeSetup(JSON.stringify(next), custom)
    assert.equal(restored.customPalette.colorsExtractedFromLogo, false)
  }
})

test('usable logo colors replace the visible palette as Custom without retaining an old comparison source', () => {
  const named = updateThemeSetup(custom, selectPalette(custom, 'Navy'))
  const next = updateThemeSetup(named, logoColorUpdates(named, { primary: '#008080', accent: '#F09020' }))
  assert.equal(next.selectedPalette, 'Custom')
  assert.equal(next.primaryColor, '#008080')
  assert.equal(next.accentColor, '#F09020')
  assert.equal(next.colorsExtractedFromLogo, true)
  assert.equal(next.customPalette.colorsExtractedFromLogo, true)
  assert.equal(next.contrastSourceColor, null)
})

async function withImageEnvironment({ pixels = [], decodeFailure = false, canvasFailure = false }, run) {
  const image = globalThis.Image
  const document = globalThis.document
  globalThis.Image = class {
    width = 2
    height = 1
    set src(_value) { queueMicrotask(() => decodeFailure ? this.onerror() : this.onload()) }
  }
  globalThis.document = {
    createElement: () => ({
      getContext: () => ({
        drawImage() {},
        getImageData: () => {
          if (canvasFailure) throw new Error('Unreadable pixels')
          return { data: new Uint8ClampedArray(pixels) }
        },
      }),
    }),
  }
  try { await run() } finally {
    if (image === undefined) delete globalThis.Image
    else globalThis.Image = image
    if (document === undefined) delete globalThis.document
    else globalThis.document = document
  }
}

test('decoded white and transparent logos are accepted with no extracted colors', async () => {
  for (const pixels of [[255, 255, 255, 255], [100, 30, 40, 0], [250, 250, 250, 255, 0, 0, 0, 100]]) {
    await withImageEnvironment({ pixels }, async () => {
      assert.equal(await extractDominantColors('data:image/png;base64,white-or-transparent'), null)
    })
  }
})

test('decodable visible pixels produce deterministic starting colors', async () => {
  await withImageEnvironment({ pixels: [4, 100, 150, 255, 220, 90, 32, 255] }, async () => {
    assert.deepEqual(await extractDominantColors('data:image/webp;base64,colors'), { primary: '#006090', accent: '#D05020' })
  })
})

test('corrupt files and unreadable pixels reject rather than masquerading as no-color logos', async () => {
  await withImageEnvironment({ decodeFailure: true }, async () => {
    await assert.rejects(extractDominantColors('data:image/svg+xml,damaged'), /Could not open image/)
  })
  await withImageEnvironment({ canvasFailure: true }, async () => {
    await assert.rejects(extractDominantColors('data:image/png;base64,damaged'), /Unreadable pixels/)
  })
})