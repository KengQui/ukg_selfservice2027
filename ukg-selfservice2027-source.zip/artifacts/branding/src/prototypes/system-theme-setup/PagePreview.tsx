import type { ThemeSetupState } from './SystemThemeSetup'
import HeaderPreview from './HeaderPreview'

/** The themed header over a page skeleton with the accent color: the "header" preview shared by Theme and copy review. */
export default function PagePreview({ data }: { data: ThemeSetupState }) {
  return (
    <div className="theme-setup-preview-card">
      <HeaderPreview data={data} />
      <div className="theme-setup-preview-body ts-accent-preview-body">
        <div className="ts-preview-columns" aria-hidden="true">
          {[0, 1].map(column => (
            <div key={column}>
              {(column === 0 ? [80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 50] : [80, 80, 80, 80, 50]).map((width, index) => (
                <div key={index} className="theme-setup-preview-skeleton-line" style={{ width: `${width}%` }} />
              ))}
            </div>
          ))}
        </div>
        <div className="ts-accent-circles" style={{ color: data.accentColor }} aria-hidden="true">
          <span className="ts-accent-circle-large" />
          <span className="ts-accent-circle-small" />
        </div>
      </div>
    </div>
  )
}
