import type { ThemeSetupState } from './SystemThemeSetup'

export const BRAND_IMAGE_EXTENSIONS = ['png', 'jpg', 'jpeg', 'svg', 'webp'] as const
export const BRAND_IMAGE_ACCEPT = BRAND_IMAGE_EXTENSIONS.map(extension => `.${extension}`).join(',')
export const BRAND_ASSET_ACCEPT = `${BRAND_IMAGE_ACCEPT},.pdf`
export const BRAND_IMAGE_FORMATS = 'PNG, JPG, SVG or WebP'
export const BRAND_ASSET_FORMATS = 'PNG, JPG, SVG, WebP or PDF'

export function brandImageMime(name: string): string | undefined {
  switch (name.split('.').pop()?.toLowerCase()) {
    case 'png': return 'image/png'
    case 'jpg':
    case 'jpeg': return 'image/jpeg'
    case 'svg': return 'image/svg+xml'
    case 'webp': return 'image/webp'
    default: return undefined
  }
}

export const isBrandImage = (file: Pick<File, 'name'>) => brandImageMime(file.name) !== undefined
export const isBrandAsset = (file: Pick<File, 'name'>) =>
  isBrandImage(file) || file.name.split('.').pop()?.toLowerCase() === 'pdf'

export type BrandAnalysisStatus = 'idle' | 'processing' | 'matched' | 'no-match' | 'documents-only' | 'failed'
/** Only settled outcomes are kept with a draft; an analysis in progress keeps the previous record. */
export type StoredBrandAnalysisStatus = Exclude<BrandAnalysisStatus, 'idle' | 'processing'>
const STORED_STATUSES: readonly string[] = ['matched', 'no-match', 'documents-only', 'failed']

/** One brand asset as kept with a company's draft. Documents have no image; images keep a size-bounded copy. */
export const BRAND_DOCUMENT_TYPES = ['', 'Logo', 'Brand style'] as const
export type BrandDocumentType = 'Logo' | 'Brand style'
export function brandDocumentType(value: unknown): BrandDocumentType | undefined {
  return value === 'Logo' || value === 'Brand style' ? value : undefined
}
export type StoredBrandFile = { id: string; name: string; size: number; url: string | null; docType?: BrandDocumentType }
export type StoredBrandUploads = {
  files: StoredBrandFile[]
  status: StoredBrandAnalysisStatus
  message: string
  selectedLogoId: string | null
}

/** Session-only extras: the original upload gives a full-quality logo; the vision copy is what analysis receives. */
export type BrandFile = StoredBrandFile & { originalUrl?: string; visionDataUrl?: string }
export type BrandUploads = {
  files: BrandFile[]
  status: BrandAnalysisStatus
  message: string
  selectedLogoId: string | null
}

/** Always a new object: the draft-sync handshake recognises hydrated state by identity, so a shared constant would never settle. */
export function emptyBrandUploads(): BrandUploads {
  return { files: [], status: 'idle', message: '', selectedLogoId: null }
}

function isStoredStatus(value: unknown): value is StoredBrandAnalysisStatus {
  return typeof value === 'string' && STORED_STATUSES.includes(value)
}

function isStoredBrandFile(value: unknown): value is StoredBrandFile {
  if (!value || typeof value !== 'object') return false
  const file = value as Record<string, unknown>
  return typeof file.id === 'string' && typeof file.name === 'string' && typeof file.size === 'number'
    && (file.url === null || typeof file.url === 'string')
}

/** The draft-sized record for the current uploads, or null when there is nothing settled to keep. */
export function storableBrandUploads(uploads: BrandUploads): StoredBrandUploads | null {
  if (!uploads.files.length || !isStoredStatus(uploads.status)) return null
  return {
    files: uploads.files.map(storedBrandFile),
    status: uploads.status,
    message: uploads.message,
    selectedLogoId: uploads.selectedLogoId,
  }
}

/** Rebuilds the brand step from a stored record; anything unreadable restores as no uploads. */
export function restoreBrandUploads(stored: unknown): BrandUploads {
  if (!stored || typeof stored !== 'object' || Array.isArray(stored)) return emptyBrandUploads()
  const record = stored as Record<string, unknown>
  if (!Array.isArray(record.files) || !isStoredStatus(record.status)) return emptyBrandUploads()
  const files = record.files.filter(isStoredBrandFile).map(storedBrandFile)
  if (!files.length) return emptyBrandUploads()
  const selectedLogoId = typeof record.selectedLogoId === 'string' && files.some(file => file.id === record.selectedLogoId)
    ? record.selectedLogoId
    : null
  return { files, status: record.status, message: typeof record.message === 'string' ? record.message : '', selectedLogoId }
}

/** Unknown or legacy categories do not discard the asset or invent a classification. */
function storedBrandFile({ id, name, size, url, docType }: StoredBrandFile): StoredBrandFile {
  const category = brandDocumentType(docType)
  return { id, name, size, url, ...(category ? { docType: category } : {}) }
}

/** A pick made on the brand step stays checked only while that file is still the theme's logo. */
export function isSelectedBrandLogo(
  uploads: Pick<BrandUploads, 'selectedLogoId'>,
  file: StoredBrandFile,
  theme: Pick<ThemeSetupState, 'logoFileName' | 'logoSize'>,
): boolean {
  return uploads.selectedLogoId === file.id && theme.logoFileName === file.name && theme.logoSize === file.size
}
