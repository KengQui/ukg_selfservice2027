import type { ThemeSetupState } from './SystemThemeSetup'
import { customSnapshot, hasCompanyColors, PRESET_PALETTES } from './palettes.ts'

export function restoreThemeSetup(saved: string, defaults: ThemeSetupState): ThemeSetupState {
  // Defaults fill missing fields; explicit nulls preserve a user's removed logo.
  const parsed = JSON.parse(saved)
  const restored: ThemeSetupState = { ...defaults, ...parsed }
  if (restored.logoFileName === 'acme-logo-sample.svg') {
    restored.logoUrl = defaults.logoUrl
    restored.logoFileName = defaults.logoFileName
    restored.logoSize = defaults.logoSize
  }
  if (['Company name', 'ACME CORP', 'Acai Bowl Bar'].includes(restored.loginTagline)) {
    restored.loginTagline = defaults.loginTagline
  }
  // Refresh the old sample copy without replacing a user's custom message.
  if (restored.employeeLoginMessage === 'Welcome to Acme Corp. Sign in with your company credentials.'
    || restored.employeeLoginMessage === 'Welcome to ACME\nIf you have any issues logging in, please get in touch with our support team:\n\nEmail: support@acme.com\nPhone: (555) 555-5555'
    || restored.employeeLoginMessage === 'Welcome to ABC Company!\nIf you have any issues logging in, please get in touch with our support team:\n\nEmail: helpmeloginplease@ukg.com\nPhone: (555) 555-5555'
    || restored.employeeLoginMessage === 'Welcome to ACME Company!\nIf you have any issues logging in, please get in touch with our support team:\n\nEmail: helpmeloginplease@ukg.com\nPhone: (555) 555-5555'
    || restored.employeeLoginMessage === 'Welcome to ACME Company!\nIf you have any issues logging in, please get in touch with our support team:\n\nEmail: support@acme.com\nPhone: (555) 555-5555') {
    restored.employeeLoginMessage = defaults.employeeLoginMessage
  }
  const preset = PRESET_PALETTES.find(palette => palette.name === parsed.selectedPalette)
  // Never infer identity from legacy color values or discard saved edits.
  restored.selectedPalette = preset
    && preset.primaryColor.toUpperCase() === restored.primaryColor.toUpperCase()
    && preset.accentColor.toUpperCase() === restored.accentColor.toUpperCase()
    ? preset.name : 'Custom'
  if (restored.selectedPalette === 'Custom') restored.customPalette = customSnapshot(restored)
  else {
    restored.colorsExtractedFromLogo = false
    restored.customPalette ??= customSnapshot(defaults)
  }
  restored.customColors = typeof parsed.customColors === 'boolean'
    ? parsed.customColors || restored.selectedPalette === 'Custom' && parsed.selectedPalette !== 'Custom'
    : hasCompanyColors({ ...restored, customColors: undefined })
  return restored
}
