import { brandImageMime } from './brandUploads.ts'

const MAX_VISION_EDGE = 1024
const MAX_VISION_DATA_URL_LENGTH = 1_300_000

/** About 300 KB per image: five kept uploads plus the draft stay well inside browser storage. */
export const MAX_STORED_IMAGE_LENGTH = 400_000
// A transparent PNG keeps a logo's background; photos that still do not fit fall back to JPEG on white.
const STORED_IMAGE_ATTEMPTS: { edge: number; type: 'image/png' | 'image/jpeg'; quality?: number }[] = [
  { edge: 640, type: 'image/png' },
  { edge: 640, type: 'image/jpeg', quality: 0.8 },
  { edge: 480, type: 'image/jpeg', quality: 0.6 },
]

export function readAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onerror = () => reject(new Error('Could not read file'))
    reader.onload = () => {
      const url = reader.result as string
      // Some drag-and-drop sources omit the MIME type. Decoding still checks the actual bytes.
      const mime = brandImageMime(file.name)
      resolve(mime ? url.replace(/^data:[^;,]*/, `data:${mime}`) : url)
    }
    reader.readAsDataURL(file)
  })
}

export function decodeImage(dataUrl: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image()
    image.onload = () => resolve(image)
    image.onerror = () => reject(new Error('Could not open image'))
    image.src = dataUrl
  })
}

function drawScaled(
  image: HTMLImageElement,
  maxEdge: number,
  type: 'image/png' | 'image/jpeg',
  quality: number | undefined,
  whiteBackground: boolean,
): string {
  const scale = Math.min(1, maxEdge / Math.max(image.naturalWidth, image.naturalHeight))
  const canvas = document.createElement('canvas')
  canvas.width = Math.max(1, Math.round(image.naturalWidth * scale))
  canvas.height = Math.max(1, Math.round(image.naturalHeight * scale))
  const context = canvas.getContext('2d')
  if (!context) throw new Error('Could not prepare image')
  if (whiteBackground || type === 'image/jpeg') {
    context.fillStyle = '#ffffff'
    context.fillRect(0, 0, canvas.width, canvas.height)
  }
  context.drawImage(image, 0, 0, canvas.width, canvas.height)
  return canvas.toDataURL(type, quality)
}

/** The copy sent to logo analysis: bounded in size, always on a white background. */
export async function makeVisionImage(dataUrl: string): Promise<string> {
  const image = await decodeImage(dataUrl)
  const preferPng = /^data:image\/(png|svg\+xml)[;,]/.test(dataUrl)
  let result = drawScaled(image, MAX_VISION_EDGE, preferPng ? 'image/png' : 'image/jpeg', 0.82, true)
  if (result.length > MAX_VISION_DATA_URL_LENGTH) {
    result = drawScaled(image, MAX_VISION_EDGE, 'image/jpeg', 0.68, true)
  }
  if (result.length > MAX_VISION_DATA_URL_LENGTH) {
    throw new Error('Prepared image is too large')
  }
  return result
}

/** The copy kept with a company's draft: the original when it is small enough, otherwise a reduced version. */
export async function makeStoredImage(originalUrl: string): Promise<string> {
  if (originalUrl.length <= MAX_STORED_IMAGE_LENGTH) return originalUrl
  const image = await decodeImage(originalUrl)
  for (const attempt of STORED_IMAGE_ATTEMPTS) {
    const result = drawScaled(image, attempt.edge, attempt.type, attempt.quality, false)
    if (result.length <= MAX_STORED_IMAGE_LENGTH) return result
  }
  throw new Error('Image is too large to keep with the setup')
}
