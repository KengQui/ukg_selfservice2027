import assert from 'node:assert/strict'
import test from 'node:test'
import { copyEditSessionKey, readPendingCopyEdit, writePendingCopyEdit, clearPendingCopyEdit } from './copyEditSession.ts'
import { brandingStorageKeys } from '../../../../../lib/setup-shared/src/prototypes/branding-demo/demoScenarios.ts'

const draft = { primaryColor: '#123456', accentColor: '#abcdef', loginTagline: 'Recipient', employeeLoginMessage: 'Edited text' }
const edit = { version: 1, page: 'multi-ein', listSourceId: '', sourceId: 'one', targetId: 'two', step: 'login', draft }

test('copy editor recovers last values and step in its own scenario without saving branding', () => {
  const values = new Map()
  const original = Object.getOwnPropertyDescriptor(globalThis, 'sessionStorage')
  Object.defineProperty(globalThis, 'sessionStorage', { configurable: true, value: {
    getItem: key => values.get(key) ?? null,
    setItem: (key, value) => values.set(key, value),
    removeItem: key => values.delete(key),
  } })
  try {
    const key = copyEditSessionKey(brandingStorageKeys('new-multi').companies)
    const otherKey = copyEditSessionKey(brandingStorageKeys('implementation-multi').companies)
    assert.equal(writePendingCopyEdit(key, edit), true)
    assert.deepEqual(readPendingCopyEdit(key), edit)
    assert.equal(readPendingCopyEdit(otherKey), null)
    assert.equal(values.size, 1)
    assert.equal(writePendingCopyEdit(key, { ...edit, step: 'advanced', draft: { ...draft, employeeLoginMessage: 'Latest keystroke' } }), true)
    assert.equal(readPendingCopyEdit(key).draft.employeeLoginMessage, 'Latest keystroke')
    assert.equal(readPendingCopyEdit(key).step, 'login')
    assert.equal(clearPendingCopyEdit(key), true)
    assert.equal(readPendingCopyEdit(key), null)
    for (const invalid of [null, [], { ...edit, version: 2 }, { ...edit, step: 'done' },
      { ...edit, targetId: 'one' }, { ...edit, page: 'saved-look' }, { ...edit, draft: {} }]) {
      values.set(key, JSON.stringify(invalid))
      assert.equal(readPendingCopyEdit(key), null)
    }
  } finally {
    if (original) Object.defineProperty(globalThis, 'sessionStorage', original)
    else delete globalThis.sessionStorage
  }
})

test('storage refusal is observable for write/discard, and never fabricates a recovered draft', () => {
  const original = Object.getOwnPropertyDescriptor(globalThis, 'sessionStorage')
  Object.defineProperty(globalThis, 'sessionStorage', { configurable: true, get() { throw new Error('Denied') } })
  try {
    assert.equal(readPendingCopyEdit('denied'), null)
    assert.equal(writePendingCopyEdit('denied', edit), false)
    assert.equal(clearPendingCopyEdit('denied'), false)
  } finally {
    if (original) Object.defineProperty(globalThis, 'sessionStorage', original)
    else delete globalThis.sessionStorage
  }
})