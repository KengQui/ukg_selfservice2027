import svg from './defaultBrandLogo.svg?raw'

export const SAMPLE_LOGO = {
  logoUrl: `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`,
  logoFileName: 'default-brand-logo.svg',
  logoSize: new TextEncoder().encode(svg).length,
}