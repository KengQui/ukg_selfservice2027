import HeaderPreview from './HeaderPreview'
import type { ThemeSetupState } from './SystemThemeSetup'

/** Decorative app window using the same visual language as the colors preview. */
export default function CopyBrandingIllustration({ data, pending = false, preview: isPreview = false }: {
  data: ThemeSetupState
  pending?: boolean
  preview?: boolean
}) {
  const preview = pending ? {
    ...data, logoUrl: null, primaryColor: '#737373', accentColor: '#cccccc',
    lightView: false, colorBehindLogo: false, headerClock: false,
  } : data
  return (
    <div className={`theme-setup-preview-card ts-copy-window${pending ? ' ts-copy-window-pending' : ''}`}>
      <HeaderPreview data={{ ...preview, headerClock: false }} />
      <div className="theme-setup-preview-body ts-accent-preview-body">
        <div className="ts-preview-columns">
          {[7, 5].map((count, column) => (
            <div key={column}>
              {Array.from({ length: count }, (_, index) => (
                <div key={index} className="theme-setup-preview-skeleton-line"
                  style={{ width: index === count - 1 ? '50%' : '80%' }} />
              ))}
            </div>
          ))}
        </div>
        <div className="ts-accent-circles" style={{ color: preview.accentColor }}>
          <span className="ts-accent-circle-large" />
          <span className="ts-accent-circle-small" />
        </div>
      </div>
      <span className={pending ? 'ts-copy-status-tag bg-[#474747] text-[#ffffff]' : 'ts-copy-status-tag pl-[12px] pr-[12px]'}
        style={pending ? { backgroundColor: '#474747', color: '#ffffff' } : { paddingLeft: 12, paddingRight: 12 }}>
        {pending ? 'No saved branding yet' : isPreview ? 'Preview — not saved' : 'Branding saved'}
      </span>
    </div>
  )
}