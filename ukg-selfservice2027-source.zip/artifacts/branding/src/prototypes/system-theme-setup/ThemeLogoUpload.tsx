import { useEffect, useRef, useState } from 'react'
import { Button, Dialog, InlineMessage } from '@ready/dls/compatibility'
import { DropZone } from '@workspace/setup-shared/prototypes/_shared/uploadFiles'
import type { ThemeSetupState } from './SystemThemeSetup'
import { SAMPLE_LOGO } from './sampleLogo'
import LogoBackgroundControl from './LogoBackgroundControl'
import { extractDominantColors, logoColorUpdates } from './colorExtraction'
import { BRAND_IMAGE_ACCEPT, BRAND_IMAGE_FORMATS, isBrandImage } from './brandUploads'
import { decodeImage, readAsDataUrl } from './brandImages'

export default function ThemeLogoUpload({ data, onUpdate, logoOnly = false }: {
  data: ThemeSetupState
  onUpdate: (updates: Partial<ThemeSetupState>) => void
  logoOnly?: boolean
}) {
  const [open, setOpen] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [pending, setPending] = useState<{ file: File; url: string } | null>(null)
  const version = useRef(0)
  useEffect(() => () => { version.current++ }, [])
  const hasLogo = !!data.logoUrl && data.logoUrl !== SAMPLE_LOGO.logoUrl
  const close = () => { version.current++; setOpen(false); setBusy(false); setPending(null) }
  const readFile = async (files: File[]) => {
    if (busy || !files.length) return
    if (files.length !== 1) { setError('Choose one logo image at a time.'); return }
    const file = files[0]
    if (!isBrandImage(file)) {
      setError(`Choose a ${BRAND_IMAGE_FORMATS} image.`); return
    }
    if (file.size > 2 * 1024 * 1024) { setError('Choose an image no larger than 2 MB.'); return }
    setError('')
    setBusy(true)
    const request = ++version.current
    try {
      const url = await readAsDataUrl(file)
      await decodeImage(url)
      if (version.current !== request) return
      setPending({ file, url })
      setBusy(false)
    } catch {
      if (version.current !== request) return
      setBusy(false)
      setError('We couldn’t open this image. It may be damaged. Export it again, or choose another file.')
    }
  }
  return (
    <section className="ts-card" style={{ marginBottom: 24 }} aria-label="Company logo">
      <h2 style={{ fontSize: 'var(--type-lg-size)', margin: '0 0 16px' }}>Company logo</h2>
      {hasLogo && <img src={data.logoUrl!} alt="Current company logo" style={{
        maxWidth: '100%', width: 'auto', height: 64, objectFit: 'contain', display: 'block', marginBottom: 12,
        background: hasLogo ? (data.colorBehindLogo ? data.logoBackgroundColor : 'transparent') : '#015151',
        border: data.colorBehindLogo ? `4px solid ${data.logoBackgroundColor}` : 'none',
        boxSizing: 'content-box',
      }} />}
      <Button variant="secondary" onClick={() => { setError(''); setOpen(true) }}>{hasLogo ? 'Update logo' : 'Upload logo'}</Button>
      {notice && <div style={{ marginTop: 12 }}><InlineMessage theme="info">{notice}</InlineMessage></div>}
      {!logoOnly && <>
        <hr style={{ border: 0, borderTop: '1px solid var(--color-border)', margin: '24px 0 0' }} />
        <LogoBackgroundControl data={data} onUpdate={onUpdate} />
      </>}
      <Dialog open={open} onClose={close} title={hasLogo ? 'Update company logo' : 'Upload company logo'} size="normal"
        secondaryAction={{ label: 'Cancel', onClick: close }}
        primaryAction={{ label: 'Use logo', disabled: !pending || busy, onClick: async () => {
          if (!pending || busy) return
          setBusy(true)
          const request = ++version.current
          try {
            const colors = await extractDominantColors(pending.url)
            if (version.current !== request) return
            onUpdate({
              logoUrl: pending.url, logoFileName: pending.file.name, logoSize: pending.file.size,
              isDocumentUpload: false, presetPalettesOnly: false,
              ...logoColorUpdates(data, colors),
            })
            setNotice(colors ? '' : 'Your logo is ready. We couldn’t pick colors from it, so your current colors are unchanged. Choose your colors below.')
            close()
          } catch {
            if (version.current !== request) return
            setBusy(false)
            setError('We couldn’t open this image. It may be damaged. Export it again, or choose another file.')
          }
        } }}>
        <p>Choose one logo image. We’ll suggest primary and accent colors when they’re available. Otherwise, your current colors stay unchanged. You can change them afterward.</p>
        <DropZone disabled={busy} multiple={false} accept={BRAND_IMAGE_ACCEPT}
          helperText={`One ${BRAND_IMAGE_FORMATS} image, up to 2 MB.`} onFiles={files => void readFile(files)} />
        {busy && <p role="status">Preparing logo and colors…</p>}
        {error && <InlineMessage theme="error">{error}</InlineMessage>}
        {pending && <div style={{ marginTop: 16, overflowWrap: 'anywhere' }}>
          <img src={pending.url} alt="New logo preview" style={{ width: 80, height: 80, objectFit: 'contain' }} />
          <p>{pending.file.name}</p>
          <Button variant="tertiary" disabled={busy} onClick={() => setPending(null)}>Remove selection</Button>
        </div>}
      </Dialog>
    </section>
  )
}