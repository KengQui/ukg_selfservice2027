// The Company Setup hub counts Branding's progress with a shared reader instead of importing Branding. These checks fail
// if that reader and Branding's own storage and status rules drift apart.
import assert from 'node:assert/strict'
import test from 'node:test'
import {
  DEMO_REVISION_ACTOR, companySetupStatus, persistBranding, persistBrandingDraft, persistBrandingEditDraft,
  persistBrandUploads, persistSingleBranding, persistSingleEditDraft, readBrandingStore,
} from './brandingStorage.ts'
import {
  brandingShare, demoCompanyStatuses, markSingleStepShown, singleStepShownKey,
} from '../../../../../lib/setup-shared/src/prototypes/branding-demo/brandingProgress.ts'
import {
  DEMO_COMPANY_IDS, DEMO_SCENARIOS, brandingStorageKeys, isMultiEinScenario, preparedBranding, resumesAtLogin,
} from '../../../../../lib/setup-shared/src/prototypes/branding-demo/demoScenarios.ts'

function memory() {
  const values = new Map()
  return {
    values,
    getItem: key => values.get(key) ?? null,
    setItem: (key, value) => { values.set(key, String(value)) },
    removeItem: key => { values.delete(key) },
  }
}

const theme = { primaryColor: '#123456', accentColor: '#abcdef', loginTagline: 'Acme' }
const draft = { ...theme, selectedPalette: 'Navy' }
const attribution = { actor: DEMO_REVISION_ACTOR, savedAt: '2026-09-14T13:30:00.000Z' }
const [holdings, services, retail] = DEMO_COMPANY_IDS
const scenarios = Object.keys(DEMO_SCENARIOS)
const multiScenarios = scenarios.filter(isMultiEinScenario)
const singleScenarios = scenarios.filter(scenario => !isMultiEinScenario(scenario))

/** Branding's own statuses for the stored companies; a store Branding cannot read shows every company not started. */
function brandingStatuses(raw) {
  let store
  try {
    store = readBrandingStore(raw)
  } catch {
    store = readBrandingStore(null)
  }
  return DEMO_COMPANY_IDS.map(id => companySetupStatus(store, id))
}

function assertParity(storage, scenario, label) {
  const raw = storage.getItem(brandingStorageKeys(scenario).companies)
  assert.deepEqual(demoCompanyStatuses(storage, scenario), brandingStatuses(raw), label)
}

test('multi EIN: the hub counts each company exactly as Branding tags it, through saves, drafts and edits', () => {
  for (const scenario of ['new-multi', 'returning-multi']) {
    const storage = memory()
    const key = brandingStorageKeys(scenario).companies
    const steps = [
      ['draft', () => persistBrandingDraft(storage, holdings, draft, key)],
      ['uploads only', () => persistBrandUploads(storage, retail, { files: [], status: 'idle', message: '' }, key)],
      ['save', () => persistBranding(storage, { [holdings]: theme }, key)],
      ['second draft', () => persistBrandingDraft(storage, services, draft, key)],
      ['edit of saved', () => persistBrandingEditDraft(storage, holdings, { ...theme, loginTagline: 'Unfinished edit' }, key)],
      ['draft after save is ignored', () => persistBrandingDraft(storage, holdings, draft, key)],
      ['save all', () => persistBranding(storage, { [services]: theme, [retail]: theme }, key)],
    ]
    for (const [label, step] of steps) {
      step()
      assertParity(storage, scenario, `${scenario}: ${label}`)
    }
    assert.equal(brandingShare(storage, scenario), 1)
  }
})

test('multi EIN: the share weights saved as whole and in process as half, and edits never lower it', () => {
  const storage = memory()
  const key = brandingStorageKeys('new-multi').companies
  assert.equal(brandingShare(storage, 'new-multi'), 0)
  persistBrandingDraft(storage, holdings, draft, key)
  assert.equal(brandingShare(storage, 'new-multi'), 0.5 / 3)
  persistBranding(storage, { [holdings]: theme }, key)
  assert.equal(brandingShare(storage, 'new-multi'), 1 / 3)
  persistBrandingEditDraft(storage, holdings, { ...theme, loginTagline: 'Unfinished edit' }, key)
  assert.equal(brandingShare(storage, 'new-multi'), 1 / 3)
  persistBrandingDraft(storage, services, draft, key)
  assert.equal(brandingShare(storage, 'new-multi'), 1.5 / 3)
})

test('multi EIN: legacy and tolerated records read like Branding; stores Branding rejects show nothing started', () => {
  const tolerated = [
    { [holdings]: theme },
    { version: 2, themes: { [holdings]: theme }, savedIds: [holdings, 7, 'unknown', retail] },
    { version: 2, themes: { [holdings]: theme, [services]: theme }, savedIds: [holdings], drafts: { [holdings]: draft } },
    '',
  ]
  const rejected = [
    [], 'text', { version: 2, themes: {}, savedIds: 'none' }, { version: 2, themes: [], savedIds: [] },
    { [holdings]: 'not a theme' },
    ...['drafts', 'editDrafts', 'brandUploads', 'revisions', 'completions']
      .map(field => ({ version: 2, themes: { [holdings]: theme }, savedIds: [holdings], [field]: { [services]: [] } })),
  ]
  for (const scenario of multiScenarios) {
    const key = brandingStorageKeys(scenario).companies
    for (const value of tolerated) {
      const storage = memory()
      storage.setItem(key, typeof value === 'string' ? value : JSON.stringify(value))
      assertParity(storage, scenario, `${scenario}: ${JSON.stringify(value)}`)
    }
    for (const value of [...rejected.map(entry => JSON.stringify(entry)), '{broken']) {
      const storage = memory()
      storage.setItem(key, value)
      assert.throws(() => readBrandingStore(value), undefined, value)
      assert.deepEqual(demoCompanyStatuses(storage, scenario), ['not-started', 'not-started', 'not-started'], value)
    }
  }
})

test('returning scenarios count their prepared branding before and after Branding prepares it', () => {
  // Before Branding has opened in the scenario, nothing is stored yet.
  assert.equal(brandingShare(memory(), 'returning-single'), 1)
  assert.equal(brandingShare(memory(), 'returning-multi'), 0.5)
  for (const scenario of scenarios.filter(scenario => !scenario.startsWith('returning'))) {
    assert.equal(brandingShare(memory(), scenario), 0, scenario)
  }
  // What Branding's demo setup writes for returning-multi: its saved companies and in-process drafts.
  const prepared = preparedBranding('returning-multi')
  assert.deepEqual(prepared, { singleSaved: false, saved: [holdings], inProcess: [services] })
  const storage = memory()
  const key = brandingStorageKeys('returning-multi').companies
  persistBranding(storage, Object.fromEntries(prepared.saved.map(id => [id, theme])), key)
  for (const id of prepared.inProcess) persistBrandingDraft(storage, id, draft, key)
  assertParity(storage, 'returning-multi', 'prepared returning-multi')
  assert.equal(brandingShare(storage, 'returning-multi'), 0.5)
  // Only the prepared in-process company resumes on Login.
  for (const id of DEMO_COMPANY_IDS) assert.equal(resumesAtLogin('returning-multi', id), prepared.inProcess.includes(id), id)
  assert.equal(preparedBranding('returning-single').singleSaved, true)
})

test('single EIN demos: prepared starting data is not progress until a wizard step shows; a save is done', () => {
  for (const scenario of singleScenarios.filter(scenario => !preparedBranding(scenario).singleSaved)) {
    const storage = memory()
    const keys = brandingStorageKeys(scenario)
    // Branding's demo setup keeps a default draft as soon as the scenario opens.
    storage.setItem(keys.single, JSON.stringify(draft))
    assert.equal(brandingShare(storage, scenario), 0, scenario)
    markSingleStepShown(storage, scenario)
    assert.equal(brandingShare(storage, scenario), 0.5, scenario)
    persistSingleBranding(storage, theme, keys.single, keys.singleConfirmed, attribution)
    assert.equal(brandingShare(storage, scenario), 1, scenario)
    persistSingleEditDraft(storage, keys.single, { ...theme, loginTagline: 'Unfinished edit' })
    assert.equal(brandingShare(storage, scenario), 1, `${scenario}: edit of saved`)
  }
})

test('single EIN outside a demo: kept branding is in process, a confirmed save is done', () => {
  const storage = memory()
  const keys = brandingStorageKeys(null)
  assert.equal(brandingShare(storage, null), 0)
  // Branding keeps the working draft only once a wizard step shows (for example before Save and finish later).
  storage.setItem(keys.single, JSON.stringify(draft))
  assert.equal(brandingShare(storage, null), 0.5)
  persistSingleBranding(storage, theme, keys.single, keys.singleConfirmed, attribution)
  assert.equal(brandingShare(storage, null), 1)
  persistSingleEditDraft(storage, keys.single, { ...theme, loginTagline: 'Unfinished edit' })
  assert.equal(brandingShare(storage, null), 1)
  // A demo's marker never counts outside that demo.
  const other = memory()
  markSingleStepShown(other, 'new-single')
  assert.equal(brandingShare(other, null), 0)
  assert.equal(brandingShare(other, 'new-multi'), 0)
})

test('the step-shown marker is separate per scenario, outside Branding\'s own keys, and never breaks Branding', () => {
  const markers = singleScenarios.map(singleStepShownKey)
  assert.equal(new Set(markers).size, markers.length)
  for (const scenario of scenarios) {
    assert.ok(!Object.values(brandingStorageKeys(scenario)).some(key => markers.includes(key)), scenario)
  }
  assert.doesNotThrow(() => markSingleStepShown({ setItem() { throw new Error('Quota exceeded') } }, 'new-single'))
  const refusing = { getItem() { throw new Error('Storage disabled') } }
  for (const scenario of [null, ...scenarios]) {
    assert.doesNotThrow(() => brandingShare(refusing, scenario))
  }
})
