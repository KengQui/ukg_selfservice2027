import test from 'node:test'
import assert from 'node:assert/strict'
import { readAsDataUrl } from './brandImages.ts'

test('supported images with missing MIME metadata still receive the correct image data URL', async () => {
  const reader = globalThis.FileReader
  globalThis.FileReader = class {
    readAsDataURL() {
      this.result = 'data:application/octet-stream;base64,aW1hZ2U='
      queueMicrotask(() => this.onload())
    }
  }
  try {
    for (const [name, mime] of [
      ['logo.png', 'image/png'], ['logo.JPG', 'image/jpeg'], ['logo.jpeg', 'image/jpeg'],
      ['logo.svg', 'image/svg+xml'], ['logo.webp', 'image/webp'],
    ]) {
      assert.equal(await readAsDataUrl({ name, type: '' }), `data:${mime};base64,aW1hZ2U=`)
    }
    assert.equal(await readAsDataUrl({ name: 'brand-guide.pdf', type: '' }), 'data:application/octet-stream;base64,aW1hZ2U=')
  } finally {
    if (reader === undefined) delete globalThis.FileReader
    else globalThis.FileReader = reader
  }
})