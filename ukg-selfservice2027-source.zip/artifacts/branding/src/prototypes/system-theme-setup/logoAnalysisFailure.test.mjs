import test from 'node:test'
import assert from 'node:assert/strict'
import { customFetch } from '../../../../../lib/api-client-react/src/custom-fetch.ts'
import { LogoDetectionErrorCode } from '../../../../../lib/api-client-react/src/generated/api.schemas.ts'
import {
  EXPLAINED_FAILURE_CODES, LOGO_ANALYSIS_FALLBACK_MESSAGE, logoAnalysisFailureMessage,
} from './logoAnalysisFailure.ts'

// What the logo-detection route answers with for each failure it explains.
const routeFailures = [
  [400, 'invalid_images', 'Logo analysis needs 1 to 5 PNG or JPEG images, each within the size limit. Check the images, then try again.'],
  [429, 'rate_limited', 'Logo analysis has reached its limit for the moment. Wait a minute, then try again.'],
  [502, 'unavailable', 'Logo analysis isn’t available right now. Try again in a moment.'],
  [504, 'timed_out', 'Logo analysis took too long to finish. Try again in a moment.'],
]

const json = (status, body) => new Response(JSON.stringify(body), {
  status,
  headers: { 'content-type': 'application/json; charset=utf-8' },
})

/** The error the logo step catches when the server answers its request with `response`. */
async function rejectionFor(response) {
  const realFetch = globalThis.fetch
  globalThis.fetch = async () => response
  try {
    await customFetch('/api/brand/logo-detection', { method: 'POST', body: JSON.stringify({ images: [] }) })
  } catch (error) {
    return error
  } finally {
    globalThis.fetch = realFetch
  }
  assert.fail('The request should have been rejected')
}

test('the step explains exactly the failures the API spec gives a code', () => {
  const specCodes = Object.values(LogoDetectionErrorCode).sort()
  assert.deepEqual([...EXPLAINED_FAILURE_CODES].sort(), specCodes)
  assert.deepEqual(routeFailures.map(([, code]) => code).sort(), specCodes)
})

test('each failure the route explains shows its explanation and says the files are kept', async () => {
  for (const [status, code, explanation] of routeFailures) {
    const error = await rejectionFor(json(status, { code, error: explanation }))
    assert.equal(logoAnalysisFailureMessage(error), `${explanation} Your files are still here.`)
  }
})

test('error responses the route didn’t explain keep the general message, even at the same statuses', async () => {
  const responses = [
    // The server's generic request errors.
    json(400, { error: 'Request body must be valid JSON.' }),
    json(413, { error: 'Request body is too large.' }),
    json(500, { error: 'Internal Server Error' }),
    // A proxy's error, as a page or as JSON.
    new Response('<html><body>502 Bad Gateway</body></html>', { status: 502, headers: { 'content-type': 'text/html' } }),
    json(502, { error: 'Bad Gateway' }),
    json(504, { error: 'Gateway Timeout', message: 'The upstream server didn’t respond in time.' }),
    new Response(null, { status: 504 }),
    // Codes the route doesn't send.
    json(502, { code: 'overloaded', error: 'Try again later.' }),
    json(429, { code: 'toString', error: 'Try again later.' }),
    json(429, { code: 429, error: 'Try again later.' }),
    // A route code without a usable explanation.
    json(429, { code: 'rate_limited' }),
    json(429, { code: 'rate_limited', error: '' }),
    json(504, { code: 'timed_out', error: '   ' }),
    json(502, { code: 'unavailable', error: 42 }),
    json(502, null),
    json(502, {}),
  ]
  for (const response of responses) {
    assert.equal(logoAnalysisFailureMessage(await rejectionFor(response)), LOGO_ANALYSIS_FALLBACK_MESSAGE)
  }
})

test('a failure before any response, such as a dropped connection, keeps the general message', () => {
  const failures = [
    new TypeError('Failed to fetch'),
    new Error('Prepared image is too large'),
    { data: { error: routeFailures[2][2] } },
    'offline',
    null,
    undefined,
  ]
  for (const failure of failures) {
    assert.equal(logoAnalysisFailureMessage(failure), LOGO_ANALYSIS_FALLBACK_MESSAGE)
  }
})

test('an explanation without closing punctuation still reads as its own sentence', async () => {
  const error = await rejectionFor(json(504, { code: 'timed_out', error: '  Logo analysis took too long to finish  ' }))
  assert.equal(logoAnalysisFailureMessage(error), 'Logo analysis took too long to finish. Your files are still here.')
})
