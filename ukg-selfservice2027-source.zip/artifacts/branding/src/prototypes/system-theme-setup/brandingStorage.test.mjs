import test from 'node:test'
import assert from 'node:assert/strict'
import {
  readBrandingStore, savedBranding, persistBranding, persistBrandingDraft, persistBrandingEditDraft, persistSingleEditDraft, persistBrandUploads, persistSingleBranding, companySetupStatus, updatedCompletionCompany, revisionLabel, companyAttributionLabel, readSingleRevision, readSingleCompletion,
} from './brandingStorage.ts'

const theme = { primaryColor: '#123456', accentColor: '#abcdef', loginTagline: 'Preserve me' }
const draft = { ...theme, selectedPalette: 'Navy', loginTagline: 'Still in process' }
const uploads = {
  files: [{ id: 'logo', name: 'acme.png', size: 2048, url: 'data:image/png;base64,kept' }, { id: 'guide', name: 'guide.pdf', size: 10, url: null }],
  status: 'matched', message: 'Bryte identified acme.png as the standalone logo and prepared colors from it.', selectedLogoId: 'logo',
}
function memory(raw = null) {
  return { getItem: () => raw, setItem: (_key, value) => { raw = value } }
}
const statuses = store => ['one', 'two', 'three'].map(id => companySetupStatus(store, id))

test('Updated belongs only to the exact saved EIN revision of a committed edit', () => {
  const storage = memory()
  const first = persistBranding(storage, { one: theme })
  assert.equal(updatedCompletionCompany(null, savedBranding(first)), undefined)
  assert.equal(updatedCompletionCompany({ id: 'one', snapshot: JSON.stringify(theme) }, {}), undefined)
  const updated = { ...theme, loginTagline: 'New saved tagline' }
  const saved = persistBranding(storage, { one: updated })
  const outcome = { id: 'one', snapshot: JSON.stringify(updated) }
  assert.equal(updatedCompletionCompany(outcome, savedBranding(saved)), 'one')
  assert.equal(updatedCompletionCompany({ id: 'two', snapshot: outcome.snapshot }, savedBranding(saved)), undefined)
  assert.equal(updatedCompletionCompany(outcome, savedBranding(persistBranding(storage, { one: theme }))), undefined)
  assert.equal(updatedCompletionCompany(outcome, savedBranding(readBrandingStore(storage.getItem()))), undefined)
})

test('later edits show Updated immediately; reopening shows revision over first completion', () => {
  const storage = memory()
  const revised = { ...theme, loginTagline: 'New saved tagline' }
  const revision = { actor: 'System Administrator', savedAt: '2025-04-21T12:34:56.000Z' }
  persistBranding(storage, { one: theme }, undefined, revision)
  assert.deepEqual(readBrandingStore(storage.getItem()).revisions, {})
  assert.deepEqual(readBrandingStore(storage.getItem()).completions.one, revision)
  const readable = new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(revision.savedAt))
  assert.equal(companyAttributionLabel(readBrandingStore(storage.getItem()).completions.one), `Completed: System Administrator ${readable}`)
  const saved = persistBranding(storage, { one: revised }, undefined, revision)
  const outcome = { id: 'one', snapshot: JSON.stringify(revised) }
  assert.equal(updatedCompletionCompany(outcome, savedBranding(saved)), 'one')
  const reentry = readBrandingStore(storage.getItem())
  assert.equal(updatedCompletionCompany(null, savedBranding(reentry)), undefined)
  assert.equal(revisionLabel(reentry.revisions.one), `Revised: System Administrator ${readable}`)
  assert.equal(companyAttributionLabel(reentry.completions.one, reentry.revisions.one), `Revised: System Administrator ${readable}`)
  // The single theme remains an exact serialized snapshot; its separate metadata survives reentry.
  assert.deepEqual(readSingleRevision(JSON.stringify(revision)), revision)
  assert.equal(revisionLabel(readSingleRevision(JSON.stringify(revision))), `Revised: System Administrator ${readable}`)
  assert.equal(readSingleRevision(null), undefined)
})

test('first confirmed saves, including a copied company, keep per-EIN completion provenance', () => {
  const storage = memory()
  const first = { actor: 'System Administrator', savedAt: '2025-04-21T12:34:56.000Z' }
  const later = { actor: 'System Administrator', savedAt: '2025-05-01T09:05:00.000Z' }
  persistBrandingDraft(storage, 'one', draft)
  assert.deepEqual(readBrandingStore(storage.getItem()).completions, {})
  persistBranding(storage, { one: theme }, undefined, first)
  persistBranding(storage, { two: theme }, undefined, later)
  persistBranding(storage, { one: draft }, undefined, later)
  const reopened = readBrandingStore(storage.getItem())
  assert.deepEqual(reopened.completions, { one: first, two: later })
  assert.deepEqual(reopened.revisions, { one: later })
  const before = storage.getItem()
  storage.setItem = () => { throw new Error('Quota exceeded') }
  assert.throws(() => persistBranding(storage, { three: theme }, undefined, later), /Quota/)
  assert.equal(storage.getItem(), before)
  const legacy = readBrandingStore(JSON.stringify({ version: 2, themes: { one: theme }, savedIds: ['one'] }))
  assert.deepEqual(legacy.completions, {})
  assert.equal(companyAttributionLabel(legacy.completions.one, legacy.revisions.one), undefined)
  assert.deepEqual(readBrandingStore(JSON.stringify({
    version: 2, themes: { one: theme }, savedIds: ['one'],
    completions: { one: { actor: 4, savedAt: first.savedAt }, two: later },
  })).completions, {})
})

test('single confirmation stores first completion separately; draft, failure and legacy confirmation do not invent history', () => {
  const values = new Map()
  const storage = { getItem: key => values.get(key) ?? null, setItem: (key, value) => values.set(key, value), removeItem: key => values.delete(key) }
  const key = 'single-theme'
  const confirmed = 'single-confirmed'
  const first = { actor: 'System Administrator', savedAt: '2025-04-21T12:34:56.000Z' }
  const later = { actor: 'System Administrator', savedAt: '2025-05-01T09:05:00.000Z' }
  storage.setItem(key, JSON.stringify(draft))
  assert.equal(readSingleCompletion(storage.getItem(`${key}:completion`)), undefined)
  storage.setItem = (_key, value) => {
    if (_key === confirmed) throw new Error('Quota exceeded')
    values.set(_key, value)
  }
  assert.throws(() => persistSingleBranding(storage, theme, key, confirmed, first), /Quota/)
  assert.equal(storage.getItem(confirmed), null)
  assert.equal(storage.getItem(`${key}:completion`), null)
  assert.equal(storage.getItem(key), JSON.stringify(draft))
  storage.setItem = (key, value) => values.set(key, value)
  const result = persistSingleBranding(storage, theme, key, confirmed, later)
  assert.equal(result.wasSaved, false)
  assert.deepEqual(readSingleCompletion(storage.getItem(`${key}:completion`)), later)
  assert.equal(storage.getItem(confirmed), '1')
  const edited = persistSingleBranding(storage, draft, key, confirmed, first)
  assert.equal(edited.wasSaved, true)
  assert.deepEqual(readSingleRevision(storage.getItem(`${key}:revision`)), first)
  assert.deepEqual(readSingleCompletion(storage.getItem(`${key}:completion`)), later)
  assert.equal(readSingleCompletion(JSON.stringify({ actor: 1, savedAt: later.savedAt })), undefined)
  assert.equal(readSingleCompletion(JSON.stringify({ actor: 'Admin', savedAt: 'invalid' })), undefined)
})

test('revision attribution stays with the EIN, replaces on the next edit, and survives drafts and failure', () => {
  const storage = memory()
  const first = { actor: 'System Administrator', savedAt: '2025-04-21T12:34:56.000Z' }
  const second = { actor: 'System Administrator', savedAt: '2025-05-01T09:05:00.000Z' }
  persistBranding(storage, { one: theme, two: theme })
  persistBranding(storage, { one: draft }, undefined, first)
  persistBrandingDraft(storage, 'three', draft)
  persistBrandUploads(storage, 'three', uploads)
  assert.deepEqual(readBrandingStore(storage.getItem()).revisions, { one: first })
  const before = storage.getItem()
  storage.setItem = () => { throw new Error('Quota exceeded') }
  assert.throws(() => persistBranding(storage, { two: draft }, undefined, second), /Quota/)
  assert.equal(storage.getItem(), before)
  // A subsequent successful edit replaces only this EIN's revision.
  const resumed = memory(before)
  persistBranding(resumed, { one: theme }, undefined, second)
  assert.deepEqual(readBrandingStore(resumed.getItem()).revisions, { one: second })
  assert.equal(companySetupStatus(readBrandingStore(resumed.getItem()), 'one'), 'done')
  assert.equal(readBrandingStore(resumed.getItem()).revisions.two, undefined)
  assert.equal(revisionLabel({ actor: null, savedAt: first.savedAt }),
    `Revised: Name unavailable ${new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(first.savedAt))}`)
})

test('fresh entry and preview drafts have no saved companies', () => {
  const storage = memory()
  const draft = { ...theme }
  assert.deepEqual(savedBranding(readBrandingStore(storage.getItem())), {})
  assert.equal(storage.getItem(), null)
  assert.deepEqual(draft, theme)
})
test('legacy content is retained without claiming a verified save', () => {
  const storage = memory(JSON.stringify({ one: theme, two: theme }))
  const original = storage.getItem()
  assert.deepEqual(readBrandingStore(original).themes.one, theme)
  assert.deepEqual(savedBranding(readBrandingStore(original)), {})
  assert.equal(storage.getItem(), original)
  const saved = persistBranding(storage, { one: theme })
  assert.deepEqual(saved.savedIds, ['one'])
  assert.deepEqual(saved.themes.two, theme)
})
test('explicit save affects one company and survives reload; subset and all saves accumulate', () => {
  const storage = memory()
  persistBranding(storage, { one: theme })
  assert.deepEqual(Object.keys(savedBranding(readBrandingStore(storage.getItem()))), ['one'])
  persistBranding(storage, { two: theme })
  assert.deepEqual(readBrandingStore(storage.getItem()).savedIds, ['one', 'two'])
  persistBranding(storage, { three: theme })
  assert.deepEqual(readBrandingStore(storage.getItem()).savedIds, ['one', 'two', 'three'])
})
test('failed writes do not change storage or completion', () => {
  const storage = memory()
  storage.setItem = () => { throw new Error('Quota exceeded') }
  assert.throws(() => persistBranding(storage, { one: theme }), /Quota/)
  assert.deepEqual(readBrandingStore(storage.getItem()).savedIds, [])
})
test('malformed storage is rejected instead of overwritten', () => {
  for (const raw of ['null', '[]', '{', '{"one":null}', '{"version":2,"themes":{},"savedIds":null}']) {
    const storage = memory(raw)
    assert.throws(() => persistBranding(storage, { one: theme }))
    assert.equal(storage.getItem(), raw)
  }
})

test('version-2 stores without drafts and legacy records still load', () => {
  const versioned = readBrandingStore(JSON.stringify({ version: 2, themes: { one: theme }, savedIds: ['one'] }))
  assert.deepEqual(versioned.drafts, {})
  assert.deepEqual(versioned.editDrafts, {})
  assert.deepEqual(statuses(versioned), ['done', 'not-started', 'not-started'])
  const legacy = readBrandingStore(JSON.stringify({ two: theme }))
  assert.deepEqual(legacy.drafts, {})
  assert.deepEqual(savedBranding(legacy), {})
  assert.deepEqual(statuses(legacy), ['not-started', 'in-process', 'not-started'])
})
test('saved-company edits are isolated, never copy sources, and save or copy clears only its target edit', () => {
  const storage = memory()
  const first = { actor: 'System Administrator', savedAt: '2026-09-14T13:30:00.000Z' }
  persistBranding(storage, { one: theme, two: theme }, undefined, first)
  persistBrandingEditDraft(storage, 'one', draft)
  persistBrandingEditDraft(storage, 'two', { ...draft, primaryColor: '#654321' })
  persistBrandingEditDraft(storage, 'three', draft)
  const reopened = readBrandingStore(storage.getItem())
  assert.deepEqual(Object.keys(reopened.editDrafts), ['one', 'two'])
  assert.deepEqual(savedBranding(reopened), { one: theme, two: theme })
  assert.deepEqual(reopened.themes.one, theme)
  assert.deepEqual(reopened.revisions, {})
  assert.deepEqual(reopened.completions.one, first)
  assert.deepEqual(readBrandingStore(JSON.stringify({
    version: 2, themes: { one: theme }, savedIds: ['one'], editDrafts: { one: draft, three: draft },
  })).editDrafts, { one: draft })
  const before = storage.getItem()
  storage.setItem = () => { throw new Error('Quota exceeded') }
  assert.throws(() => persistBrandingEditDraft(storage, 'one', null), /Quota/)
  assert.equal(storage.getItem(), before)
  const resumed = memory(before)
  const saved = persistBranding(resumed, { one: draft }, undefined, first)
  assert.deepEqual(saved.editDrafts, { two: reopened.editDrafts.two })
  assert.deepEqual(saved.revisions.one, first)
  const copied = persistBranding(resumed, { two: theme }, undefined, first)
  assert.deepEqual(copied.editDrafts, {})
  assert.deepEqual(copied.completions.two, first)
})
test('single unfinished edit keeps its saved snapshot, clears on save and rolls back a failed save', () => {
  const values = new Map()
  const storage = { getItem: key => values.get(key) ?? null, setItem: (key, value) => values.set(key, value), removeItem: key => values.delete(key) }
  const first = { actor: 'System Administrator', savedAt: '2026-09-14T13:30:00.000Z' }
  persistSingleBranding(storage, theme, 'single', 'confirmed', first)
  persistSingleEditDraft(storage, 'single', draft)
  assert.equal(storage.getItem('single'), JSON.stringify(theme))
  assert.equal(storage.getItem('single:revision'), null)
  storage.setItem = (key, value) => {
    if (key === 'single:revision') throw new Error('Quota exceeded')
    values.set(key, value)
  }
  assert.throws(() => persistSingleBranding(storage, draft, 'single', 'confirmed', first), /Quota/)
  assert.equal(storage.getItem('single'), JSON.stringify(theme))
  assert.equal(storage.getItem('single:edit'), JSON.stringify(draft))
  storage.setItem = (key, value) => values.set(key, value)
  persistSingleBranding(storage, draft, 'single', 'confirmed', first)
  assert.equal(storage.getItem('single'), JSON.stringify(draft))
  assert.equal(storage.getItem('single:edit'), null)
})
test('a draft marks a company in process without counting as saved', () => {
  const storage = memory()
  const store = persistBrandingDraft(storage, 'two', draft)
  assert.deepEqual(store.drafts.two, draft)
  assert.deepEqual(store.savedIds, [])
  assert.deepEqual(savedBranding(store), {})
  assert.deepEqual(statuses(readBrandingStore(storage.getItem())), ['not-started', 'in-process', 'not-started'])
  const updated = persistBrandingDraft(storage, 'two', { ...draft, accentColor: '#000000' })
  assert.equal(updated.drafts.two.accentColor, '#000000')
  assert.equal(Object.keys(updated.themes).length, 0)
})
test('saving clears that company’s draft and done wins over any leftover draft', () => {
  const storage = memory()
  persistBrandingDraft(storage, 'one', draft)
  persistBrandingDraft(storage, 'two', draft)
  const saved = persistBranding(storage, { one: theme })
  assert.deepEqual(saved.savedIds, ['one'])
  assert.deepEqual(Object.keys(saved.drafts), ['two'])
  assert.deepEqual(statuses(readBrandingStore(storage.getItem())), ['done', 'in-process', 'not-started'])
  assert.deepEqual(persistBrandingDraft(storage, 'one', draft).drafts, { two: draft })
  const stale = readBrandingStore(JSON.stringify({ version: 2, themes: { one: theme }, savedIds: ['one'], drafts: { one: draft } }))
  assert.deepEqual(stale.drafts, {})
  assert.equal(companySetupStatus(stale, 'one'), 'done')
})
test('failed draft writes leave storage unchanged', () => {
  const storage = memory()
  persistBrandingDraft(storage, 'one', draft)
  const before = storage.getItem()
  storage.setItem = () => { throw new Error('Quota exceeded') }
  assert.throws(() => persistBrandingDraft(storage, 'two', draft), /Quota/)
  assert.equal(storage.getItem(), before)
})
test('malformed drafts are rejected instead of overwritten', () => {
  for (const drafts of ['[]', '"x"', '{"one":null}', '{"one":[]}']) {
    const raw = `{"version":2,"themes":{},"savedIds":[],"drafts":${drafts}}`
    const storage = memory(raw)
    assert.throws(() => persistBrandingDraft(storage, 'one', draft))
    assert.equal(storage.getItem(), raw)
  }
})

test('brand uploads are kept beside the draft without changing saved companies or statuses', () => {
  const storage = memory()
  persistBrandingDraft(storage, 'two', draft)
  const store = persistBrandUploads(storage, 'two', uploads)
  assert.deepEqual(store.brandUploads, { two: uploads })
  assert.deepEqual(store.drafts, { two: draft })
  assert.deepEqual(store.savedIds, [])
  assert.deepEqual(savedBranding(store), {})
  const reloaded = readBrandingStore(storage.getItem())
  assert.deepEqual(reloaded.brandUploads.two, uploads)
  assert.deepEqual(statuses(reloaded), ['not-started', 'in-process', 'not-started'])
  const changed = persistBrandUploads(storage, 'two', { ...uploads, selectedLogoId: null, status: 'no-match' })
  assert.equal(changed.brandUploads.two.status, 'no-match')
  assert.deepEqual(changed.drafts.two, draft)
})
test('removing uploads clears only that company and skips the write when nothing was kept', () => {
  const storage = memory()
  persistBrandUploads(storage, 'one', uploads)
  persistBrandUploads(storage, 'two', uploads)
  const cleared = persistBrandUploads(storage, 'one', null)
  assert.deepEqual(Object.keys(cleared.brandUploads), ['two'])
  assert.deepEqual(Object.keys(readBrandingStore(storage.getItem()).brandUploads), ['two'])
  const before = storage.getItem()
  storage.setItem = () => { throw new Error('No write expected') }
  assert.deepEqual(persistBrandUploads(storage, 'one', null).brandUploads, { two: uploads })
  assert.equal(storage.getItem(), before)
})
test('saving a company drops its uploads, and saved companies keep none afterwards', () => {
  const storage = memory()
  persistBrandingDraft(storage, 'one', draft)
  persistBrandUploads(storage, 'one', uploads)
  persistBrandUploads(storage, 'two', uploads)
  const saved = persistBranding(storage, { one: theme })
  assert.deepEqual(Object.keys(saved.brandUploads), ['two'])
  assert.deepEqual(saved.drafts, {})
  assert.deepEqual(persistBrandUploads(storage, 'one', uploads).brandUploads, { two: uploads })
  assert.deepEqual(readBrandingStore(storage.getItem()).brandUploads, { two: uploads })
  const stale = readBrandingStore(JSON.stringify({ version: 2, themes: { one: theme }, savedIds: ['one'], brandUploads: { one: uploads, two: uploads } }))
  assert.deepEqual(Object.keys(stale.brandUploads), ['two'])
  assert.equal(companySetupStatus(stale, 'one'), 'done')
})
test('stores without brand uploads still load, and failed or malformed upload writes leave storage unchanged', () => {
  assert.deepEqual(readBrandingStore(JSON.stringify({ version: 2, themes: {}, savedIds: [], drafts: { one: draft } })).brandUploads, {})
  assert.deepEqual(readBrandingStore(JSON.stringify({ one: theme })).brandUploads, {})
  const storage = memory()
  persistBrandUploads(storage, 'one', uploads)
  const before = storage.getItem()
  storage.setItem = () => { throw new Error('Quota exceeded') }
  assert.throws(() => persistBrandUploads(storage, 'two', uploads), /Quota/)
  assert.equal(storage.getItem(), before)
  for (const brandUploads of ['[]', '"x"', '{"one":null}', '{"one":[]}']) {
    const raw = `{"version":2,"themes":{},"savedIds":[],"brandUploads":${brandUploads}}`
    const malformed = memory(raw)
    assert.throws(() => persistBrandUploads(malformed, 'one', uploads))
    assert.throws(() => persistBrandingDraft(malformed, 'one', draft))
    assert.equal(malformed.getItem(), raw)
  }
})

test('scenario save provenance stays within its own storage namespace', () => {
  const values = new Map()
  const storage = { getItem: key => values.get(key) ?? null, setItem: (key, value) => values.set(key, value) }
  persistBranding(storage, { one: theme }, 'ready-dls-demo-new-multi-ein-themes')
  assert.deepEqual(readBrandingStore(storage.getItem('ready-dls-demo-new-multi-ein-themes')).savedIds, ['one'])
  assert.equal(storage.getItem('ready-dls-ein-themes'), null)
  assert.equal(storage.getItem('ready-dls-demo-returning-multi-ein-themes'), null)
})