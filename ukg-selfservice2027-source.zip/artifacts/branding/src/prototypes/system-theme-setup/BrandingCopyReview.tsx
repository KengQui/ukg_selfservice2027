import { useEffect, useRef, useState } from 'react'
import type { Dispatch, SetStateAction } from 'react'
import { Button, InlineMessage, Tag } from '@ready/dls/compatibility'
import type { ThemeSetupState } from './SystemThemeSetup'
import PagePreview from './PagePreview'
import LoginPreview from './LoginPreview'
import PreviewCarousel from './PreviewCarousel'
import StepColors from './StepColors'
import StepLogin from './StepLogin'
import type { CompanySummary, ReviewedBranding } from './copyBrandingState'
import { updateThemeSetup } from './palettes'
import { SAMPLE_LOGO } from './sampleLogo'
import type { CopyEditorState, CopyEditorStep } from './copyEditSession'
import { useAskBrytePage } from '@workspace/setup-shared/ask-bryte'

export default function BrandingCopyReview({ companies, data, sourceId, selectedIds, error, onBack, onApply, onFinishEdit, onChangeSource, copyEdit, onCopyEditChange, copyEditWarning, savedView = false, savedStatus = 'saved', onEdit, startInEdit = false, unfinishedEdit, onDiscardEdit, onSaveLaterChange, onSaveLaterEdit }: {
  /** The company catalog the prototype was opened with; names the source and destinations. */
  companies: CompanySummary[]
  data: ThemeSetupState & ReviewedBranding
  sourceId: string
  selectedIds: string[]
  error: string
  onBack: () => void
  onApply: () => void
  onFinishEdit: (draft: ThemeSetupState & ReviewedBranding) => void
  /** Reopens the choice of company to copy from; offered only while more than one company can be copied from. */
  onChangeSource?: () => void
  copyEdit?: CopyEditorState | null
  onCopyEditChange?: Dispatch<SetStateAction<CopyEditorState | null>>
  copyEditWarning?: string
  savedView?: boolean
  savedStatus?: 'saved' | 'in-process' | 'unconfirmed' | 'preview'
  onEdit?: () => void
  startInEdit?: boolean
  unfinishedEdit?: ThemeSetupState
  onDiscardEdit?: () => boolean
  onSaveLaterChange?: (saveLater: (() => void) | null) => void
  onSaveLaterEdit?: (draft: ThemeSetupState) => void
}) {
  useAskBrytePage(savedView ? 'saved-look' : 'copy-review', savedView
    ? {
        palette: data.selectedPalette ?? 'Custom',
        primaryColor: data.primaryColor,
        accentColor: data.accentColor,
        logoAdded: Boolean(data.logoUrl),
        editInProcess: Boolean(unfinishedEdit),
      }
    : { destinations: selectedIds.length, palette: data.selectedPalette ?? 'Custom', editing: Boolean(copyEdit) })
  const [localEdit, setLocalEdit] = useState<CopyEditorState | null>(() =>
    startInEdit ? { step: 'theme', draft: { ...(unfinishedEdit ?? data) } } : null)
  const edit = onCopyEditChange ? copyEdit ?? null : localEdit
  const setEdit = onCopyEditChange ?? setLocalEdit
  const saveLaterRef = useRef(() => {})
  saveLaterRef.current = () => { if (edit && onSaveLaterEdit) onSaveLaterEdit(edit.draft) }
  useEffect(() => {
    if (!startInEdit || !edit || !onSaveLaterChange || !onSaveLaterEdit) return
    onSaveLaterChange(() => saveLaterRef.current())
    return () => onSaveLaterChange(null)
  }, [startInEdit, Boolean(edit), onSaveLaterChange, Boolean(onSaveLaterEdit)])
  const source = companies.find(company => company.id === sourceId)
  const destinations = companies.filter(company => selectedIds.includes(company.id))
   const beginEdit = () => setEdit({ step: 'theme', draft: { ...(unfinishedEdit ?? data) } })
  const cancelEdit = () => {
    if (startInEdit) {
      onBack()
      return
    }
    setEdit(null)
  }
  if (edit) {
    const updateDraft = (updates: Partial<ThemeSetupState>) => setEdit(previous =>
      previous && { ...previous, draft: updateThemeSetup(previous.draft, updates) })
    const goTo = (step: CopyEditorStep) => setEdit(previous => previous && { ...previous, step })
    const finishEdit = () => onFinishEdit({ ...edit.draft })
    const finishLabel = savedView ? 'Save branding' : 'Apply branding'
    return <div className="theme-setup-full">
      {error && <InlineMessage theme="error">{error}</InlineMessage>}
      {unfinishedEdit && onDiscardEdit && <div className="ts-edit-draft-notice" role="status">
        <span>Your saved branding has not changed. An edit is in progress.</span>
        <Button variant="tertiary" size="small" onClick={() => {
          if (onDiscardEdit()) setEdit({ step: 'theme', draft: { ...data } })
        }}>Discard changes</Button>
      </div>}
      {copyEditWarning && <InlineMessage theme="warning">{copyEditWarning}</InlineMessage>}
      <div className="theme-setup-content ts-split-content">
        {edit.step === 'theme' && <StepColors data={edit.draft}
          onUpdate={updateDraft}
          onBack={cancelEdit}
          onNext={() => goTo('login')} />}
        {edit.step === 'login' && <StepLogin data={edit.draft} onUpdate={updateDraft}
          onBack={() => goTo('theme')}
          onNext={finishEdit}
          nextLabel={finishLabel} />}
      </div>
    </div>
  }
  return (
    <main className="ts-hero-grid ts-colors-split ts-copy-review-split">
      <div className="ts-hero-left">
      <div className="ts-hero-left-inner">
       <h1 className="text-display ts-h1">{savedView ? (source?.name ?? 'Your branding') : destinations.map(company => company.name).join(', ')}</h1>
       <p className="text-body ts-intro">{savedView ? savedStatus === 'saved'
          ? unfinishedEdit
            ? 'Review your saved branding: the logo and colors below, and the company name and login message in the Login page preview. This is what your team sees now. Your edit is still in progress; select Edit branding to continue it.'
            : 'Review your saved branding: the logo and colors below, and the company name and login message in the Login page preview. This is what your team sees now, and you can edit it anytime.'
         : savedStatus === 'in-process'
           ? 'Check the logo and colors below, and the company name and login message in the Login page preview. This company’s branding setup is in progress. Select Edit branding to continue, then save it to finish.'
         : savedStatus === 'unconfirmed'
           ? 'Check the logo and colors below, and the company name and login message in the Login page preview. Your earlier branding is preserved, but its saved status cannot be confirmed. Select Edit branding to review and save it.'
           : 'Check the logo and colors below, and the company name and login message in the Login page preview. This company has no saved branding yet. Select Edit branding to set it up.'
         : 'Check the logo and colors below, and the company name and login message in the Login page preview, before they’re saved for this company. Select Edit branding to make changes, or Apply branding to save them. You can change them anytime.'}</p>
      {!savedView && <div className="ts-intro ts-copy-review-source">
        <Tag label={`Copying from ${source?.name ?? ''}`} type="misc" color="teal" size="large" />
        {onChangeSource && <Button variant="tertiary" highEmphasis size="small" style={{ padding: 0, textDecoration: 'underline' }}
          aria-label="Change the company to copy from" onClick={onChangeSource} data-testid="button-change-copy-source">
          Change
        </Button>}
      </div>}
        <section aria-label="Branding summary" className="ts-copy-review-summary">
          <div className="ts-card">
          <h2 className="ts-copy-review-card-title">Logo</h2>
          <div className="ts-copy-review-logo">
            {data.logoUrl && data.logoUrl !== SAMPLE_LOGO.logoUrl
              ? <img src={data.logoUrl} alt="Company logo" data-testid="img-copy-logo" />
              : <span className="ts-copy-review-logo__empty" data-testid="text-copy-logo">No logo yet. Select Edit branding to add one.</span>}
          </div>
          </div>
          <div className="ts-card">
          <h2 className="ts-copy-review-card-title">Palette</h2>
          <p className="ts-copy-review-palette" data-testid="text-copy-palette">{data.selectedPalette ?? 'Custom'}</p>
          <div className="ts-copy-review-colors gap-[24px]">
            <span data-testid="text-copy-primary"><i style={{ background: data.primaryColor }} />Primary color</span>
            <span data-testid="text-copy-accent"><i style={{ background: data.accentColor }} />Accent color</span>
          </div>
          </div>
        </section>
       {error && <InlineMessage theme="error">{error}</InlineMessage>}
      <div className="ts-actions">
           <Button variant="secondary" size="large" onClick={onBack} data-testid="button-back-branding-review">Back</Button>
            <Button variant={savedView ? 'primary' : 'secondary'} size="large" onClick={onEdit ?? beginEdit} data-testid="button-edit-branding">Edit branding</Button>
           {!savedView && <Button variant="primary" size="large" onClick={onApply} data-testid="button-apply-branding">Apply branding</Button>}
      </div>
      </div>
      </div>
      <aside className="ts-hero-right">
        <div className="ts-colors-preview ts-copy-review-preview">
          <PreviewCarousel label="Branding preview" slides={[
            { id: 'header', label: 'Header', content: <PagePreview data={data} /> },
            { id: 'login', label: 'Login page', content: <LoginPreview data={data} /> },
          ]} />
        </div>
      </aside>
    </main>
  )
}
