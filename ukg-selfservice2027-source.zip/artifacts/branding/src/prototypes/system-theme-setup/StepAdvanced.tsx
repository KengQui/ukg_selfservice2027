import { useState } from 'react'
import { Button, Dialog, Icon, InlineMessage } from '@ready/dls/compatibility'
import { DropZone } from '@workspace/setup-shared/prototypes/_shared/uploadFiles'
import type { ThemeSetupState } from './SystemThemeSetup'
import { useAskBrytePage } from '@workspace/setup-shared/ask-bryte'

function Toggle({ id, checked, onChange }: { id: string; checked: boolean; onChange: (checked: boolean) => void }) {
  return <button id={id} type="button" role="switch" aria-checked={checked} onClick={() => onChange(!checked)}
    style={{ width: 40, height: 24, flexShrink: 0, border: 0, borderRadius: 20, padding: 3, background: checked ? 'var(--color-primary)' : 'var(--color-border-high)', cursor: 'pointer' }}>
    <span style={{ display: 'block', width: 18, height: 18, borderRadius: '50%', background: 'var(--color-surface)', transform: checked ? 'translateX(16px)' : 'none' }} />
  </button>
}

function formatBytes(bytes: number): string {
  if (!bytes) return '0 B'
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / 1048576).toFixed(1)} MB`
}

interface Props {
  data: ThemeSetupState
  onUpdate: (updates: Partial<ThemeSetupState>) => void
  onNext: () => void
  onBack: () => void
  /** Primary action label: Advanced settings is the last step, so it takes over Login page's finishing label. */
  nextLabel?: string
}

const validateImage = (
  file: File,
  type: 'favicon' | 'oauth',
  url: string,
  callback: (error: string | null) => void
) => {
  if (type === 'favicon') {
    if (!['image/png', 'image/jpeg', 'image/x-icon', 'image/vnd.microsoft.icon'].includes(file.type)) {
      return callback('Use a PNG, JPG or ICO file for the favicon.')
    }
  } else {
    if (!['image/png', 'image/jpeg'].includes(file.type)) {
      return callback('Use a PNG or JPG file for the OAuth icon.')
    }
  }

  if (file.size > 2 * 1024 * 1024) {
    return callback('This file is larger than 2 MB. Choose one under 2 MB.')
  }

  const img = new Image()
  img.onload = () => callback(null)
  img.onerror = () => callback('We couldn’t open this image. It may be damaged. Export it again as a PNG or JPG, or choose another file.')
  img.src = url
}

/** Archived implementation team demos only: favicon, OAuth icon and clock options after Login page. */
export default function StepAdvanced({ data, onUpdate, onNext, onBack, nextLabel = 'Save branding' }: Props) {
  useAskBrytePage('advanced', {
    faviconAdded: Boolean(data.faviconUrl),
    oauthIconAdded: Boolean(data.oauthIconUrl),
    headerClock: data.headerClock,
    loginClock: data.loginClock,
  })
  const [faviconError, setFaviconError] = useState('')
  const [oauthError, setOauthError] = useState('')
  const [uploadTarget, setUploadTarget] = useState<'favicon' | 'oauth' | null>(null)

  const handleFaviconFiles = (files: File[]) => {
    if (files.length === 0) return
    const file = files[0]

    const reader = new FileReader()
    reader.onload = (e) => {
      const url = e.target?.result as string
      validateImage(file, 'favicon', url, (err) => {
        if (err) setFaviconError(err)
        else {
          setFaviconError('')
          onUpdate({ faviconUrl: url, faviconFileName: file.name, faviconSize: file.size })
          setUploadTarget(null)
        }
      })
    }
    reader.onerror = () => setFaviconError('We couldn’t read this file. Choose it again, or try another file.')
    reader.readAsDataURL(file)
  }

  const handleOauthFiles = (files: File[]) => {
    if (files.length === 0) return
    const file = files[0]

    const reader = new FileReader()
    reader.onload = (e) => {
      const url = e.target?.result as string
      validateImage(file, 'oauth', url, (err) => {
        if (err) setOauthError(err)
        else {
          setOauthError('')
          onUpdate({ oauthIconUrl: url, oauthIconFileName: file.name, oauthIconSize: file.size })
          setUploadTarget(null)
        }
      })
    }
    reader.onerror = () => setOauthError('We couldn’t read this file. Choose it again, or try another file.')
    reader.readAsDataURL(file)
  }

  return (
    <div style={{ width: '100%', maxWidth: 800, margin: '0 auto', padding: 24, boxSizing: 'border-box' }}>
      <div>
      <div>
      <h1 className="text-display ts-h1">
        Advanced settings
      </h1>
      <p className="text-body ts-intro">
        These small touches help your team recognize your company in browser tabs and on sign-in screens. Everything here is optional: anything you skip keeps its default, and you can change it later.
      </p>

      <div className="ts-card">
        <h4 style={{ margin: '0 0 var(--space-400)', fontSize: 'var(--type-lg-size)' }}>Display options</h4>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-400)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <label htmlFor="headerClockToggle" style={{ fontWeight: 500 }}>Show the clock in the application header</label>
            <Toggle id="headerClockToggle" checked={data.headerClock} onChange={(checked) => onUpdate({ headerClock: checked })} />
          </div>

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <label htmlFor="loginClockToggle" style={{ fontWeight: 500 }}>Show the clock on the login page</label>
            <Toggle id="loginClockToggle" checked={data.loginClock} onChange={(checked) => onUpdate({ loginClock: checked })} />
          </div>

        </div>
      </div>

      <div className="ts-card" style={{ marginTop: 24 }}>
        <h4 style={{ margin: '0 0 var(--space-400)', fontSize: 'var(--type-lg-size)' }}>Browser and sign-in icons</h4>

        <div style={{ marginBottom: 'var(--space-600)' }}>
          <h5 style={{ margin: '0 0 var(--space-200)', fontSize: 'var(--type-md-size)' }}>Favicon</h5>
          <p style={{ margin: '0 0 var(--space-300)', fontSize: 'var(--type-sm-size)', color: 'var(--color-text-subtle)' }}>Appears in browser tabs and bookmarks. A square 32 × 32px image is recommended.</p>

          {data.faviconFileName && (
            <div style={{ background: 'var(--color-bg)', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-300)', padding: 'var(--space-400)', display: 'flex', alignItems: 'center', gap: 'var(--space-400)', marginBottom: 'var(--space-300)' }}>
              {data.faviconUrl ? (
                <div style={{ width: 32, height: 32, borderRadius: 'var(--radius-100)', border: '1px solid var(--color-border)', overflow: 'hidden', flexShrink: 0 }}>
                  <img src={data.faviconUrl} alt="Favicon preview" style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
                </div>
              ) : (
                <div style={{ width: 32, height: 32, borderRadius: 'var(--radius-100)', border: '1px solid var(--color-border)', background: 'var(--color-surface)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <Icon name="document" size={16} className="icon--subtle" />
                </div>
              )}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 500, fontSize: 'var(--type-md-size)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{data.faviconFileName}</div>
                <div style={{ color: 'var(--color-text-subtle)', fontSize: 'var(--type-sm-size)' }}>{formatBytes(data.faviconSize || 0)}</div>
              </div>
              <Button variant="tertiary" borderShape="none" size="small" iconLeftName="delete" onClick={() => onUpdate({ faviconUrl: null, faviconFileName: null, faviconSize: 0 })} aria-label="Remove favicon" />
            </div>
          )}
          <Button variant="secondary" onClick={() => { setFaviconError(''); setUploadTarget('favicon') }}>
            {data.faviconUrl ? 'Replace favicon' : 'Upload favicon'}
          </Button>
        </div>

        <div>
          <h5 style={{ margin: '0 0 var(--space-200)', fontSize: 'var(--type-md-size)' }}>OAuth icon</h5>
          <p style={{ margin: '0 0 var(--space-300)', fontSize: 'var(--type-sm-size)', color: 'var(--color-text-subtle)' }}>Represents your company on the screens where people approve another app’s access to their account (OAuth authorization). A square 84 × 84px JPG or PNG is recommended.</p>

          {data.oauthIconFileName && (
            <div style={{ background: 'var(--color-bg)', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-300)', padding: 'var(--space-400)', display: 'flex', alignItems: 'center', gap: 'var(--space-400)', marginBottom: 'var(--space-300)' }}>
              {data.oauthIconUrl ? (
                <div style={{ width: 84, height: 84, borderRadius: 'var(--radius-200)', border: '1px solid var(--color-border)', overflow: 'hidden', flexShrink: 0 }}>
                  <img src={data.oauthIconUrl} alt="OAuth icon preview" style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
                </div>
              ) : (
                <div style={{ width: 84, height: 84, borderRadius: 'var(--radius-200)', border: '1px solid var(--color-border)', background: 'var(--color-surface)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <Icon name="document" size={32} className="icon--subtle" />
                </div>
              )}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 500, fontSize: 'var(--type-md-size)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{data.oauthIconFileName}</div>
                <div style={{ color: 'var(--color-text-subtle)', fontSize: 'var(--type-sm-size)' }}>{formatBytes(data.oauthIconSize || 0)}</div>
              </div>
              <Button variant="tertiary" borderShape="none" size="small" iconLeftName="delete" onClick={() => onUpdate({ oauthIconUrl: null, oauthIconFileName: null, oauthIconSize: 0 })} aria-label="Remove OAuth icon" />
            </div>
          )}
          <Button variant="secondary" onClick={() => { setOauthError(''); setUploadTarget('oauth') }}>
            {data.oauthIconUrl ? 'Replace OAuth icon' : 'Upload OAuth icon'}
          </Button>
        </div>

      </div>
      <div className="ts-actions">
        <Button variant="secondary" size="large" onClick={onBack}>Back</Button>
        <Button variant="primary" size="large" onClick={onNext}>{nextLabel}</Button>
      </div>
      </div>
      </div>
      <Dialog open={uploadTarget !== null} onClose={() => setUploadTarget(null)}
        title={uploadTarget === 'favicon' ? 'Upload favicon' : 'Upload OAuth icon'} size="normal"
        secondaryAction={{ label: 'Close', onClick: () => setUploadTarget(null) }}>
        <p>{uploadTarget === 'favicon'
          ? 'Choose a PNG, JPG or ICO image. A square 32 × 32px image is recommended.'
          : 'Choose a JPG or PNG image for your company’s OAuth authorization screens. A square 84 × 84px image is recommended.'}</p>
        <DropZone disabled={false} multiple={false}
          accept={uploadTarget === 'favicon' ? 'image/png,image/jpeg,image/x-icon,image/vnd.microsoft.icon' : 'image/png,image/jpeg'}
          onFiles={uploadTarget === 'favicon' ? handleFaviconFiles : handleOauthFiles} />
        {(uploadTarget === 'favicon' ? faviconError : oauthError) && (
          <InlineMessage theme="error">{uploadTarget === 'favicon' ? faviconError : oauthError}</InlineMessage>
        )}
      </Dialog>
    </div>
  )
}
