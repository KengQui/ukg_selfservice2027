import assert from 'node:assert/strict'
import test from 'node:test'
import { brandingPages } from '../../askBrytePages.ts'

test('Bryte describes customer branding screens with current customer-facing names', () => {
  for (const register of ['first-time', 'experienced']) {
    for (const facts of [
      { single: true, savedCompanies: 0, allComplete: false, presetPalettesOnly: true },
      { single: true, savedCompanies: 1, allComplete: true, editInProcess: true },
      { multiEin: true, savedCompanies: 2, allComplete: false, editsInProcess: 1 },
    ]) {
      for (const [key, describe] of Object.entries(brandingPages)) {
        // Advanced settings exists only in the archived implementation team demos; it is checked separately below.
        if (key === 'advanced') continue
        const content = JSON.stringify(describe(facts, register))
        assert.doesNotMatch(content, /\b(?:look|tagline|advanced|favicon|OAuth)\b/i, key)
        // The page after Upload your brand assets is called Theme again, never Colors.
        assert.doesNotMatch(content, /\bColors\b/, key)
        assert.doesNotMatch(content, /In process|edit in process|Return to hub|Done for today|Next step:/i, key)
      }
    }
  }
  assert.equal(brandingPages.colors({}, 'first-time').name, 'Theme')
  assert.equal(brandingPages.login({}, 'first-time').name, 'Login page')
})

test('Bryte knows editable Custom, conditional Copy and prototype-only Global Setup exits', () => {
  const colors = brandingPages.colors({ presetPalettesOnly: true }, 'first-time')
  assert.match(JSON.stringify(colors), /manual color entry remains available/)
  assert.match(JSON.stringify(colors), /entering a code or using Choose color switches the palette to Custom/)
  // Without company colors there is no Custom option, and Bryte doesn't describe one.
  assert.match(colors.onScreen.join(' '), /ready-made palettes only; there is no Custom option yet/)
  assert.match(colors.state.join(' '), /Custom isn’t listed/)
  assert.doesNotMatch(colors.purpose, /Custom are always available/)
  const withCustom = brandingPages.colors({ customAvailable: true, colorsFromLogo: true }, 'first-time')
  assert.match(withCustom.onScreen.join(' '), /Custom, with the company’s own colors, and the ready-made palettes/)
  assert.match(withCustom.state.join(' '), /Custom is available with the company’s own colors/)
  assert.doesNotMatch(JSON.stringify(withCustom), /no Custom option|isn’t listed/)
  assert.match(JSON.stringify(colors), /usable logo without extractable colors is accepted/)
  assert.match(colors.onScreen.join(' '), /Choose a palette in the right panel above the preview/)
  assert.doesNotMatch(colors.onScreen.join(' '), /left Palette card/)
  for (const page of ['company-list', 'copy-branding']) {
    const unfinished = brandingPages[page]({ savedCompanies: 0, allComplete: false }, 'first-time')
    assert.match(unfinished.onScreen.join(' '), /Copy branding is hidden/)
    assert.doesNotMatch(unfinished.suggestions.join(' '), /cop/i)
    assert.doesNotMatch(unfinished.onScreen.join(' '), /Primary action: Invite/)
    const complete = brandingPages[page]({ savedCompanies: 3, allComplete: true }, 'first-time')
    assert.match(complete.onScreen.join(' '), /Primary action: Invite others to help/)
    assert.match(complete.onScreen.join(' '), /Global Setup stays on this screen/)
    assert.match(complete.onScreen.join(' '), /another company’s saved branding/)
  }
  const done = brandingPages.done({ single: true }, 'experienced')
  assert.match(done.onScreen.join(' '), /Opens Theme with saved values/)
  assert.match(done.welcome, /opens Theme/)
  assert.match(brandingPages['saved-look']({}, 'first-time').onScreen.join(' '), /Back from Theme during an edit/)
  for (const page of ['logo', 'colors', 'login']) {
    assert.match(brandingPages[page]({}, 'first-time').onScreen.join(' '),
      /Save and finish later keeps progress without publishing branding/)
  }
})

test('Advanced settings wording appears only for the archived implementation team demos', () => {
  for (const register of ['first-time', 'experienced']) {
    const advanced = brandingPages.advanced({ faviconAdded: true }, register)
    assert.equal(advanced.name, 'Advanced settings')
    const content = JSON.stringify(advanced)
    assert.match(content, /favicon/)
    assert.match(content, /OAuth icon/)
    assert.doesNotMatch(content, /\b(?:look|tagline|Colors)\b/)
    assert.match(advanced.state.join(' '), /A favicon is uploaded/)
    // Customer intro and Login page never mention it; the archived facts add it.
    const customerIntro = JSON.stringify(brandingPages.intro({}, register))
    const customerLogin = JSON.stringify(brandingPages.login({}, register))
    assert.doesNotMatch(customerIntro + customerLogin, /advanced|favicon|OAuth|4 steps/i)
    const archivedIntro = JSON.stringify(brandingPages.intro({ advancedStep: true }, register))
    assert.match(archivedIntro, /4 steps/)
    assert.match(archivedIntro, /Advanced settings/)
    assert.match(brandingPages.login({ advancedNext: true }, register).onScreen.join(' '), /Next, which opens Advanced settings/)
  }
})
