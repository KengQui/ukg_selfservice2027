import { Button } from '@ready/dls/compatibility'
import { readCompanySetup, sampleFromDocState } from '@workspace/setup-shared/prototypes/_shared-company-setup/useCompanySetupState'
import CompanySetupStatusTag, { CompanyRevisionText } from './CompanySetupStatusTag'
import CopyBrandingIllustration from './CopyBrandingIllustration'
import CompletionActions from './CompletionActions'
import type { ThemeSetupState } from './SystemThemeSetup'
import type { BrandingCompletion, BrandingRevision } from './brandingStorage'
import './multiEinSelection.css'
import './singleEinCompletion.css'

/** Completion is reached only after the explicit branding save succeeds. */
export default function SingleEinCompletion({ data, demo, updated = false, editInProcess = false, completion, revision, onEditTheme }: {
  data: ThemeSetupState
  demo: boolean
  updated?: boolean
  editInProcess?: boolean
  revision?: BrandingRevision
  completion?: BrandingCompletion
  onEditTheme: () => void
}) {
  // Demo scenarios stay independent of any real setup working copy. Outside demos,
  // use the latest setup record, the same precedence used when reopening setup.
  const setup = demo ? sampleFromDocState : [readCompanySetup('manual'), readCompanySetup('from-doc')]
    .filter(record => record !== undefined)
    .sort((a, b) => (b.updatedAt ?? 0) - (a.updatedAt ?? 0))[0] ?? sampleFromDocState
  const name = setup.legalName?.trim() || 'Your company'
  const ein = setup.taxId?.trim()

  return (
    <main className="ts-hero-grid ts-intro-grid ts-company-split ts-single-completion" aria-labelledby="single-completion-title">
      <div className="ts-hero-left">
        <div className="ts-hero-left-inner">
          <h1 id="single-completion-title" className="text-display ts-headline">What's next?</h1>
          <p className="text-body ts-body-text">Your company’s branding is saved, and your team will see it when they sign in. You can edit it anytime using the edit icon on your company card, invite others to help, or return to Global Setup.</p>
          <section className="ts-company-group" aria-labelledby="single-completion-completed">
            <h2 id="single-completion-completed" className="text-caption ts-eyebrow">Completed</h2>
            <section className="ts-company-card" aria-label={`Completed company: ${name}`}>
              <div className="ts-company-card__details">
                <span className="ts-company-card__title">
                  <strong>{name}</strong>
                  <CompanySetupStatusTag status="done" companyId="single" updated={updated} editInProcess={editInProcess} />
                </span>
                <span className="text-caption">{ein ? `EIN: ${ein}` : 'EIN not provided'}</span>
                <CompanyRevisionText completion={completion} revision={revision} updated={updated && !editInProcess} />
              </div>
              <div className="ts-company-card__actions">
                <Button variant="secondary" size="small" iconLeftName="edit" aria-label={`Edit branding for ${name}`}
                  data-testid="button-edit-single" onClick={onEditTheme} />
              </div>
            </section>
          </section>
          <section aria-label="Next actions">
            <nav className="ts-single-completion__next" aria-label="Branding follow-up actions">
              <CompletionActions />
            </nav>
          </section>
        </div>
      </div>
      <div className="ts-hero-right">
        <figure className="ts-copy-figure ts-single-completion__preview" aria-label={`Saved branding for ${name}`}>
          <CopyBrandingIllustration data={data} />
          <figcaption><strong>{name}</strong></figcaption>
        </figure>
      </div>
    </main>
  )
}