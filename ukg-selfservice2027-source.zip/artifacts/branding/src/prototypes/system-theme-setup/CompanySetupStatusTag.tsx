import { Tag } from '@ready/dls/compatibility'
import type { TagStatusColor } from '@ready/dls'
import { companyAttributionLabel } from './brandingStorage'
import type { BrandingCompletion, BrandingRevision, CompanySetupStatus } from './brandingStorage'
import './multiEinSelection.css'

export const SETUP_STATUS_LABELS: Record<CompanySetupStatus, string> = {
  done: 'Done',
  'in-process': 'In progress',
  'not-started': 'Not started',
}

const SETUP_STATUS_COLORS: Record<CompanySetupStatus, TagStatusColor> = {
  done: 'success',
  'in-process': 'warning',
  'not-started': 'neutral',
}

/** Only show actionable progress or revision details; completed and untouched cards need no badge. */
export default function CompanySetupStatusTag({ status, companyId, updated = false, editInProcess = false }: { status: CompanySetupStatus; companyId: string; updated?: boolean; editInProcess?: boolean }) {
  const label = status === 'done' ? editInProcess ? 'Edit in progress' : updated ? 'Updated' : null : status === 'in-process' ? SETUP_STATUS_LABELS[status] : null
  if (!label) return null
  return (
    <span className="ts-setup-status" data-testid={`status-setup-${companyId}`} data-status={status}>
      <span className="ts-visually-hidden">Setup status: </span>
      <Tag label={label} type="status" color={editInProcess ? SETUP_STATUS_COLORS['in-process'] : SETUP_STATUS_COLORS[status]} size="small" />
    </span>
  )
}

/** Completion and revision attribution share the plain-text slot below the EIN. */
export function CompanyRevisionText({ completion, revision, updated = false }: { completion?: BrandingCompletion; revision?: BrandingRevision; updated?: boolean }) {
  const label = !updated ? companyAttributionLabel(completion, revision) : undefined
  return label ? <span className="text-caption ts-company-revision">{label}</span> : null
}
