import { useEffect, useRef } from 'react'
import './messageEditor.css'

interface Props {
  value: string
  onChange: (value: string) => void
}

/** Visual rich-text prototype; message storage remains plain text. */
export default function MessageEditor({ value, onChange }: Props) {
  const editorRef = useRef<HTMLDivElement>(null)

  function formatMessage(element: HTMLDivElement, text: string) {
    element.replaceChildren()
    text.split('\n').forEach((line, index) => {
      const row = document.createElement('div')
      row.className = index === 0 ? 'ts-editor-heading' : 'ts-editor-line'
      const contact = index > 0 && line.match(/^\s*(Email|Phone):\s*(.*)$/i)
      if (contact) {
        row.className = 'ts-editor-contact'
        const label = document.createElement('strong')
        label.textContent = `${contact[1]}: `
        row.append(label, document.createTextNode(contact[2]))
      } else if (line) row.textContent = line
      else row.append(document.createElement('br'))
      element.append(row)
    })
  }

  useEffect(() => {
    const editor = editorRef.current
    if (editor && document.activeElement !== editor) formatMessage(editor, value)
  }, [value])

  return (
    <div className="ts-message-editor">
      <div className="ts-editor-menu" aria-hidden="true">
        <span>File</span><span>Edit</span><span>View</span><span>Insert</span><span>Format</span>
      </div>
      <div className="ts-editor-toolbar" role="toolbar" aria-label="Formatting preview (not enabled)">
        <button type="button" disabled aria-label="Undo">↶</button>
        <button type="button" disabled aria-label="Redo">↷</button>
        <span className="ts-editor-divider" />
        <button type="button" disabled className="ts-editor-paragraph">Paragraph ▾</button>
        <span className="ts-editor-divider" />
        <button type="button" disabled aria-label="Bold"><strong>B</strong></button>
        <button type="button" disabled aria-label="Italic"><em>I</em></button>
        <button type="button" disabled aria-label="Underline"><u>U</u></button>
        <span className="ts-editor-divider" />
        <button type="button" disabled aria-label="Bulleted list">• ≡</button>
        <button type="button" disabled aria-label="Numbered list">1. ≡</button>
      </div>
      <div
        ref={editorRef}
        id="employee-login"
        className="ts-editor-content"
        contentEditable="plaintext-only"
        role="textbox"
        aria-label="Employee login message"
        aria-multiline="true"
        onInput={event => {
          const editor = event.currentTarget
          const text = editor.innerText.replace(/\r\n/g, '\n')
          if (text.length > 5000) {
            editor.textContent = text.slice(0, 5000)
            const selection = window.getSelection()
            selection?.selectAllChildren(editor)
            selection?.collapseToEnd()
          }
          onChange(text.slice(0, 5000))
        }}
        onBlur={event => formatMessage(event.currentTarget, value)}
        aria-describedby="employee-editor-note"
      />
      <div className="ts-editor-status">
        <span id="employee-editor-note">The first line shows as the heading. Lines that start with Email: or Phone: show as contact details.</span>
        <span>{value.length}/5000</span>
      </div>
    </div>
  )
}