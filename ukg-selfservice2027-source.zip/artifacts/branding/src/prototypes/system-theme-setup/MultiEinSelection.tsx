import { useSearchParams } from 'react-router-dom'
import { Button, SelectableCard, SelectableCardGroup } from '@ready/dls/compatibility'
import './multiEinSelection.css'

import CompanySetupStatusTag from './CompanySetupStatusTag'
import CopyBrandingIllustration from './CopyBrandingIllustration'
import type { CompanySetupStatus } from './brandingStorage'
import type { CompanySummary, ThemeMap } from './copyBrandingState'
import type { ThemeSetupState } from './SystemThemeSetup'
import { useAskBrytePage } from '@workspace/setup-shared/ask-bryte'

/** The multi-EIN company chooser, laid out like the What's next page it leads to: the list on the left, one preview per company on the right. */
export default function MultiEinSelection({ companies, themes, fallbackData, onBack, onNext, statuses }: {
  /** The company catalog the prototype was opened with. */
  companies: CompanySummary[]
  /** Saved branding per company; a company without one shows the pending placeholder. */
  themes: ThemeMap
  /** The current setup state, drawn behind the pending placeholders as on What's next. */
  fallbackData: ThemeSetupState
  onBack: () => void
  onNext: (companyId: string) => void
  statuses: Record<string, CompanySetupStatus>
}) {
  useAskBrytePage('company-chooser', {
    companies: companies.length,
    savedCompanies: companies.filter(company => themes[company.id]).length,
  })
  const [params, setParams] = useSearchParams()
  const selected = (params.get('companies') ?? '').split(',').find(id =>
    companies.some(company => company.id === id))
  const selectCompany = (id: string) => {
    setParams(previous => {
      previous.set('companies', id)
      return previous
    }, { replace: true })
  }

  return (
    <main className="ts-hero-grid ts-intro-grid ts-company-split ts-multi-ein">
      <div className="ts-hero-left">
        <div className="ts-hero-left-inner">
          <h1 className="text-display ts-headline">Select a company</h1>
          <p className="text-body ts-body-text">Start with one company. Each is listed with its tax ID (EIN). Once its branding is saved, you can copy it to the others, so you only set it up once.</p>
          {/* One Tab stop for the whole list; the arrow keys move and select within it. */}
          <SelectableCardGroup className="ts-multi-ein-cards" aria-label="Companies">
            {companies.map(company => (
              <SelectableCard
                key={company.id}
                type="single"
                title={company.name}
                subHeading={`EIN: ${company.ein}`}
                selected={selected === company.id}
                onChange={() => selectCompany(company.id)}
              >
                <span className="sc__title ts-company-option__title">
                  {company.name}
                  <CompanySetupStatusTag status={statuses[company.id] ?? 'not-started'} companyId={company.id} />
                </span>
                <span className="sc__sub-heading">EIN: {company.ein}</span>
              </SelectableCard>
            ))}
          </SelectableCardGroup>
          <div className="ts-actions-row">
            <Button variant="secondary" onClick={onBack}>Back</Button>
            <Button variant="primary" disabled={!selected} onClick={() => {
              if (selected) onNext(selected)
            }}>Next</Button>
          </div>
        </div>
      </div>

      <div className="ts-hero-right">
        <div className="ts-copy-intro-stack">
          {companies.map(company => (
            <figure key={company.id} className="ts-copy-figure" data-testid={`card-preview-${company.id}`}>
              <CopyBrandingIllustration data={themes[company.id] ?? fallbackData} pending={!themes[company.id]} />
              <figcaption><strong>{company.name}</strong></figcaption>
            </figure>
          ))}
        </div>
      </div>
    </main>
  )
}
