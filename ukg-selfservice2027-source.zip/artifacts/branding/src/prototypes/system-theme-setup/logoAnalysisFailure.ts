/** Shown when logo analysis fails without an explanation, such as a dropped connection or an image the browser couldn’t prepare. */
export const LOGO_ANALYSIS_FALLBACK_MESSAGE =
  'We couldn’t finish checking your files for a logo. Your files are still here. Select Retry analysis to try again.'

/**
 * The failures the logo-detection route explains itself, by the `code` it sends with each (LogoDetectionError in the
 * API spec): images that need fixing, too many requests, unavailable, or taking too long. Other error responses can
 * arrive with the same statuses, like the server's generic request errors or a proxy's, but carry no code and aren't
 * written for the customer. Listed here rather than imported from the API client, which the design handoff export
 * leaves out; the tests hold this list to the spec's.
 */
export const EXPLAINED_FAILURE_CODES: readonly string[] = ['invalid_images', 'rate_limited', 'unavailable', 'timed_out']

/**
 * What the logo step says when analysis fails: the server's explanation when it sent one, so the customer can tell
 * whether to wait, retry or change their images, and the general message otherwise. The files stay either way.
 */
export function logoAnalysisFailureMessage(error: unknown): string {
  const explanation = serverExplanation(error)
  return explanation ? `${explanation} Your files are still here.` : LOGO_ANALYSIS_FALLBACK_MESSAGE
}

/** The generated API client rejects with the response's parsed JSON body as `data`. */
function serverExplanation(error: unknown): string | null {
  if (typeof error !== 'object' || error === null) return null
  const { data } = error as { data?: unknown }
  if (typeof data !== 'object' || data === null) return null
  const { code, error: text } = data as { code?: unknown; error?: unknown }
  if (typeof code !== 'string' || !EXPLAINED_FAILURE_CODES.includes(code)) return null
  if (typeof text !== 'string') return null
  const explanation = text.trim()
  if (!explanation) return null
  // The reassurance is added as its own sentence, so the explanation needs to end like one.
  return /[.!?]$/.test(explanation) ? explanation : `${explanation}.`
}
