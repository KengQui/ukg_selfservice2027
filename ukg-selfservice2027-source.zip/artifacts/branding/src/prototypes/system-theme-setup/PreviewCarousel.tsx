import { useEffect, useRef, useState, type ReactNode } from 'react'
import { ButtonTabSet } from '@ready/dls'
import './previewCarousel.css'

export interface PreviewSlide {
  id: string
  label: string
  content: ReactNode
}

/**
 * One preview at a time, chosen with a DLS ButtonTabSet above the slide title (the DLS has no carousel primitive).
 * Slides that are not showing are hidden from assistive technology and cannot take focus, so the preview stays
 * one readable region.
 */
export default function PreviewCarousel({ slides, label }: { slides: PreviewSlide[]; label: string }) {
  const [index, setIndex] = useState(0)
  const current = slides[Math.min(index, slides.length - 1)]
  // The viewport follows the showing slide's height, so the dots sit right under a short slide and a tall one alike.
  const slideElements = useRef<(HTMLDivElement | null)[]>([])
  const [slideHeights, setSlideHeights] = useState<number[]>([])
  useEffect(() => {
    const measure = () => setSlideHeights(slideElements.current.map(element => element?.offsetHeight ?? 0))
    const observer = new ResizeObserver(measure)
    slideElements.current.forEach(element => element && observer.observe(element))
    measure()
    return () => observer.disconnect()
  }, [slides.length])
  const viewportHeight = slideHeights[index]
  const show = (next: number) => setIndex(Math.max(0, Math.min(slides.length - 1, next)))

  return (
    <section className="ts-preview-carousel" aria-roledescription="carousel" aria-label={label} data-testid="preview-carousel">
      <div className="ts-preview-carousel__tabs">
        <ButtonTabSet tabs={slides.map(slide => slide.label)} activeIndex={index} onChange={show} size="small" />
      </div>
      <h2 className="ts-preview-title ts-preview-carousel__title" aria-live="polite" data-testid="text-preview-slide">{current.label}</h2>
      <div className="ts-preview-carousel__viewport" style={viewportHeight ? { height: viewportHeight } : undefined}>
        <div className="ts-preview-carousel__track" style={{ transform: `translateX(-${index * 100}%)` }}>
          {slides.map((slide, position) => {
            const hidden = position !== index
            return (
              <div key={slide.id} ref={element => { slideElements.current[position] = element }}
                className="ts-preview-carousel__slide" role="group" aria-roledescription="slide"
                aria-label={`${position + 1} of ${slides.length}: ${slide.label}`} aria-hidden={hidden} inert={hidden}
                data-testid={`slide-${slide.id}`}>
                {slide.content}
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
