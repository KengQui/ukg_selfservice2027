import assert from 'node:assert/strict'
import test from 'node:test'
import { LARGE_SAMPLE_COMPANIES, SAMPLE_COMPANIES, companyCatalog } from './companies.ts'
import { SOURCE_SEARCH_THRESHOLD } from './copyBrandingState.ts'

test('only the check-only "large" catalog replaces the demo catalog', () => {
  assert.strictEqual(companyCatalog(null), SAMPLE_COMPANIES)
  assert.strictEqual(companyCatalog(''), SAMPLE_COMPANIES)
  assert.strictEqual(companyCatalog('huge'), SAMPLE_COMPANIES)
  assert.strictEqual(companyCatalog('large'), LARGE_SAMPLE_COMPANIES)
  assert.equal(SAMPLE_COMPANIES.length, 3, 'the demo scenarios keep their three companies')
})

test('the large catalog extends the demo companies with enough distinct companies to reach the copy-source search', () => {
  assert.deepEqual(LARGE_SAMPLE_COMPANIES.slice(0, SAMPLE_COMPANIES.length), SAMPLE_COMPANIES)
  // More than SOURCE_SEARCH_THRESHOLD companies must be saved (to show the search) with one still left to copy to.
  assert.ok(LARGE_SAMPLE_COMPANIES.length >= SOURCE_SEARCH_THRESHOLD + 2)
  for (const field of ['id', 'name', 'ein']) {
    const values = LARGE_SAMPLE_COMPANIES.map(company => company[field])
    assert.equal(new Set(values).size, values.length, `every company has its own ${field}`)
  }
  for (const company of LARGE_SAMPLE_COMPANIES) assert.match(company.ein, /^\d{2}-\d{7}$/)
})
