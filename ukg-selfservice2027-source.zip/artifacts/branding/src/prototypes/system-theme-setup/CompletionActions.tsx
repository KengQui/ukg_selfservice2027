import { Button } from '@ready/dls/compatibility'
import { useNavigate, useLocation } from 'react-router-dom'
import { invitationSearch, showGlobalSetupPlaceholder } from './completionNavigation'

export default function CompletionActions() {
  const navigate = useNavigate()
  const { search } = useLocation()
  return <>
    <Button onClick={() => navigate(`/prototypes/company-setup-invite${invitationSearch(search)}`)}>
      Invite others to help
    </Button>
    <Button variant="secondary" onClick={() => showGlobalSetupPlaceholder()}>Return to Global Setup</Button>
  </>
}