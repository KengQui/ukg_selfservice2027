import { Menu, Search } from 'lucide-react'
import type { ThemeSetupState } from './SystemThemeSetup'
import { headerAppearance } from './contrast'
import { SAMPLE_LOGO } from './sampleLogo'

/** Visual sample of the signed-in header, not application navigation. */
export default function HeaderPreview({ data }: { data: ThemeSetupState }) {
  const header = headerAppearance(data.primaryColor, data.lightView)
  return (
    <div className="theme-setup-preview-header ts-header-sample" style={{
      background: header.background,
      color: header.textColor,
      borderBottom: data.lightView ? '1px solid var(--color-border)' : 'none',
    }}>
      <Menu size={18} role="img" aria-label="Menu icon" />
      <span style={{
        display: 'inline-flex', flexShrink: 0,
        border: data.colorBehindLogo ? `4px solid ${data.logoBackgroundColor}` : 'none',
        background: data.colorBehindLogo ? data.logoBackgroundColor : undefined,
      }}>
      <img className="ts-header-logo" src={data.logoUrl || SAMPLE_LOGO.logoUrl} alt="Company logo" style={{
        filter: (!data.logoUrl || data.logoUrl === SAMPLE_LOGO.logoUrl) && data.lightView ? 'brightness(0)' : undefined,
      }} />
      </span>
      {data.headerClock && <span className="theme-setup-preview-clock">10:10 AM (EDT)</span>}
      <div className="ts-header-tools">
        <Search size={18} role="img" aria-label="Search icon" />
        <span className="ts-header-avatar" role="img" aria-label="User avatar, SN">SN</span>
      </div>
    </div>
  )
}