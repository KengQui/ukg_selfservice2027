import assert from 'node:assert/strict'
import test from 'node:test'
import {
  copySources,
  copyVisualBranding,
  filterCopySources,
  freshBrandingDraft,
  withSingleCompanyDefaults,
  prepareReviewedBranding,
} from './copyBrandingState.ts'

const base = {
  logoUrl: null, logoFileName: null, logoSize: 0, isDocumentUpload: false,
  primaryColor: '#111111', accentColor: '#eeeeee', lightView: false, headerClock: true,
  reuseHeaderLogo: true, localLoginLogoUrl: null, localLoginLogoFileName: null,
  localLoginLogoSize: 0, employeeLoginMessage: 'Message', loginTagline: 'Name',
  loginClock: true, displayLoginLogo: true, colorBehindLogo: false,
  logoBackgroundColor: '#ffffff', faviconUrl: null, faviconFileName: null, faviconSize: 0,
  oauthIconUrl: null, oauthIconFileName: null, oauthIconSize: 0,
}
const companies = [
  { id: 'one', name: 'One', ein: '1' },
  { id: 'two', name: 'Two', ein: '2' },
  { id: 'three', name: 'Three', ein: '3' },
]

test('copy review starts with recipient text and preserves every other source setting', () => {
  const source = { ...base, loginTagline: 'A custom tagline', employeeLoginMessage: 'Welcome to One. [Company Name] support: support@acme.com' }
  const before = structuredClone(source)
  const reviewed = prepareReviewedBranding(source, 'One', 'Two')
  assert.equal(reviewed.loginTagline, 'Two')
  assert.equal(reviewed.employeeLoginMessage, 'Welcome to Two. Two support: support@acme.com')
  assert.equal(reviewed.primaryColor, source.primaryColor)
  assert.deepEqual(source, before)
  reviewed.employeeLoginMessage = 'My edited recipient message'
  const applied = copyVisualBranding({ one: source }, 'one', ['two'], reviewed)
  assert.equal(applied.two.employeeLoginMessage, 'My edited recipient message')
  assert.equal(applied.one.employeeLoginMessage, before.employeeLoginMessage)
})

test('recipient substitution escapes punctuation, replaces once, and treats dollar signs literally', () => {
  const source = { ...base, employeeLoginMessage: '[Company Name], A.C.M.E. (US) and A-C-M-E- (US)' }
  const reviewed = prepareReviewedBranding(source, 'A.C.M.E. (US)', 'A.C.M.E. (US) $&')
  assert.equal(reviewed.employeeLoginMessage, 'A.C.M.E. (US) $&, A.C.M.E. (US) $& and A-C-M-E- (US)')
})

test('new company drafts retain the full suggested login message and contact placeholders', () => {
  const defaults = { ...base, employeeLoginMessage: 'Welcome to [Company Name]\nIf you have any issues logging in, please get in touch with our support team:\n\nEmail: support@acme.com\nPhone: (555) 555-5555' }
  const draft = freshBrandingDraft(defaults, 'Acme Services, LLC')
  assert.equal(draft.loginTagline, 'Acme Services, LLC')
  assert.equal(draft.employeeLoginMessage, defaults.employeeLoginMessage.replaceAll('[Company Name]', 'Acme Services, LLC'))
  assert.ok(draft.employeeLoginMessage.includes('Email: support@acme.com'))
  assert.ok(draft.employeeLoginMessage.includes('Phone: (555) 555-5555'))
  assert.ok(defaults.employeeLoginMessage.includes('[Company Name]'))
})

test('single EIN uses its known name for the untouched login preview and message', () => {
  const defaults = { ...base, loginTagline: '[Company Name]', employeeLoginMessage: 'Welcome to [Company Name]' }
  const initial = withSingleCompanyDefaults(defaults, defaults, 'Bright Harbor Bakery LLC')
  assert.equal(initial.loginTagline, 'Bright Harbor Bakery LLC')
  assert.equal(initial.employeeLoginMessage, 'Welcome to Bright Harbor Bakery LLC')
  assert.equal(defaults.loginTagline, '[Company Name]')
  assert.equal(withSingleCompanyDefaults(defaults, defaults, undefined).loginTagline, '')
})

test('single EIN restores custom and intentionally cleared display names without replacing them', () => {
  const defaults = { ...base, loginTagline: '[Company Name]', employeeLoginMessage: 'Welcome to [Company Name]' }
  for (const loginTagline of ['Our public brand', '']) {
    const saved = { ...defaults, loginTagline, employeeLoginMessage: 'Our edited welcome' }
    const restored = withSingleCompanyDefaults(saved, defaults, 'Bright Harbor Bakery LLC')
    assert.equal(restored.loginTagline, loginTagline)
    assert.equal(restored.employeeLoginMessage, 'Our edited welcome')
  }
  assert.equal(withSingleCompanyDefaults(defaults, defaults, 'Bright Harbor Bakery LLC').loginTagline, 'Bright Harbor Bakery LLC')
})

test('single EIN defaults do not change other companies or their saved display names', () => {
  const one = freshBrandingDraft({ ...base, employeeLoginMessage: 'Welcome to [Company Name]' }, 'One')
  const two = { ...base, loginTagline: 'Two public name' }
  withSingleCompanyDefaults(base, base, 'Bright Harbor Bakery LLC')
  assert.equal(one.loginTagline, 'One')
  assert.equal(two.loginTagline, 'Two public name')
})

test('every company with saved branding is offered as a copying choice, identical looks included', () => {
  const themes = {
    one: { ...base, loginTagline: 'One', employeeLoginMessage: 'One message' },
    two: { ...base, loginTagline: 'One', employeeLoginMessage: 'One message' },
  }
  const sources = copySources(themes, companies, 'three', base)
  assert.deepEqual(sources.map(source => [source.company.id, source.saved]), [['one', true], ['two', true]])
  assert.strictEqual(sources[1].theme, themes.two)
})

test('before any confirmed save, even a supplied preview cannot be copied', () => {
  const preview = { ...base, primaryColor: '#333333' }
  assert.deepEqual(copySources({}, companies, 'two', preview), [])
  assert.deepEqual(copySources({}, companies, 'missing', preview), [])
})

test('Bright Harbor uses its sample email only in fresh or untouched suggested content', () => {
  const defaults = { ...base, loginTagline: '[Company Name]',
    employeeLoginMessage: 'Welcome to [Company Name]\nEmail: support@acme.com\nPhone: (555) 555-5555' }
  const name = 'Bright Harbor Bakery LLC'
  const expected = 'Welcome to Bright Harbor Bakery LLC\nEmail: support@brightharborbakery.com\nPhone: (555) 555-5555'
  assert.equal(freshBrandingDraft(defaults, name).employeeLoginMessage, expected)
  assert.equal(withSingleCompanyDefaults(defaults, defaults, name).employeeLoginMessage, expected)
  assert.equal(freshBrandingDraft(defaults, 'Acme Services, LLC').employeeLoginMessage,
    defaults.employeeLoginMessage.replaceAll('[Company Name]', 'Acme Services, LLC'))
  for (const employeeLoginMessage of [
    '', 'Contact support@acme.com for help',
    defaults.employeeLoginMessage.replaceAll('[Company Name]', name),
  ]) {
    const saved = { ...defaults, loginTagline: name, employeeLoginMessage }
    assert.equal(withSingleCompanyDefaults(saved, defaults, name).employeeLoginMessage, employeeLoginMessage)
  }
  assert.equal(defaults.employeeLoginMessage.includes('support@acme.com'), true)
})

test('the entire source is copied only to selected targets', () => {
  const themes = {
    one: { ...base, primaryColor: '#123456', loginTagline: 'One', employeeLoginMessage: 'One message' },
    two: { ...base, primaryColor: '#abcdef', loginTagline: 'Two', employeeLoginMessage: 'Two message' },
    three: { ...base, primaryColor: '#fedcba', loginTagline: 'Three', employeeLoginMessage: 'Three message' },
  }
  const copied = copyVisualBranding(themes, 'one', ['two', 'one'], themes.one)
  assert.equal(copied.two.primaryColor, '#123456')
  assert.deepEqual(copied.two, themes.one)
  assert.equal(copied.three.primaryColor, '#fedcba')
  assert.strictEqual(copied.one, themes.one)
})

test('new destination receives the source name and unedited suggested message', () => {
  const themes = { one: { ...base, primaryColor: '#123456', loginTagline: 'One' } }
  const copied = copyVisualBranding(themes, 'one', ['two'], themes.one)
  assert.equal(copied.two.primaryColor, '#123456')
  assert.equal(copied.two.loginTagline, 'One')
  assert.equal(copied.two.employeeLoginMessage, 'Message')
  assert.deepEqual(Object.keys(themes), ['one'])
})

test('a new look remains a draft and exiting leaves saved companies unchanged', () => {
  const saved = { one: { ...base, primaryColor: '#123456' } }
  const draft = freshBrandingDraft(base, 'Two')
  draft.primaryColor = '#999999'
  assert.deepEqual(Object.keys(saved), ['one'])
  assert.equal(saved.one.primaryColor, '#123456')
  assert.equal(draft.loginTagline, 'Two')
})

test('every reviewed setting reaches selected destinations without changing source or other companies', () => {
  const themes = {
    one: { ...base, logoUrl: 'source-logo', primaryColor: '#123456', accentColor: '#abcdef',
      headerClock: false, loginTagline: 'Source', employeeLoginMessage: 'Source message' },
    two: { ...base, logoUrl: 'old-logo', loginTagline: 'Destination', employeeLoginMessage: 'Destination message' },
    three: { ...base, primaryColor: '#fedcba' },
  }
  const original = structuredClone(themes)
  const reviewed = { ...themes.one, logoUrl: 'new-logo', logoFileName: 'brand.png', logoSize: 512,
    primaryColor: '#AABBCC', accentColor: '#334455', headerClock: true,
    loginTagline: 'Wrong name', employeeLoginMessage: 'Wrong message' }
  const copied = copyVisualBranding(themes, 'one', ['two', 'one', 'two'], reviewed)
  assert.equal(copied.two.logoUrl, 'new-logo')
  assert.equal(copied.two.logoFileName, 'brand.png')
  assert.equal(copied.two.logoSize, 512)
  assert.equal(copied.two.primaryColor, '#AABBCC')
  assert.equal(copied.two.accentColor, '#334455')
  assert.deepEqual(copied.two, reviewed)
  assert.deepEqual(copied.one, original.one)
  assert.deepEqual(copied.three, original.three)
  assert.deepEqual(themes, original)
})

test('unapplied review draft cannot mutate source or later copies', () => {
  const themes = { one: { ...base, primaryColor: '#123456' } }
  const draft = { ...themes.one, primaryColor: '#999999' }
  const copied = copyVisualBranding(themes, 'one', ['two'], themes.one)
  assert.equal(copied.two.primaryColor, '#123456')
  assert.equal(themes.one.primaryColor, '#123456')
  assert.equal(draft.primaryColor, '#999999')
})
test('filterCopySources matches a company by name or by the digits of its EIN', () => {
  const einCompanies = [
    { id: 'one', name: 'Acme Holdings, Inc.', ein: '12-3456789' },
    { id: 'two', name: 'Acme Services, LLC', ein: '23-4567890' },
    { id: 'three', name: 'Northwind Retail', ein: '34-5678901' },
  ]
  const sources = copySources({ one: base, two: base, three: base }, einCompanies, 'one', base)
  const ids = (query) => filterCopySources(sources, query).map(source => source.company.id)
  assert.deepEqual(ids('  '), ['one', 'two', 'three'])
  assert.deepEqual(ids('acme'), ['one', 'two'])
  assert.deepEqual(ids('RETAIL'), ['three'])
  assert.deepEqual(ids('12-3'), ['one'])
  assert.deepEqual(ids('01'), ['three'])
  assert.deepEqual(ids('2345'), ['one', 'two'])
  // Words never match against EIN digits, and unknown names match nothing.
  assert.deepEqual(ids('nobody'), [])
})
