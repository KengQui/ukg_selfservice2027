import { useState, useCallback, useEffect, useRef } from 'react'
import { useSearchParams } from 'react-router-dom'
import { readCompanySetup, sampleFromDocState } from '@workspace/setup-shared/prototypes/_shared-company-setup/useCompanySetupState'
import './themeSetup.css'
import StepScope from './StepScope'
import CopyBranding from './CopyBranding'
import BrandingCopyReview from './BrandingCopyReview'
import StepBrand from './StepBrand'
import StepColors from './StepColors'
import StepLogin from './StepLogin'
import StepAdvanced from './StepAdvanced'
import { Button, InlineMessage } from '@ready/dls/compatibility'
import StepDone from './StepDone'
import { SAMPLE_LOGO } from './sampleLogo'
import { restoreThemeSetup } from './savedState'
import { STARTING_COLORS, updateThemeSetup, withStartingPalette } from './palettes'
import type { CustomPalette, PaletteName } from './palettes'
import { copyVisualBranding, freshBrandingDraft, withSingleCompanyDefaults } from './copyBrandingState'
import type { ReviewedBranding } from './copyBrandingState'
import { copyEditSessionKey } from './copyEditSession'
import { rememberDemo, singleDemoConfirmed } from '@workspace/setup-shared/prototypes/branding-demo/demoNavigation'
import { markSingleStepShown } from '@workspace/setup-shared/prototypes/branding-demo/brandingProgress'
import { readBrandingStore, savedBranding, persistBranding, persistBrandingDraft, persistBrandingEditDraft, persistSingleEditDraft, persistBrandUploads, persistSingleBranding, companySetupStatus, updatedCompletionCompany, readSingleRevision, readSingleCompletion, DEMO_REVISION_ACTOR } from './brandingStorage'
import type { BrandingCompletion, BrandingRevision } from './brandingStorage'
import { emptyBrandUploads, restoreBrandUploads, storableBrandUploads } from './brandUploads'
import type { BrandUploads } from './brandUploads'
import { advancedStepRequired, brandingStorageKeys, brandingDemoScenario, isMultiEinNewSetup, isMultiEinScenario, isReturningScenario, resumesAtLogin } from '@workspace/setup-shared/prototypes/branding-demo/demoScenarios'
import MultiEinSelection from './MultiEinSelection'
import { companyCatalog } from './companies'
import { retainOwnBrandingEdit, showGlobalSetupPlaceholder } from './completionNavigation'

export type ThemeSetupState = {
  // Brand
  logoUrl: string | null
  logoFileName: string | null
  logoSize: number
  isDocumentUpload: boolean
  // Colors
  primaryColor: string
  contrastSourceColor?: string | null
  accentColor: string
  colorsExtractedFromLogo?: boolean
  selectedPalette?: PaletteName
  /** True once Custom holds the company's own colors (from its logo or entered by hand), not the starting colors. */
  customColors?: boolean
  presetPalettesOnly?: boolean
  customPalette?: CustomPalette
  // Header appearance
  lightView: boolean
  headerClock: boolean
  // Login
  reuseHeaderLogo: boolean
  localLoginLogoUrl: string | null
  localLoginLogoFileName: string | null
  localLoginLogoSize: number
  employeeLoginMessage: string
  loginTagline: string
  loginClock: boolean
  // Advanced
  displayLoginLogo: boolean
  colorBehindLogo: boolean
  logoBackgroundColor: string
  faviconUrl: string | null
  faviconFileName: string | null
  faviconSize: number
  oauthIconUrl: string | null
  oauthIconFileName: string | null
  oauthIconSize: number
}

export const DEFAULT_STATE: ThemeSetupState = {
  ...SAMPLE_LOGO,
  isDocumentUpload: false,
  ...STARTING_COLORS,
  selectedPalette: 'Custom',
  // Built-in starting colors, not the company's: Colors opens on a ready-made palette instead (withStartingPalette).
  customColors: false,
  lightView: false,
  headerClock: true,
  reuseHeaderLogo: true,
  localLoginLogoUrl: null,
  localLoginLogoFileName: null,
  localLoginLogoSize: 0,
  employeeLoginMessage: 'Welcome to [Company Name]\nIf you have any issues logging in, please get in touch with our support team:\n\nEmail: support@acme.com\nPhone: (555) 555-5555',
  loginTagline: '[Company Name]',
  loginClock: true,
  displayLoginLogo: true,
  colorBehindLogo: false,
  logoBackgroundColor: '#ffffff',
  faviconUrl: null,
  faviconFileName: null,
  faviconSize: 0,
  oauthIconUrl: null,
  oauthIconFileName: null,
  oauthIconSize: 0,
}

const STEPS = [
  { id: 'scope', label: 'scope' },
  { id: 'brand', label: 'brand' },
  { id: 'colors', label: 'colors' },
  { id: 'login', label: 'login' },
  { id: 'done', label: 'done' },
]

function companyListParams(params: URLSearchParams, returning: boolean) {
  params.set('page', 'multi-ein')
  if (returning) params.set('returning', '1')
  params.delete('companies')
  params.delete('fresh')
  params.delete('pending')
  params.delete('editFrom')
  return params
}

type SystemThemeSetupProps = {
  /**
   * Reports the "save and finish later" action while a wizard step (Brand, Theme, or Login page) is
   * showing, and null once it is not (or the wizard unmounts). The page header offers the action in every flow.
   */
  onSaveLaterChange?: (saveLater: (() => void) | null) => void
}

export default function SystemThemeSetup({ onSaveLaterChange }: SystemThemeSetupProps) {
  const [searchParams, setSearchParams] = useSearchParams()
  const scenario = brandingDemoScenario(searchParams.get('demo'))
  const storageKeys = brandingStorageKeys(scenario)
  const returningScenario = scenario !== null && isReturningScenario(scenario)
  const returning = searchParams.get('returning') === '1' || returningScenario
  // A new multi-EIN setup starts on the intro, then chooses the one company to work on. Its intro keeps the
  // chosen company in the URL (so the chooser restores the selection) and is marked with `page=intro`, so a
  // reload shows the intro again instead of that company's wizard.
  const multiEinSetup = isMultiEinNewSetup(scenario) && !returning
  // Every multi-EIN scenario, returning included, works through the company list and pauses with companies pending.
  const multiEinScenario = scenario !== null && isMultiEinScenario(scenario)
  const contrastExample = searchParams.get('contrastExample') === '1'
  // Advanced settings follows Login page only in the archived implementation team demos (see advancedStep below).
  // Anywhere else an Advanced settings URL recovers at Login page, the final step.
  const advancedRequested = searchParams.get('page') === 'advanced'
  const isMultiEinIntro = multiEinSetup && searchParams.get('page') === 'intro'
  // The demo catalog, or the larger check-only catalog when the URL asks for it (`catalog=large`).
  const companies = companyCatalog(searchParams.get('catalog'))
  const sourceCompany = companies.find(company => company.id === searchParams.get('companies'))
  // Single-EIN demos have their own fixture; ordinary setup uses the most recent Company Setup identity.
  // Do not use the multi-EIN catalog's first company as a fallback for an unrelated single setup.
  const singleCompanyName = () => (scenario && !multiEinScenario ? sampleFromDocState
    : multiEinScenario ? undefined
    : [readCompanySetup('manual'), readCompanySetup('from-doc')]
      .filter(record => record !== undefined)
      .sort((a, b) => (b.updatedAt ?? 0) - (a.updatedAt ?? 0))[0])?.legalName?.trim()

  const [brandingStore, setBrandingStore] = useState(() => {
    try {
      return readBrandingStore(localStorage.getItem(storageKeys.companies))
    } catch {
      return readBrandingStore(null)
    }
  })
  const companyThemes = savedBranding(brandingStore)
  const unconfirmedIds = Object.keys(brandingStore.themes).filter(id => !companyThemes[id])
  // Saved companies in the active catalog: a save kept from a larger catalog is not offered here.
  const savedCompanyIds = companies.filter(company => companyThemes[company.id]).map(company => company.id)
  // Once a company has branding, Select a company is the What's next list under its own title, in every multi-EIN
  // scenario: a returning customer arrives on it too (its completed cards open the saved look). The plain picker
  // shows only while nothing is saved.
  const selectCompanyIsList = savedCompanyIds.length > 0
  const statuses = Object.fromEntries(companies.map(company => [company.id, companySetupStatus(brandingStore, company.id)]))
  // A setup in process resumes at the colors step, where its draft shows; its kept brand uploads are one Back away.
  // Not every draft has uploads (Skip, earlier records), and without them the brand step would be a dead end.
  const wizardEntryStep = (companyId: string) => statuses[companyId] === 'in-process' ? 2 : 1

  const [currentStepIndex, setCurrentStepIndex] = useState(() => {
    if (searchParams.get('page') === 'completion' && !multiEinScenario && !sourceCompany) {
      try {
        if (localStorage.getItem(storageKeys.singleConfirmed) === '1' && localStorage.getItem(storageKeys.single)) return 4
      } catch { /* Unreadable storage does not confirm completion. */ }
    }
    if (advancedRequested || searchParams.get('page') === 'login') return 3
    if (searchParams.get('page') === 'colors') return 2
    if (contrastExample) return 2
    if (isMultiEinIntro) return 0
    if (sourceCompany) return searchParams.get('fresh') === '1' ? 1 : wizardEntryStep(sourceCompany.id)
    return 0
  })
  const [data, setData] = useState<ThemeSetupState>(() => sourceCompany
    ? freshBrandingDraft(DEFAULT_STATE, sourceCompany.name)
    : withSingleCompanyDefaults(DEFAULT_STATE, DEFAULT_STATE, singleCompanyName()))
  // The brand step's uploads live with the setup, so they survive leaving that step and resuming the company.
  const [brandUploads, setBrandUploads] = useState<BrandUploads>(emptyBrandUploads)
  const [saveError, setSaveError] = useState('')
  const [lastCopySourceId, setLastCopySourceId] = useState('')
  // Updated is only an in-memory post-save outcome; reentry reads the persisted revision instead.
  const [editOutcome, setEditOutcome] = useState<{ id: string; snapshot: string } | null>(null)
  const [singleRevision, setSingleRevision] = useState(() => readSingleRevision(localStorage.getItem(`${storageKeys.single}:revision`)))
  const [singleCompletion, setSingleCompletion] = useState(() => readSingleCompletion(localStorage.getItem(`${storageKeys.single}:completion`)))
  const [singleEditInProcess, setSingleEditInProcess] = useState(() => localStorage.getItem(`${storageKeys.single}:edit`) !== null)
  const revisionNow = (): BrandingRevision => ({ actor: DEMO_REVISION_ACTOR, savedAt: new Date().toISOString() })
  const recordOutcome = (id: string, theme: ThemeSetupState, wasSaved: boolean) => {
    setEditOutcome(wasSaved ? { id, snapshot: JSON.stringify(theme) } : null)
  }
  // Saves the setup from its last wizard step (Login, or Advanced settings where that step is required).
  const handleDone = () => {
    try {
      let wasSaved = sourceCompany ? sourceSaved : false
      if (sourceCompany) {
        setBrandingStore(persistBranding(localStorage, { [sourceCompany.id]: data }, storageKeys.companies, revisionNow()))
      } else {
        const saved = persistSingleBranding(localStorage, data, storageKeys.single, storageKeys.singleConfirmed, revisionNow())
        wasSaved = saved.wasSaved
        if (saved.revision) setSingleRevision(saved.revision)
        if (saved.completion) setSingleCompletion(saved.completion)
        setSingleEditInProcess(false)
      }
      recordOutcome(sourceCompany?.id ?? 'single', data, wasSaved)
      // Reentry preference is not the branding save; a failed preference must not undo successful navigation.
      try { rememberDemo(localStorage, scenario) } catch { /* Saved branding determines reentry. */ }
      setSaveError('')
      if (sourceCompany) {
        setSearchParams(prev => {
          if (!wasSaved) return companyListParams(prev, returning)
          prev.set('page', 'copy-branding')
          prev.delete('companies')
          prev.delete('fresh')
          prev.delete('editFrom')
          return prev
        })
        // Do not reset the wizard index while the URL transition is pending. For a returning
        // company, scope + the old wizard URL normalizes to Select a company and hides the
        // edit-completion outcome before What's next can render.
        return
      }
      setSearchParams(prev => { prev.set('page', 'completion'); prev.delete('editFrom'); return prev; })
      setCurrentStepIndex(STEPS.findIndex(step => step.id === 'done'))
    } catch {
      setSaveError(`Your branding wasn’t saved. An image may be too large, so try a smaller logo or icon, then select ${finishLabel} again. Your choices are still here.`)
    }
  }

  /** Saves the reviewed copy onto the chosen company; true once it is stored, false when the list should keep the review open. */
  const applyBrandingCopy = (copySourceId: string, targetIds: string[], reviewed: ReviewedBranding): boolean => {
    const targetId = targetIds[0]
    if (targetIds.length !== 1 || targetId === copySourceId || !companies.some(company => company.id === targetId)) {
      setSaveError('Select one company to copy branding to.')
      return false
    }
    try {
      const themes = savedBranding(readBrandingStore(localStorage.getItem(storageKeys.companies)))
      if (!themes[copySourceId]) {
        setSaveError('Choose a company with saved branding to copy from.')
        return false
      }
      const copied = copyVisualBranding(themes, copySourceId, targetIds, reviewed)
      const storedNext = persistBranding(localStorage, { [targetId]: copied[targetId] }, storageKeys.companies, revisionNow())
      recordOutcome(targetId, copied[targetId], Boolean(themes[targetId]))
      try { rememberDemo(localStorage, scenario) } catch { /* The recipient was saved successfully. */ }
      setBrandingStore(storedNext)
      setLastCopySourceId(copySourceId)
      setSaveError('')
      setSearchParams(previous => companyListParams(previous, returning))
      setCurrentStepIndex(0)
      return true
    } catch {
      setSaveError('This branding wasn’t applied. An image may be too large, so try a smaller logo or icon, then select Apply branding again. Your choices are still here.')
      return false
    }
  }

  // Draft tracking starts only after the selected company's stored setup has been restored into `data` and `brandUploads`.
  const draftSession = useRef<{
    id: string
    hydrated: ThemeSetupState
    hydratedUploads: BrandUploads
    settled: boolean
    uploadsSettled: boolean
  } | null>(null)
  const singleDraftSession = useRef<{ key: string; hydrated: ThemeSetupState; settled: boolean } | null>(null)

  useEffect(() => {
    draftSession.current = null
    singleDraftSession.current = null
    if (contrastExample) return
    // Unsaved setups never show the built-in starting colors as Custom; saved branding loads exactly as saved.
    let initial = withStartingPalette(sourceCompany ? freshBrandingDraft(DEFAULT_STATE, sourceCompany.name)
      : withSingleCompanyDefaults(DEFAULT_STATE, DEFAULT_STATE, singleCompanyName()))
    let initialUploads = emptyBrandUploads()
    let unconfirmedSingle = false
    try {
      const restoredStore = readBrandingStore(localStorage.getItem(storageKeys.companies))
      setBrandingStore(restoredStore)
      if (sourceCompany) {
        const startFresh = searchParams.get('fresh') === '1'
        const isSaved = restoredStore.savedIds.includes(sourceCompany.id)
        // The editor resumes an unfinished saved-company edit; the saved-look summary reads the live theme separately.
        const stored = startFresh ? undefined
          : isSaved ? restoredStore.editDrafts[sourceCompany.id] ?? restoredStore.themes[sourceCompany.id]
          : restoredStore.drafts[sourceCompany.id] ?? restoredStore.themes[sourceCompany.id]
        if (stored) initial = restoreThemeSetup(JSON.stringify(stored), DEFAULT_STATE)
        if (!isSaved) initial = withStartingPalette(initial)
        // Kept uploads belong to unsaved work only; a saved company's brand step starts empty, as before.
        if (!startFresh && !isSaved) initialUploads = restoreBrandUploads(restoredStore.brandUploads[sourceCompany.id])
        if (startFresh && !isSaved) {
          // A fresh start replaces the earlier draft and its uploads, then drops the flag so a reload resumes the new draft.
          persistBrandUploads(localStorage, sourceCompany.id, null, storageKeys.companies)
          setBrandingStore(persistBrandingDraft(localStorage, sourceCompany.id, initial, storageKeys.companies))
          setSearchParams(previous => { previous.delete('fresh'); return previous }, { replace: true })
        }
      } else {
        const saved = localStorage.getItem(storageKeys.single)
        if (saved) initial = withSingleCompanyDefaults(restoreThemeSetup(saved, DEFAULT_STATE), DEFAULT_STATE, singleCompanyName())
        const savedEdit = localStorage.getItem(`${storageKeys.single}:edit`)
        if (localStorage.getItem(storageKeys.singleConfirmed) === '1' && savedEdit) {
          initial = withSingleCompanyDefaults(restoreThemeSetup(savedEdit, DEFAULT_STATE), DEFAULT_STATE, singleCompanyName())
        }
        if (localStorage.getItem(storageKeys.singleConfirmed) !== '1') initial = withStartingPalette(initial)
        setSingleEditInProcess(localStorage.getItem(`${storageKeys.single}:edit`) !== null)
        unconfirmedSingle = scenario !== null && !isMultiEinScenario(scenario) && !isReturningScenario(scenario)
          && localStorage.getItem(storageKeys.singleConfirmed) !== '1'
      }
    } catch {
      // Unreadable storage falls back to the defaults prepared above.
    }
    if (sourceCompany) {
      draftSession.current = { id: sourceCompany.id, hydrated: initial, hydratedUploads: initialUploads, settled: false, uploadsSettled: false }
    } else if (unconfirmedSingle) {
      singleDraftSession.current = { key: storageKeys.single, hydrated: initial, settled: false }
    }
    setData(initial)
    setBrandUploads(initialUploads)
  }, [contrastExample, sourceCompany?.id, searchParams.get('fresh'), storageKeys.companies, storageKeys.single, storageKeys.singleConfirmed])

  // Archived implementation team demos add Advanced settings after Login page when setting up branding that isn't
  // saved yet. Edits of saved branding and every customer scenario finish on Login page.
  const sourceSaved = Boolean(sourceCompany && brandingStore.savedIds.includes(sourceCompany.id))
  let singleSaved = false
  try {
    singleSaved = !sourceCompany && !multiEinScenario && localStorage.getItem(storageKeys.singleConfirmed) === '1'
  } catch { /* Unreadable storage does not confirm a save. */ }
  const advancedStep = advancedStepRequired(scenario) && !sourceSaved && !singleSaved && !searchParams.get('editFrom')
  // An archived demo shows Advanced settings whenever its URL asks, even once saved (history Back after the save),
  // so a save from that step never races a redirect to Login page.
  const isAdvanced = advancedStepRequired(scenario) && advancedRequested

  // A customer scenario that lands on the Advanced settings URL is moved to Login, so the rest of the flow never sees it.
  useEffect(() => {
    if (advancedRequested && !advancedStepRequired(scenario)) {
      setSearchParams(previous => { previous.set('page', 'login'); return previous }, { replace: true })
    }
  }, [advancedRequested, scenario, setSearchParams])

  const page = searchParams.get('page')
  useEffect(() => {
    if (page !== 'completion' && page !== 'copy-branding' && page !== 'multi-ein') setEditOutcome(null)
  }, [page])
  // The multi-EIN intro is addressed by its URL, so it shows regardless of the step the wizard was on before
  // (browser history can bring that URL back while the step index still points into the wizard).
  // History Back can restore the completion URL without remounting the editor.
  const singleCompletionPage = page === 'completion' && !multiEinScenario && !sourceCompany
    && localStorage.getItem(storageKeys.singleConfirmed) === '1'
  useEffect(() => {
    if (page !== 'done' && (page !== 'completion' || singleCompletionPage)) return
    // The removed fallback never grants completion. Recover a list or a normal setup instead.
    setCurrentStepIndex(0)
    setSearchParams(previous => {
      if (multiEinScenario || sourceCompany) return companyListParams(previous, returning)
      previous.delete('page')
      previous.delete('editFrom')
      return previous
    }, { replace: true })
  }, [page, singleCompletionPage, multiEinScenario, sourceCompany?.id, returning, setSearchParams])
  const currentStep = isMultiEinIntro ? STEPS[0] : singleCompletionPage ? STEPS[4]
    : page === 'colors' ? STEPS[2] : page === 'login' || advancedRequested ? STEPS[3] : STEPS[currentStepIndex]
  const stepId = currentStep.id
  // A wizard step is showing while the brand, colors, or login step is on the page; the intro (with or
  // without its page marker), chooser, saved look, copy page, and completion screen are not steps.
  const stepShowing = (page === null || page === 'login' || page === 'colors' || isAdvanced) && ['brand', 'colors', 'login'].includes(stepId)
  // The wizard is open for a company while one of its steps is showing.
  const wizardOpen = Boolean(sourceCompany) && stepShowing

  useEffect(() => {
    const session = singleDraftSession.current
    if (!session || session.key !== storageKeys.single) return
    if (!session.settled) {
      if (data !== session.hydrated) return
      session.settled = true
    }
    if (!stepShowing || returning) return
    try {
      if (localStorage.getItem(storageKeys.singleConfirmed) !== '1') {
        localStorage.setItem(storageKeys.single, JSON.stringify(data))
      }
    } catch {
      // Background draft writes are best-effort; explicit saves report storage errors.
    }
  }, [data, stepShowing, returning, storageKeys.single, storageKeys.singleConfirmed])

  // For the Company Setup hub's progress: a single-EIN demo starts with a prepared draft that looks like kept work, so
  // record that a step has actually been shown. Nothing in Branding reads this.
  useEffect(() => {
    if (scenario && !multiEinScenario && stepShowing) markSingleStepShown(localStorage, scenario)
  }, [scenario, multiEinScenario, stepShowing])

  useEffect(() => {
    const session = draftSession.current
    if (!sourceCompany || !session || session.id !== sourceCompany.id) return
    if (!session.settled) {
      // Effects in the hydration commit still see the previous data; wait for the restored state.
      if (data !== session.hydrated) return
      session.settled = true
    }
    if (!wizardOpen || sourceSaved) return
    try {
      setBrandingStore(persistBrandingDraft(localStorage, sourceCompany.id, data, storageKeys.companies))
    } catch {
      // Draft writes are best-effort; storage problems surface only through the explicit save.
    }
  }, [data, sourceCompany?.id, wizardOpen, sourceSaved, storageKeys.companies])

  useEffect(() => {
    const session = draftSession.current
    if (!sourceCompany || !session || session.id !== sourceCompany.id) return
    if (!session.uploadsSettled) {
      if (brandUploads !== session.hydratedUploads) return
      session.uploadsSettled = true
    }
    // An analysis still running keeps the previous record; only settled outcomes are worth resuming.
    if (!wizardOpen || sourceSaved || brandUploads.status === 'processing') return
    try {
      setBrandingStore(persistBrandUploads(localStorage, sourceCompany.id, storableBrandUploads(brandUploads), storageKeys.companies))
    } catch {
      // Best-effort like the draft itself; a failed write never shows the save error.
    }
  }, [brandUploads, sourceCompany?.id, wizardOpen, sourceSaved, storageKeys.companies])

  // Save and finish later: keep the current choices where a reopened setup reads them, then leave for the hub.
  // An unsaved company keeps its draft and settled uploads (nothing counts as saved); a saved company keeps the
  // edits separately from live branding; the single flow does likewise. A refused write shows the save error and stays.
  const saveAndLeave = () => {
    try {
      if (sourceCompany && sourceSaved) {
        setBrandingStore(persistBrandingEditDraft(localStorage, sourceCompany.id, data, storageKeys.companies))
      } else if (sourceCompany) {
        let next = persistBrandingDraft(localStorage, sourceCompany.id, data, storageKeys.companies)
        // Like the background writes, an analysis still running keeps the previous uploads record.
        if (brandUploads.status !== 'processing') {
          next = persistBrandUploads(localStorage, sourceCompany.id, storableBrandUploads(brandUploads), storageKeys.companies)
        }
        setBrandingStore(next)
      } else {
        if (localStorage.getItem(storageKeys.singleConfirmed) === '1') {
          persistSingleEditDraft(localStorage, storageKeys.single, data)
          setSingleEditInProcess(true)
        } else localStorage.setItem(storageKeys.single, JSON.stringify(data))
      }
    } catch {
      setSaveError('Your progress wasn’t saved. An image may be too large, so try a smaller logo or icon, then select Save and finish later again. Your choices are still here.')
      return
    }
    try { rememberDemo(localStorage, scenario) } catch { /* Saved work determines reentry. */ }
    recordOutcome('', data, false)
    setSaveError('')
    showGlobalSetupPlaceholder(true)
  }
  // The report changes only with availability, and the reported action reads the latest handler through a ref, so a
  // fresh closure per render cannot loop the wrapper's state. Unmounting clears the report.
  const saveAndLeaveRef = useRef(saveAndLeave)
  useEffect(() => { saveAndLeaveRef.current = saveAndLeave })
  useEffect(() => {
    if (!onSaveLaterChange || !stepShowing) return
    onSaveLaterChange(() => saveAndLeaveRef.current())
    return () => onSaveLaterChange(null)
  }, [stepShowing, onSaveLaterChange])

  const handleNext = useCallback(() => {
    setCurrentStepIndex(prev => Math.min(prev + 1, STEPS.length - 1))
  }, [])

  const handleBack = useCallback(() => {
    setCurrentStepIndex(prev => Math.max(prev - 1, 0))
  }, [])

  // The origin lives in the URL, so a refresh never turns an edit into first-time setup.
  const backFromColors = () => {
    const origin = searchParams.get('editFrom')
    let singleSaved = false
    try {
      singleSaved = !sourceCompany && localStorage.getItem(storageKeys.singleConfirmed) === '1'
      if (sourceCompany && sourceSaved) {
        const store = readBrandingStore(localStorage.getItem(storageKeys.companies))
        const saved = savedBranding(store)[sourceCompany.id]
        if (!saved) throw new Error('Saved branding is unavailable.')
        retainOwnBrandingEdit(data, restoreThemeSetup(JSON.stringify(saved), DEFAULT_STATE),
          Boolean(store.editDrafts[sourceCompany.id]), draft => {
            setBrandingStore(persistBrandingEditDraft(localStorage, sourceCompany.id, draft, storageKeys.companies))
          })
      } else if (singleSaved) {
        const saved = localStorage.getItem(storageKeys.single)
        if (!saved) throw new Error('Saved branding is unavailable.')
        const hasEdit = retainOwnBrandingEdit(data,
          withSingleCompanyDefaults(restoreThemeSetup(saved, DEFAULT_STATE), DEFAULT_STATE, singleCompanyName()),
          localStorage.getItem(`${storageKeys.single}:edit`) !== null,
          draft => persistSingleEditDraft(localStorage, storageKeys.single, draft))
        setSingleEditInProcess(hasEdit)
      }
      setSaveError('')
    } catch {
      setSaveError('Your edits weren’t saved. Select Back to try again. Your choices are still here, and your saved branding hasn’t changed.')
      return
    }
    if (origin || sourceSaved || singleSaved) {
      setSearchParams(previous => {
        previous.delete('editFrom')
        if (origin === 'multi-ein' || origin === 'copy-branding') {
          companyListParams(previous, returning)
          previous.set('page', origin)
        } else previous.set('page', origin === 'completion' && singleSaved ? 'completion' : 'saved-look')
        return previous
      })
      return
    }
    setCurrentStepIndex(1)
    setSearchParams(previous => { previous.delete('page'); return previous })
  }

  const handleUpdate = useCallback((updates: Partial<ThemeSetupState>) => {
    setData(prev => updateThemeSetup(prev, updates))
  }, [])
  const discardEdit = () => {
    try {
      if (sourceCompany) {
        setBrandingStore(persistBrandingEditDraft(localStorage, sourceCompany.id, null, storageKeys.companies))
        setData(restoreThemeSetup(JSON.stringify(companyThemes[sourceCompany.id]), DEFAULT_STATE))
      } else {
        persistSingleEditDraft(localStorage, storageKeys.single, null)
        setSingleEditInProcess(false)
        const live = localStorage.getItem(storageKeys.single)
        if (live) setData(withSingleCompanyDefaults(restoreThemeSetup(live, DEFAULT_STATE), DEFAULT_STATE, singleCompanyName()))
      }
      setSaveError('')
      return true
    } catch {
      setSaveError('Your changes weren’t discarded. Select Discard changes again. Your saved branding hasn’t changed.')
      return false
    }
  }

  // The final step (Login page, or Advanced settings in the archived demos) saves the company's own branding.
  const finishLabel = 'Save branding'

  // Split steps own their progress inside the full-width controls column.
  const isIntro = currentStep.id === 'scope' || currentStep.id === 'done'
  const isSplitStep = ['colors', 'login'].includes(currentStep.id)
  const wrapperClass = isIntro || isSplitStep ? 'theme-setup-full' : 'theme-setup-wizard'

  // A stale intro bookmark must not send a confirmed setup through first-time onboarding.
  const savedIntro = page === 'intro' && scenario !== null
    && (multiEinScenario ? savedCompanyIds.length > 0 : singleDemoConfirmed(localStorage, scenario))
  const returningFromIntro = returning || savedIntro
  const needsReturningCompanyList = returningFromIntro && (
    (multiEinScenario && (
      page === 'intro'
       || (!sourceCompany && page !== 'multi-ein' && page !== 'copy-branding')
      || (page === 'multi-ein' && selectCompanyIsList && Boolean(sourceCompany))
      || (page === null && currentStep.id === 'scope')
    ))
    || (Boolean(sourceCompany) && page === 'intro')
  )
  // Apply resets the step index before the deferred list URL commits; keep its review route independent.
  const wouldShowReturningIntro = returningFromIntro && currentStep.id === 'scope'
    && page !== 'saved-look' && page !== 'completion' && page !== 'multi-ein' && page !== 'copy-branding'
  const needsReturningHub = wouldShowReturningIntro && !needsReturningCompanyList
  const needsReturningFlag = returningScenario && searchParams.get('returning') !== '1'
  useEffect(() => {
    if (needsReturningHub) {
      setSearchParams(previous => { previous.set('page', 'saved-look'); return previous }, { replace: true })
    } else if (needsReturningCompanyList || needsReturningFlag) {
      setSearchParams(previous => {
        if (needsReturningCompanyList) return companyListParams(previous, returningFromIntro)
        previous.set('returning', '1')
        return previous
      }, { replace: true })
    }
  }, [needsReturningCompanyList, needsReturningFlag, needsReturningHub, returningFromIntro, setSearchParams])
  if (needsReturningCompanyList || needsReturningHub || needsReturningFlag) return null

  if (searchParams.get('page') === 'saved-look') {
    return <BrandingCopyReview companies={companies} savedView data={sourceCompany && companyThemes[sourceCompany.id]
      ? companyThemes[sourceCompany.id] : !sourceCompany && localStorage.getItem(storageKeys.singleConfirmed) === '1'
        ? restoreThemeSetup(localStorage.getItem(storageKeys.single) ?? JSON.stringify(data), DEFAULT_STATE) : data} sourceId={sourceCompany?.id ?? ''}
      unfinishedEdit={sourceCompany ? brandingStore.editDrafts[sourceCompany.id] : singleEditInProcess ? data : undefined}
      savedStatus={sourceCompany
        ? companyThemes[sourceCompany.id] ? 'saved'
          : brandingStore.drafts[sourceCompany.id] ? 'in-process'
          : unconfirmedIds.includes(sourceCompany.id) ? 'unconfirmed' : 'preview'
        : scenario ? singleDemoConfirmed(localStorage, scenario) ? 'saved' : 'preview'
          : localStorage.getItem(storageKeys.singleConfirmed) === '1' ? 'saved'
          : localStorage.getItem(storageKeys.single) ? 'unconfirmed' : 'preview'}
      selectedIds={[]} error={saveError} onApply={() => {}} onFinishEdit={() => {}}
      onBack={() => {
        if (sourceCompany) setSearchParams(previous => companyListParams(previous, returning))
        else showGlobalSetupPlaceholder()
      }}
      onEdit={() => {
        if (sourceCompany && brandingStore.editDrafts[sourceCompany.id]) setData(restoreThemeSetup(JSON.stringify(brandingStore.editDrafts[sourceCompany.id]), DEFAULT_STATE))
        const savedEdit = localStorage.getItem(`${storageKeys.single}:edit`)
        if (!sourceCompany && singleEditInProcess && savedEdit) setData(withSingleCompanyDefaults(restoreThemeSetup(savedEdit, DEFAULT_STATE), DEFAULT_STATE, singleCompanyName()))
        setCurrentStepIndex(2)
        setSearchParams(previous => {
          if (scenario && (sourceCompany ? sourceSaved : !multiEinScenario && singleDemoConfirmed(localStorage, scenario))) {
            previous.set('returning', '1')
          }
          previous.set('editFrom', 'saved-look')
          previous.set('page', 'colors')
          return previous
        })
      }} />
  }

  // What's next and Select a company (once a company has branding) show the same company list with the same actions.
  const companyListProps = {
    companies, themes: companyThemes, fallbackData: data, error: saveError, unconfirmedIds, statuses,
    updatedCompanyId: page === 'copy-branding' || page === 'multi-ein' ? updatedCompletionCompany(editOutcome, companyThemes) : undefined,
    editDrafts: brandingStore.editDrafts,
    onSaveLaterChange,
    onSaveLaterEdit: (id: string, draft: ThemeSetupState) => {
      try {
        setBrandingStore(persistBrandingEditDraft(localStorage, id, draft, storageKeys.companies))
        setSaveError('')
        try { rememberDemo(localStorage, scenario) } catch { /* The edit draft was kept. */ }
        showGlobalSetupPlaceholder(true)
      } catch {
        setSaveError('Your progress wasn’t saved. An image may be too large, so try a smaller logo or icon, then select Save and finish later again. Your choices are still here.')
      }
    },
    onDiscardEdit: (id: string) => {
      try {
        setBrandingStore(persistBrandingEditDraft(localStorage, id, null, storageKeys.companies))
        setSaveError('')
        return true
      } catch {
        setSaveError('Your changes weren’t discarded. Select Discard changes again. Your saved branding hasn’t changed.')
        return false
      }
    },
    revisions: brandingStore.revisions,
    completions: brandingStore.completions,
    onBeginEdit: () => setEditOutcome(null),
    lastAppliedSourceId: lastCopySourceId,
    pendingCopyKey: copyEditSessionKey(storageKeys.companies),
    onApply: applyBrandingCopy,
    onSaveSource: (id: string, draft: ThemeSetupState) => {
      try {
        const wasSaved = readBrandingStore(localStorage.getItem(storageKeys.companies)).savedIds.includes(id)
        setBrandingStore(persistBranding(localStorage, { [id]: draft }, storageKeys.companies, revisionNow()))
        recordOutcome(id, draft, wasSaved)
        try { rememberDemo(localStorage, scenario) } catch { /* Branding was saved successfully. */ }
        if (id === sourceCompany?.id) setData(draft)
        setSaveError('')
        setSearchParams(previous => {
          previous.set('page', 'copy-branding')
          previous.delete('companies')
          previous.delete('fresh')
          return previous
        })
        return true
      } catch {
        setSaveError('Your branding wasn’t saved. An image may be too large, so try a smaller logo or icon, then save again. Your choices are still here.')
        return false
      }
    },
    onCreateNew: (id: string) => {
      setCurrentStepIndex(1)
      setSearchParams(previous => {
        previous.delete('page')
        previous.set('companies', id)
        previous.set('fresh', '1')
        previous.delete('editFrom')
        return previous
      })
    },
    onContinueSetup: (id: string) => {
      const openLogin = statuses[id] === 'in-process' && resumesAtLogin(scenario, id)
      setCurrentStepIndex(openLogin ? 3 : wizardEntryStep(id))
      setSearchParams(previous => {
        if (openLogin) previous.set('page', 'login')
        else previous.delete('page')
        previous.set('companies', id)
        previous.delete('fresh')
        previous.delete('editFrom')
        return previous
      })
    },
    // Edit opens Theme directly, with a refresh-safe return to the originating list.
    onEditCompleted: (id: string) => {
      setCurrentStepIndex(2)
      setSearchParams(previous => {
        previous.set('editFrom', page === 'copy-branding' ? 'copy-branding' : 'multi-ein')
        previous.set('page', 'colors')
        previous.set('companies', id)
        previous.delete('fresh')
        previous.delete('pending')
        return previous
      })
    },
    // Leaving the list is not another save or completion action.
    onDone: () => {
      try {
        rememberDemo(localStorage, scenario)
        setSaveError('')
        showGlobalSetupPlaceholder()
      } catch {
        setSaveError('We couldn’t mark your place for next time. Select Return to Global Setup again. Your saved branding hasn’t changed.')
      }
    },
  }

  // Multi-EIN demos and the ordinary prototype (where the Projects Copy branding shortcut lands) have this company
  // list; single-EIN demos have one company and never show it.
  if (searchParams.get('page') === 'copy-branding' && selectCompanyIsList && (multiEinScenario || scenario === null)) {
    return <CopyBranding key={`${sourceCompany?.id ?? ''}:${savedCompanyIds.join(',')}`} sourceId={sourceCompany?.id ?? ''} listPage="copy-branding" {...companyListProps} />
  }

  if (searchParams.get('page') === 'multi-ein' || searchParams.get('page') === 'copy-branding') {
    // Until a company has branding there is nothing to copy, so the page is the plain chooser: pick one and continue.
    // From the first save on it is the What's next list, so each company is copied to or edited from its card.
    if (selectCompanyIsList) {
      return <CopyBranding key={`select-company:${savedCompanyIds.join(',')}`} sourceId="" listPage="multi-ein"
        {...companyListProps} />
    }
    return <MultiEinSelection
      companies={companies}
      themes={companyThemes}
      fallbackData={data}
      statuses={statuses}
      onBack={() => {
      if (returning) { showGlobalSetupPlaceholder(); return }
      setCurrentStepIndex(0)
      setSearchParams(previous => {
        // A multi-EIN setup returns to its own intro and keeps the chosen company for the way back.
        if (multiEinSetup) previous.set('page', 'intro')
        else previous.delete('page')
        previous.delete('pending')
        return previous
      })
    }} onNext={companyId => {
      setCurrentStepIndex(wizardEntryStep(companyId))
      setSearchParams(previous => {
        if (returning) previous.set('page', 'saved-look')
        else previous.delete('page')
        previous.delete('pending')
        previous.set('companies', companyId)
        previous.delete('fresh')
        return previous
      })
    }} />
  }

  return (
    <div className={wrapperClass}>
      {saveError && <div role="alert"><InlineMessage theme="error">{saveError}</InlineMessage></div>}
      {/* Step Content */}
      <div className={`theme-setup-content${currentStep.id === 'login' ? ' ts-split-content' : ''}`}>
        {stepShowing && (sourceCompany ? Boolean(brandingStore.editDrafts[sourceCompany.id]) : singleEditInProcess) && <div className="ts-edit-draft-notice" role="status">
          <span>Your saved branding has not changed. An edit is in progress.</span>
          <Button variant="tertiary" size="small" onClick={discardEdit}>Discard changes</Button>
        </div>}
        {currentStep.id === 'scope' && (
          <StepScope data={data} multiEin={multiEinSetup} advancedStep={advancedStepRequired(scenario)} onNext={() => {
            if (multiEinSetup) {
              // Choose the company first; an earlier choice stays in the URL so the chooser shows it selected.
              setSearchParams(previous => { previous.set('page', 'multi-ein'); return previous })
              return
            }
            setSearchParams(previous => { previous.delete('companies'); return previous })
            handleNext()
          }} />
        )}
        {currentStep.id === 'brand' && (
          // Keyed per company so a company change while this step is showing ends its analyses, like leaving the step.
          <StepBrand key={sourceCompany?.id ?? 'single'} data={data} onUpdate={handleUpdate} uploads={brandUploads} onUploadsChange={setBrandUploads} onNext={handleNext} onBack={() => {
            if (searchParams.get('companies')) {
              // The picker keeps the company to show it selected; the list has no selection, so it drops it.
              setSearchParams(previous => {
                previous.set('page', 'multi-ein')
                if (selectCompanyIsList) { previous.delete('companies'); previous.delete('fresh') }
                return previous
              })
            } else if (returning) showGlobalSetupPlaceholder()
            else handleBack()
          }} />
        )}
        {currentStep.id === 'colors' && (
          <StepColors key={sourceCompany?.id ?? storageKeys.single} data={data} onUpdate={handleUpdate} onNext={() => {
            setCurrentStepIndex(3)
            setSearchParams(previous => { previous.set('page', 'login'); return previous })
          }} onBack={backFromColors} />
        )}
        {currentStep.id === 'login' && !isAdvanced && (
          <StepLogin
            data={data}
            onUpdate={handleUpdate}
            onNext={advancedStep
              ? () => setSearchParams(previous => { previous.set('page', 'advanced'); return previous })
              : handleDone}
            nextLabel={advancedStep ? 'Next' : finishLabel}
            advancedNext={advancedStep}
            onBack={() => {
              setCurrentStepIndex(2)
              setSearchParams(previous => { previous.set('page', 'colors'); return previous })
            }}
          />
        )}
        {currentStep.id === 'login' && isAdvanced && (
          <StepAdvanced
            data={data}
            onUpdate={handleUpdate}
            onNext={handleDone}
            nextLabel={finishLabel}
            onBack={() => setSearchParams(previous => { previous.set('page', 'login'); return previous })}
          />
        )}
        {currentStep.id === 'done' && singleCompletionPage && (
          <StepDone singleData={restoreThemeSetup(localStorage.getItem(storageKeys.single) ?? JSON.stringify(data), DEFAULT_STATE)} demo={scenario !== null}
             editInProcess={singleEditInProcess}
            updated={editOutcome?.id === 'single' && editOutcome.snapshot === localStorage.getItem(storageKeys.single)
               && localStorage.getItem(storageKeys.singleConfirmed) === '1'}
             revision={singleRevision}
              completion={singleCompletion}
              onEditTheme={() => { setEditOutcome(null); setCurrentStepIndex(2); setSearchParams(prev => { prev.set('editFrom', 'completion'); prev.set('page', 'colors'); return prev }) }} />
        )}
      </div>
    </div>
  )
}
