import { useCallback, useState } from 'react'
import { Dialog, SearchField } from '@ready/dls/compatibility'
import type { ThemeSetupState } from './SystemThemeSetup'
import { headerAppearance } from './contrast'
import { SAMPLE_LOGO } from './sampleLogo'
import { SOURCE_SEARCH_THRESHOLD, filterCopySources } from './copyBrandingState'
import type { CompanySummary, CopySource } from './copyBrandingState'
import './multiEinSelection.css'

/** Thumbnail of the company's header — the same logo treatment as the header preview, at option size. */
function HeaderLogoTile({ theme }: { theme: ThemeSetupState }) {
  const usesDefaultLogo = !theme.logoUrl || theme.logoUrl === SAMPLE_LOGO.logoUrl
  return (
    <span className="ts-look-option__logo" aria-hidden="true" style={{ background: headerAppearance(theme.primaryColor, theme.lightView).background }}>
      <img src={theme.logoUrl || SAMPLE_LOGO.logoUrl} alt="" style={{
        background: theme.colorBehindLogo ? theme.logoBackgroundColor : undefined,
        filter: usesDefaultLogo && theme.lightView ? 'brightness(0)' : undefined,
      }} />
    </span>
  )
}

/**
 * Asks which company's branding to copy onto `target`. It stays mounted while closed so the dialog can
 * return focus to the action that opened it (a card's Copy branding, or Change on the review).
 */
export default function CopySourceDialog({ target, sources, replacesSaved = false, replacesEdit = false, initialSourceId, onClose, onConfirm }: {
  /** The company receiving the copy; null keeps the dialog closed. */
  target: CompanySummary | null
  sources: CopySource[]
  /** The target already has saved branding, which the copy replaces once applied. */
  replacesSaved?: boolean
  replacesEdit?: boolean
  /** Preselected company: the one being copied from, the last one copied from, or the page's own company. */
  initialSourceId: string
  onClose: () => void
  onConfirm: (sourceId: string) => void
}) {
  // Choice and search belong to one opening: both clear when the dialog closes, so reopening it (for the next
  // company, or to change the source while reviewing) starts from the preselected company again.
  const [choice, setChoice] = useState<string | null>(null)
  const [query, setQuery] = useState('')
  const defaultId = sources.some(source => source.company.id === initialSourceId) ? initialSourceId : sources[0]?.company.id
  const selectedId = choice ?? defaultId
  const visible = filterCopySources(sources, query)
  // A company hidden by the search cannot be continued with; it comes back when the search clears.
  const selected = visible.find(source => source.company.id === selectedId)
  // Dialog re-runs its focus handling whenever onClose changes identity, so the close handler stays stable.
  const close = useCallback(() => {
    setChoice(null)
    setQuery('')
    onClose()
  }, [onClose])
  const confirm = () => {
    if (!selected) return
    setChoice(null)
    setQuery('')
    onConfirm(selected.company.id)
  }
  return (
    <Dialog open={target !== null} onClose={close} title={target ? `Copy branding to ${target.name}` : ''} size="normal"
      className="ts-copy-source-dialog"
      secondaryAction={{ label: 'Cancel', onClick: close }}
      primaryAction={{ label: 'Review branding', disabled: !selected, onClick: confirm }}>
      <p className="text-body ts-copy-source-lead">Choose the company to copy from. You can review and adjust the branding before it is saved.{replacesSaved && target ? ` It replaces the branding saved for ${target.name}.` : ''}{replacesEdit ? ' Applying the copy also discards its unfinished edit.' : ''}</p>
      {sources.length > SOURCE_SEARCH_THRESHOLD && (
        <div className="ts-look-search" onKeyDownCapture={event => {
          if (event.key === 'Escape' && query) {
            event.preventDefault()
            event.stopPropagation()
            setQuery('')
          }
        }}>
          <SearchField size="small" placeholder="Search by company name or EIN" value={query}
            onChange={setQuery} onClear={() => setQuery('')} />
        </div>
      )}
      <div role="radiogroup" aria-label="Companies to copy from" className="ts-look-list" data-testid="list-copy-sources">
        {visible.map(({ company, theme, saved }) => (
          <label key={company.id} className={`ts-look-option${company.id === selectedId ? ' is-selected' : ''}`} data-testid={`option-source-${company.id}`}>
            <input type="radio" name="copy-source" value={company.id} checked={company.id === selectedId}
              onChange={() => setChoice(company.id)} />
            <HeaderLogoTile theme={theme} />
            <span className="ts-look-option__text">
              <strong>{company.name}</strong>
              <span className="text-caption">EIN: {company.ein}{saved ? '' : ' · Preview — not saved'}</span>
            </span>
            <span className="ts-look-option__swatches">
              <i aria-label={`Primary color ${theme.primaryColor}`} style={{ background: theme.primaryColor }} />
              <i aria-label={`Accent color ${theme.accentColor}`} style={{ background: theme.accentColor }} />
            </span>
          </label>
        ))}
        {!visible.length && <p className="text-caption ts-look-empty">No companies match “{query.trim()}”. Try another company name or EIN.</p>}
      </div>
    </Dialog>
  )
}
