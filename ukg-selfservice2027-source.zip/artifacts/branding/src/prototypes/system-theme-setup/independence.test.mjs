import assert from 'node:assert/strict'
import { readdirSync, readFileSync } from 'node:fs'
import path from 'node:path'
import test from 'node:test'
import { fileURLToPath } from 'node:url'
import { ARCHIVED_DEMO_SCENARIOS, DEMO_SCENARIOS, brandingStorageKeys } from '../../../../../lib/setup-shared/src/prototypes/branding-demo/demoScenarios.ts'

const brandingRoot = fileURLToPath(new URL('../../../', import.meta.url))

function* sourceFiles(dir) {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const filename = path.join(dir, entry.name)
    if (entry.isDirectory()) yield* sourceFiles(filename)
    else if (/\.(?:tsx?|css)$/.test(entry.name)) yield filename
  }
}

test('branding source does not import playground source', () => {
  for (const filename of sourceFiles(path.join(brandingRoot, 'src'))) {
    const contents = readFileSync(filename, 'utf8')
    const imports = /\bfrom\s*['"]([^'"]+)['"]|\bimport\s*(?:\(\s*)?['"]([^'"]+)['"]|@import\s*['"]([^'"]+)['"]/g
    for (const match of contents.matchAll(imports)) {
      const specifier = match[1] ?? match[2] ?? match[3]
      assert.ok(!specifier.includes('ready-dls-kit'), `${filename} imports ${specifier}`)
      if (specifier.startsWith('.')) {
        assert.ok(path.resolve(path.dirname(filename), specifier).startsWith(path.join(brandingRoot, 'src') + path.sep),
          `${filename} escapes branding source through ${specifier}`)
      }
    }
  }
})

test('only the four customer demo labels are customer scenarios while existing storage keys remain stable', () => {
  assert.deepEqual(DEMO_SCENARIOS, {
    'new-single': 'New setup — Single EIN',
    'new-multi': 'New setup — Multi EIN',
    'returning-single': 'Returning customer — Single EIN',
    'returning-multi': 'Returning customer — Multi EIN',
  })
  // The implementation team demos are listed separately, only for the Archive group.
  assert.deepEqual(ARCHIVED_DEMO_SCENARIOS, {
    'implementation-single': 'Implementation team — Single EIN',
    'implementation-multi': 'Implementation team — Multi EIN',
  })
  for (const scenario of [...Object.keys(DEMO_SCENARIOS), ...Object.keys(ARCHIVED_DEMO_SCENARIOS)]) {
    const prefix = `ready-dls-demo-${scenario}`
    assert.deepEqual(brandingStorageKeys(scenario), {
      single: `${prefix}-theme-setup`,
      singleConfirmed: `${prefix}-single-confirmed`,
      companies: `${prefix}-ein-themes`,
    })
  }
  assert.deepEqual(brandingStorageKeys(null), {
    single: 'ready-dls-theme-setup',
    singleConfirmed: 'ready-dls-single-confirmed',
    companies: 'ready-dls-ein-themes',
  })
})

test('single and multi EIN saved-look summaries offer only Back and Edit', () => {
  const setup = readFileSync(path.join(brandingRoot, 'src/prototypes/system-theme-setup/SystemThemeSetup.tsx'), 'utf8')
  const review = readFileSync(path.join(brandingRoot, 'src/prototypes/system-theme-setup/BrandingCopyReview.tsx'), 'utf8')
  const savedLook = setup.split("if (searchParams.get('page') === 'saved-look') {")[1]?.split('// What\'s next and Select a company')[0]
  assert.ok(savedLook?.includes('savedView data={sourceCompany && companyThemes[sourceCompany.id]'))
  assert.ok(savedLook?.includes('unfinishedEdit={sourceCompany ? brandingStore.editDrafts[sourceCompany.id]'))
  assert.ok(savedLook?.includes('if (sourceCompany) setSearchParams(previous => companyListParams(previous, returning))'))
  assert.ok(savedLook?.includes('setCurrentStepIndex(2)'))
  assert.ok(!savedLook?.includes('completionActions'))
  const summaryActions = review.split('<div className="ts-actions">')[1]?.split('</div>')[0]
  assert.deepEqual([...summaryActions.matchAll(/data-testid="([^"]+)"/g)].map(match => match[1]),
    ['button-back-branding-review', 'button-edit-branding', 'button-apply-branding'])
  assert.ok(summaryActions.includes('{!savedView && <Button variant="primary"'))
  assert.ok(!summaryActions.includes('completionActions'))
})

test('successful saved edits lead to completion while first saves keep Done', () => {
  const setup = readFileSync(path.join(brandingRoot, 'src/prototypes/system-theme-setup/SystemThemeSetup.tsx'), 'utf8')
  const completion = readFileSync(path.join(brandingRoot, 'src/prototypes/system-theme-setup/SingleEinCompletion.tsx'), 'utf8')
  const list = readFileSync(path.join(brandingRoot, 'src/prototypes/system-theme-setup/CopyBranding.tsx'), 'utf8')
  const save = setup.split('const handleDone = () => {')[1]?.split('/** Saves the reviewed copy')[0]
  assert.ok(save?.includes("if (!wasSaved) return companyListParams(prev, returning)"))
  assert.ok(save?.includes("prev.set('page', 'copy-branding')"))
  assert.ok(save?.includes("prev.set('page', 'completion')"))
  assert.ok(!save?.includes("prev.set('page', 'saved-look')"))
  assert.ok(!save?.includes('setCurrentStepIndex(0)'))
  assert.ok(setup.includes("updatedCompanyId: page === 'copy-branding' || page === 'multi-ein' ? updatedCompletionCompany(editOutcome, companyThemes) : undefined"))
  assert.ok(completion.includes('>Completed</h2>'))
  assert.ok(list.includes('>Completed</h2>'))
  assert.ok(completion.includes('status="done" companyId="single" updated={updated} editInProcess={editInProcess}'))
  assert.ok(list.includes('updated={updatedCompanyId === company.id}'))
})