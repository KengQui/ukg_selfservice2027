import test from 'node:test'
import assert from 'node:assert/strict'
import { NORMAL_TEXT_MIN_CONTRAST, primaryTextContrast, primaryColorSuggestion, headerAppearance, applyContrastChoice } from './contrast.ts'

test('normal text uses WCAG AAA at 7:1', () => {
  assert.equal(NORMAL_TEXT_MIN_CONTRAST, 7)
  assert.equal(primaryTextContrast('#000').whiteRatio, 21)
  assert.equal(primaryTextContrast('#fff').blackRatio, 21)
  assert.equal(primaryTextContrast('#777777').whitePasses, false)
  assert.equal(primaryTextContrast('#777777').blackPasses, false)
  assert.equal(primaryTextContrast('#1D6E56').whitePasses, false)
})

test('checks both sides of the AAA white-text boundary without rounding ratios', () => {
  assert.equal(primaryTextContrast('#595959').whitePasses, true)
  assert.equal(primaryTextContrast('#5A5A5A').whitePasses, false)
})

test('mid-tone brand colors need adjustments to meet AAA', () => {
  const result = primaryTextContrast('#4A8E82')
  assert.equal(result.blackPasses, false)
  assert.equal(result.whitePasses, false)
  assert.equal(result.textColor, '#000000')
  assert.equal(primaryColorSuggestion('#4A8E82').options.length, 2)
})

test('passing colors need no adjustment; suggested colors meet AAA across many hues', () => {
  for (let r = 0; r <= 255; r += 51) {
    for (let g = 0; g <= 255; g += 51) {
      for (let b = 0; b <= 255; b += 51) {
        const color = '#' + [r, g, b].map(v => v.toString(16).padStart(2, '0')).join('')
        const result = primaryTextContrast(color)
        const ratio = result.textColor === '#FFFFFF' ? result.whiteRatio : result.blackRatio
        const suggestion = primaryColorSuggestion(color)
        if (ratio >= 7) assert.equal(suggestion, null)
        else {
          assert.ok(suggestion, color)
          for (const option of suggestion.options) {
            const adjusted = primaryTextContrast(option.color)
            assert.ok((option.textColor === '#FFFFFF' ? adjusted.whiteRatio : adjusted.blackRatio) >= 7, option.color)
            assert.equal(primaryColorSuggestion(option.color), null)
          }
        }
      }
    }
  }
})

test('supports short hex and rejects unsupported values', () => {
  assert.deepEqual(primaryTextContrast('#abc'), primaryTextContrast('#AABBCC'))
  for (const color of ['bad', '#abcd', '#12345', '#12345678', 'transparent']) {
    assert.throws(() => primaryTextContrast(color))
  }
})

test('white background and revert preserve the original brand color', () => {
  const source = '#4A8E82'
  const applied = applyContrastChoice(source, 'white')
  assert.equal(applied.primaryColor, source)
  assert.equal(headerAppearance(applied.primaryColor, applied.lightView).blackRatio, 21)
  const restored = JSON.parse(JSON.stringify(applied))
  assert.deepEqual(headerAppearance(restored.primaryColor, restored.lightView), headerAppearance(source, true))
  const reverted = applyContrastChoice(restored.contrastSourceColor, 'original')
  assert.equal(reverted.primaryColor, source)
  assert.equal(reverted.lightView, false)
  assert.deepEqual(headerAppearance(reverted.primaryColor, reverted.lightView), headerAppearance(source, false))
  for (const choice of ['darker', 'lighter']) {
    const adjusted = applyContrastChoice(source, choice)
    const preview = headerAppearance(adjusted.primaryColor, adjusted.lightView)
    assert.ok(choice === 'darker' ? preview.whitePasses : preview.blackPasses)
    assert.equal(adjusted.contrastSourceColor, source)
    assert.equal(applyContrastChoice(adjusted.contrastSourceColor, 'original').primaryColor, source)
  }
})