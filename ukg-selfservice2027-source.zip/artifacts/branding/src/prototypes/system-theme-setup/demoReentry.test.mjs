import assert from 'node:assert/strict'
import test from 'node:test'
import { demoEntryParams, singleDemoConfirmed, rememberedDemo, rememberDemo, forgetDemo } from '../../../../../lib/setup-shared/src/prototypes/branding-demo/demoNavigation.ts'
import { ARCHIVED_DEMO_SCENARIOS, DEMO_SCENARIOS, brandingDemoScenario, brandingStorageKeys, demoScenario, demoStartParams, normalizeDemoParams, advancedStepRequired, resumesAtLogin } from '../../../../../lib/setup-shared/src/prototypes/branding-demo/demoScenarios.ts'

function memory() {
  const values = new Map()
  return {
    getItem: key => values.get(key) ?? null,
    setItem: (key, value) => values.set(key, value),
    removeItem: key => values.delete(key),
  }
}

test('all four customer scenarios retain isolated keys and deterministic restart entries', () => {
  const storage = memory()
  const keys = Object.keys(DEMO_SCENARIOS).flatMap(scenario => Object.values(brandingStorageKeys(scenario)))
  assert.equal(new Set(keys).size, 12)
  for (const scenario of Object.keys(DEMO_SCENARIOS)) {
    assert.equal(demoEntryParams(scenario, storage).toString(), demoStartParams(scenario).toString())
  }
  assert.equal(resumesAtLogin('returning-multi', 'acme-services'), true)
  assert.equal(resumesAtLogin('new-multi', 'acme-services'), false)
  assert.equal(resumesAtLogin('returning-multi', 'acme-retail'), false)
})

test('single records and remembered launches do not confirm saves; explicit confirmation does', () => {
  const storage = memory()
  const keys = brandingStorageKeys('new-single')
  storage.setItem(keys.single, JSON.stringify({ primaryColor: '#123456' }))
  rememberDemo(storage, 'new-single')
  assert.equal(singleDemoConfirmed(storage, 'new-single'), false)
  assert.equal(demoEntryParams('new-single', storage).has('returning'), false)
  storage.setItem(keys.singleConfirmed, '1')
  assert.equal(singleDemoConfirmed(storage, 'new-single'), true)
  assert.equal(demoEntryParams('new-single', storage).get('page'), 'saved-look')
  assert.equal(demoEntryParams('new-single', storage).get('returning'), '1')
  assert.equal(demoEntryParams('returning-single', storage).get('page'), 'saved-look')
  assert.equal(demoStartParams('new-single').has('page'), false)
  for (const invalid of ['null', '[]', '"theme"', '{invalid']) {
    storage.setItem(keys.single, invalid)
    assert.equal(singleDemoConfirmed(storage, 'new-single'), false)
  }
})

test('multi reentry uses catalog-confirmed saves only, not legacy themes, drafts, or uploads', () => {
  const storage = memory()
  const keys = brandingStorageKeys('new-multi')
  const theme = { primaryColor: '#123456' }
  for (const store of [
    { 'acme-holdings': theme },
    { version: 2, themes: { 'acme-holdings': theme }, savedIds: [], drafts: { 'acme-services': theme } },
    { version: 2, themes: { unknown: theme }, savedIds: ['unknown'] },
  ]) {
    storage.setItem(keys.companies, JSON.stringify(store))
    assert.equal(demoEntryParams('new-multi', storage).has('returning'), false)
  }
  storage.setItem(keys.companies, JSON.stringify({ version: 2, themes: { 'acme-holdings': theme }, savedIds: ['acme-holdings'] }))
  assert.equal(demoEntryParams('new-multi', storage).get('page'), 'multi-ein')
  assert.equal(demoEntryParams('new-multi', storage).get('returning'), '1')
  assert.equal(demoEntryParams('returning-multi', storage).get('page'), 'multi-ein')
})

test('archived bookmarks open their own demos with their original storage, never customer or ordinary data', () => {
  const storage = memory()
  storage.setItem(brandingStorageKeys(null).single, 'ordinary branding')
  assert.deepEqual(Object.keys(ARCHIVED_DEMO_SCENARIOS), ['implementation-single', 'implementation-multi'])
  for (const archived of Object.keys(ARCHIVED_DEMO_SCENARIOS)) {
    // Archived demos are never customer scenarios.
    assert.equal(Object.hasOwn(DEMO_SCENARIOS, archived), false)
    assert.equal(demoScenario(archived), null)
    assert.equal(brandingDemoScenario(archived), archived)
    // Keys match the ones these demos used before they were retired, so earlier saves load again.
    assert.deepEqual(brandingStorageKeys(archived), {
      single: `ready-dls-demo-${archived}-theme-setup`,
      singleConfirmed: `ready-dls-demo-${archived}-single-confirmed`,
      companies: `ready-dls-demo-${archived}-ein-themes`,
    })
    for (const other of [null, ...Object.keys(DEMO_SCENARIOS)]) {
      for (const key of Object.values(brandingStorageKeys(other))) {
        assert.equal(Object.values(brandingStorageKeys(archived)).includes(key), false, `${archived} shares ${key}`)
      }
    }
    const archiveKeys = brandingStorageKeys(archived)
    storage.setItem(archiveKeys.single, 'archived branding')
    // Old bookmarks, Advanced settings included, are not redirected.
    for (const page of ['advanced', 'login', null]) {
      const old = new URLSearchParams({ demo: archived, companies: 'acme-holdings' })
      if (page) old.set('page', page)
      assert.equal(normalizeDemoParams(old), null)
    }
    assert.equal(advancedStepRequired(archived), true)
    assert.equal(demoStartParams(archived).toString(), `standalone=1&demo=${archived}`)
    assert.equal(storage.getItem(archiveKeys.single), 'archived branding')
    assert.equal(storage.getItem(brandingStorageKeys(null).single), 'ordinary branding')
  }
  // An archived save reopens the archived demo as returning, from its own data only.
  const single = brandingStorageKeys('implementation-single')
  storage.setItem(single.single, JSON.stringify({ primaryColor: '#123456' }))
  storage.setItem(single.singleConfirmed, '1')
  assert.equal(demoEntryParams('implementation-single', storage).get('page'), 'saved-look')
  assert.equal(demoEntryParams('new-single', storage).has('returning'), false)
  // The main Open button resumes customer demos only; archived demos stay in the Archive group.
  rememberDemo(storage, 'new-multi')
  rememberDemo(storage, 'implementation-single')
  assert.equal(rememberedDemo(storage), 'new-multi')
  storage.setItem('ready-dls-demo-last-resumable', 'implementation-multi')
  assert.equal(rememberedDemo(storage), null)
})

test('customer scenarios finish at Login page and Advanced bookmarks normalize without changing identity', () => {
  for (const scenario of [...Object.keys(DEMO_SCENARIOS), null]) {
    assert.equal(advancedStepRequired(scenario), false)
    const old = new URLSearchParams({ page: 'advanced', companies: 'acme-services' })
    if (scenario) old.set('demo', scenario)
    const normalized = normalizeDemoParams(old)
    assert.equal(normalized.get('page'), 'login')
    assert.equal(normalized.get('demo'), scenario)
    assert.equal(normalized.get('companies'), 'acme-services')
    assert.equal(normalizeDemoParams(normalized), null)
  }
})

test('restart forgets only its own preference; inaccessible storage cannot fabricate confirmation', () => {
  const storage = memory()
  rememberDemo(storage, 'new-single')
  forgetDemo(storage, 'new-multi')
  assert.equal(rememberedDemo(storage), 'new-single')
  forgetDemo(storage, 'new-single')
  assert.equal(rememberedDemo(storage), null)
  const denied = { getItem() { throw new Error('Denied') } }
  assert.equal(rememberedDemo(denied), null)
  assert.equal(singleDemoConfirmed(denied, 'new-single'), false)
  assert.equal(demoEntryParams('new-multi', denied).has('returning'), false)
})