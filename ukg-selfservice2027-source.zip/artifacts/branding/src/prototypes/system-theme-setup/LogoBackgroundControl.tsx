import { useEffect, useRef, useState } from 'react'
import { Button, Input } from '@ready/dls/compatibility'
import type { ThemeSetupState } from './SystemThemeSetup'
import { COLOR_CODE_MESSAGE, colorPickerValue, isValidColorCode } from './palettes'

export default function LogoBackgroundControl({ data, onUpdate }: {
  data: ThemeSetupState
  onUpdate: (updates: Partial<ThemeSetupState>) => void
}) {
  const [colorText, setColorText] = useState(data.logoBackgroundColor || '#ffffff')
  useEffect(() => {
    setColorText(data.logoBackgroundColor || '#ffffff')
  }, [data.logoBackgroundColor])
  const colorPicker = useRef<HTMLInputElement>(null)
  const validColor = isValidColorCode(colorText)
  const changeColor = (color: string) => {
    setColorText(color)
    if (isValidColorCode(color)) onUpdate({ logoBackgroundColor: color })
  }
  return (
    <div style={{ marginTop: 24 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16 }}>
        <label htmlFor="colorBehindLogoToggle" style={{ fontWeight: 500 }}>Enable color behind logo</label>
        <button id="colorBehindLogoToggle" type="button" role="switch" aria-checked={!!data.colorBehindLogo}
          onClick={() => {
            if (data.colorBehindLogo) onUpdate({ colorBehindLogo: false })
            else {
              setColorText('#ffffff')
              onUpdate({ colorBehindLogo: true, logoBackgroundColor: '#ffffff' })
            }
          }}
          style={{ width: 40, height: 24, flexShrink: 0, border: 0, borderRadius: 20, padding: 3, background: data.colorBehindLogo ? '#015151' : '#777', cursor: 'pointer' }}>
          <span style={{ display: 'block', width: 18, height: 18, borderRadius: '50%', background: '#fff', transform: data.colorBehindLogo ? 'translateX(16px)' : 'none' }} />
        </button>
      </div>
      {data.colorBehindLogo && (
        <div style={{ display: 'flex', gap: 'var(--space-400)', marginTop: 16 }}>
          <div style={{ position: 'relative', width: 48, height: 48, marginTop: 24, flexShrink: 0 }}>
            <div style={{ position: 'absolute', width: '100%', height: '100%', borderRadius: 'var(--radius-200)', background: data.logoBackgroundColor, border: '1px solid var(--color-border)', pointerEvents: 'none' }} />
            <input ref={colorPicker} id="logoBackgroundColor" type="color" aria-label="Choose logo background color"
              value={colorPickerValue(data.logoBackgroundColor)} onChange={event => changeColor(event.target.value)}
              style={{ opacity: 0, width: '100%', height: '100%', cursor: 'pointer' }} />
          </div>
          <div style={{ width: 220, maxWidth: '100%', minWidth: 0 }}>
            <Input id="logo-background-hex" label="Background color" value={colorText} onChange={changeColor} size="large" />
            {!validColor && <p role="alert" style={{ color: 'var(--color-status-error)', fontSize: 12 }}>{COLOR_CODE_MESSAGE}</p>}
            <Button variant="tertiary" highEmphasis size="small" style={{ padding: 0, textDecoration: 'underline' }}
              onClick={() => colorPicker.current?.click()}>Choose color</Button>
          </div>
        </div>
      )}
    </div>
  )
}