import test from 'node:test'
import assert from 'node:assert/strict'
import { restoreThemeSetup } from './savedState.ts'
import { SAMPLE_LOGO } from './sampleLogo.ts'
import { customSnapshot, PRESET_PALETTES, selectPalette, updateThemeSetup } from './palettes.ts'
import { applyContrastChoice } from './contrast.ts'

const defaults = {
  ...SAMPLE_LOGO,
  isDocumentUpload: false,
  primaryColor: '#4A8E82',
  accentColor: '#D85A30',
  lightView: false,
  headerClock: false,
  reuseHeaderLogo: true,
  localLoginLogoUrl: null,
  localLoginLogoFileName: null,
  localLoginLogoSize: 0,
  employeeLoginMessage: 'Welcome',
  applicantLoginMessage: 'Welcome',
  loginClock: false,
}

test('save/reload preserves deliberately removed logos and manual theme values', () => {
  const selected = {
    ...defaults,
    logoUrl: null,
    logoFileName: null,
    logoSize: 0,
    primaryColor: '#123456',
    employeeLoginMessage: `${'x'.repeat(200)}\nEmployee message`,
    applicantLoginMessage: `${'y'.repeat(200)}\nApplicant message`,
  }
  assert.deepEqual(restoreThemeSetup(JSON.stringify(selected), defaults), {
    ...selected, selectedPalette: 'Custom', customPalette: customSnapshot(selected), customColors: true,
  })
})

test('missing fields get defaults without overriding explicitly saved fields', () => {
  const restored = restoreThemeSetup(JSON.stringify({ primaryColor: '#123456' }), defaults)
  assert.equal(restored.logoUrl, SAMPLE_LOGO.logoUrl)
  assert.equal(restored.primaryColor, '#123456')
  assert.equal(restored.loginClock, false)
  assert.equal(restored.selectedPalette, 'Custom')
  assert.equal(restored.customPalette.primaryColor, '#123456')
})

const choose = (state, name) => updateThemeSetup(state, selectPalette(state, name))

test('refreshes the old sample login message while preserving custom messages', () => {
  const oldSample = 'Welcome to Acme Corp. Sign in with your company credentials.'
  assert.equal(restoreThemeSetup(JSON.stringify({ employeeLoginMessage: oldSample }), defaults).employeeLoginMessage, defaults.employeeLoginMessage)
  assert.equal(restoreThemeSetup(JSON.stringify({ employeeLoginMessage: 'Our custom welcome' }), defaults).employeeLoginMessage, 'Our custom welcome')
})

test('all six screenshot palettes apply exact colors, clear comparison, and start with Light view off', () => {
  assert.deepEqual(PRESET_PALETTES.map(p => [p.name, p.primaryColor, p.accentColor]), [
    ['Teal', '#015151', '#2AD6C4'], ['Gray', '#3D475C', '#C2C9D6'],
    ['Navy', '#1F3D7A', '#ADC2EB'], ['Neutral', '#3576B0', '#C2DEF0'],
    ['Purple', '#1F257A', '#C1C4F0'], ['Sky Blue', '#1F657A', '#ADDCEB'],
  ])
  let state = { ...defaults, colorsExtractedFromLogo: true, lightView: true, contrastSourceColor: '#777777' }
  const original = customSnapshot(state)
  for (let round = 0; round < 3; round++) {
    for (const preset of PRESET_PALETTES) {
      state = choose(state, preset.name)
      assert.equal(state.primaryColor, preset.primaryColor)
      assert.equal(state.accentColor, preset.accentColor)
      assert.equal(state.lightView, false)
      assert.equal(state.contrastSourceColor, null)
      assert.equal(state.colorsExtractedFromLogo, false)
      assert.deepEqual(state.customPalette, original)
    }
    state = choose(state, 'Custom')
    assert.deepEqual(customSnapshot(state), original)
  }
})

test('preset edits become Custom and named palettes remain immutable', () => {
  for (const field of ['primaryColor', 'accentColor']) {
    let state = choose(defaults, 'Teal')
    state = updateThemeSetup(state, { [field]: '#123456', contrastSourceColor: null })
    assert.equal(state.selectedPalette, 'Custom')
    assert.equal(state.customPalette[field], '#123456')
    state = choose(state, 'Teal')
    assert.equal(state[field], PRESET_PALETTES[0][field])
    state = choose(state, 'Custom')
    assert.equal(state[field], '#123456')
  }
})

test('contrast comparisons, original restore, and white-only changes retain correct identity', () => {
  let state = choose(defaults, 'Neutral')
  const source = state.primaryColor
  state = updateThemeSetup(state, applyContrastChoice(source, 'white'))
  assert.equal(state.selectedPalette, 'Neutral')
  state = updateThemeSetup(state, applyContrastChoice(source, 'original'))
  assert.equal(state.selectedPalette, 'Neutral')
  state = updateThemeSetup(state, applyContrastChoice(source, 'darker'))
  assert.equal(state.selectedPalette, 'Custom')
  const darker = state.primaryColor
  state = choose(choose(state, 'Navy'), 'Custom')
  assert.equal(state.primaryColor, darker)
  assert.equal(state.contrastSourceColor, source)
  state = updateThemeSetup(state, applyContrastChoice(state.contrastSourceColor, 'lighter'))
  assert.notEqual(state.primaryColor, darker)
  state = updateThemeSetup(state, applyContrastChoice(state.contrastSourceColor, 'original'))
  assert.equal(state.primaryColor, source)
  assert.equal(state.lightView, false)
})

test('successful extraction becomes Custom and skip preserves extracted draft under Teal', () => {
  let state = choose(defaults, 'Gray')
  state = updateThemeSetup(state, {
    selectedPalette: 'Custom', primaryColor: '#345678', accentColor: '#ABCDEF',
    contrastSourceColor: null, colorsExtractedFromLogo: true,
  })
  assert.equal(state.selectedPalette, 'Custom')
  assert.equal(state.customPalette.colorsExtractedFromLogo, true)
  state = choose(state, 'Teal')
  assert.equal(state.selectedPalette, 'Teal')
  assert.equal(state.colorsExtractedFromLogo, false)
  assert.equal(choose(state, 'Custom').colorsExtractedFromLogo, true)
})

test('local save/reload retains palette, custom comparison draft, and header appearance changes', () => {
  let state = updateThemeSetup(defaults, applyContrastChoice(defaults.primaryColor, 'darker'))
  state = updateThemeSetup(state, { lightView: true, headerClock: true, loginClock: false })
  const custom = customSnapshot(state)
  state = choose(state, 'Purple')
  state = updateThemeSetup(state, { lightView: true })
  state = restoreThemeSetup(JSON.stringify(state), defaults)
  assert.equal(state.selectedPalette, 'Purple')
  assert.equal(state.lightView, true)
  assert.equal(state.headerClock, true)
  assert.equal(state.loginClock, false)
  assert.deepEqual(customSnapshot(choose(state, 'Custom')), custom)
  const legacy = restoreThemeSetup(JSON.stringify({ primaryColor: '#015151', accentColor: '#2AD6C4', lightView: true }), defaults)
  assert.equal(legacy.selectedPalette, 'Custom')
  assert.equal(legacy.lightView, true)
})

test('restoreThemeSetup incorporates new advanced defaults for existing saves', () => {
  const oldSave = JSON.stringify({
    primaryColor: '#123456',
    headerClock: false,
    loginClock: false,
  })

  // Mocking defaults that include advanced properties
  const advancedDefaults = {
    ...defaults,
    displayLoginLogo: true,
    colorBehindLogo: false,
    faviconUrl: null,
    faviconFileName: null,
    faviconSize: 0,
    oauthIconUrl: null,
    oauthIconFileName: null,
    oauthIconSize: 0,
  }

  const restored = restoreThemeSetup(oldSave, advancedDefaults)

  // Preserves old values
  assert.equal(restored.primaryColor, '#123456')
  assert.equal(restored.headerClock, false)
  assert.equal(restored.loginClock, false)

  // Gets new defaults
  assert.equal(restored.displayLoginLogo, true)
  assert.equal(restored.colorBehindLogo, false)
  assert.equal(restored.faviconFileName, null)
  assert.equal(restored.oauthIconFileName, null)
})

test('restoreThemeSetup maintains new advanced properties when saved', () => {
  const advancedDefaults = {
    ...defaults,
    displayLoginLogo: true,
    colorBehindLogo: false,
    faviconUrl: null,
    faviconFileName: null,
    faviconSize: 0,
    oauthIconUrl: null,
    oauthIconFileName: null,
    oauthIconSize: 0,
  }

  const newSave = JSON.stringify({
    displayLoginLogo: false,
    colorBehindLogo: true,
    faviconUrl: 'data:image/png;base64,favicon',
    faviconFileName: 'favicon.png',
    faviconSize: 1024,
    oauthIconUrl: 'data:image/jpeg;base64,oauth',
    oauthIconFileName: 'oauth.jpg',
    oauthIconSize: 2048,
  })

  const restored = restoreThemeSetup(newSave, advancedDefaults)

  assert.equal(restored.displayLoginLogo, false)
  assert.equal(restored.colorBehindLogo, true)
  assert.equal(restored.faviconUrl, 'data:image/png;base64,favicon')
  assert.equal(restored.faviconFileName, 'favicon.png')
  assert.equal(restored.faviconSize, 1024)
  assert.equal(restored.oauthIconUrl, 'data:image/jpeg;base64,oauth')
  assert.equal(restored.oauthIconFileName, 'oauth.jpg')
  assert.equal(restored.oauthIconSize, 2048)
})