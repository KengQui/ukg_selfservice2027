import SingleEinCompletion from './SingleEinCompletion'
import type { ThemeSetupState } from './SystemThemeSetup'
import type { BrandingCompletion, BrandingRevision } from './brandingStorage'
import { useAskBrytePage } from '@workspace/setup-shared/ask-bryte'

interface Props {
  singleData: ThemeSetupState
  demo?: boolean
  onEditTheme: () => void
  updated?: boolean
  editInProcess?: boolean
  revision?: BrandingRevision
  completion?: BrandingCompletion
}

export default function StepDone({ singleData, demo = false, onEditTheme, updated = false, editInProcess = false, revision, completion }: Props) {
  useAskBrytePage('done', { single: true, updated, editInProcess })
  return <SingleEinCompletion data={singleData} demo={demo} updated={updated} editInProcess={editInProcess} revision={revision} completion={completion}
    onEditTheme={onEditTheme} />
}