import type { ThemeSetupState } from './SystemThemeSetup'

export const PRESET_PALETTES = [
  { name: 'Teal', primaryColor: '#015151', accentColor: '#2AD6C4' },
  { name: 'Gray', primaryColor: '#3D475C', accentColor: '#C2C9D6' },
  { name: 'Navy', primaryColor: '#1F3D7A', accentColor: '#ADC2EB' },
  { name: 'Neutral', primaryColor: '#3576B0', accentColor: '#C2DEF0' },
  { name: 'Purple', primaryColor: '#1F257A', accentColor: '#C1C4F0' },
  { name: 'Sky Blue', primaryColor: '#1F657A', accentColor: '#ADDCEB' },
] as const

export type PaletteName = typeof PRESET_PALETTES[number]['name'] | 'Custom'
export type CustomPalette = Pick<ThemeSetupState,
  'primaryColor' | 'accentColor' | 'lightView' | 'contrastSourceColor' | 'colorsExtractedFromLogo'>

export const COLOR_CODE_MESSAGE = 'Use # followed by 3 or 6 digits or letters A–F, like #1D6E56.'
export const isValidColorCode = (value: string) => /^#(?:[0-9A-F]{3}|[0-9A-F]{6})$/i.test(value)

/** Native color inputs require six digits, even though code fields accept shorthand. */
export function colorPickerValue(value: string): string {
  if (!isValidColorCode(value)) return '#000000'
  return value.length === 4 ? '#' + [...value.slice(1)].map(digit => digit + digit).join('') : value
}

/** The app's built-in starting colors. They belong to no company, so they never appear as Custom. */
export const STARTING_COLORS = { primaryColor: '#4A8E82', accentColor: '#D85A30' } as const

const sameColor = (a: unknown, b: string) => typeof a === 'string' && a.toUpperCase() === b.toUpperCase()

/**
 * Whether Custom holds the company's own colors: taken from its logo, entered or picked by hand, or a contrast choice.
 * Saves from before this was tracked are read here, wherever they enter a Colors editor (wizard, copy review, pending
 * copy edits): live Custom colors count as the company's, so saved edits are never discarded; behind a ready-made
 * palette, the Custom comparison counts only if it came from a logo or differs from the starting colors that an older
 * Skip stored there.
 */
export function hasCompanyColors(data: ThemeSetupState): boolean {
  if (typeof data.customColors === 'boolean') return data.customColors
  if (!data.selectedPalette || data.selectedPalette === 'Custom') return true
  const custom = data.customPalette
  if (!custom || typeof custom.primaryColor !== 'string' || typeof custom.accentColor !== 'string') return false
  return Boolean(custom.colorsExtractedFromLogo)
    || !sameColor(custom.primaryColor, STARTING_COLORS.primaryColor)
    || !sameColor(custom.accentColor, STARTING_COLORS.accentColor)
}

/** A selected Custom always stays listed so the chooser matches what's shown. */
export function offersCustomPalette(data: ThemeSetupState): boolean {
  return data.selectedPalette === 'Custom' || hasCompanyColors(data)
}

export function paletteChoices(data: ThemeSetupState) {
  if (!offersCustomPalette(data)) return [...PRESET_PALETTES]
  const custom = data.customPalette ?? data
  return [{ name: 'Custom' as const, primaryColor: custom.primaryColor, accentColor: custom.accentColor }, ...PRESET_PALETTES]
}

/** A valid manual edit uses the visible colors as Custom, without modifying any built-in palette. */
export function manualColorUpdates(field: 'primaryColor' | 'accentColor', value: string): Partial<ThemeSetupState> {
  if (!isValidColorCode(value)) return {}
  return {
    [field]: value, selectedPalette: 'Custom', colorsExtractedFromLogo: false, customColors: true,
    ...(field === 'primaryColor' ? { contrastSourceColor: null } : {}),
  }
}

export function customSnapshot(data: CustomPalette): CustomPalette {
  return {
    primaryColor: data.primaryColor,
    accentColor: data.accentColor,
    lightView: data.lightView,
    contrastSourceColor: data.contrastSourceColor ?? null,
    colorsExtractedFromLogo: data.colorsExtractedFromLogo ?? false,
  }
}

/** Named palettes are immutable; Custom retains its own comparison session. */
export function selectPalette(data: ThemeSetupState, name: PaletteName): Partial<ThemeSetupState> {
  const customPalette = !data.selectedPalette || data.selectedPalette === 'Custom'
    ? customSnapshot(data) : data.customPalette ?? customSnapshot(data)
  // Picking keeps whether Custom holds company colors (resolving older saves); it never turns starting colors into them.
  const customColors = hasCompanyColors(data)
  if (name === 'Custom') return { ...customPalette, selectedPalette: name, customPalette, customColors }
  const preset = PRESET_PALETTES.find(palette => palette.name === name)!
  return {
    primaryColor: preset.primaryColor, accentColor: preset.accentColor,
    selectedPalette: name, customPalette, lightView: false,
    contrastSourceColor: null, colorsExtractedFromLogo: false, customColors,
  }
}

/**
 * Skipping the brand uploads continues with a ready-made palette. A preset the company already chose
 * (for example in a resumed draft) stays exactly as it is; only Custom or unset colors fall back to Teal.
 */
export function readyMadePalette(data: ThemeSetupState): Partial<ThemeSetupState> {
  const hasPreset = PRESET_PALETTES.some(palette => palette.name === data.selectedPalette)
  return hasPreset ? {} : selectPalette(data, 'Teal')
}

/**
 * Colors opens on a ready-made palette unless the company already has its own colors selected as Custom.
 * Used when continuing from the brand step with uploads and when an unsaved setup is hydrated.
 */
export function startingPalette(data: ThemeSetupState): Partial<ThemeSetupState> {
  return data.selectedPalette === 'Custom' && hasCompanyColors(data) ? {} : readyMadePalette(data)
}

export function withStartingPalette(data: ThemeSetupState): ThemeSetupState {
  const updates = startingPalette(data)
  return Object.keys(updates).length ? updateThemeSetup(data, updates) : data
}

/** Captures header appearance changes alongside Custom color edits. */
export function updateThemeSetup(data: ThemeSetupState, updates: Partial<ThemeSetupState>): ThemeSetupState {
  const changesColors = (updates.primaryColor !== undefined && updates.primaryColor !== data.primaryColor)
    || (updates.accentColor !== undefined && updates.accentColor !== data.accentColor)
  const next = { ...data, ...updates }
  if (!updates.selectedPalette && changesColors) next.selectedPalette = 'Custom'
  // A color change or contrast choice that lands on Custom is the company's own choice, so Custom stays available.
  const leavesPreset = data.selectedPalette !== undefined && data.selectedPalette !== 'Custom'
  if (updates.customColors === undefined && next.selectedPalette === 'Custom' && (changesColors || leavesPreset)) {
    next.customColors = true
  }
  next.selectedPalette ??= 'Custom'
  if (next.selectedPalette === 'Custom') next.customPalette = customSnapshot(next)
  return next
}