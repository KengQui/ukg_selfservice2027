import type { ReactNode } from 'react'
import { Button, Icon } from '@ready/dls/compatibility'
import { AILogo } from '@ready/dls/ai'
import type { ThemeSetupState } from './SystemThemeSetup'
import { useAskBrytePage } from '@workspace/setup-shared/ask-bryte'

interface Props {
  data: ThemeSetupState
  /** A new multi-EIN setup: the primary action leads to the company chooser instead of the Brand step. */
  multiEin?: boolean
  /** Archived implementation team demos only: Advanced settings follows Login page. */
  advancedStep?: boolean
  onNext: () => void
}

function Checklist({ children }: { children: ReactNode }) {
  return (
    <div className="ts-checklist-row">
      <span className="ts-check-circle" aria-hidden="true">
        <Icon name="statusSuccessSolid" size={14} />
      </span>
      <span>{children}</span>
    </div>
  )
}

export default function StepScope({ multiEin = false, advancedStep = false, onNext }: Props) {
  useAskBrytePage('intro', { multiEin, advancedStep })
  return (
    <div className="ts-hero-grid ts-intro-grid ts-scope-intro">
      <div className="ts-hero-left">
        <div className="ts-hero-left-inner">
          <h1 className="text-display ts-headline">
            Bring Your Brand to Work
          </h1>
          <p className="text-body ts-body-text">
            Give your team a familiar experience with your company’s logo and colors.{' '}{advancedStep
              ? 'Add your branding, choose a palette, customize the login page, and add the favicon and OAuth icon in advanced settings.'
              : 'Add your branding, choose a palette, and customize the login page.'}
            {multiEin && <>
              {' '}You’ll pick one company to start with. Once its branding is finished, you can copy it to your other companies.
            </>}
          </p>

          <div className="ts-stat-row">
            <div>
              <p className="text-heading-md" style={{ margin: '0 0 var(--space-100)' }}>5 min</p>
              <p className="text-caption ts-stat-caption">Estimated setup time</p>
            </div>
            <div>
              <p className="text-heading-md" style={{ margin: '0 0 var(--space-100)' }}>{advancedStep ? '4 steps' : '3 steps'}</p>
              <p className="text-caption ts-stat-caption">{advancedStep ? 'Brand assets, theme, login page, advanced settings' : 'Brand assets, theme, login page'}</p>
            </div>
            <div>
              <p className="text-heading-md" style={{ margin: '0 0 var(--space-100)' }}>Anytime</p>
              <p className="text-caption ts-stat-caption">Update your branding</p>
            </div>
          </div>

          <p className="text-caption ts-eyebrow">Bring your brand along</p>
          <Checklist>Your company logo</Checklist>
          <Checklist>A brand guide or style guide</Checklist>
          <Checklist>A screenshot of your company website</Checklist>
          <Checklist>A branded brochure, presentation saved as PDF, or letterhead</Checklist>

          <div className="ts-actions-row">
            <Button onClick={onNext}>Add your branding</Button>
          </div>
        </div>
      </div>

      <div className="ts-hero-right">
        <div className="ts-preview-card">
          <div className="ts-preview-card-header">
            <p className="ts-preview-card-eyebrow">Your company’s identity</p>
            <p className="ts-preview-card-title">A familiar brand for your team</p>
            <div className="ts-doc-graphic">
              <div className="ts-doc-lines">
                <span style={{ display: 'block', height: 6, borderRadius: 4, background: 'rgba(255,255,255,.35)', width: '82%' }} />
                <span style={{ display: 'block', height: 6, borderRadius: 4, background: 'rgba(255,255,255,.35)', width: '58%' }} />
                <span style={{ display: 'block', height: 6, borderRadius: 4, background: 'rgba(255,255,255,.18)', width: '90%' }} />
                <span style={{ display: 'block', height: 6, borderRadius: 4, background: 'rgba(255,255,255,.18)', width: '68%' }} />
              </div>
              <span className="ts-sparkle-circle" aria-hidden="true">
                <AILogo variant="secondary" size={16} />
              </span>
            </div>
          </div>
          <div className="ts-preview-card-body">
            <p className="ts-preview-card-label">What you’ll customize</p>
            <div className="ts-preview-field-list">
              <p className="ts-preview-field-row">Company logo</p>
              <p className="ts-preview-field-row">Primary color</p>
              <p className="ts-preview-field-row">Accent color</p>
              <p className="ts-preview-field-row">Login page branding</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
