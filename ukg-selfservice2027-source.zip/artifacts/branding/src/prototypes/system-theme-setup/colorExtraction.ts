import type { ThemeSetupState } from './SystemThemeSetup'

export type LogoColors = { primary: string; accent: string }

/** A new logo without usable colors keeps both live colors and Custom's comparison session. */
export function logoColorUpdates(data: ThemeSetupState, colors: LogoColors | null): Partial<ThemeSetupState> {
  if (colors) return {
    selectedPalette: 'Custom', primaryColor: colors.primary, accentColor: colors.accent,
    contrastSourceColor: null, colorsExtractedFromLogo: true, customColors: true,
  }
  return {
    colorsExtractedFromLogo: false,
    ...(data.customPalette ? { customPalette: { ...data.customPalette, colorsExtractedFromLogo: false } } : {}),
  }
}

/** Null means a decoded logo has no usable colors; unreadable images reject instead. */
export async function extractDominantColors(dataUrl: string): Promise<LogoColors | null> {
  return new Promise((resolve, reject) => {
    const img = new Image()
    
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas')
        const MAX_SIZE = 150 // Scale down for performance and deterministic bucketing
        let scale = 1
        if (img.width > MAX_SIZE || img.height > MAX_SIZE) {
          scale = Math.min(MAX_SIZE / img.width, MAX_SIZE / img.height)
        }
        
        canvas.width = Math.max(1, Math.floor(img.width * scale))
        canvas.height = Math.max(1, Math.floor(img.height * scale))

        const ctx = canvas.getContext('2d')
        if (!ctx) throw new Error('Could not read image colors')

        ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
        const data = imageData.data

        const colorCounts = new Map<string, number>()

        for (let i = 0; i < data.length; i += 4) {
          const r = data[i]
          const g = data[i+1]
          const b = data[i+2]
          const a = data[i+3]

          // Ignore mostly transparent pixels
          if (a < 128) continue
          
          // Ignore pure or near-white pixels
          if (r > 240 && g > 240 && b > 240) continue

          // Quantize to deterministic buckets (intervals of 16)
          const qR = Math.floor(r / 16) * 16
          const qG = Math.floor(g / 16) * 16
          const qB = Math.floor(b / 16) * 16
          
          const hex = '#' + [qR, qG, qB]
            .map(x => Math.min(255, x).toString(16).padStart(2, '0'))
            .join('')
            .toUpperCase()
          
          colorCounts.set(hex, (colorCounts.get(hex) || 0) + 1)
        }

        if (colorCounts.size === 0) {
          return resolve(null)
        }

        const sorted = Array.from(colorCounts.entries()).sort((a, b) => b[1] - a[1])
        const primary = sorted[0][0]
        let accent = sorted.length > 1 ? sorted[1][0] : primary

        // Find a distinct accent color
        for (let i = 1; i < sorted.length; i++) {
          if (colorDistance(primary, sorted[i][0]) > 50) {
            accent = sorted[i][0]
            break
          }
        }

        resolve({ primary, accent })
      } catch (error) {
        reject(error)
      }
    }

    img.onerror = () => {
      reject(new Error('Could not open image'))
    }

    img.src = dataUrl
  })
}

function hexToRgb(hex: string) {
  const match = hex.replace(/^#/, '').match(/.{2}/g)
  if (!match) return [0, 0, 0]
  return match.map(x => parseInt(x, 16))
}

function colorDistance(hex1: string, hex2: string) {
  const [r1, g1, b1] = hexToRgb(hex1)
  const [r2, g2, b2] = hexToRgb(hex2)
  return Math.sqrt(Math.pow(r1 - r2, 2) + Math.pow(g1 - g2, 2) + Math.pow(b1 - b2, 2))
}
