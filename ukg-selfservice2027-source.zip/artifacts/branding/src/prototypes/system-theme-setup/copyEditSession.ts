import type { ThemeSetupState } from './SystemThemeSetup'

export type CopyEditorStep = 'theme' | 'login'
export type CopyEditorState = { step: CopyEditorStep; draft: ThemeSetupState }
export type PendingCopyEdit = CopyEditorState & {
  version: 1
  page: 'multi-ein' | 'copy-branding'
  listSourceId: string
  sourceId: string
  targetId: string
}

/** Per-tab recovery is separate from saved branding and company setup drafts. */
export const copyEditSessionKey = (brandingKey: string) => `${brandingKey}-pending-copy-edit`

export function readPendingCopyEdit(key: string): PendingCopyEdit | null {
  try {
    const raw = sessionStorage.getItem(key)
    if (!raw) return null
    const value: unknown = JSON.parse(raw)
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null
    const edit = value as Record<string, unknown>
    if (edit.version !== 1 || (edit.page !== 'multi-ein' && edit.page !== 'copy-branding')
      || typeof edit.listSourceId !== 'string'
      || typeof edit.sourceId !== 'string' || !edit.sourceId
      || typeof edit.targetId !== 'string' || !edit.targetId || edit.sourceId === edit.targetId
      || (edit.step !== 'theme' && edit.step !== 'login' && edit.step !== 'advanced')
      || !edit.draft || typeof edit.draft !== 'object' || Array.isArray(edit.draft)) return null
    const draft = edit.draft as Record<string, unknown>
    if (typeof draft.primaryColor !== 'string' || typeof draft.accentColor !== 'string'
      || typeof draft.loginTagline !== 'string' || typeof draft.employeeLoginMessage !== 'string') return null
    // Older pending copies keep every choice but resume at the remaining final step.
    return { ...edit, step: edit.step === 'advanced' ? 'login' : edit.step } as PendingCopyEdit
  } catch {
    return null
  }
}

export function writePendingCopyEdit(key: string, edit: PendingCopyEdit): boolean {
  try {
    sessionStorage.setItem(key, JSON.stringify(edit))
    return true
  } catch {
    return false
  }
}

export function clearPendingCopyEdit(key: string): boolean {
  try {
    sessionStorage.removeItem(key)
    return true
  } catch {
    return false
  }
}