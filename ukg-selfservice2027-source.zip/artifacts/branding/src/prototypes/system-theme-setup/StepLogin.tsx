import { useCallback, useState } from 'react'
import { Button, Input } from '@ready/dls/compatibility'
import type { ThemeSetupState } from './SystemThemeSetup'
import LoginPreview from './LoginPreview'
import MessageEditor from './MessageEditor'
import bryteLogo from '../../assets/bryte-logo.svg'
import LoginMessageBrytePanel from './LoginMessageBrytePanel'
import { useAskBrytePage } from '@workspace/setup-shared/ask-bryte'

interface Props {
  data: ThemeSetupState
  onUpdate: (updates: Partial<ThemeSetupState>) => void
  onNext: () => void
  onBack: () => void
  nextLabel?: string
  /** Archived implementation team demos: Next opens Advanced settings instead of saving. */
  advancedNext?: boolean
}

export default function StepLogin({ data, onUpdate, onNext, onBack, nextLabel = 'Save branding', advancedNext = false }: Props) {
  useAskBrytePage('login', {
    advancedNext,
    companyNameEntered: Boolean(data.loginTagline.trim()),
    messageWritten: Boolean(data.employeeLoginMessage.trim()),
    logoShown: data.displayLoginLogo,
  })
  const [bryteOpen, setBryteOpen] = useState(false)
  const closeBryte = useCallback(() => setBryteOpen(false), [])

  return (
    <div className="ts-hero-grid ts-theme-split">
      <div className="ts-hero-left">
      <div className="ts-hero-left-inner">
      <h1 className="text-display ts-h1">
        Login page
      </h1>
      <p className="text-body ts-intro">
        Your login page is the first thing your team sees when they sign in. Your company name appears under the logo, and your message shows beside the sign-in form. Check the preview as you type.
      </p>

      <div className="ts-card">
        <div style={{ marginBottom: 'var(--space-600)' }}>
          <Input
            id="login-tagline"
            label="Company name"
            value={data.loginTagline}
            onChange={v => onUpdate({ loginTagline: v })}
            size="large"
          />
        </div>

        <div style={{ marginBottom: 'var(--space-600)' }}>
          <label className="ts-label" htmlFor="employee-login">
            Employee login message
          </label>
          <MessageEditor
            value={data.employeeLoginMessage}
            onChange={(v) => onUpdate({ employeeLoginMessage: v.slice(0, 5000) })}
          />
          <div className="ts-message-drafting-hint">
            <img src={bryteLogo} width={18} height={18} alt="" />
            <p>Need help drafting another message?{' '}
            <button type="button" className="ts-message-drafting-cta" onClick={() => setBryteOpen(true)} aria-haspopup="dialog" aria-expanded={bryteOpen}>
              <span>Draft with Bryte</span>
            </button>
            </p>
          </div>
        </div>

      </div>
      <div className="ts-actions">
        <Button variant="secondary" size="large" onClick={onBack}>Back</Button>
        <Button variant="primary" size="large" onClick={onNext}>{nextLabel}</Button>
      </div>
      </div>
      </div>
      <aside className="ts-hero-right" aria-label="Login page preview">
        <div className="ts-theme-preview ts-login-preview">
          <p className="ts-preview-title">Preview</p>
          <LoginPreview data={data} />
        </div>
      </aside>
      <LoginMessageBrytePanel open={bryteOpen} onClose={closeBryte} />
    </div>
  )
}
