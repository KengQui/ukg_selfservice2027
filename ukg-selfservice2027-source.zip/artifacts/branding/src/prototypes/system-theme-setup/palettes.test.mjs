import test from 'node:test'
import assert from 'node:assert/strict'
import {
  COLOR_CODE_MESSAGE, PRESET_PALETTES, colorPickerValue, customSnapshot, isValidColorCode,
  manualColorUpdates, offersCustomPalette, paletteChoices, readyMadePalette, selectPalette, startingPalette,
  updateThemeSetup, withStartingPalette,
} from './palettes.ts'
import { logoColorUpdates } from './colorExtraction.ts'
import { restoreThemeSetup } from './savedState.ts'
import { copySources, freshBrandingDraft, prepareReviewedBranding } from './copyBrandingState.ts'
import { persistBrandingDraft, readBrandingStore } from './brandingStorage.ts'

// Mirrors DEFAULT_STATE with an inline sample logo; the real one is an SVG import only Vite can load.
const defaults = {
  logoUrl: 'data:image/svg+xml;charset=utf-8,sample',
  logoFileName: 'default-brand-logo.svg',
  logoSize: 6,
  isDocumentUpload: false,
  primaryColor: '#4A8E82',
  accentColor: '#D85A30',
  selectedPalette: 'Custom',
  customColors: false,
  lightView: false,
  headerClock: true,
  reuseHeaderLogo: true,
  localLoginLogoUrl: null,
  localLoginLogoFileName: null,
  localLoginLogoSize: 0,
  employeeLoginMessage: 'Welcome to [Company Name]',
  loginTagline: '[Company Name]',
  loginClock: true,
  displayLoginLogo: true,
  colorBehindLogo: false,
  logoBackgroundColor: '#ffffff',
  faviconUrl: null,
  faviconFileName: null,
  faviconSize: 0,
  oauthIconUrl: null,
  oauthIconFileName: null,
  oauthIconSize: 0,
}
// The brand step's Skip link applies the placeholder logo next to the ready-made palette.
const placeholderLogo = {
  logoUrl: defaults.logoUrl, logoFileName: defaults.logoFileName, logoSize: defaults.logoSize,
  isDocumentUpload: false, colorsExtractedFromLogo: false, reuseHeaderLogo: true,
  localLoginLogoUrl: null, localLoginLogoFileName: null, localLoginLogoSize: 0, displayLoginLogo: true,
}
const skipBrandStep = state => updateThemeSetup(state, { ...readyMadePalette(state), ...placeholderLogo, presetPalettesOnly: true })
const choose = (state, name) => updateThemeSetup(state, selectPalette(state, name))
const preset = name => PRESET_PALETTES.find(palette => palette.name === name)
function memory(raw = null) {
  return { getItem: () => raw, setItem: (_key, value) => { raw = value } }
}

const paletteNames = state => paletteChoices(state).map(palette => palette.name)
const presetNames = PRESET_PALETTES.map(palette => palette.name)

test('fresh setups skip to Teal with the placeholder logo and no made-up Custom colors', () => {
  const teal = preset('Teal')
  for (const start of [defaults, { ...defaults, selectedPalette: undefined }]) {
    const skipped = skipBrandStep(start)
    assert.equal(skipped.selectedPalette, 'Teal')
    assert.equal(skipped.primaryColor, teal.primaryColor)
    assert.equal(skipped.accentColor, teal.accentColor)
    assert.equal(skipped.presetPalettesOnly, true)
    assert.equal(skipped.lightView, false)
    assert.equal(skipped.contrastSourceColor, null)
    assert.equal(skipped.colorsExtractedFromLogo, false)
    assert.equal(skipped.logoUrl, defaults.logoUrl)
    // The built-in starting colors are never offered as the company's Custom palette.
    assert.equal(offersCustomPalette(skipped), false)
    assert.deepEqual(paletteNames(skipped), presetNames)
    // Picking other ready-made palettes never brings them back.
    assert.deepEqual(paletteNames(choose(choose(skipped, 'Navy'), 'Teal')), presetNames)
  }
})

test('custom colors restored from an older save stay available after Skip', () => {
  const start = restoreThemeSetup(JSON.stringify({ primaryColor: '#123456' }), defaults)
  assert.equal(start.customColors, true)
  const skipped = skipBrandStep(start)
  assert.equal(skipped.selectedPalette, 'Teal')
  assert.deepEqual(skipped.customPalette, customSnapshot(start))
  assert.deepEqual(paletteChoices(skipped)[0], { name: 'Custom', primaryColor: '#123456', accentColor: defaults.accentColor })
})

test('continuing with uploads but no extracted colors opens on a ready-made palette', () => {
  // The brand step clears an earlier detection the same way when the new uploads have no usable colors.
  const uploaded = updateThemeSetup(defaults, logoColorUpdates(defaults, null))
  const continued = updateThemeSetup(uploaded, { ...startingPalette(uploaded), presetPalettesOnly: false })
  assert.equal(continued.selectedPalette, 'Teal')
  assert.equal(continued.primaryColor, preset('Teal').primaryColor)
  assert.deepEqual(paletteNames(continued), presetNames)
  // A preset already chosen, or the company's own Custom colors, are kept as they are.
  const navy = choose(defaults, 'Navy')
  assert.deepEqual(startingPalette(navy), {})
  const extracted = updateThemeSetup(defaults, logoColorUpdates(defaults, { primary: '#345678', accent: '#ABCDEF' }))
  assert.deepEqual(startingPalette(extracted), {})
  assert.equal(updateThemeSetup(extracted, { ...startingPalette(extracted), presetPalettesOnly: false }).primaryColor, '#345678')
})

test('unsaved setups hydrate on a ready-made palette; company colors and presets hydrate unchanged', () => {
  const fresh = withStartingPalette(freshBrandingDraft(defaults, 'Acme Services, LLC'))
  assert.equal(fresh.selectedPalette, 'Teal')
  assert.equal(fresh.loginTagline, 'Acme Services, LLC')
  assert.deepEqual(paletteNames(fresh), presetNames)
  // A fresh draft stored before Skip resumes the same way.
  const storedFresh = restoreThemeSetup(JSON.stringify(freshBrandingDraft(defaults, 'Acme Services, LLC')), defaults)
  assert.equal(withStartingPalette(storedFresh).selectedPalette, 'Teal')
  const edited = updateThemeSetup(fresh, manualColorUpdates('primaryColor', '#123456'))
  assert.equal(withStartingPalette(edited), edited)
  const navy = choose(fresh, 'Navy')
  assert.equal(withStartingPalette(navy), navy)
})

test('a manual edit adds Custom with the edited colors, and it stays available after other palettes', () => {
  const skipped = skipBrandStep(defaults)
  for (const [field, value] of [['primaryColor', '#123456'], ['accentColor', '#ABCDEF']]) {
    const edited = updateThemeSetup(skipped, manualColorUpdates(field, value))
    assert.equal(edited.selectedPalette, 'Custom')
    assert.equal(edited.customColors, true)
    assert.equal(paletteChoices(edited)[0].name, 'Custom')
    assert.equal(paletteChoices(edited)[0][field], value)
    const named = choose(edited, 'Purple')
    assert.equal(paletteChoices(named)[0][field], value)
    assert.equal(choose(named, 'Custom')[field], value)
    // A reload keeps it available too.
    assert.equal(paletteChoices(restoreThemeSetup(JSON.stringify(named), defaults))[0][field], value)
  }
  // A contrast adjustment on a ready-made palette is the company's own choice as well.
  const adjusted = updateThemeSetup(skipped, { primaryColor: '#012020', contrastSourceColor: preset('Teal').primaryColor, selectedPalette: 'Custom' })
  assert.equal(adjusted.customColors, true)
  assert.equal(paletteChoices(choose(adjusted, 'Gray'))[0].primaryColor, '#012020')
})

test('logo colors show as Custom and stay available after picking a ready-made palette', () => {
  const extracted = updateThemeSetup(defaults, logoColorUpdates(defaults, { primary: '#345678', accent: '#ABCDEF' }))
  assert.equal(extracted.selectedPalette, 'Custom')
  assert.equal(extracted.customColors, true)
  const named = choose(extracted, 'Sky Blue')
  assert.deepEqual(paletteChoices(named)[0], { name: 'Custom', primaryColor: '#345678', accentColor: '#ABCDEF' })
  assert.equal(choose(named, 'Custom').colorsExtractedFromLogo, true)
  // A later logo without usable colors keeps them as the company's.
  const unusable = updateThemeSetup(named, logoColorUpdates(named, null))
  assert.equal(paletteChoices(unusable)[0].primaryColor, '#345678')
})

test('older saves keep real Custom colors and drop only the stored starting colors', () => {
  const tealWith = customPalette => JSON.stringify({
    ...defaults, customColors: undefined, selectedPalette: 'Teal',
    primaryColor: preset('Teal').primaryColor, accentColor: preset('Teal').accentColor, customPalette,
  })
  // An older Skip stored the starting colors as the Custom comparison.
  const oldSkip = restoreThemeSetup(tealWith(customSnapshot(defaults)), defaults)
  assert.equal(oldSkip.customColors, false)
  assert.deepEqual(paletteNames(oldSkip), presetNames)
  assert.equal(restoreThemeSetup(tealWith(undefined), defaults).customColors, false)
  // Edited or logo colors behind a ready-made palette are kept.
  const oldEdit = restoreThemeSetup(tealWith({ ...customSnapshot(defaults), primaryColor: '#123456' }), defaults)
  assert.equal(paletteChoices(oldEdit)[0].primaryColor, '#123456')
  const oldLogo = restoreThemeSetup(tealWith({ ...customSnapshot(defaults), colorsExtractedFromLogo: true }), defaults)
  assert.equal(paletteChoices(oldLogo)[0].name, 'Custom')
  // Live Custom colors in an older save are never discarded.
  const oldCustom = restoreThemeSetup(JSON.stringify({ ...defaults, customColors: undefined, primaryColor: '#123456' }), defaults)
  assert.equal(oldCustom.selectedPalette, 'Custom')
  assert.equal(oldCustom.customColors, true)
  // Newer saves keep their own answer, and a preset whose colors were edited counts as company colors.
  assert.equal(restoreThemeSetup(JSON.stringify(skipBrandStep(defaults)), defaults).customColors, false)
  const editedPreset = { ...skipBrandStep(defaults), primaryColor: '#123456' }
  assert.equal(restoreThemeSetup(JSON.stringify(editedPreset), defaults).customColors, true)
})

test('older saved colors keep Custom in the copy review, which reads saved branding without restoring it', () => {
  // Saved branding from before Custom tracked its source, read straight from the store as Copy branding does.
  const legacyCustom = { ...defaults, customColors: undefined, primaryColor: '#123456', accentColor: '#ABCDEF' }
  const legacyNamed = {
    ...defaults, customColors: undefined, selectedPalette: 'Teal', primaryColor: preset('Teal').primaryColor,
    accentColor: preset('Teal').accentColor, customPalette: { ...customSnapshot(defaults), primaryColor: '#345678' },
  }
  const legacySkip = { ...legacyNamed, customPalette: customSnapshot(defaults) }
  const store = readBrandingStore(JSON.stringify({
    version: 2, themes: { one: legacyCustom, two: legacyNamed, three: legacySkip },
    savedIds: ['one', 'two', 'three'], drafts: {}, completions: {},
  }))
  const companies = [{ id: 'one', name: 'One', ein: '1' }, { id: 'two', name: 'Two', ein: '2' }, { id: 'three', name: 'Three', ein: '3' }]
  const [one, two, three] = copySources(store.themes, companies)
    .map(source => prepareReviewedBranding(source.theme, source.company.name, 'Four'))
  // Live Custom colors: Custom → a named palette → Custom keeps them.
  assert.equal(paletteChoices(one)[0].name, 'Custom')
  const navy = choose(one, 'Navy')
  assert.equal(navy.customColors, true)
  assert.deepEqual(paletteChoices(navy)[0], { name: 'Custom', primaryColor: '#123456', accentColor: '#ABCDEF' })
  assert.equal(choose(navy, 'Custom').primaryColor, '#123456')
  // A named palette with real Custom colors behind it starts with Custom available.
  assert.equal(paletteChoices(two)[0].primaryColor, '#345678')
  assert.equal(paletteChoices(choose(two, 'Gray'))[0].primaryColor, '#345678')
  // An older Skip that stored only the starting colors still shows no Custom.
  assert.deepEqual(paletteNames(three), presetNames)
  assert.deepEqual(paletteNames(choose(three, 'Gray')), presetNames)
  // Copy keeps the saved branding as it was; nothing is rewritten on read.
  assert.equal(Object.hasOwn(store.themes.one, 'customColors') && store.themes.one.customColors !== undefined, false)
})

test('built-in palettes match Ready without changing the other colors', () => {
  assert.deepEqual(PRESET_PALETTES, [
    { name: 'Teal', primaryColor: '#015151', accentColor: '#2AD6C4' },
    { name: 'Gray', primaryColor: '#3D475C', accentColor: '#C2C9D6' },
    { name: 'Navy', primaryColor: '#1F3D7A', accentColor: '#ADC2EB' },
    { name: 'Neutral', primaryColor: '#3576B0', accentColor: '#C2DEF0' },
    { name: 'Purple', primaryColor: '#1F257A', accentColor: '#C1C4F0' },
    { name: 'Sky Blue', primaryColor: '#1F657A', accentColor: '#ADDCEB' },
  ])
})

test('all code fields share the exact message and accept only three or six hexadecimal digits', () => {
  assert.equal(COLOR_CODE_MESSAGE, 'Use # followed by 3 or 6 digits or letters A–F, like #1D6E56.')
  for (const value of ['#fff', '#AbC', '#123', '#1D6E56', '#abcdef', '#000000']) {
    assert.equal(isValidColorCode(value), true, value)
    assert.match(colorPickerValue(value), /^#[0-9a-f]{6}$/i)
  }
  assert.equal(colorPickerValue('#AbC'), '#AAbbCC')
  for (const value of ['', '#', 'fff', '#1234', '#12345', '#1234567', '#GGG', '#f f', ' #fff', '#fff ']) {
    assert.equal(isValidColorCode(value), false, value)
    assert.equal(colorPickerValue(value), '#000000')
    assert.deepEqual(manualColorUpdates('primaryColor', value), {})
    assert.deepEqual(manualColorUpdates('accentColor', value), {})
  }
})

test('manual codes after Skip switch to Custom while preserving built-in palettes and the edited snapshot', () => {
  const skipped = skipBrandStep(defaults)
  const originalPreset = { ...preset('Teal') }
  const edited = updateThemeSetup(skipped, manualColorUpdates('primaryColor', '#abc'))
  assert.equal(edited.selectedPalette, 'Custom')
  assert.equal(edited.primaryColor, '#abc')
  assert.equal(edited.accentColor, skipped.accentColor)
  assert.equal(edited.colorsExtractedFromLogo, false)
  const adjusted = updateThemeSetup(edited, { primaryColor: '#345678', contrastSourceColor: '#abc', lightView: true })
  const named = choose(adjusted, 'Purple')
  assert.equal(paletteChoices(named)[0].name, 'Custom')
  assert.deepEqual(customSnapshot(choose(named, 'Custom')), customSnapshot(adjusted))
  const restored = restoreThemeSetup(JSON.stringify(named), defaults)
  assert.deepEqual(customSnapshot(choose(restored, 'Custom')), customSnapshot(adjusted))
  assert.deepEqual(preset('Teal'), originalPreset)
})

test('manual accent codes on a named palette use visible colors and clear extracted-color provenance', () => {
  const named = choose({ ...defaults, colorsExtractedFromLogo: true }, 'Navy')
  const edited = updateThemeSetup(named, manualColorUpdates('accentColor', '#def'))
  assert.equal(edited.selectedPalette, 'Custom')
  assert.equal(edited.primaryColor, preset('Navy').primaryColor)
  assert.equal(edited.accentColor, '#def')
  assert.equal(edited.colorsExtractedFromLogo, false)
  assert.equal(edited.customPalette.colorsExtractedFromLogo, false)
  assert.equal(choose(choose(edited, 'Neutral'), 'Custom').accentColor, '#def')
})

test('skip contributes no palette changes while a preset is selected', () => {
  for (const { name, primaryColor, accentColor } of PRESET_PALETTES) {
    const chosen = updateThemeSetup(choose(defaults, name), { lightView: true })
    assert.deepEqual(readyMadePalette(chosen), {})
    const skipped = skipBrandStep(chosen)
    assert.equal(skipped.selectedPalette, name)
    assert.equal(skipped.primaryColor, primaryColor)
    assert.equal(skipped.accentColor, accentColor)
    assert.equal(skipped.lightView, true)
    assert.equal(skipped.presetPalettesOnly, true)
    assert.deepEqual(skipped.customPalette, chosen.customPalette)
  }
})

test('resume, Back, and Skip keep the palette of an in-process draft', () => {
  // The returning-multi fixture: Acme Services chose Navy and stopped before saving.
  const servicesDraft = freshBrandingDraft(defaults, 'Acme Services, LLC')
  const inProcess = choose(servicesDraft, 'Navy')
  const storage = memory()
  persistBrandingDraft(storage, 'acme-services', inProcess)

  // Resuming restores the stored draft into the wizard; Back then reopens the brand step with that state.
  const resumed = restoreThemeSetup(JSON.stringify(readBrandingStore(storage.getItem()).drafts['acme-services']), defaults)
  assert.equal(resumed.selectedPalette, 'Navy')
  const skipped = skipBrandStep(resumed)
  assert.equal(skipped.selectedPalette, 'Navy')
  assert.equal(skipped.primaryColor, preset('Navy').primaryColor)
  assert.equal(skipped.accentColor, preset('Navy').accentColor)
  assert.equal(skipped.presetPalettesOnly, true)
  assert.equal(skipped.loginTagline, 'Acme Services, LLC')
  assert.deepEqual(skipped.customPalette, resumed.customPalette)

  // The draft written after Skip still records Navy, so a later resume shows the same palette.
  const store = persistBrandingDraft(storage, 'acme-services', skipped)
  assert.equal(store.drafts['acme-services'].selectedPalette, 'Navy')
  assert.equal(restoreThemeSetup(JSON.stringify(store.drafts['acme-services']), defaults).selectedPalette, 'Navy')
})

test('custom colors from a logo or manual edits still fall back to Teal on Skip', () => {
  const extracted = updateThemeSetup(choose(defaults, 'Navy'), {
    selectedPalette: 'Custom', primaryColor: '#345678', accentColor: '#ABCDEF',
    contrastSourceColor: null, colorsExtractedFromLogo: true,
  })
  const edited = updateThemeSetup(choose(defaults, 'Navy'), { primaryColor: '#123456', contrastSourceColor: null })
  assert.equal(edited.selectedPalette, 'Custom')
  for (const [state, primaryColor] of [[extracted, '#345678'], [edited, '#123456']]) {
    const skipped = skipBrandStep(state)
    assert.equal(skipped.selectedPalette, 'Teal')
    assert.equal(skipped.primaryColor, preset('Teal').primaryColor)
    assert.equal(skipped.colorsExtractedFromLogo, false)
    assert.equal(skipped.presetPalettesOnly, true)
    // The company's Custom colors are still listed and retained for comparison.
    assert.equal(paletteChoices(skipped)[0].primaryColor, primaryColor)
    assert.equal(choose(skipped, 'Custom').primaryColor, primaryColor)
  }
  // Unknown palette names are never trusted as presets.
  assert.equal(skipBrandStep({ ...defaults, selectedPalette: 'Rainbow' }).selectedPalette, 'Teal')
})
