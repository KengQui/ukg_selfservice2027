import { useEffect, useRef, useState } from 'react'
import BrytePanel from '@ready/dls/ai/components/BrytePanel/BrytePanel'
import BryteAIMessage from '@ready/dls/ai/components/BryteAIMessage/BryteAIMessage'
import BryteUserMessage from '@ready/dls/ai/components/BryteUserMessage/BryteUserMessage'
import AIFooter from '@ready/dls/ai/components/AIFooter/AIFooter'
import { useBrytePanelPresence } from '@workspace/setup-shared/ask-bryte'
import './loginMessageBrytePanel.css'

export default function LoginMessageBrytePanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  useBrytePanelPresence(open, onClose)
  const [input, setInput] = useState('')
  const [expanded, setExpanded] = useState(false)
  const [messages, setMessages] = useState<string[]>([])
  const endRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (open) endRef.current?.scrollIntoView({ block: 'nearest' })
  }, [messages, open])

  useEffect(() => {
    if (!open) return
    const previous = document.activeElement as HTMLElement | null
    const panel = document.querySelector<HTMLElement>('.ts-login-bryte')
    panel?.querySelector<HTMLInputElement>('input, textarea')?.focus()
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose()
      if (event.key !== 'Tab' || !panel) return
      const controls = [...panel.querySelectorAll<HTMLElement>('button:not([disabled]), input:not([disabled]), textarea:not([disabled]), a[href]')]
      const first = controls[0]
      const last = controls.at(-1)
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus() }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus() }
    }
    document.addEventListener('keydown', handleKey)
    return () => { document.removeEventListener('keydown', handleKey); previous?.focus() }
  }, [open, onClose])

  return (
    <BrytePanel
      className="ts-login-bryte"
      open={open}
      title="Bryte AI"
      mode={expanded ? 'fullscreen' : 'split'}
      onModeToggle={() => setExpanded(value => !value)}
      onClose={onClose}
      onDelete={() => { setMessages([]); setInput('') }}
      footer={<AIFooter value={input} onChange={setInput} placeholder="Search or ask Bryte"
        onSubmit={text => {
          if (!text.trim()) return
          setMessages(previous => [...previous, text.trim()])
          setInput('')
        }} />}
    >
      <BryteAIMessage type="welcome" heading="Welcome">
        <p>I can help you shape a clear, friendly employee login message.</p>
        <p><strong>What would you like your message to say?</strong></p>
      </BryteAIMessage>
      {messages.map((query, index) => (
        <div className="ts-login-bryte__exchange" key={index}>
          <BryteUserMessage>{query}</BryteUserMessage>
          <BryteAIMessage heading="Example message">
            <p>Welcome to ACME</p>
            <p>Sign in to access your employee account. If you need help, contact support@acme.com or (555) 555-5555.</p>
            <p className="ts-login-bryte__notice">I haven’t changed your login message. If you like this example, copy it into the message box.</p>
          </BryteAIMessage>
        </div>
      ))}
      <div ref={endRef} />
    </BrytePanel>
  )
}
