import { useCallback, useEffect, useState, type ReactNode } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Button, Dialog, InlineMessage } from '@ready/dls/compatibility'
import SystemThemeSetup, { DEFAULT_STATE } from './SystemThemeSetup'
import { brandingDemoLabel, brandingDemoScenario, brandingStorageKeys, demoStartParams, isMultiEinScenario, preparedBranding } from '@workspace/setup-shared/prototypes/branding-demo/demoScenarios'
import { singleStepShownKey } from '@workspace/setup-shared/prototypes/branding-demo/brandingProgress'
import type { BrandingDemoScenario } from '@workspace/setup-shared/prototypes/branding-demo/demoScenarios'
import { demoEntryParams, forgetDemo } from '@workspace/setup-shared/prototypes/branding-demo/demoNavigation'
import { clearPendingCopyEdit, copyEditSessionKey } from './copyEditSession'
import { freshBrandingDraft } from './copyBrandingState'
import { selectPalette, updateThemeSetup } from './palettes'
import { DEMO_REVISION_ACTOR, readBrandingStore } from './brandingStorage'
import { SAMPLE_COMPANIES } from './companies'

const fixtureCompletion = { actor: DEMO_REVISION_ACTOR, savedAt: '2026-09-14T13:30:00.000Z' }

/** One fixture value per company, for the companies a scenario's prepared branding names. */
function perCompany<T>(ids: readonly string[], value: (id: string) => T): Record<string, T> {
  return Object.fromEntries(ids.map(id => [id, value(id)]))
}

function initializeDemo(scenario: BrandingDemoScenario, reset = false) {
  const keys = brandingStorageKeys(scenario)
  // Only the returning scenarios start with prior work; new-setup scenarios start empty.
  // The Company Setup hub counts this same prepared work before Branding has opened in the scenario.
  const prepared = preparedBranding(scenario)
  const completed = {
    ...DEFAULT_STATE,
    logoUrl: null, logoFileName: null, logoSize: 0,
    loginTagline: 'Acme Holdings, Inc.',
    employeeLoginMessage: DEFAULT_STATE.employeeLoginMessage.replaceAll('[Company Name]', 'Acme Holdings, Inc.'),
    colorBehindLogo: false, logoBackgroundColor: '#ffffff',
    // The returning customer saved these colors as their own, so Custom stays available when they edit.
    customColors: true,
  }
  // A setup left mid-way: a preset palette is chosen while the login text is still the suggested default.
  const inProcess = (id: string) => {
    const draft = freshBrandingDraft(DEFAULT_STATE, SAMPLE_COMPANIES.find(company => company.id === id)?.name ?? '')
    return updateThemeSetup(draft, selectPalette(draft, 'Navy'))
  }
  if (reset) {
    localStorage.removeItem(keys.singleConfirmed)
    localStorage.removeItem(singleStepShownKey(scenario))
  }
  if (reset || localStorage.getItem(keys.single) === null) {
    localStorage.setItem(keys.single, JSON.stringify(prepared.singleSaved ? completed : DEFAULT_STATE))
  }
  if (reset || localStorage.getItem(keys.companies) === null) {
    // This isolated returning scenario explicitly models one prior successful save and one unsaved draft.
    // Never promote arbitrary legacy records or the standalone preview this way.
    localStorage.setItem(keys.companies, JSON.stringify({
      version: 2,
      themes: perCompany(prepared.saved, () => completed),
      savedIds: [...prepared.saved],
      drafts: perCompany(prepared.inProcess, inProcess),
      completions: perCompany(prepared.saved, () => fixtureCompletion),
    }))
  }
  // This isolated fixture explicitly models a prior successful save; ordinary legacy records do not.
  if (prepared.singleSaved && localStorage.getItem(keys.singleConfirmed) !== '1') {
    localStorage.setItem(keys.singleConfirmed, '1')
  }
  if (prepared.singleSaved && localStorage.getItem(keys.singleConfirmed) === '1'
    && localStorage.getItem(`${keys.single}:completion`) === null) {
    localStorage.setItem(`${keys.single}:completion`, JSON.stringify(fixtureCompletion))
  }
  if (prepared.saved.length > 0) {
    const store = readBrandingStore(localStorage.getItem(keys.companies))
    const missing = prepared.saved.filter(id => store.savedIds.includes(id) && !store.completions[id])
    if (missing.length > 0) {
      localStorage.setItem(keys.companies, JSON.stringify({
        ...store, completions: { ...store.completions, ...perCompany(missing, () => fixtureCompletion) },
      }))
    }
  }
  if (reset) forgetDemo(localStorage, scenario)
}

export default function BrandingDemo({ renderPage }: {
  renderPage: (content: ReactNode, actions?: ReactNode, scenarioLabel?: string) => ReactNode
}) {
  const [params, setParams] = useSearchParams()
  const scenario = brandingDemoScenario(params.get('demo'))
  const [ready, setReady] = useState<BrandingDemoScenario | null>(null)
  const [opening, setOpening] = useState<{ scenario: BrandingDemoScenario, target: string } | null>(null)
  // A restart keeps the wizard unmounted until the scenario's start URL is in place. The router applies that
  // URL after the click, so remounting right away would reopen the company still named in the old URL and
  // record a draft for it in the freshly reset store.
  const [restarting, setRestarting] = useState(false)
  const [confirmReset, setConfirmReset] = useState(false)
  const [error, setError] = useState('')
  // The wizard reports its save-and-leave action while one of its steps is showing (null elsewhere and once it
  // unmounts); the header offers it as a secondary Save and finish later action beside Restart demo.
  const [saveLater, setSaveLater] = useState<(() => void) | null>(null)
  const handleSaveLaterChange = useCallback((action: (() => void) | null) => setSaveLater(() => action), [])
  const atStart = scenario !== null && params.toString() === demoStartParams(scenario).toString()
  const waitingForEntry = opening?.scenario === scenario && params.toString() !== opening.target
  useEffect(() => {
    if (!scenario) { setReady(null); return }
    try {
      initializeDemo(scenario)
      // Normalize arrival only, not editing steps in the same scenario.
      const isLaunch = !['page', 'companies', 'fresh', 'contrastExample', 'catalog'].some(key => params.has(key))
      const entry = isLaunch ? demoEntryParams(scenario, localStorage) : null
      if (entry && params.get('returning') === '1' && !entry.has('returning')) {
        entry.set('returning', '1')
        if (isMultiEinScenario(scenario)) entry.set('page', 'multi-ein')
      }
      if (entry && (entry.has('page') || (params.has('returning') && !entry.has('returning')))
        && entry.toString() !== params.toString()) {
        setOpening({ scenario, target: entry.toString() })
        setParams(entry, { replace: true })
      }
      setReady(scenario)
      setError('')
    }
    catch { setError('We couldn’t set up this demo. Your browser may be blocking this site from saving data. Allow it, then reload the page.') }
  }, [scenario])
  useEffect(() => {
    if (opening?.scenario === scenario && params.toString() === opening.target) setOpening(null)
  }, [opening, scenario, params])
  useEffect(() => {
    if (restarting && atStart) setRestarting(false)
  }, [restarting, atStart])
   const saveLaterButton = saveLater && <Button variant="secondary" size="small" onClick={() => saveLater()}>Save and finish later</Button>
  if (!scenario) return renderPage(
    <SystemThemeSetup onSaveLaterChange={handleSaveLaterChange} />,
    saveLaterButton && <div className="branding-demo-actions">{saveLaterButton}</div>,
  )
  const restart = () => {
    try {
      if (!clearPendingCopyEdit(copyEditSessionKey(brandingStorageKeys(scenario).companies))) {
        throw new Error('Copy recovery could not be cleared.')
      }
      localStorage.removeItem(`${brandingStorageKeys(scenario).single}:revision`)
      localStorage.removeItem(`${brandingStorageKeys(scenario).single}:completion`)
      localStorage.removeItem(`${brandingStorageKeys(scenario).single}:edit`)
      initializeDemo(scenario, true)
      setRestarting(true)
      setOpening(null)
      setParams(demoStartParams(scenario), { replace: true })
      setReady(scenario)
      setConfirmReset(false)
      setError('')
    } catch { setError('We couldn’t restart this demo. Your browser may be blocking this site from saving data. Allow it, then select Restart demo again.') }
  }
  return renderPage(<>
    {error && <InlineMessage theme="error">{error}</InlineMessage>}
    {ready === scenario && !restarting && !waitingForEntry && <SystemThemeSetup key={scenario} onSaveLaterChange={handleSaveLaterChange} />}
    <Dialog open={confirmReset} onClose={() => setConfirmReset(false)} title="Restart this demo?"
      secondaryAction={{ label: 'Cancel', onClick: () => setConfirmReset(false) }} /* copy-exception(review/cancel): Restart demo confirmation wording approved by the user (guide A.7) */
      primaryAction={{ label: 'Restart demo', onClick: restart }}>
      Changes made in this demo scenario will be cleared. Other scenarios and saved setups will not change.
    </Dialog>
  </>,
    <div className="branding-demo-actions">
      {saveLaterButton}
      <Button variant="secondary" size="small" onClick={() => setConfirmReset(true)}>Restart demo</Button>
    </div>,
    brandingDemoLabel(scenario),
  )
}
