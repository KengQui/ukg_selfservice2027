import type { ThemeMap } from './copyBrandingState'
import type { ThemeSetupState } from './SystemThemeSetup'
import type { StoredBrandUploads } from './brandUploads'

// The company status rule lives in the shared setup library so the Company Setup hub counts companies the same way.
export { companySetupStatus, type CompanySetupStatus } from '@workspace/setup-shared/prototypes/branding-demo/brandingProgress'

export const BRANDING_KEY = 'ready-dls-ein-themes'
/**
 * themes: every branding record, saved or unconfirmed. savedIds: companies with a confirmed save.
 * drafts: unsaved setups still in process. Drafts never enter themes or savedIds, so they cannot read as saved.
 * brandUploads: the brand step's uploads and analysis outcome for a draft, kept so resuming does not repeat the uploads.
 */
export type BrandingStore = {
  version: 2
  themes: ThemeMap
  savedIds: string[]
  drafts: ThemeMap
  editDrafts: ThemeMap
  brandUploads: Record<string, StoredBrandUploads>
  revisions: Record<string, BrandingRevision>
  completions: Record<string, BrandingCompletion>
}

/** The prototype's displayed persona, not an authenticated audit identity. */
export const DEMO_REVISION_ACTOR = 'System Administrator'
export type BrandingRevision = { actor: string | null; savedAt: string }
/** Provenance of a confirmed first save, never inferred from a saved theme or draft. */
export type BrandingCompletion = { actor: string | null; savedAt: string }

function validAttribution(value: unknown): value is BrandingCompletion {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false
  const entry = value as Partial<BrandingCompletion>
  return typeof entry.savedAt === 'string' && Number.isFinite(Date.parse(entry.savedAt))
    && (entry.actor === null || typeof entry.actor === 'string')
}

function attributionLabel(prefix: 'Completed' | 'Revised', value: BrandingCompletion | undefined): string | undefined {
  if (!validAttribution(value)) return undefined
  const date = new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value.savedAt))
  return `${prefix}: ${value.actor?.trim() || 'Name unavailable'} ${date}`
}

export function revisionLabel(revision: BrandingRevision | undefined): string | undefined {
  return attributionLabel('Revised', revision)
}

export function companyAttributionLabel(completion?: BrandingCompletion, revision?: BrandingRevision): string | undefined {
  return revisionLabel(revision) ?? attributionLabel('Completed', completion)
}

/** Only the in-memory outcome of a confirmed edit of this exact saved snapshot may show Updated. */
export function updatedCompletionCompany(
  outcome: { id: string; snapshot: string } | null,
  savedThemes: ThemeMap,
): string | undefined {
  if (!outcome || !Object.prototype.hasOwnProperty.call(savedThemes, outcome.id)) return undefined
  return JSON.stringify(savedThemes[outcome.id]) === outcome.snapshot ? outcome.id : undefined
}

function recordMap<T extends object>(value: unknown, mapError: string, entryError: string): Record<string, T> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error(mapError)
  if (Object.values(value).some(entry => !entry || typeof entry !== 'object' || Array.isArray(entry))) {
    throw new Error(entryError)
  }
  return value as Record<string, T>
}

function withoutSaved<T>(entries: Record<string, T>, savedIds: string[]): Record<string, T> {
  return Object.fromEntries(Object.entries(entries).filter(([id]) => !savedIds.includes(id)))
}

/**
 * Old records have no provenance. Retain their content, without inventing save history. The Company Setup hub's
 * branding progress mirrors what this accepts (shared brandingProgress.ts); brandingProgress.test.mjs keeps them together.
 */
export function readBrandingStore(raw: string | null): BrandingStore {
  const value = JSON.parse(raw || '{}')
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('Invalid branding storage')
  const versioned = value.version === 2
  const themes = recordMap<ThemeSetupState>(versioned ? value.themes : value, 'Invalid branding themes', 'Invalid company branding')
  if (versioned && !Array.isArray(value.savedIds)) throw new Error('Invalid branding save history')
  const savedIds: string[] = versioned
    ? value.savedIds.filter((id: unknown) => typeof id === 'string' && themes[id])
    : []
  // Drafts and brand uploads arrived after the first version-2 stores; earlier records simply have none.
  const drafts = versioned && value.drafts !== undefined
    ? recordMap<ThemeSetupState>(value.drafts, 'Invalid branding drafts', 'Invalid company draft')
    : {}
  const rawEditDrafts = versioned && value.editDrafts !== undefined
    ? recordMap<ThemeSetupState>(value.editDrafts, 'Invalid branding edit drafts', 'Invalid company edit draft')
    : {}
  const brandUploads = versioned && value.brandUploads !== undefined
    ? recordMap<StoredBrandUploads>(value.brandUploads, 'Invalid brand uploads', 'Invalid company brand uploads')
    : {}
  const rawRevisions = versioned && value.revisions !== undefined
    ? recordMap<BrandingRevision>(value.revisions, 'Invalid branding revisions', 'Invalid company revision')
    : {}
  const revisions = Object.fromEntries(Object.entries(rawRevisions).filter(([id, revision]) =>
    savedIds.includes(id) && validAttribution(revision)))
  const rawCompletions = versioned && value.completions !== undefined
    ? recordMap<BrandingCompletion>(value.completions, 'Invalid branding completions', 'Invalid company completion')
    : {}
  const completions = Object.fromEntries(Object.entries(rawCompletions).filter(([id, completion]) =>
    savedIds.includes(id) && validAttribution(completion)))
  return {
    version: 2, themes, savedIds,
    drafts: withoutSaved(drafts, savedIds),
    editDrafts: Object.fromEntries(Object.entries(rawEditDrafts).filter(([id]) => savedIds.includes(id))),
    brandUploads: withoutSaved(brandUploads, savedIds),
    revisions,
    completions,
  }
}

export function savedBranding(store: BrandingStore): ThemeMap {
  return Object.fromEntries(store.savedIds.map(id => [id, store.themes[id]]))
}

/** One atomic write: failed storage writes never publish successful completion. */
export function persistBranding(
  storage: Pick<Storage, 'getItem' | 'setItem'>,
  updates: ThemeMap,
  key = BRANDING_KEY,
  revision?: BrandingRevision,
): BrandingStore {
  const previous = readBrandingStore(storage.getItem(key))
  const savedIds = Object.keys(updates)
  const revisions = { ...previous.revisions }
  const completions = { ...previous.completions }
  if (revision) {
    if (!validAttribution(revision)) throw new Error('Invalid branding attribution')
    for (const id of savedIds) {
      if (previous.savedIds.includes(id)) revisions[id] = revision
      else completions[id] = revision
    }
  }
  const next: BrandingStore = {
    version: 2,
    themes: { ...previous.themes, ...updates },
    savedIds: [...new Set([...previous.savedIds, ...savedIds])],
    // A successful save ends that company's in-process work, uploads included.
    drafts: withoutSaved(previous.drafts, savedIds),
    editDrafts: withoutSaved(previous.editDrafts, savedIds),
    brandUploads: withoutSaved(previous.brandUploads, savedIds),
    revisions,
    completions,
  }
  storage.setItem(key, JSON.stringify(next))
  return next
}

/** Single-EIN branding lives in its original exact theme snapshot; revision metadata has its own key. */
export function readSingleRevision(raw: string | null): BrandingRevision | undefined {
  if (!raw) return undefined
  try {
    const revision = JSON.parse(raw)
    return validAttribution(revision) ? revision : undefined
  } catch { return undefined }
}

/** A separate provenance key keeps the single theme's exact snapshot format unchanged. */
export const readSingleCompletion = readSingleRevision

export function persistSingleBranding(
  storage: Pick<Storage, 'getItem' | 'setItem' | 'removeItem'>,
  theme: ThemeSetupState,
  key: string,
  confirmedKey: string,
  attribution: BrandingCompletion,
): { completion?: BrandingCompletion; revision?: BrandingRevision; wasSaved: boolean } {
  if (!validAttribution(attribution)) throw new Error('Invalid branding attribution')
  const wasSaved = storage.getItem(confirmedKey) === '1'
  const metadataKey = `${key}:${wasSaved ? 'revision' : 'completion'}`
  const oldTheme = storage.getItem(key)
  const oldMetadata = storage.getItem(metadataKey)
  const oldConfirmed = storage.getItem(confirmedKey)
  const editKey = `${key}:edit`
  const oldEdit = storage.getItem(editKey)
  try {
    storage.setItem(key, JSON.stringify(theme))
    storage.setItem(metadataKey, JSON.stringify(attribution))
    if (!wasSaved) {
      // Confirmation comes last: neither a draft nor a failed first save counts as completed.
      storage.setItem(confirmedKey, '1')
    }
    storage.removeItem(editKey)
  } catch (error) {
    // Restore the snapshot and attribution if any part of the explicit save was rejected.
    try {
      if (oldTheme === null) storage.removeItem(key)
      else storage.setItem(key, oldTheme)
      if (oldMetadata === null) storage.removeItem(metadataKey)
      else storage.setItem(metadataKey, oldMetadata)
      if (oldEdit === null) storage.removeItem(editKey)
      else storage.setItem(editKey, oldEdit)
      if (oldConfirmed === null) storage.removeItem(confirmedKey)
      else storage.setItem(confirmedKey, oldConfirmed)
    } catch { /* The original storage error remains the actionable failure. */ }
    throw error
  }
  return wasSaved ? { revision: attribution, wasSaved } : { completion: attribution, wasSaved }
}

/** Unfinished edits never replace the live branding or its attribution. */
export function persistBrandingEditDraft(
  storage: Pick<Storage, 'getItem' | 'setItem'>,
  id: string,
  draft: ThemeSetupState | null,
  key = BRANDING_KEY,
): BrandingStore {
  const previous = readBrandingStore(storage.getItem(key))
  if (!previous.savedIds.includes(id)) return previous
  const editDrafts = { ...previous.editDrafts }
  if (draft) editDrafts[id] = draft
  else delete editDrafts[id]
  const next = { ...previous, editDrafts }
  storage.setItem(key, JSON.stringify(next))
  return next
}

export function persistSingleEditDraft(
  storage: Pick<Storage, 'getItem' | 'setItem' | 'removeItem'>,
  key: string,
  draft: ThemeSetupState | null,
): void {
  if (draft) storage.setItem(`${key}:edit`, JSON.stringify(draft))
  else storage.removeItem(`${key}:edit`)
}

/** Records one company's unsaved setup. Companies with a confirmed save keep no draft. */
export function persistBrandingDraft(
  storage: Pick<Storage, 'getItem' | 'setItem'>,
  id: string,
  draft: ThemeSetupState,
  key = BRANDING_KEY,
): BrandingStore {
  const previous = readBrandingStore(storage.getItem(key))
  if (previous.savedIds.includes(id)) return previous
  const next: BrandingStore = { ...previous, drafts: { ...previous.drafts, [id]: draft } }
  storage.setItem(key, JSON.stringify(next))
  return next
}

/** Keeps one company's brand step uploads beside its draft; null removes them. Saved companies keep none. */
export function persistBrandUploads(
  storage: Pick<Storage, 'getItem' | 'setItem'>,
  id: string,
  uploads: StoredBrandUploads | null,
  key = BRANDING_KEY,
): BrandingStore {
  const previous = readBrandingStore(storage.getItem(key))
  if (previous.savedIds.includes(id)) return previous
  if (!uploads && !previous.brandUploads[id]) return previous
  const brandUploads = { ...previous.brandUploads }
  if (uploads) brandUploads[id] = uploads
  else delete brandUploads[id]
  const next: BrandingStore = { ...previous, brandUploads }
  storage.setItem(key, JSON.stringify(next))
  return next
}
