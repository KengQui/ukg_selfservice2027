import SelfServiceShell from '@workspace/setup-shared/templates/selfservice-shell/SelfServiceShell'
import BrandingDemo from './BrandingDemo'
import { useEffect, useState } from 'react'
import { InlineMessage } from '@ready/dls/compatibility'
import { GLOBAL_SETUP_NOTICE_EVENT, showGlobalSetupPlaceholder } from './completionNavigation'

export const meta = {
  id:          'system-theme-setup',
  title:       'Bring Your Brand to Work',
  route:       'system-theme-setup',
  section:     'prototype',
  area:        'System Setup',
  description: 'Add your company’s logo, colors and login page so your team sees a familiar look when they sign in.',
  status:      'wip',
} as const

export default function SystemThemeSetupPage() {
  const [notice, setNotice] = useState('')
  useEffect(() => {
    let timeout: ReturnType<typeof setTimeout> | undefined
    const handleNotice = (event: Event) => {
      setNotice((event as CustomEvent<string>).detail)
      clearTimeout(timeout)
      timeout = setTimeout(() => setNotice(''), 5000)
    }
    window.addEventListener(GLOBAL_SETUP_NOTICE_EVENT, handleNotice)
    return () => {
      window.removeEventListener(GLOBAL_SETUP_NOTICE_EVENT, handleNotice)
      clearTimeout(timeout)
    }
  }, [])
  return (
    <BrandingDemo renderPage={(content, actions, scenarioLabel) => <SelfServiceShell
      title="Bring Your Brand to Work"
      titleHeadingClassName="text-[18px]"
      backButtonClassName="text-[12px]"
      headerActions={actions && <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 'var(--space-100)' }}>
        {actions}
        {scenarioLabel && <p className="text-caption" style={{ margin: 0 }}>{scenarioLabel}</p>}
      </div>}
      breadcrumbs={['Global Setup', 'Bring Your Brand to Work']}
      hideNav
      hideTabs
      showBack={true}
      onBack={() => showGlobalSetupPlaceholder()}
    >
      {notice && <div role="status"><InlineMessage theme="info">{notice}</InlineMessage></div>}
      {content}
    </SelfServiceShell>} />
  )
}
