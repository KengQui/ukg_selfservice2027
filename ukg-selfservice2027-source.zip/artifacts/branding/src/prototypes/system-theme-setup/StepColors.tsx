import { Button, Input } from '@ready/dls/compatibility'
import type { ThemeSetupState } from './SystemThemeSetup'
import { useEffect, useRef, useState } from 'react'
import ContrastGuidance from './ContrastGuidance'
import PagePreview from './PagePreview'
import { applyContrastChoice } from './contrast'
import { COLOR_CODE_MESSAGE, colorPickerValue, isValidColorCode, manualColorUpdates, offersCustomPalette, paletteChoices, selectPalette } from './palettes'
import type { PaletteName } from './palettes'
import ThemeLogoUpload from './ThemeLogoUpload'
import { useAskBrytePage } from '@workspace/setup-shared/ask-bryte'

interface Props {
  data: ThemeSetupState
  onUpdate: (updates: Partial<ThemeSetupState>) => void
  onNext: () => void
  onBack: () => void
}

export default function StepColors({ data, onUpdate, onNext, onBack }: Props) {
  useAskBrytePage('colors', {
    palette: data.selectedPalette ?? 'Custom',
    primaryColor: data.primaryColor,
    accentColor: data.accentColor,
    presetPalettesOnly: false,
    customAvailable: offersCustomPalette(data),
    colorsFromLogo: Boolean((data.customPalette ?? data).colorsExtractedFromLogo),
  })
  const [localPrimary, setLocalPrimary] = useState(data.primaryColor)
  const [localAccent, setLocalAccent] = useState(data.accentColor)
  const primaryPicker = useRef<HTMLInputElement>(null)
  const accentPicker = useRef<HTMLInputElement>(null)
  const selectedPalette = data.selectedPalette ?? 'Custom'
  const custom = data.customPalette ?? data
  // The intro follows how the step was reached (Skip, a logo with extracted colors, or neither), never the selected
  // palette: the Palette card and the picker already show that. Picking a named palette clears
  // colorsExtractedFromLogo on the live colors, so the Custom snapshot is what still says the colors came from the logo.
  const intro = data.presetPalettesOnly
    ? 'Your colors show across the pages your team uses every day. Choose a ready-made palette or pick your own colors. You can change them anytime.'
    : custom.colorsExtractedFromLogo
    ? 'We picked these starting colors from your logo. Check them and adjust anything that’s off. You can change them anytime.'
    : 'Your colors show across the pages your team uses every day. Check them and adjust if needed. You can change them anytime.'
  const palettes = paletteChoices(data)
  useEffect(() => { setLocalPrimary(data.primaryColor) }, [data.primaryColor])
  useEffect(() => { setLocalAccent(data.accentColor) }, [data.accentColor])
  const handlePaletteChange = (name: PaletteName) => {
    const updates = selectPalette(data, name)
    setLocalPrimary(updates.primaryColor!)
    setLocalAccent(updates.accentColor!)
    onUpdate(updates)
  }

  const openPicker = (input: HTMLInputElement | null) => {
    if (!input) return
    if (typeof input.showPicker === 'function') input.showPicker()
    else input.click()
  }

  const isPrimaryValid = isValidColorCode(localPrimary)
  const isAccentValid = isValidColorCode(localAccent)
  const comparisonColor = data.contrastSourceColor ?? data.primaryColor

  const handleContrastChoice = (choice: 'darker' | 'lighter' | 'white' | 'original') => {
    const update = applyContrastChoice(comparisonColor, choice)
    setLocalPrimary(update.primaryColor)
    onUpdate({ ...update, selectedPalette: 'Custom' })
  }

  const handlePrimaryChange = (val: string) => {
    setLocalPrimary(val)
    if (isValidColorCode(val)) {
      onUpdate(manualColorUpdates('primaryColor', val))
    }
  }

  const handleAccentChange = (val: string) => {
    setLocalAccent(val)
    if (isValidColorCode(val)) {
      onUpdate(manualColorUpdates('accentColor', val))
    }
  }

  return (
    <div className="ts-hero-grid ts-colors-split">
      <div className="ts-hero-left">
      <div className="ts-hero-left-inner">
      <h1 className="text-display ts-h1">
        Theme
      </h1>
      <p className="text-body ts-intro">{intro}</p>

      <ThemeLogoUpload data={data} onUpdate={onUpdate} />
      <section className="ts-card ts-primary-color-card" aria-label="Theme color settings">
        <h2 style={{ margin: '0 0 var(--space-400)', fontSize: 'var(--type-lg-size)', fontWeight: 600 }}>Palette</h2>
        <p className="text-body" style={{ margin: '0 0 var(--space-400)', color: 'var(--color-text-subtle)' }}>{selectedPalette}</p>
        <div style={{ display: 'flex', gap: 'var(--space-400)' }}>
          <div style={{ position: 'relative', width: 48, height: 48, marginTop: 24, flexShrink: 0 }}>
            <div style={{ width: '100%', height: '100%', borderRadius: 'var(--radius-200)', background: isPrimaryValid ? localPrimary : 'var(--color-surface)', border: '1px solid var(--color-border)', position: 'absolute', pointerEvents: 'none' }} />
            <input 
              type="color" 
              aria-label="Choose primary color"
              ref={primaryPicker}
              value={colorPickerValue(localPrimary)}
              onChange={e => handlePrimaryChange(e.target.value)}
              style={{ opacity: 0, width: '100%', height: '100%', cursor: 'pointer' }}
            />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <Input
              id="primary-color"
              label="Primary color"
              value={localPrimary}
              onChange={handlePrimaryChange}
              size="large"
            />
            {!isPrimaryValid && <div role="alert" style={{ color: 'var(--color-status-error)', fontSize: 'var(--type-sm-size)', marginTop: 'var(--space-100)' }}>{COLOR_CODE_MESSAGE}</div>}
            <Button variant="tertiary" highEmphasis size="small" style={{ padding: 0, textDecoration: 'underline' }} aria-label="Choose primary color using color picker" onClick={() => openPicker(primaryPicker.current)}>Choose color</Button>
          </div>
        </div>
        {isPrimaryValid && (
          <ContrastGuidance color={comparisonColor} currentColor={data.primaryColor} whiteBackground={data.lightView} onChoose={handleContrastChoice} />
        )}
        <div style={{ display: 'flex', gap: 'var(--space-400)', marginTop: 'var(--space-600)' }}>
          <div style={{ position: 'relative', width: 48, height: 48, marginTop: 24, flexShrink: 0 }}>
            <div style={{ width: '100%', height: '100%', borderRadius: 'var(--radius-200)', background: isAccentValid ? localAccent : 'var(--color-surface)', border: '1px solid var(--color-border)', position: 'absolute', pointerEvents: 'none' }} />
            <input 
              type="color" 
              aria-label="Choose accent color"
              ref={accentPicker}
              value={colorPickerValue(localAccent)}
              onChange={e => handleAccentChange(e.target.value)}
              style={{ opacity: 0, width: '100%', height: '100%', cursor: 'pointer' }}
            />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <Input
              id="accent-color"
              label="Accent color"
              value={localAccent}
              onChange={handleAccentChange}
              size="large"
            />
            {!isAccentValid && <div role="alert" style={{ color: 'var(--color-status-error)', fontSize: 'var(--type-sm-size)', marginTop: 'var(--space-100)' }}>{COLOR_CODE_MESSAGE}</div>}
            <Button variant="tertiary" highEmphasis size="small" style={{ padding: 0, textDecoration: 'underline' }} aria-label="Choose accent color using color picker" onClick={() => openPicker(accentPicker.current)}>Choose color</Button>
          </div>
        </div>

      </section>
      <div className="ts-actions">
        <Button variant="secondary" size="large" onClick={onBack}>Back</Button>
        <Button variant="primary" size="large" onClick={onNext} disabled={!isPrimaryValid || !isAccentValid}>Next</Button>
      </div>
      </div>
      </div>
      <aside className="ts-hero-right" aria-label="Theme colors preview">
        <div className="ts-colors-preview">
          <div className="ts-palette-card mb-[0px]">
          <fieldset className="ts-palette-selector">
            <legend className="font-normal">Choose a palette</legend>
            <div className="ts-palette-options">
              {palettes.map(palette => (
                <label className="ts-palette-option" key={palette.name}>
                  <input type="radio" name="theme-palette" value={palette.name}
                    checked={selectedPalette === palette.name}
                    onChange={() => handlePaletteChange(palette.name)} />
                  <span className="ts-palette-circle" aria-hidden="true"
                    style={{ background: `linear-gradient(90deg, ${palette.primaryColor} 50%, ${palette.accentColor} 50%)` }}>
                    {selectedPalette === palette.name && <span className="ts-palette-check">✓</span>}
                  </span>
                  <span>{palette.name}</span>
                </label>
              ))}
            </div>
          </fieldset>
          </div>
          <p className="ts-preview-title">Preview</p>
          <PagePreview data={data} />
        </div>
      </aside>
    </div>
  );
}
