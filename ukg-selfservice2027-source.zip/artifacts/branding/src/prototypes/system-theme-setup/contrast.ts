/** WCAG AAA, normal text, opaque sRGB backgrounds. */
export const NORMAL_TEXT_MIN_CONTRAST = 7

function rgb(hex: string) {
  if (!/^#(?:[a-f\d]{3}|[a-f\d]{6})$/i.test(hex)) throw new Error('Expected an opaque hex color.')
  const digits = hex.slice(1)
  const expanded = digits.length === 3 ? [...digits].map(c => c + c).join('') : digits
  return [0, 2, 4].map(offset => parseInt(expanded.slice(offset, offset + 2), 16) / 255)
}

export function primaryTextContrast(background: string) {
  const channels = rgb(background).map(value =>
    value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4,
  )
  const luminance = channels[0] * 0.2126 + channels[1] * 0.7152 + channels[2] * 0.0722
  const whiteRatio = 1.05 / (luminance + 0.05)
  const blackRatio = (luminance + 0.05) / 0.05
  const whitePasses = whiteRatio >= NORMAL_TEXT_MIN_CONTRAST
  const blackPasses = blackRatio >= NORMAL_TEXT_MIN_CONTRAST
  // Show the stronger pairing, even when an adjustment is needed to meet AAA.
  const useWhite = whiteRatio >= blackRatio
  return { whiteRatio, blackRatio, whitePasses, blackPasses,
    textColor: useWhite ? '#FFFFFF' : '#000000', textLabel: useWhite ? 'White' : 'Black' }
}

export function headerAppearance(primaryColor: string, lightView: boolean) {
  const background = lightView ? '#FFFFFF' : primaryColor
  return { background, ...primaryTextContrast(background) }
}

export function colorHsl(hex: string) {
  const [r, g, b] = rgb(hex)
  const max = Math.max(r, g, b), min = Math.min(r, g, b)
  const delta = max - min
  const lightness = (max + min) / 2
  const saturation = delta === 0 ? 0 : delta / (1 - Math.abs(2 * lightness - 1))
  let hue = 0
  if (delta !== 0) {
    hue = max === r ? ((g - b) / delta) % 6 : max === g ? (b - r) / delta + 2 : (r - g) / delta + 4
    hue = (hue * 60 + 360) % 360
  }
  return { hue, saturation, lightness }
}

function hslHex(hue: number, saturation: number, lightness: number) {
  const chroma = (1 - Math.abs(2 * lightness - 1)) * saturation
  const x = chroma * (1 - Math.abs((hue / 60) % 2 - 1))
  const m = lightness - chroma / 2
  const channels = hue < 60 ? [chroma, x, 0] : hue < 120 ? [x, chroma, 0]
    : hue < 180 ? [0, chroma, x] : hue < 240 ? [0, x, chroma]
      : hue < 300 ? [x, 0, chroma] : [chroma, 0, x]
  return '#' + channels.map(v => Math.round((v + m) * 255).toString(16).padStart(2, '0')).join('').toUpperCase()
}

/** Retain HSL hue and saturation; search only lightness, checking rounded RGB. */
export function primaryColorSuggestion(background: string) {
  const contrast = primaryTextContrast(background)
  if (contrast.whitePasses || contrast.blackPasses) return null
  const { hue, saturation, lightness } = colorHsl(background)
  const options = (['darker', 'lighter'] as const).map(direction => {
    const target = direction === 'darker' ? 0 : 1
    for (let step = 1; step <= 1000; step++) {
      const color = hslHex(hue, saturation, lightness + (target - lightness) * step / 1000)
      const adjusted = primaryTextContrast(color)
      if (direction === 'darker' ? adjusted.whitePasses : adjusted.blackPasses) {
        return { direction, color, textColor: direction === 'darker' ? '#FFFFFF' : '#000000',
          textLabel: direction === 'darker' ? 'White' : 'Black',
          ratio: direction === 'darker' ? adjusted.whiteRatio : adjusted.blackRatio }
      }
    }
    throw new Error('Unable to find a readable primary color.')
  })
  return { ...contrast, options }
}

export function applyContrastChoice(source: string, choice: 'darker' | 'lighter' | 'white' | 'original') {
  const suggestion = primaryColorSuggestion(source)
  const primaryColor = choice === 'white' || choice === 'original' ? source : suggestion?.options.find(option => option.direction === choice)?.color
  if (!primaryColor) throw new Error('No contrast adjustment is needed for this color.')
  return { primaryColor, lightView: choice === 'white', contrastSourceColor: source }
}