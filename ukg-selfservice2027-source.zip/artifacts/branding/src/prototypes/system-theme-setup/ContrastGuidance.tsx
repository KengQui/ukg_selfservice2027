import { Button } from '@ready/dls/compatibility'
import { primaryColorSuggestion } from './contrast'

export default function ContrastGuidance({ color, currentColor, whiteBackground, onChoose }: {
  color: string
  currentColor: string
  whiteBackground: boolean
  onChoose: (choice: 'darker' | 'lighter' | 'white' | 'original') => void
}) {
  const suggestion = primaryColorSuggestion(color)
  if (!suggestion) return null
  const selected = whiteBackground ? 'white background' : suggestion.options.find(option => option.color.toUpperCase() === currentColor.toUpperCase())?.direction
  return (
    <section className="ts-contrast-guidance" aria-label="Primary color text contrast">
      <h2>Text readability</h2>
      <p>With your original primary color, <strong>{color.toUpperCase()}</strong>, as the header background, neither white nor black text stands out enough to read comfortably. Try a darker or lighter shade, or a white header background, so everyone can read the header. You can switch between these options to compare the preview.</p>
      <div className="ts-contrast-options">
        {suggestion.options.map(option => (
        <div className="ts-contrast-option" key={option.direction}>
          <span className="ts-contrast-sample" style={{ background: option.color, color: option.textColor }} aria-hidden="true">Aa</span>
          <span><strong>{option.color}</strong><br />{option.textLabel} text</span>
          <Button variant={selected === option.direction ? 'primary' : 'secondary'} size="small" aria-pressed={selected === option.direction} onClick={() => onChoose(option.direction)}>Apply {option.direction}</Button>
        </div>
        ))}
        <div className="ts-contrast-option">
          <span className="ts-contrast-sample" style={{ background: '#FFFFFF', color: '#000000' }} aria-hidden="true">Aa</span>
          <span><strong>White background</strong><br />Black text</span>
          <Button variant={whiteBackground ? 'primary' : 'secondary'} size="small" aria-pressed={whiteBackground} onClick={() => onChoose('white')}>Apply white background</Button>
        </div>
      </div>
      <Button variant="tertiary" highEmphasis size="small" style={{ padding: 0, textDecoration: 'underline' }} disabled={!selected} onClick={() => onChoose('original')}>Revert to original color</Button>
    </section>
  )
}