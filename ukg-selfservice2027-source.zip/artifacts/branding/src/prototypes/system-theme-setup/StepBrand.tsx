import { useEffect, useRef, useState } from 'react'
import { detectBrandLogo } from '@workspace/api-client-react'
import { Button, Checkbox, InlineMessage, Icon } from '@ready/dls/compatibility'
import { DropZone, SelectedFilesCard } from '@workspace/setup-shared/prototypes/_shared/uploadFiles'
import type { ThemeSetupState } from './SystemThemeSetup'
import { extractDominantColors, logoColorUpdates } from './colorExtraction'
import { readyMadePalette, startingPalette } from './palettes'
import { SAMPLE_LOGO } from './sampleLogo'
import { makeStoredImage, makeVisionImage, readAsDataUrl } from './brandImages'
import { BRAND_ASSET_ACCEPT, BRAND_ASSET_FORMATS, BRAND_DOCUMENT_TYPES, brandDocumentType, isBrandAsset, isBrandImage, isSelectedBrandLogo } from './brandUploads'
import type { BrandDocumentType, BrandFile, BrandUploads } from './brandUploads'
import { logoAnalysisFailureMessage } from './logoAnalysisFailure'
import { useAskBrytePage } from '@workspace/setup-shared/ask-bryte'

const PLACEHOLDER_LOGO = {
  ...SAMPLE_LOGO,
  isDocumentUpload: false,
  colorsExtractedFromLogo: false,
  reuseHeaderLogo: true,
  localLoginLogoUrl: null,
  localLoginLogoFileName: null,
  localLoginLogoSize: 0,
  displayLoginLogo: true,
}

const MAX_FILES = 5
function formatBytes(bytes: number): string {
  if (!bytes) return '0 B'
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / 1048576).toFixed(1)} MB`
}
function matchesOriginalUploadBytes(file: BrandFile): boolean {
  if (!file.url) return false
  const comma = file.url.indexOf(',')
  if (comma < 0 || !file.url.slice(0, comma).endsWith(';base64')) return false
  const encoded = file.url.slice(comma + 1)
  const padding = encoded.endsWith('==') ? 2 : encoded.endsWith('=') ? 1 : 0
  return Math.floor(encoded.length * 3 / 4) - padding === file.size
}
interface Props {
  data: ThemeSetupState
  onUpdate: (updates: Partial<ThemeSetupState>) => void
  onNext: () => void
  onBack: () => void
  /** Uploads and their analysis outcome belong to the setup, so they outlive this step and a resumed company. */
  uploads: BrandUploads
  onUploadsChange: (update: (previous: BrandUploads) => BrandUploads) => void
}

export default function StepBrand({ data, onUpdate, onNext, onBack, uploads, onUploadsChange }: Props) {
  useAskBrytePage('logo', { uploads: uploads.files.length, logoChosen: Boolean(uploads.selectedLogoId) })
  const [error, setError] = useState('')
  const [selectedFiles, setSelectedFiles] = useState<{ id: string; file: File; docType?: BrandDocumentType }[]>([])
  const [isSelectingLogo, setIsSelectingLogo] = useState(false)
  const analysisVersion = useRef(0)
  const open = useRef(true)
  // A resumed draft can still hold the original image even though its kept upload is bounded.
  // Keep that source for this step so unchecking and rechecking does not downgrade it.
  const retainedLogoUrls = useRef(new Map<string, string>())
  const { files: uploadedFiles, status: analysisStatus, message: analysisMessage } = uploads
  // Results belong to the company whose brand step started them. Leaving the step (browser Back, another company)
  // ends every analysis in flight, so a late result can never land in whichever setup is open by then.
  useEffect(() => {
    open.current = true
    // An analysis cut short that way is picked up again when the same setup reopens this step.
    if (analysisStatus === 'processing') void analyzeFiles(uploadedFiles)
    return () => {
      open.current = false
      analysisVersion.current++
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- mount and unmount only
  }, [])
  const isCurrent = (version: number) => open.current && version === analysisVersion.current
  const isProcessing = analysisStatus === 'processing' || isSelectingLogo
  const canContinue = uploadedFiles.length > 0
    && selectedFiles.length === 0
    && !isProcessing
    && analysisStatus !== 'failed'
    && analysisStatus !== 'idle'

  const clearDetectedLogo = () => {
    onUploadsChange(previous => ({ ...previous, selectedLogoId: null }))
    onUpdate({
      ...PLACEHOLDER_LOGO,
      ...logoColorUpdates(data, null),
    })
  }

  const analyzeFiles = async (files: BrandFile[]) => {
    if (!open.current) return
    const version = ++analysisVersion.current
    setError('')
    clearDetectedLogo()

    if (!files.some(file => file.url)) {
      onUploadsChange(previous => ({
        ...previous,
        files,
        status: files.length ? 'documents-only' : 'idle',
        message: files.length ? 'Continue to choose your colors and add a logo separately.' : '',
      }))
      return
    }

    onUploadsChange(previous => ({ ...previous, files, status: 'processing', message: '' }))
    try {
      // Restored uploads keep only their stored image; the copy for analysis is prepared from it again.
      const prepared = await Promise.all(files.map(async file => (
        file.url && !file.visionDataUrl ? { ...file, visionDataUrl: await makeVisionImage(file.url) } : file
      )))
      const images = prepared.filter(file => file.visionDataUrl)
      const result = await detectBrandLogo({
        images: images.map(file => ({ dataUrl: file.visionDataUrl! })),
      })
      if (!isCurrent(version)) return

      const match = result.selectedIndex === null || result.confidence < 0.8 ? undefined : images[result.selectedIndex]
      if (!match?.url) {
        onUploadsChange(previous => ({ ...previous, files: prepared, status: 'no-match', message: NO_MATCH_MESSAGE }))
        return
      }

      const logoUrl = match.originalUrl ?? match.url
      const colors = await extractDominantColors(logoUrl)
      if (!isCurrent(version)) return
      onUpdate({
        ...logoColorUpdates(data, colors),
        logoUrl,
        logoFileName: match.name,
        logoSize: match.size,
        isDocumentUpload: false,
      })
      onUploadsChange(previous => ({
        ...previous,
        files: prepared,
        status: 'matched',
        selectedLogoId: match.id,
        message: colors
          ? `We identified ${match.name} as the standalone logo and picked starting colors from it. Check them on the next step.`
          : `We identified ${match.name} as the standalone logo, but couldn’t pick colors from it. Choose your colors on the next step.`,
      }))
    } catch (error) {
      if (!isCurrent(version)) return
      onUploadsChange(previous => ({
        ...previous,
        status: 'failed',
        message: logoAnalysisFailureMessage(error),
      }))
    }
  }

  const handleFiles = (files: File[]) => {
    if (files.length === 0) return
    if (files.length + selectedFiles.length + uploadedFiles.length > MAX_FILES) {
      setError('Choose up to 5 files in total. Remove a file before adding more.')
      return
    }
    // Drag and drop bypasses the input's accept filter, so the format is checked here as well.
    const unsupported = files.filter(file => !isBrandAsset(file))
    const tooLarge = files.filter(file => isBrandAsset(file) && file.size > MAX_FILE_BYTES)
    const problems = [
      unsupported.length ? `${unsupported.map(file => file.name).join(', ')}: use ${BRAND_ASSET_FORMATS}.` : '',
      tooLarge.length ? `${tooLarge.map(file => file.name).join(', ')}: each file must be no larger than 2 MB.` : '',
    ].filter(Boolean)
    setError(problems.join(' '))
    const accepted = files.filter(file => isBrandAsset(file) && file.size <= MAX_FILE_BYTES)
    setSelectedFiles(previous => [...previous, ...accepted.map(file => ({ id: crypto.randomUUID(), file }))])
  }

  const uploadFiles = async () => {
    if (!selectedFiles.length || isProcessing) return
    const version = ++analysisVersion.current
    onUploadsChange(previous => ({ ...previous, status: 'processing' }))
    setError('')
    const added: BrandFile[] = []
    const errors: string[] = []

    for (const { id, file, docType } of selectedFiles) {
      try {
        if (isBrandImage(file)) {
          const originalUrl = await readAsDataUrl(file)
          const [url, visionDataUrl] = await Promise.all([makeStoredImage(originalUrl), makeVisionImage(originalUrl)])
          added.push({ id, name: file.name, size: file.size, url, originalUrl, visionDataUrl, docType })
        } else {
          added.push({ id, name: file.name, size: file.size, url: null, docType })
        }
      } catch {
        errors.push(file.name)
      }
    }

    if (!isCurrent(version)) return
    const next = [...uploadedFiles, ...added]
    setSelectedFiles(previous => previous.filter(item => !added.some(file => file.id === item.id)))
    const analysis = analyzeFiles(next)
    const activeVersion = analysisVersion.current
    await analysis
    if (errors.length && isCurrent(activeVersion)) setError(`We couldn’t add ${errors.join(', ')}. Try again, or remove ${errors.length === 1 ? 'that file' : 'those files'} and choose another.`)
  }

  const removeUploadedFile = (id: string) => {
    retainedLogoUrls.current.delete(id)
    void analyzeFiles(uploadedFiles.filter(file => file.id !== id))
  }

  const selectLogo = async (file: BrandFile, checked: boolean) => {
    if (isProcessing || !file.url) return
    if (!checked) {
      if (isSelectedBrandLogo(uploads, file, data) && data.logoUrl) {
        retainedLogoUrls.current.set(file.id, data.logoUrl)
      }
      clearDetectedLogo()
      onUploadsChange(previous => ({
        ...previous,
        status: 'no-match',
        message: 'No brand logo selected. Choose an image below or add a logo on the next step.',
      }))
      return
    }
    setIsSelectingLogo(true)
    const version = ++analysisVersion.current
    try {
      // The original upload is used while it is still in memory; a restored upload offers its kept copy.
      const draftLogoUrl = uploads.selectedLogoId === file.id
        && data.logoFileName === file.name
        && data.logoSize === file.size
        ? data.logoUrl
        : undefined
      const retainedLogoUrl = retainedLogoUrls.current.get(file.id)
      if (!file.originalUrl && !retainedLogoUrl && !draftLogoUrl && !matchesOriginalUploadBytes(file)) {
        setError(`We only kept a smaller copy of ${file.name}. Upload the original again to use it as your logo at full quality.`)
        return
      }
      setError('')
      const logoUrl = file.originalUrl ?? retainedLogoUrl ?? draftLogoUrl ?? file.url
      const colors = await extractDominantColors(logoUrl)
      if (!isCurrent(version)) return
      onUpdate({
        logoUrl,
        logoFileName: file.name,
        logoSize: file.size,
        isDocumentUpload: false,
        ...logoColorUpdates(data, colors),
      })
      onUploadsChange(previous => ({
        ...previous,
        status: 'matched',
        selectedLogoId: file.id,
        message: `${file.name} is your selected brand logo.${colors ? ' Colors have been prepared from it.' : ' We couldn’t pick colors from it. Choose your colors on the next step.'}`,
      }))
    } catch {
      if (!isCurrent(version)) return
      setError('We couldn’t open this image. It may be damaged. Export it again, or choose another file.')
    } finally {
      if (isCurrent(version)) setIsSelectingLogo(false)
    }
  }

  return (
    <div>
      <h1 className="text-display ts-h1">Upload your brand assets</h1>
      <p className="text-body ts-intro">
        Upload your logo, plus anything that shows your brand — a brochure, website screenshot, or brand guide, as {BRAND_ASSET_FORMATS}. We’ll find your logo and suggest starting colors when they’re available. You can check and change both on the next steps.
      </p>
      {!isProcessing && (
        <DropZone disabled={false} onFiles={handleFiles} multiple accept={BRAND_ASSET_ACCEPT} helperText="Choose up to 5 images or documents, up to 2 MB each." />
      )}
      {!!selectedFiles.length && !isProcessing && (
        <div style={{ marginTop: 'var(--space-400)' }}>
          <SelectedFilesCard localDetails
            files={selectedFiles.map(({ id, file, docType }) => ({ id, name: file.name, sizeBytes: file.size, displayName: file.name, docType: docType ?? '' }))}
            documentTypes={BRAND_DOCUMENT_TYPES}
            onDocType={(id, value) => setSelectedFiles(previous => previous.map(file => file.id === id ? { ...file, docType: brandDocumentType(value) } : file))}
            onRemove={id => { setSelectedFiles(previous => previous.filter(file => file.id !== id)); setError('') }}
            onUpload={uploadFiles} />
        </div>
      )}

      {!!uploadedFiles.length && (
        <div style={{ margin: '24px 0' }} aria-label="Uploaded brand assets">
          {uploadedFiles.map(file => (
            <div key={file.id} style={{ padding: 12, border: '1px solid var(--color-border)', borderRadius: 8, marginBottom: 8 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              {file.url ? (
                <img src={file.url} alt="" style={{ width: 48, height: 48, objectFit: 'contain' }} />
              ) : (
                <div style={{ width: 48, height: 48, display: 'grid', placeItems: 'center' }}><Icon name="document" size={24} className="icon--subtle" /></div>
              )}
              <span style={{ flex: 1, minWidth: 0, overflowWrap: 'anywhere' }}>{file.name}<br /><small>{formatBytes(file.size)}{!file.url && ' · Document'}{file.docType && <> · Document type: {file.docType}</>}</small></span>
              <Button variant="tertiary" size="small" iconLeftName="delete" aria-label={`Remove ${file.name}`} disabled={isProcessing} onClick={() => removeUploadedFile(file.id)} />
              </div>
              {file.url && (
                <div style={{ marginTop: 12 }}>
                  <Checkbox
                    label="Use as your brand logo"
                    description={file.name}
                    checked={isSelectedBrandLogo(uploads, file, data)}
                    disabled={isProcessing}
                    onChange={checked => void selectLogo(file, checked)}
                  />
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {isProcessing ? (
        <div role="status" style={{ padding: 'var(--space-600)', background: 'var(--color-surface)', borderRadius: 'var(--radius-300)', textAlign: 'center', color: 'var(--color-text-subtle)' }}>
          {isSelectingLogo ? 'Picking colors from your logo…' : 'Finding your logo…'}
        </div>
      ) : analysisMessage ? (
        <div style={{ marginTop: 'var(--space-400)' }}>
          <InlineMessage theme={analysisStatus === 'failed' ? 'error' : 'info'}>{analysisMessage}</InlineMessage>
          {analysisStatus === 'failed' && (
            <div style={{ marginTop: 'var(--space-300)' }}>
              <Button variant="secondary" size="small" onClick={() => void analyzeFiles(uploadedFiles)}>Retry analysis</Button>
            </div>
          )}
        </div>
      ) : null}

      {error && <div style={{ marginTop: 'var(--space-400)' }}><InlineMessage theme="error">{error}</InlineMessage></div>}

      <div style={{ marginTop: 'var(--space-600)' }}>
        {/* A palette the company already chose survives Skip; only Custom or unset colors fall back to Teal. */}
        <Button variant="tertiary" highEmphasis size="small" disabled={isProcessing} onClick={() => { onUpdate({ ...readyMadePalette(data), ...PLACEHOLDER_LOGO, presetPalettesOnly: true }); onNext(); }} style={{ padding: 0, textDecoration: 'underline', textUnderlineOffset: '3px' }}>
          Skip, I'll pick a ready-made palette
        </Button>
      </div>

      <div className="ts-actions">
        <Button variant="secondary" size="large" onClick={onBack} disabled={isProcessing}>Back</Button>
        <Button variant="primary" size="large" onClick={() => {
          if (!canContinue) return
          // Without colors from the uploads, Colors opens on a ready-made palette, never the built-in starting colors.
          onUpdate({ ...startingPalette(data), presetPalettesOnly: false })
          onNext()
        }} disabled={!canContinue}>Next</Button>
      </div>
    </div>
  )
}

const NO_MATCH_MESSAGE = 'We didn’t find a standalone logo in these files. You can continue with them and add your logo on the next step.'

const MAX_FILE_BYTES = 2 * 1024 * 1024
