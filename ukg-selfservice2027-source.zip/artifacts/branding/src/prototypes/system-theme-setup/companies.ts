import type { CompanySummary } from './copyBrandingState'
import { DEMO_COMPANY_IDS } from '@workspace/setup-shared/prototypes/branding-demo/demoScenarios'

// Demo catalog only. Replace with authorized company records before production use.
export const SAMPLE_COMPANIES: CompanySummary[] = [
  { id: DEMO_COMPANY_IDS[0], name: 'Acme Holdings, Inc.', ein: '12-3456789' },
  { id: DEMO_COMPANY_IDS[1], name: 'Acme Services, LLC', ein: '23-4567890' },
  { id: DEMO_COMPANY_IDS[2], name: 'Acme Retail, Inc.', ein: '34-5678901' },
]

/**
 * A larger catalog for browser checks only, opened with `?catalog=large`. Some behavior appears only past a
 * handful of companies (the copy-source dialog's search), which the three demo companies can never reach.
 * The demo scenarios always use SAMPLE_COMPANIES; their start URLs never name a catalog.
 */
export const LARGE_SAMPLE_COMPANIES: CompanySummary[] = [
  ...SAMPLE_COMPANIES,
  { id: 'acme-logistics', name: 'Acme Logistics, LLC', ein: '41-2093857' },
  { id: 'northwind-traders', name: 'Northwind Traders, Inc.', ein: '58-6641209' },
  { id: 'northwind-foods', name: 'Northwind Foods, LLC', ein: '58-6641377' },
  { id: 'contoso-labs', name: 'Contoso Labs, Inc.', ein: '73-1180462' },
  { id: 'contoso-clinics', name: 'Contoso Clinics, LLC', ein: '73-2295018' },
  { id: 'fabrikam-manufacturing', name: 'Fabrikam Manufacturing, Inc.', ein: '92-0473615' },
]

/** The company catalog named by the prototype URL's `catalog` parameter; anything but `large` is the demo catalog. */
export function companyCatalog(value: string | null): CompanySummary[] {
  return value === 'large' ? LARGE_SAMPLE_COMPANIES : SAMPLE_COMPANIES
}

export function selectedCompanies(value: string | null) {
  const ids = new Set((value ?? '').split(','))
  // Even legacy multi-selection URLs must target only one EIN.
  return SAMPLE_COMPANIES.filter(company => ids.has(company.id)).slice(0, 1)
}
