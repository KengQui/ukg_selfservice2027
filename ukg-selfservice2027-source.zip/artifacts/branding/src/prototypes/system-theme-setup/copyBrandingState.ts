import type { ThemeSetupState } from './SystemThemeSetup'

export type CompanySummary = { id: string; name: string; ein: string }
export type ThemeMap = Record<string, ThemeSetupState>

/** The reviewed setup includes visual settings and recipient-specific initial Login text. */
export type ReviewedBranding = Partial<ThemeSetupState> & Pick<ThemeSetupState,
  'logoUrl' | 'logoFileName' | 'logoSize' | 'primaryColor' | 'accentColor'>

/** A company whose confirmed saved branding can be copied. */
export type CopySource = {
  company: CompanySummary
  theme: ThemeSetupState
  saved: boolean
}

/** Every company with confirmed saved branding, in company order; unsaved previews never qualify. */
export function copySources(
  themes: ThemeMap,
  companies: CompanySummary[],
  _previewId?: string,
  _previewTheme?: ThemeSetupState,
): CopySource[] {
  return companies.flatMap(company => {
    const theme = themes[company.id]
    return theme ? [{ company, theme, saved: true }] : []
  })
}

/** Prepare recipient text once; subsequent edits are applied exactly as reviewed. */
export function prepareReviewedBranding(source: ThemeSetupState, sourceName: string, recipientName: string): ThemeSetupState {
  const escapedSourceName = sourceName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  const companyReference = escapedSourceName
    ? new RegExp(`\\[Company Name\\]|${escapedSourceName}`, 'g')
    : /\[Company Name\]/g
  return {
    ...structuredClone(source),
    loginTagline: recipientName,
    employeeLoginMessage: source.employeeLoginMessage.replace(companyReference, () => recipientName),
  }
}

/** Copies the entire reviewed setup without mutating the source or unselected companies. */
export function copyVisualBranding(
  themes: ThemeMap,
  sourceId: string,
  targetIds: string[],
  reviewed: ReviewedBranding,
): ThemeMap {
  const source = themes[sourceId]
  if (!source) throw new Error('The selected branding source is not available.')

  const visual = { ...source, ...reviewed }
  const next = { ...themes }
  for (const id of new Set(targetIds)) {
    if (id === sourceId) continue
    next[id] = structuredClone(visual)
  }
  return next
}

/** Creates an unsaved draft; callers persist it only after explicit completion. */
export function freshBrandingDraft(defaults: ThemeSetupState, companyName: string): ThemeSetupState {
  return {
    ...defaults,
    loginTagline: companyName,
    employeeLoginMessage: suggestedLoginMessage(defaults.employeeLoginMessage, companyName),
  }
}

/** Company-specific sample contact details belong only to new, untouched suggestions. */
function suggestedLoginMessage(message: string, companyName: string): string {
  const suggested = message.replaceAll('[Company Name]', companyName)
  return /^Bright Harbor Bakery(?: LLC)?[.,]?$/i.test(companyName.trim())
    ? suggested.replace('support@acme.com', 'support@brightharborbakery.com')
    : suggested
}

/** Resolve only untouched suggested text. An edited (including deliberately cleared) display name stays put. */
export function withSingleCompanyDefaults(
  state: ThemeSetupState,
  defaults: ThemeSetupState,
  companyName: string | undefined,
): ThemeSetupState {
  const name = companyName?.trim() ?? ''
  return {
    ...state,
    loginTagline: state.loginTagline === defaults.loginTagline ? name : state.loginTagline,
    employeeLoginMessage: state.employeeLoginMessage === defaults.employeeLoginMessage
      ? suggestedLoginMessage(defaults.employeeLoginMessage, name)
      : state.employeeLoginMessage.replaceAll('[Company Name]', name),
  }
}
/** Past this many companies to copy from, the dialog adds a search field so it stays usable at any company count. */
export const SOURCE_SEARCH_THRESHOLD = 6

/** Matches a company by name, or by EIN when the search is typed as digits, whichever the admin remembers. */
export function filterCopySources(sources: CopySource[], query: string) {
  const needle = query.trim().toLowerCase()
  if (!needle) return sources
  const digits = /^[\d\s-]+$/.test(needle) ? needle.replace(/\D/g, '') : ''
  return sources.filter(({ company }) =>
    company.name.toLowerCase().includes(needle) ||
    (digits.length > 0 && company.ein.replace(/\D/g, '').includes(digits)))
}
