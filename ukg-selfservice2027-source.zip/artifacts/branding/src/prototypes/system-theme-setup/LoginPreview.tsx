import type { CSSProperties } from 'react'
import type { ThemeSetupState } from './SystemThemeSetup'
import './loginPreview.css'
import { SAMPLE_LOGO } from './sampleLogo'

interface Props {
  data: ThemeSetupState
}

export default function LoginPreview({ data }: Props) {

  const logoSrc = (data.reuseHeaderLogo ? data.logoUrl : data.localLoginLogoUrl) || SAMPLE_LOGO.logoUrl
  const isDefaultLogo = logoSrc === SAMPLE_LOGO.logoUrl
  
  const bgStyle = {
    '--preview-primary': data.primaryColor,
    '--preview-accent': data.accentColor,
  } as CSSProperties

  const rawMessage = data.employeeLoginMessage
  const messageLines = rawMessage ? rawMessage.split('\n') : ['No login message yet. Add one on the Login screen step.']
  const firstLine = messageLines[0]
  const restLines = messageLines.slice(1)

  return (
    <div className="lp-container" style={bgStyle} aria-label="Login screen appearance preview">

      <div className="lp-page">
         <div className="lp-header">
             {data.displayLoginLogo && logoSrc ? (
              <div className="lp-logo-wrap" style={{ 
                 background: data.colorBehindLogo ? data.logoBackgroundColor : 'transparent',
                 padding: '0',
                 border: data.colorBehindLogo ? `4px solid ${data.logoBackgroundColor}` : 'none',
                 borderRadius: data.colorBehindLogo ? 'var(--radius-200)' : '0'
              }}>
                {data.displayLoginLogo && <img src={logoSrc} alt="Company Logo" className="lp-logo" style={{ display: 'block', filter: isDefaultLogo ? 'brightness(0)' : undefined }} />}
              </div>
            ) : (
              data.displayLoginLogo ? <div className="lp-logo-placeholder">Logo</div> : null
            )}
            {data.loginTagline && <div className="lp-tagline">{data.loginTagline}</div>}
         </div>

         <div className="lp-card">
            <div className="lp-left pt-[12px] pb-[12px]" style={{ paddingTop: 12, paddingBottom: 12 }}>
               <div className="lp-message-box text-[12px] border-t-[0px] border-r-[0px] border-b-[0px] border-l-[0px] mt-[24px] mb-[24px] pt-[24px] pb-[24px] bg-[#ffffff12]" style={{ fontSize: 12, borderWidth: 0, marginTop: 24, marginBottom: 24, paddingTop: 24, paddingBottom: 24, backgroundColor: '#ffffff12' }}>
                 <div className="lp-message-content">
                    <h3 className="lp-message-heading text-[#015151]" style={{ color: '#015151' }}>
                      {firstLine}
                    </h3>
                    {restLines.map((line, index) => {
                      const contact = line.match(/^\s*(Email|Phone):\s*(.*)$/i)
                      if (contact) return (
                        <div className="lp-message-contact" key={index}>
                          <strong>{contact[1]}</strong>
                          <span>{contact[2]}</span>
                        </div>
                      )
                      return line.trim()
                        ? <p className="lp-message-paragraph" key={index}>{line}</p>
                        : <div className="lp-message-gap" aria-hidden="true" key={index} />
                    })}
                 </div>
                 
               </div>
            </div>
            
            <div className="lp-right pt-[40px]" style={{ paddingTop: 40 }}>
               <h2 className="lp-welcome">Welcome back</h2>
               
               {data.loginClock ? (
                 <div className="lp-clock">10:27 AM (EDT)</div>
               ) : (
                 <div className="lp-clock-placeholder"></div>
               )}

               <div className="lp-form">
                 <div className="lp-input-group">
                   <label>Username</label>
                   <div className="lp-input-fake"></div>
                 </div>
                 <div className="lp-input-group">
                   <label>Password</label>
                   <div className="lp-input-fake lp-password-fake">
                     <svg className="lp-eye-icon" viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" strokeWidth="2" fill="none">
                       <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                       <circle cx="12" cy="12" r="3"></circle>
                       <line x1="1" y1="1" x2="23" y2="23"></line>
                     </svg>
                   </div>
                 </div>

                 <div className="lp-button-fake">
                   Sign in
                 </div>

                 <div className="lp-forgot">
                   Forgot your password?
                 </div>

                 <div className="lp-divider">
                   <span>or</span>
                 </div>

                 <div className="lp-google-fake">
                   <svg width="16" height="16" viewBox="0 0 24 24">
                     <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                     <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                     <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                     <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                   </svg>
                   Sign in with Google
                 </div>
               </div>
            </div>
         </div>
         
         <div className="lp-footer">
            Copyright © 2026 All Rights Reserved.
         </div>
      </div>
    </div>
  )
}
