/**
 * What Bryte knows about each Bring Your Brand to Work screen: name, purpose,
 * what's on screen, current state, welcome and suggested questions. Screens
 * register a page key and a few non-sensitive facts; everything Bryte reads
 * lives here, so voice passes edit this file rather than the screens.
 *
 * Register: `first-time` uses plain words and defines terms inline;
 * `experienced` is concise and pairs industry
 * names with plain ones. Never put file contents, the login message text, or
 * people's names and contact details in these descriptions.
 */
import type { AskBryteCatalog, AskBryteFacts, AskBryteRegister } from '@workspace/setup-shared/ask-bryte'
import { NORMAL_TEXT_MIN_CONTRAST, primaryTextContrast } from './prototypes/system-theme-setup/contrast.ts'

const yesNo = (value: unknown, yes: string, no: string) => (value ? yes : no)
const count = (value: unknown) => Math.max(0, Number(value) || 0)
const pick = (register: AskBryteRegister, firstTime: string, experienced: string) =>
  register === 'experienced' ? experienced : firstTime

function contrastLine(hex: unknown): string[] {
  if (typeof hex !== 'string') return []
  try {
    const result = primaryTextContrast(hex)
    const ratio = Math.max(result.whiteRatio, result.blackRatio).toFixed(1)
    const meets = result.whitePasses || result.blackPasses
    return [`${result.textLabel} text on the primary color has a contrast ratio of ${ratio}:1, which ${meets ? 'meets' : 'is below'} the ${NORMAL_TEXT_MIN_CONTRAST}:1 goal for readable text`]
  } catch {
    return ['Use # followed by 3 or 6 digits or letters A–F, like #1D6E56.']
  }
}

function companiesState(facts: AskBryteFacts): string[] {
  return [
    `Companies listed: ${count(facts.companies)}`,
    `Companies with saved branding: ${count(facts.savedCompanies)}`,
    ...(count(facts.editsInProcess) ? [`Companies with an edit in progress: ${count(facts.editsInProcess)}`] : []),
  ]
}

const nextStepActions = [
  'Primary action: Invite others to help. Opens the Invite others to help page; it does not send invitations.',
  'Secondary action: Return to Global Setup',
  'Global Setup is outside this prototype. Return to Global Setup stays on this screen; it does not open Company Setup.',
]

const companyListActions = (facts: AskBryteFacts) =>
  facts.allComplete ? nextStepActions : [
    'Action: Return to Global Setup',
    'Global Setup is outside this prototype. Return to Global Setup stays on this screen; it does not open Company Setup.',
  ]

const companyCardActions = (facts: AskBryteFacts) => [
  'Unfinished company actions: Set up (plus icon) if not started, Continue (forward arrow icon) if in progress',
  'Completed company action: Edit branding using its pencil icon',
  ...(count(facts.savedCompanies) > 0
    ? ['Copy branding is available only on company cards with another company’s saved branding to copy from; it is hidden otherwise']
    : ['Copy branding is hidden because no company has saved branding yet']),
]

const saveLaterGuidance = 'Header action: Save and finish later keeps progress without publishing branding. Global Setup is outside this prototype, so the action stays on the current screen and shows a saved-progress message.'

export const brandingPages = {
  intro: (facts, register) => ({
    name: 'Bring Your Brand to Work',
    purpose: [
      pick(register,
        'The start of branding. The person adds their logo and colors so UKG Ready feels familiar to their team, and sets up the login page they see when they sign in.',
        'The start of branding for this company: its logo, colors and login page, so its team sees a familiar brand when they sign in.'),
      // Archived implementation team demos only.
      ...(facts.advancedStep ? ['This setup also has Advanced settings after Login page: the favicon, the OAuth icon and the clock options.'] : []),
      ...(facts.multiEin ? ['The business has more than one company EIN (federal tax ID), so the person brands one company first and can then copy that branding to the others.'] : []),
    ].join(' '),
    onScreen: [
      'What you’ll customize: your company logo, primary color, accent color, and login page branding',
      'Bring your brand along: your company logo; a brand guide or style guide; a branded brochure, presentation saved as PDF, or letterhead; a screenshot of your company website',
      facts.advancedStep
        ? 'Estimated setup time, 4 steps (brand assets, theme, login page, advanced settings), and a note that you can update your branding anytime'
        : 'Estimated setup time, and a note that you can update your branding anytime',
      'Main action: Add your branding',
    ],
    state: [],
    welcome: pick(register,
      'You’re at the start of Bring Your Brand to Work. I can explain what you’ll customize and what’s handy to have nearby before you begin.',
      'You’re at the start of branding. I can cover the logo, theme and login page before you start.'),
    suggestions: register === 'experienced'
      ? ['What does branding change?', 'Which files work best for the logo?', 'Can I change this later?']
      : ['What will my team see?', 'What should I have ready?', 'Can I change this later?'],
  }),
  logo: (facts, register) => ({
    name: 'Upload your brand assets',
    purpose: 'The person uploads a logo, brand guide or website screenshot. Bryte suggests a standalone logo, and the colors can come from it on the next step. A usable logo with no extractable colors is accepted; the person chooses colors by hand.',
    onScreen: [
      'An upload area: choose up to 5 PNG, JPG, SVG, WebP images or PDF documents, up to 2 MB each',
      'Uploaded brand assets, with Use as your brand logo on each image',
      'Retry analysis if the logo suggestion didn’t work',
      'Actions: Next, Back, and Skip, I’ll pick a ready-made palette',
      saveLaterGuidance,
    ],
    state: [
      `Images uploaded: ${count(facts.uploads)}`,
      yesNo(facts.logoChosen, 'A logo is chosen', 'No logo is chosen yet'),
    ],
    welcome: pick(register,
      'You’re on the logo step. Upload what you have, and I’ll suggest which image is your logo.',
      'You’re on logo upload. I can cover file types, sizing and how the logo suggestion works.'),
    suggestions: register === 'experienced'
      ? ['What file types and sizes work best?', 'How is the logo picked from my uploads?', 'Can I skip the logo for now?']
      : ['What kind of logo file works best?', 'What if I don’t have a logo?', 'How do you know which image is my logo?'],
  }),
  colors: (facts, register) => ({
    name: 'Theme',
    purpose: `The person picks the theme colors used across UKG Ready: a primary color for the header and main buttons, and an accent color for highlights. Ready-made palettes are always available. Custom holds only the company’s own colors, taken from its logo or entered by hand${facts.customAvailable ? '' : ', so it appears once the person enters a color code, uses Choose color, or adds a logo with usable colors'}.`,
    onScreen: [
      facts.customAvailable
        ? 'Choose a palette in the right panel above the preview: Custom, with the company’s own colors, and the ready-made palettes'
        : 'Choose a palette in the right panel above the preview: the ready-made palettes only; there is no Custom option yet',
      'Primary color and Accent color, each with an editable hex code field and a color picker; entering a code or using Choose color switches the palette to Custom with those colors, including after Skip',
      'Upload company logo without a supplied logo, or Update company logo with one: PNG, JPG, SVG or WebP, not PDF. A usable logo without extractable colors is accepted for manual color selection.',
      'Contrast guidance when text on the primary color would be hard to read, with suggested adjustments',
      'A preview of the header, buttons and login page in the chosen colors',
      'Actions: Next and Back',
      saveLaterGuidance,
    ],
    state: [
      `Palette: ${typeof facts.palette === 'string' && facts.palette ? facts.palette : 'Custom'}`,
      ...(facts.primaryColor ? [`Primary color: ${facts.primaryColor}`] : []),
      ...(facts.accentColor ? [`Accent color: ${facts.accentColor}`] : []),
      ...contrastLine(facts.primaryColor),
      ...(facts.presetPalettesOnly ? ['The upload step was skipped; manual color entry remains available'] : []),
      facts.customAvailable
        ? 'Custom is available with the company’s own colors'
        : 'Custom isn’t listed because no colors were taken from a logo or entered by hand',
      ...(facts.colorsFromLogo ? ['The custom colors came from the uploaded logo'] : []),
    ],
    welcome: pick(register,
      'You’re choosing your theme colors. I can explain where each color shows up and how to keep text readable.',
      'You’re on Theme. I can cover primary and accent usage, readable text and palette choices.'),
    suggestions: register === 'experienced'
      ? ['Where is the accent color used?', 'What contrast ratio does this need?', 'Should I use a ready-made palette?']
      : ['Where will my primary color show up?', 'Why does contrast matter?', 'Which colors work best together?'],
  }),
  login: (facts, register) => ({
    name: 'Login page',
    purpose: 'The person sets up the login page, the first thing the team sees when they sign in: the company name under the logo and a message beside the sign-in form.',
    onScreen: [
      'Field: Company name, shown under the logo at the top of the login page',
      'Employee login message editor, shown beside the sign-in form',
      'Draft with Bryte, which helps write the message',
      'A preview of the login page',
      facts.advancedNext
        ? 'Actions: Next, which opens Advanced settings, the last step, and Back'
        : 'Actions: Save branding for own setup or edits, Apply branding when editing a copy from another company, and Back',
      saveLaterGuidance,
    ],
    state: [
      yesNo(facts.companyNameEntered, 'Company name is filled in', 'Company name is empty'),
      yesNo(facts.messageWritten, 'An employee login message is written', 'No employee login message yet'),
      yesNo(facts.logoShown, 'The logo shows on the login page', 'The logo is hidden on the login page'),
    ],
    welcome: pick(register,
      'You’re setting up the login page your team sees when they sign in. I can help you decide what to show and what to say in your message.',
      'You’re on the login page. I can cover the company name, the employee message and what the preview shows.'),
    suggestions: ['What should my login message say?', 'Where does the company name appear?', 'Who sees this page?'],
  }),
  // Archived implementation team demos only; customer setups never show this screen.
  advanced: (facts, register) => ({
    name: 'Advanced settings',
    purpose: 'The last setup step in the implementation team demos: the browser tab icon (favicon), the icon on sign-in approval screens (OAuth icon), and whether clocks show in the header and on the login page.',
    onScreen: [
      'Intro: everything here is optional; anything skipped keeps its default and can be changed later',
      'Display options: Show the clock in the application header, Show the clock on the login page',
      'Favicon, which appears in browser tabs and bookmarks (a square 32 × 32px PNG, JPG or ICO image is recommended)',
      'OAuth icon, which represents the company on the screens where people approve another app’s access to their account, called OAuth authorization (a square 84 × 84px JPG or PNG is recommended)',
      'Actions: Save branding and Back, which returns to Login page',
      saveLaterGuidance,
    ],
    state: [
      yesNo(facts.faviconAdded, 'A favicon is uploaded', 'No favicon yet'),
      yesNo(facts.oauthIconAdded, 'An OAuth icon is uploaded', 'No OAuth icon yet'),
      yesNo(facts.headerClock, 'Header clock is on', 'Header clock is off'),
      yesNo(facts.loginClock, 'Login page clock is on', 'Login page clock is off'),
    ],
    welcome: pick(register,
      'You’re on Advanced settings. I can explain the browser tab icon, the sign-in icon and the clock options.',
      'You’re on Advanced settings. I can cover favicon and OAuth icon specs and the header and login clock options.'),
    suggestions: register === 'experienced'
      ? ['What size should the favicon be?', 'Where does the OAuth icon appear?', 'Do the clock settings affect everyone?']
      : ['What is a favicon?', 'What is an OAuth icon for?', 'Should I show the clock?'],
  }),
  done: (facts, register) => ({
    name: 'What’s next?',
    purpose: 'Branding is saved, and the team sees it when they sign in. It can be edited anytime. The person can check the result or move on to the next setup task.',
    onScreen: [
          'Completed: the company, its setup status and when its branding was saved',
          'Edit icon on the company card: Edit branding for the company. Opens Theme with saved values or unfinished edits; Back returns to this company card and nothing changes until Save branding.',
          ...nextStepActions,
          'A preview of the saved branding',
        ],
    state: [
      yesNo(facts.updated, 'Branding was updated a moment ago', 'Branding was saved a moment ago'),
      ...(facts.editInProcess ? ['An edit is still in progress'] : []),
    ],
    welcome: pick(register,
      facts.single
        ? 'Your branding is saved. Use the edit icon on your company card to make changes anytime. I can help you invite others or decide what to set up next.'
        : 'Your branding is saved. I can explain how to change it later or what to set up next.',
      facts.single
         ? 'Branding is saved. The edit icon on the company card opens Theme. I can cover edits, inviting others, or the Global Setup placeholder.'
        : 'Branding is saved. I can cover edits, previewing the login page, or the next setup task.'),
    suggestions: ['How do I change my branding later?', 'When will people see the new branding?', 'What should I set up next?'],
  }),
  'company-chooser': (facts, register) => ({
    name: 'Select a company',
    purpose: 'The business has more than one company, each listed with its federal tax ID (EIN). The person picks one company to brand first; once its branding is saved, it can be copied to the others, so it’s only set up once.',
    onScreen: ['Cards for each company with its setup status', 'Actions: Continue and Back'],
    state: companiesState(facts),
    welcome: pick(register,
      'Pick one company to brand first. Once its branding is saved, you can copy it to your other companies, so you only set it up once.',
      'Choose the first company EIN to brand. You can copy its branding to the other EINs afterward.'),
    suggestions: ['Which company should I start with?', 'Can each company use different branding?', 'How does copying branding work?'],
  }),
  'company-list': (facts, register) => ({
    name: count(facts.savedCompanies) > 0 ? 'What’s next?' : 'Select a company',
    purpose: count(facts.savedCompanies) > 0
      ? 'The list of company EINs (federal tax IDs) and their branding status. Each company can be edited, or get branding copied from another company that has saved it.'
      : 'The list of company EINs (federal tax IDs) and unfinished branding. Start or continue one company first; copying becomes available after a confirmed save.',
    onScreen: ['Cards for each company with status wording such as In progress, Edit in progress or Updated', ...companyCardActions(facts), ...companyListActions(facts)],
    state: companiesState(facts),
    welcome: count(facts.savedCompanies) > 0
      ? pick(register,
        'Here are your companies and where each one stands. I can explain the statuses or how to copy branding from one company to another.',
        'This is your EIN list with branding status. I can cover statuses, copying branding between EINs, and edits in progress.')
      : 'Start or continue one company’s branding here. I can explain the statuses and help you decide where to begin. Copying becomes available after branding is saved.',
    suggestions: count(facts.savedCompanies) > 0
      ? ['What do the statuses mean?', 'How do I copy branding to another company?', 'What happens to an edit in progress?']
      : ['Which company should I start with?', 'How do I continue unfinished branding?', 'What do the statuses mean?'],
  }),
  'copy-branding': (facts, register) => ({
    name: 'What’s next?',
    purpose: count(facts.savedCompanies) > 0
      ? 'Copy saved branding from one company to others to save time, so they share the same branding, or edit a company’s branding. Each copy can be reviewed before it’s saved.'
      : 'Start or continue one company’s branding. No company has saved branding yet, so no Copy branding buttons are available.',
    onScreen: ['Cards for each company with its branding status', ...companyCardActions(facts), ...companyListActions(facts)],
    state: companiesState(facts),
    welcome: count(facts.savedCompanies) > 0
      ? pick(register,
        'You can copy saved branding from one company to your others here. I can walk you through how copying works and what changes.',
        'Copy saved branding between EINs here. I can cover what gets copied and how it affects saved branding.')
      : 'No company has saved branding yet. Set up or continue one company first, then you can copy its branding to the others.',
    suggestions: count(facts.savedCompanies) > 0
      ? ['What gets copied?', 'Will copying replace saved branding?', 'Can I change copied branding afterward?']
      : ['Which company should I start with?', 'How do I continue unfinished branding?', 'What do the statuses mean?'],
  }),
  'saved-look': (facts, register) => ({
    name: 'Your saved branding',
    purpose: 'A summary of the saved branding for one company: logo, palette, colors and login page, with a preview. This is what the team sees now, and it can be edited anytime.',
    onScreen: ['Branding summary: logo and colors below; company name and login message in the Login page preview', 'Actions: Edit branding and Back', 'Back from Theme during an edit returns to this summary without opening Upload your brand assets'],
    state: [
      ...(facts.palette ? [`Palette: ${facts.palette}`] : []),
      ...(facts.primaryColor ? [`Primary color: ${facts.primaryColor}`] : []),
      ...(facts.accentColor ? [`Accent color: ${facts.accentColor}`] : []),
      yesNo(facts.logoAdded, 'A logo is saved', 'No logo is saved yet'),
      ...(facts.editInProcess ? ['An edit is in progress; the saved branding hasn’t changed'] : []),
    ],
    welcome: pick(register,
      'This is your saved branding. I can explain what each part controls or how to make a change.',
      'This is the saved branding. I can cover what each setting controls and how edits in progress work.'),
    suggestions: ['How do I change my colors?', 'What happens if I start an edit?', 'Where does this branding show up?'],
  }),
  'copy-review': (facts, register) => ({
    name: 'Review copied branding',
    purpose: 'The person checks branding copied from another company (logo, colors, company name and login message) before it’s saved for this one. They can change which company it comes from, edit it, apply it, or discard the changes.',
    onScreen: ['Check the logo and colors below, and the company name and login message in the Login page preview, before they’re saved for this company', 'Change the company to copy from', 'Actions: Apply branding and Discard changes'],
    state: [
      `Companies receiving this branding: ${count(facts.destinations)}`,
      ...(facts.palette ? [`Palette: ${facts.palette}`] : []),
      yesNo(facts.editing, 'The copied branding is being edited', 'The copied branding is unchanged'),
    ],
    welcome: pick(register,
      'You’re checking branding copied from another company. I can explain what applying does and how to adjust it first.',
      'You’re reviewing copied branding before applying it. I can cover what apply changes and how to adjust it.'),
    suggestions: ['What happens when I apply this?', 'Can I change it before applying?', 'What if I pick the wrong company?'],
  }),
} satisfies AskBryteCatalog
