import { readFileSync } from 'node:fs'
import { registerHooks } from 'node:module'
import { fileURLToPath } from 'node:url'

// Vite's ?raw SVG imports also need to work in Node's source-level unit tests.
registerHooks({
  load(url, context, nextLoad) {
    if (!url.startsWith('file:') || !url.endsWith('.svg?raw')) return nextLoad(url, context)
    return {
      format: 'module',
      shortCircuit: true,
      source: `export default ${JSON.stringify(readFileSync(fileURLToPath(url), 'utf8'))}`,
    }
  },
})