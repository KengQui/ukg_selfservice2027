import path from 'node:path'
import { createHash } from 'node:crypto'
import { readFile, readdir } from 'node:fs/promises'

// The deployed frontend, API snapshot, and published verifier hash the same
// branding-owned files. The gallery is intentionally not an input.
export const brandingBoot = [
  'artifacts/branding/index.html',
  'artifacts/branding/vite.config.ts',
  'artifacts/branding/package.json',
  'artifacts/branding/branding-fingerprint.mjs',
  'lib/setup-shared/src/base.css',
  'lib/setup-shared/package.json',
]

export const brandingDirectories = [
  'artifacts/branding/src',
  'lib/setup-shared/src/templates/selfservice-shell',
  'lib/setup-shared/src/prototypes/_shared',
  'lib/setup-shared/src/prototypes/_shared-company-setup',
  'lib/setup-shared/src/prototypes/branding-demo',
]

export async function brandingAppFingerprint(root) {
  const hash = createHash('sha256')
  const files = [...brandingBoot]
  async function walk(directory) {
    for (const entry of (await readdir(path.join(root, directory), { withFileTypes: true }))
      .sort((a, b) => a.name.localeCompare(b.name))) {
      const relative = path.posix.join(directory, entry.name)
      if (entry.isDirectory()) await walk(relative)
      else if (entry.isFile()) files.push(relative)
      else throw new Error(`Unsupported branding fingerprint input: ${relative}`)
    }
  }
  for (const dir of brandingDirectories) await walk(dir)
  for (const relative of files) hash.update(relative).update(await readFile(path.join(root, relative)))
  return hash.digest('hex')
}