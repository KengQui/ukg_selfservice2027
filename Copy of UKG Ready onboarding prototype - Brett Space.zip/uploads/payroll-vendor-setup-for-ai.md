# Payroll Vendor Payment Setup — AI Handoff Document

Purpose: this document captures the payroll vendor payment configuration
implemented in the Smart Vendor Configuration flow of this prototype, in
enough detail for another AI (or engineer) to reproduce the setup logic,
decision tree, and derived values. Source of truth in this repo:
`resources/flows.js` (flow id `vendorConfiguration`) rendered by
`index.html`.

## Context

- Product: benefit-plan / payroll configuration prototype (UKG Ready demo).
- The flow configures how vendor payments — money deducted from employees'
  paychecks (benefits premiums, garnishments, retirement contributions) —
  reach each vendor.
- System-derived context available before the flow starts:
  - Payroll services client: no
  - Company funding: established — Reverse Wire money-movement profile
  - EINs: ABC Company (12-3456789), XYZ Subsidiary (98-7654321)

## Flow overview (7 counted steps; sub-steps share the parent step number)

1. **Who does your company pay?** — user builds the complete vendor list
   before any configuration questions. The list is pre-seeded with sample
   vendors (Blue Cross, Delta Dental, Texas State Disbursement Unit, ABC
   Garnishment Agency).
2. **Missing Vendor Information** (backend coverage check) — payroll
   deduction codes are compared against the vendor list; missing coverage
   (e.g. 401K) must be resolved: add the vendor, or explicitly skip.
3. **Court-Ordered & Government-Mandated** — classify each vendor
   (court-ordered/government-mandated vs. not). Determines compliance
   handling.
4. **HR/Benefits Availability** — whether each vendor is available in
   HR/Benefits modules.
5. **Vendor Payment Responsibility** — per vendor with "Used for Payroll"
   enabled: will Ready send the payments? "No" records the vendor as
   **No Payment** and skips all payment configuration for it.
6. **Check or ACH** — per vendor Ready is responsible for paying, choose
   the payment method: **Check**, **ACH**, or **Not yet confirmed**.
   - No option is preselected; an explicit choice is required.
   - "Not yet confirmed" is tracked as an open item (vendor is created
     with payment details pending).
7. **Payment details, review, validation, creation** — check vendors and
   ACH vendors are configured individually (sub-steps below), then a final
   review validates and creates every vendor at once.

## Check vendors — "Set Up Check Payments"

Per check vendor (example: ABC Garnishment Agency):

- Question: **Does this vendor require a separate check for each
  case/deduction?** (no preselection)
  - Yes — one check per case number → check payment type: per-case check.
  - No — one combined check → combined check.
- The vendor's payment address / payee details are shown as a fact card
  with an in-card confirmation: **"Do these details match the vendor's
  payment instructions?"** — options: *Yes, it matches* / *Revision
  required* (required).

## ACH vendors — decision tree (per vendor)

Later questions stay hidden until the earlier ones are answered; nothing
is preselected.

1. **Are payments sent to a different destination account for each
   employee?**
   - *A different account for each employee* → ACH payment type is
     **ACH – Employee Level**; the transaction-style question is skipped.
   - *One destination account for the vendor* → continue.
2. **How does the vendor require ACH transactions?** (from the vendor's
   ACH/payment instructions; never guessed)
   - Separate transaction for each case/deduction → per-case ACH.
   - Combined transaction with one Addenda record (**CCD**).
   - Combined transaction with multiple Addenda records (**CTX**).
3. **ACH Addenda Type** (only when combined CCD/CTX):
   - Payment remittance detail
   - DED — child support / deduction detail
4. **Derived ACH payment type** — computed read-only from the answers
   above; the user reviews it instead of picking Ready terminology.
5. **Banking details** — account type (Checking / Savings), routing
   number, account number, entered/confirmed against the vendor's payment
   instructions. Missing information flags the vendor **ACH Information
   Required** (open item) rather than blocking creation.

Sample ACH vendors and prefilled banking values (demo data):
- Blue Cross — routing 121000358, account 4402198801
- Delta Dental — routing 026009593, account 7710453392
- Texas State Disbursement Unit — routing 111900659, account 3300127745

## Open-item model

Vendors can be created with unresolved information. Anything answered
"Not yet confirmed" (payment method, banking details, verification) is
labeled **Not yet confirmed** and surfaced as an open item after creation
— creation is never blocked on missing vendor instructions.

## Copy & UX conventions (apply to any regenerated copy)

- Never use the word "wizard" in user-facing copy.
- Subtexts explain **why** a step matters in a **positive tone** (e.g.
  "The right routing and account numbers make sure money withheld from
  employees' paychecks reaches the right place"), not a list of steps.
- No preselected answers for decision questions; required fields show no
  red asterisk — the continue button stays disabled instead.
- Per-vendor screens show the step kicker of the parent counted step
  (e.g. "Step 4 of 7" plus "1 of 3" page indicator on multi-vendor
  screens) and page headings are just the vendor name.
- Derived values (payment types) are always shown read-only for review,
  never asked in system terminology.
