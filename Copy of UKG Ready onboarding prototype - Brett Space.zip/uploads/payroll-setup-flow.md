# Lighthouse Payroll Setup Flow — AI Reference Document

This document explains the payroll setup prototype (`artifacts/payroll-setup`, served at `/`) so that another AI (or developer) can understand, extend, or reason about the flow. It covers the product concept, the core interaction model, each step, the data model, and the two entry paths (document-driven vs. manual).

## 1. What this is

An interactive UX prototype that reimagines UKG's fragmented self-service payroll setup — originally five separate AI-chat sessions with handoffs to legacy admin screens — as **one cohesive six-step guided wizard**. It is frontend-only: no backend or database. All state lives in a single React context (`src/hooks/use-setup-state.tsx`). Sample data comes verbatim from real UAT screen recordings.

## 2. The core interaction model: Extract → Review & Confirm → Edit

This is the most important concept for understanding the flow:

**The user does not fill out blank forms.** Instead:

1. **Upload once, up front.** At the start, the user uploads their payroll documents (tax forms, voided checks, prior payroll reports). A simulated AI extraction pass reads them and pre-fills *all* subsequent steps at once.
2. **Review and confirm, step by step.** Each following step presents the extracted data as populated, editable cards. The user's job is to *verify* the information — not to enter it. Extracted fields are visually marked (a "Sparkles"/AI-extracted indicator) so the user knows what came from their documents.
3. **Correct anything, inline.** Every extracted value is directly editable in place. Validation problems are surfaced inline with suggested fixes (e.g. "Invalid city for zip code 53718. Did you mean Madison?") rather than blocking errors on legacy screens.
4. **Add manually at any point.** Every collection step (EINs, schedules, banks) has an explicit "Add" affordance, so users can supplement or replace extracted data with manual entries.

So the mental model an AI should hold: **the wizard is a confirmation surface over AI-extracted data, with full manual override.** Confirmation (clicking "Continue") is an implicit sign-off on the data shown at that step.

## 3. Two entry paths

### Path A — Document-driven (primary / happy path)
- Step 0: user clicks "Upload Documents" → `startExtraction()` → `intakeStatus` goes `idle → extracting → done` (~2s simulated).
- On completion, `extractedDocs = { eins: true, schedule: true, banks: true }` and the EINs, pay schedule, bank account, and defaults are all pre-filled.
- The user then walks steps 1–5 reviewing/confirming/correcting.

### Path B — Manual entry (fully supported fallback)
- Step 0: user chooses to enter data manually → `setManualEntry()` → `intakeStatus = "manual"`.
- Steps 1–3 start empty and show a dashed empty-state card with an "Add EIN" / "Add pay schedule" / "Add bank account" action (`addEin()`, `addSchedule()`, `addBank()`).
- New records get sensible defaults (first EIN becomes default; a new bank auto-becomes the funding/tax account if none is set).
- The manual path reaches the same Review & Finish step; there are no dead ends.

Both paths can mix: a user who uploaded documents can still add more records manually, and vice versa.

## 4. The six steps

| # | Step | Purpose |
|---|------|---------|
| 0 | Welcome & Documents | Smart document intake: upload → simulated AI extraction, or opt into manual entry. |
| 1 | Company EINs | Review/confirm extracted tax identifiers (legal name, address, tax ID, ID type, default flag). Inline validation with suggested corrections; embedded NAICS code picker (no legacy screen handoff). "Continue" is blocked while a validation error is unresolved. |
| 2 | Pay Schedule | Review/confirm the pay schedule profile (frequency, start date, periods per year, which EINs it applies to) with a calendar preview of upcoming pay periods. |
| 3 | Bank Accounts | Review/confirm bank details (bank name, routing/account, ACH transfer type, account type) plus consolidated purpose questions (payroll funding / tax payments / vendor payments) asked together rather than one at a time. |
| 4 | Defaults | Auto-configured default funding account, tax payment account, and vendor payment settings — derived from the bank step, presented for confirmation, still editable. |
| 5 | Review & Finish | Grouped summary of everything confirmed, with edit links that jump back to any earlier step. Final confirmation completes setup. |

Navigation: a persistent left sidebar progress rail shows all six steps with completed/current states. Each step has Back / Continue buttons. The "Bryte" assistant sits in the sidebar as a contextual helper rather than being the container for the flow (a deliberate inversion of the original chat-first UX).

## 5. Data model (from `use-setup-state.tsx`)

```ts
IntakeStatus = "idle" | "extracting" | "done" | "manual"

EIN         { id, taxId, legalName, address, city, state, zip, phone,
              idType ("EIN" | "SSN"), isDefault, naicsCode, validationError? }
PaySchedule { id, profileName, frequency, startDate, periodsPerYear, appliedEinIds[] }
BankAccount { id, name, bankName, city, state, routing, account,
              transferType, accountType, purposes[] ("payroll" | "tax" | "vendor") }

SetupState  { currentStep (0–5), intakeStatus,
              extractedDocs { eins, schedule, banks },   // which sections were AI-filled
              eins[], schedules[], banks[],
              defaults { fundingAccountId, taxPaymentAccountId, vendorPaymentSettings } }
```

Context actions: `setCurrentStep`, `startExtraction`, `setManualEntry`, `updateEin`, `updateSchedule`, `updateBank`, `updateDefaults`, `addEin`, `addSchedule`, `addBank`.

Notes:
- `extractedDocs` flags drive the "AI-extracted" badges — steps only show extraction indicators when their section was actually filled from documents.
- `validationError` on an EIN is the inline-correction mechanism; step 1's Continue button is disabled while any EIN has an unresolved error.
- Defaults auto-wire: extraction sets `bank-1` as both funding and tax account; manual `addBank` fills any unset default with the new account.

## 6. Where the code lives

```
artifacts/payroll-setup/src/
├── pages/setup.tsx                 # Wizard shell: sidebar rail + step switch
├── hooks/use-setup-state.tsx       # All state, sample data, and actions (source of truth)
└── components/setup/
    ├── step-intake.tsx             # Step 0: upload / extraction / manual choice
    ├── step-eins.tsx               # Step 1: EIN review + validation + NAICS
    ├── step-schedule.tsx           # Step 2: pay schedule + calendar preview
    ├── step-banks.tsx              # Step 3: bank accounts + purpose questions
    ├── step-defaults.tsx           # Step 4: auto-configured defaults
    ├── step-review.tsx             # Step 5: summary with jump-back edit links
    └── bryte-assistant.tsx         # Sidebar contextual assistant
```

## 7. Design principles to preserve when extending

1. **Never make the user re-enter what was extracted** — new fields should be pre-filled from extraction when possible and merely confirmed.
2. **Extraction is transparent** — always mark which values came from documents vs. entered by hand.
3. **Errors are conversations, not walls** — inline validation with suggested fixes, only blocking progression when truly necessary.
4. **Manual entry is a first-class path** — every collection must have an empty state with an Add action; no step may dead-end without extracted data.
5. **One flow, no handoffs** — anything that used to be a legacy screen (NAICS lookup, pay period calendar, check info) is embedded inline.
